package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirAdkBasvuru;
import tr.com.aktifbank.bnspr.dao.BirAzamiFaizOranPr;
import tr.com.aktifbank.bnspr.dao.BirBasvuruKartBilgi;
import tr.com.aktifbank.bnspr.dao.BirBasvuruKonsolidasyon;
import tr.com.aktifbank.bnspr.dao.BirNbsmMusteriSegment;
import tr.com.calikbank.bnspr.consumerloan.netmera.EventTypeEnum;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlik;
import tr.com.calikbank.bnspr.dao.BirKampanya;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.dao.BirKullandirimTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.module.custom.services.LOVExecuter;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3132Services {
	private final static Logger LOGGER = Logger.getLogger(ConsumerLoanTRN3132Services.class);
	
	@GraymoundService("BNSPR_TRN3132_GET_INFO")
	public static GMMap getInfoTRN3132(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			Session session = DAOSession.getSession("BNSPRDal");

			BirKullandirimTx birKullandirimTx = (BirKullandirimTx) session.get(BirKullandirimTx.class, iMap.getBigDecimal("TRX_NO"));

			oMap.put("BASVURU_NO", birKullandirimTx.getBasvuruNo());
			oMap.put("MUSTERI_NO", birKullandirimTx.getMusteriNo());
			oMap.put("DI_MUSTERI_NO", LovHelper.diLov(birKullandirimTx.getBasvuruNo(), "3132/LOV_BASVURU_VIEW", "ADI_SOYADI"));
			oMap.put("VALOR", birKullandirimTx.getValor());
			oMap.put("SUBE_KOD", birKullandirimTx.getSubeKod());
			oMap.put("ISLEM_TARIHI", birKullandirimTx.getIslemTar());
			oMap.put("FIRMA_MUSTERI_NO", birKullandirimTx.getFirmaMusteriNo());
			oMap.put("DI_FIRMA_MUSTERI_NO", LovHelper.diLov(birKullandirimTx.getFirmaMusteriNo(), DALUtil.getResult("select b.satici_kod FROM BIR_BASVURU B WHERE b.basvuru_no='" + birKullandirimTx.getBasvuruNo() + "'"), "3132/LOV_FIRMA_MUSTERI_NO", "UNVAN"));
			oMap.put("FIRMA_HESAP_NO", birKullandirimTx.getFirmaHesapNo());
			oMap.put("BAYI_HESAP_NO", birKullandirimTx.getBayiHesapNo());
			oMap.put("BAYI_MUSTERI_NO", birKullandirimTx.getBayiMusteriNo());
			oMap.put("DI_BAYI_MUSTERI_NO", LovHelper.diLov(birKullandirimTx.getBayiMusteriNo(), DALUtil.getResult("select b.satici_kod FROM BIR_BASVURU B WHERE b.basvuru_no='" + birKullandirimTx.getBasvuruNo() + "'"), "3132/LOV_BAYI_MUSTERI_NO", "UNVAN"));
			oMap.put("KRD_HESAP_NO", birKullandirimTx.getKrdHesapNo());
			oMap.put("ALAC_HESAP_NO", birKullandirimTx.getAlacHesapNo());
			oMap.put("OTO_VIRMAN", birKullandirimTx.getOtoVirman());
			oMap.put("OTO_VIRMAN_HESAP", birKullandirimTx.getOtoVirmanHesap());
			oMap.put("ACIKLAMA", birKullandirimTx.getAciklama());
			oMap.put("KRD_TUTAR_TL", birKullandirimTx.getKrdTutarTl());
			oMap.put("KUR", birKullandirimTx.getKur());
			oMap.put("KRD_DOVIZ_KOD", birKullandirimTx.getKrdDovizKod());
			oMap.put("KRD_TUTAR", birKullandirimTx.getKrdTutar());
			oMap.put("BAYI_KOM", birKullandirimTx.getBayiKom());
			oMap.put("MUS_KOM", birKullandirimTx.getMusKom());
			oMap.put("DOSYA_MASRAF", birKullandirimTx.getDosyaMasraf());
			oMap.put("TEM_SIG_PRIM", birKullandirimTx.getTemSigPrim());
			oMap.put("FARK_FAIZ", birKullandirimTx.getFarkFaiz());
			oMap.put("KREDI_SIG_PRIM", birKullandirimTx.getKrediSigPrim());
			oMap.put("AVUKAT_UCRET", birKullandirimTx.getAvukatUcret());
			oMap.put("EXPERTIZ_UCRET", birKullandirimTx.getExpertizUcret());
			oMap.put("KKDF", birKullandirimTx.getKkdfOran());
			oMap.put("BSMV", birKullandirimTx.getBsmvOran());
			oMap.put("FAIZ_ORANI", birKullandirimTx.getFaizOrani());
			oMap.put("SIGORTA_HESABI", birKullandirimTx.getSigortaHesabi());
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3132_GET_SIGORTA_BILGILERI", iMap));
			oMap.put("SIGORTA_KOMISYON", birKullandirimTx.getSigortaKomisyon());
			oMap.put("KREDI_SIGORTA_PRIMI", birKullandirimTx.getKrediSigPrim());
			oMap.put("SIGORTA_HESABI_2", birKullandirimTx.getSigortaHesabi2());
			oMap.put("SIGORTA_KOMISYON_2", birKullandirimTx.getSigortaKomisyon2());
			oMap.put("KREDI_SIGORTA_PRIMI_2", birKullandirimTx.getKrediSigPrim2());
			oMap.put("SIGORTA_HESABI_3", birKullandirimTx.getSigortaHesabi3());
			oMap.put("SIGORTA_KOMISYON_3", birKullandirimTx.getSigortaKomisyon3());
			oMap.put("KREDI_SIGORTA_PRIMI_3", birKullandirimTx.getKrediSigPrim3());
			oMap.put("KRD_TUR", birKullandirimTx.getKrdTur());
			oMap.put("DI_KRD_TUR", LovHelper.diLov(birKullandirimTx.getKrdTur(), "3131/LOV_KREDI_TUR", "ACIKLAMA"));
			oMap.put("VADE", birKullandirimTx.getVade());
			oMap.put("ALAC_DOVIZ_KODU", birKullandirimTx.getAlacDovizKod());
			oMap.put("KRD_TIP_KOD", birKullandirimTx.getKrdAltTur());
			oMap.put("DI_KRD_TIP", LovHelper.diLov(birKullandirimTx.getKrdAltTur(), birKullandirimTx.getKrdTur(), "3109/LOV_KREDI_TIPI", "ACIKLAMA"));
			oMap.put("ALT_KRD_TIP", birKullandirimTx.getKrdAltTur2());
			oMap.put("DI_ALT_KRD_TIP", LovHelper.diLov(birKullandirimTx.getKrdAltTur2(), birKullandirimTx.getKrdTur(), birKullandirimTx.getKrdAltTur(), "3109/LOV_ALT_KREDI_TIP", "ACIKLAMA"));
			oMap.put("KANAL_KODU", birKullandirimTx.getKanalKodu());
			// oMap.put("DISTRIBUTOR_HESAP_NO", birKullandirimTx.getDistHesapNo());

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3132_CONTROL")
	public static GMMap afterControl(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap fMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			/** azami faiz oran kontrol **/
			BirBasvuru basvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			BirKampanya birKampanya = (BirKampanya) session.get(BirKampanya.class, basvuru.getKampKod());
			fMap.put("TICARI_KREDI_EH", "E".equals(birKampanya.getTicariKrediEh()) ? true : false);
			fMap.put("KAMPANYA_KOD", birKampanya.getKod());
			fMap.put("KREDI_TURU", birKampanya.getKrdTurKod());
			BirAzamiFaizOranPr azamiFaizOrani = ConsumerLoanTRN3112Services.findBirAzamiFaiz(fMap);

			BigDecimal faiz = iMap.getBigDecimal("FAIZ_ORANI");
			BigDecimal vade = iMap.getBigDecimal("VADE");
			if (ConsumerLoanTRN3112Services.azamiFaizAsildi(faiz, vade, azamiFaizOrani)) {
				throw new GMRuntimeException(0, "Azami faiz oran� �zerinde kredi kullan�lamaz. Bilgi almak i�in 0850 724 30 50 Aktif Bank �leti�im Merkezi ile g�r��ebilirsin.");
			}
		}
		catch (GMRuntimeException e) {
			throw e;
		}
		catch (Exception e) {
			oMap.put("HATA_EH", "E");
			oMap.put("HATA_ACK", e.getMessage());
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3132_SAVE")
	public static Map<?, ?> saveTRN3132(GMMap iMap) {
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		CallableStatement stmt3 = null;
		Connection conn = null;

		try {
			
			GMServiceExecuter.call("BNSPR_TRN3132_CONTROL", iMap);
			
			conn = DALUtil.getGMConnection();

			Session session = DAOSession.getSession("BNSPRDal");

			BirKullandirimTx birKullandirimTx = (BirKullandirimTx) session.get(BirKullandirimTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birKullandirimTx == null)
				birKullandirimTx = new BirKullandirimTx();

			birKullandirimTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birKullandirimTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birKullandirimTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			birKullandirimTx.setValor(iMap.getDate("VALOR"));
			birKullandirimTx.setIslemTar(DateUtils.truncate(new java.util.Date(), Calendar.DATE));
			birKullandirimTx.setSubeKod(iMap.getString("SUBE_KOD"));
			birKullandirimTx.setFirmaMusteriNo(iMap.getBigDecimal("FIRMA_MUSTERI_NO"));
			birKullandirimTx.setFirmaHesapNo(iMap.getBigDecimal("FIRMA_HESAP_NO"));
			birKullandirimTx.setBayiHesapNo(iMap.getBigDecimal("BAYI_HESAP_NO"));
			// birKullandirimTx.getDistHesapNo(iMap.getBigDecimal("DIST_HESAP_NO"));
			birKullandirimTx.setBayiMusteriNo(iMap.getBigDecimal("BAYI_MUSTERI_NO"));
			birKullandirimTx.setKrdHesapNo(iMap.getBigDecimal("KRD_HESAP_NO"));
			birKullandirimTx.setAlacHesapNo(iMap.getBigDecimal("ALAC_HESAP_NO"));
			birKullandirimTx.setOtoVirman(iMap.getString("OTO_VIRMAN"));
			birKullandirimTx.setOtoVirmanHesap(iMap.getBigDecimal("OTO_VIRMAN_HESAP"));
			birKullandirimTx.setAciklama(iMap.getString("ACIKLAMA"));
			birKullandirimTx.setKrdTutarTl(iMap.getBigDecimal("KRD_TUTAR_TL"));
			birKullandirimTx.setKur(iMap.getBigDecimal("KUR"));
			birKullandirimTx.setKrdDovizKod(iMap.getString("KRD_DOVIZ_KOD"));
			birKullandirimTx.setKrdTutar(iMap.getBigDecimal("KRD_TUTAR"));
			birKullandirimTx.setBayiKom(iMap.getBigDecimal("BAYI_KOM"));
			birKullandirimTx.setMusKom(iMap.getBigDecimal("MUS_KOM"));
			birKullandirimTx.setDosyaMasraf(iMap.getBigDecimal("DOSYA_MASRAF"));
			birKullandirimTx.setTemSigPrim(iMap.getBigDecimal("TEM_SIG_PRIM"));
			birKullandirimTx.setFarkFaiz(iMap.getBigDecimal("FARK_FAIZ"));
			birKullandirimTx.setAvukatUcret(iMap.getBigDecimal("AVUKAT_UCRET"));
			birKullandirimTx.setExpertizUcret(iMap.getBigDecimal("EXPERTIZ_UCRET"));
			birKullandirimTx.setKkdfOran(iMap.getBigDecimal("KKDF"));
			birKullandirimTx.setBsmvOran(iMap.getBigDecimal("BSMV"));
			birKullandirimTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			birKullandirimTx.setSigortaHesabi(iMap.getBigDecimal("SIGORTA_HESABI"));
			birKullandirimTx.setSigortaKomisyon(iMap.getBigDecimal("SIGORTA_KOMISYON"));
			birKullandirimTx.setKrediSigPrim(iMap.getBigDecimal("KREDI_SIGORTA_PRIMI"));
			birKullandirimTx.setSigortaHesabi2(iMap.getBigDecimal("SIGORTA_HESABI_2"));
			birKullandirimTx.setSigortaKomisyon2(iMap.getBigDecimal("SIGORTA_KOMISYON_2"));
			birKullandirimTx.setKrediSigPrim2(iMap.getBigDecimal("KREDI_SIGORTA_PRIMI_2"));
			birKullandirimTx.setSigortaHesabi3(iMap.getBigDecimal("SIGORTA_HESABI_3"));
			birKullandirimTx.setSigortaKomisyon3(iMap.getBigDecimal("SIGORTA_KOMISYON_3"));
			birKullandirimTx.setKrediSigPrim3(iMap.getBigDecimal("KREDI_SIGORTA_PRIMI_3"));
			birKullandirimTx.setSigortaKomBsmvEh(iMap.getString("BSMV_EH"));
			birKullandirimTx.setKrdTur(iMap.getBigDecimal("KRD_TUR"));
			birKullandirimTx.setVade(iMap.getBigDecimal("VADE"));
			birKullandirimTx.setDrm("G");
			birKullandirimTx.setAlacDovizKod(iMap.getString("ALAC_DOVIZ_KODU"));
			birKullandirimTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
			birKullandirimTx.setDistributorHesapNo(iMap.getBigDecimal("DISTRIBUTOR_HESAP_NO"));
			birKullandirimTx.setFaizsizSure(iMap.getBigDecimal("FAIZSIZ_SURE"));

			String urunKampKod = iMap.getString("URUN_KAMP_KOD");
			String saticiKod = null;
			String paraCikisOtomatikMi = null;

			int pc = 1;
			stmt = conn.prepareCall("{? = call PKG_BIREYSEL2.SaticiKod(?)}");
			stmt.registerOutParameter(pc++, Types.VARCHAR);
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			saticiKod = stmt.getString(1);
			// saticiKod = DALUtil.getResult("select PKG_BIREYSEL2.SaticiKod('"+ iMap.getBigDecimal("BASVURU_NO")+"') from dual");

			if (saticiKod != null) {
				int pc2 = 1;
				stmt2 = conn.prepareCall("{? = call PKG_SATICI.ParaCikisOtomatikMi(?)}");
				stmt2.registerOutParameter(pc2++, Types.VARCHAR);
				stmt2.setInt(pc2++, Integer.parseInt(saticiKod));
				stmt2.execute();
				paraCikisOtomatikMi = stmt2.getString(1);
				// birKullandirimTx.setParaCikisOtoEh(DALUtil.getResult(" select PKG_SATICI.ParaCikisOtomatikMi('" + Integer.parseInt(saticiKod) +
				// "') from dual"));
				birKullandirimTx.setParaCikisOtoEh(paraCikisOtomatikMi);
			}
			else {
				birKullandirimTx.setParaCikisOtoEh("H");
			}

			if (urunKampKod.indexOf('-') < 0)
				birKullandirimTx.setKampKod(new BigDecimal(urunKampKod));
			else {
				birKullandirimTx.setKrdAltTur(iMap.getBigDecimal("KRD_TIP_KOD"));
				birKullandirimTx.setKrdAltTur2(iMap.getBigDecimal("ALT_KRD_TIP"));
			}
			birKullandirimTx.setKanalKodu(iMap.getString("KANAL_KODU"));
			birKullandirimTx.setYeniSigortaUrunNo(iMap.getBigDecimal("YENI_SIGORTA_URUN_NO"));

			session.saveOrUpdate(birKullandirimTx);
			session.flush();

			iMap.put("TRX_NAME", "3132");
			Map<?, ?> oMap = GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
			BigDecimal islemOnayli = (BigDecimal) DALUtil.callOneParameterFunction("{? = call pkg_tx.Islem_onaylanmis_mi(?)}", Types.NUMERIC, iMap.getBigDecimal("TRX_NO"));
			if(BigDecimal.ONE.compareTo(islemOnayli) == 0){
				try {
					GMMap iwdMap = new GMMap();
					iwdMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
					iwdMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
					GMServiceExecuter.executeAsync("BNSPR_CL_IWD_CREATE_TASK_KREDI_KONTROL", iwdMap);
				}
				catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
			}
			
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt3);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_KULLANDIRIM_SMS")
	public static GMMap kullandirimSMS(GMMap iMap) {
		GMServiceExecuter.execute("BNSPR_TRN3132_AFTER_APPROVAL", iMap);
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3132.KullandirimSMS(?,?,?,?)}");
			int pc = 1;
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.registerOutParameter(pc++, Types.DECIMAL);
			stmt.registerOutParameter(pc++, Types.VARCHAR);
			stmt.registerOutParameter(pc++, Types.VARCHAR);

			stmt.execute();
			String mesaj = stmt.getString(--pc);
			if (mesaj != null) {
				String cepTel = stmt.getString(--pc);
				GMMap iMap1 = new GMMap();
				iMap1.put("CONTENT", mesaj);
				iMap1.put("MSISDN", cepTel);
				GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS_ASYNC", iMap1).get("RESULT");
				// if(!mesg.substring(0, 1).equals("-"))
				// System.out.println(cepTel+" numarali telefona -"+ iMap1.getString("CONTENT")+ "- mesaji gonderilmistir.");
			}
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_GET_FIRMA_BAYI_MUSTERI_NO")
	public static GMMap getFirmaBayiMusteriNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			List<Object> inputList = new ArrayList<Object>();
			inputList.add(iMap.getString("SATICI_KOD"));
			List<?> list = LOVExecuter.execute("3132/LOV_BAYI_MUSTERI_NO", "%", inputList);
			if (list.size() != 0) {
				oMap.put("BAYI_MUSTERI_NO", ((HashMap<?, ?>) list.get(0)).get("MUSTERI_NO"));
				oMap.put("DI_BAYI_MUSTERI_NO", ((HashMap<?, ?>) list.get(0)).get("UNVAN"));
				oMap.put("BAYI_HESAP_NO", ((HashMap<?, ?>) list.get(0)).get("HESAP_NO"));
				oMap.put("BAYI_SUBE_KODU", ((HashMap<?, ?>) list.get(0)).get("HESAP_SUBE_KODU"));
				if (oMap.getString("BAYI_HESAP_NO") == null) {
					List<Object> hesapNoInputList = new ArrayList<Object>();
					hesapNoInputList.add(oMap.getString("BAYI_MUSTERI_NO"));
					List<?> listHesapNo = LOVExecuter.execute("3132/LOV_BAYI_HESAP_NO", "%", hesapNoInputList);
					if (listHesapNo.size() != 0) {
						oMap.put("BAYI_HESAP_NO", ((HashMap<?, ?>) listHesapNo.get(0)).get("HESAP_NO"));
						oMap.put("BAYI_SUBE_KODU", ((HashMap<?, ?>) listHesapNo.get(0)).get("HESAP_SUBE_KODU"));
					}
				}
			}

			list.clear();
			list = LOVExecuter.execute("3132/LOV_FIRMA_MUSTERI_NO", "%", inputList);
			if (list.size() != 0) {
				oMap.put("FIRMA_MUSTERI_NO", ((HashMap<?, ?>) list.get(0)).get("MUSTERI_NO"));
				oMap.put("DI_FIRMA_MUSTERI_NO", ((HashMap<?, ?>) list.get(0)).get("UNVAN"));
				oMap.put("FIRMA_HESAP_NO", ((HashMap<?, ?>) list.get(0)).get("HESAP_NO"));
				if (oMap.getString("FIRMA_HESAP_NO") == null) {
					List<Object> hesapNoInputList = new ArrayList<Object>();
					hesapNoInputList.add(oMap.getString("FIRMA_MUSTERI_NO"));
					List<?> listHesapNo = LOVExecuter.execute("3132/LOV_FIRMA_HESAP_NO", "%", hesapNoInputList);
					if (listHesapNo.size() != 0) {
						oMap.put("FIRMA_HESAP_NO", ((HashMap<?, ?>) listHesapNo.get(0)).get("HESAP_NO"));
					}
				}
			}
			if (oMap.getString("FIRMA_MUSTERI_NO") == null && !iMap.getString("KAMPANYA_KOD").contains("-")) {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call pkg_kampanya.Firma_Hesap_No(?)}");
				int pc = 1;
				stmt.registerOutParameter(pc++, Types.DECIMAL);
				stmt.setBigDecimal(pc++, iMap.getBigDecimal("KAMPANYA_KOD"));

				stmt.execute();
				oMap.put("FIRMA_HESAP_NO", stmt.getBigDecimal(1));
				oMap.put("FIRMA_MUSTERI_NO", LovHelper.diLov(oMap.getBigDecimal("FIRMA_HESAP_NO"), null, "3132/LOV_FIRMA_HESAP_NO", "MUSTERI_NO"));
				oMap.put("DI_FIRMA_MUSTERI_NO", LovHelper.diLov(oMap.getBigDecimal("FIRMA_HESAP_NO"), null, "3132/LOV_FIRMA_HESAP_NO", "UNVAN"));
			}
			stmt.close();
			int i = 1;
			stmt = conn.prepareCall("{ ? = call PKG_SATICI.DistributorHesapNo(?)}");
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("DISTRIBUTOR_HESAP_NO", stmt.getBigDecimal(1));

			return oMap;
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_GET_TEMINAT_GIRILMIS_MI")
	public static GMMap getTeminatGirilmisMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3132.TeminatGirilmisMi(?)}");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("HATA_NO", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_CHECK_KATKIPAYI_DOSYAMASRAFI")
	public static GMMap checkKatkiPayiDosyaMasrafiDegisti(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3132.KatkiPayi_DosyaMasrafi_Degisti(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("CHECK_MESSAGE", stmt.getString(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_BLOKELI_HESABI_VAR_MI")
	public static GMMap blokeliHesabiVarMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3132.blokeli_hesabi_var_mi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("MESSAGE", stmt.getString(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_MUSTERI_BLOKESI_VAR_MI")
	public static GMMap musteriBlokesiVarMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3132.musteri_blokesi_var_mi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("MESSAGE", stmt.getString(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_YENIDEN_YAPILANDIRMA_VAR_MI")
	public static GMMap yenidenYapilandirmaVarMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3132.yeniden_yapilandirma_tutari(?,?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("MUSTERI_NO"));

			stmt.execute();

			GMMap oMap = new GMMap();
			oMap.put("OTOMATIK_KAPAMA_TUTARI", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_GET_KULLANDIRIM")
	public static GMMap getKullandirim(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirKullandirim birKullandirim = (BirKullandirim) session.get(BirKullandirim.class, iMap.getBigDecimal("BASVURU_NO"));

			oMap.put("BASVURU_NO", birKullandirim.getBasvuruNo());
			oMap.put("MUSTERI_NO", birKullandirim.getMusteriNo());
			oMap.put("DI_MUSTERI_NO", LovHelper.diLov(birKullandirim.getMusteriNo(), "3132/LOV_BASVURU", "ADI_SOYADI"));

			oMap.put("VALOR", birKullandirim.getValor());
			oMap.put("SUBE_KOD", birKullandirim.getSubeKod());
			oMap.put("ISLEM_TARIHI", birKullandirim.getIslemTar());
			oMap.put("FIRMA_MUSTERI_NO", birKullandirim.getFirmaMusteriNo());
			oMap.put("DI_FIRMA_MUSTERI_NO", LovHelper.diLov(birKullandirim.getFirmaMusteriNo(), DALUtil.getResult("select b.satici_kod FROM BIR_BASVURU B WHERE b.basvuru_no='" + birKullandirim.getBasvuruNo() + "'"), "3132/LOV_FIRMA_MUSTERI_NO", "UNVAN"));
			oMap.put("FIRMA_HESAP_NO", birKullandirim.getFirmaHesapNo());
			oMap.put("BAYI_HESAP_NO", birKullandirim.getBayiHesapNo());
			// oMap.put("DIST_HESAP_NO", birKullandirim.getDistHesapNo());
			oMap.put("BAYI_MUSTERI_NO", birKullandirim.getBayiMusteriNo());
			oMap.put("DI_BAYI_MUSTERI_NO", LovHelper.diLov(birKullandirim.getBayiMusteriNo(), DALUtil.getResult("select b.satici_kod FROM BIR_BASVURU B WHERE b.basvuru_no='" + birKullandirim.getBasvuruNo() + "'"), "3132/LOV_BAYI_MUSTERI_NO", "UNVAN"));
			oMap.put("KRD_HESAP_NO", birKullandirim.getKrdHesapNo());
			oMap.put("ALAC_HESAP_NO", birKullandirim.getAlacHesapNo());
			oMap.put("OTO_VIRMAN", birKullandirim.getOtoVirman());
			oMap.put("OTO_VIRMAN_HESAP", birKullandirim.getOtoVirmanHesap());
			oMap.put("ACIKLAMA", birKullandirim.getAciklama());
			oMap.put("KRD_TUTAR_TL", birKullandirim.getKrdTutarTl());
			oMap.put("KUR", birKullandirim.getKur());
			oMap.put("KRD_DOVIZ_KOD", birKullandirim.getKrdDovizKod());
			oMap.put("KRD_TUTAR", birKullandirim.getKrdTutar());
			oMap.put("BAYI_KOM", birKullandirim.getBayiKom());
			oMap.put("MUS_KOM", birKullandirim.getMusKom());
			oMap.put("DOSYA_MASRAF", birKullandirim.getDosyaMasraf());
			oMap.put("TEM_SIG_PRIM", birKullandirim.getTemSigPrim());
			oMap.put("FARK_FAIZ", birKullandirim.getFarkFaiz());
			oMap.put("KREDI_SIG_PRIM", birKullandirim.getKrediSigPrim());
			oMap.put("AVUKAT_UCRET", birKullandirim.getAvukatUcret());
			oMap.put("EXPERTIZ_UCRET", birKullandirim.getExpertizUcret());
			oMap.put("KKDF", birKullandirim.getKkdfOran());
			oMap.put("BSMV", birKullandirim.getBsmvOran());
			oMap.put("FAIZ_ORANI", birKullandirim.getFaizOrani());
			oMap.put("SIGORTA_HESABI", birKullandirim.getSigortaHesabi());
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3132_GET_SIGORTA_BILGILERI", iMap));
			oMap.put("SIGORTA_KOMISYON", birKullandirim.getSigortaKomisyon());
			oMap.put("KREDI_SIGORTA_PRIMI", birKullandirim.getKrediSigPrim());
			oMap.put("SIGORTA_HESABI_2", birKullandirim.getSigortaHesabi2());
			oMap.put("SIGORTA_KOMISYON_2", birKullandirim.getSigortaKomisyon2());
			oMap.put("KREDI_SIGORTA_PRIMI_2", birKullandirim.getKrediSigPrim2());
			oMap.put("SIGORTA_HESABI_3", birKullandirim.getSigortaHesabi3());
			oMap.put("SIGORTA_KOMISYON_3", birKullandirim.getSigortaKomisyon3());
			oMap.put("KREDI_SIGORTA_PRIMI_3", birKullandirim.getKrediSigPrim3());
			oMap.put("KRD_TUR", birKullandirim.getKrdTur());
			oMap.put("DI_KRD_TUR", LovHelper.diLov(birKullandirim.getKrdTur(), "3131/LOV_KREDI_TUR", "ACIKLAMA"));
			oMap.put("VADE", birKullandirim.getVade());
			oMap.put("ALAC_DOVIZ_KODU", birKullandirim.getAlacDovizKod());
			oMap.put("KRD_TIP_KOD", birKullandirim.getKrdAltTur());
			oMap.put("DI_KRD_TIP", LovHelper.diLov(birKullandirim.getKrdAltTur(), birKullandirim.getKrdTur(), "3109/LOV_KREDI_TIPI", "ACIKLAMA"));
			oMap.put("ALT_KRD_TIP", birKullandirim.getKrdAltTur2());
			oMap.put("DI_ALT_KRD_TIP", LovHelper.diLov(birKullandirim.getKrdAltTur2(), birKullandirim.getKrdTur(), birKullandirim.getKrdAltTur(), "3109/LOV_ALT_KREDI_TIP", "ACIKLAMA"));
			oMap.put("TRX_NO", DALUtil.getResult("select max(k.tx_no) from bir_kullandirim_tx k where k.basvuru_no = " + iMap.getBigDecimal("BASVURU_NO") + ""));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3132_GET_SIGORTA_BILGILERI")
	public static GMMap getSigortaBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			oMap.put("PANEL_GOSTER1", false);
			oMap.put("PANEL_GOSTER2", false);
			oMap.put("PANEL_GOSTER3", false);

			// Sigorta Bilgileri
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_trn3132.get_basvuru_sigorta(?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(2, -10);

			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(2);
			int index = 1;
			while (rSet.next()) {
				oMap.put("TEMINAT_TUR" + index, rSet.getString("TEMINAT_TUR"));
				oMap.put("TEMINAT_KOD" + index, rSet.getString("TEMINAT_KOD"));
				oMap.put("SIGORTA_SIRKETI" + index, rSet.getString("SIGORTA_SIRKETI"));
				oMap.put("KREDI_SIGORTA_PRIMI" + index, rSet.getBigDecimal("KOMISYON_ORAN"));
				oMap.put("KOMISYON" + index, rSet.getBigDecimal("KOMISYON"));
				oMap.put("MUSTERI_NO" + index, rSet.getBigDecimal("MUSTERI_NO"));
				oMap.put("SIGORTA_HESABI" + index, rSet.getBigDecimal("HESAP_NO"));
				oMap.put("DI_SIGORTA_HESABI" + index, rSet.getString("KISA_ISIM"));
				oMap.put("PANEL_GOSTER" + index, true);
				oMap.put("URUN_NO" + index, rSet.getString("URUN_NO"));
				index++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_GET_SIGORTA_URUN_BILGILERI")
	public static GMMap getSigortaUrunBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			// oMap.put("PANEL_GOSTER1", false);

			// Sigorta Bilgileri
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_trn3132.get_basvuru_sigorta_urun(?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("URUN_NO"));
			stmt.setString(3, iMap.getString("TEMINAT_KOD"));
			stmt.registerOutParameter(4, -10);

			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(4);

			while (rSet.next()) {
				oMap.put("TEMINAT_TUR", rSet.getString("TEMINAT_TUR"));
				oMap.put("TEMINAT_KOD", rSet.getString("TEMINAT_KOD"));
				oMap.put("SIGORTA_SIRKETI", rSet.getString("SIGORTA_SIRKETI"));
				oMap.put("KREDI_SIGORTA_PRIMI", rSet.getBigDecimal("KOMISYON_ORAN"));
				oMap.put("KOMISYON", rSet.getBigDecimal("KOMISYON"));
				oMap.put("MUSTERI_NO", rSet.getBigDecimal("MUSTERI_NO"));
				oMap.put("SIGORTA_HESABI", rSet.getBigDecimal("HESAP_NO"));
				oMap.put("DI_SIGORTA_HESABI", rSet.getString("KISA_ISIM"));
				// oMap.put("PANEL_GOSTER" , true);
				;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_BAYI_KONTROL")
	public static GMMap bayiKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3132.BayiKontrol(?)}");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KODU"));

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("HATA_NO", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_CALISAN_KONTROL")
	public static GMMap calisanKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3132.BayiCalisanKontrol(?,?)}");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KODU"));
			stmt.setString(3, iMap.getString("CALISAN_KODU"));

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("HATA_NO", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_SATICI_STATU_KOD_UYGUNMU")
	public static GMMap SATICI_STATU_KOD_UYGUNMU(GMMap iMap) {
		// Connection conn = null;
		// CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			oMap.put("KONTROL", "1");

			if (iMap.getString("SATICI_STATU_KOD").compareTo("KK".toString()) == 0) {
				iMap.put("HATA_NO", new BigDecimal(1438));
				iMap.put("P1", "SATICI_STATU_KOD");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			// GMServerDatasource.close(stmt);
			// GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_SATICI_STATU_KOD_UYGUNMU_IS")
	public static GMMap SATICI_STATU_KOD_UYGUNMU_IS(GMMap iMap) {
		// Connection conn = null;
		// CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			oMap.put("KONTROL", "1");
			oMap.put("MESSAGE", "H");

			if (iMap.getString("SATICI_STATU_KOD").compareTo("KK".toString()) == 0) {
				iMap.put("MESSAGE_NO", new BigDecimal(1438));
				iMap.put("P1", "SATICI_STATU_KOD");
				oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			// GMServerDatasource.close(stmt);
			// GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_GET_ISLEM_ADI")
	public static GMMap getAciklama(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("ISLEM_ADI", (String) DALUtil.callOneParameterFunction("{? = call pkg_genel_pr.islem_adi(?)}", Types.VARCHAR, iMap.getString("ISLEM_NO")));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3132_AFTER_APPROVAL")
	public static GMMap mailGonder(GMMap iMap) {
		GMMap servisMap = new GMMap();
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		BigDecimal basvuruNo = BigDecimal.ZERO;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3132.get_mail_bilgileri(?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_NO"));
			stmt.registerOutParameter(2, -10);
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(2);
			while (rSet.next()) {
				if (rSet.getBigDecimal("KANAL_KODU") != null) {
					if ((rSet.getBigDecimal("KANAL_KODU").compareTo(new BigDecimal(1)) == 0 || rSet.getBigDecimal("KANAL_KODU").compareTo(new BigDecimal(2)) == 0 || rSet.getBigDecimal("KANAL_KODU").compareTo(new BigDecimal(5)) == 0) && ("CEPTE".compareTo(rSet.getString("ISLEM_SONRASI_DURUM_KODU")) == 0 || "EVRAKSIZ".compareTo(rSet.getString("ISLEM_SONRASI_DURUM_KODU")) == 0)) {
						servisMap.put("MAIL_FROM", "bnspr@aktifbank.com.tr");
						servisMap.put("MAIL_TO", rSet.getString("MAIL_TO"));
						servisMap.put("MAIL_CC", rSet.getString("MAIL_CC"));
						servisMap.put("MAIL_SUBJECT", "Hayat Sigortas� Poli�esinin D�zenlenmesi");
						servisMap.put("MAIL_BODY", "<html><head><title></title> </head> <body>" + "Ekteki formda talep edilen hayat sigortas� poli�esinin d�zenlenmesini rica ederiz." + "<br /><br /><br />" + "<b>M��teri Ad�:</b> " + rSet.getString("MUSTERI_ADI") + "<br />" + "<b>TC Kimlik Numaras�:</b> " + rSet.getString("TC_KIMLIK_NO") + "<br />" + "<b>Do�um Tarihi:</b> " + rSet.getString("DOGUM_TAR") + "<br />" + "<b>Cinsiyet:</b> " + rSet.getString("CINSIYET") + "<br />" + "<b>Kredi Ba�vuru No:</b> " + rSet.getBigDecimal("BASVURU_NO") + "<br />" + "<b>Kredi Tutar�:</b> " + rSet.getBigDecimal("KRD_TUTAR") + "<br />" + "<b>Kredi ve/ veya Sigorta poli�e s�resi:</b> " + rSet.getBigDecimal("VADE") + "<br />" + "</body></html> "); // mail_body
																																																																																																																																																																																									// bos
																																																																																																																																																																																									// gonderilemez.
						servisMap.put("IS_BODY_HTML", "E");
						servisMap.put("FILE_NAME", rSet.getString("BELGE_ADI"));
						// if(rSet.getString("BELGE_ADI")!=null){
						// GMMap servisMap2=new GMMap();
						// servisMap2.put("FILE_PATH", rSet.getString("BELGE_YERI"));
						// servisMap2.put("ORIGINAL_FILE_NAME", rSet.getString("BELGE_ADI"));
						// servisMap2.put("CUSTOMER_NO", rSet.getString("MUSTERI_NO"));
						// servisMap2.put("DOCUMENT_CODE", rSet.getString("DOKUMAN_KOD"));
						// servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", rSet.getString("BELGE_ADI"));
						// servisMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT",
						// GMServiceExecuter.execute("BNSPR_TRN1090_GET_FILE_FROM_REPOSITORY", servisMap2).get("FILE_CONTENT"));
						// }
						GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
					}
				}
			}
			Session session = DAOSession.getSession("BNSPRDal");
			BirKullandirimTx birKullandirimTx = (BirKullandirimTx) session.get(BirKullandirimTx.class, iMap.getBigDecimal("ISLEM_NO"));
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, birKullandirimTx.getBasvuruNo());
			session.refresh(birBasvuru);
			
			stmt = conn.prepareCall("{call PKG_TRN3132.sigorta_satis_talep(?)}");
			stmt.setBigDecimal(1, birKullandirimTx.getBasvuruNo());
			stmt.execute();
			
			/** web kanaliysa event tetikle **/
			if("8".equals(birKullandirimTx.getKanalKodu())||"5".equals(birKullandirimTx.getKanalKodu())){
				iMap.put("EVENT_TYPE_NO", "64");
				iMap.put("EVENT_REF_NO", birKullandirimTx.getBasvuruNo());
				GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
				
				/** netmera **/
				
				GMMap nMap = new GMMap();
				nMap.put("EVENT_TYPE", EventTypeEnum.KullandirimEvent.toString());
				nMap.put("TC_KIMLIK_NO", birBasvuru.getTcKimlikNo());
				nMap.put("KREDI_TUR", birKullandirimTx.getKrdTur());
				nMap.put("TUTAR", birKullandirimTx.getKrdTutar());
				List<?> birAdkBasvuru = session.createCriteria(BirAdkBasvuru.class).add(Restrictions.eq("kulBasvuruNo", birBasvuru.getBasvuruNo())).list();
				if(birAdkBasvuru.size() > 0){
					nMap.put("ON_ONAY_FLAG", "E");
				}else{
					nMap.put("ON_ONAY_FLAG", "H");
				}
				List<?> segmentList = session.createCriteria(BirNbsmMusteriSegment.class).add(Restrictions.eq("id.basvuruNo", birBasvuru.getBasvuruNo())).add(Restrictions.eq("id.sorguSeviyesi", "F")).list();
				if(segmentList.size() > 0){
					BirNbsmMusteriSegment segment = (BirNbsmMusteriSegment)segmentList.get(0);
					nMap.put("SEGMENT", segment.getSegment());
				}else{
					nMap.put("SEGMENT", "");
				}
				if(birKullandirimTx.getKrediSigPrim() != null && birKullandirimTx.getKrediSigPrim().compareTo(BigDecimal.ZERO) > 0){
					nMap.put("SIGORTA_FLAG", "E");
				}else{
					nMap.put("SIGORTA_FLAG", "H");
				}
				nMap.put("SPOT_KREDI_FLAG", "H");
				GMServiceExecuter.executeAsync("BNSPR_CL_SEND_EVENT_TO_NETMERA", nMap);
			
				/** retention kapama **/ 
				List<BirBasvuruKonsolidasyon> konsolidasyonList = session.createCriteria(BirBasvuruKonsolidasyon.class).add(Restrictions.eq("id.basvuruNo", birBasvuru.getBasvuruNo())).list();
				for (BirBasvuruKonsolidasyon kons : konsolidasyonList) {
					DALUtil.callOracleProcedure("{call pkg_ptt_basvuru.konsolidasyon_kredi_kapama(?)}", new Object[]{
							BnsprType.NUMBER, kons.getId().getYapilandirilanBasvuruNo()
						}, new Object[]{});
				}
				
				/** PBIBK-540 sifremi olustur menusu bilgilendirme sms **/
				GMMap tMap = new GMMap();
				tMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
				tMap.put("INTERNET", false);
				tMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
				tMap.put("CAGRI_MERKEZI", false);
				tMap.put("INTERNET_NG", true);
				tMap.put("PASSOLIG_NG",  false);										
				GMServiceExecuter.executeAsync("BNSPR_TRN4170_SAVE", tMap);
			}
			
			/** P2D d�n���m� **/
			if("2".equals(birKullandirimTx.getKanalKodu()) && "E".equals(birBasvuru.getDebitKartTalep())){
				BirBasvuruKartBilgi kartBilgi = (BirBasvuruKartBilgi) session.get(BirBasvuruKartBilgi.class, birKullandirimTx.getBasvuruNo());
				if(kartBilgi != null){
					if("P".equals(kartBilgi.getKartTipi()) && kartBilgi.getKkBasvuruNo() != null){
						GMMap cMap = new GMMap();
						cMap.put("PROCESS_TYPE", "P");
						cMap.put("CL_APPLICATION_NO", birKullandirimTx.getBasvuruNo());
						cMap.put("TFF_APPLICATION_NO", kartBilgi.getTffBasvuruNo());
						cMap.put("KK_APPLICATION_NO", kartBilgi.getKkBasvuruNo());
						cMap.put("CARD_NO", kartBilgi.getKartNo());
						cMap.put("DURUM_KOD", BigDecimal.ZERO);
						cMap.put("ONAY_FLAG", "TRUE");
						cMap.put("KANAL", "BAYI");
						GMServiceExecuter.executeAsync("BNSPR_CL_CREATE_DEBIT_CARD_REQUEST", cMap);
					}
				}
			}
			
			/** PTT sms kurye konsolidasyon **/
			if("7".equals(birKullandirimTx.getKanalKodu()) && "K".equals(birBasvuru.getKuryeSecimi())) {
				BirKampanya birKampanya = (BirKampanya) session.get(BirKampanya.class, birBasvuru.getKampKod());
				
				if("E".equals(birKampanya.getBirlestirmeEh())) {
					List<BirBasvuruKonsolidasyon> konsolidasyonList = session.createCriteria(BirBasvuruKonsolidasyon.class).add(Restrictions.eq("id.basvuruNo", birBasvuru.getBasvuruNo())).add(Restrictions.eq("kapamaEh", "E")).list();
					for (BirBasvuruKonsolidasyon kons : konsolidasyonList) {
						DALUtil.callOracleProcedure("{call pkg_ptt_basvuru.konsolidasyon_kredi_kapama(?)}", new Object[]{
								BnsprType.NUMBER, kons.getId().getYapilandirilanBasvuruNo()
							}, new Object[]{});
					}
				}
			}
			
			/** dokuman ftp transfer **/
			if ("CEPTE".equals(birBasvuru.getDurumKodu()) && "2".equals(birBasvuru.getKanalKodu())) {
				GMMap sorguMap = new GMMap();
				sorguMap.put("BASVURU_NO", birBasvuru.getBasvuruNo());
				GMServiceExecuter.execute("BNSPR_TRN3182_GECICI_DOKUMAN_TRANSFER_ET", sorguMap);
			}
			/** ftp transfer sonu **/
			
			/** Bayiye Odemeyse YIM servisini cagir **/
			if (birKullandirimTx != null ) {
				if(birBasvuru != null){
					if (BigDecimal.ONE.equals(birBasvuru.getKrediOdemeTipi())) {
						basvuruNo = birBasvuru.getBasvuruNo();
						GMMap yimMap = new GMMap();
						yimMap.put("BASVURU_NO", basvuruNo);
						GMServiceExecuter.execute("BNSPR_TRN3294_SAVE", yimMap);
						oMap.put("YIM_TRANSFER", true);
					}
					else {
						oMap.put("YIM_TRANSFER", false);
					}
				}
			}
			
			/* KAPS Bildirim */
			GMMap paramMap = new GMMap();
			paramMap.put("KOD", "KAPS_SORGU");
			paramMap.put("KEY", "BILDIRIM_KONTROL");
			String sorguKontrol = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap).getString("TEXT");
			
			if("1".equals(sorguKontrol)){
				try {
					GMMap kapsMap = new GMMap();
					kapsMap.put("TCKN", birBasvuru.getTcKimlikNo());
					kapsMap.put("URUN_KODU", "02");// GNL_PARAM_TEXT WHERE KOD = 'KAPS_SORGU'
					kapsMap.put("DOVIZ_KODU", "949");
					kapsMap.put("KREDI_TUTARI", birKullandirimTx.getKrdTutar());
					kapsMap.put("KULLANDIRIM_TARIHI", new SimpleDateFormat("dd-MM-yyyy").format(birKullandirimTx.getIslemTar()));
					kapsMap.put("KULLANDIRIM_ZAMANI", new SimpleDateFormat("HH:mm:ss").format(birKullandirimTx.getIslemTar()));
					kapsMap.put("KULLANICI", ADCSession.get("USER_NAME"));
					kapsMap.put("TAKSIT_SAYISI", birKullandirimTx.getVade());
					
					BirBasvuruKimlik kimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", birKullandirimTx.getBasvuruNo())).uniqueResult();
					
					kapsMap.put("GELIR_BILGISI", kimlik.getAylikGelir());
					kapsMap.put("KANAL_KOD", birKullandirimTx.getKanalKodu());
					GMServiceExecuter.executeAsync("BNSPR_KAPS_BILDIRIM", kapsMap);
				}
				catch (Exception e) {
					LOGGER.error(e.getMessage());
				}
			}
			
			
			
			return new GMMap();
		}
		catch (Exception e) {
			/** YIM Bildirimi yap�ld�ysa, tekrar gonderebilmek icin durumunu guncelleiyoruz **/
			if(oMap.getBoolean("YIM_TRANSFER")){
				GMMap yimMap = new GMMap();
				yimMap.put("KRD_BASVURU_NO", basvuruNo);
				yimMap.put("DURUM_KODU", "0");
				yimMap.put("ACIKLAMA_ID", "");
				yimMap.put("ACIKLAMA", "");
				GMServiceExecuter.execute("BNSPR_YIM_DURUM_GUNCELLE", yimMap);
			}
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_GET_TEMINAT_BILGI")
	public static GMMap teminatBilgi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3132.get_teminat_bilgi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("TEMINAT_BILGI", stmt.getString(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_GET_SONRADAN_EKLENEN_TEMINAT")
	public static GMMap sonradanEklenenTem(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3132.get_sonradan_eklenen_teminat(?,?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("URUN_NO"));

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("HATA_NO", stmt.getString(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3132_SIGORTA_POLICE_OLUSTUR")
	public static GMMap issueCreditLife(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap sMap = new GMMap();

			String proc = "{ call PKG_SIGORTA_DE.ebs_sorgu_bilgi_getir(?,?,?) }";
			Object[] inputValues = new Object[2];
			int n = 0;
			inputValues[n++] = BnsprType.NUMBER;
			inputValues[n++] = iMap.getBigDecimal("BASVURU_NO");

			Object[] outputValues = new Object[4];
			n = 0;
			outputValues[n++] = BnsprType.REFCURSOR;
			outputValues[n++] = "CAPITAL_REPAYMENT_INFO";
			outputValues[n++] = BnsprType.REFCURSOR;
			outputValues[n++] = "CREDIT_INFO";

			GMMap resultMap = (GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues);

			sMap.put("PARAM_REF_TUR", "BIR_BASVURU");
			sMap.put("PARAM_REF_ID", iMap.getBigDecimal("BASVURU_NO"));

			for (int i = 0; i < resultMap.getSize("CAPITAL_REPAYMENT_INFO"); i++) {
				// CAPITAL_REPAYMENT
				sMap.put("CAPITAL_REPAYMENT", i, "ORDER", resultMap.getString("CAPITAL_REPAYMENT_INFO", i, "ORDER"));
				sMap.put("CAPITAL_REPAYMENT", i, "DUE", resultMap.getString("CAPITAL_REPAYMENT_INFO", i, "DUE"));
				sMap.put("CAPITAL_REPAYMENT", i, "AMOUNT", resultMap.getString("CAPITAL_REPAYMENT_INFO", i, "AMOUNT"));
			}

			for (int i = 0; i < resultMap.getSize("CREDIT_INFO"); i++) {
				// CREDIT
				sMap.put("CREDIT", i, "PAYMENT_TERM", resultMap.getString("CREDIT_INFO", i, "PAYMENT_TERM"));
				sMap.put("CREDIT", i, "PAYMENT_PERIOD", resultMap.getString("CREDIT_INFO", i, "PAYMENT_PERIOD"));
				sMap.put("CREDIT", i, "PREMIUM_PAYMENT_TERM", resultMap.getString("CREDIT_INFO", i, "PREMIUM_PAYMENT_TERM"));
				sMap.put("CREDIT", i, "COVERAGE_PERIOD", resultMap.getString("CREDIT_INFO", i, "COVERAGE_PERIOD"));
				sMap.put("CREDIT", i, "CREDIT_AMOUNT", resultMap.getString("CREDIT_INFO", i, "CREDIT_AMOUNT"));
				sMap.put("CREDIT", i, "INITIAL_COVERAGE_AMOUNT", resultMap.getString("CREDIT_INFO", i, "INITIAL_COVERAGE_AMOUNT"));
				sMap.put("CREDIT", i, "INTEREST_PERIOD", resultMap.getString("CREDIT_INFO", i, "INTEREST_PERIOD"));
				sMap.put("CREDIT", i, "INTEREST_RATE", resultMap.getString("CREDIT_INFO", i, "INTEREST_RATE"));
				// POLICY_INSURED
				sMap.put("POLICY_INSURED", i, "TCKNO", resultMap.getString("CREDIT_INFO", i, "TCKNO"));
				sMap.put("POLICY_INSURED", i, "VKNO", resultMap.getString("CREDIT_INFO", i, "VKNO"));
				sMap.put("POLICY_INSURED", i, "YKN", resultMap.getString("CREDIT_INFO", i, "YKN"));
				sMap.put("POLICY_INSURED", i, "NAME", resultMap.getString("CREDIT_INFO", i, "NAME"));
				sMap.put("POLICY_INSURED", i, "MIDDLE_NAME", resultMap.getString("CREDIT_INFO", i, "MIDDLE_NAME"));
				sMap.put("POLICY_INSURED", i, "SURNAME", resultMap.getString("CREDIT_INFO", i, "SURNAME"));
				sMap.put("POLICY_INSURED", i, "FATHER_NAME", resultMap.getString("CREDIT_INFO", i, "FATHER_NAME"));
				sMap.put("POLICY_INSURED", i, "BIRTHDAY", resultMap.getString("CREDIT_INFO", i, "BIRTHDAY"));
				sMap.put("POLICY_INSURED", i, "GENDER", resultMap.getString("CREDIT_INFO", i, "GENDER"));
				sMap.put("POLICY_INSURED", i, "GSM_AREA_CODE", resultMap.getString("CREDIT_INFO", i, "GSM_AREA_CODE"));
				sMap.put("POLICY_INSURED", i, "GSM_NO", resultMap.getString("CREDIT_INFO", i, "GSM_NO"));
				sMap.put("POLICY_INSURED", i, "TEL_AREA_CODE", resultMap.getString("CREDIT_INFO", i, "TEL_AREA_CODE"));
				sMap.put("POLICY_INSURED", i, "TEL_NO", resultMap.getString("CREDIT_INFO", i, "TEL_NO"));
				sMap.put("POLICY_INSURED", i, "FAX_AREA_CODE", resultMap.getString("CREDIT_INFO", i, "FAX_AREA_CODE"));
				sMap.put("POLICY_INSURED", i, "FAX_NO", resultMap.getString("CREDIT_INFO", i, "FAX_NO"));
				sMap.put("POLICY_INSURED", i, "PASSPORT_NO", resultMap.getString("CREDIT_INFO", i, "PASSPORT_NO"));
				sMap.put("POLICY_INSURED", i, "WORK_POSITION", resultMap.getString("CREDIT_INFO", i, "WORK_POSITION"));
				sMap.put("POLICY_INSURED", i, "EDUCATIONAL_STATE", resultMap.getString("CREDIT_INFO", i, "EDUCATIONAL_STATE"));
				sMap.put("POLICY_INSURED", i, "EMAIL", resultMap.getString("CREDIT_INFO", i, "EMAIL"));
				// POLICY_INSURED_ADDRESS
				sMap.put("POLICY_INSURED_ADDRESS", i, "ADDRESS", resultMap.getString("CREDIT_INFO", i, "ADDRESS"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "UAVT_ADDRESS_NO", resultMap.getString("CREDIT_INFO", i, "UAVT_ADDRESS_NO"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "BLOCK", resultMap.getString("CREDIT_INFO", i, "BLOCK"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "APARTMANT", resultMap.getString("CREDIT_INFO", i, "APARTMANT"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "BUILDING", resultMap.getString("CREDIT_INFO", i, "BUILDING"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "ROAD", resultMap.getString("CREDIT_INFO", i, "ROAD"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "FLAT", resultMap.getString("CREDIT_INFO", i, "FLAT"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "CITY_CODE", resultMap.getString("CREDIT_INFO", i, "CITY_CODE"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "COUNTRY", resultMap.getString("CREDIT_INFO", i, "COUNTRY"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "COUNTRY_NAME", resultMap.getString("CREDIT_INFO", i, "COUNTRY_NAME"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "TOWN_CODE", resultMap.getString("CREDIT_INFO", i, "TOWN_CODE"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "FLOOR", resultMap.getString("CREDIT_INFO", i, "FLOOR"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "VILLAGE_CODE", resultMap.getString("CREDIT_INFO", i, "VILLAGE_CODE"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "DISTRICT", resultMap.getString("CREDIT_INFO", i, "DISTRICT"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "SITE_NAME", resultMap.getString("CREDIT_INFO", i, "SITE_NAME"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "STREET", resultMap.getString("CREDIT_INFO", i, "STREET"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "POSTAL_CODE", resultMap.getString("CREDIT_INFO", i, "POSTAL_CODE"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "BLOCK2", resultMap.getString("CREDIT_INFO", i, "BLOCK2"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "PLOT", resultMap.getString("CREDIT_INFO", i, "PLOT"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "LOT", resultMap.getString("CREDIT_INFO", i, "LOT"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "PAGE", resultMap.getString("CREDIT_INFO", i, "PAGE"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "CITY_NAME", resultMap.getString("CREDIT_INFO", i, "CITY_NAME"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "TOWN_NAME", resultMap.getString("CREDIT_INFO", i, "TOWN_NAME"));
				sMap.put("POLICY_INSURED_ADDRESS", i, "VILLAGE_NAME", resultMap.getString("CREDIT_INFO", i, "VILLAGE_NAME"));
				// OTHERS
				sMap.put("GUID", resultMap.getString("CREDIT_INFO", i, "GUID"));
				sMap.put("APPLICATION_CODE", resultMap.getString("CREDIT_INFO", i, "APPLICATION_CODE"));
				sMap.put("PRODUCT_CODE", resultMap.getString("CREDIT_INFO", i, "PRODUCT_CODE"));
				sMap.put("START_DATE", resultMap.getString("CREDIT_INFO", i, "START_DATE"));				
				sMap.put("END_DATE", resultMap.getString("CREDIT_INFO", i, "END_DATE"));
				sMap.put("ISSUE_DATE", resultMap.getString("CREDIT_INFO", i, "ISSUE_DATE"));				
				sMap.put("BANK_ID", resultMap.getString("CREDIT_INFO", i, "BANK_ID"));
				sMap.put("BRANCH_ID", resultMap.getString("CREDIT_INFO", i, "BRANCH_ID"));
				sMap.put("SALESMAN_ID", resultMap.getString("CREDIT_INFO", i, "SALESMAN_ID"));
				sMap.put("BANK_CREDIT_APPLICATION", resultMap.getString("CREDIT_INFO", i, "BANK_CREDIT_APPLICATION"));
				sMap.put("BANK_CUSTOMER_ID", resultMap.getString("CREDIT_INFO", i, "BANK_CUSTOMER_ID"));
				sMap.put("PROPOSAL_GROSS_PREMIUM", resultMap.getString("CREDIT_INFO", i, "PROPOSAL_GROSS_PREMIUM"));
			}
			oMap.putAll(GMServiceExecuter.execute("BNSPR_EXT_ISSUE_CREDIT_LIFE", sMap));
			
			if (!StringUtils.isEmpty(oMap.getString("INSURANCE_COMPANY_POLICY_NO")))
			{
				String proc2 = "{ call PKG_SIGORTA_DE.ebs_police_guncelle(?,?,?,?,?) }";
				Object[] inputValues2 = new Object[10];
				int n2 = 0;
				inputValues2[n2++] = BnsprType.NUMBER;
				inputValues2[n2++] = iMap.getBigDecimal("BASVURU_NO");
				inputValues2[n2++] = BnsprType.STRING;
				inputValues2[n2++] = oMap.getString("INSURANCE_COMPANY_POLICY_NO");
				inputValues2[n2++] = BnsprType.DATE;
				inputValues2[n2++] = oMap.getDate("POLICY_START_DATE");
				inputValues2[n2++] = BnsprType.DATE;
				inputValues2[n2++] = oMap.getDate("POLICY_END_DATE");
				inputValues2[n2++] = BnsprType.DATE;
				inputValues2[n2++] = oMap.getDate("ISSUE_DATE");

				Object[] outputValues2 = new Object[0];
				DALUtil.callOracleProcedure(proc2, inputValues2, outputValues2);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3132_TOPLU_SIGORTA_POLICE_OLUSTUR")
	public static GMMap issueCreditLifeBulk(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String proc = "{ call PKG_SIGORTA_DE.ebs_police_mesaj_olustur }";
			Object[] inputValues = new Object[0];
			Object[] outputValues = new Object[0];
			DALUtil.callOracleProcedure(proc, inputValues, outputValues);
			
			String func = "{ ? = call PKG_SIGORTA_DE.ebs_sorgu_liste }";
			GMMap resultMap = (GMMap) DALUtil.callOracleRefCursorFunction(func, "BASVURU_LISTE", inputValues);

			for (int i = 0; i < resultMap.getSize("BASVURU_LISTE"); i++) {
				GMMap sMap = new GMMap();
				sMap.put("BASVURU_NO", resultMap.getString("BASVURU_LISTE", i, "BASVURU_NO"));
				GMServiceExecuter.executeNT("BNSPR_TRN3132_SIGORTA_POLICE_OLUSTUR", sMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
