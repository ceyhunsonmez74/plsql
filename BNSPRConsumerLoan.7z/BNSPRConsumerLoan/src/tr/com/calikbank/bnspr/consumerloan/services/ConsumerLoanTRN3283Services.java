package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BirBasvuruDavaMasrafTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

/** Dava masraf bilgilerinin tutulmasini gerceklestirir.
 * @author murat.el
 * @since TYBK-791
 */
public class ConsumerLoanTRN3283Services {
	
	private static final String ISLEM_KODU = "3283";
	
	/** Ekran acilisinda kullanilacak degerleri bulur<br>
	 * @author murat.el
	 * @since TY-3761
	 * @param iMap - Input yok<br>
	 * @return Ekran acilisinda kullanilacak degerler<br>
	 *         <li>KANAL_LIST - Bireysel basvuru alinabilen kanal listesi
	 */
	@GraymoundService("BNSPR_TRN3283_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3178_GET_KANAL_LIST", iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Alinan bilgilerle islemi kaydet ve sonlandir<br>
	 * @author murat.el
	 * @since TY-3761
	 * @param iMap - Islem bilgileri<br>
	 *        <li>TRX_NO - Islem numarasi
	 *        <li>MUSTERI_NO - Musteri numarasi
	 *        <li>BASVURU_NO - Bireysel kredi basvuru numarasi
	 *        <li>KANAL_KODU - Basvurunun yapildigi kanal kodu
	 *        <li>KULLANDIRIM_TARIHI - Basvurunun kullandirim tarihi
	 *        <li>KRD_HESAP_NO - Kredinin kullandirildigi hesap no
	 *        <li>ICRA_TUTARI - Mahkeme icra masrafi
	 *        <li>YARGILAMA_GIDERI - Mahkeme yargilama gideri
	 *        <li>MAHKEME_HARCI - Mahkeme harci
	 *        <li>ACIKLAMA - Islem aciklamasi
	 * @return Islem sonucu<br>
	 *        <li>MESSAGE - Islem sonuc mesaji
	 */
	@GraymoundService("BNSPR_TRN3283_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		//Variables
		BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

		try {
			//Session ac
			Session session = DAOSession.getSession("BNSPRDal");
			//Varsa islem numarasina ait bilgiyi al, yoksa olustur
			BirBasvuruDavaMasrafTx birBasvuruDavaMasrafTx = (BirBasvuruDavaMasrafTx) session.get(BirBasvuruDavaMasrafTx.class, trxNo);
			if (birBasvuruDavaMasrafTx == null) {
				birBasvuruDavaMasrafTx = new BirBasvuruDavaMasrafTx();
				birBasvuruDavaMasrafTx.setTxNo(trxNo);
			}
			//Islem bilgilerini al.
			birBasvuruDavaMasrafTx.setAciklama(trimNewLine(iMap.getString("ACIKLAMA")));
			birBasvuruDavaMasrafTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBasvuruDavaMasrafTx.setIcraTutari(iMap.getBigDecimal("ICRA_TUTARI"));
			birBasvuruDavaMasrafTx.setKanalKod(iMap.getString("KANAL_KODU"));
			birBasvuruDavaMasrafTx.setKrdHesapNo(iMap.getBigDecimal("KRD_HESAP_NO"));
			birBasvuruDavaMasrafTx.setKullandirimTarihi(iMap.getDate("KULLANDIRIM_TARIHI"));
			birBasvuruDavaMasrafTx.setMahkemeHarci(iMap.getBigDecimal("MAHKEME_HARCI"));
			birBasvuruDavaMasrafTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			birBasvuruDavaMasrafTx.setYargilamaGideri(iMap.getBigDecimal("YARGILAMA_GIDERI"));
			//Islem bilgilerini kaydet
			session.save(birBasvuruDavaMasrafTx);
			session.flush();
			
			//Alinan islem bilgileri ile islemi sonlandir.
			GMMap islemMap = new GMMap();
			islemMap.put("TRX_NAME", ISLEM_KODU);
			islemMap.put("TRX_NO", trxNo);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", islemMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	/** Verilen islem numarasina ait yapilan islem bilgilerini getirir<br>
	 * @author murat.el
	 * @since
	 * @param iMap
	 *         <li>TRX_NO - Islem numarasi
	 * @return Isleme ait bilgiler<br>
	 *         <li>MUSTERI_NO - Musteri numarasi
	 *         <li>BASVURU_NO - Bireysel kredi basvuru numarasi
	 *         <li>KANAL_KODU - Basvurunun yapildigi kanal kodu
	 *         <li>KULLANDIRIM_TARIHI - Basvurunun kullandirim tarihi
	 *         <li>ICRA_TUTARI - Mahkeme icra masrafi
	 *         <li>YARGILAMA_GIDERI - Mahkeme yargilama gideri
	 *         <li>MAHKEME_HARCI - Mahkeme harci
	 *         <li>ACIKLAMA - Islem aciklamasi
	 */
	@GraymoundService("BNSPR_TRN3283_GET_ISLEM_INFO")
	public static GMMap getIslemInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			//Session ac
			Session session = DAOSession.getSession("BNSPRDal");
			//Varsa islem numarasina ait bilgiyi al
			if (StringUtils.isNotBlank(iMap.getString("TRX_NO"))) {
				BirBasvuruDavaMasrafTx birBasvuruDavaMasrafTx = (BirBasvuruDavaMasrafTx) 
						session.get(BirBasvuruDavaMasrafTx.class, iMap.getBigDecimal("TRX_NO"));
				if (birBasvuruDavaMasrafTx != null) {
					oMap.put("MUSTERI_NO", birBasvuruDavaMasrafTx.getMusteriNo());
					oMap.put("BASVURU_NO", birBasvuruDavaMasrafTx.getBasvuruNo());
					oMap.put("KANAL_KODU", birBasvuruDavaMasrafTx.getKanalKod());
					oMap.put("KULLANDIRIM_TARIHI", birBasvuruDavaMasrafTx.getKullandirimTarihi());
					oMap.put("ICRA_TUTARI", birBasvuruDavaMasrafTx.getIcraTutari());
					oMap.put("YARGILAMA_GIDERI", birBasvuruDavaMasrafTx.getYargilamaGideri());
					oMap.put("MAHKEME_HARCI", birBasvuruDavaMasrafTx.getMahkemeHarci());
					oMap.put("ACIKLAMA", birBasvuruDavaMasrafTx.getAciklama());
					oMap.put("KRD_HESAP_NO", birBasvuruDavaMasrafTx.getKrdHesapNo());
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
		
	/** Trims new line characters from given string<br>
	 * 
	 * @author murat.el
	 * @since TY-3761
	 * @param value - String new line characters will be removed
	 * @param replaceString - String new line characters will be replaced
	 * @return String has no new line characters
	 */
	private static String trimNewLine(String value) {
		return StringUtils.isBlank(value) == true ? value : value.replaceAll("[\\t\\n\\r]+", " ");
	}
	
}
