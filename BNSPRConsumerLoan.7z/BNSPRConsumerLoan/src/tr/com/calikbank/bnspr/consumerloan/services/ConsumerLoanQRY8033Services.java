package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKrediTaksit;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY8033Services {

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_QRY8033_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		String webRetentionSorgu = "H";
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<BirKullandirim> birKullandirimList = session.createCriteria(BirKullandirim.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).add(Restrictions.eq("drm", "G")).list();

			GMMap oMap = new GMMap();
			String tableName = "RESULT";
			BigDecimal toplamKalanBorc = BigDecimal.ZERO, toplamAnapara = BigDecimal.ZERO, toplamKapamaBakiyesi = BigDecimal.ZERO, toplamTaksit = BigDecimal.ZERO, toplamGecikmis = BigDecimal.ZERO, gecikmeTutar = BigDecimal.ZERO;
			for (int i = 0; i < birKullandirimList.size(); i++) {

				GMMap sorguMap = new GMMap();
				sorguMap.put("BASVURU_NO", birKullandirimList.get(i).getBasvuruNo());
				sorguMap.put("REZERVASYON_KURU", new BigDecimal(0));
				sorguMap.put("EKRAN_NO", "3137");
				sorguMap.put("ERKEN_KAPAMA_GEC_KISMI_DAHIL", "E");

				GMMap serviceOmap = GMServiceExecuter.call("BNSPR_GET_GERI_ODEME_ERKEN_KAPAMA", sorguMap);
				GMMap detayMap = GMServiceExecuter.call("BNSPR_GET_GERI_ODEME_ERKEN_KAPAMA_DETAY", sorguMap);
				detayMap.put("BASVURU_NO", birKullandirimList.get(i).getBasvuruNo());

				BigDecimal kalanToplamBorc = findKalanGeriOdemeTutari(sorguMap.getBigDecimal("BASVURU_NO"));
				BigDecimal kapamaBakiyesi = musteridenAlinacakTutar(serviceOmap, detayMap);
				BigDecimal kalanAnapara = gecikmedeKalanAnapara(birKullandirimList.get(i).getBasvuruNo());

				oMap.put(tableName, i, "BASVURU_NO", sorguMap.get("BASVURU_NO"));
				oMap.put(tableName, i, "KULLANDIRIM_TARIHI", birKullandirimList.get(i).getIslemTar());
				oMap.put(tableName, i, "KALAN_ANAPARA", kalanAnapara);
				oMap.put(tableName, i, "KAPAMA_BAKIYESI", kapamaBakiyesi);
				oMap.put(tableName, i, "SEC", true);

				oMap.put(tableName, i, "KALAN_TOPLAM_BORC", kalanToplamBorc);

				toplamKalanBorc = toplamKalanBorc.add(kalanToplamBorc != null ? kalanToplamBorc : BigDecimal.ZERO);
				toplamAnapara = toplamAnapara.add(kalanAnapara != null ? kalanAnapara : BigDecimal.ZERO);
				toplamKapamaBakiyesi = toplamKapamaBakiyesi.add(kapamaBakiyesi != null ? kapamaBakiyesi : BigDecimal.ZERO);
				
				Date enGecikmisTarih = new Date();

				BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, birKullandirimList.get(i).getBasvuruNo());
				oMap.put(tableName, i, "BASVURU_TARIHI", birBasvuru.getBasvuruTarihi());

				List<BirKrediTaksit> gecikmisTaksitList = session.createCriteria(BirKrediTaksit.class).add(Restrictions.eq("id.basvuruNo", birKullandirimList.get(i).getBasvuruNo())).add(Restrictions.eq("durumKod", "ACIK")).add(Restrictions.lt("taksitTarih", new Date())).add(Restrictions.gt("taksitTut", BigDecimal.ZERO)).list();
				gecikmisTaksitList.addAll(session.createCriteria(BirKrediTaksit.class).add(Restrictions.eq("id.basvuruNo", birKullandirimList.get(i).getBasvuruNo())).add(Restrictions.eq("durumKod", "KISMI")).add(Restrictions.lt("taksitTarih", new Date())).list());
				List<BirKrediTaksit> acikTaksitList = session.createCriteria(BirKrediTaksit.class).add(Restrictions.eq("id.basvuruNo", birKullandirimList.get(i).getBasvuruNo())).add(Restrictions.eq("durumKod", "ACIK")).add(Restrictions.ge("taksitTarih", new Date())).list();

				if (acikTaksitList != null && !acikTaksitList.isEmpty()) {
					oMap.put(tableName, i, "TAKSIT_BORCU", acikTaksitList.get(0).getTaksitTut());
					toplamTaksit = toplamTaksit.add(acikTaksitList.get(0).getTaksitTut());
				}
				else {
					oMap.put(tableName, i, "TAKSIT_BORCU", BigDecimal.ZERO);
				}

				BigDecimal taksit = BigDecimal.ZERO;
				BigDecimal gecikmeFaiz = BigDecimal.ZERO;
				for (BirKrediTaksit birKrediTaksit : gecikmisTaksitList) {
					
					if (birKrediTaksit.getTaksitTarih().before(enGecikmisTarih)) {
						enGecikmisTarih = birKrediTaksit.getTaksitTarih();
					}
					
					if ("ACIK".equalsIgnoreCase(birKrediTaksit.getDurumKod())) {
						taksit = taksit.add(birKrediTaksit.getTaksitTut() != null ? birKrediTaksit.getTaksitTut() : BigDecimal.ZERO);
					}
					else {
						taksit = taksit.add(birKrediTaksit.getKismidenKalanAnapara() != null ? birKrediTaksit.getKismidenKalanAnapara() : BigDecimal.ZERO);
						taksit = taksit.add(birKrediTaksit.getKismidenKalanBsmv() != null ? birKrediTaksit.getKismidenKalanBsmv() : BigDecimal.ZERO);
						taksit = taksit.add(birKrediTaksit.getKismidenKalanFaiz() != null ? birKrediTaksit.getKismidenKalanFaiz() : BigDecimal.ZERO);
						taksit = taksit.add(birKrediTaksit.getKismidenKalanKkdf() != null ? birKrediTaksit.getKismidenKalanKkdf() : BigDecimal.ZERO);
					}
					if (birKrediTaksit.getGecikmeFaizTutari() != null)
						gecikmeFaiz = birKrediTaksit.getGecikmeFaizTutari();
					if (gecikmeFaiz != null && !gecikmeFaiz.equals(BigDecimal.ZERO)) {
						gecikmeFaiz = gecikmeFaiz.setScale(2, RoundingMode.HALF_EVEN);

						BigDecimal bsmvOran = birKullandirimList.get(i).getBsmvOran();
						BigDecimal bsmvTutar = BigDecimal.ZERO;
						if (bsmvOran != null && !bsmvOran.equals(BigDecimal.ZERO)) {
							bsmvTutar = gecikmeFaiz.multiply(bsmvOran).divide(new BigDecimal(100));
							bsmvTutar = bsmvTutar.setScale(2, RoundingMode.HALF_EVEN);
						}

						BigDecimal kkdfOran = birKullandirimList.get(i).getKkdfOran();
						if (kkdfOran != null && !kkdfOran.equals(BigDecimal.ZERO)) {
							BigDecimal kkdfTutar = gecikmeFaiz.multiply(kkdfOran).divide(new BigDecimal(100));
							kkdfTutar = kkdfTutar.setScale(2, RoundingMode.HALF_EVEN);
							gecikmeFaiz = gecikmeFaiz.add(kkdfTutar);
						}

						if (gecikmeFaiz != null) {
							gecikmeFaiz = gecikmeFaiz.add(bsmvTutar);
							gecikmeTutar = gecikmeTutar.add(gecikmeFaiz);
						}
					}
				}
				
				GMMap s3Map = new GMMap();
				Calendar c = Calendar.getInstance();
				s3Map.put("BANKA_TARIH", c.getTime()); 
				
				GMMap inputDates = new GMMap();
				inputDates.put("FIRST_DATE", enGecikmisTarih);
				inputDates.put("SECOND_DATE", s3Map.getDate("BANKA_TARIH"));
				GMMap dayMap = GMServiceExecuter.call("BNSPR_COMMON_GUN_FARKI_HESAPLA", inputDates);
				
				if (dayMap.getBigDecimal("DAYS") != null && dayMap.getBigDecimal("DAYS").signum() != -1) {
					oMap.put(tableName, i, "GECIKME_GUN_SAYISI", dayMap.getBigDecimal("DAYS"));
				}
				
				taksit = taksit.add(gecikmeTutar);
				oMap.put(tableName, i, "GECIKMIS_TAKSIT", taksit);

				if (taksit != null) {
					toplamGecikmis = toplamGecikmis.add(taksit);
				}
				
				inputDates.put("FIRST_DATE", birKullandirimList.get(i).getIslemTar());
				inputDates.put("SECOND_DATE", s3Map.getDate("BANKA_TARIH"));
				dayMap = GMServiceExecuter.call("BNSPR_COMMON_GUN_FARKI_HESAPLA", inputDates);
				/** Retention sorgusu i�in **/
				if("8".equals(birBasvuru.getKanalKodu()) && BigDecimal.valueOf(14).compareTo(dayMap.getBigDecimal("DAYS")) <= 0){
					webRetentionSorgu = "E";
				}
				
				gecikmeTutar = BigDecimal.ZERO;
			}
			
			BigDecimal toplamMasraf = toplamMasrafBakiye(iMap.getBigDecimal("MUSTERI_NO"));
			if(toplamMasraf == null)
				toplamMasraf = BigDecimal.ZERO;
			
			toplamKalanBorc = toplamKalanBorc.add(toplamMasraf);
			toplamKapamaBakiyesi = toplamKapamaBakiyesi.add(toplamMasraf);
			toplamGecikmis = toplamGecikmis.add(toplamMasraf);
			
			if(toplamGecikmis.compareTo(BigDecimal.ZERO) > 0){
				// gecikme var ise retention teklif olmayacak.
				webRetentionSorgu = "H";
			}
			
			oMap.put("TOPLAM_MASRAF_BAKIYE" , toplamMasraf);
			oMap.put("TOPLAM_KALAN_BORC", toplamKalanBorc);
			oMap.put("TOPLAM_ANAPARA", toplamAnapara);
			oMap.put("TOPLAM_KAPAMA_BAKIYESI", toplamKapamaBakiyesi);
			oMap.put("TOPLAM_TAKSIT_BORCU", toplamTaksit);
			oMap.put("TOPLAM_GECIKMIS_TAKSIT", toplamGecikmis);
			oMap.put("WEB_RETENTION_SORGU", webRetentionSorgu);
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static BigDecimal findKalanGeriOdemeTutari(BigDecimal basvuruNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_Bireysel2.Kalan_Geri_Odeme_Tutari(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, basvuruNo);
			stmt.execute();
			return stmt.getBigDecimal(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static BigDecimal toplamMasrafBakiye(BigDecimal musteriNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_QRY8033.ihtarname_masraf_bakiye(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, musteriNo);
			stmt.execute();
			return stmt.getBigDecimal(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}


	public static BigDecimal gecikmedeKalanAnapara(BigDecimal basvuruNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_Bireysel2.gecikmedekalananapara(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, basvuruNo);
			stmt.execute();
			return stmt.getBigDecimal(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static BigDecimal musteridenAlinacakTutar(GMMap anaMap, GMMap detayMap) {
		BigDecimal tutar = anaMap.getBigDecimal("TAHSILAT_TUTARI");
		BigDecimal farkFaiziKkdf = detayMap.getBigDecimal("FARK_FAIZI_KKDF");
		BigDecimal farkFaiziBsmv = detayMap.getBigDecimal("FARK_FAIZI_BSMV");
		BigDecimal farkFaizi = detayMap.getBigDecimal("FARK_FAIZI");

		String ilkTaksitOdendiMi = (String) DALUtil.callOneParameterFunction("{? = call pkg_trn3133.ilk_taksit_odendimi(?)}", Types.VARCHAR, detayMap.getBigDecimal("BASVURU_NO"));

		if ("H".equalsIgnoreCase(ilkTaksitOdendiMi)) {
			if (tutar != null && farkFaiziKkdf != null) {
				tutar = tutar.subtract(farkFaiziKkdf);
			}

			if (tutar != null && farkFaiziBsmv != null) {
				tutar = tutar.subtract(farkFaiziBsmv);
			}

			if (tutar != null && farkFaizi != null) {
				tutar = tutar.subtract(farkFaizi);
			}
		}
		return tutar;

	}

	@GraymoundService("BNSPR_QRY8033_SELECT_ALL")
	public static GMMap selectAll(GMMap iMap) {
		try {
			if (iMap.getBoolean("CHECKED")) {
				for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
					iMap.put("TABLE_DATA", i, "SEC", 1);
				}
				iMap = calculateAllTotalValues(iMap);
			}
			else {
				for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
					iMap.put("TABLE_DATA", i, "SEC", 0);
				}
				assignZeroAllTotalValues(iMap);
			}
			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}

	private static void assignZeroAllTotalValues(GMMap iMap) {
		iMap.put("TOPLAM_KALAN_BORC", BigDecimal.ZERO.add(iMap.getBigDecimal("IHTAR_MASRAF")));
		iMap.put("TOPLAM_ANAPARA", BigDecimal.ZERO);
		iMap.put("TOPLAM_KAPAMA_BAKIYESI", BigDecimal.ZERO.add(iMap.getBigDecimal("IHTAR_MASRAF")));
		iMap.put("TOPLAM_TAKSIT_BORCU", BigDecimal.ZERO);
		iMap.put("TOPLAM_GECIKMIS_TAKSIT", BigDecimal.ZERO.add(iMap.getBigDecimal("IHTAR_MASRAF")));
		
	}

	private static GMMap calculateAllTotalValues(GMMap iMap) {
		BigDecimal toplamKalanBorc = BigDecimal.ZERO;
		BigDecimal toplamAnapara = BigDecimal.ZERO;
		BigDecimal toplamKapamaBakiyesi = BigDecimal.ZERO;
		BigDecimal toplamTaksit = BigDecimal.ZERO;
		BigDecimal toplamGecikmis = BigDecimal.ZERO;

		int tableSize = iMap.getSize("TABLE_DATA");
		for (int i = 0; i < tableSize; i++) {
			BigDecimal kalanBorc = iMap.getBigDecimal("TABLE_DATA", i, "KALAN_TOPLAM_BORC");
			if (kalanBorc != null)
				toplamKalanBorc = toplamKalanBorc.add(kalanBorc);

			BigDecimal anapara = iMap.getBigDecimal("TABLE_DATA", i, "KALAN_ANAPARA");
			if (anapara != null)
				toplamAnapara = toplamAnapara.add(anapara);

			BigDecimal kapamaBakiyesi = iMap.getBigDecimal("TABLE_DATA", i, "KAPAMA_BAKIYESI");
			if (kapamaBakiyesi != null)
				toplamKapamaBakiyesi = toplamKapamaBakiyesi.add(kapamaBakiyesi);

			BigDecimal taksit = iMap.getBigDecimal("TABLE_DATA", i, "TAKSIT_BORCU");
			if (taksit != null)
				toplamTaksit = toplamTaksit.add(taksit);

			BigDecimal gecikmisTaksit = iMap.getBigDecimal("TABLE_DATA", i, "GECIKMIS_TAKSIT");
			if (gecikmisTaksit != null)
				toplamGecikmis = toplamGecikmis.add(gecikmisTaksit);
		}
		
		BigDecimal toplamMasraf = iMap.getBigDecimal("IHTAR_MASRAF");
		if(toplamMasraf == null)
			toplamMasraf = BigDecimal.ZERO;
		
		toplamKalanBorc = toplamKalanBorc.add(toplamMasraf);
		toplamKapamaBakiyesi = toplamKapamaBakiyesi.add(toplamMasraf);
		toplamGecikmis = toplamGecikmis.add(toplamMasraf);

		iMap.put("TOPLAM_KALAN_BORC", toplamKalanBorc);
		iMap.put("TOPLAM_ANAPARA", toplamAnapara);
		iMap.put("TOPLAM_KAPAMA_BAKIYESI", toplamKapamaBakiyesi);
		iMap.put("TOPLAM_TAKSIT_BORCU", toplamTaksit);
		iMap.put("TOPLAM_GECIKMIS_TAKSIT", toplamGecikmis);

		return iMap;
	}

}
