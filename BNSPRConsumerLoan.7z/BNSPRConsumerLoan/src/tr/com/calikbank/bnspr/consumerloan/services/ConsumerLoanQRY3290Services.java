package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KmhTaksitli;
import tr.com.aktifbank.bnspr.dao.MuhHesapKredi;
import tr.com.calikbank.bnspr.consumerloan.utils.CreditTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruKefil;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.dao.KmhTanim;
import tr.com.calikbank.bnspr.dao.KreMusteriLimit;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.module.custom.services.LOVExecuter;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanQRY3290Services {
	
	/**
	 * DESC    : Risk Sorgulama Servisi
	 *
	 * @param iMap (GMMap)
	 *          MUSTERI_NO  TC_KIMLIK_NO
	 *
	 * @return oMap (GMMap)
	 *      RESPONSE
	 *      RESPONSE_DATA
	 *      	MUSTERI RISK BILGILERI (BIREYSEL, VDMK, TASFIYE)
	 */
	@GraymoundService("BNSPR_QRY3290_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap tMap = new GMMap();
		List<Object> inputList = null;
		String musteriNo = StringUtils.EMPTY;
		try {
			if (StringUtil.isEmpty(iMap.getString("MUSTERI_NO"))) {
				if (StringUtil.isEmpty(iMap.getString("TC_KIMLIK_NO"))) {
					throw new GMRuntimeException(0, "M��teri No / Tc kimlik no dan birisi dolu olmal�d�r.");
				}
				else {
					musteriNo = (String) DALUtil.callOneParameterFunction("{? = call  pkg_musteri.Musteri_Varmi_TCKN(?)}", Types.VARCHAR, iMap.getString("TC_KIMLIK_NO"));
					if (musteriNo == null) {
						throw new GMRuntimeException(0, "Tc Kimlik Noya ait m��teri bulunamad�.");
					}
					else {
						iMap.put("MUSTERI_NO", musteriNo);
					}
				}
			}
			GMMap rMap = new GMMap();
			
			/** Bireysel Risk **/
			BigDecimal toplamBireyselRisk = BigDecimal.ZERO;
			BigDecimal toplamVdmkRisk = BigDecimal.ZERO;
			String vdmkDevredildimi = "";
			List<BirBasvuru> list = null;
			Session session = DAOSession.getSession("BNSPRDal");
			if(!StringUtil.isEmpty(iMap.getString("MUSTERI_NO"))){
				list = session.createCriteria(BirBasvuru.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).list();
			}else{
				list = session.createCriteria(BirBasvuru.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).list();
			}
			
			for (BirBasvuru birBasvuru : list) {
				rMap.put("BASVURU_NO", birBasvuru.getBasvuruNo());
				BirKullandirim kul = (BirKullandirim) session.createCriteria(BirKullandirim.class).add(Restrictions.eq("basvuruNo", birBasvuru.getBasvuruNo())).uniqueResult();
				
				if (kul != null && "G".equals(kul.getDrm())) {
					KmhTaksitli kmhTaksit = (KmhTaksitli) session.createCriteria(KmhTaksitli.class).add(Restrictions.eq("basvuruNo", kul.getBasvuruNo())).uniqueResult();
					KmhTanim kdhRisk = null;
					
					if(kul.getKrdTur().compareTo(CreditTypes.TAKSITLI_KDH.getCreditCode()) == 0 && kmhTaksit != null){
						kdhRisk = (KmhTanim) session.createCriteria(KmhTanim.class).add(Restrictions.eq("kmhSiraNo", kmhTaksit.getKmhNo()))
																					.add(Restrictions.not(Restrictions.in("durum", new String[] {"KAPALI","T","Y","YT"})))
																					.uniqueResult();
					}
					
					if(kdhRisk == null) {
						vdmkDevredildimi = (String) DALUtil.callOneParameterFunction("{?=call PKG_VDMK.Devredildi_Mi(?)}", Types.VARCHAR, birBasvuru.getBasvuruNo());

						inputList = new ArrayList<Object>();
		    			inputList.add(kul.getBasvuruNo());
		    			List<?> listHesap = LOVExecuter.execute("3135Q/LOV_BASVURU_2", "%", inputList);
		    			if(listHesap.size() > 0){
		    				iMap.put("HESAP_DURUM", ((HashMap<?, ?>)listHesap.get(0)).get("HESAP_DURUM"));
		    			}
						
						rMap.putAll(GMServiceExecuter.execute("BNSPR_GET_TAKSIT_BILGILER", rMap));
						rMap.put("REZERVASYON_KURU", BigDecimal.ZERO);
						if("I".equals(iMap.getString("HESAP_DURUM")) || "G".equals(iMap.getString("HESAP_DURUM")))
							rMap.put("ERKEN_KAPAMA_GEC_KISMI_DAHIL", "E");
						else
							rMap.put("ERKEN_KAPAMA_GEC_KISMI_DAHIL", "H");
						rMap.put("EKRAN_NO", "3137");
						rMap.putAll(GMServiceExecuter.execute("BNSPR_Q3137_GET_GERI_ODEME_ERKEN_KAPAMA", rMap));
						
						if ("E".equals(vdmkDevredildimi)) {
							toplamVdmkRisk = toplamVdmkRisk.add(rMap.getBigDecimal("TAHSILAT_TUTARI") == null ? BigDecimal.ZERO : rMap.getBigDecimal("TAHSILAT_TUTARI"));
						}
						else {
							toplamBireyselRisk = toplamBireyselRisk.add(rMap.getBigDecimal("TAHSILAT_TUTARI") == null ? BigDecimal.ZERO : rMap.getBigDecimal("TAHSILAT_TUTARI"));
						}
					}
					
				}
			}
			oMap.put("TOPLAM_BIREYSEL_RISK", toplamBireyselRisk);
			oMap.put("TOPLAM_VDMK_RISK", toplamVdmkRisk);
			
			/** Gayri nakdi risk **/
			BigDecimal toplamGayriNakdiRisk = BigDecimal.ZERO;
			rMap.clear();
			KreMusteriLimit kreLimit = (KreMusteriLimit) session.createCriteria(KreMusteriLimit.class).add(Restrictions.eq("musteriNo", iMap.getString("MUSTERI_NO"))).uniqueResult();
			if(kreLimit != null){
				toplamGayriNakdiRisk = kreLimit.getLcGnakdiRisk() != null ? kreLimit.getLcGnakdiRisk() : BigDecimal.ZERO;
			}
			oMap.put("TOPLAM_GAYRINAKDI_RISK", toplamGayriNakdiRisk);
			
			/** Toplam Kefil Olunan Risk **/ 
			BigDecimal toplamKefilRisk = BigDecimal.ZERO;
			rMap.clear();
			if(!StringUtil.isEmpty(iMap.getString("TC_KIMLIK_NO"))){
				List<BirBasvuruKefil> kefilList = session.createCriteria(BirBasvuruKefil.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).list();
				for (BirBasvuruKefil birBasvuruKefil : kefilList) {
					rMap.put("BASVURU_NO", birBasvuruKefil.getBasvuruNo());
					BirKullandirim kul = (BirKullandirim) session.createCriteria(BirKullandirim.class).add(Restrictions.eq("basvuruNo", birBasvuruKefil.getBasvuruNo())).uniqueResult();
					
					if (kul != null && "G".equals(kul.getDrm())) {
						inputList = new ArrayList<Object>();
		    			inputList.add(kul.getBasvuruNo());
		    			List<?> listHesap = LOVExecuter.execute("3135Q/LOV_BASVURU_2", "%", inputList);
		    			if(listHesap.size() > 0){
		    				iMap.put("HESAP_DURUM", ((HashMap<?, ?>)listHesap.get(0)).get("HESAP_DURUM"));
		    			}
						rMap.putAll(GMServiceExecuter.execute("BNSPR_GET_TAKSIT_BILGILER", rMap));
						rMap.put("REZERVASYON_KURU", BigDecimal.ZERO);
						
						if("I".equals(iMap.getString("HESAP_DURUM")) || "G".equals(iMap.getString("HESAP_DURUM")))
							rMap.put("ERKEN_KAPAMA_GEC_KISMI_DAHIL", "E");
						else
							rMap.put("ERKEN_KAPAMA_GEC_KISMI_DAHIL", "H");
						rMap.put("EKRAN_NO", "3137");
						rMap.putAll(GMServiceExecuter.execute("BNSPR_Q3137_GET_GERI_ODEME_ERKEN_KAPAMA", rMap));
						
						toplamKefilRisk = toplamKefilRisk.add(rMap.getBigDecimal("TAHSILAT_TUTARI") == null ? BigDecimal.ZERO : rMap.getBigDecimal("TAHSILAT_TUTARI"));
					}
				}
			}
			
			oMap.put("TOPLAM_KEFIL_RISK", toplamKefilRisk);
			
			/** YTS Riskleri **/
			BigDecimal toplamYTSRisk = BigDecimal.ZERO;
			rMap.clear();
			rMap.put("MUSTERI_NO", iMap.getString("MUSTERI_NO"));
			rMap.putAll(GMServiceExecuter.execute("BNSPR_DCS_ANLIK_BAKIYE_AL", rMap));
			toplamYTSRisk = toplamYTSRisk.add(rMap.getBigDecimal("SUM_KALAN_ANAPARA") != null ? rMap.getBigDecimal("SUM_KALAN_ANAPARA") : BigDecimal.ZERO);
			toplamYTSRisk = toplamYTSRisk.add(rMap.getBigDecimal("SUM_FAIZ") != null ? rMap.getBigDecimal("SUM_FAIZ") : BigDecimal.ZERO);
			toplamYTSRisk = toplamYTSRisk.add(rMap.getBigDecimal("SUM_MASRAF") != null ? rMap.getBigDecimal("SUM_MASRAF") : BigDecimal.ZERO);
			toplamYTSRisk = toplamYTSRisk.add(rMap.getBigDecimal("SUM_KTVU") != null ? rMap.getBigDecimal("SUM_KTVU") : BigDecimal.ZERO);
			toplamYTSRisk = toplamYTSRisk.compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : toplamYTSRisk;
			oMap.put("TOPLAM_YTS_RISK", toplamYTSRisk);
			
			/** Yasal takip - Kapal� Kontrol **/
			List<MuhHesapKredi> takipList = session.createCriteria(MuhHesapKredi.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).add(Restrictions.eq("takipDurumKodu", "Y")).list();
			if(takipList.size() > 0){
				oMap.put("YASAL_TAKIP", "E");
			}
			takipList = session.createCriteria(MuhHesapKredi.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).add(Restrictions.eq("takipDurumKodu", "T")).list();
			if(takipList.size() > 0){
				oMap.put("TAKIPTEN_KAPALI", "E");
			}
			
			/** Vefat Durum Kontrol **/
			iMap.put("VEFAT_TARIHI", DALUtil.callOneParameterFunction("{? = call  pkg_musteri.olum_tarihi(?)}", Types.DATE, iMap.getBigDecimal("MUSTERI_NO")));
			if(iMap.get("VEFAT_TARIHI") != null){
				oMap.put("VEFAT_DURUM", "E");
			}
			
			/** Noter Masraf�, ge�ici Hesap Riskleri **/
			BigDecimal masrafRisk = (BigDecimal) DALUtil.callOneParameterFunction("{? = call  pkg_rc3290.masraf_risk_getir(?)}", Types.DECIMAL, iMap.getBigDecimal("MUSTERI_NO"));
			oMap.put("TOPLAM_MASRAF_RISK", masrafRisk);
			
			/** KDH Kapama Bakiyesi **/
			List<?> kdhList = null;
			kdhList = session.createCriteria(KmhTanim.class)
					.add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO")))
					.add(Restrictions.not(Restrictions.in("durum", new String[] {"KAPALI","T","Y","YT"})))
					.list();
			//Degerleri al
			BigDecimal kdhKapamaBakiye = BigDecimal.ZERO;
			KmhTanim kmhTanim = null;
			for (Object o : kdhList) {
				kmhTanim = (KmhTanim) o;
				rMap.clear();
				rMap.put("HESAP_NO", kmhTanim.getHesapNo());
				rMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3290_KMH_KAPAMA_BAKIYESI_HESAPLA", rMap));
				kdhKapamaBakiye = kdhKapamaBakiye.add(rMap.getBigDecimal("KAPAMA_BAKIYESI"));
			}
			oMap.put("TOPLAM_KDH_KAPAMA_BAKIYE", kdhKapamaBakiye);
			
			/** Kredi Karti Anlik Risk **/						
			iMap.put("CUSTOMER_NO", iMap.getString("MUSTERI_NO"));
			tMap.putAll(GMServiceExecuter.execute("BNSPR_OCEAN_GET_CARD_INFO", iMap));			
			//tMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_OCEAN_GET_CARD_INFO", iMap)); 
			
			String cardTableName="CARD_DETAIL_INFO";
			String deptTableName="DEBT_INFO_LIST";
			BigDecimal bdKrediKartiAnlikRiskToplam = BigDecimal.ZERO;
			
			if (tMap.getString("RETURN_CODE").equals("2")) {
				if (tMap.containsKey(cardTableName) && tMap.getSize(cardTableName) > 0) {					
					for (int i = 0; i < tMap.getSize(cardTableName); i++) {
						if (tMap.get(cardTableName, i, deptTableName) != null) {
							@SuppressWarnings("unchecked")
							List<GMMap> cardDept = (List<GMMap>) tMap.get(cardTableName, i, deptTableName);
							GMMap deptMap = cardDept.get(0);
							for (int j = 0; j < deptMap.getSize(deptTableName); j++) {
								if (deptMap.getString(deptTableName, j, "CURRENCY") != null && deptMap.getString(deptTableName, j, "CURRENCY").equals("TRY")) {
									BigDecimal bdTemp =deptMap.getBigDecimal(deptTableName, j, "PAYOFF_TOTAL"); 												
																		
									bdKrediKartiAnlikRiskToplam = bdKrediKartiAnlikRiskToplam.add(bdTemp);
								}
							}
						}
						break;

					}
				}
			}
			bdKrediKartiAnlikRiskToplam = bdKrediKartiAnlikRiskToplam.compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : bdKrediKartiAnlikRiskToplam;
			oMap.put("KREDI_KARTI_ANLIK_RISK", bdKrediKartiAnlikRiskToplam);
			
			BigDecimal toplamRisk = toplamBireyselRisk.add(toplamVdmkRisk).add(toplamKefilRisk).add(toplamYTSRisk).add(masrafRisk).add(toplamGayriNakdiRisk).add(kdhKapamaBakiye).add(bdKrediKartiAnlikRiskToplam);
			toplamRisk = toplamRisk.compareTo(BigDecimal.ZERO) < 0 ? BigDecimal.ZERO : toplamRisk;

			/** Genel Toplam **/
			oMap.put("GENEL_TOPLAM", toplamRisk);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_QRY3290_GET_KEFIL_DETAY")
	public static GMMap getKefilDetay(GMMap iMap) {
		GMMap oMap = new GMMap();
		int i=0;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			if(!StringUtil.isEmpty(iMap.getString("TC_KIMLIK_NO"))){
				List<BirBasvuruKefil> kefilList = session.createCriteria(BirBasvuruKefil.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TC_KIMLIK_NO"))).list();
				for (BirBasvuruKefil birBasvuruKefil : kefilList) {
					BirBasvuru bas = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", birBasvuruKefil.getBasvuruNo())).uniqueResult();
					if(bas != null){
						oMap.put("KEFIL_TABLE", i, "BASVURU_NO", bas.getBasvuruNo());
						oMap.put("KEFIL_TABLE", i, "MUSTERI_NO", bas.getMusteriNo());
						i++;
					}
				}
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	/** Kmh kapama bakiyesini hesap numarasi ve valor tarihi kullanarak bulur. 
	 * Valor tarihi verilmezse bir sonraki is gunu baz alinir.<br>
	 * @author murat.el
	 * @since TY-3875
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>HESAP_NO - Kmh hesap numarasi
	 *        <li>VALOR_TARIHI - Faiz tutarlarin hesaplanacagi valor tarihi. yyyyMMdd formati.
	 * @return oMap - Sonuc bilgisi<br>
	 * 		  <li>KAPAMA_BAKIYESI - Kmh kapama bakiyesi
	 */
	@GraymoundService("BNSPR_QRY3290_KMH_KAPAMA_BAKIYESI_HESAPLA")
	public static GMMap kmhKapamaBakiyesiHesapla(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal kapamaBakiyesi = BigDecimal.ZERO;

		try {
			GMMap sorguMap = new GMMap();
			sorguMap.put("HESAP_NO", iMap.get("HESAP_NO"));
			sorguMap.putAll(kmhBilgiAlByHesapNo(sorguMap));
			//Kontrol - Data alindi mi
			if (sorguMap.get("KMH_SIRA_NO") == null) {
				oMap.put("KAPAMA_BAKIYESI", kapamaBakiyesi);
				return oMap;
			}
			//Data alindi ise faiz tutarlarini valorle hesapla
			if (iMap.containsKey("VALOR_TARIHI") && StringUtils.isNotBlank(iMap.getString("VALOR_TARIHI"))) {
				sorguMap.put("VALOR_TARIHI", iMap.get("VALOR_TARIHI"));
			}
			sorguMap.putAll(GMServiceExecuter.call("BNSPR_TRN3005_VALOR_TARIH_KONTROL", sorguMap));
			//Valorle hesaplanan tutarlari bakiyeye ekle
			kapamaBakiyesi = kapamaBakiyesi
					.add(ConsumerLoanCommonServices.nvl(sorguMap.getBigDecimal("HESAP_BAKIYE"), BigDecimal.ZERO))
					.multiply(BigDecimal.valueOf(-1))
					.add(ConsumerLoanCommonServices.nvl(sorguMap.getBigDecimal("FAIZ"), BigDecimal.ZERO))
					.add(ConsumerLoanCommonServices.nvl(sorguMap.getBigDecimal("BSMV"), BigDecimal.ZERO))
					.add(ConsumerLoanCommonServices.nvl(sorguMap.getBigDecimal("KKDF"), BigDecimal.ZERO))
					.add(ConsumerLoanCommonServices.nvl(sorguMap.getBigDecimal("TAHSIL_EDILMEMIS_TAHAKKUK"), BigDecimal.ZERO));		
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("KAPAMA_BAKIYESI", kapamaBakiyesi);
		return oMap;
	}
	
	/** Kmh kapama bakiyesi hesaplamada kullanilacak degerleri alir.<br>
	 * @author murat.el
	 * @since TY-3875
	 * @param iMap - Sorgu kriterleri<br>
	 *        <li>HESAP_NO - Kmh hesap numarasi
	 * @return oMap - Sonuc bilgisi<br>
	 * 		  <li>HESAP_NO <li>KMH_SIRA_NO<li>VALOR_TARIHI<li>BIRIKMIS_FAIZ
	 * 		  <li>FAIZ_ORANI<li>KMH_BAKIYE<li>HESAP_BAKIYE<li>BSMV_ORAN
	 * 		  <li>KKDF_ORAN<li>TAHSIL_EDILMEMIS_TAHAKKUK
	 */
	private static GMMap kmhBilgiAlByHesapNo(GMMap iMap) {
		GMMap oMap = new GMMap();

		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_rc3290.kmh_kapama_bakiyesi_bilgi_al(?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("HESAP_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetMap(rSet));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

}
