package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3139Services {
	
	@GraymoundService("BNSPR_QRY3139_QUERY_WINBANK_AKTARIM")
	public static GMMap queryWinbankAktarim(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3139.RC_QRY3139_WINBANK_AKTARIM(?,?,?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("BAYI_FIRMA_MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("TCKN"));
			if(iMap.getDate("BAS_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			else
				stmt.setDate(i++, null);
			if(iMap.getDate("BIT_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BIT_TARIH").getTime()));
			else
				stmt.setDate(i++, null);
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);

			String tableName = "RESULT";
			for (i = 0; rSet.next(); i++) {
				oMap.put(tableName, i, "AD_AKTARILACAK_TUTAR", rSet.getString("aktarilacak_tutar"));
				oMap.put(tableName, i, "AD_AKTARILACAK_TUTAR_DOVIZ_KODU", rSet.getString("doviz_kodu"));
				oMap.put(tableName, i, "AD_ALACAKLI_HESAP_NO", rSet.getString("alac_hesap_no"));
				oMap.put(tableName, i, "AD_BASVURU_NO", rSet.getString("basvuru_no"));
				oMap.put(tableName, i, "AD_BAYI_FIRMA_HESAP_NO", rSet.getString("firma_bayi_hesap_no"));
				oMap.put(tableName, i, "AD_BAYI_FIRMA_UNVAN", rSet.getString("firma_bayi_unvan"));
				oMap.put(tableName, i, "AD_BAYI_KOMISYONU", rSet.getString("bayi_kom"));
				oMap.put(tableName, i, "AD_FIRMA_BAYI_MUSTERI_NO", rSet.getString("firma_bayi_musteri_no"));
				oMap.put(tableName, i, "AD_KULLANDIRIM_TARIHI", rSet.getString("islem_tar"));
				oMap.put(tableName, i, "AD_MUSTERI_NO", rSet.getString("musteri_no"));
				oMap.put(tableName, i, "AD_MUSTERI_UNVANI", rSet.getString("musteri_unvan"));
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
