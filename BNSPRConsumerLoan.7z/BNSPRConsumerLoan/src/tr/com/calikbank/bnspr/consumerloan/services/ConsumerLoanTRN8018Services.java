package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KrediLimitKriterler;
import tr.com.aktifbank.bnspr.dao.KrediLimitKriterlerTx;
import tr.com.aktifbank.bnspr.dao.KrediLimitKriterlerTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN8018Services {

	public enum IslemTipi {
		YENI("Y", "Yeni Kay�t"), GUNCELLEME("G", "G�ncelleme"), SILME("S", "Silme"), DEGISIKLIK_YOK("D", "De�i�iklik Yok");

		private String kod;
		private String aciklama;

		public String getKod() {
			return kod;
		}

		public String getAciklama() {
			return aciklama;
		}

		public static IslemTipi tipBul(String kod) {
			if ("Y".equalsIgnoreCase(kod)) {
				return YENI;
			}
			else if ("G".equalsIgnoreCase(kod)) {
				return GUNCELLEME;
			}
			else if ("S".equalsIgnoreCase(kod)) {
				return SILME;
			}

			return null;
		}

		private IslemTipi(String kod, String aciklama) {
			this.kod = kod;
			this.aciklama = aciklama;
		}

	}

	private enum KriterKod {
		KAMPANYA("KAMPANYA", "kampKod", true), KANAL("KANAL", "kanalKodu", false), KREDI_TUR("KREDI_TUR", "krdTur", true);

		private String kriterKod;
		private String fieldName;
		private boolean isNumber;

		private KriterKod(String kriterKod, String fieldName, boolean isNumber) {
			this.kriterKod = kriterKod;
			this.fieldName = fieldName;
			this.isNumber = isNumber;
		}
	}

	@GraymoundService("BNSPR_TRN8018_FILL_TABLE_COMBOBOX")
	public static GMMap fillTableComboBox(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			oMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("LIST_NAME", "KRITERLER");
			oMap.put("LIST_QUERY", "select TEXT ,KEY1 FROM BNSPR.GNL_PARAM_TEXT WHERE KOD ='KREDI_LIMIT_PARAMETRE' order by KEY1");

			DALUtil.fillComboBox(oMap);

			String listName = "TEMINATLI";
			GuimlUtil.wrapMyCombo(oMap, listName, "E", "EVET");
			GuimlUtil.wrapMyCombo(oMap, listName, "H", "HAYIR");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN8018_GET_CODE")
	public static GMMap getCode(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('KREDI_LIMIT_KRITERLER')}");
			stmt.registerOutParameter(1, Types.NUMERIC);

			stmt.execute();

			BigDecimal code = stmt.getBigDecimal(1);

			oMap.put("CODE", code);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN8018_GET_INFO")
	public static GMMap getInfoTRN8018(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");

		ArrayList<KrediLimitKriterlerTx> kriterler = (ArrayList<KrediLimitKriterlerTx>) session.createCriteria(KrediLimitKriterlerTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
		String tableName = "KREDI_LIMIT_KRITERLER";

		for (int row = 0; row < kriterler.size(); row++) {
			oMap.put(tableName, row, "KRITER", kriterler.get(row).getKriterKey());
			oMap.put(tableName, row, "KOD", kriterler.get(row).getId().getKod());
			oMap.put(tableName, row, "DEGER_KOD", kriterler.get(row).getDegerKod());
			oMap.put(tableName, row, "DEGER", LovHelper.diLov(kriterler.get(row).getDegerKod(), kriterler.get(row).getKriterKey(), kriterler.get(row).getKriterKey(), kriterler.get(row).getKriterKey(), kriterler.get(row).getKriterKey(), kriterler.get(row).getKriterKey(), kriterler.get(row).getKriterKey(), "8018/LOV_DEGER", "ACIKLAMA"));
			oMap.put(tableName, row, "KULLANDIRIM_TUTARI_YILLIK", kriterler.get(row).getKullandirimTutariYillik());
			oMap.put(tableName, row, "BAKIYE_YILLIK", kriterler.get(row).getBakiyeYillik());
			oMap.put(tableName, row, "KULLANDIRIM_TUTARI_AYLIK", kriterler.get(row).getKullandirimTutariAylik());
			oMap.put(tableName, row, "BAKIYE_AYLIK", kriterler.get(row).getBakiyeAylik());
			oMap.put(tableName, row, "ISLEM_TIPI", IslemTipi.tipBul(kriterler.get(row).getIslemTipi()));
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN8018_GET")
	public static GMMap getTRN8018(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");

		ArrayList<KrediLimitKriterler> kriterler = (ArrayList<KrediLimitKriterler>) session.createCriteria(KrediLimitKriterler.class).list();
		String tableName = "KREDI_LIMIT_KRITERLER";

		for (int row = 0; row < kriterler.size(); row++) {
			oMap.put(tableName, row, "KRITER", kriterler.get(row).getKriterKey());
			oMap.put(tableName, row, "KOD", kriterler.get(row).getKod());
			oMap.put(tableName, row, "DEGER_KOD", kriterler.get(row).getDegerKod());
			oMap.put(tableName, row, "DEGER", LovHelper.diLov(kriterler.get(row).getDegerKod(), kriterler.get(row).getKriterKey(), kriterler.get(row).getKriterKey(), kriterler.get(row).getKriterKey(), kriterler.get(row).getKriterKey(), kriterler.get(row).getKriterKey(), kriterler.get(row).getKriterKey(), "8018/LOV_DEGER", "ACIKLAMA"));
			oMap.put(tableName, row, "KULLANDIRIM_TUTARI_YILLIK", kriterler.get(row).getKullandirimTutariYillik());
			oMap.put(tableName, row, "BAKIYE_YILLIK", kriterler.get(row).getBakiyeYillik());
			oMap.put(tableName, row, "KULLANDIRIM_TUTARI_AYLIK", kriterler.get(row).getKullandirimTutariAylik());
			oMap.put(tableName, row, "BAKIYE_AYLIK", kriterler.get(row).getBakiyeAylik());
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN8018_DELETE_ROW")
	public static GMMap deleteRow(GMMap iMap) {

		Session session = DAOSession.getSession("BNSPRDal");

		GMMap rowMap = iMap.getMap("ROW");

		KrediLimitKriterlerTx krediLimitKriterTx = new KrediLimitKriterlerTx();

		KrediLimitKriterlerTxId krediLimitKriterlerTxId = new KrediLimitKriterlerTxId(iMap.getBigDecimal("TRX_NO"), rowMap.getBigDecimal("KOD"));
		krediLimitKriterTx.setId(krediLimitKriterlerTxId);
		krediLimitKriterTx.setKriterKey(rowMap.getString("KRITER"));
		krediLimitKriterTx.setDegerKod(rowMap.getString("DEGER_KOD"));
		krediLimitKriterTx.setKullandirimTutariYillik(rowMap.getBigDecimal("KULLANDIRIM_TUTARI_YILLIK"));
		krediLimitKriterTx.setBakiyeYillik(rowMap.getBigDecimal("BAKIYE_YILLIK"));
		krediLimitKriterTx.setKullandirimTutariAylik(rowMap.getBigDecimal("KULLANDIRIM_TUTARI_AYLIK"));
		krediLimitKriterTx.setBakiyeAylik(rowMap.getBigDecimal("BAKIYE_AYLIK"));
		krediLimitKriterTx.setIslemTipi("S");

		session.save(krediLimitKriterTx);

		session.flush();

		return iMap;
	}

	@GraymoundService("BNSPR_TRN8018_SAVE")
	public static Map<?, ?> saveTRN8018(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "KREDI_LIMIT_KRITERLER";
			ArrayList<?> list = (ArrayList<?>) iMap.get(tableName);

			for (int i = 0; i < list.size(); i++) {
				if (iMap.getString(tableName, i, "ISLEM_TIPI") != null) {
					KrediLimitKriterlerTx krediLimitKriterTx = new KrediLimitKriterlerTx();

					KrediLimitKriterlerTxId krediLimitKriterlerTxId = new KrediLimitKriterlerTxId(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal(tableName, i, "KOD"));
					krediLimitKriterTx.setId(krediLimitKriterlerTxId);
					krediLimitKriterTx.setKriterKey(iMap.getString(tableName, i, "KRITER"));
					krediLimitKriterTx.setDegerKod(iMap.getString(tableName, i, "DEGER_KOD"));
					krediLimitKriterTx.setKullandirimTutariYillik(iMap.getBigDecimal(tableName, i, "KULLANDIRIM_TUTARI_YILLIK"));
					krediLimitKriterTx.setBakiyeYillik(iMap.getBigDecimal(tableName, i, "BAKIYE_YILLIK"));
					krediLimitKriterTx.setKullandirimTutariAylik(iMap.getBigDecimal(tableName, i, "KULLANDIRIM_TUTARI_AYLIK"));
					krediLimitKriterTx.setBakiyeAylik(iMap.getBigDecimal(tableName, i, "BAKIYE_AYLIK"));
					krediLimitKriterTx.setIslemTipi(iMap.getString(tableName, i, "ISLEM_TIPI"));

					session.save(krediLimitKriterTx);
				}
			}

			session.flush();

			iMap.put("TRX_NAME", "8018");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN8018_KRITER_KONTROL_JOB")
	public static GMMap kriterKontrolJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		Calendar calendar = Calendar.getInstance();

		calendar.set(Calendar.DATE, 1);
		calendar.add(Calendar.DAY_OF_MONTH, -1);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		Date sonGun = calendar.getTime();

		calendar.add(Calendar.YEAR, -1);
		Date gecenSene = calendar.getTime();

		calendar.add(Calendar.YEAR, 1);
		calendar.set(Calendar.DATE, 1);
		Date ilkGun = calendar.getTime();

		StringBuilder mailBody = new StringBuilder();
		mailBody.append("<html><body>");
		mailBody.append("<table border=\"1\">");
		mailBody.append("<tr>");
		mailBody.append("<th>Kriter Ad�</th>");
		mailBody.append("<th>Kriter Degeri</th>");
		mailBody.append("<th>Kull.Tutar� Ayl�k</th>");
		mailBody.append("<th>Bakiye Ayl�k</th>");
		mailBody.append("<th>Kull.Tutar� Y�ll�k</th>");
		mailBody.append("<th>Bakiye Y�ll�k</th></tr>");

		for (KriterKod kriterKod : KriterKod.values()) {
			List<KrediLimitKriterler> kriterler = session.createCriteria(KrediLimitKriterler.class).add(Restrictions.eq("kriterKey", kriterKod.kriterKod)).list();

			for (KrediLimitKriterler kriter : kriterler) {

				String sql = "select sum(k.krdTutar) as krdtutar, -sum(h.bakiye) as tutar from BirKullandirim k,MuhHesapBakiye h where k." + kriterKod.fieldName + " = :value and k.krdHesapNo = h.hesapNo and k.islemTar between :tar1 and :tar2";
				Query query = session.createQuery(sql);

				if (kriterKod.isNumber) {
					query.setParameter("value", new BigDecimal(kriter.getDegerKod()));
				}
				else {
					query.setParameter("value", kriter.getDegerKod());
				}
				query.setParameter("tar1", ilkGun);
				query.setParameter("tar2", sonGun);

				Iterator iterator = query.list().iterator();

				boolean aylikEklendiMi = false;

				while (iterator.hasNext()) {
					Object[] list = (Object[]) iterator.next();
					aylikEklendiMi = true;
					mailBody.append("<tr><td>" + kriterKod.kriterKod + "</td>");
					mailBody.append("<td>" + kriter.getDegerKod() + "</td>");

					if (list[0] != null && ((BigDecimal) list[0]).compareTo(kriter.getKullandirimTutariAylik()) >= 0) {
						mailBody.append("<td><font color=\"red\">" + list[0] + "(" + kriter.getKullandirimTutariAylik() + ")" + "</font></td>");
					}
					else {
						mailBody.append("<td>" + list[0] + "(" + kriter.getKullandirimTutariAylik() + ")" + "</td>");
					}

					if (list[1] != null && ((BigDecimal) list[1]).compareTo(kriter.getBakiyeAylik()) >= 0) {
						mailBody.append("<td><font color=\"red\">" + list[1] + "(" + kriter.getBakiyeAylik() + ")" + "</font></td>");
					}
					else {
						mailBody.append("<td>" + list[1] + "(" + kriter.getBakiyeAylik() + ")" + "</td>");
					}

				}

				query = session.createQuery(sql);
				if (kriterKod.isNumber) {
					query.setParameter("value", new BigDecimal(kriter.getDegerKod()));
				}
				else {
					query.setParameter("value", kriter.getDegerKod());
				}
				query.setParameter("tar1", gecenSene);
				query.setParameter("tar2", sonGun);

				iterator = query.list().iterator();

				while (iterator.hasNext()) {
					Object[] list = (Object[]) iterator.next();
					if (!aylikEklendiMi) {
						mailBody.append("<tr><td>" + kriterKod.kriterKod + "</td>");
						mailBody.append("<td>" + kriter.getDegerKod() + "</td><td></td><td></td>");
					}

					if (list[0] != null && ((BigDecimal) list[0]).compareTo(kriter.getKullandirimTutariYillik()) >= 0) {
						mailBody.append("<td><font color=\"red\">" + list[0] + "(" + kriter.getKullandirimTutariYillik() + ")" + "</font></td>");
					}
					else {
						mailBody.append("<td>" + list[0] + "(" + kriter.getKullandirimTutariYillik() + ")" + "</td>");
					}

					if (list[1] != null && ((BigDecimal) list[1]).compareTo(kriter.getBakiyeYillik()) >= 0) {
						mailBody.append("<td><font color=\"red\">" + list[1] + "(" + kriter.getBakiyeYillik() + ")" + "</font></td>");
					}
					else {
						mailBody.append("<td>" + list[1] + "(" + kriter.getBakiyeYillik() + ")" + "</td>");
					}

				}
			}
		}

		List<KrediLimitKriterler> kriterler = session.createCriteria(KrediLimitKriterler.class).add(Restrictions.eq("kriterKey", "KREDI_TIP")).list();
		for (KrediLimitKriterler kriter : kriterler) {
			String sql = "select sum(k.krdTutar) as krdtutar, -sum(h.bakiye) as tutar from BirKullandirim k,MuhHesapBakiye h, BirKampanya b where b.krdTurAltKod = :value and b.kod = k.kampKod and k.krdHesapNo = h.hesapNo and k.islemTar between :tar1 and :tar2";
			Query query = session.createQuery(sql);

			query.setParameter("value", new BigDecimal(kriter.getDegerKod()));
			query.setParameter("tar1", ilkGun);
			query.setParameter("tar2", sonGun);

			Iterator iterator = query.list().iterator();

			boolean aylikEklendiMi = false;

			while (iterator.hasNext()) {
				Object[] list = (Object[]) iterator.next();
				aylikEklendiMi = true;
				mailBody.append("<tr><td>" + "KREDI TIPI" + "</td>");
				mailBody.append("<td>" + kriter.getDegerKod() + "</td>");

				if (list[0] != null && ((BigDecimal) list[0]).compareTo(kriter.getKullandirimTutariAylik()) >= 0) {
					mailBody.append("<td><font color=\"red\">" + list[0] + "(" + kriter.getKullandirimTutariAylik() + ")" + "</font></td>");
				}
				else {
					mailBody.append("<td>" + list[0] + "(" + kriter.getKullandirimTutariAylik() + ")" + "</td>");
				}

				if (list[1] != null && ((BigDecimal) list[1]).compareTo(kriter.getBakiyeAylik()) >= 0) {
					mailBody.append("<td><font color=\"red\">" + list[1] + "(" + kriter.getBakiyeAylik() + ")" + "</font></td>");
				}
				else {
					mailBody.append("<td>" + list[1] + "(" + kriter.getBakiyeAylik() + ")" + "</td>");
				}

			}

			query = session.createQuery(sql);
			query.setParameter("value", new BigDecimal(kriter.getDegerKod()));

			query.setParameter("tar1", gecenSene);
			query.setParameter("tar2", sonGun);

			iterator = query.list().iterator();

			while (iterator.hasNext()) {
				Object[] list = (Object[]) iterator.next();
				if (!aylikEklendiMi) {
					mailBody.append("<tr><td>" + "KREDI TIPI" + "</td>");
					mailBody.append("<td>" + kriter.getDegerKod() + "</td><td></td><td></td>");
				}

				if (list[0] != null && ((BigDecimal) list[0]).compareTo(kriter.getKullandirimTutariYillik()) >= 0) {
					mailBody.append("<td><font color=\"red\">" + list[0] + "(" + kriter.getKullandirimTutariYillik() + ")" + "</font></td>");
				}
				else {
					mailBody.append("<td>" + list[0] + "(" + kriter.getKullandirimTutariYillik() + ")" + "</td>");
				}

				if (list[1] != null && ((BigDecimal) list[1]).compareTo(kriter.getBakiyeYillik()) >= 0) {
					mailBody.append("<td><font color=\"red\">" + list[1] + "(" + kriter.getBakiyeYillik() + ")" + "</font></td>");
				}
				else {
					mailBody.append("<td>" + list[1] + "(" + kriter.getBakiyeYillik() + ")" + "</td>");
				}

			}
		}

		kriterler = session.createCriteria(KrediLimitKriterler.class).add(Restrictions.eq("kriterKey", "IL")).list();
		for (KrediLimitKriterler kriter : kriterler) {
			String sql = "select sum(k.krdTutar) as krdtutar, -sum(h.bakiye) as tutar from BirKullandirim k,MuhHesapBakiye h, BirBasvuruKimlik b where b.evAdrIlKod = :value and b.basvuruNo = k.basvuruNo and k.krdHesapNo = h.hesapNo and k.islemTar between :tar1 and :tar2";
			Query query = session.createQuery(sql);

			query.setParameter("value", kriter.getDegerKod());
			query.setParameter("tar1", ilkGun);
			query.setParameter("tar2", sonGun);

			Iterator iterator = query.list().iterator();

			boolean aylikEklendiMi = false;

			while (iterator.hasNext()) {
				Object[] list = (Object[]) iterator.next();
				aylikEklendiMi = true;
				mailBody.append("<tr><td>" + "IL" + "</td>");
				mailBody.append("<td>" + kriter.getDegerKod() + "</td>");

				if (list[0] != null && ((BigDecimal) list[0]).compareTo(kriter.getKullandirimTutariAylik()) >= 0) {
					mailBody.append("<td><font color=\"red\">" + list[0] + "(" + kriter.getKullandirimTutariAylik() + ")" + "</font></td>");
				}
				else {
					mailBody.append("<td>" + list[0] + "(" + kriter.getKullandirimTutariAylik() + ")" + "</td>");
				}

				if (list[1] != null && ((BigDecimal) list[1]).compareTo(kriter.getBakiyeAylik()) >= 0) {
					mailBody.append("<td><font color=\"red\">" + list[1] + "(" + kriter.getBakiyeAylik() + ")" + "</font></td>");
				}
				else {
					mailBody.append("<td>" + list[1] + "(" + kriter.getBakiyeAylik() + ")" + "</td>");
				}

			}

			query = session.createQuery(sql);
			query.setParameter("value", kriter.getDegerKod());

			query.setParameter("tar1", gecenSene);
			query.setParameter("tar2", sonGun);

			iterator = query.list().iterator();

			while (iterator.hasNext()) {
				Object[] list = (Object[]) iterator.next();
				if (!aylikEklendiMi) {
					mailBody.append("<tr><td>" + "IL" + "</td>");
					mailBody.append("<td>" + kriter.getDegerKod() + "</td><td></td><td></td>");
				}

				if (list[0] != null && ((BigDecimal) list[0]).compareTo(kriter.getKullandirimTutariYillik()) >= 0) {
					mailBody.append("<td><font color=\"red\">" + list[0] + "(" + kriter.getKullandirimTutariYillik() + ")" + "</font></td>");
				}
				else {
					mailBody.append("<td>" + list[0] + "(" + kriter.getKullandirimTutariYillik() + ")" + "</td>");
				}

				if (list[1] != null && ((BigDecimal) list[1]).compareTo(kriter.getBakiyeYillik()) >= 0) {
					mailBody.append("<td><font color=\"red\">" + list[1] + "(" + kriter.getBakiyeYillik() + ")" + "</font></td>");
				}
				else {
					mailBody.append("<td>" + list[1] + "(" + kriter.getBakiyeYillik() + ")" + "</td>");
				}

			}
		}

		kriterler = session.createCriteria(KrediLimitKriterler.class).add(Restrictions.eq("kriterKey", "BOLGE")).list();
		for (KrediLimitKriterler kriter : kriterler) {
			String sql = " select sum(k.krdTutar) as krdtutar, -sum(h.bakiye) as tutar from BirKullandirim k,MuhHesapBakiye h, BirBasvuruKimlik b,GnlilKodPr i where i.bolgeKod = :value and  b.evAdrIlKod = i.kod and b.basvuruNo = k.basvuruNo and k.krdHesapNo = h.hesapNo and k.islemTar between :tar1 and :tar2";
			Query query = session.createQuery(sql);

			query.setParameter("value", kriter.getDegerKod());
			query.setParameter("tar1", ilkGun);
			query.setParameter("tar2", sonGun);

			Iterator iterator = query.list().iterator();

			boolean aylikEklendiMi = false;

			while (iterator.hasNext()) {
				Object[] list = (Object[]) iterator.next();
				aylikEklendiMi = true;
				mailBody.append("<tr><td>" + "BOLGE" + "</td>");
				mailBody.append("<td>" + kriter.getDegerKod() + "</td>");

				if (list[0] != null && ((BigDecimal) list[0]).compareTo(kriter.getKullandirimTutariAylik()) >= 0) {
					mailBody.append("<td><font color=\"red\">" + list[0] + "(" + kriter.getKullandirimTutariAylik() + ")" + "</font></td>");
				}
				else {
					mailBody.append("<td>" + list[0] + "(" + kriter.getKullandirimTutariAylik() + ")" + "</td>");
				}

				if (list[1] != null && ((BigDecimal) list[1]).compareTo(kriter.getBakiyeAylik()) >= 0) {
					mailBody.append("<td><font color=\"red\">" + list[1] + "(" + kriter.getBakiyeAylik() + ")" + "</font></td>");
				}
				else {
					mailBody.append("<td>" + list[1] + "(" + kriter.getBakiyeAylik() + ")" + "</td>");
				}

			}

			query = session.createQuery(sql);
			query.setParameter("value", kriter.getDegerKod());

			query.setParameter("tar1", gecenSene);
			query.setParameter("tar2", sonGun);

			iterator = query.list().iterator();

			while (iterator.hasNext()) {
				Object[] list = (Object[]) iterator.next();
				if (!aylikEklendiMi) {
					mailBody.append("<tr><td>" + "BOLGE" + "</td>");
					mailBody.append("<td>" + kriter.getDegerKod() + "</td><td></td><td></td>");
				}

				if (list[0] != null && ((BigDecimal) list[0]).compareTo(kriter.getKullandirimTutariYillik()) >= 0) {
					mailBody.append("<td><font color=\"red\">" + list[0] + "(" + kriter.getKullandirimTutariYillik() + ")" + "</font></td>");
				}
				else {
					mailBody.append("<td>" + list[0] + "(" + kriter.getKullandirimTutariYillik() + ")" + "</td>");
				}

				if (list[1] != null && ((BigDecimal) list[1]).compareTo(kriter.getBakiyeYillik()) >= 0) {
					mailBody.append("<td><font color=\"red\">" + list[1] + "(" + kriter.getBakiyeYillik() + ")" + "</font></td>");
				}
				else {
					mailBody.append("<td>" + list[1] + "(" + kriter.getBakiyeYillik() + ")" + "</td>");
				}

			}
		}

		mailBody.append("</table></body></html>");

		GMMap servisMap = new GMMap();
		servisMap.put("MAIL_FROM", "system@aktifbank.com.tr");
		servisMap.put("MAIL_TO", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "KREDI_LIMIT_BILGI_MAIL").put("KEY", "MAIL_TO")).getString("TEXT"));
		servisMap.put("MAIL_SUBJECT", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KOD", "KREDI_LIMIT_BILGI_MAIL").put("KEY", "SUBJECT")).getString("TEXT"));

		if (mailBody.length() > 3000) {
			servisMap.put("MAIL_BODY_CLOB", mailBody);
		}
		else {
			servisMap.put("MAIL_BODY", mailBody);
		}
		servisMap.put("IS_BODY_HTML", "E");
		GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);

		oMap.put("MAIL_BODY", mailBody);

		return oMap;
	}
}
