package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.httpclient.util.DateUtil;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KkbServisLog;
import tr.com.aktifbank.bnspr.dao.KkbServisLogId;
import tr.com.aktifbank.bnspr.dao.TelcoSorguDetay;
import tr.com.aktifbank.bnspr.dao.TelcoSorguDetayId;
import tr.com.aktifbank.bnspr.dao.TelcoSorguislem;
import tr.com.aktifbank.rm.telco.model.TELKOInquiryRequest;
import tr.com.aktifbank.rm.telco.model.TELKOInquiryResponse;
import tr.com.aktifbank.rm.telco.model.TelecomPaylasimDetayBean;
import tr.com.aktifbank.rm.telco.model.TelecomPaylasimOzetBean;
import tr.com.aktifbank.rm.telco.services.TelcoService;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlikTx;
import tr.com.calikbank.integration.core.conf.Configurator;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanQRY8008Services {

	@GraymoundService("BNSPR_QRY8008_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();

		Calendar prevYear = Calendar.getInstance();
		prevYear.add(Calendar.YEAR, -1);
		prevYear.set(Calendar.DAY_OF_MONTH, 15);

		oMap.put("BAS_TAR", DateUtil.formatDate(prevYear.getTime(), "yyyyMM"));
		oMap.put("BIT_TAR", DateUtil.formatDate(new Date(), "yyyyMM"));

		return oMap;
	}

	@GraymoundService("BNSPR_QRY8008_TELCO_SORGULA")
	public static GMMap basvurudanSorgula(GMMap iMap) {
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
		Configurator configurator = Configurator.createConfiguratorFromProperties("aktifbank-int-telco.properties");
		GMMap oMap = new GMMap();
		int kontrolGunu = 11;
		
		try {
		  kontrolGunu = Integer.parseInt(configurator.getProperty("gun"));
		} catch (Exception e) {
			kontrolGunu = 11;
		}

		BirBasvuruKimlikTx basvuru = (BirBasvuruKimlikTx) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

		List<TelcoSorguislem> islemList = session.createCriteria(TelcoSorguislem.class).add(Restrictions.eq("tckn", basvuru.getTcKimlikNo())).addOrder(Order.desc("sorguTarihi")).list();

		if (islemList != null && islemList.size() > 0) {
			Calendar cal = Calendar.getInstance();
			int gun = cal.get(Calendar.DAY_OF_MONTH);
			oMap.put("GUN", gun);
			cal.set(Calendar.DAY_OF_MONTH, kontrolGunu);
			cal.set(Calendar.HOUR_OF_DAY, 0);
			Date ortaTarih = cal.getTime();
			oMap.put("ORTA_TARIH", ortaTarih);
			cal.add(Calendar.MONTH, -1);
			Date gecenAy = cal.getTime();
			oMap.put("GECEN_AY", gecenAy);

			if ((gun < kontrolGunu && gecenAy.before(islemList.get(0).getSorguTarihi())) || (gun >= kontrolGunu && ortaTarih.before(islemList.get(0).getSorguTarihi()))) {
				oMap.put("ONCEKI_SORGU_NO", islemList.get(0).getSorguNo());
				return oMap;
			}

		}

		iMap.put("KIMLIK_TIPI_TCKN", true);
		iMap.put("KIMLIK_NO", basvuru.getTcKimlikNo());
		iMap.put("BASVURU_NO", basvuru.getBasvuruNo());

		iMap.putAll(initialize(iMap));

		GMServiceExecuter.execute("BNSPR_QRY8008_SORGULA", iMap);

		return oMap;
	}

	@GraymoundService("BNSPR_QRY8008_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			if (iMap.getString("KIMLIK_NO") == null || iMap.getString("KIMLIK_NO").isEmpty()) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Kimlik No");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (iMap.getString("BAS_TAR") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Ba�lang�� Tarihi");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (iMap.getString("BIT_TAR") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Biti� Tarihi");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			TELKOInquiryRequest request = new TELKOInquiryRequest();
			String tckn = null, vkn = null, ykn = null;
			request.setKullaniciKodu(ADCSession.getString("USER_NAME"));
			request.setSorguDonemiBaslangic(iMap.getString("BAS_TAR"));
			request.setSorguDonemiBitis(iMap.getString("BIT_TAR"));
			if (iMap.getBoolean("KIMLIK_TIPI_TCKN")) {
				request.setTckn(iMap.getString("KIMLIK_NO"));
				tckn = iMap.getString("KIMLIK_NO");
			}
			else if (iMap.getBoolean("KIMLIK_TIPI_VKN")) {
				request.setVkn(iMap.getString("KIMLIK_NO"));
				vkn = iMap.getString("KIMLIK_NO");
			}
			else if (iMap.getBoolean("KIMLIK_TIPI_YKN")) {
				request.setYkn(iMap.getString("KIMLIK_NO"));
				ykn = iMap.getString("KIMLIK_NO");
			}

			TELKOInquiryResponse response = TelcoService.telcoSorgulama(request);

			String tableName = "TELCO_TABLO";

			oMap.put(tableName, 0, "SORGU_NO", servisLog(response, request, iMap.getBigDecimal("BASVURU_NO"), tckn, vkn, ykn));

			oMap.put(tableName, 0, "KIMLIK_NO", iMap.getString("KIMLIK_NO"));
			GMMap paramMap = new GMMap();
			paramMap.put("KOD", "TELCO_ISLEM_SONUCU");
			paramMap.put("KEY", response.getIslemSonucu());

			oMap.put(tableName, 0, "SORGU_SONUCU", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap).get("TEXT"));
			oMap.put(tableName, 0, "SORGU_TARIHI", new Date());
			oMap.put(tableName, 0, "ACIKLAMA", response.getHataAciklamasi());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(new GMRuntimeException(0, e.getMessage()));
		}

		return oMap;
	}

	private static BigDecimal servisLog(TELKOInquiryResponse response, TELKOInquiryRequest request, BigDecimal basvuruNo, String tckn, String vkn, String ykn) {
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

		Date now = new Date();
		KkbServisLogId logId = new KkbServisLogId("TELCO", request.toString(), now);
		KkbServisLog log = new KkbServisLog(logId);
		if (response != null && response.toString().length() > 2000) {
			log.setOutput(response.toString().substring(0, 2000));
		}
		else if (response != null) {
			log.setOutput(response.toString());
		}

		session.save(log);

		GMMap sorguMap = new GMMap();
		sorguMap.put("TABLE_NAME", "TELCO_SORGU_ISLEM");
		BigDecimal sorguNo = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", sorguMap).getBigDecimal("ID");
		TelcoSorguislem islem = new TelcoSorguislem(sorguNo);
		islem.setBasvuruNo(basvuruNo);
		islem.setHataAciklama(response.getHataAciklamasi());
		islem.setHataKodu(response.getHataKodu());
		islem.setIslemSonucu(response.getIslemSonucu());
		islem.setSorguTarihi(now);
		islem.setTckn(tckn);
		islem.setVkn(vkn);
		islem.setYkn(ykn);

		session.save(islem);

		List<TelecomPaylasimOzetBean> list = response.getTelecomPaylasimOzetBean();

		if (list != null) {
			for (TelecomPaylasimOzetBean bean : list) {
				TelcoSorguDetay detay = new TelcoSorguDetay();
				TelcoSorguDetayId id = new TelcoSorguDetayId("0", sorguNo, bean.getDonem());
				detay.setId(id);
				detay.setFaturaSayisi(bean.getTelekomOzetFaturaSayisi());
				detay.setFaturaTl(bean.getTelekomOzetFaturaTL());
				detay.setSirketSayisi(bean.getTelekomOzetSirketSayisi());

				session.save(detay);

				int i = 1;
				for (TelecomPaylasimDetayBean detayBean : bean.getTelecomPaylasimDetayBean()) {
					detay = new TelcoSorguDetay();
					id = new TelcoSorguDetayId(Integer.toString(i), sorguNo, bean.getDonem());
					detay.setId(id);
					detay.setFaturaSayisi(detayBean.getTelekomDetayFaturaSayisi());
					detay.setFaturaTl(detayBean.getTelekomDetayFaturaTL());

					session.save(detay);
					i++;
				}
			}
		}

		session.flush();

		return sorguNo;
	}

	@GraymoundService("BNSPR_QRY8008_ONCEKI_SORGULAR")
	public static GMMap oncekiSorgular(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

		List<TelcoSorguislem> sonuc = null;

		if (iMap.getBigDecimal("BASVURU_NO") != null) {
			sonuc = session.createCriteria(TelcoSorguislem.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
		}

		if (iMap.getString("KIMLIK_NO") != null && !iMap.getString("KIMLIK_NO").isEmpty()) {
			if (iMap.getBoolean("KIMLIK_TIPI_TCKN")) {
				sonuc = session.createCriteria(TelcoSorguislem.class).add(Restrictions.eq("tckn", iMap.getString("KIMLIK_NO"))).list();
			}
			else if (iMap.getBoolean("KIMLIK_TIPI_VKN")) {
				sonuc = session.createCriteria(TelcoSorguislem.class).add(Restrictions.eq("vkn", iMap.getString("KIMLIK_NO"))).list();
			}
			else if (iMap.getBoolean("KIMLIK_TIPI_YKN")) {
				sonuc = session.createCriteria(TelcoSorguislem.class).add(Restrictions.eq("ykn", iMap.getString("KIMLIK_NO"))).list();
			}
		}
		String tableName = "TELCO_TABLO";
		int row = 0;
		for (TelcoSorguislem islem : sonuc) {

			oMap.put(tableName, row, "SORGU_NO", islem.getSorguNo());
			oMap.put(tableName, row, "SORGU_TARIHI", islem.getSorguTarihi());
			oMap.put(tableName, row, "ACIKLAMA", islem.getHataAciklama());

			GMMap paramMap = new GMMap();
			paramMap.put("KOD", "TELCO_ISLEM_SONUCU");
			paramMap.put("KEY", islem.getIslemSonucu());

			oMap.put(tableName, row, "SORGU_SONUCU", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap).get("TEXT"));
			oMap.put(tableName, row, "BASVURU_NO", islem.getBasvuruNo());

			if (islem.getTckn() != null) {
				oMap.put(tableName, row, "KIMLIK_NO", islem.getTckn());
			}
			else if (islem.getVkn() != null) {
				oMap.put(tableName, row, "KIMLIK_NO", islem.getVkn());
			}
			else if (islem.getYkn() != null) {
				oMap.put(tableName, row, "KIMLIK_NO", islem.getYkn());
			}

			row++;
		}

		return oMap;
	}

	@GraymoundService("BNSPR_QRY8008_OZET")
	public static GMMap ozet(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
		String ozetTablo = "OZET_TABLO";

		List<TelcoSorguDetay> ozetList = session.createCriteria(TelcoSorguDetay.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).add(Restrictions.eq("id.detayTur", "0")).list();

		int row = 0;

		for (TelcoSorguDetay ozet : ozetList) {
			oMap.put(ozetTablo, row, "DONEM", ozet.getId().getDonem());
			oMap.put(ozetTablo, row, "FATURA_SAYISI", ozet.getFaturaSayisi());
			oMap.put(ozetTablo, row, "FATURA_TUTARI", ozet.getFaturaTl());
			oMap.put(ozetTablo, row, "SIRKET_SAYISI", ozet.getSirketSayisi());

			row++;
		}

		return oMap;
	}

	@GraymoundService("BNSPR_QRY8008_DETAY")
	public static GMMap detay(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
		String detayTablo = "DETAY_TABLO";

		List<TelcoSorguDetay> ozetList = session.createCriteria(TelcoSorguDetay.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).add(Restrictions.ne("id.detayTur", "0")).add(Restrictions.eq("id.donem", iMap.getString("DONEM"))).list();

		int row = 0;

		for (TelcoSorguDetay ozet : ozetList) {
			oMap.put(detayTablo, row, "DONEM", ozet.getId().getDonem());
			oMap.put(detayTablo, row, "FATURA_SAYISI", ozet.getFaturaSayisi());
			oMap.put(detayTablo, row, "FATURA_TUTARI", ozet.getFaturaTl());
			oMap.put(detayTablo, row, "SIRKET_SAYISI", ozet.getSirketSayisi());
			
			GMMap paramMap = new GMMap();
			paramMap.put("KOD", "TELCO_DETAY_BILGI");
			paramMap.put("KEY", ozet.getId().getDetayTur());
			
			oMap.put(detayTablo, row, "DONEM", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap).get("TEXT"));

			row++;
		}

		return oMap;
	}

}
