package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Map;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BirTesvikOdemeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3258Services {

	@GraymoundService("BNSPR_TRN3258_FILL_BAYI_BILGI_COMBO")
	public static GMMap fillBayiBilgiCombo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3258.fill_bayi_bilgi_combo(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, "BAYI_BILGI", rSet.getString(1), rSet.getString(2));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3258_FILL_ISLEM_FIS_BILGI")
	public static GMMap fillIslemFisBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap islemFisBilgiMap = new GMMap();
		String tableName = "RESULT";
		try {
			Object[] inputValues = { BnsprType.STRING, iMap.getString("BAYI_KOD") };
			Object[] outputValues = { BnsprType.REFCURSOR, tableName };

			islemFisBilgiMap.putAll((GMMap) DALUtil.callOracleProcedure("{call PKG_TRN3258.fill_islem_fis_bilgileri(?, ?) }", inputValues, outputValues));

			for (int i = 0; i < islemFisBilgiMap.getSize(tableName); i++) {
				BigDecimal hesapNo = islemFisBilgiMap.getBigDecimal(tableName, i, "HESAP_NO");
				oMap.put("HESAP_NO", hesapNo);
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3258_FILL_TESVIK_DETAY")
	public static GMMap fillTesvikDetay(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "RESULTS";
		BigDecimal toplamHakedisTutari = BigDecimal.ZERO;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3258.get_tesvik_by_bayi_kod(?,?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BAYI_KOD"));

			if (iMap.getDate("TARIH_1") != null)
				stmt.setDate(3, new java.sql.Date(iMap.getDate("TARIH_1").getTime()));
			else
				stmt.setDate(3, null);

			if (iMap.getDate("TARIH_2") != null)
				stmt.setDate(4, new java.sql.Date(iMap.getDate("TARIH_2").getTime()));
			else
				stmt.setDate(4, null);

			if (iMap.getBoolean("KREDI_DURUM_KODU") == true)
				stmt.setString(5, "EXCEPT_KAPANDI");
			else
				stmt.setString(5, "ALL");

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			int i = 0;
			while (rSet.next()) {
				oMap.put(tableName, i, "BAYI_KODU", rSet.getBigDecimal("BAYI_KOD"));
				oMap.put(tableName, i, "BASVURU_NO", rSet.getBigDecimal("BASVURU_NO"));
				oMap.put(tableName, i, "TESVIK_TUTAR", rSet.getBigDecimal("BAYI_TUTARI"));
				oMap.put(tableName, i, "KULLANDIRIM_TUTARI", rSet.getBigDecimal("KREDI_TUTARI"));
				oMap.put(tableName, i, "KULLANDIRIM_TARIHI", rSet.getDate("ISLEM_TAR"));
				oMap.put(tableName, i, "BASVURU_DURUMU", rSet.getString("BASVURU_DURUMU"));
				oMap.put(tableName, i, "BAYI_STATUSU", rSet.getString("BAYI_STATUSU"));
				oMap.put(tableName, i, "BAGLI_BOLGE", rSet.getString("BAGLI_BOLGE"));
				toplamHakedisTutari = toplamHakedisTutari.add(rSet.getBigDecimal("BAYI_TUTARI"));
				i++;
			}
			oMap.put("TOPLAM_HAKEDIS_TUTARI", toplamHakedisTutari);
			return oMap;

		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3258_FILL_TESVIK_TAKSIT_DETAY")
	public static GMMap fillTesvikTaksitDetay(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "RESULTS";
		BigDecimal toplamHakedisTutari = BigDecimal.ZERO;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3258.get_taksit_tesvik_by_bayi_kod(?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BAYI_KOD"));

			if (iMap.getDate("TARIH_1") != null)
				stmt.setDate(3, new java.sql.Date(iMap.getDate("TARIH_1").getTime()));
			else
				stmt.setDate(3, null);

			if (iMap.getDate("TARIH_2") != null)
				stmt.setDate(4, new java.sql.Date(iMap.getDate("TARIH_2").getTime()));
			else
				stmt.setDate(4, null);

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			int i = 0;
			while (rSet.next()) {
				oMap.put(tableName, i, "BAYI_KODU", rSet.getBigDecimal("BAYI_KOD"));
				oMap.put(tableName, i, "BASVURU_NO", rSet.getBigDecimal("BASVURU_NO"));
				oMap.put(tableName, i, "TESVIK_TAKSITI", rSet.getBigDecimal("TESVIK_TAKSITI"));
				oMap.put(tableName, i, "TAKSIT_NO", rSet.getBigDecimal("TAKSIT_NO"));
				oMap.put(tableName, i, "ODEME_TARIHI", rSet.getDate("ISLEM_TAR"));
				oMap.put(tableName, i, "TAKSIT_TUTAR", rSet.getBigDecimal("TAKSIT_TUTAR"));
				oMap.put(tableName, i, "BAYI_STATUSU", rSet.getString("BAYI_STATUSU"));
				oMap.put(tableName, i, "BAGLI_BOLGE", rSet.getString("BAGLI_BOLGE"));
				toplamHakedisTutari = toplamHakedisTutari.add(rSet.getBigDecimal("TESVIK_TAKSITI"));
				i++;
			}
			oMap.put("TOPLAM_HAKEDIS_TUTARI", toplamHakedisTutari);
			return oMap;

		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3258_FILL_TESVIK_DETAY_VIEW")
	public static GMMap fillTesvikDetayView(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "RESULTS";
		BigDecimal toplamHakedisTutari = BigDecimal.ZERO;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3258.get_tesvik_view_by_bayi_kod(?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BAYI_KOD"));

			if (iMap.getDate("TARIH_1") != null)
				stmt.setDate(3, new java.sql.Date(iMap.getDate("TARIH_1").getTime()));
			else
				stmt.setDate(3, null);

			if (iMap.getDate("TARIH_2") != null)
				stmt.setDate(4, new java.sql.Date(iMap.getDate("TARIH_2").getTime()));
			else
				stmt.setDate(4, null);

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			int i = 0;
			while (rSet.next()) {
				oMap.put(tableName, i, "BAYI_KODU", rSet.getBigDecimal("BAYI_KOD"));
				oMap.put(tableName, i, "BASVURU_NO", rSet.getBigDecimal("BASVURU_NO"));
				oMap.put(tableName, i, "TESVIK_TUTAR", rSet.getBigDecimal("BAYI_TUTARI"));
				oMap.put(tableName, i, "KULLANDIRIM_TUTARI", rSet.getBigDecimal("KREDI_TUTARI"));
				oMap.put(tableName, i, "KULLANDIRIM_TARIHI", rSet.getDate("ISLEM_TAR"));
				oMap.put(tableName, i, "DURUM", rSet.getString("DURUM"));
				toplamHakedisTutari = toplamHakedisTutari.add(rSet.getBigDecimal("BAYI_TUTARI"));
				i++;
			}
			oMap.put("TOPLAM_HAKEDIS_TUTARI", toplamHakedisTutari);
			return oMap;

		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3258_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		CallableStatement stmt3 = null;
		Connection conn = null;

		try {
			conn = DALUtil.getGMConnection();

			Session session = DAOSession.getSession("BNSPRDal");

			BirTesvikOdemeTx birTesvikOdemeTx = (BirTesvikOdemeTx) session.get(BirTesvikOdemeTx.class, iMap.getBigDecimal("TRX_NO"));
			if (birTesvikOdemeTx == null)
				birTesvikOdemeTx = new BirTesvikOdemeTx();

			birTesvikOdemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birTesvikOdemeTx.setFaturaNo(iMap.getString("FATURA_NO"));
			birTesvikOdemeTx.setBayiKod(iMap.getBigDecimal("BAYI_KOD"));
			birTesvikOdemeTx.setBayiTutari(iMap.getBigDecimal("TUTAR"));
			birTesvikOdemeTx.setBayiHesap(iMap.getBigDecimal("BAYI_HESABI"));
			birTesvikOdemeTx.setTarih1(iMap.getDate("TARIH_1"));
			birTesvikOdemeTx.setTarih2(iMap.getDate("TARIH_2"));
			birTesvikOdemeTx.setTaksitliTutar(iMap.getBigDecimal("TAKSIT_TUTAR"));

			session.saveOrUpdate(birTesvikOdemeTx);
			session.flush();

			iMap.put("TRX_NAME", "3258");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt3);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3258_GET_TESVIK_ODEME_TX")
	public static GMMap getTesvikOdemeTx(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3258.get_tesvik_odeme_tx(?, ?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.registerOutParameter(2, -10);

			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(2);

			while (rSet.next()) {
				oMap.put("BAYI_KOD", rSet.getBigDecimal("BAYI_KOD"));
				oMap.put("BAYI_HESAP", rSet.getBigDecimal("BAYI_HESAP"));
				oMap.put("TARIH_1", rSet.getDate("TARIH_1"));
				oMap.put("TARIH_2", rSet.getDate("TARIH_2"));
				oMap.put("FATURA_NO", rSet.getString("FATURA_NO"));
				oMap.put("SATICI_ADI", rSet.getString("SATICI_ADI"));
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		return oMap;
	}

}
