package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Date;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.httpclient.util.DateUtil;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ClientConnectionManager;
import org.apache.http.conn.scheme.Scheme;
import org.apache.http.conn.scheme.SchemeRegistry;
import org.apache.http.conn.ssl.SSLSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.conn.BasicClientConnectionManager;
import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BkmCiroBilgi;
import tr.com.aktifbank.bnspr.dao.BkmCiroBilgiId;
import tr.com.aktifbank.bnspr.dao.BkmCiroSorguislem;
import tr.com.calikbank.integration.core.conf.Configurator;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonToken;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3939Services {
	private static final String confFile = "aktifbank-bkm-ciro.properties";
	private static Configurator configurator = null;
	private static Logger logger = Logger.getLogger(ConsumerLoanTRN3939Services.class);
	static {
		try {
			configurator = Configurator.createConfiguratorFromProperties(confFile);
		}
		catch (Exception e) {
			logger.error("kkb bkm service parameters could not be initialized...");
		}
	}

	@GraymoundService("BNSPR_TRN3939_SORGULA")
	public static GMMap sorgula(GMMap iMap) {

		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");

		try {

			if (iMap.getString("KIMLIK_NO") == null || iMap.getString("KIMLIK_NO").isEmpty()) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Kimlik No");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (iMap.getString("BAS_TAR") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Ba�lang�� Tarihi");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			if (iMap.getString("BIT_TAR") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "Biti� Tarihi");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			String ortam = configurator.getProperty("ortam");

			ClientConnectionManager ccm = new BasicClientConnectionManager();

			if ("L".equalsIgnoreCase(ortam)) {
				SSLContext ctx = SSLContext.getInstance("TLS");
				X509TrustManager tm = new X509TrustManager() {

					public void checkClientTrusted(X509Certificate[] xcs, String string) throws CertificateException {
					}

					public void checkServerTrusted(X509Certificate[] xcs, String string) throws CertificateException {
					}

					public X509Certificate[] getAcceptedIssuers() {
						return null;
					}
				};
				ctx.init(null, new TrustManager[] { tm }, null);
				SSLSocketFactory ssf = new SSLSocketFactory(ctx, SSLSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

				SchemeRegistry sr = ccm.getSchemeRegistry();
				sr.register(new Scheme("https", 443, ssf));
			}
			HttpClient client = new DefaultHttpClient(ccm);
			GMMap tokenInputMap = new GMMap();
			tokenInputMap.put("SCOPE", configurator.getProperty("scope"));
			GMMap tokenOutputMap = GMServiceExecuter.call("BNSPR_KKB_GET_TOKEN", tokenInputMap);

			String token = tokenOutputMap.getString("TOKEN");

			/** servis url bilgisi */
			String endpoint = configurator.getProperty("endpoint");
			String uyeKod = configurator.getProperty("banka.kod");

			String tckn = null;
			String vkn = null;
			String ykn = null;

			if (iMap.getBoolean("KIMLIK_TIPI_TCKN")) {
				tckn = iMap.getString("KIMLIK_NO");
			}
			else if (iMap.getBoolean("KIMLIK_TIPI_VKN")) {
				vkn = iMap.getString("KIMLIK_NO");
			}
			else if (iMap.getBoolean("KIMLIK_TIPI_YB")) {
				ykn = iMap.getString("KIMLIK_NO");
			}

			Date basTar = iMap.getDate("BAS_TAR");
			Date bitTar = iMap.getDate("BIT_TAR");

			String sorguDonemiBaslangic = DateUtil.formatDate(basTar, "yyyyMM");
			String sorguDonemiBitis = DateUtil.formatDate(bitTar, "yyyyMM");

			String kullKodu = GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_KOD", new GMMap()).getString("KULLANICI_KOD");

			String json = "{\"vkn\":\"" + (vkn == null ? "" : vkn) + "\", \"tckn\":\"" + (tckn == null ? "" : tckn) + "\", \"ykn\":\"" + (ykn == null ? "" : ykn) + "\", \"kullaniciKodu\":\"" + kullKodu + "\", \"sorguDonemiBaslangic\":\"" + sorguDonemiBaslangic + "\", \"sorguDonemiBitis\":\"" + sorguDonemiBitis + "\",\"uyeKodu\":\"" + uyeKod + "\"}";

			oMap.put("JSON", json);
			
			HttpPost post = new HttpPost(endpoint);
			post.setHeader("Authorization", "Bearer " + token);
			StringEntity input = new StringEntity(json);
			input.setContentType("application/json");
			post.setEntity(input);

			HttpResponse response = client.execute(post);

			if (response.getStatusLine().getStatusCode() != 200) {
				if (response.getStatusLine().getStatusCode() == 401) {
					post.releaseConnection();
					oMap = GMServiceExecuter.call("BNSPR_KKB_GET_TOKEN", iMap);
					token = oMap.getString("TOKEN");
					post = new HttpPost(endpoint);
					post.setHeader("Authorization", "Bearer " + token);
					input = new StringEntity(json);
					input.setContentType("application/json");
					post.setEntity(input);
					response = client.execute(post);
					if (response.getStatusLine().getStatusCode() != 200) {
						throw new RuntimeException("BKM Ciro Servis Hatas� : " + response.getStatusLine().getStatusCode());
					}
				}
				else {
					throw new RuntimeException("BKM Ciro Servis Hatas� : " + response.getStatusLine().getStatusCode());
				}
			}
			BufferedReader br = new BufferedReader(new InputStreamReader(response.getEntity().getContent()));
			String content = br.readLine();
			oMap.put("CONTENT", content);

			JsonFactory factory = new JsonFactory();
			JsonParser parser = factory.createParser(content);

			BkmCiroSorguislem islem = new BkmCiroSorguislem();

			while (!parser.isClosed()) {
				JsonToken jsonToken = parser.nextToken();

				if (JsonToken.FIELD_NAME.equals(jsonToken)) {
					String fieldName = parser.getCurrentName();
					jsonToken = parser.nextToken();

					if ("sorguRefNo".equals(fieldName)) {
						islem.setSorguRefNo(parser.getValueAsString());
					}
					else if ("islemSonucu".equals(fieldName)) {
						islem.setIslemSonucu(parser.getValueAsString());
					}
					else if ("hataAciklama".equals(fieldName)) {
						islem.setHataAciklama(parser.getValueAsString());
					}
				}
			}
			
			if (islem != null && islem.getSorguRefNo() != null && !islem.getSorguRefNo().isEmpty()) {
				islem.setInput(json);
				islem.setOutput(content.substring(1000));
				session.save(islem);
				session.flush();
			}

			parser = factory.createParser(content);
			ObjectMapper mapper = new ObjectMapper();
			JsonNode node = mapper.readTree(parser);
			JsonNode ciroListesi = node.get("ciroListesi");

			int i = 0;
			String tableName = "CIRO_TABLO";
			for (JsonNode element : ciroListesi) {
				BkmCiroBilgiId id = new BkmCiroBilgiId();
				id.setSorguRefNo(islem.getSorguRefNo());
				if (element.get("donem") != null) {
					id.setDonem(element.get("donem").textValue());
					oMap.put(tableName, i, "DONEM", id.getDonem());
				}

				BkmCiroBilgi bilgi = new BkmCiroBilgi(id);

				if (element.get("vkn") != null) {
					bilgi.setVkn(element.get("vkn").textValue());
				}

				if (element.get("tckn") != null) {
					bilgi.setTckn(element.get("tckn").textValue());
				}

				if (element.get("ykn") != null) {
					bilgi.setYkn(element.get("ykn").textValue());
				}

				if (element.get("isyeriCiroTutari") != null) {
					bilgi.setIsyeriCiroTutari(element.get("isyeriCiroTutari").textValue());
					oMap.put(tableName, i, "ISYERI_CIRO_TUTARI", bilgi.getIsyeriCiroTutari());
				}

				if (element.get("kaynakBankaSayisi") != null) {
					bilgi.setKaynakBankaSayisi(element.get("kaynakBankaSayisi").textValue());
					oMap.put(tableName, i, "KAYNAK_BANKA_SAYISI", bilgi.getKaynakBankaSayisi());
				}

				session.save(bilgi);
				i++;

			}
			
			if ("2".equals(islem.getIslemSonucu()) || "3".equals(islem.getIslemSonucu()) || "4".equals(islem.getIslemSonucu())) {
				throw new GMRuntimeException(0, islem.getHataAciklama());
			}

		}
		catch (Exception e) {
			logger.error("Bkm Ciro sorgusu s�ras�nda hata : " + e);
			throw new GMRuntimeException(0, e);
		}
		return oMap;
	}

}
