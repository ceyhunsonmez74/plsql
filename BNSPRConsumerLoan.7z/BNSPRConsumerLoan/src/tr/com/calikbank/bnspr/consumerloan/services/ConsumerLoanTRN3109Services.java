package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirFaizOranPrTx;
import tr.com.calikbank.bnspr.dao.BirFaizOranPrTxId;
import tr.com.calikbank.bnspr.dao.VBirFaizOran;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3109Services {
	@GraymoundService("BNSPR_TRN3109_GET_FAIZ_ORAN_PR")
	public static GMMap getKrdAltTur(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(VBirFaizOran.class).add(Restrictions.and(Restrictions.and(Restrictions.eq("krdTurKod", iMap.getBigDecimal("KRD_TUR_KOD")), Restrictions.eq("krdTurAltKod", iMap.getBigDecimal("KRD_ALT_TUR_KOD"))), Restrictions.eq("krdTurAltKod2", iMap.getBigDecimal("KRD_ALT_TUR_KOD_2")))).addOrder(Order.asc("kanalKod")).addOrder(Order.asc("dovizKod")).addOrder(Order.asc("minVade")).addOrder(Order.asc("maxVade")).addOrder(Order.asc("minTutar")).addOrder(Order.asc("maxTutar")).list();

			GMMap oMap = new GMMap();
			String tableName = "FAIZ_ORAN_PR";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				VBirFaizOran vBirFaizOran = (VBirFaizOran) iterator.next();

				oMap.put(tableName, row, "FAIZ_ORAN_ID", vBirFaizOran.getId().getFaizOranId());
				oMap.put(tableName, row, "BAZ_FAIZ_ORAN_ID", vBirFaizOran.getId().getBazFaizOranId());
				oMap.put(tableName, row, "KANAL_KODU", vBirFaizOran.getKanalKod());
				oMap.put(tableName, row, "DOVIZ_CINSI", vBirFaizOran.getDovizKod());
				
				iMap.put("KRD_TUR_ALT_KOD",iMap.getBigDecimal("KRD_ALT_TUR_KOD"));
				iMap.put("KRD_TUR_ALT_KOD2",iMap.getBigDecimal("KRD_ALT_TUR_KOD_2"));
				iMap.put("KANAL_KOD",vBirFaizOran.getKanalKod());
				iMap.put("DOVIZ_KOD",vBirFaizOran.getDovizKod());	
				
				oMap.put(tableName, row, "DI_KANAL_KODU", GMServiceExecuter.execute("BNSPR_TRN3109_GET_KANAL_ADI", iMap).get("KANAL_ADI"));
				
				oMap.put(tableName, row, "MIN_VADE", vBirFaizOran.getMinVade());
				oMap.put(tableName, row, "MAX_VADE", vBirFaizOran.getMaxVade());
				oMap.put(tableName, row, "MIN_TUTAR", vBirFaizOran.getMinTutar());
				oMap.put(tableName, row, "MAX_TUTAR", vBirFaizOran.getMaxTutar());
				oMap.put(tableName, row, "FAIZ_ORANI", vBirFaizOran.getFaizOran());
				
				oMap.put(tableName, row, "DOSYA_MASRAF_TIP", vBirFaizOran.getDosMasrafTip());
				oMap.put(tableName, row, "DOSYA_MASRAFI", vBirFaizOran.getDosMasrafOran());
				oMap.put(tableName, row, "MIN_DOSYA_MASRAFI", vBirFaizOran.getMinDosMasraf());
				oMap.put(tableName, row, "MAX_DOSYA_MASRAFI", vBirFaizOran.getMaxDosMasraf());

				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3109_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "FAIZ_ORAN_PR";
			List<?> list = (List<?>) iMap.get(tableName);
			for (int i = 0; i<list.size(); i++) {
				BirFaizOranPrTx birFaizOranPrTx = new BirFaizOranPrTx();
				BirFaizOranPrTxId birFaizOranPrTxId = new BirFaizOranPrTxId();

				birFaizOranPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birFaizOranPrTxId.setId(iMap.getBigDecimal(tableName, i, "FAIZ_ORAN_ID"));

				birFaizOranPrTx.setId(birFaizOranPrTxId);
				birFaizOranPrTx.setFaizOran(iMap.getBigDecimal(tableName, i, "FAIZ_ORANI"));
				birFaizOranPrTx.setKanalKod(iMap.getString(tableName, i, "KANAL_KODU"));
				birFaizOranPrTx.setDovizKod(iMap.getString(tableName, i, "DOVIZ_CINSI"));
				
				birFaizOranPrTx.setDosMasrafOran(iMap.getBigDecimal(tableName, i, "DOSYA_MASRAFI"));
				birFaizOranPrTx.setMinDosMasraf(iMap.getBigDecimal(tableName, i, "MIN_DOSYA_MASRAFI"));
				birFaizOranPrTx.setMaxDosMasraf(iMap.getBigDecimal(tableName, i, "MAX_DOSYA_MASRAFI"));
				birFaizOranPrTx.setDosMasrafTip(iMap.getString(tableName, i, "DOSYA_MASRAF_TIP"));
				birFaizOranPrTx.setBazFaizOranId(iMap.getBigDecimal(tableName, i, "BAZ_FAIZ_ORAN_ID"));
				
				session.save(birFaizOranPrTx);
			}
			session.flush();
			iMap.put("TRX_NAME", "3109");
			/*Map<?, ?> oMap = GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			Map<?, ?> myMap = GMServiceExecuter.execute("BNSPR_KREDI_FAIZ_ORAN_TO_TURKLINE", iMap);

			if(myMap.get("RESULT").equals("HATA")){
				throw new GMRuntimeException(0, "TurkLine Aktar�mda hata al�nd�");
			}
			return oMap;*/
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3109_GET_DOVIZ_KODLARI")
	public static GMMap getDovizKodlari(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select distinct b.doviz_kod as doviz_kodu,b.doviz_kod as doviz_kodu2 from bir_krd_tur_knl b where b.krd_tur_kod = ? and b.krd_tur_alt_kod = ? order by 1");

			stmt.setBigDecimal(1, iMap.getBigDecimal("KRD_TUR_KOD"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("KRD_ALT_TUR_KOD"));

			rSet = stmt.executeQuery();
			oMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("LIST_NAME", "DOVIZ_KODLARI");
			DALUtil.fillComboBox(oMap, rSet);
			
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3109_GET_KANAL_KODLARI")
	public static GMMap getKanalKodlari(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "H");
		iMap.put("LIST_NAME", "KANAL_KODLARI");
		iMap.put("LIST_QUERY", "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr order by to_number(kod)");
		DALUtil.fillComboBox(iMap);
		return iMap;
	}

	@GraymoundService("BNSPR_TRN3109_GET_FAIZ_ORAN_PR_WITH_TX_NO")
	public static GMMap getKrdAltTurWithTxNo(GMMap iMap) {
		BigDecimal krdTurKod = null;
		BigDecimal krdAltTurKod = null;
		BigDecimal krdAltTurKod2 = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(BirFaizOranPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			GMMap oMap = new GMMap();
			String tableName = "FAIZ_ORAN_PR";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();row++) {
				BirFaizOranPrTx birFaizOranPrTx = (BirFaizOranPrTx) iterator.next();

				oMap.put(tableName, row, "BAZ_FAIZ_ORAN_ID", birFaizOranPrTx.getBazFaizOranId());
				oMap.put(tableName, row, "KANAL_KODU", birFaizOranPrTx.getKanalKod());
				oMap.put(tableName, row, "DOVIZ_CINSI", birFaizOranPrTx.getDovizKod());
				Connection conn = null;
				PreparedStatement stmt = null;
				ResultSet rSet = null;
				try {
					conn = DALUtil.getGMConnection();
					stmt = conn.prepareStatement("select v.krd_tur_kod,v.krd_tur_alt_kod,v.krd_tur_alt_kod2,v.min_vade,v.max_vade,v.min_tutar,v.max_tutar from v_bir_faiz_oran v,bir_faiz_oran_pr_tx b where b.id = v.faiz_oran_id and b.tx_no = ? and b.id = ?");
					stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));

					stmt.setBigDecimal(2, birFaizOranPrTx.getId().getId());
					rSet = stmt.executeQuery();
					if (rSet.next()) {
						krdTurKod = rSet.getBigDecimal("krd_tur_kod");
						krdAltTurKod = rSet.getBigDecimal("krd_tur_alt_kod");
						krdAltTurKod2 = rSet.getBigDecimal("krd_tur_alt_kod2");
						oMap.put(tableName, row, "MIN_VADE", rSet.getBigDecimal("min_vade"));
						oMap.put(tableName, row, "MAX_VADE", rSet.getBigDecimal("max_vade"));
						oMap.put(tableName, row, "MIN_TUTAR", rSet.getBigDecimal("min_tutar"));
						oMap.put(tableName, row, "MAX_TUTAR", rSet.getBigDecimal("max_tutar"));
					}
				} catch (Exception e) {
					throw ExceptionHandler.convertException(e);
				} finally {
					GMServerDatasource.close(stmt);
					GMServerDatasource.close(conn);
					GMServerDatasource.close(rSet);
				}
				oMap.put(tableName, row, "FAIZ_ORANI", birFaizOranPrTx.getFaizOran());
				
				iMap.put("KRD_TUR_KOD",krdTurKod);
				iMap.put("KRD_TUR_ALT_KOD",krdAltTurKod);
				iMap.put("KRD_TUR_ALT_KOD2",krdAltTurKod2);
				iMap.put("KANAL_KOD",birFaizOranPrTx.getKanalKod());
				iMap.put("DOVIZ_KOD",birFaizOranPrTx.getDovizKod());	
				
				oMap.put(tableName, row, "DI_KANAL_KODU", GMServiceExecuter.execute("BNSPR_TRN3109_GET_KANAL_ADI", iMap).get("KANAL_ADI"));
				
				oMap.put(tableName, row, "DOSYA_MASRAF_TIP", birFaizOranPrTx.getDosMasrafTip());
				oMap.put(tableName, row, "DOSYA_MASRAFI", birFaizOranPrTx.getDosMasrafOran());
				oMap.put(tableName, row, "MIN_DOSYA_MASRAFI", birFaizOranPrTx.getMinDosMasraf());
				oMap.put(tableName, row, "MAX_DOSYA_MASRAFI", birFaizOranPrTx.getMaxDosMasraf());
			}
			oMap.put("KRD_TUR_KOD", krdTurKod);
			oMap.put("KRD_ALT_TUR_KOD", krdAltTurKod);
			oMap.put("KRD_ALT_TUR_KOD_2", krdAltTurKod2);
			oMap.put("KREDI_TURU_ACIKLAMA", LovHelper.diLov(krdTurKod, "3109/LOV_KREDI_TURU", "ACIKLAMA"));
			oMap.put("KREDI_TIPI_ACIKLAMA", LovHelper.diLov(krdAltTurKod, krdTurKod, "3109/LOV_KREDI_TIPI", "ACIKLAMA"));
			oMap.put("ALT_KREDI_TIPI_ACIKLAMA", LovHelper.diLov(krdAltTurKod2, krdTurKod, krdAltTurKod, "3109/LOV_ALT_KREDI_TIP", "ACIKLAMA"));

			iMap.put("KRD_TUR_KOD", krdTurKod);
			iMap.put("KRD_ALT_TUR_KOD", krdAltTurKod);
			oMap.putAll(getDovizKodlari(iMap));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3109_NOT_NULL_SECIM_KRITERLERI")
	public static GMMap notNullSecimKriterTRN3109(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			if ((iMap.getBigDecimal("KREDI_TURU") == null) || (iMap.getBigDecimal("KREDI_TIPI") == null) || (iMap.getBigDecimal("ALT_KREDI_TIPI") == null)) {
				stmt = conn.prepareCall("{call pkg_hata.hata_yaz(758,true,'Kredi T�r�, Kredi Tipini ve Alt Kredi Tipini','Listele')}");
				stmt.execute();
			}

			return new GMMap();

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3109_GET_KANAL_ADI")
	public static GMMap getKanalAdi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_bireysel.KanaldakiAd(?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("KRD_TUR_KOD"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
			stmt.setString(5, iMap.getString("KANAL_KOD"));
			stmt.setString(6, iMap.getString("DOVIZ_KOD"));			

			stmt.execute();

			GMMap oMap = new GMMap();

			oMap.put("KANAL_ADI", stmt.getString(1));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN3109_AFTER_APROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		try {
			GMServiceExecuter.execute("BNSPR_KREDI_FAIZ_ORAN_TO_TURKLINE", new GMMap());
			GMServiceExecuter.execute("BNSPR_DELETE_TURKLINE_KREDI_DATA", new GMMap());
			GMServiceExecuter.execute("BNSPR_SET_TURKLINE_KREDITUR_DATA", new GMMap());
			GMServiceExecuter.execute("BNSPR_SET_TURKLINE_KREDI_DATA", new GMMap());
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
