package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirSaticiSicilAksiyonTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiSicilAksiyonTxId;
import tr.com.aktifbank.bnspr.dao.BirSaticiSicilDurumTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiSicilDurumTxId;
import tr.com.aktifbank.bnspr.dao.BirSaticiSicilSaticilarTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiSicilSaticilarTxId;
import tr.com.aktifbank.bnspr.dao.BirSaticiSicilTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiTahsisTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsis;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3264Services {

	@GraymoundService("BNSPR_TRN3264_GET_GUNCELLEME_YETKI")
	public static GMMap getGuncellemeYetki(GMMap iMap) {
		GMMap oMap = new GMMap();
		Object[] inputValues;
		String func;
		try {

			func = "{? = call pkg_global.get_kullanicikod}";
			iMap.put("KULLANICI_KOD", DALUtil.callOracleFunction(func, BnsprType.STRING, new Object[0]));

			inputValues = new Object[] {
				BnsprType.STRING, iMap.getString("KULLANICI_KOD")
			};
			
			func = "{? = call pkg_trn3264.sicil_guncelleme_yetki(?)}";

			oMap.put("GUNCELLEME_YETKI", "E".equals(DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues)));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}

	@GraymoundService("BNSPR_TRN3264_GET_SICIL_DEGISTIRILEBILIR_MI")
	public static GMMap getSicilDegistirilebilirMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Object[] inputValues;
		String func;
		try {
			if (StringUtils.isNotBlank(iMap.getString("ISLEM_NO"))) {
				inputValues = new Object[]{
					BnsprType.STRING, iMap.getString("ISLEM_NO")	
				};
		
				func = "{? = call pkg_trn3264.sicil_guncellenebilir_eh (?)}";

				oMap.put("GUNCELLENEBILIR_MI", "E".equals(DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues)));

				func = "{? = call pkg_trn3264.sicil_silinebilir_eh (?)}";

				oMap.put("SILINEBILIR_MI", "E".equals(DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues)));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}

	@GraymoundService("BNSPR_TRN3264_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap bilgiFillComboBoxInitialValues(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("SELECT KEY1, TEXT, KEY3 FROM V_ML_GNL_PARAM_TEXT WHERE KOD = ? ORDER BY SIRA_NO");
			stmt.setString(1, "BAYI_SICIL_TESPIT");

			rSet = stmt.executeQuery();
			oMap.put("TESPIT", 0, "NAME", " ");
			oMap.put("TESPIT", 0, "VALUE", (String) null);
			oMap.put("TESPIT", 0, "KEY3", (String) null);

			int i = 1;
			while (rSet.next()) {
				oMap.put("TESPIT", i, "VALUE", rSet.getString(1));
				oMap.put("TESPIT", i, "NAME", rSet.getString(2));
				oMap.put("TESPIT", i, "KEY3", rSet.getString(3));
				i++;
			}

			iMap.put("KOD", "BAYI_SICIL_KAYIT_TIP");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("KAYIT_TIP", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "BAYI_SICIL_TESPIT_KAYNAK");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("TESPIT_KAYNAK", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "BAYI_SICIL_TESPIT_KISI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("TESPIT_KISI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "BAYI_RISK_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("BAYI_RISK", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "BAYI_STATU_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("BAYI_STATU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "KISMI_KAPANMA_NEDEN_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("KISMI_KAPANMA_NEDEN", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "KAPANMA_NEDEN_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("KAPANMA_NEDEN", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "ONEM_DERECE_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("ONEM_DERECE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "BAYI_KATEGORI_SKOR");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("KATEGORI_SKOR_TAHSIS", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "BAYI_SICIL_DURUM");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("SICIL_DURUM_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "BAYI_SICIL_AKSIYON");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("SICIL_AKSIYON_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "BAYI_STATU_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("BAYI_STATU_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			iMap.put("KOD", "SATICI_TIP_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("SATICI_TIP_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
           
			iMap.put("ADD_EMPTY_KEY", "E");
	        iMap.put("KOD", "BAYI_KAZANIM_KANAL");
	        oMap.put("DST_KAZANIM_KANAL", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("KOD", "AKTIF_PASIF");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("AKTIF_PASIF", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3264_GET_TESPIT_COMBO_DATA")
	public static GMMap getTespitComboData(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("SELECT KEY1, TEXT, KEY3 FROM V_ML_GNL_PARAM_TEXT WHERE KOD = ? AND KEY2 = ? ORDER BY SIRA_NO");
			stmt.setString(1, "BAYI_SICIL_TESPIT");
			stmt.setString(2, iMap.getString("KEY2"));

			rSet = stmt.executeQuery();
			oMap.put("TESPIT", 0, "NAME", " ");
			oMap.put("TESPIT", 0, "VALUE", (String) null);
			oMap.put("TESPIT", 0, "KEY3", (String) null);

			int i = 1;
			while (rSet.next()) {
				oMap.put("TESPIT", i, "VALUE", rSet.getString(1));
				oMap.put("TESPIT", i, "NAME", rSet.getString(2));
				oMap.put("TESPIT", i, "KEY3", rSet.getString(3));
				i++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3264_BAYI_SICIL_SORGULA")
	public static GMMap getSicilBilgileri(GMMap iMap) {
		GMMap oMap;
		Object[] inputValues;
		String func;

		try {
			func = "{? = call pkg_trn3264.bayi_sicil_sorgula(?,?,?,?,?,?,?,?,?,?,?)}";

			inputValues = new Object[] { 
				BnsprType.NUMBER, iMap.getBigDecimal("SATICI_KOD"), 
				BnsprType.STRING, iMap.getString("TESPIT"),
				BnsprType.DATE, iMap.getDate("TAKIP_BAS"), 
				BnsprType.DATE, iMap.getDate("TAKIP_BIT"), 
				BnsprType.DATE, iMap.getDate("TESPIT_BAS"),
				BnsprType.DATE, iMap.getDate("TESPIT_BIT"), 
				BnsprType.NUMBER, iMap.getBigDecimal("BATCH_SORGU_NO"), 
				BnsprType.NUMBER, iMap.getBigDecimal("BATCH_DETAY_NO"),
				BnsprType.STRING, iMap.getString("BAYI_STATU_KOD"),
				BnsprType.STRING, iMap.getString("BAYI_KAZANIM_KANAL"),
				BnsprType.STRING, iMap.getString("KAYIT_DURUM")
		    };

			oMap = DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}

	@GraymoundService("BNSPR_TRN3264_BAYI_SICIL_DETAY")
	public static GMMap getSicilDetay(GMMap iMap) {
		GMMap oMap = new GMMap();
		Object[] inputValues;
		Object[] outputValues;
		String func;		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			func = "{? = call pkg_trn3264.sicil_bilgileri(?,?)}";
			inputValues = new Object[] {
			  	BnsprType.NUMBER,iMap.getBigDecimal("ISLEM_NO"),
			  	BnsprType.NUMBER,iMap.getBigDecimal("TRX_NO")
			};			
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues));
			oMap.put("DURUM", oMap.getString("RESULTS", 0, "DURUM"));
			oMap.put("KOD", oMap.getString("RESULTS", 0, "SATICI_KOD"));
			oMap.put("KAYIT_TIP_KOD", oMap.getString("RESULTS", 0, "KAYIT_TIP_KOD"));
			oMap.put("TESPIT_KOD", oMap.getString("RESULTS", 0, "TESPIT_KOD"));
			oMap.put("TESPIT_KAYNAK_KOD", oMap.getString("RESULTS", 0, "TESPIT_KAYNAK_KOD"));
			oMap.put("RISK_DERECESI_KOD", oMap.getString("RESULTS", 0, "RISK_DERECESI_KOD"));
			oMap.put("TESPIT_TARIH", oMap.getDate("RESULTS", 0, "TESPIT_TARIH"));
			oMap.put("TAKIP_TARIH", oMap.getDate("RESULTS", 0, "TAKIP_TARIH"));
			oMap.put("TAKIP_TAMAM_EH", StringUtils.isNotBlank(oMap.getString("RESULTS", 0, "TAKIP_TAMAM_EH")) && "E".equals(oMap.getString("RESULTS", 0, "TAKIP_TAMAM_EH")));
			oMap.put("TESPIT_KISI_KOD", oMap.getString("RESULTS", 0, "TESPIT_KISI_KOD"));
			oMap.put("BASVURU_NO", oMap.getBigDecimal("RESULTS", 0, "BASVURU_NO"));
			oMap.put("BAYI_RISK_KOD", oMap.getString("RESULTS", 0, "BAYI_RISK_KOD"));
			oMap.put("EX_BAYI_RISK_KOD", oMap.getString("RESULTS", 0, "EX_BAYI_RISK_KOD"));
			oMap.put("BAYI_STATU_KOD", oMap.getString("RESULTS", 0, "BAYI_STATU_KOD"));
			oMap.put("EX_BAYI_STATU_KOD", oMap.getString("RESULTS", 0, "EX_BAYI_STATU_KOD"));
			oMap.put("KISMI_KAPANMA_NEDEN_KOD", oMap.getString("RESULTS", 0, "KISMI_KAPANMA_NEDEN_KOD"));
			oMap.put("KAPANMA_NEDEN_KOD", oMap.getString("RESULTS", 0, "KAPANMA_NEDEN_KOD"));
			oMap.put("EX_ONEM_DERECE_KOD", oMap.getString("RESULTS", 0, "EX_ONEM_DERECE_KOD"));
			oMap.put("ONEM_DERECE_KOD", oMap.getString("RESULTS", 0, "ONEM_DERECE_KOD"));
			oMap.put("KATEGORI_SKOR_TAHSIS_KOD", oMap.getString("RESULTS", 0, "KATEGORI_SKOR_TAHSIS_KOD"));
			oMap.put("EX_KATEGORI_SKOR_TAHSIS_KOD", oMap.getString("RESULTS", 0, "EX_KATEGORI_SKOR_TAHSIS_KOD"));
			oMap.put("ACIKLAMA", oMap.getString("RESULTS", 0, "ACIKLAMA"));
			oMap.put("KULL_ACIKLAMA", oMap.getString("RESULTS", 0, "KULL_ACIKLAMA"));
			oMap.put("ISLEM_NO", oMap.getString("RESULTS", 0, "ISLEM_NO"));
			oMap.put("REC_DATE", oMap.getString("RESULTS", 0, "REC_DATE"));
			oMap.put("REC_OWNER", oMap.getString("RESULTS", 0, "REC_OWNER"));
			oMap.put("ILISKILI_ISLEM",oMap.getString("RESULTS",0,"ILISKILI_ISLEM"));

			func = "{? = call pkg_trn3264.sicil_durum_listesi(?,?)}";
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "SICIL_DURUM_TABLE", inputValues));

			func = "{? = call pkg_trn3264.sicil_aksiyon_listesi(?,?)}";
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "SICIL_AKSIYON_TABLE", inputValues));

			func = "{? = call pkg_trn3264.iliskili_bayi_list(?,?)}";
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "BAGLI_BAYI_TABLE", inputValues));

			func = "{? = call pkg_satici_otosicil.sicil_sorguya_bagli_eh(?)}";
			oMap.put("SORGU_IZLENSIN_MI", "E".equals((String) DALUtil.callOneParameterFunction(func, Types.VARCHAR, iMap.getBigDecimal("ISLEM_NO"))));
			
			
			func = "{ call pkg_trn3264.son_guncelleme_bilgisi(?,?,?,?)}";
			inputValues = new Object[]{BnsprType.NUMBER,iMap.getBigDecimal("ISLEM_NO")};
			outputValues = new Object[]{BnsprType.NUMBER,"UPD_TRX_NO",
					                    BnsprType.DATE,"UPD_DATE",
					                    BnsprType.STRING,"UPD_USER"};					
			oMap.putAll((GMMap)DALUtil.callOracleProcedure(func, inputValues, outputValues));

			func = "{ call pkg_trn3264.sicil_pasif_bilgisi(?,?,?,?)}";
			inputValues = new Object[]{BnsprType.NUMBER,iMap.getBigDecimal("ISLEM_NO")};
			outputValues = new Object[]{BnsprType.NUMBER,"PSF_TRX_NO",
					                    BnsprType.DATE,"PSF_DATE",
					                    BnsprType.STRING,"PSF_USER"};					
			oMap.putAll((GMMap)DALUtil.callOracleProcedure(func, inputValues, outputValues));
			
			BirSaticiTahsis birSaticiTahsis = (BirSaticiTahsis) session.createCriteria(BirSaticiTahsis.class).add(Restrictions.eq("kod", oMap.getBigDecimal("KOD"))).uniqueResult();
			if(birSaticiTahsis != null) {
				oMap.put("DST_KAZANIM_KANAL", birSaticiTahsis.getDstKazanimKanal()); 
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}

	@GraymoundService("BNSPR_TRN3264_GET_INFO_FOR_NEW_RECORD")
	public static GMMap getInfoForNewRecord(GMMap iMap) {
		GMMap oMap = new GMMap();
		Object[] inputValues;
		Object[] outputValues;
		String proc;
		String func;

		try {
			proc = "{call pkg_trn3264.bayi_statu_bilgileri(?,?,?,?,?,?,?)}";
			
			inputValues = new Object[]{
				BnsprType.NUMBER, iMap.getBigDecimal("SATICI_KOD")	
			};			
			outputValues = new Object[]{
				BnsprType.STRING, "BAYI_RISK_KOD",
				BnsprType.STRING, "BAYI_STATU_KOD",
				BnsprType.STRING, "KISMI_KAPANMA_NEDEN_KOD",
				BnsprType.STRING, "KAPANMA_NEDEN_KOD",
				BnsprType.STRING, "ONEM_DERECE_KOD",
				BnsprType.STRING, "KATEGORI_SKOR_TAHSIS_KOD"						
			};
			oMap.putAll((GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues));
			
			func = "{? = call pkg_trn3264.get_bagli_bayi_list(?)}";

			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "BAGLI_BAYI_TABLE", inputValues));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}

	@GraymoundService("BNSPR_TRN3264_SAVE")
	public static GMMap save3264(GMMap iMap) {
		String tableName;
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			// Temizle

			List<?> birSaticiSicilDurumTxList = session.createCriteria(BirSaticiSicilDurumTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : birSaticiSicilDurumTxList) {
				BirSaticiSicilDurumTx birSaticiSicilDurumTx = (BirSaticiSicilDurumTx) name;
				session.delete(birSaticiSicilDurumTx);
			}
			session.flush();

			List<?> birSaticiSicilAksiyonTxList = session.createCriteria(BirSaticiSicilAksiyonTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : birSaticiSicilAksiyonTxList) {
				BirSaticiSicilAksiyonTx BirSaticiSicilAksiyonTx = (BirSaticiSicilAksiyonTx) name;
				session.delete(BirSaticiSicilAksiyonTx);
			}
			session.flush();

			List<?> birSaticiSicilSaticilarTxList = session.createCriteria(BirSaticiSicilSaticilarTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : birSaticiSicilSaticilarTxList) {
				BirSaticiSicilSaticilarTx BirSaticiSicilSaticilarTx = (BirSaticiSicilSaticilarTx) name;
				session.delete(BirSaticiSicilSaticilarTx);
			}
			session.flush();

			// yaz

			birSaticiSicilDurumTxList = (List<?>) iMap.get("DURUM_TABLE");
			tableName = "DURUM_TABLE";

			for (int i = 0; i < birSaticiSicilDurumTxList.size(); i++) {
				BirSaticiSicilDurumTx birSaticiSicilDurumTx = new BirSaticiSicilDurumTx();
				BirSaticiSicilDurumTxId birSaticiSicilDurumTxId = new BirSaticiSicilDurumTxId();

				birSaticiSicilDurumTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birSaticiSicilDurumTxId.setIslemNo(iMap.getBigDecimal("ISLEM_NO"));
				birSaticiSicilDurumTxId.setSicilDurumKod(iMap.getString(tableName, i, "SICIL_DURUM_KOD"));
				birSaticiSicilDurumTx.setId(birSaticiSicilDurumTxId);
				session.saveOrUpdate(birSaticiSicilDurumTx);
			}
			session.flush();

			birSaticiSicilAksiyonTxList = (List<?>) iMap.get("AKSIYON_TABLE");
			tableName = "AKSIYON_TABLE";

			for (int i = 0; i < birSaticiSicilAksiyonTxList.size(); i++) {
				BirSaticiSicilAksiyonTx birSaticiSicilAksiyonTx = new BirSaticiSicilAksiyonTx();
				BirSaticiSicilAksiyonTxId birSaticiSicilAksiyonTxId = new BirSaticiSicilAksiyonTxId();

				birSaticiSicilAksiyonTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birSaticiSicilAksiyonTxId.setIslemNo(iMap.getBigDecimal("ISLEM_NO"));
				birSaticiSicilAksiyonTxId.setSicilAksiyonKod(iMap.getString(tableName, i, "SICIL_AKSIYON_KOD"));
				birSaticiSicilAksiyonTx.setId(birSaticiSicilAksiyonTxId);
				session.saveOrUpdate(birSaticiSicilAksiyonTx);
			}
			session.flush();
			birSaticiSicilSaticilarTxList = (List<?>) iMap.get("SATICILAR_TABLE");
			tableName = "SATICILAR_TABLE";

			for (int i = 0; i < birSaticiSicilSaticilarTxList.size(); i++) {
				BirSaticiSicilSaticilarTx birSaticiSicilSaticilarTx = new BirSaticiSicilSaticilarTx();
				BirSaticiSicilSaticilarTxId birSaticiSicilSaticilarTxId = new BirSaticiSicilSaticilarTxId();

				birSaticiSicilSaticilarTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birSaticiSicilSaticilarTxId.setIliskiliSaticiKod(iMap.getBigDecimal(tableName, i, "ILISKILI_SATICI_KOD"));
				birSaticiSicilSaticilarTxId.setIslemNo(iMap.getBigDecimal("ISLEM_NO"));
				birSaticiSicilSaticilarTx.setId(birSaticiSicilSaticilarTxId);
				birSaticiSicilSaticilarTx.setAktiflikBasvuruKod(iMap.getString(tableName, i, "AKTIFLIK_BASVURU_KOD"));
				birSaticiSicilSaticilarTx.setAktiflikKullandirimKod(iMap.getString(tableName, i, "AKTIFLIK_KULLANDIRIM_KOD"));
				birSaticiSicilSaticilarTx.setBayiStatuKod(iMap.getString(tableName, i, "BAYI_STATU_KOD"));
				birSaticiSicilSaticilarTx.setGuncelleEh(iMap.getBoolean(tableName, i, "GUNCELLE_EH") ? "E" : "H");
				birSaticiSicilSaticilarTx.setSaticiTipKod(iMap.getString(tableName, i, "SATICI_TIP_KOD"));

				session.saveOrUpdate(birSaticiSicilSaticilarTx);
			}
			session.flush();

			BirSaticiSicilTx birSaticiSicilTx = (BirSaticiSicilTx) session.createCriteria(BirSaticiSicilTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

			if (birSaticiSicilTx == null) {
				birSaticiSicilTx = new BirSaticiSicilTx();
			}
			birSaticiSicilTx.setAciklama(iMap.getString("ACIKLAMA"));
			birSaticiSicilTx.setKullAciklama(iMap.getString("KULL_ACIKLAMA"));
			birSaticiSicilTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birSaticiSicilTx.setBayiRiskKod(iMap.getString("BAYI_RISK_KOD"));
			birSaticiSicilTx.setBayiStatuKod(iMap.getString("BAYI_STATU_KOD"));

			if (StringUtils.isBlank(iMap.getString("DURUM"))) {
				iMap.put("MESSAGE_NO", new java.math.BigDecimal(985));
				String message = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
				throw new GMRuntimeException(0, message);
			}
			else {
				birSaticiSicilTx.setDurum(iMap.getString("DURUM"));
			}
			birSaticiSicilTx.setExBayiRiskKod(iMap.getString("EX_BAYI_RISK_KOD"));
			birSaticiSicilTx.setExBayiStatuKod(iMap.getString("EX_BAYI_STATU_KOD"));
			birSaticiSicilTx.setExKategoriSkorTahsisKod(iMap.getString("EX_KATEGORI_SKOR_TAHSIS_KOD"));
			birSaticiSicilTx.setExOnemDereceKod(iMap.getString("EX_ONEM_DERECE_KOD"));
			birSaticiSicilTx.setIslemNo(iMap.getBigDecimal("ISLEM_NO"));
			birSaticiSicilTx.setKapanmaNedenKod(iMap.getString("KAPANMA_NEDEN_KOD"));
			birSaticiSicilTx.setKategoriSkorTahsisKod(iMap.getString("KATEGORI_SKOR_TAHSIS_KOD"));
			birSaticiSicilTx.setKayitTipKod(iMap.getString("KAYIT_TIP_KOD"));
			birSaticiSicilTx.setKismiKapanmaNedenKod(iMap.getString("KISMI_KAPANMA_NEDEN_KOD"));
			birSaticiSicilTx.setOnemDereceKod(iMap.getString("ONEM_DERECE_KOD"));
			birSaticiSicilTx.setRiskDerecesiKod(iMap.getString("RISK_DERECESI_KOD"));
			birSaticiSicilTx.setSaticiKod(iMap.getBigDecimal("SATICI_KOD"));
			birSaticiSicilTx.setTakipTamamEh(iMap.getBoolean("TAKIP_TAMAM_EH") ? "E" : "H");
			birSaticiSicilTx.setTakipTarih(iMap.getDate("TAKIP_TARIH"));
			birSaticiSicilTx.setTespitKaynakKod(iMap.getString("TESPIT_KAYNAK_KOD"));
			birSaticiSicilTx.setTespitKisiKod(iMap.getString("TESPIT_KISI_KOD"));
			birSaticiSicilTx.setTespitTarih(iMap.getDate("TESPIT_TARIH"));
			birSaticiSicilTx.setTespitKod(iMap.getString("TESPIT_KOD"));
			birSaticiSicilTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birSaticiSicilTx.setIliskiliIslem(iMap.getString("ILISKILI_ISLEM"));

			session.save(birSaticiSicilTx);
			session.flush();

			iMap.put("TRX_NAME", "3264");
			return new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}

	@GraymoundService("BNSPR_TRN3264_GET_INFO")
	public static GMMap trn3264GetInfo(GMMap iMap) {

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			GMMap oMap = new GMMap();
			GMMap i2Map = new GMMap();
			GMMap oldMap = new GMMap();
			Object[] inputValues;
			BigDecimal islemNo;
		
			BirSaticiSicilTx birSaticiSicilTx = (BirSaticiSicilTx) session.createCriteria(BirSaticiSicilTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

			islemNo = birSaticiSicilTx.getIslemNo();

			i2Map.put("TRX_NO", iMap.get("TRX_NO"));
			i2Map.put("ISLEM_NO", islemNo);
			oldMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRN3264_GET_ONCEKI_TX_NO", i2Map).getBigDecimal("OLD_TRX_NO"));
			
			inputValues = new Object[]{
					BnsprType.NUMBER,null,
					BnsprType.NUMBER,iMap.getBigDecimal("TRX_NO")
			};

			setSicilDetayMap(oMap, inputValues);

			setSicilDurumListesiTable("SICIL_DURUM_TABLE", oMap, inputValues);

			setSicilAksiyonListesiTable("SICIL_AKSIYON_TABLE", oMap, inputValues);

			setIliskiliBayiListesiTable("BAGLI_BAYI_TABLE", oMap, inputValues);

			inputValues[1] = oldMap.getBigDecimal("TRX_NO");

			setSicilDetayMap(oldMap, inputValues);
			oMap.putAll(BeanSetProperties.mapDifference(oldMap, oMap));

			setSicilDurumListesiTable("OLD_SICIL_DURUM_TABLE", oMap, inputValues);
			oMap.put("SICIL_DURUM_TABLE_COLOR_DATA", BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get("OLD_SICIL_DURUM_TABLE"), (ArrayList<?>) oMap.get("SICIL_DURUM_TABLE"), "SICIL_DURUM_KOD").get("COLOR_DATA"));

			setSicilAksiyonListesiTable("OLD_SICIL_AKSIYON_TABLE", oMap, inputValues);
			oMap.put("SICIL_AKSIYON_TABLE_COLOR_DATA", BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get("OLD_SICIL_AKSIYON_TABLE"), (ArrayList<?>) oMap.get("SICIL_AKSIYON_TABLE"), "SICIL_AKSIYON_KOD").get("COLOR_DATA"));

			setIliskiliBayiListesiTable("OLD_BAGLI_BAYI_TABLE", oMap, inputValues);
			oMap.put("BAGLI_BAYI_TABLE_COLOR_DATA", BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oldMap.get("OLD_BAGLI_BAYI_TABLE"), (ArrayList<?>) iMap.get("BAGLI_BAYI_TABLE"), "GUNCELLE_EH").get("COLOR_DATA"));

			oMap.putAll(iMap);

			return oMap;

		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}

	public static void setSicilDetayMap(GMMap oMap, Object[] inputValues) throws SQLException, ParseException {

		String func = "{? = call pkg_trn3264.sicil_bilgileri(?,?)}";
		oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues));
		oMap.put("DURUM", oMap.getString("RESULTS", 0, "DURUM"));
		oMap.put("KOD", oMap.getString("RESULTS", 0, "SATICI_KOD"));
		oMap.put("KAYIT_TIP_KOD", oMap.getString("RESULTS", 0, "KAYIT_TIP_KOD"));
		oMap.put("TESPIT_KOD", oMap.getString("RESULTS", 0, "TESPIT_KOD"));
		oMap.put("TESPIT_KAYNAK_KOD", oMap.getString("RESULTS", 0, "TESPIT_KAYNAK_KOD"));
		oMap.put("RISK_DERECESI_KOD", oMap.getString("RESULTS", 0, "RISK_DERECESI_KOD"));
		oMap.put("TESPIT_TARIH", oMap.getDate("RESULTS", 0, "TESPIT_TARIH"));
		oMap.put("TAKIP_TARIH", oMap.getDate("RESULTS", 0, "TAKIP_TARIH"));
		oMap.put("TAKIP_TAMAM_EH", StringUtils.isNotBlank(oMap.getString("RESULTS", 0, "TAKIP_TAMAM_EH")) && "E".equals(oMap.getString("RESULTS", 0, "TAKIP_TAMAM_EH")));
		oMap.put("TESPIT_KISI_KOD", oMap.getString("RESULTS", 0, "TESPIT_KISI_KOD"));
		oMap.put("BASVURU_NO", oMap.getBigDecimal("RESULTS", 0, "BASVURU_NO"));
		oMap.put("BAYI_RISK_KOD", oMap.getString("RESULTS", 0, "BAYI_RISK_KOD"));
		oMap.put("EX_BAYI_RISK_KOD", oMap.getString("RESULTS", 0, "EX_BAYI_RISK_KOD"));
		oMap.put("BAYI_STATU_KOD", oMap.getString("RESULTS", 0, "BAYI_STATU_KOD"));
		oMap.put("EX_BAYI_STATU_KOD", oMap.getString("RESULTS", 0, "EX_BAYI_STATU_KOD"));
		oMap.put("KISMI_KAPANMA_NEDEN_KOD", oMap.getString("RESULTS", 0, "KISMI_KAPANMA_NEDEN_KOD"));
		oMap.put("KAPANMA_NEDEN_KOD", oMap.getString("RESULTS", 0, "KAPANMA_NEDEN_KOD"));
		oMap.put("EX_ONEM_DERECE_KOD", oMap.getString("RESULTS", 0, "EX_ONEM_DERECE_KOD"));
		oMap.put("ONEM_DERECE_KOD", oMap.getString("RESULTS", 0, "ONEM_DERECE_KOD"));
		oMap.put("KATEGORI_SKOR_TAHSIS_KOD", oMap.getString("RESULTS", 0, "KATEGORI_SKOR_TAHSIS_KOD"));
		oMap.put("EX_KATEGORI_SKOR_TAHSIS_KOD", oMap.getString("RESULTS", 0, "EX_KATEGORI_SKOR_TAHSIS_KOD"));
		oMap.put("ACIKLAMA", oMap.getString("RESULTS", 0, "ACIKLAMA"));
		oMap.put("KULL_ACIKLAMA", oMap.getString("RESULTS", 0, "KULL_ACIKLAMA"));
		oMap.put("ISLEM_NO", oMap.getString("RESULTS", 0, "ISLEM_NO"));
		oMap.put("REC_DATE", oMap.getString("RESULTS", 0, "REC_DATE"));
		oMap.put("REC_OWNER", oMap.getString("RESULTS", 0, "REC_OWNER"));
		oMap.put("ILISKILI_ISLEM", oMap.getString("RESULTS",0,"ILISKILI_ISLEM"));
	}

	public static void setSicilDurumListesiTable(String tableName, GMMap oMap, Object[] inputValues) throws SQLException {
		String func = "{? = call pkg_trn3264.sicil_durum_listesi(?,?)}";
		oMap.putAll(DALUtil.callOracleRefCursorFunction(func, tableName, inputValues));
	}

	public static void setSicilAksiyonListesiTable(String tableName, GMMap oMap, Object[] inputValues) throws SQLException {
		String func = "{? = call pkg_trn3264.sicil_aksiyon_listesi(?,?)}";
		oMap.putAll(DALUtil.callOracleRefCursorFunction(func, tableName, inputValues));
	}

	public static void setIliskiliBayiListesiTable(String tableName, GMMap oMap, Object[] inputValues) throws SQLException {
		String func = "{? = call pkg_trn3264.iliskili_bayi_list(?,?)}";
		oMap.putAll(DALUtil.callOracleRefCursorFunction(func, tableName, inputValues));
	}

	@GraymoundService("BNSPR_TRN3264_GET_ONCEKI_TX_NO")
	public static GMMap getOldTxNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Object[] inputValues;
		String func;
		try {
			func = "{?=call pkg_trn3264.onceki_txno(?,?)}";
			inputValues = new Object[]{
				BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO"),
				BnsprType.NUMBER, iMap.getBigDecimal("ISLEM_NO")
			};
			oMap.put("OLD_TRX_NO", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}

	@GraymoundService("BNSPR_TRN3264_GET_SICIL_ISLEM_NO")
	public static GMMap getSicilIslemNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		String func;
		try {
			func = "{?=call pkg_trn3264.sicil_islem_no_al}";
			oMap.put("ISLEM_NO", DALUtil.callOracleFunction(func, BnsprType.STRING, new Object[0]));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}

	@GraymoundService("BNSPR_BATCH_BAYI_KKB_SORGU")
	public static GMMap batchBayiKkbSorgu(GMMap iMap) {
		GMMap oMap = new GMMap();

		oMap.putAll(GMServiceExecuter.executeNT("BNSPR_BATCH_BAYI_KKB_SORGU_LISTE", oMap));

		try {
			String func = "{? = call pkg_satici_sorgu.kkb_sorguno_liste(?)}";

			Object[] inputValues = new Object[]{
				BnsprType.NUMBER, oMap.getBigDecimal("PN_ID")	
			};
			
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "KKB_SORGU_LIST", inputValues));

			if (oMap.getSize("KKB_SORGU_LIST") > 0) {
				for (int j = 0; j < oMap.getSize("KKB_SORGU_LIST"); j++) {
					GMMap kkbSorguMap = new GMMap();
					kkbSorguMap.put("KKB_SORGU_LIST", 0, "SORGU_ID", oMap.getBigDecimal("KKB_SORGU_LIST", j, "SORGU_ID"));
					GMServiceExecuter.executeNT("ADD_KKB_TEST", kkbSorguMap);
				}
			}

			GMServiceExecuter.executeNT("BNSPR_BATCH_BAYI_OTOMATIK_SORGU_ISLE", oMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_BATCH_BAYI_KKB_SORGU_LISTE")
	public static GMMap batchBayiKkbSorguListe(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			String proc = "{ call pkg_satici_sorgu.bayi_otomatik_sorgula(?,?) }";
			Object[] inputValues = new Object[]{
				BnsprType.STRING, "1"	
			};
			Object[] outputValues = new Object[]{
				BnsprType.NUMBER, "PN_ID"	
			};			
			oMap.putAll((GMMap) DALUtil.callOracleProcedure(proc, inputValues, outputValues));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_BATCH_BAYI_OTOMATIK_SORGU_ISLE")
	public static GMMap batchBayiOtomatikSorguIsle(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			String proc = "{ call pkg_satici_otosicil.otosorgu_isle(?) }";
			Object[] inputValues = new Object[]{
				BnsprType.STRING, iMap.getString("PN_ID")	
			};
			Object[] outputValues = new Object[0];			
			DALUtil.callOracleProcedure(proc, inputValues, outputValues);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3264_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap calisanMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirSaticiSicilTx birSaticiSicilTx = (BirSaticiSicilTx) session.createCriteria(BirSaticiSicilTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			
			BirSaticiTahsisTx birSaticiTahsisTx = (BirSaticiTahsisTx) session.createCriteria(BirSaticiTahsisTx.class).add(Restrictions.eq("txNo", birSaticiSicilTx.getTxNo())).uniqueResult();
			
			if(birSaticiTahsisTx != null){
				calisanMap.put("ISLEM_NO", birSaticiSicilTx.getTxNo());
				GMServiceExecuter.execute("BNSPR_TRN3162_CALISAN_STATU_GUNCELLEME", calisanMap);
				
				List<BirSaticiSicilSaticilarTx> birSaticiSicilSaticilarTxList = session.createCriteria(BirSaticiSicilSaticilarTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).list();
				for (BirSaticiSicilSaticilarTx birSaticiSicilSaticilarTx : birSaticiSicilSaticilarTxList) {
					calisanMap.put("ISLEM_NO", birSaticiSicilSaticilarTx.getId().getTxNo());
					GMServiceExecuter.execute("BNSPR_TRN3162_CALISAN_STATU_GUNCELLEME", calisanMap);
				}
			}
			return new GMMap();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
