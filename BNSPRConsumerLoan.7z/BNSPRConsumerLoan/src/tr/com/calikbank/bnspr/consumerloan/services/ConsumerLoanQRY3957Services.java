package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.File;
import java.io.FileWriter;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanQRY3957Services {
	private static String ROOT = GMServer.getProperty("graymound.home",null)+
			File.separator 	+
			"Server"		+
			File.separator 	+
			"Content"		+
			File.separator	+
			"Root"			;
	/**
	 * DESC    : ESGM html sorgulamas� i�in ba�vuru - tc kimlik no bilgilerini getirir.
	 */
	@GraymoundService("BNSPR_QRY3957_BASVURU_BILGI")
	public static GMMap musteriSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (StringUtil.isEmpty(iMap.getString("BASVURU_NO")) && StringUtil.isEmpty(iMap.getString("TC_KIMLIK_NO"))) {
				HashMap<String, Object> myMap = new HashMap<String, Object>();
				myMap.put("HATA_NO", new BigDecimal(442));
				return oMap;
			}
			
			GMMap sMap = new GMMap();
			String func = "{ ? = call PKG_IST_PTT_EMEKLI.RC_BASVURU_BILGI(?) }";
			Object[] inputValues = new Object[2];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			sMap = DALUtil.callOracleRefCursorFunction(func, "KIMLIK_TABLO", inputValues);

			oMap.put("MUSTERI_NO", sMap.get("KIMLIK_TABLO", 0, "MUSTERI_NO"));
			oMap.put("AD", sMap.get("KIMLIK_TABLO", 0, "AD"));
			oMap.put("SOYAD", sMap.get("KIMLIK_TABLO", 0, "SOYAD"));
			oMap.put("TC_KIMLIK_NO", "<html><head><title>Untitled Document</title>   \t</head> \t<body bgcolor=\"#26424b\"> \t<font face=\"Arial,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\" color=\"white\"> \t<b><p>Uluslararas� Banka Hesap Numaras� (IBAN)</p> \t<p>IBAN Nedir? </p></b> \t</font> \t<font face=\"Arial,Verdana,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\" color=\"#bad4dd\"> \t<p >Avrupa Birli�i d�zenlemeleri �er�evesinde, �lkeler aras�nda ger�ekle�tirilen para transferlerinin h�z� ile kalitesini art�rmak ve maliyetlerini d���rmek amac�yla International Bank Account Number-IBAN ad� verilen uluslararas� banka hesap numaras� standard� geli�tirilmi�tir. IBAN bug�n 33 Avrupa �lkesinde kullan�lmaktad�r. </p> \t<p >IBAN'�n amac� Avrupa �lkelerindeki banka ve di�er finansal kurumlar arac�l��� ile ger�ekle�tirilen para transferlerindeki hatalar� ve bundan do�an gecikmeleri engellemektir. IBAN sayesinde transfer edilen para daha h�zl� ve hatas�z bir bi�imde g�ndericinin hesab�ndan al�c�n�n hesab�na ge�mekte; b�ylece, i�lemlerde olu�an hatalardan kaynaklanan bekleme s�releri ve ek maliyetler ortadan kalkmaktad�r. </p> \t</font> \t<font face=\"Arial,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\" color=\"white\"> \t<b><p color=\"white\">IBAN, Hesap Sahiplerine Nas�l Kolayl�k Sa�lar? </p></b> \t</font> \t<font  face=\"Arial,Verdana,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\" color=\"#bad4dd\"> \t<p >G�n�m�zde her �lkenin ve bankan�n hesap numaralar�n�n bi�imi ve uzunlu�u farkl�d�r. Bir ba�ka �lkeye veya bankaya para transferi yapacak olan m��teriler, hesap numaralar�nda belirli bir standart olmad���ndan, para transferi yapacaklar� ki�iden ald�klar� kar�� hesap numaras�n�n do�rulu�undan emin olamamaktad�rlar. </p> \t<p >Bir mal veya hizmet al�m� s�z konusu ise bir�ok farkl� sat�c� taraf�ndan gelen faturalar�n �zerinde de�i�ik yap�da hesap numaralar� yer almakta; bu da para g�nderecek ithalat�� firmalar�n/ki�ilerin hata yapmalar�na neden olmaktad�r. Sonu� olarak yanl�� hesap numaralar� ile yap�lan para transferleri ger�ekle�memekte; kar�� hesap numaras�n�n hatal� oldu�u, para kar�� bankaya ula�t���nda ortaya ��kmaktad�r. Hatal� i�lemin d�zeltilmesi i�in bir�ok operasyon yap�lmakta, i�lemlerin s�resi uzamakta ve maliyeti y�kselmektedir. </p> \t<p >IBAN uygulamas�na ge�en �lkelerde banka hesap numaralar�n�n her biri i�in hesap sahiplerine bir IBAN verilir. Her �lke i�in belirli bir bi�imi ve standard� bulunan IBAN'�n i�inde �zel bir �ifreleme algoritmas� ile elde edilen iki basamakl� &quot;kontrol rakam�&quot; bulunmaktad�r. Bir ba�ka �lkeye ya da bankaya para transfer etmek isteyen bir m��teri, elindeki IBAN'� g�nderici bankaya verdi�inde, para, al�c� bankaya gitmeden �nce al�c� hesab�n IBAN'� g�nderici bankada kontrol edilir. IBAN yanl�� ise para kar�� bankaya g�nderilmez ve yanl�� i�lem engellenmi� olur. </p> \t</font> \t\t<font face=\"Arial,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\" color=\"white\"> \t<b><p>IBAN'�n Kullan�m� </p></b> \t</font> \t<font  face=\"Arial,Verdana,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\" color=\"#bad4dd\"> \t<p >Almanya'da ya�ayan Ahmet Bey'in, T�rkiye'deki o�lu Ali'ye havale g�ndermek istedi�ini varsayal�m. </p> \t<p >Ali, e�er bilmiyorsa X bankas�na giderek hesab�na ait IBAN numaras�n� ��renir. </p> \t<p >Ali, IBAN numaras�n� babas�na iletir. </p> \t<p>O�lundan paray� havale edece�i hesab�n IBAN'�n� ��renen Ahmet Bey Almanya'daki Y bankas�na gider. Ahmet Bey o�lunun IBAN'�n� Y bankas�ndaki g�revliye verir ve bu hesaba havale yapmak istedi�ini s�yler. </p> \t<p>Y bankas� g�revlisi, Ahmet Bey taraf�ndan verilen IBAN'�n do�ru olup olmad���n� �n�ndeki ekrandan kontrol eder. Verilen IBAN do�ru ise para transferi ger�ekle�ir.</p> \t<p >Para transferi do�ru IBAN ile ger�ekle�ti�inden, Almanya'daki Y bankas�ndan gelen havale mesaj� T�rkiye'deki X bankas�na ula�t���nda Ahmet Bey'in g�nderdi�i miktar, o�lu Ali'nin hesab�na otomatik olarak ge�er. </p> \t</font> \t\t<font face=\"Arial,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\" color=\"white\"> \t<b><p>IBAN Standard� (IBAN Nas�l Olu�turulur?) </p></b> \t</font> \t<font  face=\"Arial,Verdana,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\" color=\"#bad4dd\"> \t<p>IBAN, D�nyadaki t�m banka hesaplar� i�inde yaln�zca bir hesab� i�aret eden; rakam ve harflerden olu�ur. Her hesab�n bir IBAN'� vard�r ve bir IBAN, yaln�zca bir hesab� i�aret eder. </p> \t<p>Bir IBAN, en fazla 34 basamaktan olu�ur. IBAN'�n ilk d�rt hanesi, iki haneli �lke kodu ve iki haneli kontrol rakam�d�r. Kontrol rakam�, IBAN'�n do�ru ve ge�erli olup olmad���n� g�sterir. IBAN'�n bundan sonraki k�sm�, ulusal banka hesap numaras�n� i�erir. Bu b�l�m, IBAN'�n toplam uzunlu�u 34 haneyi a�mayacak �ekilde her �lke taraf�ndan serbest�e belirlenebilir. </p> \t<p>�lkemizin IBAN uzunlu�u 26 hane olarak belirlenmi�tir. T�rkiye IBAN'�n bi�imi a�a��dad�r:</p> \t</font> \t<font face=\"Arial,Verdana,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\" color=\"#FFF\"> \t<table width=\"670\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\" >  <tr>    <td colspan=\"2\" align=\"center\" bgcolor=\"#6d95a3\" >�lke Kodu</td>    <td colspan=\"2\" align=\"center\" bgcolor=\"#6d95a3\" >Kontrol <br />    Basamaklar</td>    <td colspan=\"5\" align=\"center\" bgcolor=\"#6d95a3\" >Banka Kodu <br />      5 Hane</td>    <td width=\"64\" align=\"center\" bgcolor=\"#6d95a3\" >Rez.Alan 1 Hane</td>    <td colspan=\"16\" align=\"center\" bgcolor=\"#6d95a3\" >Hesap No<br />      16 No</td>  </tr>  <tr >    <td width=\"36\" align=\"center\" bgcolor=\"#6d95a3\">T</td>    <td width=\"34\" align=\"center\" bgcolor=\"#6d95a3\">R</td>    <td width=\"39\" align=\"center\" bgcolor=\"#6d95a3\">5</td>    <td width=\"39\" align=\"center\" bgcolor=\"#6d95a3\">6</td>    <td width=\"18\" align=\"center\" bgcolor=\"#6d95a3\">0</td>    <td width=\"18\" align=\"center\" bgcolor=\"#6d95a3\">0</td>    <td width=\"18\" align=\"center\" bgcolor=\"#6d95a3\">0</td>    <td width=\"18\" align=\"center\" bgcolor=\"#6d95a3\">6</td>    <td width=\"17\" align=\"center\" bgcolor=\"#6d95a3\">1</td>    <td align=\"center\" bgcolor=\"#6d95a3\">0</td>    <td width=\"17\" align=\"center\" bgcolor=\"#6d95a3\">0</td>    <td width=\"17\" align=\"center\" bgcolor=\"#6d95a3\">0</td>    <td width=\"17\" align=\"center\" bgcolor=\"#6d95a3\">0</td>    <td width=\"17\" align=\"center\" bgcolor=\"#6d95a3\">0</td>    <td width=\"17\" align=\"center\" bgcolor=\"#6d95a3\">0</td>    <td width=\"17\" align=\"center\" bgcolor=\"#6d95a3\">1</td>    <td width=\"17\" align=\"center\" bgcolor=\"#6d95a3\">2</td>    <td width=\"17\" align=\"center\" bgcolor=\"#6d95a3\">9</td>    <td width=\"17\" align=\"center\" bgcolor=\"#6d95a3\">9</td>    <td width=\"23\" align=\"center\" bgcolor=\"#6d95a3\">0</td>    <td width=\"17\" align=\"center\" bgcolor=\"#6d95a3\">0</td>    <td width=\"16\" align=\"center\" bgcolor=\"#6d95a3\">2</td>    <td width=\"26\" align=\"center\" bgcolor=\"#6d95a3\">2</td>    <td width=\"31\" align=\"center\" bgcolor=\"#6d95a3\">3</td>    <td width=\"17\" align=\"center\" bgcolor=\"#6d95a3\">0</td>    <td width=\"32\" align=\"center\" bgcolor=\"#6d95a3\">2</td>  </tr></table> \t</font> \t<font face=\"Arial,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\" color=\"white\"><p>Baz� Avrupa �lkelerinin IBAN standartlar� A�a��dad�r:</p></font> \t<font face=\"Arial,Verdana,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\" color=\"#FFF\"> \t<table width=\"670\" border=\"0\" cellpadding=\"0\" cellspacing=\"0\">  <tr >    <td align=\"left\" bgcolor=\"#6d95a3\">�lke</td>    <td width=\"94\" bgcolor=\"#6d95a3\">Uzunluk</td>    <td bgcolor=\"#6d95a3\">�rnek Numaralar</td>  </tr>  <tr>    <td bgcolor=\"#6d95a3\"><font size=\"2\" >Almanya</font></td>    <td bgcolor=\"#6d95a3\" >22</td>    <td bgcolor=\"#6d95a3\"><span >DE89 3704 0044 0532 0130 00</span></td>  </tr>  <tr>    <td bgcolor=\"#6d95a3\"><span >Avusturya</span></td>    <td bgcolor=\"#6d95a3\" >20</td>    <td bgcolor=\"#6d95a3\"><span > AT61 1904 3002 3457 3201 </span></td>  </tr>  <tr>    <td bgcolor=\"#6d95a3\"><span >Bel�ika </span></td>    <td bgcolor=\"#6d95a3\" >16</td>    <td bgcolor=\"#6d95a3\"><span >BE68 5390 0754 7034 <br />    </span></td>  </tr>  <tr>    <td bgcolor=\"#6d95a3\"><span >Danimarka</span></td>    <td bgcolor=\"#6d95a3\" >18</td>    <td bgcolor=\"#6d95a3\"><span >DK50 0040 0440 1162 43 </span></td>  </tr>  <tr>    <td bgcolor=\"#6d95a3\"><span >Finlandiya</span></td>    <td bgcolor=\"#6d95a3\" >18</td>    <td bgcolor=\"#6d95a3\"><span >FI21 1234 5600 0007 85 </span></td>  </tr>  <tr>    <td bgcolor=\"#6d95a3\"><span >Fransa</span></td>    <td bgcolor=\"#6d95a3\" >27</td>    <td bgcolor=\"#6d95a3\"><span >FR14 2004 1010 0505 0001 3M02 606 </span></td>  </tr>  <tr>    <td bgcolor=\"#6d95a3\"><span >Hollanda</span></td>    <td bgcolor=\"#6d95a3\" >18</td>    <td bgcolor=\"#6d95a3\"><span >NL91 ABNA 0417 1643 00 </span></td>  </tr>  <tr>    <td bgcolor=\"#6d95a3\"><span >�ngiltere</span></td>    <td bgcolor=\"#6d95a3\" >22</td>    <td bgcolor=\"#6d95a3\"><span >GB29 NWBK 6016 1331 9268 19 </span></td>  </tr>  <tr>    <td bgcolor=\"#6d95a3\"><span >�sve�</span></td>    <td bgcolor=\"#6d95a3\" >24</td>    <td bgcolor=\"#6d95a3\"><span >SE35 5000 0000 0549 1000 0003 </span></td>  </tr>  <tr>    <td bgcolor=\"#6d95a3\"><span >�svi�re</span></td>    <td bgcolor=\"#6d95a3\" >21</td>    <td bgcolor=\"#6d95a3\"><span > CH39 0070 0115 2018 4917 3 </span></td>  </tr></table> \t</font> \t<font face=\"Arial,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\" color=\"white\"><b><p>IBAN'�n Elektronik Ortamda ve Ka��t Ortam�ndaki G�sterili�i </p></b></font> \t<font face=\"Arial,Verdana,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\" color=\"#bad4dd\"> \t<p>IBAN numaras�, elektronik ortamda i�lenecek ya da saklanacak ise (�rne�in bilgisayara ya da ekrana IBAN giri�i yap�lmas�) t�m harf ve rakamlar yan yana bo�luk ve herhangi bir ayr�m karakteri (ayra�, virg�l, tire vb.) olmaks�z�n yaz�lmal�d�r. Bu g�sterim �eklinde &quot;elektronik g�sterim&quot; ad� verilmektedir. IBAN'�n ka��t �zerine bas�lmas�na y�nelik g�sterimine ise &quot;yaz�m g�sterimi&quot; ad� verilir. Bu g�sterimde ise IBAN soldan 4'l� basamaklara ayr�larak yaz�l�r. Numaran�n 4'erli gruplar halinde yaz�lmas�ndan sonra son k�s�mda rakam art�yorsa bunlar da yan yana yaz�l�r. </p> \t<b><p><span>IBAN'�n Elektronik G�sterimi</span><br /><span >TR5600061000 00012990022302 </span></p> \t<p><span>IBAN'�n Yaz�m G�sterimi</span><br /><span >TR56 0006 1000 0001 2990 0223 02 </span></p> \t\t</font> \t\t<font color=\"white\"> \t<b><p >M��teriler Ne Yapmal�? </p></b></font>   \t<p><font color=\"#bad4dd\" face=\"Arial,Verdana,Helvetica,sans-serif\" clear=\"both\" size=\"2\" height=\"2\">IBAN ile gelen kolayl�klardan yararlanmak i�in hesab�n�za para g�nderecek olan ki�ilere IBAN'�n�z� iletiniz; �lkeler aras� ya da bankalar aras� para transferi yapaca��n�z ki�ilerin IBAN'�n� isteyiniz. Ticaret yapt���n�z ya da size para transferi yapan ki�i ve kurulu�lara verece�iniz dok�manlara IBAN numaran�z� m�mk�n oldu�unca yaz�n�z. </font></p>   \t</body> \t</html> ");
		
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	
	/**
	 * DESC    : ESGM_HTML tablosundan basvuru no ve/veya tckn ile sorgulama yapar. 
	 *			 liste olarak geri dondurur.
	 */
	@GraymoundService("BNSPR_QRY3957_ESGM_SORGU")
	public static GMMap esgmHtmlListesiGetir(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (StringUtil.isEmpty(iMap.getString("BASVURU_NO")) && StringUtil.isEmpty(iMap.getString("TC_KIMLIK_NO"))) {
				HashMap<String, Object> myMap = new HashMap<String, Object>();
				myMap.put("HATA_NO", new BigDecimal(442));
				throw new GMRuntimeException(0, "Basvuru No / Tc kimlik no dan birisi dolu olmalidir.");
			}
			
			String func = "{ ? = call PKG_IST_ESGM.rc_ist_list_esgm(?,?) }";
			Object[] inputValues = new Object[4];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TC_KIMLIK_NO");

			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "TABLE", inputValues));
			
			List<?> ozetList=(List<?>) oMap.get("TABLE");
			if (ozetList != null) {
				for (int k = 0; k < ozetList.size(); k++) {
					oMap.put("TABLE", k, "HTML_EH", StringUtil.isEmpty(oMap.get("TABLE", k, "HTML").toString()) ? "0" : "1");
				}
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	
	/**
	 * 
	 * DESC    : G�nderilen html i�eri�i clienta g�ndermeden �nce sunucuda temp olarak kaydeder. 
	 *
	 */
	@GraymoundService("BNSPR_QRY3957_SAVE_HTML_TMP")
	public static GMMap saveHtml(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			File f = new File(ROOT+File.separator+"files"+File.separator + "tmpEsgm.html");
			FileWriter w = new FileWriter(f);
			w.write(iMap.getString("HTML").replace("\"refresh\"", ""));
			w.close();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	/**
	 * 
	 * DESC    : temp olarak kaydedilen html dosyayi siler. 
	 *
	 */
	@GraymoundService("BNSPR_QRY3957_DELETE_HTML_TMP")
	public static GMMap deleteTempHtml(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			File f = new File(ROOT+File.separator+"files"+File.separator + "tmpEsgm.html");
			f.delete();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}



}
