package tr.com.calikbank.bnspr.consumerloan.services;

import java.util.Iterator;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import tr.com.aktifbank.bnspr.dao.BirUbeBasvuruTakipTx;
import tr.com.aktifbank.bnspr.dao.BirUbeBasvuruTakipTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3462Services {
	@GraymoundService("BNSPR_3462_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap) {
        GMMap oMap = new GMMap();
		try {
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "UBE_BASVURU_STATU");
			oMap.put("STATU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			oMap.putAll(DALUtil.fillComboBox(iMap, "KURYE", true, "select k.firma_kod, k.firma_adi from bnspr.kry_tanimlama k, bnspr.kry_proje_iliski_pr p   where k.firma_statusu = 'A' and k.firma_kod = p.firma_kod and p.proje_kod = 'WEBMUST' "));
		} 
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN3462_ALT_STATU")
	public static GMMap initalizeAltStatu(GMMap iMap) {
		GMMap oMap = new GMMap();	
		String statuKod = iMap.getString("STATU_KOD");
		String sql = "select key1,text from gnl_param_text where kod = 'UBE_BASVURU_ALT_STATU'";
		if(statuKod!=null && !statuKod.isEmpty()) {
			sql += " and key2 = '"+statuKod+"'";
		}
		oMap.putAll(DALUtil.fillComboBox(iMap,"ALT_STATU_KOD",true,sql));
		return oMap;
	}
	@GraymoundService("BNSPR_TRN3462_GET_LIST")
	public static GMMap sorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{					
			Object[] inputValues = {
				BnsprType.STRING, iMap.getString("TCKN"),
				BnsprType.STRING, iMap.getString("VKN"),
				BnsprType.STRING, iMap.getString("UNVAN"),
				BnsprType.STRING, iMap.getString("AD_SOYAD"),				
			    BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),
			    BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"),
			    BnsprType.DATE,   iMap.getDate("BAS_TARIH"),
			    BnsprType.DATE,   iMap.getDate("BIT_TARIH"),
				BnsprType.STRING, iMap.getString("CEP_TEL_NO"),
				BnsprType.STRING, iMap.getString("STATU"),
				BnsprType.STRING, iMap.getString("ALT_STATU"),
				BnsprType.NUMBER, iMap.getBigDecimal("SATICI_KOD"),
				BnsprType.NUMBER, iMap.getBigDecimal("DIST_KOD"),
				BnsprType.STRING, iMap.getString("KURYE")
			};
			String func = getFunc("PKG_TRN3462.ube_basvuru_sorgula",inputValues.length);	
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "TABLE", inputValues));
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN3462_SAVE")
	public static GMMap save3462(GMMap iMap) {		
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			BirUbeBasvuruTakipTxId birUbeBasvuruTakipTxId = new BirUbeBasvuruTakipTxId(); 
			birUbeBasvuruTakipTxId.setTxNo(iMap.getBigDecimal("TX_NO"));
			birUbeBasvuruTakipTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			BirUbeBasvuruTakipTx birUbeBasvuruTakipTx = new BirUbeBasvuruTakipTx(); 
			birUbeBasvuruTakipTx.setId(birUbeBasvuruTakipTxId);
			birUbeBasvuruTakipTx.setStatuKod(iMap.getString("STATU_KOD"));
			birUbeBasvuruTakipTx.setAltStatuKod(iMap.getString("ALT_STATU_KOD"));
			birUbeBasvuruTakipTx.setKuryeFirmaKod(iMap.getString("KURYE"));
			birUbeBasvuruTakipTx.setGonderimTarihi(iMap.getDate("GONDERIM_TARIHI"));	
			GMMap rowMap=iMap.getMap("ROW_DATA");		
			birUbeBasvuruTakipTx.setDistSaticiKod(rowMap.getBigDecimal("DIST_SATICI_KOD"));
			birUbeBasvuruTakipTx.setGuncelleyenKullanici(rowMap.getString("GUNCELLEYEN_KULLANICI"));			
			birUbeBasvuruTakipTx.setWebDistBayiRef(rowMap.getString("WEB_DIST_BAYI_REF"));
			birUbeBasvuruTakipTx.setWebCepTelNo(rowMap.getBigDecimal("WEB_CEP_TEL_NO"));
			birUbeBasvuruTakipTx.setWebCepAlanKod(rowMap.getBigDecimal("WEB_CEP_ALAN_KOD"));
			birUbeBasvuruTakipTx.setWebTckn(rowMap.getString("WEB_TCKN"));
			birUbeBasvuruTakipTx.setTxNo3161(rowMap.getBigDecimal("TX_NO_3161"));
			birUbeBasvuruTakipTx.setTxNo3166(rowMap.getBigDecimal("TX_NO_3166"));
			birUbeBasvuruTakipTx.setCalisanKod(rowMap.getBigDecimal("CALISAN_KOD"));
			birUbeBasvuruTakipTx.setKullaniciKod(rowMap.getString("KULLANICI_KOD"));
			birUbeBasvuruTakipTx.setBasvuruTarihi(rowMap.getDate("BASVURU_TARIHI"));
			birUbeBasvuruTakipTx.setGuncellemeTarihi(rowMap.getDate("GUNCELLEME_TARIHI"));		
			birUbeBasvuruTakipTx.setSaticiKod(rowMap.getBigDecimal("SATICI_KOD"));
			session.save(birUbeBasvuruTakipTx);
			session.flush();
			iMap.put("TRX_NO",birUbeBasvuruTakipTxId.getTxNo());
		    iMap.put("TRX_NAME", "3462");
		    return new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
		}
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}	   
	}
	@GraymoundService("BNSPR_TRN3462_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();	
		try {			
			Session session = DAOSession.getSession("BNSPRDal");		
			List<?> list = (List<?>) session.createCriteria(BirUbeBasvuruTakipTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirUbeBasvuruTakipTx birUbeBasvuruTakipTx = (BirUbeBasvuruTakipTx) iterator.next();
				oMap.put("STATU_KOD", birUbeBasvuruTakipTx.getStatuKod());
				oMap.put("ALT_STATU_KOD",birUbeBasvuruTakipTx.getAltStatuKod()); 
				oMap.put("KURYE",birUbeBasvuruTakipTx.getKuryeFirmaKod()); 
				iMap.put("BASVURU_NO",birUbeBasvuruTakipTx.getId().getBasvuruNo());
				oMap.putAll(sorgula(iMap));			
			}
		return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3462_ISLEM_YETKI")
	public static GMMap getIslemYetki(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			Object[] inputValues={
				BnsprType.STRING,null 
			};		
			String func = getFunc("PKG_TRN3462.guncelleme_yetki",inputValues.length);
			String yetki = String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));			
			oMap.put("ISLEM_YETKI", "E".equals(yetki));			
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	private static String getFunc(String pFuncName,int pLen) {
		String func = "{? = call "+pFuncName+"(";
		int len = (pLen / 2);
		for(int i=0;i<len;i++) {				
			func += (i==(len-1)) ? "?)}" : "?,";
		}
		return func;
	}
}
