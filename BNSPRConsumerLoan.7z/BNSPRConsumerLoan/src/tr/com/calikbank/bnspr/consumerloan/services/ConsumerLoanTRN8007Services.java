package tr.com.calikbank.bnspr.consumerloan.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KkbOrtamYetkiTalepTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN8007Services {

	public static final String TABLE_NAME = "TBL_KULLANICI_SEC";

	@GraymoundService("BNSPR_TRN8007_GET_INFO")
	public static GMMap getInfoTRN8007(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<KkbOrtamYetkiTalepTx> liste = session.createCriteria(KkbOrtamYetkiTalepTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HHmmss");
		for (KkbOrtamYetkiTalepTx tx : liste) {
			oMap.put("TRX_NO", tx.getTxNo());
			oMap.put("BASLANGIC_TARIHI", tx.getBaslangicTarihi());
			oMap.put("BASLANGIC_TARIHI_SAAT", tx.getBaslangicTarihi() == null ? null : sdf.format(tx.getBaslangicTarihi()).split(" ")[1]);
			oMap.put("BITIS_TARIHI", tx.getBitisTarihi());
			oMap.put("BITIS_TARIHI_SAAT", tx.getBitisTarihi() == null ? null : sdf.format(tx.getBitisTarihi()).split(" ")[1]);
			oMap.put("ACIKLAMA", tx.getAciklama());
		}
		return oMap;

	}

	@GraymoundService("BNSPR_TRN8007_SAVE")
	public static Map<?, ?> saveTRN8007(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			Date bitisTarihi = null;
			Date baslangicTarihi = null;
			SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			String saat;
			if (StringUtils.isNotBlank(iMap.getString("BASLANGIC_TAR"))) {
				saat = iMap.getString("BASLANGIC_SAATI") == null ? "000000" : iMap.getString("BASLANGIC_SAATI");
				baslangicTarihi = sdf.parse(sdf.format(iMap.getDate("BASLANGIC_TAR")).replaceAll("[0-9]{2}:[0-9]{2}:[0-9]{2}", saat.substring(0, 2) + ":" + saat.substring(2, 4) + ":" + saat.substring(4)));
			}

			if (StringUtils.isNotBlank(iMap.getString("BITIS_TAR"))) {
				saat = iMap.getString("BITIS_SAATI") == null ? "235900" : iMap.getString("BITIS_SAATI");
				bitisTarihi = sdf.parse(sdf.format(iMap.getDate("BITIS_TAR")).replaceAll("[0-9]{2}:[0-9]{2}:[0-9]{2}", saat.substring(0, 2) + ":" + saat.substring(2, 4) + ":" + saat.substring(4)));
			}
			KkbOrtamYetkiTalepTx tx = new KkbOrtamYetkiTalepTx(iMap.getBigDecimal("TRX_NO"), baslangicTarihi, bitisTarihi, iMap.getString("ACIKLAMA"), "G");

			session.save(tx);
			session.flush();

			iMap.put("TRX_NAME", "8007");
			Map<?, ?> oMap = GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

			emailGonder(iMap, baslangicTarihi, bitisTarihi);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	private static void emailGonder(GMMap iMap, Date baslangicTarihi, Date bitisTarihi) {
		GMMap mailServisMap = new GMMap();
		GMMap paramMap = new GMMap();
		paramMap.put("KOD", "KKB_ORTAM_YETKI");
		paramMap.put("KEY", "MAIL_FROM");
		GMMap mailMap = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap);
		mailServisMap.put("FROM", mailMap.getString("TEXT"));

		paramMap.clear();
		paramMap.put("KOD", "KKB_ORTAM_YETKI");
		paramMap.put("KEY", "MAIL_TO");
		mailMap = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap);
		mailServisMap.put("RECIPIENTS_TO", GuimlUtil.createFromCommaSeparatedList(mailMap.getString("TEXT")));

		mailServisMap.put("SUBJECT", "KKB Ortam Yetki Talebi");

		paramMap.clear();
		paramMap.put("KOD", "KKB_ORTAM_YETKI");
		paramMap.put("KEY", "MAIL_CC");
		mailMap = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap);
		mailServisMap.put("RECIPIENTS_CC", GuimlUtil.createFromCommaSeparatedList(mailMap.getString("TEXT")));

		paramMap.clear();
		paramMap.put("KOD", "KKB_ORTAM_YETKI");
		paramMap.put("KEY", "MAIL_ICERIK");
		mailMap = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", paramMap);
		String mailIcerik = mailMap.getString("TEXT");
		mailIcerik = mailIcerik.replaceAll("#1", ADCSession.getString("USER_NAME"));

		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		mailIcerik = mailIcerik.replaceAll("#2", sdf.format(baslangicTarihi));
		mailIcerik = mailIcerik.replaceAll("#3", sdf.format(bitisTarihi));

		mailIcerik = mailIcerik.replaceAll("#4", iMap.getString("ACIKLAMA"));
		mailServisMap.put("MESSAGE_BODY", mailIcerik);

		mailServisMap.put("IS_BODY_HTML", "H");

		GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", mailServisMap);

	}

}
