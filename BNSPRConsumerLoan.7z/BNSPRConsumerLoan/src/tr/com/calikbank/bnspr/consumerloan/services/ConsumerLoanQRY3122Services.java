package tr.com.calikbank.bnspr.consumerloan.services;

import java.awt.Color;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3122Services {

	@GraymoundService("BNSPR_QRY3122_GET_MUSTERI_ESLESTIRME_INFO")
	public static GMMap getMusteriEslestirmeInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3122.RC_QRY3122_MUSTERI_ESLESTIRME(?, ?, ?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("KIM_ICIN"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			Color differentBackground = new Color(255,0,64);
			Color defaultBackground = new Color(128,255,0);
			GMMap oMap = new GMMap();
			int row = 0;
			if (rSet.next()) {
				ResultSetMetaData rs = rSet.getMetaData();
				for (int c = 1; c <= rs.getColumnCount(); c++){
					oMap.put(rs.getColumnName(c), rSet.getObject(c));
					if(rs.getColumnName(c).endsWith("FARKLI")){
						if(rSet.getString(c).equals("1")){
							oMap.put("C_BASVURU_"+rs.getColumnName(c).substring(0,rs.getColumnName(c).lastIndexOf("_")), differentBackground);
							oMap.put("C_MUSTERI_"+rs.getColumnName(c).substring(0,rs.getColumnName(c).lastIndexOf("_")), differentBackground);
						}else {
							oMap.put("C_BASVURU_"+rs.getColumnName(c).substring(0,rs.getColumnName(c).lastIndexOf("_")), defaultBackground);
							oMap.put("C_MUSTERI_"+rs.getColumnName(c).substring(0,rs.getColumnName(c).lastIndexOf("_")), defaultBackground);
						}
					}
				}
				row++;
			}
			oMap.put("CHK_APSADRESI_GUNCELLE", "0");
			
			if ("0".equals(oMap.getString("MUSTERI_APS_TEYIT"))) {
				oMap.put("MUSTERI_APS_TEYIT", "1");
				oMap.put("CHK_APSADRESI_GUNCELLE", "1");
			}
			
			oMap.put("ROW_COUNT", row);
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3122_GET_MUSTERI_ESLESTIRME_LIST")
	public static GMMap getMusteriEslestirmeList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3122.RC_QRY3122_MUSTERI_ESLES_LIST(?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet)stmt.getObject(1);

			GMMap oMap = new GMMap();
			oMap.putAll(DALUtil.rSetResults(rSet,"RESULTS"));
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3122_GET_BASVURU_COUNT")
	public static GMMap getBasvuruCount(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			oMap.put("BASVURU_SAYISI", DALUtil.getResult("select count(*) from bir_basvuru where musteri_no = "+iMap.getBigDecimal("MUSTERI_NO")));
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
