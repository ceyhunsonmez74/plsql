package tr.com.calikbank.bnspr.consumerloan.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class ConsumerLoanQRY3902Services {
	@GraymoundService("BNSPR_QRY3902_GET_INITIAL_COMBO_VALUES")
	public static GMMap getInitialComboValues(GMMap iMap){
		String listName = "DURUM";
		GuimlUtil.wrapMyCombo(iMap, listName, "X", " ");
		GuimlUtil.wrapMyCombo(iMap, listName, "B", "Benzer");
		GuimlUtil.wrapMyCombo(iMap, listName, "K", "Kesin");
		GuimlUtil.wrapMyCombo(iMap, listName, "Y", "Yok");
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "IL_LIST");
		iMap.put("LIST_QUERY", "select kod,il_adi from gnl_il_kod_pr order by kod");
		DALUtil.fillComboBox(iMap);
		return iMap;
	}
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_SORGU")
	public static GMMap getTcmbSorgu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_SORGU(?,?)}");	
			stmt.registerOutParameter(1, -10); //ref cursor
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, iMap.getString("SORGU_TURU"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			oMap.put("RESULTS", DALUtil.rSetResults(rSet,"RESULTS").get("RESULTS"));
			
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			
			List<?> ozetList=(List<?>) oMap.get("RESULTS");
			if(ozetList!=null){
				for(int i=0;i<ozetList.size();i++){
					stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_NN_KREDI(?)}");
					stmt.registerOutParameter(1, -10);
					stmt.setBigDecimal(2, oMap.getBigDecimal("RESULTS", i, "ID"));

					stmt.execute();
					stmt.getMoreResults();
					rSet = (ResultSet)stmt.getObject(1);
					
					oMap.put("RESULTS", i, "KREDI_MODEL", DALUtil.rSetResults(rSet,"RESULTS").get("RESULTS"));						
					
					GMServerDatasource.close(rSet);
					GMServerDatasource.close(stmt);
					
					stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_CEK_GERCEK(?)}");
					stmt.registerOutParameter(1, -10);
					stmt.setBigDecimal(2, oMap.getBigDecimal("RESULTS", i, "ID"));

					stmt.execute();
					stmt.getMoreResults();
					rSet = (ResultSet)stmt.getObject(1);

					oMap.put("RESULTS", i, "CEK_MODEL", DALUtil.rSetResults(rSet,"RESULTS").get("RESULTS"));
					
					GMServerDatasource.close(rSet);
					GMServerDatasource.close(stmt);
					
					stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_CEK_MAHK(?)}");
					stmt.registerOutParameter(1, -10);
					stmt.setBigDecimal(2, oMap.getBigDecimal("RESULTS", i, "ID"));

					stmt.execute();
					stmt.getMoreResults();
					rSet = (ResultSet)stmt.getObject(1);

					oMap.put("RESULTS", i, "MAHKEME_MODEL", DALUtil.rSetResults(rSet,"RESULTS").get("RESULTS"));
					
					GMServerDatasource.close(rSet);
					GMServerDatasource.close(stmt);
					
					stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_PROT_SENET(?)}");
					stmt.registerOutParameter(1, -10);
					stmt.setBigDecimal(2, oMap.getBigDecimal("RESULTS", i, "ID"));

					stmt.execute();
					stmt.getMoreResults();
					rSet = (ResultSet)stmt.getObject(1);
					
					oMap.put("RESULTS", i, "SENET_MODEL", DALUtil.rSetResults(rSet,"RESULTS").get("RESULTS"));
					
					GMServerDatasource.close(rSet);
					GMServerDatasource.close(stmt);
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_SORGU_BY_BATCH_ID")
	public static GMMap getTcmbSorguByBatchId(GMMap iMap) {		
		try {			
			GMMap oMap = new GMMap();
			String func="{? = call PKG_SATICI_SORGU.RC_QRY3902_GET_TCMB_SORGU(?,?)}";
		    Object inputValues[] = {BnsprType.NUMBER,iMap.getBigDecimal("BATCH_DETAY_ID"),
		    		                BnsprType.STRING,iMap.getString("SORGU_TURU")};		 
		    oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues));	  			
			List<?> ozetList=(List<?>) oMap.get("RESULTS");
			if(ozetList!=null){
				for(int i=0;i<ozetList.size();i++){
					func = "{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_NN_KREDI(?)}";
					inputValues = new Object[] {BnsprType.NUMBER,oMap.getBigDecimal("RESULTS",i,"ID")};									
					oMap.put("RESULTS", i, "KREDI_MODEL", DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues).get("RESULTS"));						
					func = "{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_CEK_GERCEK(?)}";
					oMap.put("RESULTS", i, "CEK_MODEL", DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues).get("RESULTS"));						
					func = "{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_CEK_MAHK(?)}";
					oMap.put("RESULTS", i, "MAHKEME_MODEL", DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues).get("RESULTS"));						
					func = "{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_PROT_SENET(?)}";
					oMap.put("RESULTS", i, "SENET_MODEL", DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues).get("RESULTS"));													
				}
			}
			return oMap;
		}
		catch (Exception e) {			
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_NEG_NIT_KREDI")
	public static GMMap getTcmbNegNitKredi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_NN_KREDI(?,?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			stmt.setString(i++, iMap.getString("HEPSINI_GOSTER"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return convertTableComboValuesToName(rSet);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_CEK_GERCEK")
	public static GMMap getTcmbCekGercek(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_CEK_GERCEK(?,?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			stmt.setString(i++, iMap.getString("HEPSINI_GOSTER"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return convertTableComboValuesToName(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_CEK_MAHKEME")
	public static GMMap getTcmbCekMahkeme(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_CEK_MAHK(?,?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			stmt.setString(i++, iMap.getString("HEPSINI_GOSTER"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return convertTableComboValuesToName(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_PROTESTOLU_SENET")
	public static GMMap getTcmbProtestoluSenet(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_PROT_SENET(?,?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			stmt.setString(i++, iMap.getString("HEPSINI_GOSTER"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return convertTableComboValuesToName(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_NEG_NIT_KREDI_DETAY")
	public static GMMap getTcmbNegNitKrediDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_NN_KREDI_D(?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY3902_GET_MUSTERI_BILGI")
	public static GMMap getGetMusteriBilgi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_MUSTERI_BILGI(?,?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("KIM_ICIN"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3902_GET_MUSTERI_BILGI_BY_BATCH_ID")
	public static GMMap getGetMusteriBilgiByBatchId(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func="{? = call PKG_SATICI_SORGU.RC_QRY3902_MUSTERI_BILGI(?,?)}";
			
			Object inputValues[] = {BnsprType.NUMBER,iMap.getBigDecimal("BATCH_ID"),
					                BnsprType.STRING,iMap.getString("KIM_ICIN")};   
		
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues));		
			
			if(oMap.size()>0) {
				GMMap tmpMap = oMap.getMap("RESULTS",0);
				oMap.clear();
				oMap.putAll(tmpMap);
			}		
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_PUAN")
	public static GMMap getGetTcmbPuan(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			GMMap oMap = new GMMap();
			stmt = conn.prepareCall("{call PKG_RC3902.get_tcmb_puan(?,?) }"); 
			
			stmt.setBigDecimal(1, iMap.getBigDecimal("KAYIT_ID"));
			stmt.registerOutParameter(2, -10);
			
			BigDecimal toplam = new BigDecimal(0);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(2);
			
			while(rSet.next()){
				oMap.put("P_"+rSet.getString("KRITER_KOD"), rSet.getString("PUAN"));
				toplam = toplam.add(rSet.getBigDecimal("PUAN"));
			}
			oMap.put("TOPLAM", toplam);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_CEK_GERCEK_DETAY")
	public static GMMap getTcmbCekGercekDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_TCMB_CEK_GERCEK_D(?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_CEK_TUZEL_DETAY")
	public static GMMap getTcmbCekGercekTuzelDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_TCMB_CEK_TUZEL_D(?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_CEK_MAHKEME_DETAY")
	public static GMMap getTcmbCekMahkemeDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_TCMB_CEK_MAHK_D(?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_PROTESTOLU_SENET_DETAY")
	public static GMMap getTcmbProtestoluSenetDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_TCMB_PROT_SENET_D(?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_PROTESTOLU_SENET_TUZEL_DETAY")
	public static GMMap getTcmbProtestoluSenetTuzelDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_TCMB_SENET_TUZEL_D(?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3903_GET_TCMB_SORGU_NO")
	public static GMMap getTcmbSorguNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			if(iMap.getString("AD").isEmpty() || iMap.getString("SOYAD").isEmpty()){
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "AD-SOYAD");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call pkg_ist_tcmb.ManuelTCMBSorgu(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setString(i++, iMap.getString("TC_KIMLIK_NO"));
			stmt.setString(i++, iMap.getString("VKN"));
			stmt.setString(i++, iMap.getString("AD"));
			stmt.setString(i++, iMap.getString("AD2"));
			stmt.setString(i++, iMap.getString("SOYAD"));
			stmt.setString(i++, iMap.getString("ONCEKI_SOYAD"));
			stmt.setString(i++, iMap.getString("ANNE_KIZLIK_SOYADI"));
			if(iMap.get("DOGUM_TARIHI")==null){
				stmt.setDate(i++, null);
				stmt.setBigDecimal(i++, null);
			}
			else {
				stmt.setDate(i++, new Date(iMap.getDate("DOGUM_TARIHI").getTime()));
				Calendar cal = Calendar.getInstance();
				cal.setTime(iMap.getDate("DOGUM_TARIHI"));
				stmt.setBigDecimal(i++, new BigDecimal(cal.get(Calendar.YEAR)));
			}
			stmt.setString(i++, iMap.getString("DOGUM_YERI"));
			stmt.setString(i++, iMap.getString("NUFUS_CUZDAN_SERI_NO"));
			stmt.setString(i++, iMap.getString("NUFUS_CUZDAN_SIRA_NO"));
			stmt.setString(i++, iMap.getString("ANNE_ADI"));
			stmt.setString(i++, iMap.getString("BABA_ADI"));
			stmt.setString(i++, iMap.getString("SENET_IL"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, (iMap.getString("EV_ADRESI")+" "+DALUtil.getResult("select ilce_adi from gnl_ilce_kod_pr where il_kod = '"+iMap.getString("EV_IL")+"' and ilce_kod ='"+iMap.getString("EV_ILCE")+"'")));
			stmt.setString(i++, (iMap.getString("IS_ADRESI")+" "+DALUtil.getResult("select ilce_adi from gnl_ilce_kod_pr where il_kod = '"+iMap.getString("IS_IL")+"' and ilce_kod ='"+iMap.getString("IS_ILCE")+"'")));
			stmt.setString(i++, iMap.getString("EV_IL"));
            stmt.setString(i++, iMap.getString("IS_IL"));
            stmt.setString(i++, null); //son senet id
            stmt.setString(i++, null); //son �ek id
            stmt.setString(i++, null); //son kredi id
            stmt.setString(i++, null); //son mahkeme id
            if (iMap.getDate("BAS_TARIH") != null){ //sorgu ba�lang�� tarihi
                stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
            }
            else {
                stmt.setDate(i++, null);
            }
			
			stmt.execute();

			iMap.clear();
			iMap.put("SORGU_NO", stmt.getBigDecimal(1));
			
			return iMap;
		}catch (ParseException e) {
			throw new GMRuntimeException(0,e);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY3903_GET_TCMB_SORGU_MANUEL")
	public static GMMap getTcmbSorguManuel(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_RC3902.get_tcmb_sorgu_manuel(?,?)}");
			
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SORGU_NO"));
			stmt.registerOutParameter(i, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(i);
			
			return DALUtil.rSetResults(rSet,"RESULTS");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY3903_GET_ILCE_LIST")
	public static GMMap getIlceList(GMMap iMap){
		return DALUtil.fillComboBox(iMap, "ILCE_LIST", true, "select ilce_kod,ilce_adi from gnl_ilce_kod_pr where il_kod = '"+iMap.getString("IL_KOD")+"' order by 2");
	}
	
	@GraymoundService("BNSPR_QRY3903_CONVERT_DATE")
	public static GMMap getConvertDate(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
			Calendar cal = Calendar.getInstance();
			cal.setTime(iMap.getDate("DOGUM_TARIH"));
			simpleDateFormat.setCalendar(cal);
			oMap.put("DOGUM_TARIH", simpleDateFormat.format(cal.getTime()));
			oMap.put("DOGUM_YIL", cal.get(Calendar.YEAR));
			return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	@GraymoundService("BNSPR_QRY3903_DECODE_SENET_DATA")
	public static GMMap getDecodeSenetData(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			
			oMap.put("EV_ADRESI", (iMap.getString("EV_ADRESI")+" "+DALUtil.getResult("select ilce_adi from gnl_ilce_kod_pr where il_kod = '"+iMap.getString("EV_IL")+"' and ilce_kod ='"+iMap.getString("EV_ILCE")+"'") + " "+DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod = '"+iMap.getString("EV_IL")+"'")));
			oMap.put("IS_ADRESI", (iMap.getString("IS_ADRESI")+" "+DALUtil.getResult("select ilce_adi from gnl_ilce_kod_pr where il_kod = '"+iMap.getString("IS_IL")+"' and ilce_kod ='"+iMap.getString("IS_ILCE")+"'") + " "+DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod = '"+iMap.getString("IS_IL")+"'")));
			oMap.put("SENET_IL", DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod = '"+iMap.getString("SENET_IL")+"'"));
			oMap.put("EV_IL", DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod = '"+iMap.getString("EV_IL")+"'"));
			oMap.put("IS_IL", DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod = '"+iMap.getString("IS_IL")+"'"));
			return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	@GraymoundService("BNSPR_QRY3903_DECODE_CEK_GERCEK_DATA")
	public static GMMap getDecodeCekGercekData(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			
			oMap.put("EV_ADRESI", (iMap.getString("EV_ADRESI")+" "+DALUtil.getResult("select ilce_adi from gnl_ilce_kod_pr where il_kod = '"+iMap.getString("EV_IL")+"' and ilce_kod ='"+iMap.getString("EV_ILCE")+"'") + " "+DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod = '"+iMap.getString("EV_IL")+"'")));
			oMap.put("IS_ADRESI", (iMap.getString("IS_ADRESI")+" "+DALUtil.getResult("select ilce_adi from gnl_ilce_kod_pr where il_kod = '"+iMap.getString("IS_IL")+"' and ilce_kod ='"+iMap.getString("IS_ILCE")+"'") + " "+DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod = '"+iMap.getString("IS_IL")+"'")));
			oMap.put("ADRES_IL", DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod = '"+iMap.getString("ADRES_IL")+"'"));
			oMap.put("ADRES_IL_IS", DALUtil.getResult("select il_adi from gnl_il_kod_pr where kod = '"+iMap.getString("IS_IL")+"'"));
			
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");
			Calendar cal = Calendar.getInstance();
			if(iMap.get("DOGUM_TARIH")!=null){
				cal.setTime(iMap.getDate("DOGUM_TARIH"));
				simpleDateFormat.setCalendar(cal);
				oMap.put("DOGUM_TARIH", simpleDateFormat.format(cal.getTime()));
				oMap.put("DOGUM_YIL", cal.get(Calendar.YEAR));
			}
			return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	@GraymoundService("BNSPR_QRY3902_GET_TCMB_PUAN_COLOR")
	public static GMMap getGetTcmbPuanColor(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			GMMap oMap = new GMMap();
			StringBuilder query = new StringBuilder();

			query.append(" select s.kriter_kod ");
			query.append("from ist_tcmb_sorgu_detay s ");
			query.append("where s.isttcmbkayit_id = ?");
			
			stmt = conn.prepareStatement(query.toString());

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KAYIT_ID"));
			rSet = stmt.executeQuery();
			Color background = new Color(135,135,255);
			while(rSet.next()){
				oMap.put("P_"+rSet.getString(1), background);
			}
			background = new Color(255,255,5);
			oMap.put("TOPLAM", background);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3927_GET_KARA_LISTE")
	public static GMMap getTcmbKaraListe(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3927.RC_QRY3927_GET_KARA_LISTE(?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet,"RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3927_GET_KARA_LISTE_DETAY")
	public static GMMap getKaraListeDetay(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3927.RC_QRY3927_GET_KARALISTE_DETAY(?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
	
	@GraymoundService("BNSPR_QRY3927_GET_KARA_LISTE_TUZEL")
	public static GMMap getKaraListeTuzel(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3927.RC_QRY3927_GET_KARALISTE_TUZEL(?)}");
			int i =1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetMap(rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}		
	}

    @GraymoundService("BNSPR_QRY3902_GET_TCMB_KARALISTE_TUZEL")
    public static GMMap getTcmbKaraListeTuzel(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_RC3902.RC_QRY3902_GET_TCMB_KLISTE_TZL(?,?)}");
            int i =1;   
            stmt.registerOutParameter(i++, -10); //ref cursor
            stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
            stmt.setString(i++, iMap.getString("HEPSINI_GOSTER"));
            
            stmt.execute();
            
            rSet = (ResultSet)stmt.getObject(1);
            
            return convertTableComboValuesToName(rSet);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
	private static GMMap  convertTableComboValuesToName(ResultSet rSet){
	    
	      GMMap oMap =  DALUtil.rSetResults(rSet,"RESULTS");
          GMMap sMap = new  GMMap();
          GMServiceExecuter.call("BNSPR_QRY3902_GET_INITIAL_COMBO_VALUES", sMap);
          
          List<Map<String,Object>> oList =  (List<Map<String, Object>>) oMap.get("RESULTS");
          List<Map<String,Object>> sList =  (List<Map<String, Object>>) sMap.get("DURUM");
          
          if(oList != null){
              for(int index= 0 ; index< oList.size() ; index++){
                      String name = null;
                      if(sList != null) {
                          for(int sayac=0 ; sayac < sList.size() ; sayac++){
                              if( sList.get(sayac).get("VALUE") != null  &&  sList.get(sayac).get("VALUE").equals(oList.get(index).get("DURUM")) ){
                                  name = (String) sList.get(sayac).get("NAME");
                              }
                          }
                     }
                    oList.get(index).put("DURUM_NAME", name);
              }
          }
          
          return oMap;
	}
}
