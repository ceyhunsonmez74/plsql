package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruTesekkurTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruTesekkurTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3124Services {
	
	@GraymoundService("BNSPR_TRN3124_GET_COMBOBOX_INITIAL_VALUE")
	public static GMMap getComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();

			DALUtil.fillComboBox(oMap, "KANAL", true, "select b.kanal_kodu, pkg_genel_pr.kanal_adi(b.kanal_kodu) kanal_adi from bir_basvuru b group by b.kanal_kodu order by 1");
			
			iMap.put("KOD", "TESEKKUR_MEKTUBU");
			iMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("GONDERIMDURUMU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN3124_GET_KREDI_TURU")
	public static GMMap getKrediTuru(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			
			DALUtil.fillComboBox(oMap, "KREDITURU", true, "select distinct t.kod ,t.aciklama from v_ml_bir_krd_tur t,bir_kullandirim b where  b.kanal_kodu =" +iMap.getString("KANALADI")+" and t.kod = b.krd_tur and b.krd_tur = t.kod order by 1");

			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3124_GET_KAMPANYA_URUN_ADI")
	public static GMMap getKampanyaUrunAdi(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			
			DALUtil.fillComboBox(oMap,"KAMPANYAURUNADI", true, "select distinct c.kod, c.aciklama from v_ml_bir_krd_tur t,bir_kullandirim b ,BIR_KAMPANYA c  where t.kod =b.krd_tur   and b.krd_tur = " +iMap.getString("KREDITURU")+" and b.kanal_kodu = " +iMap.getString("KANAL")+"   and c.kod = b.kamp_kod");
			
			//select distinct c.aciklama ,t.kod KREDI_KODU,t.aciklama  KREDI_ACIKLAMA from bir_krd_tur t,bir_kullandirim b ,BIR_KAMPANYA c  where t.kod =b.krd_tur   and b.krd_tur = ?1? and b.kanal_kodu = ?2? and c.kod = b.kamp_kod;
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN3124_GET_MEKTUP_TABLO")
	public static GMMap BNSPR_TRN3124_GET_MEKTUP_TABLO(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3124.Get_Tesekkur_Mektubu(?,?,?,?,?,?,?,?,?,?,?,?)}"); //PROSEDUR
		
			int i = 0;
			stmt.setBigDecimal	(++i, iMap.getBigDecimal("BASVURUNO1"));
			stmt.setBigDecimal	(++i, iMap.getBigDecimal("BASVURUNO2"));
			stmt.setBigDecimal	(++i, iMap.getBigDecimal("TCKN"));
			stmt.setBigDecimal	(++i, iMap.getBigDecimal("MUSTERINO"));	
			
			
			if(iMap.get("TARIH1")!=null)
				stmt.setDate(++i, new Date(iMap.getDate("TARIH1").getTime()));
			else 
				stmt.setDate(++i, null);
			
			
			if(iMap.get("TARIH2")!=null)
				stmt.setDate(++i, new Date(iMap.getDate("TARIH2").getTime()));
			else 
				stmt.setDate(++i, null);
			
			stmt.setString(++i, iMap.getString("KANALADI"));	
			stmt.setString(++i, iMap.getString("KREDITURU"));	
			stmt.setString(++i, iMap.getString("KAMPANYAURUNADI"));	
			stmt.setString(++i, iMap.getString("GONDERIMDURUMU"));
			stmt.setBigDecimal(++i, iMap.getBigDecimal("HESAPNO"));
			
			stmt.registerOutParameter(++i, -10);
			stmt.execute();
			//stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(i);
			return DALUtil.rSetResults(rSet, "TABLO");

		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3124_BASTIRILAN_MEKTUPLAR")
	public static Map<?, ?> trn2600Save(GMMap iMap) {
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			//TRX_NO = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO",oMap).getBigDecimal("TRX_NO");
			
			String 	tableName 	= "TESEKKURTABLO";
			//BirSaticiLimitTx birSaticiLimitTx =(BirSaticiLimitTx)session_NEW.get(BirSaticiLimitTx.class, iMap.getBigDecimal("TRX_NO"));
			List<?> list = (List<?>) iMap.get(tableName);
			
			for (int i=0;i<list.size();i++){
				
				
				if (iMap.getBigDecimal(tableName, i, "SEC").intValue() == 1){
					BirBasvuruTesekkurTxId id = new BirBasvuruTesekkurTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setBasvuruNo(iMap.getBigDecimal(tableName, i, "BASVURUNO"));
					
					BirBasvuruTesekkurTx birBasvuruTesekkurTx = (BirBasvuruTesekkurTx)session.get(BirBasvuruTesekkurTx.class, id);
					//BirBasvuruTesekkurTx birBasvuruTesekkurTx = null;
					if(birBasvuruTesekkurTx == null) {
						birBasvuruTesekkurTx = new BirBasvuruTesekkurTx();
					}
					birBasvuruTesekkurTx.setId(id);
					birBasvuruTesekkurTx.setAdresMusteriden(iMap.getBoolean(tableName, i, "ADRES_MUSTERIDEN") ? "E" : "H");
					session.saveOrUpdate(birBasvuruTesekkurTx);  //G�D�YOR YUKARIDAKILERI TX TABLOSUNA KAYIT EDIYOR
				}
		      
			}
			session.flush();   //BURADA YUKARIDAKI KOMUTU �CRA ED�YOR.
			
			iMap.put("TRX_NAME", "3124");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
			//GMServiceExecuter.e
			//BNSPR_TRX_SEND_TRANSACTION -> ANA TABLOYA YAZAR TX TEN ONAY EKRANINDAN SONRA	
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN3124_GET_INFO")
	public static Map<?, ?> trn3124GetInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			BirBasvuru birBasvuru;
			
			List<?> list = (List<?>) session.createCriteria(BirBasvuruTesekkurTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			String 	tableName	= "TESEKKURTABLO";
			int row = 0;
			
			String kredi_tur;
			String kampanya_urun_adi;
			String basvuru_tarihi;
			String isim_soyisim;
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirBasvuruTesekkurTx birBasvuruTesekkurTx = (BirBasvuruTesekkurTx) iterator.next();
				
				 birBasvuru = (BirBasvuru)session.createCriteria(BirBasvuru.class)
				.add(Restrictions.eq("basvuruNo", birBasvuruTesekkurTx.getId().getBasvuruNo() ))
				.uniqueResult();

				 
				kredi_tur = DALUtil.getResult("select v.aciklama from v_ml_bir_krd_tur v where v.kod ="+ birBasvuru.getKrediTur() +"");
				kampanya_urun_adi =  DALUtil.getResult("select g.aciklama from BIR_KAMPANYA g where g.kod = "+ birBasvuru.getKampKod() +"");
				
				basvuru_tarihi = DALUtil.getResult("select b.rec_date from bir_basvuru b where b.basvuru_no = "+ birBasvuru.getBasvuruNo()+"");
				isim_soyisim  =  DALUtil.getResult("select pkg_musteri.unvan("+birBasvuru.getMusteriNo()+") from dual");
				 
				oMap.put(tableName, row, "ADISOYADI", isim_soyisim);
				oMap.put(tableName, row, "BASVURUNO", birBasvuru.getBasvuruNo());
				oMap.put(tableName, row, "BASVURUTARIHI", basvuru_tarihi);
				
				oMap.put(tableName, row, "KAMPANYAURUNADI",kampanya_urun_adi);
				oMap.put(tableName, row, "KREDITURU",kredi_tur);
				oMap.put(tableName, row, "MUSTERINO", birBasvuru.getMusteriNo());
				oMap.put(tableName, row, "ONAYLANANKREDIMIKTARI", birBasvuru.getTutar());
				oMap.put(tableName, row, "SEC", 1);
				oMap.put(tableName, row, "TCKN", birBasvuru.getTcKimlikNo() );
				row++;
			}
 			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
