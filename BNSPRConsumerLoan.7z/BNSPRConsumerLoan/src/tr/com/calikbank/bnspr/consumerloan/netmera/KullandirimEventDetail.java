package tr.com.calikbank.bnspr.consumerloan.netmera;

import java.lang.reflect.Field;

import com.google.gson.annotations.SerializedName;
import com.graymound.util.GMRuntimeException;

public class KullandirimEventDetail implements INullController {

	@SerializedName("extId")
	private String tcKimlikNo;

	@SerializedName("name")
	private String name;
	
	@SerializedName("kullanimTuru")
	private int kullanimTuru;
	
	@SerializedName("spotMu")
	private String spotMu;
	
	@SerializedName("segment")
	private String segment;
	
	@SerializedName("onOnayliMi")
	private String onOnayliMi;
	
	@SerializedName("kullandirimTutar")
	private Float kullandirimTutar;
	
	@SerializedName("sigortaliMi")
	private String sigortaliMi;
	
	public String getTcKimlikNo() {
		return tcKimlikNo;
	}

	public void setTcKimlikNo(String tcKimlikNo) {
		this.tcKimlikNo = tcKimlikNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getKullanimTuru() {
		return kullanimTuru;
	}

	public void setKullanimTuru(int kullanimTuru) {
		this.kullanimTuru = kullanimTuru;
	}

	public String getSpotMu() {
		return spotMu;
	}

	public void setSpotMu(String spotMu) {
		this.spotMu = spotMu;
	}

	public String getSegment() {
		return segment;
	}

	public void setSegment(String segment) {
		this.segment = segment;
	}

	public String getOnOnayliMi() {
		return onOnayliMi;
	}

	public void setOnOnayliMi(String onOnayliMi) {
		this.onOnayliMi = onOnayliMi;
	}

	public Float getKullandirimTutar() {
		return kullandirimTutar;
	}

	public void setKullandirimTutar(Float kullandirimTutar) {
		this.kullandirimTutar = kullandirimTutar;
	}

	public String getSigortaliMi() {
		return sigortaliMi;
	}

	public void setSigortaliMi(String sigortaliMi) {
		this.sigortaliMi = sigortaliMi;
	}

	@Override
	public String toString() {
		return "ClassPojo [extId = " + tcKimlikNo + "]";
	}

	public void checkNull() {
		Field fields[] = this.getClass().getDeclaredFields();
		for (Field f : fields) {
			try {
				Object value = f.get(this);
				if (value == null) {
					throw new GMRuntimeException(99, f.getName().toUpperCase()
							+ " degeri bos olamaz");
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				throw new GMRuntimeException(99, e.getMessage());
			}

		}
	}
}
