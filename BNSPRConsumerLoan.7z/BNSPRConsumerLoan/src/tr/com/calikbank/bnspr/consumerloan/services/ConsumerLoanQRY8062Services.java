package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY8062Services {

	@GraymoundService("BNSPR_GET_BIR_SATICI_BASVURULAR")
	public static GMMap sorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		   
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC8062.QRY8062_sorgula(?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setDate(i++, iMap.getDate("BASVURU_BAS_TAR") != null ? new Date(iMap.getDate("BASVURU_BAS_TAR").getTime()) : null);
			stmt.setDate(i++, iMap.getDate("BASVURU_BIT_TAR") != null ? new Date(iMap.getDate("BASVURU_BIT_TAR").getTime()) : null);			
			stmt.execute();
			ResultSet basvurular = (ResultSet) stmt.getObject(1) ;
			
			int j = 0;
			while (basvurular.next()) {
				oMap.put("BASVURU_LIST", j, "AGENT_ADI", basvurular.getString("AGENT_ADI"));				
				oMap.put("BASVURU_LIST", j, "BASVURU_NO", basvurular.getString("BASVURU_NO"));
				oMap.put("BASVURU_LIST", j, "BASVURU_TARIH", basvurular.getString("BASVURU_TARIH"));
				oMap.put("BASVURU_LIST", j, "DURUM", basvurular.getString("DURUM"));
				oMap.put("BASVURU_LIST", j, "TCKN", basvurular.getString("TCKN"));
				oMap.put("BASVURU_LIST", j, "VERGI_NO", basvurular.getString("VERGI_NO"));
				
				j++;
			}
			
			oMap.put("KAYIT_SAYI", j);
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}		
	}
	
		
}
