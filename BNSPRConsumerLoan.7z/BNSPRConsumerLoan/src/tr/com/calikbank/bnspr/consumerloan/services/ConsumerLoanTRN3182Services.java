package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.axis.encoding.Base64;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.SystemUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruBelge;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeKontDtyTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeKontDtyTxId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTxId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruMustGuncelleTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruMustGuncelleTxId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruTasit;
import tr.com.aktifbank.bnspr.dao.BirKampanyaSegment;
import tr.com.aktifbank.bnspr.dao.GnlBelgeKodPr;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.KryKuryeArsivGirisDetay;
import tr.com.aktifbank.bnspr.dao.MuhHesapRezerv;
import tr.com.aktifbank.bnspr.pdfViewerPanelBean.ByteArrayType;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruBelgeKontrolTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruBelgeKontrolTxId;
import tr.com.calikbank.bnspr.dao.BirBasvuruKefil;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlik;
import tr.com.calikbank.bnspr.dao.BirKampanya;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsis;
import tr.com.calikbank.bnspr.dao.GnlMusteriImaj;
import tr.com.calikbank.bnspr.dao.GnlMusteriImajId;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.StringUtil;
import tr.com.calikbank.integration.ftp.AktifSFTPClient;
import tr.com.calikbank.integration.ftp.FtpClientException;
import tr.com.calikbank.integration.webservices.kps.KPSUtil;
import tr.gov.nvi.kpsv2.model.TarihModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.BilesikKutukModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.TCCuzdanBilgisiModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.TCKKModel;
import tr.gov.nvi.kpsv2.model.bilesikkutuk.TCKisiBilgisiModel;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.lowagie.text.Document;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfImportedPage;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;

@SuppressWarnings("deprecation")
public class ConsumerLoanTRN3182Services {

	private static final Logger logger = Logger.getLogger(ConsumerLoanTRN3182Services.class);
	public static final String BELGE_ROOT_DIR = "BIREYSEL_BELGE";

	private static final Logger LOGGER = Logger.getLogger(ConsumerLoanTRN3182Services.class);

	/**
	 * Ekran acilisinda kullanilan degerleri doner.
	 * 
	 * @author murat.el
	 * @since PY-10681
	 * @param iMap
	 *            - Input Yok<br>
	 * @return oMap - Ekran acilis degerleri<br>
	 *         <li>KREDI_TURU - Kredi tur listesi <li>DOVIZ_TURU - Doviz tur listesi <li>BIR_BASVURU_BELGE_ALINMA_ADIM - Belge alinma adim listesi <li>DST_KAZANIM_KANAL - Bayi kazanim kanal listesi <li>BELGE_KONTROL - <li>BELGE_KONTROL_KOD -
	 */
	@GraymoundService("BNSPR_TRN3182_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		//
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;

		try {
			StringBuilder query = new StringBuilder();
			// Kredi Turu
			query.append("SELECT kod,aciklama FROM bir_krd_tur order by 1");
			DALUtil.fillComboBox(oMap, "KREDI_TURU", true, query.toString());
			// Doviz Turu
			query.delete(0, query.length());
			query.append("SELECT kod,aciklama FROM v_ml_gnl_doviz_kod_pr where gecerli = 'E' order by sira_no");
			DALUtil.fillComboBox(oMap, "DOVIZ_TURU", true, query.toString());
			// Banka Tarih
			//oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_BANKA_TARIH", iMap));
			oMap.put("BANKA_TARIH", DateUtils.truncate(new java.util.Date(), Calendar.DATE));
			// Belge Alinma Adim
			oMap.putAll(getParameterList("BIR_BASVURU_BELGE_ALINMA_ADIM", "BIR_BASVURU_BELGE_ALINMA_ADIM", null, null));
			// Bayi Kazanim Kanal
			oMap.putAll(getParameterList("DST_KAZANIM_KANAL", "BAYI_KAZANIM_KANAL", Constants.EVET, null));
			// Calisma Sekli
			oMap.putAll(getParameterList("CALISMA_SEKLI_KOD", "CALISMA_SEKLI_KOD", null, null));
			// Var Yok
			oMap.putAll(getParameterList("VAR_YOK", "VAR_YOK", null, null));
			// Evet Hayir
			oMap.putAll(getParameterList("EVET_HAYIR", "EVET_HAYIR", null, null));
			// Gelen Belge
			oMap.putAll(getParameterList("GNL_BELGE_GELEN_EVRAK", "GNL_BELGE_GELEN_EVRAK", Constants.EVET, null));
			// Belge Onay
			oMap.putAll(getParameterList("BIR_BELGE_ONAY_KOD", "BIR_BELGE_ONAY_KOD", null, null));
			// Belge Hata
			oMap.putAll(getParameterList("BIR_BELGE_HATA", "BIR_BELGE_HATA", Constants.EVET, null));
			// Belge Kontrol
			GMMap belgeKontrolKodMap = getParameterList("BELGE_KONTROL_KOD", "BELGE_KONTROL_KOD", null, null);
			oMap.putAll(belgeKontrolKodMap);

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select a.key1,b.key1 from gnl_param_text a, gnl_param_text b where  a.key1=b.key2 and a.kod='BELGE_KONTROL_KOD' and b.kod='BIR_BELGE_HATA'");
			rSet = stmt.executeQuery();
			// Degerleri al
			GMMap hataKodMap = new GMMap();
			while (rSet.next()) {
				hataKodMap.put(rSet.getString(1), rSet.getString(2));
			}

			for (int i = 0; i < belgeKontrolKodMap.getSize("BELGE_KONTROL_KOD"); i++) {
				if (hataKodMap.containsKey(belgeKontrolKodMap.get("BELGE_KONTROL_KOD", i, "VALUE"))) {
					GuimlUtil.wrapMyCombo(oMap, "BELGE_KONTROL", belgeKontrolKodMap.getString("BELGE_KONTROL_KOD", i, "VALUE"), "E");
				}
				else {
					GuimlUtil.wrapMyCombo(oMap, "BELGE_KONTROL", belgeKontrolKodMap.getString("BELGE_KONTROL_KOD", i, "VALUE"), "H");
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	private static GMMap getParameterList(String tableName, String kod, String addOption, String key) {
		GMMap inMap = new GMMap();
		GMMap outMap = new GMMap();

		try {
			// Default RESULTS
			if (tableName != null) {
				inMap.put("TABLE_NAME", tableName);
			}
			// Default null, E:Bos, Hepsi:Hepsi
			if (addOption != null) {
				inMap.put("ADD_EMPTY_KEY", addOption);
			}
			// Dolu Olmali
			if (kod != null) {
				inMap.put("KOD", kod);
			}
			// Default null
			if (key != null) {
				inMap.put("KEY2", key);
			}

			outMap = GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", inMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return outMap;
	}

	@GraymoundService("BNSPR_TRN3182_GET_BELGE_LIST")
	public static GMMap getBelgeList(GMMap iMap) {
		try {
			iMap.put("TARIH", iMap.getDate("SOZLESME_TARIHI"));
			iMap.put("GUN", iMap.getBigDecimal("ORJ_EVRAK_GONDERIM_SURESI") == null ? BigDecimal.ZERO : iMap.getBigDecimal("ORJ_EVRAK_GONDERIM_SURESI"));
			iMap.put("BELGE_TAMAMLAMA_TARIHI", GMServiceExecuter.execute("BNSPR_COMMON_SONRAKI_GUN", iMap).get("TARIH"));

			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).addOrder(Order.desc("id.kimden")).list();

			GMMap oMap = new GMMap();
			String tableName = "BELGELER";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) iterator.next();
				oMap.put(tableName, row, "BASVURU_NO", birBasvuruBelge.getId().getBasvuruNo()); // needed for BPM flow
				oMap.put(tableName, row, "BELGE_KOD", birBasvuruBelge.getId().getDokumanKod());
				oMap.put(tableName, row, "KIMDEN", LovHelper.diLov(birBasvuruBelge.getId().getKimden(), "3181/LOV_BASVURU_KISI", "ACIKLAMA"));
				oMap.put(tableName, row, "KIMDEN_KOD", birBasvuruBelge.getId().getKimden());
				HashMap<?, ?> lovMap = LovHelper.diLovAll(birBasvuruBelge.getId().getDokumanKod(), "3182/LOV_BELGE_KOD");
				oMap.put(tableName, row, "BELGE_ADI", lovMap.get("ACIKLAMA"));
				oMap.put(tableName, row, "DOKUMAN_TIP_KOD", lovMap.get("DOKUMAN_TIP_KOD"));
				oMap.put(tableName, row, "DOSYA_ADI", birBasvuruBelge.getBelgeAdi());
				oMap.put(tableName, row, "DOSYA_YOL", birBasvuruBelge.getBelgeYeri());

				if (birBasvuruBelge.getBelgeYeri() != null) {
					try {
						String dokumanAdi = birBasvuruBelge.getBelgeYeri();
						dokumanAdi = dokumanAdi.substring(dokumanAdi.lastIndexOf("/") + 1, dokumanAdi.length());
						oMap.put(tableName, row, "URL", GMServiceExecuter.call("DYS_CMIS_GET_CUSTOMER_DOC_INFO_BY_FILENAME", new GMMap().put("DOKUMAN_ADI", dokumanAdi).put("DOKUMAN_CLASS", "Musteri")).getString("DOKUMAN_LINK"));
					}
					catch (Exception e) {
						// Hata alirsa butun islemi kesmesin
						e.printStackTrace();
					}
				}

				oMap.put(tableName, row, "BELGE_ESKI_STATU", birBasvuruBelge.getBelgeKontrol() == null ? "" : birBasvuruBelge.getBelgeKontrol());
				oMap.put(tableName, row, "BELGE_KONTROL", birBasvuruBelge.getBelgeKontrol() == null ? "" : birBasvuruBelge.getBelgeKontrol());
				oMap.put(tableName, row, "BELGE_HATA", birBasvuruBelge.getBelgeHata() == null ? "" : birBasvuruBelge.getBelgeHata());
				oMap.put(tableName, row, "GELIS_TARIHI", birBasvuruBelge.getBelgeGelisTarihi());
				oMap.put(tableName, row, "ORJINAL_EVRAK_MI", GuimlUtil.convertToCheckBoxValue(birBasvuruBelge.getOrjinalEvrakMi()));
				oMap.put(tableName, row, "KAYIT", "ESKI");
				oMap.put(tableName, row, "BELGE_TAMAMLAMA_TARIHI", iMap.getDate("BELGE_TAMAMLAMA_TARIHI"));
				oMap.put(tableName, row, "KONTROL_NEDENI", birBasvuruBelge.getKontrolNedeni());
				oMap.put(tableName, row, "BARKOD_NUMARASI", birBasvuruBelge.getBarkodNumarasi());
				oMap.put(tableName, row, "ONAYLI_MI", birBasvuruBelge.getOnayliMi());
				oMap.put(tableName, row, "UYUMSUZ_ACIKLAMA", birBasvuruBelge.getUyumsuzAciklama());
				oMap.put(tableName, row, "BELGE_ALINMA_ADIMI", birBasvuruBelge.getBelgeAlinmaAdim() == null ? "S" : birBasvuruBelge.getBelgeAlinmaAdim());

				Object inputs[] = { BnsprType.NUMBER, birBasvuruBelge.getId().getBasvuruNo(), BnsprType.NUMBER, new BigDecimal(birBasvuruBelge.getId().getDokumanKod()) };
				Object outputs[] = { BnsprType.STRING, "BELGE_GELDI", BnsprType.STRING, "BELGE_ORJINAL" };
				GMMap resultMap = (GMMap) DALUtil.callOracleProcedure("{call PKG_TRN3182.getBelgeKuryeArsivBilgileri(?,?,?,?)}", inputs, outputs);
				oMap.put(tableName, row, "BELGE_GELDI", resultMap.getString("BELGE_GELDI"));
				oMap.put(tableName, row, "BELGE_ORJINAL", resultMap.getString("BELGE_ORJINAL"));

				GMMap pMap = new GMMap();
				pMap.put("KOD", "BELGE_SGK_BILGI");
				pMap.put("KEY", birBasvuruBelge.getId().getDokumanKod());
				String isSgkBelge = GMServiceExecuter.call("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", pMap).getString("IS_EXIST");
				oMap.put(tableName, row, "IS_SGK_BELGE", isSgkBelge);
				if ("E".equals(isSgkBelge)) {
					oMap.put(tableName, row, "AYLIK_UCRET", birBasvuruBelge.getAylikUcret());
					oMap.put(tableName, row, "ISE_BASLAMA_TARIHI", birBasvuruBelge.getIseBaslamaTarihi());
					oMap.put(tableName, row, "ISYERI_ADI", birBasvuruBelge.getIsyeriAdi());
					oMap.put(tableName, row, "ISYERI_ADRESI", birBasvuruBelge.getIsyeriAdresi());
				}

				pMap.clear();
				pMap.put("PARAMETRE", "BIR_ORJ_BEKLENMEYEN_BELGELER");
				String orjinalBeklenmeyen = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", pMap).getString("DEGER", "-1");
				oMap.put(tableName, row, "IS_ORJINAL_BEKLENMEYEN", orjinalBeklenmeyen.contains("-" + birBasvuruBelge.getId().getDokumanKod() + "-" ) ? "E" : "H");
				row++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3182_CHECK_DOCS_APPROVED")
	public static GMMap checkAllDocListIsApproved(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "BELGELER";
		boolean otomatikKullandir = true;

		for (int row = 0; row < iMap.getSize(tableName); row++) {
			if (!"1".equalsIgnoreCase(iMap.getString(tableName, row, "BELGE_KONTROL")) && "S".equalsIgnoreCase(iMap.getString(tableName, row, "BELGE_ALINMA_ADIMI"))) {
				otomatikKullandir = false;
				break;
			}
		}

		oMap.put("OTO_KULLANDIR", otomatikKullandir);

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3182_GET_BELGE_KONTROL_LIST")
	public static GMMap getBelgeKontrolList(GMMap iMap) {
		GMMap oMap = new GMMap();

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3182.get_belge_kontrol_list(?,?,?,?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(4, iMap.getString("BELGE_KOD"));
			stmt.setString(5, iMap.getString("CALISMA_SEKLI"));
			stmt.setString(6, iMap.getString("GELEN_BELGE_KOD"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "BELGE_KONTROL_LIST"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3182_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap hashMap = new GMMap();
			GMMap kontrolNameMap = new GMMap();
			GMMap hataNameMap = new GMMap();
			GMMap sMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select a.key1,b.key1,a.text,b.text from gnl_param_text a, gnl_param_text b where  a.key1=b.key2 and a.kod='BELGE_KONTROL_KOD' and b.kod='BIR_BELGE_HATA'");
			rSet = stmt.executeQuery();

			while (rSet.next()) {
				hashMap.put(rSet.getString(2), rSet.getString(1));
				kontrolNameMap.put(rSet.getString(1), rSet.getString(3));
				hataNameMap.put(rSet.getString(2), rSet.getString(4));
			}

			for (int i = 0; i < iMap.getSize("BELGELER"); i++) {
				if (!"".equals(iMap.getString("BELGELER", i, "BELGE_HATA")) && iMap.getString("BELGELER", i, "BELGE_HATA") != null) {
					if (!hashMap.getString(iMap.getString("BELGELER", i, "BELGE_HATA")).equals(iMap.getString("BELGELER", i, "BELGE_KONTROL"))) {
						sMap.clear();
						sMap.put("HATA_NO", new BigDecimal(1848));
						sMap.put("P1", kontrolNameMap.getString(iMap.getString("BELGELER", i, "BELGE_KONTROL")));
						sMap.put("P2", hataNameMap.getString(iMap.getString("BELGELER", i, "BELGE_HATA")));
						return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
					}
				}
				else {
					if (!"".equals(iMap.getString("BELGELER", i, "BELGE_KONTROL")) && iMap.getString("BELGELER", i, "BELGE_KONTROL") != null && hashMap.containsValue(iMap.getString("BELGELER", i, "BELGE_KONTROL"))) {
						sMap.clear();
						sMap.put("HATA_NO", new BigDecimal(1848));
						sMap.put("P1", kontrolNameMap.getString(iMap.getString("BELGELER", i, "BELGE_KONTROL")));
						sMap.put("P2", "bo�");
						return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
					}
				}
			}

			Session session = DAOSession.getSession("BNSPRDal");

			BirBasvuruBelgeKontrolTx birBasvuruBelgeKontrolTx = (BirBasvuruBelgeKontrolTx) session.createCriteria(BirBasvuruBelgeKontrolTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			BirBasvuruBelgeKontrolTxId id = new BirBasvuruBelgeKontrolTxId();
			if (birBasvuruBelgeKontrolTx == null) {
				birBasvuruBelgeKontrolTx = new BirBasvuruBelgeKontrolTx();
			}
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBasvuruBelgeKontrolTx.setId(id);
			birBasvuruBelgeKontrolTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
			birBasvuruBelgeKontrolTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			birBasvuruBelgeKontrolTx.setMusteriEslestirme(iMap.getBoolean("MUSTERI_ESLESTIRME") ? "E" : "H");
			birBasvuruBelgeKontrolTx.setOtomatikKullandirim(iMap.getBoolean("OTOMATIK_KULLANDIRIM") ? "E" : "H");
			birBasvuruBelgeKontrolTx.setIzinliPazarlama(iMap.getBoolean("IZINLI_PAZARLAMA") ? "E" : "H");
			/** TY-6797 TY-Kredi belgelerinin barkod numars� ve /veya her belge i�in her bas�mda �retilecek bir numara ile kontrol edilmesi */
			birBasvuruBelgeKontrolTx.setSozlesmeNumarasiAyniMiEh(iMap.getBoolean("SOZLESME_NUMARASI_AYNI_MI") ? "E" : "H");

			int belgeKontrol = 0;
			int sahteBelge = 0;
			int eksikKontrol = 0;
			int ksEksikKontrol = 0;
			String tableName = "BELGELER";
			ArrayList<GMMap> dokumanSaveList = new ArrayList<GMMap>();
			String trMode = "SAVE";

			boolean adresTeyit = false;
			boolean adresTeyitKontrol = false;
			String calismaTipi = iMap.getString("CALISMA_TIPI");
			String durumKodu = iMap.getString("DURUM_KODU");
			int belgeAdet = iMap.getSize(tableName);

			// List<?> list = (List<?>)iMap.getSize(tableName); //PTT den gelirken s�k�nt� ��kartt� iMap.getSize(tableName) ile de�i�tirldi.
			if (iMap.getString("HOBIM_HATA_VAR_YOK") == null || "EVRAKSIZ".equals(durumKodu)) {
				for (int i = 0; i < belgeAdet; i++) {

					if ("2".equals(iMap.getString(tableName, i, "DOKUMAN_TIP_KOD"))) {
						adresTeyitKontrol = true;
						if (!adresTeyit) {
							adresTeyit = iMap.getBoolean(tableName, i, "ORJINAL_EVRAK_MI") && "1".equals(iMap.getString(tableName, i, "BELGE_KONTROL"));
						}
					}

					BirBasvuruBelgeTxId birBasvuruBelgeTxId = new BirBasvuruBelgeTxId();
					birBasvuruBelgeTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birBasvuruBelgeTxId.setDokumanKod(iMap.getString(tableName, i, "BELGE_KOD"));
					birBasvuruBelgeTxId.setKimden(iMap.getString(tableName, i, "KIMDEN_KOD"));
					birBasvuruBelgeTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));

					BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.get(BirBasvuruBelgeTx.class, birBasvuruBelgeTxId);

					if (birBasvuruBelgeTx == null) {
						birBasvuruBelgeTx = new BirBasvuruBelgeTx();
						birBasvuruBelgeTx.setId(birBasvuruBelgeTxId);
					}

					GnlMusteriImajId gnlMusteriImajId = new GnlMusteriImajId();
					gnlMusteriImajId.setDokumanTipi(iMap.getString(tableName, i, "BELGE_KOD"));
					gnlMusteriImajId.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
					GnlMusteriImaj gnlMusteriImaj = (GnlMusteriImaj) session.get(GnlMusteriImaj.class, gnlMusteriImajId);
					trMode = gnlMusteriImaj == null ? "SAVE" : "UPDATE";
					birBasvuruBelgeTx.setBelgeAdi(iMap.getString(tableName, i, "DOSYA_ADI"));
					birBasvuruBelgeTx.setBelgeGelisTarihi(((iMap.get(tableName, i, "GELIS_TARIHI") == null) || ("".equals(iMap.get(tableName, i, "GELIS_TARIHI")))) ? null : iMap.getDate(tableName, i, "GELIS_TARIHI"));
					birBasvuruBelgeTx.setBelgeAlinmaAdim(iMap.getString(tableName, i, "BELGE_ALINMA_ADIMI"));
					// TY-2063 ao
					String belgeKontrolKod = iMap.getString(tableName, i, "BELGE_KONTROL");
					birBasvuruBelgeTx.setBelgeKontrol(belgeKontrolKod);
					if (!"KS".equals(birBasvuruBelgeTx.getBelgeAlinmaAdim())) {
						if ((belgeKontrolKod == null || belgeKontrolKod.isEmpty()) && !"E".equals(iMap.getString("OTOMATIK_AKIS"))) {
							String belgeAdi = iMap.getString(tableName, i, "BELGE_ADI");
							sMap.clear();
							sMap.put("HATA_NO", new BigDecimal(330));
							sMap.put("P1", belgeAdi + " i�in belge kontrol� bo� se�ilemez.");
							return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
						}
						if ("2".equals(belgeKontrolKod)) {
							eksikKontrol++;
						}
					}
					else {
						if (belgeKontrolKod == null || belgeKontrolKod.isEmpty() || "2".equals(belgeKontrolKod)) {
							ksEksikKontrol++;
						}
					}

					birBasvuruBelgeTx.setBelgeHata(iMap.getString(tableName, i, "BELGE_HATA"));
					birBasvuruBelgeTx.setOrjinalEvrakMi(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, i, "ORJINAL_EVRAK_MI")));
					birBasvuruBelgeTx.setOnayliMi(iMap.getString(tableName, i, "ONAYLI_MI"));
					birBasvuruBelgeTx.setUyumsuzAciklama(iMap.getString(tableName, i, "UYUMSUZ_ACIKLAMA"));

					if ("1".equals(belgeKontrolKod)) {
						boolean orjinalEvrakMi = "E".equals(birBasvuruBelgeTx.getOrjinalEvrakMi());
						if (("1".equals(calismaTipi) && orjinalEvrakMi) || ("2".equals(calismaTipi) && "EVRAKSIZ".equals(durumKodu) && orjinalEvrakMi) || ("3".equals(calismaTipi) && "EVRAKSIZ".equals(durumKodu) && orjinalEvrakMi) || ("3".equals(calismaTipi) && "BELGE".equals(durumKodu))) {
							belgeKontrol++;
						}
					}

					if ("4".equals(belgeKontrolKod)) {
						sahteBelge++;
					}

					birBasvuruBelgeTx.setBelgeYeri(iMap.getString(tableName, i, "DOSYA_YOL"));
					birBasvuruBelgeTx.setKontrolNedeni(iMap.getString(tableName, i, "KONTROL_NEDENI"));

					birBasvuruBelgeTx.setBarkodNumarasi(iMap.getString(tableName, i, "BARKOD_NUMARASI"));
					birBasvuruBelgeTx.setIslemYapanKullanici(iMap.getString("ISLEMI_YAPAN_KULLANICI_EVRAK"));
					if (iMap.getString("BARKOD_NUMARASI") != null) {
						birBasvuruBelgeTx.setIslemTarihi(iMap.getDate(tableName, i, "ISLEM_TARIHI"));
					}

					GMMap pMap = new GMMap();
					pMap.put("KOD", "BELGE_SGK_BILGI");
					pMap.put("KEY", birBasvuruBelgeTx.getId().getDokumanKod());
					String isSgkBelge = GMServiceExecuter.call("BNSPR_CREDITCARD_IS_EXIST_PARAM_TEXT", pMap).getString("IS_EXIST");
					if ("E".equals(isSgkBelge)) {
						birBasvuruBelgeTx.setAylikUcret(iMap.getBigDecimal(tableName, i, "AYLIK_UCRET"));
						birBasvuruBelgeTx.setIseBaslamaTarihi(iMap.getDate(tableName, i, "ISE_BASLAMA_TARIHI"));
						birBasvuruBelgeTx.setIsyeriAdi(iMap.getString(tableName, i, "ISYERI_ADI"));
						birBasvuruBelgeTx.setIsyeriAdresi(iMap.getString(tableName, i, "ISYERI_ADRESI"));
					}

					/** TY-6797 TY-Kredi belgelerinin barkod numars� ve /veya her belge i�in her bas�mda �retilecek bir numara ile kontrol edilmesi */
					birBasvuruBelgeTx.setKontrolNumarasi(iMap.getBigDecimal("KONTROL_NUMARASI"));
					session.save(birBasvuruBelgeTx);

				}
			}

			String islemSonrasiDurumKodu = durumKodu;
			if (!"IPTAL".equals(durumKodu)) {
				if (sahteBelge > 0) {
					islemSonrasiDurumKodu = "FRAUD";
				}
				/*PY-3688 Kulland�r�m Sonras� Eksiklerini Dikkate Alma*/
				else {
					if (belgeKontrol == (belgeAdet - ksEksikKontrol) || "E".equals(iMap.getString("OTOMATIK_AKIS"))) {
						if ("EVRAKSIZ".equals(durumKodu)) {
							if (ksEksikKontrol == 0) {
								islemSonrasiDurumKodu = "CEPTE";
							}
						}
						else {
							islemSonrasiDurumKodu = "KUL";
						}
					}
				}
			}
			birBasvuruBelgeKontrolTx.setIslemSonrasiDurumKodu(islemSonrasiDurumKodu);

			// durumu cepte olanlar icin hobim hata kodu set edilir
			if (iMap.getString("HOBIM_HATA_VAR_YOK") != null)
				birBasvuruBelgeKontrolTx.setHobimHataVarYok(iMap.getString("HOBIM_HATA_VAR_YOK"));

			session.save(birBasvuruBelgeKontrolTx);
			session.flush();

			iMap.put("ADRES_TEYIT", adresTeyit && adresTeyitKontrol);
			if (iMap.getBoolean("MUSTERI_ESLESTIRME")) {
				updateCustomerInfo(iMap);
			}

			if ("E".equals(iMap.getBoolean("HOBIM_RANDOM_CHECK_EH")))
				GMServiceExecuter.execute("BNSPR_TRN3182_HOBIM_RANDOM_SAVE", iMap);

			iMap.put("TRX_NAME", "3182");
			Map<?, ?> trnMap = GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

			/*
			for (Iterator<?> iterator = dokumanSaveList.iterator(); iterator.hasNext();) {
				GMMap dokumanSaveMap = (GMMap) iterator.next();
				if(dokumanSaveMap.getString("MODE").equals("SAVE")){
					GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dokumanSaveMap);
				} else{
					GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dokumanSaveMap);
				}
			}
			
			if(eksikKontrol>0) {
				GMMap processQueryMap=new GMMap();
				String basvuruNo=iMap.getString("BASVURU_NO");   				
				processQueryMap.put("COUNT", DALUtil.getResult("select count(*) from bpm_processes where reference_type='eksikBelgeTamamlamaAkisi' and reference_no = "+iMap.getBigDecimal("BASVURU_NO")));
				//System.out.println("count.0"+	processQueryMap);
				if(processQueryMap.getInt("COUNT")== 0){ // start a new instance
					Map<String, Object>  variableMap=new HashMap<String, Object>();
					BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal(tableName, 0, "BASVURU_NO"))).uniqueResult();
					if(birBasvuru.getKanalKodu().equals("2")) {
						variableMap.put("BASVURU_NO", basvuruNo);									
						variableMap.put("SATICI_KOD",""+ birBasvuru.getSaticiKod());			
						GMMap processMap=new GMMap();
						processMap.put("PROCESS_DEFINITION_KEY", "eksikBelgeTamamlamaAkisi");
						processMap.put("INSTANCE_VARIABLES", variableMap);			
						processQueryMap.putAll(GMServiceExecuter.execute("BPM_START_NEW_PROCESS_INSTANCE", processMap));
						//BPM process started
						stmt.close();
						stmt= conn.prepareStatement("insert into bpm_processes(process_instance_id,reference_type,reference_no,rec_owner,rec_date) values(TO_NUMBER(?),'eksikBelgeTamamlamaAkisi',TO_NUMBER(?),'BNSPR',sysdate)");
						stmt.setString(1, processQueryMap.getString("PROCESS_INSTANCE_ID"));
						stmt.setString(2, basvuruNo);
						stmt.execute();	
					}
				}
			}
			*/

			return trnMap;
		}
		catch (GMRuntimeException e) {
			throw new GMRuntimeException(0, e.getMessage());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3182_BELGE_KONTROL_DETAY_SAVE")
	public static GMMap saveBelgeKontrolDetayMap(GMMap iMap) {
		GMMap oMap = new GMMap();
		String uygunMu = "1";// Uygun

		try {
			GMMap sorguMap = new GMMap();
			String tableName = "KONTROL_BILGILERI";
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				sorguMap.clear();
				sorguMap.put("TRX_NO", iMap.get("TRX_NO"));
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				sorguMap.put("BELGE_KOD", iMap.get(tableName, i, "KOD"));
				sorguMap.put("SIRA_NO", iMap.get(tableName, i, "SIRA_NO"));
				sorguMap.put("ONCEKI_DEGER", iMap.get(tableName, i, "BASVURU_DEGER"));
				sorguMap.put("YENI_DEGER", iMap.get(tableName, i, "YENI_DEGER"));
				sorguMap.put("UYGUN_MU", iMap.get(tableName, i, "UYGUN_MU"));
				sorguMap.put("ACIKLAMA", iMap.get(tableName, i, "ACIKLAMA"));
				saveBelgeKontrolDetay(sorguMap);
				// Kontrol
				if (!Constants.EVET.equals(sorguMap.getString("UYGUN_MU"))) {
					uygunMu = "3";// Hatali
				}

				// Aylik gelir bilgisi alindi ise guncelle
				if ("39".equals(sorguMap.getString("BELGE_KOD")) && Constants.EVET.equals(sorguMap.getString("UYGUN_MU")) && "AYLIK_GELIR".equals(iMap.get(tableName, i, "REF_ALAN"))) {
					if (oMap.getBigDecimal("AYLIK_GELIR") == null) {
						oMap.put("AYLIK_GELIR", sorguMap.get("YENI_DEGER"));
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("UYGUN_MU", uygunMu);
		return oMap;
	}

	private static GMMap saveBelgeKontrolDetay(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			BirBasvuruBelgeKontDtyTxId id = new BirBasvuruBelgeKontDtyTxId();
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setBelgeKod(iMap.getBigDecimal("BELGE_KOD"));
			id.setSiraNo(iMap.getBigDecimal("SIRA_NO"));

			// Session ac
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuruBelgeKontDtyTx tx = (BirBasvuruBelgeKontDtyTx) session.get(BirBasvuruBelgeKontDtyTx.class, id);
			if (tx == null) {
				tx = new BirBasvuruBelgeKontDtyTx();
				tx.setId(id);
			}
			tx.setAciklama(iMap.getString("ACIKLAMA"));
			tx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			tx.setOncekiDeger(iMap.getString("ONCEKI_DEGER"));
			tx.setUygunMu(iMap.getString("UYGUN_MU"));
			tx.setYeniDeger(iMap.getString("YENI_DEGER"));

			session.save(tx);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3182_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			GMMap oMap = new GMMap();

			if (StringUtils.isBlank(iMap.getString("TRX_NO"))) {
				iMap.put("TRX_NO", getTxNoByBasvuruNo(iMap.getBigDecimal("BASVURU_NO")));
			}

			BirBasvuruBelgeKontrolTx birBasvuruBelgeKontrolTx = (BirBasvuruBelgeKontrolTx) session.createCriteria(BirBasvuruBelgeKontrolTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			oMap.put("IPTAL", "IPTAL".equals(birBasvuruBelgeKontrolTx.getIslemSonrasiDurumKodu()));
			oMap.put("HOBIM_HATA_VAR_YOK", birBasvuruBelgeKontrolTx.getHobimHataVarYok());
			oMap.put("IZINLI_PAZARLAMA", "E".equals(birBasvuruBelgeKontrolTx.getIzinliPazarlama()));
			oMap.put("SOZLESME_NUMARASI_AYNI_MI", "E".equals(birBasvuruBelgeKontrolTx.getSozlesmeNumarasiAyniMiEh()));
			/** TY-6797 TY-Kredi belgelerinin barkod numars� ve /veya her belge i�in her bas�mda �retilecek bir numara ile kontrol edilmesi */

			if (birBasvuruBelgeKontrolTx.getHobimHataVarYok() != null)
				oMap.put("CEPTE_BASVURU", true);
			else
				oMap.put("CEPTE_BASVURU", false);
			oMap.put("BASVURU_NO", birBasvuruBelgeKontrolTx.getId().getBasvuruNo());

			List<?> list = session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).addOrder(Order.desc("id.kimden")).list();
			String tableName = "BELGELER";
			int row = 0;

			String belgeTamamlamaTarihi = null;

			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) iterator.next();

				oMap.put("BASVURU_NO", birBasvuruBelgeTx.getId().getBasvuruNo());
				String dosyaPath = birBasvuruBelgeTx.getBelgeYeri();
				if (dosyaPath != null) {
					try {
						String dokumanAdi = dosyaPath;
						dokumanAdi = dokumanAdi.substring(dokumanAdi.lastIndexOf("/") + 1, dokumanAdi.length());
						oMap.put(tableName, row, "URL", GMServiceExecuter.call("DYS_CMIS_GET_CUSTOMER_DOC_INFO_BY_FILENAME", new GMMap().put("DOKUMAN_ADI", dokumanAdi).put("DOKUMAN_CLASS", "Musteri")).getString("DOKUMAN_LINK"));
					}
					catch (Exception e) {
						// Hata alirsa butun islemi kesmesin
						e.printStackTrace();
					}
				}

				oMap.put(tableName, row, "DOSYA_YOL", dosyaPath);
				oMap.put(tableName, row, "DOSYA_ADI", birBasvuruBelgeTx.getBelgeAdi());
				oMap.put(tableName, row, "BELGE_KOD", birBasvuruBelgeTx.getId().getDokumanKod());
				HashMap<?, ?> lovMap = LovHelper.diLovAll(birBasvuruBelgeTx.getId().getDokumanKod(), "3182/LOV_BELGE_KOD");
				oMap.put(tableName, row, "BELGE_ADI", lovMap.get("ACIKLAMA"));
				oMap.put(tableName, row, "DOKUMAN_TIP_KOD", lovMap.get("DOKUMAN_TIP_KOD"));
				oMap.put(tableName, row, "BELGE_KONTROL", birBasvuruBelgeTx.getBelgeKontrol());
				oMap.put(tableName, row, "BELGE_HATA", birBasvuruBelgeTx.getBelgeHata());
				oMap.put(tableName, row, "BELGE_ALINMA_ADIMI", birBasvuruBelgeTx.getBelgeAlinmaAdim());
				oMap.put(tableName, row, "GELIS_TARIHI", birBasvuruBelgeTx.getBelgeGelisTarihi());
				oMap.put(tableName, row, "ORJINAL_EVRAK_MI", GuimlUtil.convertToCheckBoxValue(birBasvuruBelgeTx.getOrjinalEvrakMi()));
				oMap.put(tableName, row, "KONTROL_NEDENI", birBasvuruBelgeTx.getKontrolNedeni());
				oMap.put(tableName, row, "KIMDEN", LovHelper.diLov(birBasvuruBelgeTx.getId().getKimden(), "3181/LOV_BASVURU_KISI", "ACIKLAMA"));
				oMap.put(tableName, row, "KIMDEN_KOD", birBasvuruBelgeTx.getId().getKimden());
				oMap.put(tableName, row, "AYLIK_UCRET", birBasvuruBelgeTx.getAylikUcret());
				oMap.put(tableName, row, "ISE_BASLAMA_TARIHI", birBasvuruBelgeTx.getIseBaslamaTarihi());
				oMap.put(tableName, row, "ISYERI_ADI", birBasvuruBelgeTx.getIsyeriAdi());
				oMap.put(tableName, row, "ISYERI_ADRESI", birBasvuruBelgeTx.getIsyeriAdresi());
				if (belgeTamamlamaTarihi == null) {
					iMap.put("IPTAL_GOSTER", "H");
					if (oMap.getBoolean("IPTAL"))
						iMap.put("IPTAL_GOSTER", "E");

					iMap.put("BASVURU_NO", birBasvuruBelgeTx.getId().getBasvuruNo());
					GMMap resultMap = GMServiceExecuter.call("BNSPR_TRN3182_GET_BASVURU_INFO", iMap);

					if (resultMap.getDate("SOZLESME_TARIHI") != null) {
						iMap.put("TARIH", resultMap.getDate("SOZLESME_TARIHI"));
						iMap.put("GUN", resultMap.getString("ORJ_EVRAK_GONDERIM_SURESI"));
						belgeTamamlamaTarihi = (GMServiceExecuter.call("BNSPR_COMMON_SONRAKI_GUN", iMap).getString("TARIH"));
					}
				}

				oMap.put(tableName, row, "BELGE_TAMAMLAMA_TARIHI", belgeTamamlamaTarihi);
				oMap.put(tableName, row, "ONAYLI_MI", birBasvuruBelgeTx.getOnayliMi());
				oMap.put(tableName, row, "UYUMSUZ_ACIKLAMA", birBasvuruBelgeTx.getUyumsuzAciklama());

				row++;
			}

			List<BirBasvuruMustGuncelleTx> birBasvuruMustGuncelleTxList = session.createCriteria(BirBasvuruMustGuncelleTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			if (birBasvuruMustGuncelleTxList != null && birBasvuruMustGuncelleTxList.size() > 0) {
				oMap.put("MUSTERI_IZLE_ENABLED", true);
			}
			else {
				oMap.put("MUSTERI_IZLE_ENABLED", false);
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3182_GET_CALISMA_TIPI")
	public static GMMap getCalismaTipi(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select s.calisma_sekli_kod from bir_satici_tahsis s,bir_basvuru b where s.kod = b.satici_kod and b.basvuru_no = ?");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			rSet = stmt.executeQuery();
			GMMap oMap = new GMMap();
			if (rSet.next()) {
				oMap.put("CALISMA_TIPI", rSet.getString(1));
			}
			oMap.put("ORJ_EVRAK_GONDERIM_SURESI", DALUtil.getResult("select s.orj_evrak_gon_sure from bir_satici_tahsis s,bir_basvuru b where s.kod = b.satici_kod and b.basvuru_no = " + iMap.getBigDecimal("BASVURU_NO") + ""));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3182_GERCEK_MUSTERI_DONUSTUR")
	public static Map<?, ?> gercekMusteriDonustur(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		String kanalKodu = "";
		try {
			iMap.put("KONTAKT_NO", iMap.getBigDecimal("MUSTERI_NO"));
			iMap.put("tckno_in", iMap.getString("TC_KIMLIK_NO"));
			iMap.put("ACTION", "NEW");
			GMMap kontakt = new GMMap();
			kontakt.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_GET_INFO", iMap));

			// kps yapilmadiysa
			if (kontakt.getString("TCKNO_IN") == null || kontakt.getString("TCKNO_OUT") == null || kontakt.getString("TCKNO_IN").isEmpty() || kontakt.getString("TCKNO_OUT").isEmpty()) {
				GMMap kpsMap = new GMMap();
				GMMap sMap = new GMMap();
				sMap.put("TCKN", iMap.getString("TC_KIMLIK_NO"));
				// kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_KPS_KIMLIK_SORGULAMA", iMap));

				sMap = GMServiceExecuter.call("BNSPR_KPS_GET_KISI_BILGILERI", sMap);

				if (sMap.getInt("HATA_KOD") == 0) {
					BilesikKutukModel bilesikKutukModel = (BilesikKutukModel) sMap.get("KISI_BILGISI");

					if (bilesikKutukModel != null) {

						Calendar dogumTarihi = Calendar.getInstance();

						TCKisiBilgisiModel tcKisiBilgisiModel = bilesikKutukModel.getTcKisiBilgisiModel();
						TCCuzdanBilgisiModel tcCuzdanBilgisiModel = bilesikKutukModel.getTcCuzdanBilgisiModel();
						TCKKModel tckkModel = bilesikKutukModel.getTckkModel();

						TarihModel dogumTarih = tcKisiBilgisiModel.getDogumTarih();
						dogumTarihi.set(dogumTarih.getYil(), dogumTarih.getAy() - 1, dogumTarih.getGun());

						String ad = StringUtils.EMPTY;
						ad = tcKisiBilgisiModel.getAd();

						String ad1 = StringUtils.EMPTY;
						String ad2 = StringUtils.EMPTY;
						if (ad.indexOf(" ") >= 0) {
							ad1 = ad.substring(0, ad.indexOf(" "));
							ad2 = ad.substring(ad.indexOf(" ")).trim();
						}
						else {
							ad1 = ad;
						}

						kontakt.put("ISIM", ad1);
						kontakt.put("IKINCI_ISIM", ad2);
						kontakt.put("SOYADI", tcKisiBilgisiModel.getSoyad());
						kontakt.put("BABA_ADI", tcKisiBilgisiModel.getBabaAd());
						kontakt.put("ANNE_ADI", tcKisiBilgisiModel.getAnneAd());
						kontakt.put("DOGUM_TARIHI", dogumTarihi.getTime());
						kontakt.put("DOGUM_YERI", tcKisiBilgisiModel.getDogumYer());

						String ilKodu = String.valueOf(tcKisiBilgisiModel.getIl().getKod());
						if (ilKodu.length() == 2)
							ilKodu = "0" + ilKodu;
						if (ilKodu.length() == 1)
							ilKodu = "00" + ilKodu;

						kontakt.put("IL_KOD", ilKodu);

						kontakt.put("CILT_NO", tcKisiBilgisiModel.getCilt() != null ? tcKisiBilgisiModel.getCilt().getKod() : "");
						kontakt.put("AILE_SIRA_NO", tcKisiBilgisiModel.getAileSiraNo());
						kontakt.put("SIRA_NO", tcKisiBilgisiModel.getBireySiraNo());
						kontakt.put("KIZLIK_SOYADI", ""); // ??
						kontakt.put("TCKN_OUT", tcKisiBilgisiModel.getTcKimlikNo());
						kontakt.put("ILCE_KOD", String.valueOf(tcKisiBilgisiModel.getIlce().getKod()));

						String olumTarihStr = StringUtils.EMPTY;
						int yil = 0, ay = 0, gun = 0;
						TarihModel olumTarihModel = tcKisiBilgisiModel.getOlumTarih();
						if (olumTarihModel != null) {
							if (olumTarihModel.getYil() != null && olumTarihModel.getAy() != null && olumTarihModel.getGun() != null) {
								yil = olumTarihModel.getYil().intValue();
								ay = olumTarihModel.getAy().intValue();
								gun = olumTarihModel.getGun().intValue();
								if (yil > 0 && ay > 0 && gun > 0) {
									olumTarihStr = olumTarihModel.toString();
								}
							}
						}
						if (!StringUtil.isEmpty(olumTarihStr)) {
							Calendar olumTarihi = Calendar.getInstance();
							olumTarihi.set(yil, ay - 1, gun);
							kontakt.put("OLUM_TARIHI", olumTarihi.getTime());
						}
						// kpsMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_KPS_KIMLIK_DOGRULAMA", iMap));

						kontakt.put("CINSIYET_KOD", KPSUtil.getParametreKod(tcKisiBilgisiModel.getCinsiyet()));
						kontakt.put("MEDENI_HAL_KOD", KPSUtil.getParametreKod(tcKisiBilgisiModel.getMedeniHal()));
						kontakt.put("KISA_AD", ad + " " + tcKisiBilgisiModel.getSoyad());
						kontakt.put("F_NUF", "E");

						if (tcCuzdanBilgisiModel != null && !StringUtils.isEmpty(tcCuzdanBilgisiModel.getAd())) {
							TarihModel verilmeTarihModel = tcCuzdanBilgisiModel.getVerilmeTarih();
							if (verilmeTarihModel != null) {
								Calendar verilisTarihi = Calendar.getInstance();
								verilisTarihi.set(verilmeTarihModel.getYil(), verilmeTarihModel.getAy() - 1, verilmeTarihModel.getGun());
								kontakt.put("VERILDIGI_TARIH", verilisTarihi.getTime());
							}
							kontakt.put("NUF_VERILIS_NEDENI", KPSUtil.getParametreAciklama(tcCuzdanBilgisiModel.getCuzdanVerilmeNeden()));
							kontakt.put("VERILDIGI_YER", KPSUtil.getParametreAciklama(tcCuzdanBilgisiModel.getVerildigiIlce()));
							kontakt.put("NUFUS_CUZDANI_SERI_NO", tcCuzdanBilgisiModel.getSeri());
						}
						// yeni kimlik almis
						if (tckkModel != null && !StringUtils.isEmpty(tckkModel.getAd())) {
							TarihModel verilmeTarihModel = tckkModel.getTeslimTarih();
							if (verilmeTarihModel != null) {
								Calendar verilisTarihi = Calendar.getInstance();
								verilisTarihi.set(verilmeTarihModel.getYil(), verilmeTarihModel.getAy() - 1, verilmeTarihModel.getGun());
								kontakt.put("VERILDIGI_TARIH", verilisTarihi.getTime());
							}
							kontakt.put("NUF_VERILIS_NEDENI", KPSUtil.getParametreAciklama(tckkModel.getBasvuruNeden()));
							kontakt.put("VERILDIGI_YER", KPSUtil.getParametreKod(tckkModel.getTeslimEdenBirim()));
							kontakt.put("NUFUS_CUZDANI_SERI_NO", tckkModel.getSeriNo().substring(0, 3));
						}
					}
				}
			}
			else // kps yapilmis
			{
				if (kontakt.getString("NUFUS_CUZDANI_SERI_NO") == null || kontakt.getString("NUFUS_CUZDANI_SERI_NO").isEmpty())
					kontakt.put("NUFUS_CUZDANI_SERI_NO", iMap.getString("KIMLIK_SERI_SIRA_NO"));
				if (kontakt.getString("NUFUS_CUZDANI_SERI_NO") != null && !kontakt.getString("NUFUS_CUZDANI_SERI_NO").isEmpty())
					kontakt.put("F_NUF", "E");
			}

			if (kontakt.getString("KISA_AD") == null || kontakt.getString("KISA_AD").isEmpty()) {
				if (kontakt.getString("KISA_AD") != null)
					kontakt.remove("KISA_AD");
				kontakt.put("KISA_AD", iMap.getString("ADI_SOYADI"));
			}
			if (kontakt.getString("KIZLIK_SOYADI") == null || kontakt.getString("KIZLIK_SOYADI").isEmpty()) {
				if (kontakt.getString("KIZLIK_SOYADI") != null)
					kontakt.remove("KIZLIK_SOYADI");
				kontakt.put("KIZLIK_SOYADI", iMap.getString("ONCEKI_SOYAD"));
			}
			if (kontakt.getString("UYRUK_KOD") != null && !kontakt.getString("UYRUK_KOD").isEmpty()) {
				if (kontakt.getString("UYRUK_KOD") != null)
					kontakt.remove("UYRUK_KOD");
				kontakt.put("UYRUK_KOD", "TR");
			}

			GMMap oMap = new GMMap();
			oMap.put("TRX_NO", kontakt.getBigDecimal("TRX_NO"));

			if (iMap.getString("CEP_TEL_NO") == null || iMap.getString("CEP_TEL_NO").isEmpty())
				kontakt.put("ADK_MUSTERISIMI", "H");
			else if ("1".equals(iMap.getString("CALISMA_TIPI"))) // Orijinal Evrakl�
			{
				if(!"2".equals(iMap.getString("KANAL_KODU")))
					kontakt.put("ADK_MUSTERISIMI", "E");
				else
					kontakt.put("ADK_MUSTERISIMI", "H");
			}
			else if ("2".equals(iMap.getString("CALISMA_TIPI")) || "3".equals(iMap.getString("CALISMA_TIPI"))) // Orijinal Evraks�z or Elektronik Evrakl�
			{
				if ("CEPTE".equals(iMap.getString("DURUM_KODU")))
					kontakt.put("ADK_MUSTERISIMI", "E");
				else
					kontakt.put("ADK_MUSTERISIMI", "H");
			}

			if (StringUtils.isBlank(kontakt.getString("ORIJINAL_EVRAKLIMI"))) {
				kontakt.put("ORIJINAL_EVRAKLIMI", "H");
			}

			if (kontakt.getString("KAZANIM_KANALI") == null || kontakt.getString("KAZANIM_KANALI").isEmpty()) {
				if (kontakt.getString("KAZANIM_KANALI") != null)
					kontakt.remove("KAZANIM_KANALI");
				kontakt.put("KAZANIM_KANALI", iMap.getString("KANAL_KODU"));
			}
			// BT-2767
			// BNSPRPRO-6697 if(kontakt.getString("KAZANIM_URUNU") == null || kontakt.getString("KAZANIM_URUNU").isEmpty())
			{
				if (kontakt.getString("KAZANIM_URUNU") != null)
					kontakt.remove("KAZANIM_URUNU");
				kontakt.put("KAZANIM_URUNU", "BRY");
			}
			if (kontakt.getString("DK_GRUP_KOD") == null || kontakt.getString("DK_GRUP_KOD").isEmpty()) {
				if (kontakt.getString("DK_GRUP_KOD") != null)
					kontakt.remove("DK_GRUP_KOD");
				kontakt.put("DK_GRUP_KOD", new BigDecimal("1042"));
			}
			if (kontakt.getString("YERLESIM_KOD") == null || kontakt.getString("YERLESIM_KOD").isEmpty()) {
				if (kontakt.getString("YERLESIM_KOD") != null)
					kontakt.remove("YERLESIM_KOD");
				kontakt.put("YERLESIM_KOD", "I");
			}
			if (kontakt.getString("BAGLI_KANAL_GRUBU") == null || kontakt.getString("BAGLI_KANAL_GRUBU").isEmpty()) {
				if (kontakt.getString("BAGLI_KANAL_GRUBU") != null)
					kontakt.remove("BAGLI_KANAL_GRUBU");
				kontakt.put("BAGLI_KANAL_GRUBU", iMap.getString("KANAL_KODU"));
			}
			/*
			if(kontakt.getString("MUSTERI_TEMSILCISI") == null || kontakt.getString("MUSTERI_TEMSILCISI").isEmpty())
			{
				if(kontakt.getString("MUSTERI_TEMSILCISI") != null) kontakt.remove("MUSTERI_TEMSILCISI");
				kontakt.put("MUSTERI_TEMSILCISI", new BigDecimal("127"));
			}
			 */
			// if(kontakt.getString("PORTFOY_KOD") == null || kontakt.getString("PORTFOY_KOD").isEmpty())
			{
				if (kontakt.getString("PORTFOY_KOD") != null)
					kontakt.remove("PORTFOY_KOD");
				kontakt.put("PORTFOY_KOD", GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_KOD", new GMMap().put("BASVURU_NO", iMap.getString("BASVURU_NO"))).getString("PORTFOY_KOD"));
			}
			// if(kontakt.getString("BOLUM_KODU") == null || kontakt.getString("BOLUM_KODU").isEmpty())
			{
				if (kontakt.getString("BOLUM_KODU") != null)
					kontakt.remove("BOLUM_KODU");
				kontakt.put("BOLUM_KODU", GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_SUBE_KOD", new GMMap().put("PORTFOY_KOD", kontakt.getString("PORTFOY_KOD"))).getString("PORTFOY_SUBE_KOD"));
			}
			if (kontakt.getString("MUSTERI_SEGMENTI") == null || kontakt.getString("MUSTERI_SEGMENTI").isEmpty()) {
				if (kontakt.getString("MUSTERI_SEGMENTI") != null)
					kontakt.remove("MUSTERI_SEGMENTI");
				kontakt.put("MUSTERI_SEGMENTI", "N");
			}
			if (kontakt.getString("PROFIL_KOD") == null || kontakt.getString("PROFIL_KOD").isEmpty()) {
				if (kontakt.getString("PROFIL_KOD") != null)
					kontakt.remove("PROFIL_KOD");
				kontakt.put("PROFIL_KOD", "1");
			}
			if (kontakt.getString("MUSTERI_GRUP_KOD") == null || kontakt.getString("MUSTERI_GRUP_KOD").isEmpty()) {
				if (kontakt.getString("MUSTERI_GRUP_KOD") != null)
					kontakt.remove("MUSTERI_GRUP_KOD");
				if (iMap.getString("URUN_KAMP_KOD") != null && iMap.getString("URUN_KAMP_KOD").indexOf('-') < 0) {
					conn = DALUtil.getGMConnection();
					stmt = conn.prepareCall("{? = call pkg_kampanya.Kamp_MusteriGrupKod(?)}");
					stmt.registerOutParameter(1, Types.VARCHAR);
					stmt.setBigDecimal(2, iMap.getBigDecimal("URUN_KAMP_KOD"));
					stmt.execute();
					if (stmt.getString(1) != null && stmt.getString(1).isEmpty() == false)
						kontakt.put("MUSTERI_GRUP_KOD", stmt.getString(1));
					else
						kontakt.put("MUSTERI_GRUP_KOD", "1"); // normal musteri
				}
				else
					kontakt.put("MUSTERI_GRUP_KOD", "1"); // normal musteri
			}

			kontakt.put("MUSTERI_KONTAKT", "M");
			kontakt.put("HESAP_UCRETI_F", "H");
			kontakt.put("YATIRIM_EKSTRESI", "H");

			if (kontakt.getBoolean("F_SAHTE")) {
				kontakt.remove("F_SAHTE");
				kontakt.put("F_SAHTE", "1");
			}
			else {
				kontakt.remove("F_SAHTE");
				kontakt.put("F_SAHTE", "0");
			}
			if (kontakt.getBoolean("F_MUSTERIYE_CEVRILEBILIR")) {
				kontakt.remove("F_MUSTERIYE_CEVRILEBILIR");
				kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "1");
			}
			else {
				kontakt.remove("F_MUSTERIYE_CEVRILEBILIR");
				kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "0");
			}
			try {
				kontakt.putAll(GMServiceExecuter.execute("BNSPR_QRY1098_GET_APS", iMap));
			}
			catch (Exception e) {
				System.out.println(e.getMessage().toString());
			}
			kontakt.put("F_APS_TEYIT", "E".equals(iMap.getString("APS_BILGILERI_UYUMLUMU")));
			kontakt.put("F_APS", "E");

			// Musteri tanimlama + guncelleme islemlerinin onaysiz gerceklesmesi
			kontakt.put("TRX_ONAYSIZ_ISLEM", "E");

			// ekranda bunlar i�in alan bulunmuyor, default olarak
			// �ifte vatanda�l�k : R ("Hay�r")
			// Green Card : R("De�ilim")
			kontakt.put("F_CIFTE_VATANDAS", "R");
			kontakt.put("F_GREEN_CARD", "R");

			if ("7".equals(iMap.getString("KANAL_KODU")) && "5".equals(iMap.getString("KREDI_TUR"))) {
				kanalKodu = (String) DALUtil.callNoParameterFunction("{? = call pkg_global.Get_KanalKod}", java.sql.Types.VARCHAR);
				DALUtil.callOracleProcedure("{call pkg_global.Set_KanalKod(?)}", new Object[] { BnsprType.STRING, iMap.getString("KANAL_KODU") }, new Object[] {});
			} else if ("7".equals(iMap.getString("KREDI_TUR"))) {
				kontakt.put("TICARI_UNVAN", kontakt.getString("KISA_AD"));
			}

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_SAVE", kontakt));

			if ("7".equals(iMap.getString("KANAL_KODU")) && "5".equals(iMap.getString("KREDI_TUR"))) {
				DALUtil.callOracleProcedure("{call pkg_global.Set_KanalKod(?)}", new Object[] { BnsprType.STRING, kanalKodu }, new Object[] {});
			}

			iMap.put("MESSAGE_NO", new BigDecimal(1753));
			iMap.put("P1", iMap.getBigDecimal("MUSTERI_NO"));
			oMap.put("GM_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));
			oMap.put("MUSTERI_KONTAKT", kontakt.getString("MUSTERI_KONTAKT"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3182_GERCEK_MUSTERI_ADK_GUNCELLE")
	public static Map<?, ?> gercekMusteriADKGuncelle(GMMap iMap) {
		GMMap pMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			iMap.put("ACTION", "NEW");
			GMMap kontakt = new GMMap();

			kontakt.put("DURUM_KODU", "A");
			kontakt.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));

			BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRN1040_CREATE_TRX_NO", kontakt).getBigDecimal("TRX_NO");
			kontakt.put("TRX_NO", trxNo);
			kontakt.putAll(GMServiceExecuter.execute("BNSPR_TRN10041_GET_INFO", kontakt));
			kontakt.put("ADK_MUSTERISIMI", iMap.getString("ADK_MUSTERISIMI"));

			GMMap oMap = new GMMap();
			oMap.put("TRX_NO", kontakt.getBigDecimal("TRX_NO"));

			if (kontakt.getBoolean("F_SAHTE")) {
				kontakt.remove("F_SAHTE");
				kontakt.put("F_SAHTE", "1");
			}
			else {
				kontakt.remove("F_SAHTE");
				kontakt.put("F_SAHTE", "0");
			}
			if (kontakt.getBoolean("F_MUSTERIYE_CEVRILEBILIR")) {
				kontakt.remove("F_MUSTERIYE_CEVRILEBILIR");
				kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "1");
			}
			else {
				kontakt.remove("F_MUSTERIYE_CEVRILEBILIR");
				kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "0");
			}

			ArrayList<HashMap<String, Object>> telefonList = new ArrayList<HashMap<String, Object>>();
			telefonList = (ArrayList<HashMap<String, Object>>) kontakt.get("TELEFON_LIST");

			String tableName = "TELEFON_LIST";

			if (telefonList != null) {
				boolean isThereNoOtp = true;
				for (int row = 0; row < telefonList.size(); row++) {
					if ("true".equals(kontakt.getString(tableName, row, "OTPMI"))) {
						isThereNoOtp = false;
					}
				}
				if (isThereNoOtp) {
					for (int row = 0; row < telefonList.size(); row++) {
						if ("3".equals(kontakt.getString(tableName, row, "TEL_TIP")) && "1".equals(kontakt.getString(tableName, row, "F_ILETISIM"))) {
							kontakt.put(tableName, row, "OTPMI", "true");
						}
					}
				}

			}

			ArrayList<HashMap<String, Object>> dokumanList = new ArrayList<HashMap<String, Object>>();
			dokumanList = (ArrayList<HashMap<String, Object>>) kontakt.get("CBS_MUSTERI_BASVURU_DOKUMAN");

			List<?> list = session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).addOrder(Order.desc("id.kimden")).list();

			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) iterator.next();
				pMap.clear();
				pMap.put("KOD", "BHS_DOKUMAN_KODLARI");
				pMap.put("KEY", birBasvuruBelgeTx.getId().getDokumanKod());
				pMap = GMServiceExecuter.call("BNSPR_COMMON_PARAMTEXT_DEGER_VAR_MI", pMap);

				if (pMap.getString("IS_EXIST").equals("E") && "E".equals(birBasvuruBelgeTx.getOrjinalEvrakMi()) && "1".equals(birBasvuruBelgeTx.getBelgeKontrol())) {
					if (dokumanList != null)
						for (int i = 0; i < dokumanList.size(); i++)
							if (birBasvuruBelgeTx.getId().getDokumanKod().equals(kontakt.getString("CBS_MUSTERI_BASVURU_DOKUMAN", i, "DOKUMAN_KODU")))
								kontakt.put("CBS_MUSTERI_BASVURU_DOKUMAN", i, "ALINDI_KUTUSU_F", "1");
				}
			}
			kontakt.put("F_APS_TEYIT", "E".equals(iMap.getString("APS_BILGILERI_UYUMLUMU")));
			kontakt.put("F_APS", "E");

			// �ifte vatanda�l�k : R ("Hay�r")
			// Green Card : R("De�ilim")

			if (iMap.getString("F_CIFTE_VATANDAS") == null) {
				kontakt.put("F_CIFTE_VATANDAS", "R");
			}
			if (iMap.getString("F_GREEN_CARD") == null) {
				kontakt.put("F_GREEN_CARD", "R");
			}

			// Musteri tanimlama + guncelleme islemlerinin onaysiz gerceklesmesi
			kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10041_SAVE", kontakt));

			iMap.put("MESSAGE_NO", new BigDecimal(1753));
			iMap.put("P1", iMap.getBigDecimal("MUSTERI_NO"));
			oMap.put("GM_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static GMMap vadesizHesapVarMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_hesap.VadesizHesapNo(?,?,?) }");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(3, iMap.getString("SUBE_KODU"));
			stmt.setString(4, "TRY");
			stmt.execute();

			oMap.put("HESAP_NO", stmt.getBigDecimal(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static GMMap teminatSigortaHesapNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3132.get_sigorta_hesabi(?) }");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			oMap.put("HESAP_NO", stmt.getBigDecimal(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3182_VADESIZ_HESAP_AC")
	public static Map<?, ?> vadesizHesapAc(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_hesap.vadesiz_hesap_acilis(?,?,?,?,?,?,?,?) }");
			stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(2, "VADESIZ");
			stmt.setString(3, "MUSTAK-TP");
			if ("7".equals(iMap.getString("KANAL_KODU")) && "5".equals(iMap.getString("KREDI_TUR"))) {
				stmt.setString(4, "KMHPTT");
			}
			else {
				stmt.setString(4, "SABIT FAIZ");
			}
			stmt.setString(5, iMap.getString("SUBE_KODU"));
			stmt.setString(6, "TRY");
			stmt.setString(7, null);

			Session session = DAOSession.getSession("BNSPRDal");

			BigDecimal rezervHesapNo = null;
			if (iMap.get("REZERV_HESAP_NO") != null) {
				rezervHesapNo = iMap.getBigDecimal("REZERV_HESAP_NO");
			}
			else {
				MuhHesapRezerv muhHesapRezerv = (MuhHesapRezerv) session.createCriteria(MuhHesapRezerv.class).add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal("MUSTERI_NO"))).add(Restrictions.eq("durumKodu", "A")).uniqueResult();
				rezervHesapNo = (muhHesapRezerv == null ? null : muhHesapRezerv.getId().getHesapNo());
			}

			if (rezervHesapNo != null) {
				stmt.setBigDecimal(8, rezervHesapNo);
			}
			else
				stmt.registerOutParameter(8, Types.NUMERIC);

			stmt.execute();

			iMap.put("MESSAGE_NO", new BigDecimal(1754));
			iMap.put("P1", iMap.getBigDecimal("MUSTERI_NO"));
			if (rezervHesapNo != null) {
				iMap.put("P2", rezervHesapNo);
				oMap.put("HESAP_NO", rezervHesapNo);
			}
			else {
				oMap.put("HESAP_NO", stmt.getBigDecimal(8));
				iMap.put("P2", oMap.getBigDecimal("HESAP_NO"));
			}
			oMap.put("VH_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static boolean teminatVarMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3132.TeminatGirilmisMi(?) }");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			return ((new BigDecimal(-1)).equals(stmt.getBigDecimal(1)));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3182_OTOMATIK_TEMINAT")
	public static Map<?, ?> otomatikTeminatInsert(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BASVURU.OtomatikTeminatInsert(?,?,?) }");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("PRIM_TUTARI"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("POLICE_NO"));
			stmt.execute();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3182_OTOMATIK_KULLANDIRIM")
	public static Map<?, ?> otomatikKullandirim(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

			HashMap<?, ?> lovMap = LovHelper.diLovAll(iMap.getBigDecimal("BASVURU_NO"), "3132/LOV_BASVURU");
			iMap.put("VALOR", lovMap.get("BANKA_TARIHI"));
			iMap.put("ISLEM_TARIHI", lovMap.get("BANKA_TARIHI"));
			iMap.put("SUBE_KOD", iMap.getString("SATICI_HESAP_SUBE_KODU") == null ? iMap.getString("SUBE_KODU") : iMap.getString("SATICI_HESAP_SUBE_KODU"));
			iMap.put("ALAC_HESAP_NO", iMap.getBigDecimal("HESAP_NO"));
			iMap.put("OTO_VIRMAN_HESAP", iMap.getBigDecimal("HESAP_NO"));
			iMap.put("ACIKLAMA", "Otomatik Kulland�r�m");
			iMap.put("KRD_TUTAR_TL", lovMap.get("KRD_TUTAR_TL"));
			iMap.put("KUR", lovMap.get("KUR"));
			iMap.put("KRD_DOVIZ_KOD", lovMap.get("DOVIZ_KODU"));
			iMap.put("KRD_TUTAR", lovMap.get("TUTAR"));
			iMap.put("BAYI_KOM", lovMap.get("BAYI_KOMISYON_TUTARI"));
			iMap.put("MUS_KOM", lovMap.get("MUSTERI_KOMISYON_TUTARI"));
			iMap.put("DOSYA_MASRAF", lovMap.get("DOSYA_MASRAFI"));
			iMap.put("FARK_FAIZ", lovMap.get("FARK_FAIZI"));
			iMap.put("KREDI_SIGORTA_PRIMI", lovMap.get("KREDI_SIG_PRIMI"));
			iMap.put("KKDF", lovMap.get("KKDF_ORAN"));
			iMap.put("BSMV", lovMap.get("BSMV_ORAN"));
			iMap.put("FAIZ_ORANI", lovMap.get("BAZ_FAIZ"));
			// iMap.put("SIGORTA_HESABI", teminatSigortaHesapNo(iMap).getBigDecimal("HESAP_NO"));
			// iMap.put("SIGORTA_KOMISYON", lovMap.get("SIGORTA_KOMISYONU"));
			iMap.put("BSMV_EH", "H");
			iMap.put("KRD_TUR", lovMap.get("KRD_TUR_KOD"));
			iMap.put("VADE", lovMap.get("VADE"));
			iMap.put("ALAC_DOVIZ_KODU", "TRY");
			iMap.put("KRD_TIP_KOD", lovMap.get("KREDI_ALT_TUR"));
			iMap.put("ALT_KRD_TIP", lovMap.get("KREDI_ALT_TUR2"));
			iMap.put("URUN_KAMP_KOD", lovMap.get("URUN_KAMP_KODU"));
			iMap.put("KANAL_KODU", lovMap.get("KANAL_KODU"));
			iMap.put("KULLANILMISMI", lovMap.get("KULLANILMISMI"));
			iMap.put("SON_TX_NO", lovMap.get("SON_TX_NO"));
			iMap.put("OTO_VIRMAN", "E");
			iMap.put("ODEME_TIPI", lovMap.get("ODEME_TIPI"));

			GMMap bMap = new GMMap();
			iMap.put("SATICI_KOD", lovMap.get("KANAL_ALT_KODU"));
			iMap.put("KAMPANYA_KOD", lovMap.get("URUN_KAMP_KODU"));
			bMap = GMServiceExecuter.call("BNSPR_TRN3132_GET_FIRMA_BAYI_MUSTERI_NO", iMap);
			iMap.put("FIRMA_MUSTERI_NO", bMap.getBigDecimal("FIRMA_MUSTERI_NO"));
			iMap.put("FIRMA_HESAP_NO", bMap.getBigDecimal("FIRMA_HESAP_NO"));
			iMap.put("BAYI_HESAP_NO", bMap.getBigDecimal("BAYI_HESAP_NO"));
			iMap.put("BAYI_MUSTERI_NO", bMap.getBigDecimal("BAYI_MUSTERI_NO"));

			BigDecimal kampKod = new BigDecimal((String) lovMap.get("URUN_KAMP_KODU"));

			BirKampanya kampanya = (BirKampanya) session.createCriteria(BirKampanya.class).add(Restrictions.eq("kod", kampKod)).uniqueResult();
			iMap.put("FAIZSIZ_SURE", kampanya.getFaizsizSure());

			conn = DALUtil.getGMConnection();
			int i = 1;
			stmt = conn.prepareCall("{ ? = call PKG_SATICI.DistributorHesapNo(?)}");
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			iMap.put("DISTRIBUTOR_HESAP_NO", stmt.getBigDecimal(1));

			GMMap sMap = new GMMap();
			sMap = GMServiceExecuter.call("BNSPR_TRN3132_GET_SIGORTA_BILGILERI", iMap);
			if (sMap.getString("TEMINAT_KOD1") != null && ("03".equals(sMap.getString("TEMINAT_KOD1")) || "32".equals(sMap.getString("TEMINAT_KOD1")))) {
				iMap.put("SIGORTA_KOMISYON", sMap.getBigDecimal("KOMISYON1"));
				iMap.put("SIGORTA_HESABI", sMap.getBigDecimal("SIGORTA_HESABI1"));
			}
			else if (sMap.getString("TEMINAT_KOD2") != null && ("03".equals(sMap.getString("TEMINAT_KOD2")) || "32".equals(sMap.getString("TEMINAT_KOD2")))) {
				iMap.put("SIGORTA_KOMISYON_2", sMap.getBigDecimal("KOMISYON2"));
				iMap.put("SIGORTA_HESABI_2", sMap.getBigDecimal("SIGORTA_HESABI2"));
			}
			else if (sMap.getString("TEMINAT_KOD3") != null && ("03".equals(sMap.getString("TEMINAT_KOD3")) || "32".equals(sMap.getString("TEMINAT_KOD3")))) {
				iMap.put("SIGORTA_KOMISYON_2", sMap.getBigDecimal("KOMISYON3"));
				iMap.put("SIGORTA_HESABI_2", sMap.getBigDecimal("SIGORTA_HESABI3"));
			}

			if (iMap.getString("KULLANILMISMI") != null && iMap.getString("KULLANILMISMI").compareTo("0") == 0) {

				iMap.put("TRX_NO", GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap).get("TRX_NO"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3132_SAVE", iMap));

				if ("0".equals(oMap.getString("TX_STATUS"))) {
					BirKullandirim birKullandirim = (BirKullandirim) session.get(BirKullandirim.class, iMap.getBigDecimal("BASVURU_NO"));
					iMap.put("MESSAGE_NO", new BigDecimal(1755));
					iMap.put("P1", iMap.getBigDecimal("BASVURU_NO"));
					iMap.put("P2", iMap.getBigDecimal("TRX_NO"));
					iMap.put("P3", birKullandirim.getKrdHesapNo());
					oMap.put("KUL_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));
				}
				else
					oMap.put("KUL_MESSAGE", oMap.getString("MESSAGE"));
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3182_OTOMATIK_EFT")
	public static Map<?, ?> otomatikEFT(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN3132.EFT_Giris_Initials(?,?,?,?,?,?,?,?,?,?)}");

			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KRD_TUTAR"));
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.execute();

			i = 4;

			GMMap eMap = new GMMap();

			eMap.put("TRX_NO", stmt.getBigDecimal(i++));
			eMap.put("GONDEREN_BANKA", stmt.getString(i++));
			eMap.put("GONDEREN_SUBE", stmt.getString(i++));
			eMap.put("GONDEREN_SEHIR", stmt.getString(i++));
			eMap.put("MASRAF", stmt.getBigDecimal(i++));
			eMap.put("GONDEREN_VERGI_KIMLIK_NUMARASI", stmt.getString(i++));
			eMap.put("BOLUM_KODU", stmt.getString(i++));
			eMap.put("OTOMATIK_BILDIRIM_OLUSTUR", "E");
			eMap.put("ALAN_BANKA_KODU", iMap.getString("EFT_BANKA"));
			eMap.put("ALAN_SEHIR_KODU", iMap.getString("EFT_IL"));
			eMap.put("ALAN_SUBE_KODU", iMap.getString("EFT_SUBE"));
			eMap.put("ALICI_HESAP_NO", iMap.getString("EFT_HESAP_NO"));
			eMap.put("ALICININ_ADI_SOYADI", iMap.getString("ADI_SOYADI"));
			eMap.put("ALICI_ADI", iMap.getString("ADI_SOYADI"));
			eMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
			eMap.put("MUSTERI_HESAP_NO", iMap.getBigDecimal("HESAP_NO"));
			eMap.put("TUTAR", iMap.getBigDecimal("KRD_TUTAR"));
			eMap.put("TUTAR_SCR", iMap.getBigDecimal("KRD_TUTAR"));
			eMap.put("EFT_TARIH", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH"));
			eMap.put("GONDEREN", iMap.getString("ADI_SOYADI"));
			eMap.put("MESAJ_KODU", "KRED");
			eMap.put("ISLEM_TIPI", "M");
			eMap.put("MASRAF_IC_DIS", "D");
			eMap.put("MASRAF_TAHSIL_SEKLI", "H");
			eMap.put("MASRAF_HESAP_NO", iMap.getBigDecimal("HESAP_NO"));
			eMap.put("GELEN_GIDEN", "GIDEN");
			eMap.put("EKRAN_NO", "2315");
			eMap.put("KIMLIK_TIPI", "1");
			eMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2315_GET_SORGU_NO", iMap));
			eMap.put("EFT_REF", eMap.getString("REF"));
			oMap.put("TRX_NO", eMap.getBigDecimal("TRX_NO"));
			// TODO: Sorgu numaras� eklendi�inde tekrar geri koy
			oMap.put("REC_ID", eMap.getString("SORGU_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_EFT_SAVE", eMap));

			iMap.put("HATA_NO", new BigDecimal(1757));
			iMap.put("P1", iMap.getBigDecimal("BASVURU_NO"));
			iMap.put("P2", eMap.getString("SORGU_NO"));
			oMap.put("EFT_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static boolean bayiDurumKismiKapaliMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3182.bayi_durum_kismi_kapali_mi(?) }");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			return ((new BigDecimal(-1)).equals(stmt.getBigDecimal(1)));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3182_OTOMATIK_KULLANDIR")
	public static Map<?, ?> otomatikKullandir(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			iMap.put("KREDI_TUR", DALUtil.callOneParameterFunction("{? = call pkg_trn3071.basvuru_kredi_turu(?)}", Types.NUMERIC, iMap.getBigDecimal("BASVURU_NO")));

			if ("K".equals(iMap.getString("MUSTERI_KONTAKT")))
				oMap.putAll(gercekMusteriDonustur(iMap));

			if (!iMap.containsKey("SUBE_KODU") || iMap.getString("SUBE_KODU") == null || "5".equals(iMap.getString("KREDI_TUR"))) {
				if (iMap.containsKey("SUBE_KODU"))
					iMap.remove("SUBE_KODU");
				String portfoyKod = GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_KOD", new GMMap().put("BASVURU_NO", iMap.getString("BASVURU_NO"))).getString("PORTFOY_KOD");
				iMap.put("SUBE_KODU", GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_SUBE_KOD", new GMMap().put("PORTFOY_KOD", portfoyKod)).getString("PORTFOY_SUBE_KOD"));
			}

			// HESAP_NO doluysa vadesiz hesap acilmistir onceden.
			if (iMap.get("HESAP_NO") == null) {
				/** TY-1686 Kanal koduna gore onceki basvuru hesap no kontrol et. **/
				iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3181_GET_ONCEKI_BASVURU_HESAPNO", iMap));

				if (iMap.getBigDecimal("HESAP_NO") == null || iMap.getBigDecimal("REZERV_HESAP_NO") != null)
					oMap.putAll(vadesizHesapAc(iMap));
			}

			iMap.putAll(oMap);
			
			otomatikTeminatInsert(iMap);
			
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			session.refresh(birBasvuru);
			
			if("8".equals(birBasvuru.getKanalKodu())) {
				/** Sigortali web basvurular i�in poli�ele�tirme **/
				BirKampanyaSegment kampSegment = (BirKampanyaSegment) session.createCriteria(BirKampanyaSegment.class).add(Restrictions.eq("sigortaliKampKod", birBasvuru.getKampKod())).setMaxResults(1).uniqueResult();
	
				if (kampSegment != null) {
					GMMap insMap = new GMMap();
					insMap.put("BASVURU_NO", birBasvuru.getBasvuruNo());
					insMap.put("TUTAR", birBasvuru.getTutar());
					insMap.put("KAMP_KOD", kampSegment.getSigortaliKampKod());
					insMap.put("VADE", birBasvuru.getVade());
					insMap.put("SERVIS_TIPI", "TANZIM");
					insMap.put("POLICELESTIR", "E");
					GMServiceExecuter.call("BNSPR_CL_PROPOSE_CREDIT_LIFE", insMap);
				}
			}
			
			if (bayiDurumKismiKapaliMi(iMap)) {
				if ("5".equals(iMap.getString("KREDI_TUR"))) {
					oMap.putAll(KMHotomatikKullandirim(iMap));
					oMap.put("KMH_MESSAGE", oMap.getString("MESSAGE"));
				}
				else
					oMap.putAll(otomatikKullandirim(iMap));
				iMap.putAll(oMap);
				// if(iMap.getString("EFT_BANKA") != null && iMap.getString("EFT_IL") != null &&
				// iMap.getString("EFT_SUBE") != null && iMap.getString("EFT_HESAP_NO") != null)
				// oMap.putAll(otomatikEFT(iMap));
			}
			else {
				iMap.put("MESSAGE_NO", new BigDecimal(1060));
				oMap.put("OTO_MESSAGE", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));
			}
			String mesg = "";
			if (oMap.getString("GM_MESSAGE") != null)
				mesg = mesg + oMap.getString("GM_MESSAGE") + " ";
			if (oMap.getString("VH_MESSAGE") != null)
				mesg = mesg + oMap.getString("VH_MESSAGE") + " ";
			if (oMap.getString("TEM_MESSAGE") != null)
				mesg = mesg + oMap.getString("TEM_MESSAGE") + " ";
			if (oMap.getString("KUL_MESSAGE") != null)
				mesg = mesg + oMap.getString("KUL_MESSAGE") + " ";
			if (oMap.getString("EFT_MESSAGE") != null)
				mesg = mesg + oMap.getString("EFT_MESSAGE") + " ";
			if (oMap.getString("OTO_MESSAGE") != null)
				mesg = mesg + oMap.getString("OTO_MESSAGE") + " ";
			if (oMap.getString("KMH_MESSAGE") != null)
				mesg = mesg + oMap.getString("KMH_MESSAGE") + " ";

			System.out.println(mesg);
			oMap.put("MESSAGE", mesg);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3182_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuruBelgeKontrolTx birBasvuruBelgeKontrolTx = (BirBasvuruBelgeKontrolTx) session.createCriteria(BirBasvuruBelgeKontrolTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			String islemSonrasiDurumKodu = birBasvuruBelgeKontrolTx.getIslemSonrasiDurumKodu();
			String durumKodu = birBasvuruBelgeKontrolTx.getDurumKodu();

			iMap.put("BASVURU_NO", birBasvuruBelgeKontrolTx.getId().getBasvuruNo());
			BirBasvuruBelgeTx birBasvuruBelgeTx = null;
			GMMap pMap = ConsumerLoanCommonServices.getParamTextLists("BHS_DOKUMAN_KODLARI", "BHS_PARAM_TABLE");
			
			/** dokuman ftp transfer **/
			if ("CEPTE".equals(islemSonrasiDurumKodu)) {
				GMMap sorguMap = new GMMap();
				sorguMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				GMServiceExecuter.execute("BNSPR_TRN3182_GECICI_DOKUMAN_TRANSFER_ET", sorguMap);
			}
			/** ftp transfer sonu **/

			if ("IPTAL,KAPANDI".contains(islemSonrasiDurumKodu) || ("CEPTE".equals(durumKodu) && "CEPTE".equals(islemSonrasiDurumKodu))) {
				return oMap;
			}
			HashMap<?, ?> lovMap = LovHelper.diLovAll(birBasvuruBelgeKontrolTx.getId().getBasvuruNo(), null, "3182/LOV_OTO_KUL_BASVURU");
			iMap.put("BASVURU_NO", lovMap.get("BASVURU_NO"));
			iMap.put("MUSTERI_KONTAKT", lovMap.get("MUSTERI_KONTAKT"));
			iMap.put("MUSTERI_NO", lovMap.get("MUSTERI_NO"));
			iMap.put("CUSTOMER_NO", lovMap.get("MUSTERI_NO"));
			iMap.put("TC_KIMLIK_NO", lovMap.get("TC_KIMLIK_NO"));
			iMap.put("CALISMA_TIPI", lovMap.get("CALISMA_SEKLI_KOD"));
			iMap.put("DURUM_KODU", lovMap.get("DURUM_KODU"));
			iMap.put("KANAL_KODU", lovMap.get("KANAL_KODU"));
			iMap.put("EFT_HESAP_NO", lovMap.get("EFT_HESAP_NO"));
			iMap.put("EFT_IL", lovMap.get("EFT_IL"));
			iMap.put("EFT_SUBE", lovMap.get("EFT_SUBE"));
			iMap.put("EFT_BANKA", lovMap.get("EFT_BANKA"));
			iMap.put("ADI_SOYADI", lovMap.get("MUSTERI_ADI"));
			iMap.put("APS_BILGILERI_UYUMLUMU", lovMap.get("APS_BILGILERI_UYUMLUMU"));
			iMap.put("CEP_TEL_NO", lovMap.get("CEP_TEL_NO"));
			iMap.put("KIMLIK_SERI_SIRA_NO", lovMap.get("KIMLIK_SERI_SIRA_NO"));
			iMap.put("URUN_KAMP_KOD", lovMap.get("URUN_KAMP_KOD"));
			iMap.put("ONCEKI_SOYAD", lovMap.get("ONCEKI_SOYAD"));
			iMap.put("ADK_MUSTERISIMI", lovMap.get("ADK_MUSTERISIMI"));
			iMap.put("SATICI_HESAP_SUBE_KODU", lovMap.get("SATICI_HESAP_SUBE_KODU"));
			iMap.put("SUBE_KODU", lovMap.get("SUBE_KODU"));
			iMap.put("KREDI_TUR", lovMap.get("KREDI_TUR"));

			// kmh ise event yarat
			if ("KUL".equals(lovMap.get("DURUM_KODU")) && "5".equals(iMap.getString("KREDI_TUR"))) {
				GMServiceExecuter.execute("BNSPR_KMH_EVENT_YARAT", iMap);
			}

			// Sozlesme Belgeleri orjinal ve uygunsa, "KULLANDIRIM" adimi beklenmeden otomatik olarak vadesiz hesap acilir...
			oMap.putAll(belgelerOkIseOtomatikHesapAc(iMap));

			if ("KUL".equals(lovMap.get("DURUM_KODU")) && "E".equals(birBasvuruBelgeKontrolTx.getOtomatikKullandirim())) {
				if ("K".equals(iMap.getString("MUSTERI_KONTAKT")) && "M".equals(oMap.getString("MUSTERI_KONTAKT"))) {
					iMap.put("MUSTERI_KONTAKT", "M");
				}
				iMap.put("HESAP_NO", oMap.get("HESAP_NO"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_OTOMATIK_KULLANDIR", iMap));
			}
			
			/** adk musteri flag tekrar kontrol ediliyor  **/
			GnlMusteri musteri = (GnlMusteri) session.get(GnlMusteri.class, iMap.getBigDecimal("MUSTERI_NO"));
			session.refresh(musteri);
			iMap.put("ADK_MUSTERISIMI_ONCESI", iMap.getString("ADK_MUSTERISIMI"));
			iMap.put("ADK_MUSTERISIMI", musteri.getAdkMusterisimi());
			if (("2".equals(iMap.getString("CALISMA_TIPI")) || "3".equals(iMap.getString("CALISMA_TIPI")) || "1".equals(iMap.getString("CALISMA_TIPI"))) && !"E".equals(iMap.getString("ADK_MUSTERISIMI"))) // Orijinal Evraks�z or Elektronik Evrakl�
			{
				birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.dokumanKod", "1")).add(Restrictions.eq("id.kimden", "M")).uniqueResult();
				if (birBasvuruBelgeTx != null && "1".equals(birBasvuruBelgeTx.getBelgeKontrol()) && "E".equals(birBasvuruBelgeTx.getOrjinalEvrakMi()) && (iMap.getString("CEP_TEL_NO") != null && !iMap.getString("CEP_TEL_NO").isEmpty()))
					iMap.put("ADK_MUSTERISIMI", "E");
				else {
					for (int i = 0; i < pMap.getSize("BHS_PARAM_TABLE"); i++) {
						birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.dokumanKod", pMap.getString("BHS_PARAM_TABLE", i, "CODE"))).add(Restrictions.eq("id.kimden", "M")).uniqueResult();
						if (birBasvuruBelgeTx != null && "1".equals(birBasvuruBelgeTx.getBelgeKontrol()) && "E".equals(birBasvuruBelgeTx.getOrjinalEvrakMi()) && (iMap.getString("CEP_TEL_NO") != null && !iMap.getString("CEP_TEL_NO").isEmpty())) {
							iMap.put("ADK_MUSTERISIMI", "E");
							break;
						}
						else
							iMap.put("ADK_MUSTERISIMI", "H");
					}
				}
				if ("E".equals(iMap.getString("ADK_MUSTERISIMI")))
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_GERCEK_MUSTERI_ADK_GUNCELLE", iMap));
			}

			/*izinli pazarlama*/
			if ("E".equals(birBasvuruBelgeKontrolTx.getIzinliPazarlama())) {
				GMServiceExecuter.call("BNSPR_CUSTOMER_UPDATE_MARKETING_PERMISSION", iMap);
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	private static void musteriBlokesiGuncelle(GMMap iMap) {
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if ("7".equals(birBasvuru.getKanalKodu())) {
				conn = DALUtil.getGMConnection();

				query = "{? = call pkg_trn3182.Musteri_Blokesi_Guncelle(?,?,?)}";
				stmt = conn.prepareCall(query);
				stmt.registerOutParameter(1, Types.NUMERIC);
				stmt.setBigDecimal(2, birBasvuru.getMusteriNo());
				stmt.setString(3, iMap.getString("BELGE_DURUM"));
				stmt.setBigDecimal(4, iMap.getBigDecimal("ISLEM_NO"));
				stmt.execute();

				GMMap blokeMap = new GMMap();
				blokeMap.put("ISLEM_KODU", new java.math.BigDecimal("4131"));
				blokeMap.put("ISLEM_NO", stmt.getBigDecimal(1));
				GMServiceExecuter.call("BNSPR_TRN4131_AFTER_APPROVAL", blokeMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3182_MUSTERI_GUNCELLEME")
	public static GMMap updateCustomerInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) iMap.get("MUSTERI_ESLESTIRME_LIST_MODEL");
			String tableName = "MUSTERI_ESLESTIRME_LIST_MODEL";
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			for (int i = 0; i < list.size(); i++) {
				boolean adresTeyit = iMap.getBoolean("ADRES_TEYIT") && "00010".equals(iMap.getString(tableName, i, "EV_ADRES"));
				boolean apsAdresTeyit = false;
				if (iMap.getBoolean("ADRES_TEYIT") && "00010".equals(iMap.getString(tableName, i, "APS_ADRES")) && "00010".equals(iMap.getString(tableName, i, "EV_ADRES"))) {
					GMMap sMap = new GMMap();
					sMap.put("HATA_NO", new BigDecimal(2188));
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
				}
				if ("00010".equals(iMap.getString(tableName, i, "APS_ADRES"))) {
					adresTeyit = false;
					apsAdresTeyit = true;
				}
				if (!"11111".equals(iMap.getString(tableName, i, "UPDATE"))) {
					continue;
				}
				if ("M".equals(iMap.getString(tableName, i, "KIM_ICIN"))) {
					BirBasvuruKimlik kimlik = (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, iMap.getBigDecimal("BASVURU_NO"));

					GMMap kontakt = new GMMap();
					kontakt.put("MUSTERI_NO", iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
					kontakt.put("DURUM_KODU", "A");
					BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRN1040_CREATE_TRX_NO", kontakt).getBigDecimal("TRX_NO");
					kontakt.putAll(GMServiceExecuter.execute("BNSPR_TRN10041_GET_INFO", new GMMap().put("TRX_NO", trxNo)));

					if (adresTeyit)
						kontakt.put("F_APS_TEYIT", false);
					if (apsAdresTeyit)
						kontakt.put("F_APS_TEYIT", true);

					if (kontakt.getBoolean("F_SAHTE")) {
						kontakt.remove("F_SAHTE");
						kontakt.put("F_SAHTE", "1");
					}
					else {
						kontakt.remove("F_SAHTE");
						kontakt.put("F_SAHTE", "0");
					}
					if (kontakt.getBoolean("F_MUSTERIYE_CEVRILEBILIR")) {
						kontakt.remove("F_MUSTERIYE_CEVRILEBILIR");
						kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "1");
					}
					else {
						kontakt.remove("F_MUSTERIYE_CEVRILEBILIR");
						kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "0");
					}

					kontakt.put("TRX_NO", trxNo);
					if ("E".equals(birBasvuru.getKpsYapildi())) {
						kontakt.put("TCKNO_IN", kimlik.getTcKimlikNo());
						kontakt.put("TCKNO_OUT", kimlik.getTcKimlikNo());
						kontakt.put("ISIM", kimlik.getAd());
						kontakt.put("IKINCI_ISIM", kimlik.getIkinciAd());
						kontakt.put("SOYADI", kimlik.getSoyad());
						kontakt.put("BABA_ADI", kimlik.getBabaAd());
						kontakt.put("ANNE_ADI", kimlik.getAnneAdi());
						kontakt.put("DOGUM_YERI", kimlik.getDogumYeri());
						kontakt.put("DOGUM_TARIHI", kimlik.getDogumTar());
						kontakt.put("UYRUK_KOD", kimlik.getUyrukKod());
						kontakt.put("CINSIYET_KOD", kimlik.getCinsiyet());
						kontakt.put("MEDENI_HAL_KOD", kimlik.getMedeniHal());
						kontakt.put("AILE_SIRA_NO", kimlik.getAileSiraNo());
						kontakt.put("CILT_NO", kimlik.getCiltNo());
						kontakt.put("SIRA_NO", kimlik.getBireySiraNo());
						kontakt.put("VERILDIGI_YER", kimlik.getNufusVerYer());
						kontakt.put("VERILDIGI_TARIH", kimlik.getNufusVerTar());
						kontakt.put("NUF_VERILIS_NEDENI", kimlik.getNufusVerNedeni());
						kontakt.put("MAHALLE_KOY", kimlik.getMahalleKoy());
						kontakt.put("IL_KOD", kimlik.getNufusIlKod());
						kontakt.put("ILCE_KOD", kimlik.getNufusIlceKod());
						kontakt.put("KISA_AD", kimlik.getAd() + " " + (kimlik.getIkinciAd() == null ? "" : kimlik.getIkinciAd() + " ") + kimlik.getSoyad());

						if (kontakt.getString("NUFUS_CUZDANI_SERI_NO") != null && !kontakt.getString("NUFUS_CUZDANI_SERI_NO").isEmpty())
							kontakt.put("F_NUF", "E");
					}

					if (kontakt.getString("KISA_AD") == null || kontakt.getString("KISA_AD").isEmpty())
						kontakt.put("KISA_AD", kimlik.getAd() + " " + (kimlik.getIkinciAd() == null ? "" : kimlik.getIkinciAd() + " ") + kimlik.getSoyad());

					kontakt.put("MESLEK_KOD", kimlik.getMeslekKod());
					kontakt.put("CALISMA_SEKLI", kimlik.getCalismaSekli());
					kontakt.put("UNVAN_KOD", kimlik.getUnvanKod());
					kontakt.put("F_ISTEGE_BAGLI_SIGORTALI", kimlik.getSigortaliMi());

					if ("00010".equals(iMap.getString(tableName, i, "EPOSTA"))) {
						kontakt.put("EMAIL_KISISEL", kimlik.getEMail());
					}

					if ("00010".equals(iMap.getString(tableName, i, "ANNE_KIZLIK"))) {
						kontakt.put("ANNE_KIZLIK_SOYADI", kimlik.getAnneKizlik());
					}
					ArrayList<HashMap<String, Object>> telefonList = new ArrayList<HashMap<String, Object>>();

					telefonList = (ArrayList<HashMap<String, Object>>) kontakt.get("TELEFON_LIST");
					if (telefonList != null && "00010".equals(iMap.getString(tableName, i, "CEP_TEL"))) {
						for (int row = 0; row < telefonList.size(); row++) {
							kontakt.put("TELEFON_LIST", row, "F_ILETISIM", "0");
						}
					}
					if ("00010".equals(iMap.getString(tableName, i, "IS_TEL"))) {
						boolean add = true;
						int row = 0;
						if (telefonList != null) {
							for (int j = 0; j < telefonList.size(); j++) {

								// dont add same tel
								if ("2".equals(kontakt.getString("TELEFON_LIST", j, "TEL_TIP")) && "90".equals(kontakt.getString("TELEFON_LIST", j, "ULKE_KODU")) && ((kimlik.getIsTelAlan() == null && kontakt.getString("TELEFON_LIST", j, "ALAN_KOD") == null) || (kimlik.getIsTelAlan() != null && kontakt.getString("TELEFON_LIST", j, "ALAN_KOD") != null && kimlik.getIsTelAlan().equals(kontakt.getString("TELEFON_LIST", j, "ALAN_KOD")))) && ((kimlik.getIsTelNo() == null && kontakt.getString("TELEFON_LIST", j, "TEL_NO") == null) || (kimlik.getIsTelNo() != null && kontakt.getString("TELEFON_LIST", j, "TEL_NO") != null && kimlik.getIsTelNo().equals(kontakt.getString("TELEFON_LIST", j, "TEL_NO")))) && ((kimlik.getIsTelDahili() == null && kontakt.getString("TELEFON_LIST", j, "DAH_NO") == null) || (kimlik.getIsTelDahili() != null && kontakt.getString("TELEFON_LIST", j, "DAH_NO") != null && kimlik.getIsTelDahili().equals(kontakt.getString("TELEFON_LIST", j, "DAH_NO"))))) {

									add = false;
									break;

								}
							}
							row = telefonList.size();
						}
						if (add) {
							kontakt.put("TELEFON_LIST", row, "TEL_TIP", "2");
							kontakt.put("TELEFON_LIST", row, "ALAN_KOD", kimlik.getIsTelAlan());
							kontakt.put("TELEFON_LIST", row, "TEL_NO", kimlik.getIsTelNo());
							kontakt.put("TELEFON_LIST", row, "DAH_NO", kimlik.getIsTelDahili());
							kontakt.put("TELEFON_LIST", row, "ULKE_KODU", "90");
						}

					}

					telefonList = (ArrayList<HashMap<String, Object>>) kontakt.get("TELEFON_LIST");
					if ("00010".equals(iMap.getString(tableName, i, "EV_TEL"))) {
						boolean add = true;
						int row = 0;
						if (telefonList != null) {
							for (int j = 0; j < telefonList.size(); j++) {

								// dont add same tel
								if ("1".equals(kontakt.getString("TELEFON_LIST", j, "TEL_TIP")) && "90".equals(kontakt.getString("TELEFON_LIST", j, "ULKE_KODU")) && ((kimlik.getEvTelAlan() == null && kontakt.getString("TELEFON_LIST", j, "ALAN_KOD") == null) || (kimlik.getEvTelAlan() != null && kontakt.getString("TELEFON_LIST", j, "ALAN_KOD") != null && kimlik.getEvTelAlan().equals(kontakt.getString("TELEFON_LIST", j, "ALAN_KOD")))) && ((kimlik.getEvTelNo() == null && kontakt.getString("TELEFON_LIST", j, "TEL_NO") == null) || (kimlik.getEvTelNo() != null && kontakt.getString("TELEFON_LIST", j, "TEL_NO") != null && kimlik.getEvTelNo().equals(kontakt.getString("TELEFON_LIST", j, "TEL_NO"))))) {

									add = false;
									break;

								}
							}
							row = telefonList.size();
						}
						if (add) {
							kontakt.put("TELEFON_LIST", row, "TEL_TIP", "1");
							kontakt.put("TELEFON_LIST", row, "ALAN_KOD", kimlik.getEvTelAlan());
							kontakt.put("TELEFON_LIST", row, "TEL_NO", kimlik.getEvTelNo());
							kontakt.put("TELEFON_LIST", row, "ULKE_KODU", "90");
						}
					}

					telefonList = (ArrayList<HashMap<String, Object>>) kontakt.get("TELEFON_LIST");
					if ("00010".equals(iMap.getString(tableName, i, "CEP_TEL"))) {
						boolean add = true;
						int row = 0;
						if (telefonList != null) {
							for (int j = 0; j < telefonList.size(); j++) {

								// dont add same tel
								if ("3".equals(kontakt.getString("TELEFON_LIST", j, "TEL_TIP")) && "90".equals(kontakt.getString("TELEFON_LIST", j, "ULKE_KODU")) && ((kimlik.getCepTelAlanKodu() == null && kontakt.getString("TELEFON_LIST", j, "ALAN_KOD") == null) || (kimlik.getCepTelAlanKodu() != null && kontakt.getString("TELEFON_LIST", j, "ALAN_KOD") != null && kimlik.getCepTelAlanKodu().equals(kontakt.getString("TELEFON_LIST", j, "ALAN_KOD")))) && ((kimlik.getCepTelNo() == null && kontakt.getString("TELEFON_LIST", j, "TEL_NO") == null) || (kimlik.getCepTelNo() != null && kontakt.getString("TELEFON_LIST", j, "TEL_NO") != null && kimlik.getCepTelNo().equals(kontakt.getString("TELEFON_LIST", j, "TEL_NO"))))) {

									kontakt.put("TELEFON_LIST", j, "F_ILETISIM", "1");
									add = false;
									break;

								}
							}
							row = telefonList.size();
						}
						if (add) {
							kontakt.put("TELEFON_LIST", row, "TEL_TIP", "3");
							kontakt.put("TELEFON_LIST", row, "ALAN_KOD", kimlik.getCepTelAlanKodu());
							kontakt.put("TELEFON_LIST", row, "TEL_NO", kimlik.getCepTelNo());
							kontakt.put("TELEFON_LIST", row, "ULKE_KODU", "90");
							kontakt.put("TELEFON_LIST", row, "F_ILETISIM", "1");
						}
					}

					ArrayList<HashMap<String, Object>> adresList = new ArrayList<HashMap<String, Object>>();

					adresList = (ArrayList<HashMap<String, Object>>) kontakt.get("ADRES_LIST");
					boolean yeniYazismaAdresi = ("00010".equals(iMap.getString(tableName, i, "IS_ADRES")) && "I".equals(kimlik.getYazismaAdresKod())) || ("00010".equals(iMap.getString(tableName, i, "EV_ADRES")) && "E".equals(kimlik.getYazismaAdresKod()));
					if ("00010".equals(iMap.getString(tableName, i, "IS_ADRES"))) {
						int row = 0;
						boolean makeYazismaAdresi = false;
						if (adresList != null) {
							for (row = 0; row < adresList.size(); row++) {
								HashMap<String, Object> adressMap = adresList.get(row);
								String adresKod = (String) adressMap.get("ADRES_KOD");
								if (adresKod.startsWith("I")) {
									if (adresKod.length() == 1) {
										kontakt.put("ADRES_LIST", row, "ADRES_KOD", "I1");
										if (!yeniYazismaAdresi && "1".equals(kontakt.getString("ADRES_LIST", row, "EXTRE_ADRES_KOD_F"))) {
											makeYazismaAdresi = true;
										}
									}
									else {
										int newAdresKod = Integer.parseInt(adresKod.substring(1));
										kontakt.put("ADRES_LIST", row, "ADRES_KOD", "I" + (newAdresKod + 1));
									}
									kontakt.put("ADRES_LIST", row, "EXTRE_ADRES_KOD_F", "0");
									if (adresTeyit) {
										kontakt.put("ADRES_LIST", row, "ADRES_TEYIT", false);
									}
								}
							}
							row = adresList.size();
						}

						kontakt.put("ADRES_LIST", row, "ADRES_KOD", "I");
						kontakt.put("ADRES_LIST", row, "ISYERI_UNVANI", kimlik.getIsyeriAdi());
						kontakt.put("ADRES_LIST", row, "ADRES", kimlik.getIsAdres());
						kontakt.put("ADRES_LIST", row, "ADRES_IL_KOD", kimlik.getIsAdrIlKod());
						kontakt.put("ADRES_LIST", row, "ADRES_ILCE_KOD", kimlik.getIsAdrIlceKod());
						kontakt.put("ADRES_LIST", row, "ULKE_KOD", "TR");
						kontakt.put("ADRES_LIST", row, "POSTA_KOD", kimlik.getIsPostakod());
						kontakt.put("ADRES_LIST", row, "ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
						if ("I".equals(kimlik.getYazismaAdresKod()) || makeYazismaAdresi) {
							kontakt.put("ADRES_LIST", row, "EXTRE_ADRES_KOD_F", "1");
						}
						else {
							kontakt.put("ADRES_LIST", row, "EXTRE_ADRES_KOD_F", "0");
						}
						kontakt.put("ADRES_LIST", row, "ADRES_TEYIT", false);
					}

					adresList = (ArrayList<HashMap<String, Object>>) kontakt.get("ADRES_LIST");
					if ("00010".equals(iMap.getString(tableName, i, "EV_ADRES"))) {
						int row = 0;
						boolean makeYazismaAdresi = false;
						if (adresList != null) {
							for (row = 0; row < adresList.size(); row++) {
								HashMap<String, Object> adressMap = adresList.get(row);
								String adresKod = (String) adressMap.get("ADRES_KOD");
								if (adresKod.startsWith("E")) {
									if (adresKod.length() == 1) {
										kontakt.put("ADRES_LIST", row, "ADRES_KOD", "E1");
										if (!yeniYazismaAdresi && "1".equals(kontakt.getString("ADRES_LIST", row, "EXTRE_ADRES_KOD_F"))) {
											makeYazismaAdresi = true;
										}
									}
									else {
										int newAdresKod = Integer.parseInt(adresKod.substring(1));
										kontakt.put("ADRES_LIST", row, "ADRES_KOD", "E" + (newAdresKod + 1));
									}
									kontakt.put("ADRES_LIST", row, "EXTRE_ADRES_KOD_F", "0");
									if (adresTeyit) {
										kontakt.put("ADRES_LIST", row, "ADRES_TEYIT", false);
									}
								}
							}
							row = adresList.size();
						}
						kontakt.put("ADRES_LIST", row, "ADRES_KOD", "E");
						kontakt.put("ADRES_LIST", row, "ADRES", kimlik.getEvAdres());
						kontakt.put("ADRES_LIST", row, "ADRES_IL_KOD", kimlik.getEvAdrIlKod());
						kontakt.put("ADRES_LIST", row, "ADRES_ILCE_KOD", kimlik.getEvAdrIlceKod());
						kontakt.put("ADRES_LIST", row, "ULKE_KOD", "TR");
						kontakt.put("ADRES_LIST", row, "POSTA_KOD", kimlik.getEvPostakod());
						kontakt.put("ADRES_LIST", row, "ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
						if ("E".equals(kimlik.getYazismaAdresKod()) || makeYazismaAdresi) {
							kontakt.put("ADRES_LIST", row, "EXTRE_ADRES_KOD_F", "1");
						}
						else {
							kontakt.put("ADRES_LIST", row, "EXTRE_ADRES_KOD_F", "0");
						}
						kontakt.put("ADRES_LIST", row, "ADRES_TEYIT", adresTeyit);
					}

					// remove same addresses
					adresList = (ArrayList<HashMap<String, Object>>) kontakt.get("ADRES_LIST");
					boolean extreKodE = false;
					boolean extreKodI = false;
					ArrayList<Integer> deletedE = new ArrayList<Integer>();
					ArrayList<Integer> deletedI = new ArrayList<Integer>();
					for (int j = 0; j < adresList.size(); j++) {
						HashMap<String, Object> adressMap = adresList.get(j);
						String adresKod = (String) adressMap.get("ADRES_KOD");
						if (adresKod.startsWith("E")) {
							if (adresKod.length() > 1) {
								if ("TR".equals(kontakt.getString("ADRES_LIST", j, "ULKE_KOD")) && ((kimlik.getEvAdres() == null && kontakt.getString("ADRES_LIST", j, "ADRES") == null) || (kimlik.getEvAdres() != null && kontakt.getString("ADRES_LIST", j, "ADRES") != null && kimlik.getEvAdres().trim().equals(kontakt.getString("ADRES_LIST", j, "ADRES").trim()))) && ((kimlik.getEvAdrIlKod() == null && kontakt.getString("ADRES_LIST", j, "ADRES_IL_KOD") == null) || (kimlik.getEvAdrIlKod() != null && kontakt.getString("ADRES_LIST", j, "ADRES_IL_KOD") != null && kimlik.getEvAdrIlKod().trim().equals(kontakt.getString("ADRES_LIST", j, "ADRES_IL_KOD").trim()))) && ((kimlik.getEvAdrIlceKod() == null && kontakt.getString("ADRES_LIST", j, "ADRES_ILCE_KOD") == null) || (kimlik.getEvAdrIlceKod() != null && kontakt.getString("ADRES_LIST", j, "ADRES_ILCE_KOD") != null && kimlik.getEvAdrIlceKod().trim().equals(kontakt.getString("ADRES_LIST", j, "ADRES_ILCE_KOD").trim()))) && ((kimlik.getEvPostakod() == null && kontakt.getString("ADRES_LIST", j, "POSTA_KOD") == null) || (kimlik.getEvPostakod() != null && kontakt.getString("ADRES_LIST", j, "POSTA_KOD") != null && kimlik.getEvPostakod().trim().equals(kontakt.getString("ADRES_LIST", j, "POSTA_KOD").trim())))) {

									if ("1".equals(kontakt.getString("ADRES_LIST", j, "EXTRE_ADRES_KOD_F"))) {
										extreKodE = true;
									}
									adresList.remove(j);
									j--;
									deletedE.add(Integer.parseInt(adresKod.substring(1)));
								}
							}
						}
						else if (adresKod.startsWith("I")) {
							if (adresKod.length() > 1) {
								if ("TR".equals(kontakt.getString("ADRES_LIST", j, "ULKE_KOD")) && ((kimlik.getIsyeriAdi() == null && kontakt.getString("ADRES_LIST", j, "ISYERI_UNVANI") == null) || (kimlik.getIsyeriAdi() != null && kontakt.getString("ADRES_LIST", j, "ISYERI_UNVANI") != null && kimlik.getIsyeriAdi().trim().equals(kontakt.getString("ADRES_LIST", j, "ISYERI_UNVANI").trim()))) && ((kimlik.getIsAdres() == null && kontakt.getString("ADRES_LIST", j, "ADRES") == null) || (kimlik.getIsAdres() != null && kontakt.getString("ADRES_LIST", j, "ADRES") != null && kimlik.getIsAdres().trim().equals(kontakt.getString("ADRES_LIST", j, "ADRES").trim()))) && ((kimlik.getIsAdrIlKod() == null && kontakt.getString("ADRES_LIST", j, "ADRES_IL_KOD") == null) || (kimlik.getIsAdrIlKod() != null && kontakt.getString("ADRES_LIST", j, "ADRES_IL_KOD") != null && kimlik.getIsAdrIlKod().trim().equals(kontakt.getString("ADRES_LIST", j, "ADRES_IL_KOD").trim()))) && ((kimlik.getIsAdrIlceKod() == null && kontakt.getString("ADRES_LIST", j, "ADRES_ILCE_KOD") == null) || (kimlik.getIsAdrIlceKod() != null && kontakt.getString("ADRES_LIST", j, "ADRES_ILCE_KOD") != null && kimlik.getIsAdrIlceKod().trim().equals(kontakt.getString("ADRES_LIST", j, "ADRES_ILCE_KOD").trim()))) && ((kimlik.getIsPostakod() == null && kontakt.getString("ADRES_LIST", j, "POSTA_KOD") == null) || (kimlik.getIsPostakod() != null && kontakt.getString("ADRES_LIST", j, "POSTA_KOD") != null && kimlik.getIsPostakod().trim().equals(kontakt.getString("ADRES_LIST", j, "POSTA_KOD").trim())))) {

									if ("1".equals(kontakt.getString("ADRES_LIST", j, "EXTRE_ADRES_KOD_F"))) {
										extreKodI = true;
									}
									adresList.remove(j);
									j--;
									deletedI.add(Integer.parseInt(adresKod.substring(1)));
								}
							}
						}
					}
					for (int j = 0; j < adresList.size(); j++) {
						HashMap<String, Object> adressMap = adresList.get(j);
						String adresKod = (String) adressMap.get("ADRES_KOD");
						if (adresKod.startsWith("E")) {
							if (adresKod.length() == 1) {
								if (extreKodE) {
									kontakt.put("ADRES_LIST", j, "EXTRE_ADRES_KOD_F", "1");
								}
							}
							else {
								int count = 0;
								int order = Integer.parseInt(adresKod.substring(1));
								for (int k = 0; k < deletedE.size(); k++) {
									if (deletedE.get(k) < order) {
										count++;
									}
								}
								kontakt.put("ADRES_LIST", j, "ADRES_KOD", "E" + (order - count));
							}
						}
						else if (adresKod.startsWith("I")) {
							if (adresKod.length() == 1) {
								if (extreKodI) {
									kontakt.put("ADRES_LIST", j, "EXTRE_ADRES_KOD_F", "1");
								}
							}
							else {
								int count = 0;
								int order = Integer.parseInt(adresKod.substring(1));
								for (int k = 0; k < deletedI.size(); k++) {
									if (deletedI.get(k) < order) {
										count++;
									}
								}
								kontakt.put("ADRES_LIST", j, "ADRES_KOD", "I" + (order - count));
							}
						}
					}

					/** Aps adresi eklenmeli. Eger daha �nce kayitliysa ve farkliysa guncellenmeli. **/
					adresList = (ArrayList<HashMap<String, Object>>) kontakt.get("ADRES_LIST");
					ArrayList<HashMap<String, Object>> adresListNew = new ArrayList<HashMap<String, Object>>();
					boolean addApsAddress = true;
					boolean ekstreAdresAps = false;
					iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_APS_INFO", iMap));
					HashMap<String, Object> rowData = ConsumerLoanTRN3171Services.getAPSAddressObject(iMap);
					for (int j = 0; j < adresList.size(); j++) {
						HashMap<String, Object> adrMap = adresList.get(j);
						String adresKod = (String) adrMap.get("ADRES_KOD");
						if ("A".equals(adresKod)) {
							if (rowData.get("ADRES") != null && adrMap.get("ADRES") != null && rowData.get("ADRES").toString().equals(adrMap.get("ADRES").toString())) {
								rowData.put("ADRES_KOD", "A");
								rowData.put("ISYERI_UNVANI", adrMap.get("ISYERI_UNVANI"));
								rowData.put("ADRES", adrMap.get("ADRES"));
								rowData.put("SEMT", adrMap.get("SEMT"));
								rowData.put("ADRES_IL_KOD", adrMap.get("ADRES_IL_KOD"));
								rowData.put("ADRES_ILCE_KOD", adrMap.get("ADRES_ILCE_KOD"));
								rowData.put("ULKE_KOD", adrMap.get("ULKE_KOD"));
								rowData.put("POSTA_KOD", adrMap.get("POSTA_KOD"));
								rowData.put("ADRES_TEYIT", false);
								rowData.put("UPD_DATE", adrMap.get("UPD_DATE"));
								rowData.put("EXTRE_ADRES_KOD_F", "E");
								rowData.put("ILK_GECERLILIK_TARIHI", adrMap.get("ILK_GECERLILIK_TARIHI"));
								rowData.put("SON_GECERLILIK_TARIHI", adrMap.get("SON_GECERLILIK_TARIHI"));

								adresListNew.add(rowData);
								addApsAddress = false;
								ekstreAdresAps = true;
							}
						}
						else {
							adresListNew.add(adrMap);
						}
					}

					if (addApsAddress && iMap.get("ADRES_NO") != null && !"0".equals(iMap.getString("ADRES_NO")) && iMap.get("YABANCI_ULKE_KOD") == null) {
						adresListNew.add(rowData);
						ekstreAdresAps = true;
					}
					if (ekstreAdresAps) {
						for (int row = 0; row < adresListNew.size(); row++) {
							HashMap<String, Object> adrMap = adresListNew.get(row);
							String adresKod = (String) adrMap.get("ADRES_KOD");
							if ((adresKod != null && adresKod.startsWith("E")) || (adresKod != null && adresKod.startsWith("I"))) {
								adrMap.put("EXTRE_ADRES_KOD_F", "H");
							}
							adresListNew.set(row, adrMap);
						}
					}
					for (int row = 0; row < adresListNew.size(); row++) {
						HashMap<String, Object> adrMap = adresListNew.get(row);
						String adresKod = (String) adrMap.get("ADRES_KOD");
						if ((adresKod != null && "E3".equals(adresKod)) || (adresKod != null && "I3".equals(adresKod))) {
							adresListNew.remove(row);
							row--;
						}
					}
					kontakt.put("ADRES_LIST", adresListNew);

					/** aps adresi ekleme/guncelleme son **/

					// �ifte vatanda�l�k : R ("Hay�r")
					// Green Card : R("De�ilim")

					if (iMap.getString("F_CIFTE_VATANDAS") == null) {
						kontakt.put("F_CIFTE_VATANDAS", "R");
					}
					if (iMap.getString("F_GREEN_CARD") == null) {
						kontakt.put("F_GREEN_CARD", "R");
					}

					// Musteri tanimlama + guncelleme islemlerinin onaysiz gerceklesmesi
					kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
					kontakt.put("DONT_SEND_TRANSACTION", "E");
					GMServiceExecuter.execute("BNSPR_TRN10041_SAVE", kontakt);
					BirBasvuruMustGuncelleTx birBasvuruMustGuncelleTx = (BirBasvuruMustGuncelleTx) session.createCriteria(BirBasvuruMustGuncelleTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.musteriTxNo", trxNo)).add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal(tableName, i, "MUSTERI_NO"))).uniqueResult();
					if (birBasvuruMustGuncelleTx == null) {
						birBasvuruMustGuncelleTx = new BirBasvuruMustGuncelleTx(new BirBasvuruMustGuncelleTxId(iMap.getBigDecimal("TRX_NO"), trxNo, iMap.getBigDecimal(tableName, i, "MUSTERI_NO")));
					}
					session.saveOrUpdate(birBasvuruMustGuncelleTx);

					session.flush();
				}
				else {
					BirBasvuruKefil kimlik = null;
					if ("K1".equals(iMap.getString(tableName, i, "KIM_ICIN"))) {
						kimlik = (BirBasvuruKefil) session.createCriteria(BirBasvuruKefil.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("siraNo", new BigDecimal(1))).uniqueResult();
					}
					else if ("K2".equals(iMap.getString(tableName, i, "KIM_ICIN"))) {
						kimlik = (BirBasvuruKefil) session.createCriteria(BirBasvuruKefil.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("siraNo", new BigDecimal(2))).uniqueResult();
					}

					GMMap kontakt = new GMMap();
					kontakt.put("MUSTERI_NO", iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
					kontakt.put("DURUM_KODU", "A");
					BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRN1040_CREATE_TRX_NO", kontakt).getBigDecimal("TRX_NO");
					kontakt.putAll(GMServiceExecuter.execute("BNSPR_TRN10041_GET_INFO", new GMMap().put("TRX_NO", trxNo)));
					if (adresTeyit)
						kontakt.put("F_APS_TEYIT", false);
					if (apsAdresTeyit)
						kontakt.put("F_APS_TEYIT", true);

					if (kontakt.getBoolean("F_SAHTE")) {
						kontakt.remove("F_SAHTE");
						kontakt.put("F_SAHTE", "1");
					}
					else {
						kontakt.remove("F_SAHTE");
						kontakt.put("F_SAHTE", "0");
					}
					if (kontakt.getBoolean("F_MUSTERIYE_CEVRILEBILIR")) {
						kontakt.remove("F_MUSTERIYE_CEVRILEBILIR");
						kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "1");
					}
					else {
						kontakt.remove("F_MUSTERIYE_CEVRILEBILIR");
						kontakt.put("F_MUSTERIYE_CEVRILEBILIR", "0");
					}

					kontakt.put("TRX_NO", trxNo);
					if ("E".equals(birBasvuru.getKpsYapildi())) {
						kontakt.put("TCKNO_IN", kimlik.getTcKimlikNo());
						kontakt.put("TCKNO_OUT", kimlik.getTcKimlikNo());
						kontakt.put("ISIM", kimlik.getAd());
						kontakt.put("IKINCI_ISIM", kimlik.getIkinciAd());
						kontakt.put("SOYADI", kimlik.getSoyad());
						kontakt.put("BABA_ADI", kimlik.getBabaAd());
						kontakt.put("ANNE_ADI", kimlik.getAnneAdi());
						kontakt.put("DOGUM_YERI", kimlik.getDogumYeri());
						kontakt.put("DOGUM_TARIHI", kimlik.getDogumTar());
						kontakt.put("UYRUK_KOD", kimlik.getUyruk());
						kontakt.put("CINSIYET_KOD", kimlik.getCinsiyet());
						kontakt.put("MEDENI_HAL_KOD", kimlik.getMedeniHal());
						kontakt.put("AILE_SIRA_NO", kimlik.getAileSiraNo());
						kontakt.put("CILT_NO", kimlik.getCiltNo());
						kontakt.put("SIRA_NO", kimlik.getBireySiraNo());
						kontakt.put("VERILDIGI_YER", kimlik.getNufusVerYer());
						kontakt.put("VERILDIGI_TARIH", kimlik.getNufusVerTar());
						kontakt.put("NUF_VERILIS_NEDENI", kimlik.getNufusVerNedeni());
						kontakt.put("MAHALLE_KOY", kimlik.getMahalleKoy());
						kontakt.put("IL_KOD", kimlik.getNufusIlKod());
						kontakt.put("ILCE_KOD", kimlik.getNufusIlceKod());
						kontakt.put("KISA_AD", kimlik.getAd() + " " + (kimlik.getIkinciAd() == null ? "" : kimlik.getIkinciAd() + " ") + kimlik.getSoyad());

						if (kontakt.getString("NUFUS_CUZDANI_SERI_NO") != null && !kontakt.getString("NUFUS_CUZDANI_SERI_NO").isEmpty())
							kontakt.put("F_NUF", "E");
					}

					if (kontakt.getString("KISA_AD") == null || kontakt.getString("KISA_AD").isEmpty())
						kontakt.put("KISA_AD", kimlik.getAd() + " " + (kimlik.getIkinciAd() == null ? "" : kimlik.getIkinciAd() + " ") + kimlik.getSoyad());

					kontakt.put("MESLEK_KOD", kimlik.getMeslekKod());
					kontakt.put("CALISMA_SEKLI", kimlik.getCalismaSekliKod());
					kontakt.put("UNVAN_KOD", kimlik.getUnvanKod());
					kontakt.put("F_ISTEGE_BAGLI_SIGORTALI", kimlik.getSigortaliMi());
					if ("00010".equals(iMap.getString(tableName, i, "EPOSTA"))) {
						kontakt.put("EMAIL_KISISEL", kimlik.getEMail());
					}
					if ("00010".equals(iMap.getString(tableName, i, "ANNE_KIZLIK"))) {
						kontakt.put("ANNE_KIZLIK_SOYADI", kimlik.getAnneKizlik());
					}

					ArrayList<HashMap<String, Object>> telefonList = new ArrayList<HashMap<String, Object>>();

					telefonList = (ArrayList<HashMap<String, Object>>) kontakt.get("TELEFON_LIST");
					if (telefonList != null && "00010".equals(iMap.getString(tableName, i, "CEP_TEL"))) {
						for (int row = 0; row < telefonList.size(); row++) {
							kontakt.put("TELEFON_LIST", row, "F_ILETISIM", "0");
						}
					}
					if ("00010".equals(iMap.getString(tableName, i, "IS_TEL"))) {
						boolean add = true;
						int row = 0;
						if (telefonList != null) {
							for (int j = 0; j < telefonList.size(); j++) {

								// dont add same tel
								if ("2".equals(kontakt.getString("TELEFON_LIST", j, "TEL_TIP")) && "90".equals(kontakt.getString("TELEFON_LIST", j, "ULKE_KODU")) && ((kimlik.getIsTelAlanKod() == null && kontakt.getString("TELEFON_LIST", j, "ALAN_KOD") == null) || (kimlik.getIsTelAlanKod() != null && kontakt.getString("TELEFON_LIST", j, "ALAN_KOD") != null && kimlik.getIsTelAlanKod().equals(kontakt.getString("TELEFON_LIST", j, "ALAN_KOD")))) && ((kimlik.getIsTelNo() == null && kontakt.getString("TELEFON_LIST", j, "TEL_NO") == null) || (kimlik.getIsTelNo() != null && kontakt.getString("TELEFON_LIST", j, "TEL_NO") != null && kimlik.getIsTelNo().equals(kontakt.getString("TELEFON_LIST", j, "TEL_NO")))) && ((kimlik.getIsTelDahili() == null && kontakt.getString("TELEFON_LIST", j, "DAH_NO") == null) || (kimlik.getIsTelDahili() != null && kontakt.getString("TELEFON_LIST", j, "DAH_NO") != null && kimlik.getIsTelDahili().equals(kontakt.getString("TELEFON_LIST", j, "DAH_NO"))))) {

									add = false;
									break;

								}
							}
							row = telefonList.size();
						}
						if (add) {
							kontakt.put("TELEFON_LIST", row, "TEL_TIP", "2");
							kontakt.put("TELEFON_LIST", row, "ALAN_KOD", kimlik.getIsTelAlanKod());
							kontakt.put("TELEFON_LIST", row, "TEL_NO", kimlik.getIsTelNo());
							kontakt.put("TELEFON_LIST", row, "DAH_NO", kimlik.getIsTelDahili());
							kontakt.put("TELEFON_LIST", row, "ULKE_KODU", "90");
						}

					}

					telefonList = (ArrayList<HashMap<String, Object>>) kontakt.get("TELEFON_LIST");
					if ("00010".equals(iMap.getString(tableName, i, "EV_TEL"))) {
						boolean add = true;
						int row = 0;
						if (telefonList != null) {
							for (int j = 0; j < telefonList.size(); j++) {

								// dont add same tel
								if ("1".equals(kontakt.getString("TELEFON_LIST", j, "TEL_TIP")) && "90".equals(kontakt.getString("TELEFON_LIST", j, "ULKE_KODU")) && ((kimlik.getEvTelAlanKod() == null && kontakt.getString("TELEFON_LIST", j, "ALAN_KOD") == null) || (kimlik.getEvTelAlanKod() != null && kontakt.getString("TELEFON_LIST", j, "ALAN_KOD") != null && kimlik.getEvTelAlanKod().equals(kontakt.getString("TELEFON_LIST", j, "ALAN_KOD")))) && ((kimlik.getEvTelNo() == null && kontakt.getString("TELEFON_LIST", j, "TEL_NO") == null) || (kimlik.getEvTelNo() != null && kontakt.getString("TELEFON_LIST", j, "TEL_NO") != null && kimlik.getEvTelNo().equals(kontakt.getString("TELEFON_LIST", j, "TEL_NO"))))) {

									add = false;
									break;

								}
							}
							row = telefonList.size();
						}
						if (add) {
							kontakt.put("TELEFON_LIST", row, "TEL_TIP", "1");
							kontakt.put("TELEFON_LIST", row, "ALAN_KOD", kimlik.getEvTelAlanKod());
							kontakt.put("TELEFON_LIST", row, "TEL_NO", kimlik.getEvTelNo());
							kontakt.put("TELEFON_LIST", row, "ULKE_KODU", "90");
						}
					}

					telefonList = (ArrayList<HashMap<String, Object>>) kontakt.get("TELEFON_LIST");
					if ("00010".equals(iMap.getString(tableName, i, "CEP_TEL"))) {
						boolean add = true;
						int row = 0;
						if (telefonList != null) {
							for (int j = 0; j < telefonList.size(); j++) {

								// dont add same tel
								if ("3".equals(kontakt.getString("TELEFON_LIST", j, "TEL_TIP")) && "90".equals(kontakt.getString("TELEFON_LIST", j, "ULKE_KODU")) && ((kimlik.getCepTelAlanKod() == null && kontakt.getString("TELEFON_LIST", j, "ALAN_KOD") == null) || (kimlik.getCepTelAlanKod() != null && kontakt.getString("TELEFON_LIST", j, "ALAN_KOD") != null && kimlik.getCepTelAlanKod().equals(kontakt.getString("TELEFON_LIST", j, "ALAN_KOD")))) && ((kimlik.getCepTelNo() == null && kontakt.getString("TELEFON_LIST", j, "TEL_NO") == null) || (kimlik.getCepTelNo() != null && kontakt.getString("TELEFON_LIST", j, "TEL_NO") != null && kimlik.getCepTelNo().equals(kontakt.getString("TELEFON_LIST", j, "TEL_NO"))))) {

									kontakt.put("TELEFON_LIST", j, "F_ILETISIM", "1");
									add = false;
									break;

								}
							}
							row = telefonList.size();
						}
						if (add) {
							kontakt.put("TELEFON_LIST", row, "TEL_TIP", "3");
							kontakt.put("TELEFON_LIST", row, "ALAN_KOD", kimlik.getCepTelAlanKod());
							kontakt.put("TELEFON_LIST", row, "TEL_NO", kimlik.getCepTelNo());
							kontakt.put("TELEFON_LIST", row, "ULKE_KODU", "90");
							kontakt.put("TELEFON_LIST", row, "F_ILETISIM", "1");
						}
					}

					ArrayList<HashMap<String, Object>> adresList = new ArrayList<HashMap<String, Object>>();

					adresList = (ArrayList<HashMap<String, Object>>) kontakt.get("ADRES_LIST");
					boolean yeniYazismaAdresi = ("00010".equals(iMap.getString(tableName, i, "IS_ADRES")) && "I".equals(kimlik.getYazismaAdresKod())) || ("00010".equals(iMap.getString(tableName, i, "EV_ADRES")) && "E".equals(kimlik.getYazismaAdresKod()));
					if ("00010".equals(iMap.getString(tableName, i, "IS_ADRES"))) {
						int row = 0;
						boolean makeYazismaAdresi = false;
						if (adresList != null) {
							for (row = 0; row < adresList.size(); row++) {
								HashMap<String, Object> adressMap = adresList.get(row);
								String adresKod = (String) adressMap.get("ADRES_KOD");
								if (adresKod.startsWith("I")) {
									if (adresKod.length() == 1) {
										kontakt.put("ADRES_LIST", row, "ADRES_KOD", "I1");
										if (!yeniYazismaAdresi && "1".equals(kontakt.getString("ADRES_LIST", row, "EXTRE_ADRES_KOD_F"))) {
											makeYazismaAdresi = true;
										}
									}
									else {
										int newAdresKod = Integer.parseInt(adresKod.substring(1));
										kontakt.put("ADRES_LIST", row, "ADRES_KOD", "I" + (newAdresKod + 1));
									}
									kontakt.put("ADRES_LIST", row, "EXTRE_ADRES_KOD_F", "0");
									if (adresTeyit) {
										kontakt.put("ADRES_LIST", row, "ADRES_TEYIT", false);
									}
								}
							}
							row = adresList.size();
						}

						kontakt.put("ADRES_LIST", row, "ADRES_KOD", "I");
						kontakt.put("ADRES_LIST", row, "ISYERI_UNVANI", kimlik.getIsyeriAdi());
						kontakt.put("ADRES_LIST", row, "ADRES", kimlik.getIsAdres());
						kontakt.put("ADRES_LIST", row, "ADRES_IL_KOD", kimlik.getIsAdresIlKod());
						kontakt.put("ADRES_LIST", row, "ADRES_ILCE_KOD", kimlik.getIsAdresIlceKod());
						kontakt.put("ADRES_LIST", row, "ULKE_KOD", "TR");
						kontakt.put("ADRES_LIST", row, "POSTA_KOD", kimlik.getIsPostaKod());
						kontakt.put("ADRES_LIST", row, "ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
						if ("I".equals(kimlik.getYazismaAdresKod()) || makeYazismaAdresi) {
							kontakt.put("ADRES_LIST", row, "EXTRE_ADRES_KOD_F", "1");
						}
						else {
							kontakt.put("ADRES_LIST", row, "EXTRE_ADRES_KOD_F", "0");
						}
						kontakt.put("ADRES_LIST", row, "ADRES_TEYIT", false);
					}

					adresList = (ArrayList<HashMap<String, Object>>) kontakt.get("ADRES_LIST");
					if ("00010".equals(iMap.getString(tableName, i, "EV_ADRES"))) {
						int row = 0;
						boolean makeYazismaAdresi = false;
						if (adresList != null) {
							for (row = 0; row < adresList.size(); row++) {
								HashMap<String, Object> adressMap = adresList.get(row);
								String adresKod = (String) adressMap.get("ADRES_KOD");
								if (adresKod.startsWith("E")) {
									if (adresKod.length() == 1) {
										kontakt.put("ADRES_LIST", row, "ADRES_KOD", "E1");
										if (!yeniYazismaAdresi && "1".equals(kontakt.getString("ADRES_LIST", row, "EXTRE_ADRES_KOD_F"))) {
											makeYazismaAdresi = true;
										}
									}
									else {
										int newAdresKod = Integer.parseInt(adresKod.substring(1));
										kontakt.put("ADRES_LIST", row, "ADRES_KOD", "E" + (newAdresKod + 1));
									}
									kontakt.put("ADRES_LIST", row, "EXTRE_ADRES_KOD_F", "0");
									if (adresTeyit) {
										kontakt.put("ADRES_LIST", row, "ADRES_TEYIT", false);
									}
								}
							}
							row = adresList.size();
						}
						kontakt.put("ADRES_LIST", row, "ADRES_KOD", "E");
						kontakt.put("ADRES_LIST", row, "ADRES", kimlik.getEvAdres());
						kontakt.put("ADRES_LIST", row, "ADRES_IL_KOD", kimlik.getEvAdresIlKod());
						kontakt.put("ADRES_LIST", row, "ADRES_ILCE_KOD", kimlik.getEvAdresIlceKod());
						kontakt.put("ADRES_LIST", row, "ULKE_KOD", "TR");
						kontakt.put("ADRES_LIST", row, "POSTA_KOD", kimlik.getEvPostaKod());
						kontakt.put("ADRES_LIST", row, "ILK_GECERLILIK_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
						if ("E".equals(kimlik.getYazismaAdresKod()) || makeYazismaAdresi) {
							kontakt.put("ADRES_LIST", row, "EXTRE_ADRES_KOD_F", "1");
						}
						else {
							kontakt.put("ADRES_LIST", row, "EXTRE_ADRES_KOD_F", "0");
						}
						kontakt.put("ADRES_LIST", row, "ADRES_TEYIT", adresTeyit);
					}

					// remove same addresses
					adresList = (ArrayList<HashMap<String, Object>>) kontakt.get("ADRES_LIST");
					boolean extreKodE = false;
					boolean extreKodI = false;
					ArrayList<Integer> deletedE = new ArrayList<Integer>();
					ArrayList<Integer> deletedI = new ArrayList<Integer>();
					for (int j = 0; j < adresList.size(); j++) {
						HashMap<String, Object> adressMap = adresList.get(j);
						String adresKod = (String) adressMap.get("ADRES_KOD");
						if (adresKod.startsWith("E")) {
							if (adresKod.length() > 1) {
								if ("TR".equals(kontakt.getString("ADRES_LIST", j, "ULKE_KOD")) && ((kimlik.getEvAdres() == null && kontakt.getString("ADRES_LIST", j, "ADRES") == null) || (kimlik.getEvAdres() != null && kontakt.getString("ADRES_LIST", j, "ADRES") != null && kimlik.getEvAdres().trim().equals(kontakt.getString("ADRES_LIST", j, "ADRES").trim()))) && ((kimlik.getEvAdresIlKod() == null && kontakt.getString("ADRES_LIST", j, "ADRES_IL_KOD") == null) || (kimlik.getEvAdresIlKod() != null && kontakt.getString("ADRES_LIST", j, "ADRES_IL_KOD") != null && kimlik.getEvAdresIlKod().trim().equals(kontakt.getString("ADRES_LIST", j, "ADRES_IL_KOD").trim()))) && ((kimlik.getEvAdresIlceKod() == null && kontakt.getString("ADRES_LIST", j, "ADRES_ILCE_KOD") == null) || (kimlik.getEvAdresIlceKod() != null && kontakt.getString("ADRES_LIST", j, "ADRES_ILCE_KOD") != null && kimlik.getEvAdresIlceKod().trim().equals(kontakt.getString("ADRES_LIST", j, "ADRES_ILCE_KOD").trim()))) && ((kimlik.getEvPostaKod() == null && kontakt.getString("ADRES_LIST", j, "POSTA_KOD") == null) || (kimlik.getEvPostaKod() != null && kontakt.getString("ADRES_LIST", j, "POSTA_KOD") != null && kimlik.getEvPostaKod().trim().equals(kontakt.getString("ADRES_LIST", j, "POSTA_KOD").trim())))) {

									if ("1".equals(kontakt.getString("ADRES_LIST", j, "EXTRE_ADRES_KOD_F"))) {
										extreKodE = true;
									}
									adresList.remove(j);
									j--;
									deletedE.add(Integer.parseInt(adresKod.substring(1)));
								}
							}
						}
						else if (adresKod.startsWith("I")) {
							if (adresKod.length() > 1) {
								if ("TR".equals(kontakt.getString("ADRES_LIST", j, "ULKE_KOD")) && ((kimlik.getIsyeriAdi() == null && kontakt.getString("ADRES_LIST", j, "ISYERI_UNVANI") == null) || (kimlik.getIsyeriAdi() != null && kontakt.getString("ADRES_LIST", j, "ISYERI_UNVANI") != null && kimlik.getIsyeriAdi().trim().equals(kontakt.getString("ADRES_LIST", j, "ISYERI_UNVANI").trim()))) && ((kimlik.getIsAdres() == null && kontakt.getString("ADRES_LIST", j, "ADRES") == null) || (kimlik.getIsAdres() != null && kontakt.getString("ADRES_LIST", j, "ADRES") != null && kimlik.getIsAdres().trim().equals(kontakt.getString("ADRES_LIST", j, "ADRES").trim()))) && ((kimlik.getIsAdresIlKod() == null && kontakt.getString("ADRES_LIST", j, "ADRES_IL_KOD") == null) || (kimlik.getIsAdresIlKod() != null && kontakt.getString("ADRES_LIST", j, "ADRES_IL_KOD") != null && kimlik.getIsAdresIlKod().trim().equals(kontakt.getString("ADRES_LIST", j, "ADRES_IL_KOD").trim()))) && ((kimlik.getIsAdresIlceKod() == null && kontakt.getString("ADRES_LIST", j, "ADRES_ILCE_KOD") == null) || (kimlik.getIsAdresIlceKod() != null && kontakt.getString("ADRES_LIST", j, "ADRES_ILCE_KOD") != null && kimlik.getIsAdresIlceKod().trim().equals(kontakt.getString("ADRES_LIST", j, "ADRES_ILCE_KOD").trim()))) && ((kimlik.getIsPostaKod() == null && kontakt.getString("ADRES_LIST", j, "POSTA_KOD") == null) || (kimlik.getIsPostaKod() != null && kontakt.getString("ADRES_LIST", j, "POSTA_KOD") != null && kimlik.getIsPostaKod().trim().equals(kontakt.getString("ADRES_LIST", j, "POSTA_KOD").trim())))) {

									if ("1".equals(kontakt.getString("ADRES_LIST", j, "EXTRE_ADRES_KOD_F"))) {
										extreKodI = true;
									}
									adresList.remove(j);
									j--;
									deletedI.add(Integer.parseInt(adresKod.substring(1)));
								}
							}
						}
					}
					for (int j = 0; j < adresList.size(); j++) {
						HashMap<String, Object> adressMap = adresList.get(j);
						String adresKod = (String) adressMap.get("ADRES_KOD");
						if (adresKod.startsWith("E")) {
							if (adresKod.length() == 1) {
								if (extreKodE) {
									kontakt.put("ADRES_LIST", j, "EXTRE_ADRES_KOD_F", "1");
								}
							}
							else {
								int count = 0;
								int order = Integer.parseInt(adresKod.substring(1));
								for (int k = 0; k < deletedE.size(); k++) {
									if (deletedE.get(k) < order) {
										count++;
									}
								}
								kontakt.put("ADRES_LIST", j, "ADRES_KOD", "E" + (order - count));
							}
						}
						else if (adresKod.startsWith("I")) {
							if (adresKod.length() == 1) {
								if (extreKodI) {
									kontakt.put("ADRES_LIST", j, "EXTRE_ADRES_KOD_F", "1");
								}
							}
							else {
								int count = 0;
								int order = Integer.parseInt(adresKod.substring(1));
								for (int k = 0; k < deletedI.size(); k++) {
									if (deletedI.get(k) < order) {
										count++;
									}
								}
								kontakt.put("ADRES_LIST", j, "ADRES_KOD", "I" + (order - count));
							}
						}
					}

					// �ifte vatanda�l�k : R ("Hay�r")
					// Green Card : R("De�ilim")

					if (iMap.getString("F_CIFTE_VATANDAS") == null) {
						kontakt.put("F_CIFTE_VATANDAS", "R");
					}
					if (iMap.getString("F_GREEN_CARD") == null) {
						kontakt.put("F_GREEN_CARD", "R");
					}

					// Musteri tanimlama + guncelleme islemlerinin onaysiz gerceklesmesi
					kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
					kontakt.put("DONT_SEND_TRANSACTION", "E");
					GMServiceExecuter.execute("BNSPR_TRN10041_SAVE", kontakt);
					BirBasvuruMustGuncelleTx birBasvuruMustGuncelleTx = (BirBasvuruMustGuncelleTx) session.createCriteria(BirBasvuruMustGuncelleTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.musteriTxNo", trxNo)).add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal(tableName, i, "MUSTERI_NO"))).uniqueResult();
					if (birBasvuruMustGuncelleTx == null) {
						birBasvuruMustGuncelleTx = new BirBasvuruMustGuncelleTx(new BirBasvuruMustGuncelleTxId(iMap.getBigDecimal("TRX_NO"), trxNo, iMap.getBigDecimal(tableName, i, "MUSTERI_NO")));
					}
					session.saveOrUpdate(birBasvuruMustGuncelleTx);

					session.flush();

				}

			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3182_GET_BELGE_LIST_FOR_HOBIM")
	public static GMMap getBelgeListForHobim(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("barkodNumarasi", iMap.getString("BARKOD_NO")))// burasi sonradan eklendi
			.addOrder(Order.desc("id.kimden")).list();

			// iMap.put("TARIH", iMap.getDate("SOZLESME_TARIHI"));
			// iMap.put("GUN", iMap.getBigDecimal("ORJ_EVRAK_GONDERIM_SURESI") == null ? BigDecimal.ZERO : iMap.getBigDecimal("ORJ_EVRAK_GONDERIM_SURESI"));
			// iMap.put("BELGE_TAMAMLAMA_TARIHI", GMServiceExecuter.execute("BNSPR_COMMON_SONRAKI_GUN", iMap).get("TARIH"));

			GMMap oMap = new GMMap();
			String tableName = "BELGELER";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) iterator.next();

				oMap.put(tableName, row, "BELGE_KOD", birBasvuruBelge.getId().getDokumanKod());
				// oMap.put(tableName, row, "KIMDEN",LovHelper.diLov(birBasvuruBelge.getId().getKimden(),"3181/LOV_BASVURU_KISI","ACIKLAMA"));
				oMap.put(tableName, row, "KIMDEN_KOD", birBasvuruBelge.getId().getKimden());
				// oMap.put(tableName, row, "BELGE_ADI",LovHelper.diLov(birBasvuruBelge.getId().getDokumanKod(), "3182/LOV_BELGE_KOD", "ACIKLAMA"));
				oMap.put(tableName, row, "DOSYA_ADI", birBasvuruBelge.getBelgeAdi());
				oMap.put(tableName, row, "DOSYA_YOL", birBasvuruBelge.getBelgeYeri());

				oMap.put(tableName, row, "BELGE_KONTROL", birBasvuruBelge.getBelgeKontrol() == null ? "" : birBasvuruBelge.getBelgeKontrol());
				oMap.put(tableName, row, "BELGE_HATA", birBasvuruBelge.getBelgeHata() == null ? "" : birBasvuruBelge.getBelgeHata());
				oMap.put(tableName, row, "GELIS_TARIHI", birBasvuruBelge.getBelgeGelisTarihi());
				oMap.put(tableName, row, "ORJINAL_EVRAK_MI", GuimlUtil.convertToCheckBoxValue(birBasvuruBelge.getOrjinalEvrakMi()));
				oMap.put(tableName, row, "KAYIT", "ESKI");
				// oMap.put(tableName, row, "BELGE_TAMAMLAMA_TARIHI",iMap.getDate("BELGE_TAMAMLAMA_TARIHI"));
				oMap.put(tableName, row, "KONTROL_NEDENI", birBasvuruBelge.getKontrolNedeni());
				oMap.put(tableName, row, "BARKOD_NUMARASI", birBasvuruBelge.getBarkodNumarasi());
				oMap.put(tableName, row, "ONAYLI_MI", birBasvuruBelge.getOnayliMi());
				oMap.put(tableName, row, "UYUMSUZ_ACIKLAMA", birBasvuruBelge.getUyumsuzAciklama());
				oMap.put(tableName, row, "BELGE_ALINMA_ADIMI", birBasvuruBelge.getBelgeAlinmaAdim());

				row++;
			}

			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			oMap.put("SON_TX_NO", birBasvuru.getSonTxNo());
			oMap.put("DURUM_KODU", birBasvuru.getDurumKodu());
			oMap.put("CALISMA_TIPI", birBasvuru.getCalismaSekliKod());
			oMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3182_SAVE_FOR_HOBIM")
	public static Map<?, ?> saveForHobim(GMMap iMap) {
		try {
			if ("CEPTE".equals(iMap.getString("DURUM_KODU"))) {
				GMMap oMap = new GMMap();
				oMap.put("TX_STATUS", "0");
				return oMap;
			}
			Session session = DAOSession.getSession("BNSPRDal");

			int belgeCount = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.or(Restrictions.eq("belgeAlinmaAdim", "S"), Restrictions.isNull("belgeAlinmaAdim"))).addOrder(Order.desc("id.kimden")).list().size();

			String tableName = "BELGELER";

			// connectionlarim farkli oldugu icin ve global e herhangibi birsey setlemedigim icin trx_no yu burda olusturuyorum
			BigDecimal trxNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).get("TRX_NO").toString());

			BirBasvuruBelgeKontrolTx birBasvuruBelgeKontrolTx = (BirBasvuruBelgeKontrolTx) session.createCriteria(BirBasvuruBelgeKontrolTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			BirBasvuruBelgeKontrolTxId id = new BirBasvuruBelgeKontrolTxId();
			if (birBasvuruBelgeKontrolTx == null) {
				birBasvuruBelgeKontrolTx = new BirBasvuruBelgeKontrolTx();
			}
			id.setTxNo(trxNo);
			id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBasvuruBelgeKontrolTx.setId(id);
			birBasvuruBelgeKontrolTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
			birBasvuruBelgeKontrolTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			birBasvuruBelgeKontrolTx.setMusteriEslestirme("H");
			birBasvuruBelgeKontrolTx.setOtomatikKullandirim("H");
			// birBasvuruBelgeKontrolTx.setIslemSonrasiDurumKodu(iMap.getString("DURUM_KODU"));

			session.save(birBasvuruBelgeKontrolTx);

			int belgeKontrol = 0;
			int sahteBelge = 0;

			ArrayList<String> dokumanKodList = new ArrayList<String>();

			if (iMap.getSize(tableName) == 0) {
				throw new GMRuntimeException(0, "Bu barkod numaras� art�k ge�ersizdir!");
			}

			for (int i = 0; i < iMap.getSize(tableName); i++) {

				BirBasvuruBelgeTxId birBasvuruBelgeTxId = new BirBasvuruBelgeTxId();
				birBasvuruBelgeTxId.setTxNo(trxNo);
				birBasvuruBelgeTxId.setDokumanKod(iMap.getString(tableName, i, "BELGE_KOD"));
				dokumanKodList.add(iMap.getString(tableName, i, "BELGE_KOD"));

				birBasvuruBelgeTxId.setKimden(iMap.getString(tableName, i, "KIMDEN_KOD"));
				birBasvuruBelgeTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));

				BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.get(BirBasvuruBelgeTx.class, birBasvuruBelgeTxId);

				if (birBasvuruBelgeTx == null) {
					birBasvuruBelgeTx = new BirBasvuruBelgeTx();
					birBasvuruBelgeTx.setId(birBasvuruBelgeTxId);
				}

				birBasvuruBelgeTx.setBelgeAdi(iMap.getString(tableName, i, "DOSYA_ADI"));

				if (iMap.get(tableName, i, "GELIS_TARIHI") == null)
					birBasvuruBelgeTx.setBelgeGelisTarihi(null);
				else if (iMap.get(tableName, i, "GELIS_TARIHI").equals(""))
					birBasvuruBelgeTx.setBelgeGelisTarihi(null);
				else
					birBasvuruBelgeTx.setBelgeGelisTarihi(iMap.getDate(tableName, i, "GELIS_TARIHI"));

				birBasvuruBelgeTx.setBelgeKontrol(iMap.getString(tableName, i, "BELGE_KONTROL"));
				birBasvuruBelgeTx.setBelgeHata(iMap.getString(tableName, i, "BELGE_HATA"));
				birBasvuruBelgeTx.setOrjinalEvrakMi(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, i, "ORJINAL_EVRAK_MI")));
				birBasvuruBelgeTx.setOnayliMi(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName, i, "ONAYLI_MI")));
				birBasvuruBelgeTx.setBelgeYeri(iMap.getString(tableName, i, "DOSYA_YOL"));
				birBasvuruBelgeTx.setKontrolNedeni(iMap.getString(tableName, i, "KONTROL_NEDENI"));
				birBasvuruBelgeTx.setUyumsuzAciklama(iMap.getString(tableName, i, "UYUMSUZ_ACIKLAMA"));

				if (("1".equals(iMap.getString("CALISMA_TIPI")) && birBasvuruBelgeTx.getBelgeKontrol().equals("1") && "E".equals(birBasvuruBelgeTx.getOrjinalEvrakMi())) || ("3".equals(iMap.getString("CALISMA_TIPI")) && iMap.getString("DURUM_KODU").equals("BELGE") && (birBasvuruBelgeTx.getBelgeKontrol().equals("1"))) || ("3".equals(iMap.getString("CALISMA_TIPI")) && iMap.getString("DURUM_KODU").equals("EVRAKSIZ") && (birBasvuruBelgeTx.getBelgeKontrol().equals("1")) && "E".equals(birBasvuruBelgeTx.getOrjinalEvrakMi())) || ("2".equals(iMap.getString("CALISMA_TIPI")) && iMap.getString("DURUM_KODU").equals("EVRAKSIZ") && (birBasvuruBelgeTx.getBelgeKontrol().equals("1")) && "E".equals(birBasvuruBelgeTx.getOrjinalEvrakMi())))
					belgeKontrol++;
				if (birBasvuruBelgeTx.getBelgeKontrol().equals("4"))
					sahteBelge++;

				if (iMap.getString("BARKOD_NUMARASI") != null) {
					birBasvuruBelgeTx.setBarkodNumarasi(iMap.getString("BARKOD_NUMARASI"));
					birBasvuruBelgeTx.setIslemTarihi(iMap.getDate(tableName, i, "ISLEM_TARIHI"));
				}
				else {
					birBasvuruBelgeTx.setBarkodNumarasi(iMap.getString(tableName, i, "BARKOD_NUMARASI"));

				}
				birBasvuruBelgeTx.setBelgeAlinmaAdim(iMap.getString(tableName, i, "BELGE_ALINMA_ADIMI"));
				session.save(birBasvuruBelgeTx);
			}

			// //BP-699
			List<?> list = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.or(Restrictions.eq("belgeAlinmaAdim", "S"), Restrictions.isNull("belgeAlinmaAdim"))).addOrder(Order.desc("id.kimden")).list();

			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) iterator.next();

				if (!dokumanKodList.contains(birBasvuruBelge.getId().getDokumanKod())) {
					BirBasvuruBelgeTxId birBasvuruBelgeTxId = new BirBasvuruBelgeTxId();
					birBasvuruBelgeTxId.setTxNo(trxNo);
					birBasvuruBelgeTxId.setDokumanKod(birBasvuruBelge.getId().getDokumanKod());
					birBasvuruBelgeTxId.setKimden(birBasvuruBelge.getId().getKimden());
					birBasvuruBelgeTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));

					BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.get(BirBasvuruBelgeTx.class, birBasvuruBelgeTxId);

					if (birBasvuruBelgeTx == null) {
						birBasvuruBelgeTx = new BirBasvuruBelgeTx();
						birBasvuruBelgeTx.setId(birBasvuruBelgeTxId);
					}

					birBasvuruBelgeTx.setBelgeAdi(birBasvuruBelge.getBelgeAdi());
					birBasvuruBelgeTx.setBelgeGelisTarihi(birBasvuruBelge.getBelgeGelisTarihi());
					birBasvuruBelgeTx.setBelgeKontrol(birBasvuruBelge.getBelgeKontrol());
					birBasvuruBelgeTx.setBelgeHata(birBasvuruBelge.getBelgeHata());
					birBasvuruBelgeTx.setOrjinalEvrakMi(birBasvuruBelge.getOrjinalEvrakMi());
					birBasvuruBelgeTx.setOnayliMi(birBasvuruBelge.getOnayliMi());
					birBasvuruBelgeTx.setBelgeYeri(birBasvuruBelge.getBelgeYeri());
					birBasvuruBelgeTx.setKontrolNedeni(birBasvuruBelge.getKontrolNedeni());
					birBasvuruBelgeTx.setUyumsuzAciklama(birBasvuruBelge.getUyumsuzAciklama());

					if (("1".equals(iMap.getString("CALISMA_TIPI")) && birBasvuruBelgeTx.getBelgeKontrol().equals("1") && "E".equals(birBasvuruBelgeTx.getOrjinalEvrakMi())) || ("3".equals(iMap.getString("CALISMA_TIPI")) && iMap.getString("DURUM_KODU").equals("BELGE") && (birBasvuruBelgeTx.getBelgeKontrol().equals("1"))) || ("3".equals(iMap.getString("CALISMA_TIPI")) && iMap.getString("DURUM_KODU").equals("EVRAKSIZ") && (birBasvuruBelgeTx.getBelgeKontrol().equals("1")) && "E".equals(birBasvuruBelgeTx.getOrjinalEvrakMi())) || ("2".equals(iMap.getString("CALISMA_TIPI")) && iMap.getString("DURUM_KODU").equals("EVRAKSIZ") && (birBasvuruBelgeTx.getBelgeKontrol().equals("1")) && "E".equals(birBasvuruBelgeTx.getOrjinalEvrakMi())))
						belgeKontrol++;
					if (birBasvuruBelgeTx.getBelgeKontrol().equals("4"))
						sahteBelge++;

					birBasvuruBelgeTx.setBarkodNumarasi(birBasvuruBelge.getBarkodNumarasi());

					session.save(birBasvuruBelgeTx);
				}
			}
			// //

			if (sahteBelge > 0)
				birBasvuruBelgeKontrolTx.setIslemSonrasiDurumKodu("FRAUD");
			else if (belgeKontrol == belgeCount) {
				if (iMap.getString("DURUM_KODU").equals("EVRAKSIZ"))
					birBasvuruBelgeKontrolTx.setIslemSonrasiDurumKodu("CEPTE");
				else
					birBasvuruBelgeKontrolTx.setIslemSonrasiDurumKodu(iMap.getString("DURUM_KODU"));
			}
			else
				birBasvuruBelgeKontrolTx.setIslemSonrasiDurumKodu(iMap.getString("DURUM_KODU"));

			session.flush();

			iMap.put("TRX_NAME", "3182");
			iMap.put("TRX_NO", trxNo);
			// bu process i cagirdiginda procedurlerde ki kontrollere takilirmi emin degilim
			Map<?, ?> trnMap = GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

			return trnMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3182_MUST_ESLES_YAPILSIN_MI")
	public static GMMap musteriEslestirmeYapilsinMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3182.Musteri_Eslestirme_Yapilsin_Mi(?,?) }");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.execute();

			oMap.put("MUST_ESLESTIRME", stmt.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3182_MUST_ESLES_GUNCELLE")
	public static GMMap musteriEslestirmeGuncelle(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3182.Musteri_Eslestirme_Guncelle(?) }");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_NO"));
			stmt.execute();

			oMap.put("MESSAGE", stmt.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3182_GET_MUSTERI_IZLE_LIST")
	public static GMMap getMusteriIzleList(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<BirBasvuruMustGuncelleTx> birBasvuruMustGuncelleTxList = session.createCriteria(BirBasvuruMustGuncelleTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			if (birBasvuruMustGuncelleTxList != null) {
				for (int i = 0; i < birBasvuruMustGuncelleTxList.size(); i++) {
					BirBasvuruMustGuncelleTxId birBasvuruMustGuncelleTxId = birBasvuruMustGuncelleTxList.get(i).getId();
					oMap.put("MUSTERI_IZLE_LIST", i, "MUSTERI_NO", birBasvuruMustGuncelleTxId.getMusteriNo());
					oMap.put("MUSTERI_IZLE_LIST", i, "TRX_NO", birBasvuruMustGuncelleTxId.getMusteriTxNo());
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3182_GET_BASVURU_INFO")
	public static GMMap getBasvuruInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String func = "{? = call PKG_TRN3182.Get_Basvuru_Info(?,?)}";
			String iptalGoster = iMap.getString("IPTAL_GOSTER", Constants.HAYIR);
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.STRING, iptalGoster };
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues));
			int size = oMap.getSize("RESULTS");
			if (size > 0) {
				Set<?> keySet = oMap.getMap("RESULTS", 0).keySet();
				for (Object key : keySet) {
					String keyName = (String) key;
					Object keyValue = oMap.get("RESULTS", 0, keyName);
					if (keyName.equals("GARANTORLU_MU") && keyValue == null) {
						keyValue = "0";
					}
					if (keyName.equals("KREDI_TUR")) {
						keyValue = oMap.getString("RESULTS", 0, keyName);
					}
					oMap.put(keyName, keyValue);
				}
				BirSaticiTahsis birSaticiTahsis = (BirSaticiTahsis) session.createCriteria(BirSaticiTahsis.class).add(Restrictions.eq("kod", oMap.getBigDecimal("SATICI_KOD"))).uniqueResult();
				if (birSaticiTahsis != null) {
					oMap.put("DST_KAZANIM_KANAL", birSaticiTahsis.getDstKazanimKanal());
				}
				try {
					BirBasvuruTasit tasit = (BirBasvuruTasit) session.createCriteria(BirBasvuruTasit.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
					if ("3".equals(tasit.getAracTipi())) {
						oMap.put("KONSINYE_EH", "1");
					} else {
						oMap.put("KONSINYE_EH", "0");
					}
				}
				catch (Exception e) {
					oMap.put("KONSINYE_EH", "0");
				}
			}

			oMap.put("IZINLI_PAZARLAMA", "E".equals(oMap.getString("IZINLI_PAZARLAMA_EH")));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

		}
	}

	/**
	 * */
	@GraymoundService("BNSPR_TRN3003_KMH_OTOMATIK_KULLANDIR")
	public static GMMap KMHotomatikKullandirim(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			if (!iMap.containsKey("KANAL_KODU") || iMap.getString("KANAL_KODU") == null) {
				BirBasvuru b = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				iMap.put("KANAL_KODU", b.getKanalKodu());
			}

			/*if("7".equals(iMap.getString("KANAL_KODU"))){
			    conn = DALUtil.getGMConnection();
			    stmt = conn.prepareCall("{call PKG_TRN3003.PTT_KMH_islem_kayit_insert(?,?,?) }");
			    
			    int i = 1;
			    
			    BigDecimal trxNo=new BigDecimal(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).get("TRX_NO").toString());
			    stmt.setBigDecimal(i++ ,  trxNo );
			    stmt.setBigDecimal(i++ ,  iMap.getBigDecimal("BASVURU_NO"));
			    stmt.setBigDecimal(i++ ,  iMap.getBigDecimal("HESAP_NO"));
			    stmt.execute();
			    
			    iMap.put("TRX_NO" , trxNo);
			    iMap.put("TRX_NAME", "3003");
			
			    oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
			}else{*/
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3013_KULLANDIR", iMap));
			// }

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static GMMap belgelerOkIseOtomatikHesapAc(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			Object[] inputValues = new Object[2];

			String func = "{? = call PKG_TRN3182.SozlesmeBelgeleriHesapAcEH(?)}";
			int i = 0;
			inputValues = new Object[2];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");

			if ("E".equals(DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues))) {

				if ("K".equals(iMap.getString("MUSTERI_KONTAKT")))
					oMap.putAll(gercekMusteriDonustur(iMap));

				if (!iMap.containsKey("SUBE_KODU") || iMap.getString("SUBE_KODU") == null || "5".equals(iMap.getString("KREDI_TUR"))) {
					if (iMap.containsKey("SUBE_KODU"))
						iMap.remove("SUBE_KODU");
					String portfoyKod = GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_KOD", new GMMap().put("BASVURU_NO", iMap.getString("BASVURU_NO"))).getString("PORTFOY_KOD");
					iMap.put("SUBE_KODU", GMServiceExecuter.call("BNSPR_TRN3171_GET_PORTFOY_SUBE_KOD", new GMMap().put("PORTFOY_KOD", portfoyKod)).getString("PORTFOY_SUBE_KOD"));
				}

				/** TY-1686 Kanal koduna gore onceki basvuru hesap no kontrol et. **/
				iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3181_GET_ONCEKI_BASVURU_HESAPNO", iMap));

				if (iMap.getBigDecimal("HESAP_NO") == null || iMap.getBigDecimal("REZERV_HESAP_NO") != null)
					oMap.putAll(vadesizHesapAc(iMap));
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	// ***************************************************************************
	// -------------------------- BAYI BELGE YUKLEME/TRANSFER ISLEMLERI
	// ***************************************************************************
	/**
	 * Enradan alinan bayi dokumanlari gecici dizine kaydedilir.<br>
	 * 
	 * @author murat.el
	 * @since PY-10975, PY-11141
	 * @param iMap
	 *            - Basvuru bilgisi<br>
	 *            <li>BASVURU_NO - Kredi basvuru numarasi <li>DOKUMAN_KOD - Dokuman kodu <li>DOSYA_ICERIK - Dosya icerigi <li>KANAL - Belgenin yuklendigi yer(Default:3270 - Belge yukleme ekrani|BAYI)
	 * @return oMap - Sonuc bilgisi<br>
	 *         <li>ARSIV_FILE_PATH - Versiyonlanan dosyanin pathi
	 */
	@GraymoundService("BNSPR_TRN3182_GECICI_BELGE_YUKLE")
	public static GMMap belgeYukle(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		//
		String arsivFilePath = StringUtils.EMPTY;
		BigDecimal basvuruNo = iMap.getBigDecimal(Constants.BASVURU_NO);
		String dokumanKod = iMap.getString(Constants.DOKUMAN_KOD);
		String kanal = ConsumerLoanCommonServices.nvl(iMap.getString("KANAL"), "3270");

		try {
			// Belge yuklenebilir mi?
			if (!"3270".equals(kanal)) {
				sorguMap.clear();
				sorguMap.put(Constants.BASVURU_NO, basvuruNo);
				sorguMap.put(Constants.DOKUMAN_KOD, dokumanKod);
				sorguMap.putAll(belgeYuklenebilirMi(sorguMap));
				// Kontrol
				if (Constants.HAYIR.equals(sorguMap.getString("YUKLENEBILIR_MI"))) {
					ConsumerLoanCommonServices.raiseGMError("5138", dokumanKod);
				}
			}

			// Belgeyi belirlenen temp alana yaz.
			sorguMap.clear();
			sorguMap.put(Constants.BASVURU_NO, basvuruNo);
			sorguMap.put("DOKUMAN_KOD", dokumanKod);
			sorguMap.putAll(generateBayiDokumanTempPath(sorguMap));

			String basvuruPath = sorguMap.getString("BASVURU_PATH");
			File basvuruDirectory = new File(basvuruPath);
			Runtime runtime = Runtime.getRuntime();
			long start = System.currentTimeMillis();
			if (!basvuruDirectory.exists()) {
				if (SystemUtils.IS_OS_WINDOWS) {
					basvuruDirectory.mkdir();
				}
				else {
					String[] cmdLine = { "mkdir", basvuruPath };
					Process p = runtime.exec(cmdLine);
					p.waitFor();
				}
			}
			start = System.currentTimeMillis();

			String filePath = sorguMap.getString("FILE_PATH");
			// filePath = "C:\\mnt2\\1.pdf";
			if ("3270".equals(kanal)) {
				FileUtils.writeByteArrayToFile(new File(filePath), (byte[]) (iMap.get("DOSYA_ICERIK")));
			}
			else {
				FileUtils.writeByteArrayToFile(new File(filePath), Base64.decode(iMap.getString("DOSYA_ICERIK")));
			}

			// Belgeyi arsive ekle
			String arsivPath = sorguMap.getString("ARSIV_PATH");
			File arsivDirectory = new File(arsivPath);
			start = System.currentTimeMillis();
			if (!arsivDirectory.exists()) {
				if (SystemUtils.IS_OS_WINDOWS) {
					arsivDirectory.mkdir();
				}
				else {
					String[] cmdLine = { "mkdir", arsivPath };
					Process p = runtime.exec(cmdLine);
					p.waitFor();
				}
			}
			start = System.currentTimeMillis();

			arsivFilePath = sorguMap.getString("ARSIV_FILE_PATH");
			if ("3270".equals(kanal)) {
				FileUtils.writeByteArrayToFile(new File(arsivFilePath), (byte[]) (iMap.get("DOSYA_ICERIK")));
			}
			else {
				FileUtils.writeByteArrayToFile(new File(arsivFilePath), Base64.decode(iMap.getString("DOSYA_ICERIK")));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("ARSIV_FILE_PATH", arsivFilePath);
		return oMap;
	}

	/**
	 * Gecici dizindeki dosyalari uyugnluguna istinaden DYS musteri dizinine aktarir<br>
	 * 
	 * @author murat.el
	 * @since PY-10975
	 * @param iMap
	 *            - Basvuru bilgisi<br>
	 *            <li>BASVURU_NO - Kredi basvuru numarasi
	 * @return oMap - Sonuc bilgisi<br>
	 */
	@GraymoundService("BNSPR_TRN3182_GECICI_DOKUMAN_TRANSFER_ET")
	public static GMMap geciciDokumanTransfer(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		BigDecimal basvuruNo = iMap.getBigDecimal(Constants.BASVURU_NO);
		GMMap ftpMap = new GMMap();
		
		try {
			// SFTP ile
			// PY-11158, Basvuru kanali aktarim icin uygun mu? Bayi harici kontrol yapilmaz.
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, basvuruNo);
			if (birBasvuru == null) {
				ConsumerLoanCommonServices.raiseGMError("2999", basvuruNo);
			}
			else {
				if (!"2".equals(birBasvuru.getKanalKodu())) {
					return oMap;
				}
			}

			// Aktarilacak dosyalari al
			List<?> birBasvuruBelgeList = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", basvuruNo)).add(Restrictions.eq("alindi", Constants.EVET)).add(Restrictions.eq("belgeKontrol", "1"))// Sadece uygun olanlari DYSye at.
			.list();
			if (birBasvuruBelgeList == null || birBasvuruBelgeList.isEmpty()) {
				return oMap;
			}
			// Dosyalari isle
			BirBasvuruBelge birBasvuruBelge = null;
			String filePath = null;
			String basvuruPath = null;
			int i = 0;
			for (Object o : birBasvuruBelgeList) {
				birBasvuruBelge = (BirBasvuruBelge) o;
				/*
				//Elektronik olarak yuklenebilir mi?
				sorguMap.clear();
				sorguMap.put(Constants.BASVURU_NO, basvuruNo);
				sorguMap.put(Constants.DOKUMAN_KOD, birBasvuruBelge.getId().getDokumanKod());
				sorguMap.putAll(belgeYuklenebilirMi(sorguMap));
				//Kontrol
				if (Constants.HAYIR.equals(sorguMap.getString("YUKLENEBILIR_MI"))) {
					continue;
				}
				*/
				// Dosyanin bulundugu yeri al
				sorguMap.clear();
				sorguMap.put(Constants.BASVURU_NO, basvuruNo);
				sorguMap.put("DOKUMAN_KOD", birBasvuruBelge.getId().getDokumanKod());
				sorguMap.put("DOSYA_UZANTISI", iMap.get("DOSYA_UZANTISI"));
				sorguMap.putAll(generateBayiDokumanTempPath(sorguMap));
				filePath = sorguMap.getString("FILE_PATH");
				basvuruPath = sorguMap.getString("BASVURU_PATH");
				// dosya yoksa hata ver
				File file = new File(filePath);
				if (file == null || !file.exists()) {
					// PY-11143, Onayli ise belge olmasa da hata verilmez, bir sonraki belgeden devam edilir.
					if (Constants.EVET.equals(birBasvuruBelge.getOnayliMi())) {
						continue;
					}

					String fileName = birBasvuruBelge.getId().getDokumanKod();
					GnlBelgeKodPr gnlBelgeKodPr = (GnlBelgeKodPr) session.createCriteria(GnlBelgeKodPr.class).add(Restrictions.eq("id.kod", birBasvuruBelge.getId().getDokumanKod())).uniqueResult();
					if (gnlBelgeKodPr != null) {
						fileName = gnlBelgeKodPr.getId().getAciklama();
					}

					ConsumerLoanCommonServices.raiseGMError("5209", fileName);
				}

				ftpMap.put("FILE_LIST",i, "FILE_NAME", birBasvuruBelge.getId().getDokumanKod() + ".pdf");// TODO uzantisini ayarlamak gerekebilir.
				ftpMap.put("FILE_LIST",i, "FILE_FULL_PATH", filePath);
				i++;
			}
			
			/** 
			 * dokumanlari ftpye aktar
			 */
			ftpMap.put("PROJECT", "BAYI_PORTAL_DOMAIN");
			ftpMap.put("REFERENCE_NO", basvuruNo);
			ftpDosyaAktar(ftpMap);
			// Basvuru icin olusturulan gecici dizini sil
			// FileUtils.deleteDirectory(new File(basvuruPath));
		}
		catch (FtpClientException e) {
			throw new GMRuntimeException(0, e.getMessage());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * Dokuman elektronik olarak sisteme yuklenebilir mi<br>
	 * 
	 * @author murat.el
	 * @since PY-10975
	 * @param iMap
	 *            - Basvuru bilgisi<br>
	 *            <li>BASVURU_NO - Kredi basvuru numarasi <li>DOKUMAN_KOD - Dokuman kodu
	 * @return oMap - Sonuc bilgisi<br>
	 *         <li>YUKLENEBILIR_MI - Dosya yuklenebilir mi? (E:Evet|H:Hayir)
	 */
	@GraymoundService("BNSPR_TRN3182_BELGE_YUKLENEBILIR_MI")
	public static GMMap belgeYuklenebilirMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		String yuklenebilirMi = null;

		// initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			// Alanlarin degerlerini al
			conn = DALUtil.getGMConnection();

			query = "{? = call pkg_trn3182.belge_yuklenebilir_mi(?,?)}";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, iMap.getString("DOKUMAN_KOD"));
			stmt.execute();

			yuklenebilirMi = ConsumerLoanCommonServices.nvl(stmt.getString(1), Constants.HAYIR);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		oMap.put("YUKLENEBILIR_MI", yuklenebilirMi);
		return oMap;
	}

	/**
	 * Verilen dosyayi ftpdeki belirlenen dizine kopyalar.<br>
	 * 
	 * @author murat.el
	 * @since PY-10975
	 * @param iMap
	 *            - Basvuru bilgisi<br>
	 *            <li>PROJECT - Dys Ftp Domain <li>REFERENCE_NO - Referans no(KRedi icin Basvuru No) <li>FILE_NAME - Dosya adi <li>FILE - Dosya icerigi <li>FILE_FULL_PATH - Dosya tam path
	 * @return oMap - Sonuc bilgisi<br>
	 */
	@GraymoundService("BNSPR_FTP_DOSYA_AKTAR")
	public static GMMap ftpDosyaAktar(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();
		AktifSFTPClient aktifSFTPClient = null;
		String fileName = "";
		
		try {
			String serverUri = null;
			String userName = null;
			String password = null;
			String ftpRootPath = null;
			// ftp erisim bilgilerini al
			sorguMap.clear();
			sorguMap.put("TABLE_NAME", Constants.RESULT);
			sorguMap.put("KOD", "DYS_FTP_JOB_PARAMS");
			sorguMap.put("KEY1", iMap.get("PROJECT"));
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_KEY", sorguMap));
			// Kontrol
			String value = null;
			String parameter = null;
			for (int i = 0; i < sorguMap.getSize(Constants.RESULT); i++) {
				parameter = sorguMap.getString(Constants.RESULT, i, "KEY2");
				value = sorguMap.getString(Constants.RESULT, i, "NAME");
				if ("USERNAME".equals(parameter)) {
					userName = value;
				}
				else if ("PASSWORD".equals(parameter)) {
					password = value;
				}
				else if ("FTP_ROOT_PATH".equals(parameter)) {
					ftpRootPath = value;
				}
				else if ("SERVER_URI".equals(parameter)) {
					serverUri = value;
				}
			}
			
			// Ftpye dosyayi yaz
			String filePath = ftpRootPath + "/" + iMap.getString("REFERENCE_NO");
			aktifSFTPClient = new AktifSFTPClient(serverUri, userName, password, 22);

			if (!aktifSFTPClient.isFileExist(ftpRootPath, iMap.getString("REFERENCE_NO"))) {
				aktifSFTPClient.createDirectory(ftpRootPath, iMap.getString("REFERENCE_NO"));
			}
			
			if(iMap.get("FILE_LIST") != null && iMap.getSize("FILE_LIST") > 0) {
				for (int i = 0; i< iMap.getSize("FILE_LIST"); i++) {
					fileName = iMap.getString("FILE_LIST", i, "FILE_NAME");

					if (StringUtils.isNotBlank(iMap.getString("FILE_LIST", i, "FILE_FULL_PATH"))) {
						aktifSFTPClient.put(filePath, fileName, new File(iMap.getString("FILE_LIST", i, "FILE_FULL_PATH")));
					}
					else if (StringUtils.isNotBlank(iMap.getString("FILE_LIST", i, "FILE"))) {
						aktifSFTPClient.put(filePath, fileName, Base64.decode(iMap.getString("FILE_LIST", i, "FILE")));
					}
				}
			}else{
				fileName = iMap.getString("FILE_NAME");
				if (StringUtils.isNotBlank(iMap.getString("FILE_FULL_PATH"))) {
					aktifSFTPClient.put(filePath, fileName, new File(iMap.getString("FILE_FULL_PATH")));
				}
				else if (StringUtils.isNotBlank(iMap.getString("FILE"))) {
					aktifSFTPClient.put(filePath, fileName, Base64.decode(iMap.getString("FILE")));
				}
			}
			
		}
		catch (FtpClientException e) {
			String message = StringUtils.EMPTY;

			if (e.getMessage().contains("Connection timed out")) {
				message = "Baglanti zaman asimi!";
			}
			else {
				message = fileName + " dosyasinin musteri uzerine aktarilmasi sirasinda hata olustu!";
			}
			
			logger.error(message);
			e.printStackTrace();
			throw new FtpClientException(message);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally{
			if(aktifSFTPClient != null) {
				aktifSFTPClient.closeConnection();
			}
		}

		return oMap;
	}

	/**
	 * Dosyanin atilacagi gecici dizin pathini olusturur.<br>
	 * 
	 * @author murat.el
	 * @since PY-10975
	 * @param iMap
	 *            - Basvuru bilgisi<br>
	 *            <li>BASVURU_NO - Kredi basvuru numarasi <li>DOKUMAN_KOD - Dokuman kodu <li>DOSYA_UZANTISI - Dosya uzantisi
	 * @return oMap - Sonuc bilgisi<br>
	 *         <li>DOSYA_YOLU - Dosynin yuklenecegi path
	 */
	@GraymoundService("BNSPR_TRN3182_GET_DOKUMAN_PATH")
	public static GMMap generateBayiDokumanTempPath(GMMap iMap) {
		GMMap oMap = new GMMap();
		String rootPath = null;
		String basvuruPath = null;
		String filePath = null;
		String arsivPath = null;
		String arsivFilePath = null;

		try {
			GMMap sorguMap = new GMMap();
			sorguMap.put("PARAMETRE", "KRE_DOKUMAN_PATH");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap));
			rootPath = sorguMap.getString("DEGER");

			String basvuruNo = iMap.getString(Constants.BASVURU_NO);
			if (StringUtils.isNotBlank(basvuruNo)) {
				basvuruPath = rootPath + File.separator + basvuruNo;
			}

			String dokumanKod = iMap.getString(Constants.DOKUMAN_KOD);
			if (StringUtils.isNotBlank(dokumanKod)) {
				filePath = basvuruPath + File.separator + dokumanKod + "." + ConsumerLoanCommonServices.nvl(iMap.getString("DOSYA_UZANTISI"), "pdf");
				arsivPath = basvuruPath + File.separator + "ARSIV";

				SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
				String time = sdf.format(Calendar.getInstance().getTime());
				arsivFilePath = arsivPath + File.separator + dokumanKod + "_" + time + "." + ConsumerLoanCommonServices.nvl(iMap.getString("DOSYA_UZANTISI"), "pdf");
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		oMap.put("ROOT_PATH", rootPath);
		oMap.put("BASVURU_PATH", basvuruPath);
		oMap.put("FILE_PATH", filePath);
		oMap.put("ARSIV_PATH", arsivPath);
		oMap.put("ARSIV_FILE_PATH", arsivFilePath);
		return oMap;
	}

	/**
	 * Gecici dizindeki dosyayi ekranda goruntulemek icin byteArray olarak doner<br>
	 * 
	 * @author murat.el
	 * @since PY-10975
	 * @param iMap
	 *            - Basvuru bilgisi<br>
	 *            <li>BASVURU_NO - Kredi basvuru numarasi <li>DOKUMAN_KOD - Dokuman kodu
	 * @return oMap - Sonuc bilgisi<br>
	 *         <li>FILE - Byte array halindeki dosya
	 */
	@GraymoundService("BNSPR_TRN3182_GET_DOKUMAN_AS_PDF_BYTE_ARRAY")
	public static GMMap getDokumanAsPdfByteArray(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		try {
			String filePath = iMap.getString("FILE_PATH", StringUtils.EMPTY);

			if (StringUtils.isEmpty(filePath)) {
				sorguMap.clear();
				sorguMap.put(Constants.BASVURU_NO, iMap.get(Constants.BASVURU_NO));
				sorguMap.put(Constants.DOKUMAN_KOD, iMap.get(Constants.DOKUMAN_KOD));
				sorguMap.putAll(generateBayiDokumanTempPath(sorguMap));
				filePath = sorguMap.getString("FILE_PATH");
			}

			// Dosyayi al
			File file = new File(filePath);
			if (file != null && file.exists()) {
				ByteArrayType fileByteArray = new ByteArrayType();
				fileByteArray.setData(FileUtils.readFileToByteArray(file));
				oMap.put("FILE", fileByteArray);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3182_MERGE_PDF")
	public static GMMap mergePdf(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sorguMap = new GMMap();

		sorguMap.clear();
		sorguMap.put(Constants.BASVURU_NO, iMap.get(Constants.BASVURU_NO));
		sorguMap.put(Constants.DOKUMAN_KOD, iMap.get(Constants.DOKUMAN_KOD));
		sorguMap.putAll(generateBayiDokumanTempPath(sorguMap));
		String filePath = sorguMap.getString("FILE_PATH");
		String arsivFilePath = sorguMap.getString("ARSIV_FILE_PATH");
		String mergePath = sorguMap.getString("BASVURU_PATH") + File.separator + "merge" + "." + ConsumerLoanCommonServices.nvl(iMap.getString("DOSYA_UZANTISI"), "pdf");

		File source = new File(filePath);
		if (source.isFile()) {
			File dest = new File(arsivFilePath);

			InputStream is = null;
			OutputStream os = null;

			try {

				is = new FileInputStream(source);
				os = new FileOutputStream(dest);

				byte[] buffer = new byte[1024];
				int length;

				while ((length = is.read(buffer)) > 0) {

					os.write(buffer, 0, length);
				}

				is.close();
				os.close();

			}
			catch (Exception e) {

			}
		}

		try {
			Document document = new Document();

			FileOutputStream outputStream = new FileOutputStream(mergePath);
			PdfWriter writer = PdfWriter.getInstance(document, outputStream);
			document.open();
			PdfContentByte cb = writer.getDirectContent();

			for (int row = 0; row < iMap.getSize("BELGELER"); row++) {

				if (iMap.getBoolean("BELGELER", row, "BIRLESTIR")) {
					PdfReader pdfReader = new PdfReader(iMap.getString("BELGELER", row, "PATH"));
					for (int page = 1; page <= pdfReader.getNumberOfPages(); page++) {
						document.newPage();
						PdfImportedPage pdfPage = writer.getImportedPage(pdfReader, page);
						cb.addTemplate(pdfPage, 0, 0);
					}

					pdfReader.close();
				}

			}

			outputStream.flush();
			document.close();
			outputStream.close();

			FileUtils.forceDelete(new File(filePath));
			FileUtils.moveFile(new File(mergePath), new File(filePath));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	// ***************************************************************************
	@GraymoundService("BNSPR_TRN3182_BASVURU_BELGE_LIST")
	public static GMMap basvuruBelgeList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_RC_3182.rasgele_basvuru_belge_list(?,?,?,?,?,?,?)}";
			Object[] inputValues = new Object[14];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TC_KIMLIK_NO");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("KANAL_KODU");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("SATICI_KODU");
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("BASLANGIC_TAR");
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("BITIS_TAR");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("HOBIM_RANDOM_EH");

			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "BASVURU_BILGILERI", inputValues));
		}
		catch (Exception E) {
			throw ExceptionHandler.convertException(E);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3182_HOBIM_RANDOM_SAVE")
	public static GMMap saveHobimRandom(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String proc = "{call PKG_RC_3182.hobim_random_kayit_kapa(?,?)}";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("HOBIM_RANDOM_TX_NO"), BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO") };
			Object[] outputValues = new Object[0];

			DALUtil.callOracleProcedure(proc, inputValues, outputValues);
		}
		catch (Exception E) {
			throw ExceptionHandler.convertException(E);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3182_GET_BASVURU_NO_BY_TRX_NO")
	public static GMMap getBasvuruNoByTxNo(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			// Session ac
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			// Kaydi al
			BirBasvuruBelgeKontrolTx birBasvuruBelgeKontrolTx = (BirBasvuruBelgeKontrolTx) session.createCriteria(BirBasvuruBelgeKontrolTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (birBasvuruBelgeKontrolTx != null) {
				oMap.put("BASVURU_NO", birBasvuruBelgeKontrolTx.getId().getBasvuruNo());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	private static BigDecimal getTxNoByBasvuruNo(BigDecimal basvuruNo) {
		BigDecimal trxNo = null;

		try {
			// Session ac
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			// Kaydi al
			BirBasvuruBelgeKontrolTx birBasvuruBelgeKontrolTx = (BirBasvuruBelgeKontrolTx) session.createCriteria(BirBasvuruBelgeKontrolTx.class).add(Restrictions.eq("id.basvuruNo", basvuruNo)).addOrder(Order.desc("islemTarihi")).setMaxResults(1).uniqueResult();
			if (birBasvuruBelgeKontrolTx != null) {
				trxNo = birBasvuruBelgeKontrolTx.getId().getTxNo();
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return trxNo;
	}

	@GraymoundService("BNSPR_TRN3182_COPY_FILE")
	public static GMMap createFile(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			String sourceFilePath = iMap.getString("SOURCE_FILE_PATH", StringUtils.EMPTY);

			if (StringUtils.isEmpty(sourceFilePath)) {
				GMMap fileInfoMap = new GMMap();
				fileInfoMap.put(Constants.BASVURU_NO, iMap.get(Constants.BASVURU_NO));
				fileInfoMap.put(Constants.DOKUMAN_KOD, iMap.get(Constants.DOKUMAN_KOD));
				sourceFilePath = generateBayiDokumanTempPath(fileInfoMap).getString("FILE_PATH");
			}

			File sourceFile = new File(sourceFilePath);
			if (!sourceFile.exists()) {
				oMap.put("MESSAGE", "Kaynak dosya bulunamad�!");
			}
			else {
				File destFile = new File(iMap.getString("DEST_FILE_PATH") + File.separator + iMap.getString("FILE_NAME"));
				FileUtils.copyFile(sourceFile, destFile);
				oMap.put("MESSAGE", "��lem ba�ar�yla tamamland�.");
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	/**
	 * BIR_BASVURU_BELGE kayd�n� g�nceller,
	 * BIR_BASVURU_BELGE_TX e kay�t olusturur.
	 */
	public static GMMap documentKodUpdate(BigDecimal basvuruNo, String dokumanKod, BigDecimal kontrolNumarasi) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName = "TABLE";
		String rootPath = StringUtils.EMPTY;
		BigDecimal txNo = BigDecimal.ZERO;
		String fileExtension = ".pdf";

		String barKod = null;

		/*
		basvuruNo = new BigDecimal(9776228);
		dokumanKod = "886";
		kontrolNumarasi = new BigDecimal(8);*/

		barKod = basvuruNo + "_" + dokumanKod + "_" + kontrolNumarasi;

		LOGGER.info("Barkod icin dokumentKodUpdate basliyor." + barKod);

		GMMap iMap = new GMMap();
		try {
			iMap.put("PARAMETRE", "KRE_DOKUMAN_PATH");
			rootPath = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).getString("DEGER");
			txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN3182.getEksikBelgeKontrolDocument(? ,? ,?)}");
			stmt.setBigDecimal(1, basvuruNo);
			stmt.setString(2, dokumanKod);
			stmt.registerOutParameter(3, -10);

			stmt.execute();
			stmt.getMoreResults();

			rSet = (ResultSet) stmt.getObject(3);
			iMap = DALUtil.rSetResults(rSet, tableName);

			if (iMap.getSize(tableName) == 0)
				LOGGER.info("Barkod db de bulunamadi." + barKod);
			else
				LOGGER.info("Barkod icin for loop a giriliyor." + barKod);

			for (int i = 0; i < iMap.getSize(tableName); i++) {
				BigDecimal txRecDate = iMap.getBigDecimal(tableName, i, "REC_DATE");
				String belgeKontrol = iMap.getString(tableName, i, "BELGE_KONTROL");

				File basvuruDir = new File(rootPath + File.separator + basvuruNo);
				File archiveDir = new File(basvuruDir + File.separator + "ARSIV");

				String fileName = dokumanKod + "_" + String.valueOf(System.currentTimeMillis()) + fileExtension;

				Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

				if (Constants.BELGE_KONTROL_EKSIK.equals(belgeKontrol) || Constants.BELGE_KONTROL_HATALI.equals(belgeKontrol)) {
					belgeKontrol = Constants.BELGE_KONTROL_EKSIK_BELGE_YUKLENDI;
				}
				else {
					belgeKontrol = Constants.BELGE_KONTROL_YUKLENDI;
				}

				BirBasvuruBelgeId belgeId = new BirBasvuruBelgeId();
				belgeId.setBasvuruNo(basvuruNo);
				belgeId.setDokumanKod(dokumanKod);
				belgeId.setKimden("M");

				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) session.get(BirBasvuruBelge.class, belgeId);

				if (!(birBasvuruBelge.getBelgeKontrol().equals("1") || birBasvuruBelge.getBelgeKontrol().equals("4"))) {
					birBasvuruBelge.setAlindi(Constants.EVET);
					birBasvuruBelge.setBelgeKontrol(belgeKontrol);
					birBasvuruBelge.setKontrolNumarasi(kontrolNumarasi);

					session.update(birBasvuruBelge);

					BirBasvuruBelgeTxId id = new BirBasvuruBelgeTxId();
					id.setTxNo(txNo);
					id.setBasvuruNo(basvuruNo);
					id.setDokumanKod(dokumanKod);
					id.setKimden("M");

					BirBasvuruBelgeTx birBasvuruBelgeTx = new BirBasvuruBelgeTx();
					birBasvuruBelgeTx.setId(id);
					birBasvuruBelgeTx.setAlindi(Constants.EVET);
					birBasvuruBelgeTx.setBelgeKontrol(belgeKontrol);
					birBasvuruBelgeTx.setKontrolNumarasi(kontrolNumarasi);
					birBasvuruBelgeTx.setVersiyonPath(archiveDir.getPath() + File.separator + fileName);

					session.save(birBasvuruBelgeTx);
					LOGGER.info("BirBasvuruBelgeTx update edildi " + barKod);
				}
				else
					LOGGER.info("BirBasvuruBelgeTx update edilmedi ,kontrol no : " + birBasvuruBelge.getBelgeKontrol() + " barkod: " + barKod);

				KryKuryeArsivGirisDetay kuryeArsivGirisDetay = new KryKuryeArsivGirisDetay();
				kuryeArsivGirisDetay.setBasvuruNo(basvuruNo);
				kuryeArsivGirisDetay.setDokumanKod(new BigDecimal(dokumanKod));

				Criteria criteria = session.createCriteria(KryKuryeArsivGirisDetay.class).add(Restrictions.eq("basvuruNo", basvuruNo)).add(Restrictions.eq("dokumanKod", new BigDecimal(dokumanKod))).addOrder(Order.desc("siraNo"));
				List<KryKuryeArsivGirisDetay> kuryeArsivGirisDetayList = (List<KryKuryeArsivGirisDetay>) criteria.list();

				if (kuryeArsivGirisDetayList.size() == 0)
					LOGGER.info("Kurye Arsiv tablosunda kayit olmadigi icin guncelleme yapilmadi: " + barKod);

				// max sirano daki item lari guncellicez
				for (KryKuryeArsivGirisDetay kryKuryeArsivGirisDetay : kuryeArsivGirisDetayList) {
					kryKuryeArsivGirisDetay.setBelgeGeldiMi("E");

					// Orjinal belge kolonu H ise update edicez ,null ise dokunma
					if (!StringUtils.isEmpty(kryKuryeArsivGirisDetay.getOrjinalBelgeMi()))
						kryKuryeArsivGirisDetay.setOrjinalBelgeMi("E");

					session.save(kryKuryeArsivGirisDetay);
					LOGGER.info("KuryeArsivGirisDetay update edildi " + barKod);
					break;// en ust sira no daki item update edilecek digerleri degil
				}

				session.flush();

				try {
					oMap.put(Constants.BASVURU_NO, basvuruNo);
					oMap.put(Constants.DOKUMAN_KOD, dokumanKod);
					oMap.put(Constants.KIMDEN, "M");
					oMap.put(Constants.BELGE_KONTROL, belgeKontrol);
					oMap.put("TRX_NO", txNo);
					GMServiceExecuter.executeAsync("BNSPR_CL_IWD_CREATE_TASK", oMap);
					LOGGER.info(" BNSPR_CL_IWD_CREATE_TASK calistirildi." + barKod);
				}
				catch (Exception e) {
					LOGGER.error("BNSPR_CL_IWD_CREATE_TASK hata aldi: " + barKod + e.getMessage());
				}
			}
		}
		catch (Exception e) {
			LOGGER.error("DokumentUpdate hata aldi." + barKod + e.getMessage());
			ExceptionHandler.convertException(e);
		}
		finally {
			LOGGER.info("DokumentUpdate islemi bitti." + barKod);

			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	// ***************************************************************************
	// -------------------------- BAYI BELGE YUKLEME/TRANSFER ISLEMLERI
	// ***************************************************************************
	/**
	 * Enradan alinan bayi dokumanlari gecici dizine kaydedilir.<br>
	 * 
	 * @author murat.el
	 * @since PY-10975, PY-11141
	 * @param iMap
	 *            - Basvuru bilgisi<br>
	 *            <li>BASVURU_NO - Kredi basvuru numarasi <li>DOKUMAN_KOD - Dokuman kodu <li>DOSYA_ICERIK - Dosya icerigi <li>KANAL - Belgenin yuklendigi yer(Default:3270 - Belge yukleme ekrani|BAYI)
	 * @return oMap - Sonuc bilgisi<br>
	 *         <li>ARSIV_FILE_PATH - Versiyonlanan dosyanin pathi
	 * @throws IOException
	 */
	@GraymoundService("BNSPR_TRN3182_BELGE_YUKLE_WEB_SERVICE")
	public static GMMap belgeYukleWebService(GMMap iMap) throws IOException {

		GMMap oMap = new GMMap();

		String destinationDirectory = null; // Genel Parametre tablosundan aliyoruz
		String arsivFilePath = null;

		BigDecimal basvuruNo = iMap.getBigDecimal("APPLICATION_NO");
		String dokumanKod = iMap.getString("DOCUMENT_CODE");
		BigDecimal kontrolNumarasi = iMap.getBigDecimal("CONTROL_NO");
		// byte[] fileContent = (byte[]) (iMap.get("DOCUMENT_CONTENT"));

		String fileContentAsString = iMap.getString("DOCUMENT_CONTENT");
		byte[] fileContent = null;

		try {
			fileContent = new sun.misc.BASE64Decoder().decodeBuffer(fileContentAsString);
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			LOGGER.error("fileContent string e cevrilirken hata alindi. ");
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}

		String fileName = dokumanKod;
		String fileExtension = ".pdf";
		String barKod;
		String rootPath;
		GMMap sorguMap;

		/*
		basvuruNo = new BigDecimal(42967);
		dokumanKod = "886";
		kontrolNumarasi = new BigDecimal(8);
		fileName = "HowHibernate3MakesComplexThingsEasy";*/

		barKod = basvuruNo + "_" + dokumanKod + "_" + kontrolNumarasi;

		// File localFile = new File("C:\\Users\\volkan.suyabatmaz\\Desktop\\551" + ".pdf");

		LOGGER.info("belgeYukleWebService basliyor ,barKod: " + barKod);
		/*
		try
		{
			fileContent  = FileUtils.readFileToByteArray(localFile);				
		}
		catch(Exception e)
		{
			throw ExceptionHandler.convertException(e);
		}*/

		// Burda su onemli ,kod server da calistigindan biz Test ederken server pathini eklemezsek bilgisayarin pathini aliyor ,UAT de su yok \\\\10.90.14.211
		// Server in pathi bulunuyor -- \\\\10.90.14.211\data\BAYI_DOKUMAN
		try {
			sorguMap = new GMMap();
			sorguMap.put("PARAMETRE", "KRE_DOKUMAN_PATH");
			sorguMap.putAll(GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", sorguMap));
			rootPath = sorguMap.getString("DEGER");
			LOGGER.info("Server path alindi ,barKod: " + barKod);
		}
		catch (Exception e) {
			LOGGER.error("Server path alinirken hata " + barKod);
			throw ExceptionHandler.convertException(e);
		}

		try {
			destinationDirectory = rootPath + File.separator + basvuruNo.toString();
			File destinationDir = new File(destinationDirectory);

			Runtime runtime = Runtime.getRuntime();

			// Bu BasvuruNo nun klasoru yoksa olustur ,cunku bu basvuruya ait dokumanlar bu folder a konucak
			if (!destinationDir.exists()) {
				if (SystemUtils.IS_OS_WINDOWS) {
					destinationDir.mkdir();
				}
				else {
					String[] cmdLine = { "mkdir", destinationDirectory };
					Process p = runtime.exec(cmdLine);
					p.waitFor();
				}
				LOGGER.info("belgeYukleWebService dizin olusturuldu : " + destinationDirectory + " " + barKod);
			}

			// DB de dosya icin guncellemeleri yapalim
			documentKodUpdate(basvuruNo, dokumanKod, kontrolNumarasi);

			// Eger gelen dosya daha onceden upload edilmemisse kaydet
			if (!(new File(destinationDirectory, fileName + fileExtension)).exists()) {
				FileUtils.writeByteArrayToFile(new File(destinationDirectory, fileName + fileExtension), fileContent);
				LOGGER.info("belgeYukleWebService dosya byte olarak dizine kaydedildi: " + fileName + fileExtension + " " + barKod);

				return oMap;
			}
			else {
				// Mevcut dosyayi arsive aktar (move et)yeni bir isimle ,yeni geleni eskisinin yerine yukardaki gibi kaydet

				Date today = new Date();
				Calendar cal = Calendar.getInstance();
				cal.setTime(today); // don't forget this if date is arbitrary e.g. 01-01-2014
				int day = cal.get(Calendar.DAY_OF_WEEK_IN_MONTH);
				int month = cal.get(Calendar.DAY_OF_MONTH);
				int year = cal.get(Calendar.YEAR);
				String dayStr = (day < 10) ? "0" + String.valueOf(day) : String.valueOf(day);

				// Arsiv klasoru yoksa olustur
				arsivFilePath = destinationDirectory + File.separator + "ARSIV";
				File arsivDirectory = new File(arsivFilePath);

				if (!arsivDirectory.exists()) {
					if (SystemUtils.IS_OS_WINDOWS) {
						arsivDirectory.mkdir();
					}
					else {
						String[] cmdLine = { "mkdir", arsivFilePath };
						Process p = runtime.exec(cmdLine);
						p.waitFor();
					}
					LOGGER.info("belgeYukleWebService ARSIV dizini olusturuldu : " + arsivFilePath + " " + barKod);
				}

				String fileNameArchived = fileName + "_" + String.valueOf(year) + String.valueOf(month) + dayStr + "_" + String.valueOf(System.currentTimeMillis()) + fileExtension;

				// Mevcut directory deki ,yeni bir isimle Arsive aktariliyor
				FileUtils.copyFile(new File(destinationDirectory, fileName + fileExtension), new File(arsivFilePath, fileNameArchived));
				LOGGER.info("belgeYukleWebService dosya byte olarak ARSIV dizinine kaydedildi: " + arsivFilePath);

				// Yeni gelen mevcudun uzerine yaziliyor
				FileUtils.writeByteArrayToFile(new File(destinationDirectory, fileName + fileExtension), fileContent);
				LOGGER.info("belgeYukleWebService dosya byte olarak dizine kaydedildi: " + fileName + fileExtension + " " + barKod);

			}

		}
		catch (Exception e) {
			LOGGER.info("belgeYukleWebService hata aldi, barKod:" + barKod + " " + e.getMessage());
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

}
