package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.File;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.NumberUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirihtarnameMusteriLog;
import tr.com.aktifbank.bnspr.dao.BirihtarnameSorguLog;
import tr.com.aktifbank.bnspr.dao.FtmFileContent;
import tr.com.aktifbank.bnspr.dao.GnlApsLog;
import tr.com.aktifbank.bnspr.dao.GnlMusteriAps;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.consumerloan.utils.FileUtils;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.integration.ftp.AktifSFTPClient;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanHobimServices {
	private static String FILE_ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root" + File.separator + "files" ;
	private static final Logger logger = Logger.getLogger(ConsumerLoanHobimServices.class);
	@GraymoundService("BNSPR_HOBIM_PREPARE_IHTARNAME_DOSYASI")
	public static GMMap prepareIhtarnameDosyasi(GMMap iMap){
		GMMap oMap = new GMMap();
		StringBuilder bireysel = new StringBuilder();
		StringBuilder kmh = new StringBuilder();
		StringBuilder kk = new StringBuilder();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd_HHmm");
		Session session = null;
		BigDecimal ftmLineNumber = BigDecimal.ONE;
		BigDecimal ftmProcessId = BigDecimal.ZERO;
		String ftmGlbParamCode = "HOBIM_IHTAR_DATA_GONDER_FTM_ID";
		
		try{
			session = DAOSession.getSession("BNSPRDal");
			
			if(iMap.containsKey("BIREYSEL_IHTARNAME") && iMap.getSize("BIREYSEL_IHTARNAME") > 0){
				ftmProcessId = getNextValueOfFTMProcessId();
				oMap.put("FTM_PROCESS_ID", ftmProcessId);
				
				bireysel.append("TC_KIMLIK_NO");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("AD_SOYAD");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("ADRES");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("ADRES_ILCE");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("ADRES_IL");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("TARIH");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("BANKA_ADRES");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("TOPLAM_BORC");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("MUSTERI_NO");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("BASVURU_NO");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("BAGLI_HESAP_NO");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("KULLANDIRIM_TARIH");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("KULLANDIRIM_TUTAR");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("FAIZ_ORAN");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("YILLIK_FAIZ_ORAN");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("TEMERRUT_ORAN");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("TAKSIT_TUTAR");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("GECIKMIS_TAKSIT_SAYI");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("GECIKMIS_TAKSIT_TUTAR");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("GECIKME_FAIZ_TUTAR");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("ODENMEMIS_TAKSIT_TOPLAM");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("TOPLAM_BORC_TUTARI");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("MUSTERI_TOPLAM_BORC");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("SORGU_NO");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("ADRES_IL_KOD");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("ADRES_ILCE_KOD");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("IBAN");
				bireysel.append(Constants.FIELD_SEPERATOR);
				bireysel.append("IHTAR_MASRAF");
				
				oMap.put("OID", ftmLineNumber.toString());
				oMap.put("LINE", bireysel.toString());
				oMap.put("LINE_NUMBER", ftmLineNumber);
				addLineToFtm(session, oMap);
				ftmLineNumber = ftmLineNumber.add(BigDecimal.ONE);
				
				for(int k = 0; k<iMap.getSize("BIREYSEL_IHTARNAME");k++){
					bireysel = new StringBuilder(StringUtils.EMPTY);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k,"TC_KIMLIK_NO")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k,"AD_SOYAD")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k,"ADRES")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k,"ADRES_ILCE")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k,"ADRES_IL")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k,"TARIH")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k,"BANKA_ADRES")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k,"TOPLAM_BORC")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "MUSTERI_NO")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "BASVURU_NO")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "BAGLI_HESAP_NO")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "KULLANDIRIM_TARIH")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "KULLANDIRIM_TUTAR")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "FAIZ_ORAN")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "YILLIK_FAIZ_ORAN")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "TEMERRUT_ORAN")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "TAKSIT_TUTAR")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "GECIKMIS_TAKSIT_SAYI")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "GECIKMIS_TAKSIT_TUTAR")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "GECIKME_FAIZ_TUTAR")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "ODENMEMIS_TAKSIT_TOPLAM")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "TOPLAM_BORC_TUTARI")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "MUSTERI_TOPLAM_BORC")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "SORGU_NO")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "ADRES_IL_KOD")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "ADRES_ILCE_KOD")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "IBAN")).append(Constants.FIELD_SEPERATOR);
					bireysel.append(iMap.get("BIREYSEL_IHTARNAME",k, "IHTAR_MASRAF"));
					
					oMap.put("OID", ftmLineNumber.toString());
					oMap.put("LINE", bireysel.toString());
					oMap.put("LINE_NUMBER", ftmLineNumber);
					addLineToFtm(session, oMap);
					ftmLineNumber = ftmLineNumber.add(BigDecimal.ONE);
				}
				
				session.flush();
				
				String fileName = "BIREYSEL_"+sdf.format(new Date())+".csv";
				sendFileByFtm(fileName, ftmProcessId, ftmGlbParamCode);
			}
			if(iMap.containsKey("KMH_IHTARNAME") && iMap.getSize("KMH_IHTARNAME") > 0){
				ftmProcessId = getNextValueOfFTMProcessId();
				oMap.put("FTM_PROCESS_ID", ftmProcessId);
				
				kmh.append("TC_KIMLIK_NO");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("AD_SOYAD");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("ADRES");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("ADRES_ILCE");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("ADRES_IL");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("TARIH");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("BANKA_ADRES");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("TOPLAM_BORC");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("MUSTERI_NO");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("BASVURU_NO");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("BAGLI_HESAP_NO");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("KULLANDIRIM_TARIH");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("KULLANDIRIM_TUTAR");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("FAIZ_ORAN");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("YILLIK_FAIZ_ORAN");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("TEMERRUT_ORAN");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("TAKSIT_TUTAR");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("GECIKMIS_TAKSIT_SAYI");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("GECIKMIS_TAKSIT_TUTAR");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("GECIKME_FAIZ_TUTAR");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("ODENMEMIS_TAKSIT_TOPLAM");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("ANAPARA_TUTARI");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("BSMV_TUTARI");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("KKDF_TUTARI");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("TOPLAM_BORC_TUTARI");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("MUSTERI_TOPLAM_BORC");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("SORGU_NO");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("ADRES_IL_KOD");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("ADRES_ILCE_KOD");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("IBAN");
				kmh.append(Constants.FIELD_SEPERATOR);
				kmh.append("IHTAR_MASRAF");
				
				oMap.put("OID", ftmLineNumber.toString());
				oMap.put("LINE", kmh.toString());
				oMap.put("LINE_NUMBER", ftmLineNumber);
				addLineToFtm(session, oMap);
				ftmLineNumber = ftmLineNumber.add(BigDecimal.ONE);
			
				for(int k = 0; k<iMap.getSize("KMH_IHTARNAME");k++){
					kmh = new StringBuilder(StringUtils.EMPTY);
					kmh.append(iMap.get("KMH_IHTARNAME",k,"TC_KIMLIK_NO")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k,"AD_SOYAD")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k,"ADRES")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k,"ADRES_ILCE")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k,"ADRES_IL")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k,"TARIH")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k,"BANKA_ADRES")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k,"TOPLAM_BORC")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "MUSTERI_NO")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "BASVURU_NO")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "BAGLI_HESAP_NO")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "KULLANDIRIM_TARIH")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "KULLANDIRIM_TUTAR")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "FAIZ_ORAN")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "YILLIK_FAIZ_ORAN")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "TEMERRUT_ORAN")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "TAKSIT_TUTAR")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "GECIKMIS_TAKSIT_SAYI")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "GECIKMIS_TAKSIT_TUTAR")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "GECIKME_FAIZ_TUTAR")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "ODENMEMIS_TAKSIT_TOPLAM")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "ANAPARA_TUTARI")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "BSMV_TUTARI")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "KKDF_TUTARI")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "TOPLAM_BORC_TUTARI")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "MUSTERI_TOPLAM_BORC")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "SORGU_NO")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "ADRES_IL_KOD")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "ADRES_ILCE_KOD")).append(Constants.FIELD_SEPERATOR);					
					kmh.append(iMap.get("KMH_IHTARNAME",k, "IBAN")).append(Constants.FIELD_SEPERATOR);
					kmh.append(iMap.get("KMH_IHTARNAME",k, "IHTAR_MASRAF"));
					
					oMap.put("OID", ftmLineNumber.toString());
					oMap.put("LINE", kmh.toString());
					oMap.put("LINE_NUMBER", ftmLineNumber);
					addLineToFtm(session, oMap);
					ftmLineNumber = ftmLineNumber.add(BigDecimal.ONE);
				}
				
				session.flush();
				
				String fileName = "KMH_"+sdf.format(new Date())+".csv";
				sendFileByFtm(fileName, ftmProcessId, ftmGlbParamCode);
			}

			if(iMap.containsKey("KK_IHTARNAME") && iMap.getSize("KK_IHTARNAME") > 0){
				ftmProcessId = getNextValueOfFTMProcessId();
				oMap.put("FTM_PROCESS_ID", ftmProcessId);
				
				kk.append("TC_KIMLIK_NO");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("AD_SOYAD");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("ADRES");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("ADRES_ILCE");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("ADRES_IL");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("TARIH");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("BANKA_ADRES");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("MUSTERI_TOPLAM_BORC");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("MUSTERI_NO");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("KART_NO");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("ASGARI_ODEME_TUTAR");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("ANAPARA_TUTAR");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("GECIKME_FAIZ_TUTAR");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("KKDF_TUTAR");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("BSMV_TUTAR");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("TOPLAM_BORC_TUTARI");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("SORGU_NO");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("ADRES_IL_KOD");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("ADRES_ILCE_KOD");
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("BAGLI_HESAP_NO");				
				kk.append(Constants.FIELD_SEPERATOR);
				kk.append("IBAN");
				
				oMap.put("OID", ftmLineNumber.toString());
				oMap.put("LINE", kk.toString());
				oMap.put("LINE_NUMBER", ftmLineNumber);
				addLineToFtm(session, oMap);
				ftmLineNumber = ftmLineNumber.add(BigDecimal.ONE);
				
				for(int k = 0; k<iMap.getSize("KK_IHTARNAME");k++){
					kk = new StringBuilder(StringUtils.EMPTY);
					kk.append(iMap.get("KK_IHTARNAME",k,"TC_KIMLIK_NO")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k,"AD_SOYAD")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k,"ADRES")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k,"ADRES_ILCE")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k,"ADRES_IL")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k,"TARIH")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k,"BANKA_ADRES")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k,"MUSTERI_TOPLAM_BORC")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k, "MUSTERI_NO")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k, "KART_NO")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k, "ASGARI_ODEME_TUTAR")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k, "ANAPARA_TUTAR")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k, "GECIKME_FAIZ_TUTAR")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k, "KKDF_TUTAR")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k, "BSMV_TUTAR")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k, "TOPLAM_BORC_TUTARI")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k, "SORGU_NO")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k, "ADRES_IL_KOD")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k, "ADRES_ILCE_KOD")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k, "BAGLI_HESAP_NO")).append(Constants.FIELD_SEPERATOR);
					kk.append(iMap.get("KK_IHTARNAME",k, "IBAN"));
					
					oMap.put("OID", ftmLineNumber.toString());
					oMap.put("LINE", kk.toString());
					oMap.put("LINE_NUMBER", ftmLineNumber);
					addLineToFtm(session, oMap);
					ftmLineNumber = ftmLineNumber.add(BigDecimal.ONE);
				}
				
				session.flush();
				
				String fileName = "KK_"+sdf.format(new Date())+".csv";
				sendFileByFtm(fileName, ftmProcessId, ftmGlbParamCode);
			}
		}catch(Exception e){
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}


	@GraymoundService("BNSPR_HOBIM_NOTER_IHTAR_RAPOR")
	public static GMMap hobimNoterIhtarReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap hobimOutput = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		int count = 0;
		try {
			String func = "{? = call pkg_genel_pr.bankamiz_adres}";
			iMap.put("BANKA_ADRES", String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, new Object[] {})).replaceAll("\n", " "));
			
			//musteri listesini don
			for (int i = 0; i < iMap.getSize("MUSTERI_LIST"); i++) {
				// musterinin birden fazla kredisi varsa bunlari toparla
				for (int j = 0; j < iMap.getSize("KREDI_LIST"); j++) {
					//birden fazla kredisi varsa her kayit ard arda gelmelidir bular hobim tafafinda tek bir ihtarnamde basilmlidir
					if (iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO").equals(iMap.getString("KREDI_LIST", j, "MUSTERI_NO"))) {
						hobimOutput.put("BIREYSEL_IHTARNAME",count,"TC_KIMLIK_NO", iMap.getString("MUSTERI_LIST", i, "TC_KIMLIK_NO"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count,"AD_SOYAD", iMap.getString("MUSTERI_LIST", i, "AD_SOYAD"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count,"ADRES", iMap.getString("MUSTERI_LIST", i, "ADRES"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count,"ADRES_ILCE", iMap.getString("MUSTERI_LIST", i, "ADRES_ILCE"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count,"ADRES_IL", iMap.getString("MUSTERI_LIST", i, "ADRES_IL"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count,"TARIH", sdf.format(new java.util.Date()));
						hobimOutput.put("BIREYSEL_IHTARNAME",count,"BANKA_ADRES", iMap.getString("BANKA_ADRES"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count,"MUSTERI_TOPLAM_BORC", iMap.getString("MUSTERI_LIST", i, "TOPLAM_BORC"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "MUSTERI_NO", iMap.getString("KREDI_LIST",j, "MUSTERI_NO"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "BASVURU_NO", iMap.getString("KREDI_LIST",j, "BASVURU_NO"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "BAGLI_HESAP_NO", iMap.getString("KREDI_LIST",j, "BAGLI_HESAP_NO"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "IBAN", iMap.getString("KREDI_LIST",j, "IBAN"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "KULLANDIRIM_TARIH", iMap.getString("KREDI_LIST",j, "KULLANDIRIM_TARIH"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "KULLANDIRIM_TUTAR", iMap.getString("KREDI_LIST",j, "KULLANDIRIM_TUTAR"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "FAIZ_ORAN", iMap.getString("KREDI_LIST",j, "FAIZ_ORAN"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "YILLIK_FAIZ_ORAN", iMap.getString("KREDI_LIST",j, "YILLIK_FAIZ_ORAN"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "TEMERRUT_ORAN", iMap.getString("KREDI_LIST",j, "TEMERRUT_ORAN"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "TAKSIT_TUTAR", iMap.getString("KREDI_LIST",j, "TAKSIT_TUTAR"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "GECIKMIS_TAKSIT_SAYI", iMap.getString("KREDI_LIST",j, "GECIKMIS_TAKSIT_SAYI"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "GECIKMIS_TAKSIT_TUTAR", iMap.getString("KREDI_LIST",j, "GECIKMIS_TAKSIT_TUTAR"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "GECIKME_FAIZ_TUTAR", iMap.getString("KREDI_LIST",j, "GECIKME_FAIZ_TUTAR"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "ODENMEMIS_TAKSIT_TOPLAM", iMap.getString("KREDI_LIST",j, "ODENMEMIS_TAKSIT_TOPLAM"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "TOPLAM_BORC_TUTARI", iMap.getString("KREDI_LIST", j, "TOPLAM_BORC_TUTARI"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "SORGU_NO", iMap.getString("KREDI_LIST", j, "SORGU_NO"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "ADRES_IL_KOD", iMap.getString("MUSTERI_LIST", i, "ADRES_IL_KOD"));
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "ADRES_ILCE_KOD", iMap.getString("MUSTERI_LIST", i, "ADRES_ILCE_KOD"));
						//BT-7989
						hobimOutput.put("BIREYSEL_IHTARNAME",count, "IHTAR_MASRAF", iMap.getString("MUSTERI_LIST", i, "IHTAR_MASRAF"));
						//logger.info("Ihtarname Masraf BK : " + iMap.getString("MUSTERI_LIST", i, "IHTAR_MASRAF"));
						count++;
					}
				}

			}
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e);
		}
		logger.info("--------------------------------------------hobimNoterIhtarReport");
		logger.info("BIREYSEL_IHTARNAME_SAYISI :"+count);
		prepareIhtarnameDosyasi(hobimOutput);
		oMap.put("BIREYSEY_IHTARNAME_COUNT", count);
		oMap.put("RESPONSE", "2");
		return oMap;
	}


	@GraymoundService("BNSPR_HOBIM_KK_IHTAR_RAPOR")
	public static GMMap hobimKkIhtarReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap hobimOutput = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		int count = 0;
		try {
			String func = "{? = call pkg_genel_pr.bankamiz_adres}";
			iMap.put("BANKA_ADRES", String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, new Object[] {})).replaceAll("\n", " "));
			for (int i = 0; i < iMap.getSize("MUSTERI_LIST"); i++) {
				for (int j = 0; j < iMap.getSize("KREDI_LIST"); j++) {
					if (iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO").equals(iMap.getString("KREDI_LIST", j, "MUSTERI_NO"))) {
						hobimOutput.put("KK_IHTARNAME",count, "TC_KIMLIK_NO", iMap.getString("MUSTERI_LIST", i, "TC_KIMLIK_NO"));
						hobimOutput.put("KK_IHTARNAME",count, "AD_SOYAD", iMap.getString("MUSTERI_LIST", i, "AD_SOYAD"));
						hobimOutput.put("KK_IHTARNAME",count, "ADRES", iMap.getString("MUSTERI_LIST", i, "ADRES"));
						hobimOutput.put("KK_IHTARNAME",count, "ADRES_ILCE", iMap.getString("MUSTERI_LIST", i, "ADRES_ILCE"));
						hobimOutput.put("KK_IHTARNAME",count, "ADRES_IL", iMap.getString("MUSTERI_LIST", i, "ADRES_IL"));
						hobimOutput.put("KK_IHTARNAME",count, "TARIH", sdf.format(new java.util.Date()));
						hobimOutput.put("KK_IHTARNAME",count, "BANKA_ADRES", iMap.getString("BANKA_ADRES"));
						hobimOutput.put("KK_IHTARNAME",count, "MUSTERI_TOPLAM_BORC", iMap.getString("MUSTERI_LIST", i, "TOPLAM_BORC"));
						hobimOutput.put("KK_IHTARNAME",count, "MUSTERI_NO", iMap.getString("KREDI_LIST",j, "MUSTERI_NO"));
						hobimOutput.put("KK_IHTARNAME",count, "KART_NO", StringUtils.leftPad(iMap.getString("KREDI_LIST",j, "KART_NO"), 16, "*"));
						hobimOutput.put("KK_IHTARNAME",count, "IBAN", iMap.getString("KREDI_LIST",j, "IBAN"));
						hobimOutput.put("KK_IHTARNAME",count, "BAGLI_HESAP_NO", iMap.getString("KREDI_LIST",j, "BAGLI_HESAP_NO"));
						hobimOutput.put("KK_IHTARNAME",count, "ASGARI_ODEME_TUTAR", iMap.getString("KREDI_LIST",j, "ASGARI_ODEME_TUTAR"));
						hobimOutput.put("KK_IHTARNAME",count, "ANAPARA_TUTAR", iMap.getString("KREDI_LIST",j, "ANAPARA_TUTAR"));
						hobimOutput.put("KK_IHTARNAME",count, "GECIKME_FAIZ_TUTAR", iMap.getString("KREDI_LIST",j, "GECIKME_FAIZ_TUTAR"));
						hobimOutput.put("KK_IHTARNAME",count, "KKDF_TUTAR", iMap.getString("KREDI_LIST",j, "KKDF_TUTAR"));
						hobimOutput.put("KK_IHTARNAME",count, "BSMV_TUTAR", iMap.getString("KREDI_LIST",j, "BSMV_TUTAR"));
						hobimOutput.put("KK_IHTARNAME",count, "TOPLAM_BORC_TUTARI", iMap.getString("KREDI_LIST",j, "TOPLAM_BORC_TUTARI"));
						hobimOutput.put("KK_IHTARNAME",count, "SORGU_NO", iMap.getString("KREDI_LIST",j, "SORGU_NO"));
						hobimOutput.put("KK_IHTARNAME",count, "ADRES_IL_KOD", iMap.getString("MUSTERI_LIST",i, "ADRES_IL_KOD"));
						hobimOutput.put("KK_IHTARNAME",count, "ADRES_ILCE_KOD", iMap.getString("MUSTERI_LIST",i, "ADRES_ILCE_KOD"));
						count++;
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		logger.info("--------------------------------------------hobimKKIhtarReport");
		logger.info("KK_IHTARNAME_SAYISI :"+count);
		prepareIhtarnameDosyasi(hobimOutput);
		oMap.put("KK_IHTARNAME_COUNT", count);
		oMap.put("RESPONSE", "2");
		return oMap;
	}
	
	@GraymoundService("BNSPR_HOBIM_NOTER_KMH_IHTAR_RAPOR")
    public static GMMap hobimNoterKMHIhtarReport(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap hobimOutput = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		int count = 0;
        try {
        	String func = "{? = call pkg_genel_pr.bankamiz_adres}";
			iMap.put("BANKA_ADRES", String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, new Object[] {})).replaceAll("\n", " "));
        	//musteri listesini don
            for (int i = 0; i < iMap.getSize("MUSTERI_LIST"); i++) {
            	// musterinin birden fazla kredisi varsa bunlari toparla
                for (int j = 0; j < iMap.getSize("KREDI_LIST"); j++) {
                	//birden fazla kmh varsa her kayit ard arda gelmelidir bular hobim tafafinda tek bir ihtarnamde basilmlidir
                    if (iMap.getString("MUSTERI_LIST", i, "MUSTERI_NO").equals(iMap.getString("KREDI_LIST", j, "MUSTERI_NO"))) {
                    	hobimOutput.put("KMH_IHTARNAME",count,"TC_KIMLIK_NO", iMap.getString("MUSTERI_LIST", i, "TC_KIMLIK_NO"));
						hobimOutput.put("KMH_IHTARNAME",count,"AD_SOYAD", iMap.getString("MUSTERI_LIST", i, "AD_SOYAD"));
						hobimOutput.put("KMH_IHTARNAME",count,"ADRES", iMap.getString("MUSTERI_LIST", i, "ADRES"));
						hobimOutput.put("KMH_IHTARNAME",count,"ADRES_ILCE", iMap.getString("MUSTERI_LIST", i, "ADRES_ILCE"));
						hobimOutput.put("KMH_IHTARNAME",count,"ADRES_IL", iMap.getString("MUSTERI_LIST", i, "ADRES_IL"));
						hobimOutput.put("KMH_IHTARNAME",count,"TARIH", sdf.format(new java.util.Date()));
						hobimOutput.put("KMH_IHTARNAME",count,"BANKA_ADRES", iMap.getString("BANKA_ADRES"));
						hobimOutput.put("KMH_IHTARNAME",count,"MUSTERI_TOPLAM_BORC", iMap.getString("MUSTERI_LIST", i, "TOPLAM_BORC"));
						hobimOutput.put("KMH_IHTARNAME",count, "MUSTERI_NO", iMap.getString("KREDI_LIST",j, "MUSTERI_NO"));
						hobimOutput.put("KMH_IHTARNAME",count, "BASVURU_NO", iMap.getString("KREDI_LIST",j, "BASVURU_NO"));
						hobimOutput.put("KMH_IHTARNAME",count, "BAGLI_HESAP_NO", iMap.getString("KREDI_LIST",j, "BAGLI_HESAP_NO"));
						hobimOutput.put("KMH_IHTARNAME",count, "IBAN", iMap.getString("KREDI_LIST",j, "IBAN"));
						hobimOutput.put("KMH_IHTARNAME",count, "KULLANDIRIM_TARIH", iMap.getString("KREDI_LIST",j, "KULLANDIRIM_TARIH"));
						hobimOutput.put("KMH_IHTARNAME",count, "KULLANDIRIM_TUTAR", iMap.getString("KREDI_LIST",j, "KULLANDIRIM_TUTAR"));
						hobimOutput.put("KMH_IHTARNAME",count, "FAIZ_ORAN", iMap.getString("KREDI_LIST",j, "FAIZ_ORAN"));
						hobimOutput.put("KMH_IHTARNAME",count, "YILLIK_FAIZ_ORAN", iMap.getString("KREDI_LIST",j, "YILLIK_FAIZ_ORAN"));
						hobimOutput.put("KMH_IHTARNAME",count, "TEMERRUT_ORAN", iMap.getString("KREDI_LIST",j, "TEMERRUT_ORAN"));
						hobimOutput.put("KMH_IHTARNAME",count, "TAKSIT_TUTAR", iMap.getString("KREDI_LIST",j, "TAKSIT_TUTAR"));
						hobimOutput.put("KMH_IHTARNAME",count, "GECIKMIS_TAKSIT_SAYI", iMap.getString("KREDI_LIST",j, "GECIKMIS_TAKSIT_SAYI"));
						hobimOutput.put("KMH_IHTARNAME",count, "GECIKMIS_TAKSIT_TUTAR", iMap.getString("KREDI_LIST",j, "GECIKMIS_TAKSIT_TUTAR"));
						hobimOutput.put("KMH_IHTARNAME",count, "GECIKME_FAIZ_TUTAR", iMap.getString("KREDI_LIST",j, "GECIKME_FAIZ_TUTAR"));
						hobimOutput.put("KMH_IHTARNAME",count, "ODENMEMIS_TAKSIT_TOPLAM", iMap.getString("KREDI_LIST",j, "ODENMEMIS_TAKSIT_TOPLAM"));
						hobimOutput.put("KMH_IHTARNAME",count, "TOPLAM_BORC_TUTARI", iMap.getString("KREDI_LIST", j, "TOPLAM_BORC_TUTARI"));
						hobimOutput.put("KMH_IHTARNAME",count,"ANAPARA_TUTARI", iMap.getString("KREDI_LIST", j, "ANAPARA_TUTARI"));
						hobimOutput.put("KMH_IHTARNAME",count,"BSMV_TUTARI", iMap.getString("KREDI_LIST", j, "BSMV_TUTARI"));
						hobimOutput.put("KMH_IHTARNAME",count,"KKDF_TUTARI", iMap.getString("KREDI_LIST", j, "KKDF_TUTARI"));
						hobimOutput.put("KMH_IHTARNAME",count,"TOPLAM_BORC", iMap.getString("KREDI_LIST", j, "TOPLAM_BORC"));
						hobimOutput.put("KMH_IHTARNAME",count,"SORGU_NO", iMap.getString("KREDI_LIST", j, "SORGU_NO"));
						hobimOutput.put("KMH_IHTARNAME",count,"ADRES_IL_KOD", iMap.getString("MUSTERI_LIST", i, "ADRES_IL_KOD"));
						hobimOutput.put("KMH_IHTARNAME",count,"ADRES_ILCE_KOD", iMap.getString("MUSTERI_LIST", i, "ADRES_ILCE_KOD"));
						//BT-7989
						hobimOutput.put("KMH_IHTARNAME",count, "IHTAR_MASRAF", iMap.getString("MUSTERI_LIST", i, "IHTAR_MASRAF"));
						//logger.info("Ihtarname Masraf KMH : " + iMap.getString("MUSTERI_LIST", i, "IHTAR_MASRAF"));
						count++;
                    }
                }
            }

        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    	logger.info("--------------------------------------------hobimNoterKMHIhtarReport");
		logger.info("KMH_IHTARNAME_SAYISI :"+count);
        prepareIhtarnameDosyasi(hobimOutput);
        oMap.put("KMH_IHTARNAME_COUNT", count);
		oMap.put("RESPONSE", "2");
		return oMap;
    }
	
	
	@GraymoundService("BNSPR_HOBIM_BIREYSEL_IHTARNAME_SORGULA")
	public static GMMap bireyselIhtarnameSorgula(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?)}";
			String maxGun =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "HOBIM_BIREYSEL_IHTARNAME", BnsprType.STRING, "GECIKME_GUN_SAYISI_MAX"));
			String minGun =  null; //String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "HOBIM_BIREYSEL_IHTARNAME", BnsprType.STRING, "GECIKME_GUN_SAYISI_MIN"));
			String tipAPS =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "HOBIM_BIREYSEL_IHTARNAME", BnsprType.STRING, "TIP_APS"));
			String tipNoter =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "HOBIM_BIREYSEL_IHTARNAME", BnsprType.STRING, "TIP_NOTER"));
			/*if(!NumberUtils.isNumber(minGun)){
				throw new GMRuntimeException(0, "Min gecikme gun sayisi gecerli degil");
			}*/
			BigDecimal bmaxgun = null;
			BigDecimal bmingun = null;
			if(!StringUtils.isBlank(maxGun) && !"null".equalsIgnoreCase(maxGun)){
				bmaxgun = new BigDecimal(maxGun);
			}
			if(!StringUtils.isBlank(minGun) && !"null".equalsIgnoreCase(minGun)){
				bmingun = new BigDecimal(minGun);
			}
			/*else{
				throw new GMRuntimeException(0, "Min gecikme gun sayisi gecerli degil");
			}*/
			iMap.put("GECIKME_GUN_SAYISI_UST", bmaxgun);
			iMap.put("GECIKME_GUN_SAYISI_ALT", bmingun);
			boolean aps = "E".equals(tipAPS)? true : false;
			iMap.put("APS_IHTAR", aps);
			boolean noter = "E".equals(tipNoter)? true : false;
			iMap.put("NOTER_IHTAR", noter);
			logger.info("GECIKME_GUN_SAYISI_ALT : "+minGun);
			logger.info("GECIKME_GUN_SAYISI_UST : "+maxGun);
			logger.info("APS_IHTAR : "+aps);
			logger.info("NOTER_IHTAR : "+noter);
			
			GMMap tmpMap = new GMMap();
			tmpMap = GMServiceExecuter.call("BNSPR_QRY3295_QUERY_IHTAR", iMap);
			BigDecimal sorguNo = tmpMap.getBigDecimal("SORGU_NO");
			
			logger.info("----------------------------- bireyselIhtarnameSorgula");
			logger.info("----------------------------- SORGU_NO :"+sorguNo);
			logger.info("----------------------------- SORGU_KAYIT_SAYISI :"+tmpMap.getSize("TABLE_DATA"));
			//SORGU_NO
			//TABLE_DATA
			tmpMap.put("CHECKED", true);
			tmpMap = GMServiceExecuter.call("BNSPR_QRY3295_SELECT_ALL", tmpMap);
			tmpMap.put("SORGU_NO", sorguNo);
			oMap.putAll(GMServiceExecuter.call("BNSPR_HOBIM_CREATE_BIREYSEL_IHTARNAME", tmpMap));
			
			oMap.put("PARAMETRE", "HOBIM_IHTAR_MAIL");
            String mailTo = (String) GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", oMap).get("DEGER");
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            Date bankDate = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH");
            
			sendMail("HOBIM Bireysel Ihtarname Datasi Gonderimi", dateFormat.format(bankDate) + " tarihi icin " + tmpMap.getSize("TABLE_DATA") + " adet bireysel ihtarname datasi gonderilmistir.", mailTo);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_HOBIM_KMH_IHTARNAME_SORGULA")
	public static GMMap kmhIhtarnameSorgula(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?)}";
			String maxGun =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "HOBIM_KMH_IHTARNAME", BnsprType.STRING, "GECIKME_GUN_SAYISI_MAX"));
			String minGun =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "HOBIM_KMH_IHTARNAME", BnsprType.STRING, "GECIKME_GUN_SAYISI_MIN"));
			String tipAPS =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "HOBIM_KMH_IHTARNAME", BnsprType.STRING, "TIP_APS"));
			String tipNoter =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "HOBIM_KMH_IHTARNAME", BnsprType.STRING, "TIP_NOTER"));
			if(!NumberUtils.isNumber(minGun)){
				throw new GMRuntimeException(0, "Min gecikme gun sayisi gecerli degil");
			}
			BigDecimal bmaxgun = null;
			BigDecimal bmingun = null;
			if(!StringUtils.isBlank(maxGun) && !"null".equalsIgnoreCase(maxGun)){
				bmaxgun = new BigDecimal(maxGun);
			}
			if(!StringUtils.isBlank(minGun) && !"null".equalsIgnoreCase(minGun)){
				bmingun = new BigDecimal(minGun);
			}else{
				throw new GMRuntimeException(0, "Min gecikme gun sayisi gecerli degil");
			}
			iMap.put("GECIKME_GUN_SAYISI_UST", bmaxgun);
			iMap.put("GECIKME_GUN_SAYISI_ALT", bmingun);
			boolean aps = "E".equals(tipAPS)? true : false;
			iMap.put("APS_IHTAR", aps);
			boolean noter = "E".equals(tipNoter)? true : false;
			iMap.put("NOTER_IHTAR", noter);
			logger.info("GECIKME_GUN_SAYISI_ALT : "+minGun);
			logger.info("GECIKME_GUN_SAYISI_UST : "+maxGun);
			logger.info("APS_IHTAR : "+aps);
			logger.info("NOTER_IHTAR : "+noter);
			
			GMMap tmpMap = new GMMap();
			tmpMap = GMServiceExecuter.call("BNSPR_QRY3296_QUERY_IHTAR", iMap);
			BigDecimal sorguNo = tmpMap.getBigDecimal("SORGU_NO");
			
			logger.info("----------------------------- kmhIhtarnameSorgula");
			logger.info("----------------------------- SORGU_NO :"+sorguNo);
			logger.info("----------------------------- SORGU_KAYIT_SAYISI :"+tmpMap.getSize("TABLE_DATA"));
			//SORGU_NO
			//TABLE_DATA
			tmpMap.put("CHECKED", true);
			tmpMap = GMServiceExecuter.call("BNSPR_QRY3296_SELECT_ALL", tmpMap);
			tmpMap.put("SORGU_NO", sorguNo);
			oMap.putAll(GMServiceExecuter.call("BNSPR_HOBIM_CREATE_KMH_IHTARNAME", tmpMap));
			
			oMap.put("PARAMETRE", "HOBIM_IHTAR_MAIL");
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
			Date bankDate = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH");
            String mailTo = (String) GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", oMap).get("DEGER");

            sendMail("HOBIM KMH Ihtarname Datasi Gonderimi", dateFormat.format(bankDate) + " tarihi icin " + tmpMap.getSize("TABLE_DATA") + " adet KMH ihtarname datasi gonderilmistir.", mailTo);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_HOBIM_CREATE_BIREYSEL_IHTARNAME")
    public static GMMap createBireyselIhtarname(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        ResultSet rSet2 = null;
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        GMMap oMap = new GMMap();
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            String tableName = "TABLE_DATA";
            String serviceName = "BNSPR_KPS_GET_ADDRESS_INFO";
            for (int i = 0; i < iMap.getSize(tableName); i++) {
                iMap.put("TCKN", iMap.getString(tableName, i, "TC_KIMLIK_NO"));
                logger.info("------------ createBireyselIhtarname - TCKN: " + iMap.getString("TCKN") + " icin kps get address info yapilacak..");
                BirihtarnameMusteriLog birihtarnameMusteriLog =
                    (BirihtarnameMusteriLog) session.createCriteria(BirihtarnameMusteriLog.class).add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal(tableName, i, "MUSTERI_NO")))
                        .add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).uniqueResult();
                if (iMap.getBoolean(tableName, i, "YAZDIR")) {
                	if(!StringUtils.isEmpty(iMap.getString("TCKN"))){
                		iMap.put("ADDRESS_LOG_ID", GMServiceExecuter.call(serviceName, iMap).getString("LOG_ID"));
                		birihtarnameMusteriLog.setApsSorguId(iMap.getBigDecimal("ADDRESS_LOG_ID"));
                	}
                    birihtarnameMusteriLog.setIhtarnameEh("E");
                } else {
                    birihtarnameMusteriLog.setIhtarnameEh("H");
                }
                session.saveOrUpdate(birihtarnameMusteriLog);
            }
            logger.info("------------------------------------- createBireyselIhtarname - kps get address info tamamlandi.");
            BirihtarnameSorguLog birihtarnameSorguLog = (BirihtarnameSorguLog)session.createCriteria(BirihtarnameSorguLog.class)
                    .add(Restrictions.eq("sorguNo", iMap.getBigDecimal("SORGU_NO"))).uniqueResult();
            birihtarnameSorguLog.setOlusturTarih(new java.util.Date());
            session.saveOrUpdate(birihtarnameSorguLog);
            session.flush();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_RC3295.ihtarname_olustur(?,?,?)}");
            stmt.setBigDecimal(1, iMap.getBigDecimal("SORGU_NO"));
            stmt.registerOutParameter(2, -10);
            stmt.registerOutParameter(3, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(2);
            rSet2 = (ResultSet) stmt.getObject(3);

            tableName = "MUSTERI_LIST";
            int row = 0;
            
            String il = null;
			String ilce = null;
			String ilKod = null;
			String ilceKod = null;
			boolean addressTaken = false;
            
            while (rSet.next()) {
            	String adress = rSet.getString("ADRES");
            	ResultSet addressSet = null;
            	
				il = null;
				ilce = null;
				ilKod = null;
				ilceKod = null;
				addressTaken = false;
				
            	// APS den adres gelmediyse extre adresini kullaniyoruz
				if (adress == null || adress.contains("musteri adres sorgusu bulunamadi")) {
					stmt = conn.prepareCall("{call PKG_RC3295.get_musteri_extre_adresi(?,?)}");
					stmt.setBigDecimal(1, rSet.getBigDecimal("MUSTERI_NO"));
					stmt.registerOutParameter(2, -10);
					stmt.execute();
					addressSet = (ResultSet) stmt.getObject(2);
					addressSet.next();
					stmt.clearParameters();
					
					adress = addressSet.getString("ADRES");
            		il = addressSet.getString("IL_ADI");
            		ilce = addressSet.getString("ILCE_ADI");
            		ilKod = addressSet.getString("KOD");
            		ilceKod = addressSet.getString("ILCE_KOD");
				}
				else
				{
	            	GnlApsLog alog = (GnlApsLog) session.get(GnlApsLog.class, rSet.getBigDecimal("APS_SORGU_ID"));
	            	if(alog != null && StringUtils.isNotEmpty(alog.getHataKod()))
	            	{
	            		if("0".equals(alog.getHataKod())){
	            			addressTaken = true;
	            			if(StringUtils.isNotEmpty(alog.getIl())){
	            				il = alog.getIl();
	            			}
	            			if(StringUtils.isNotEmpty(alog.getIlce())){
	            				ilce = alog.getIlce();
	            			}
	            			if(StringUtils.isNotEmpty(alog.getIlKod())){
	            				ilKod = alog.getIlKod();
	            			}
	            			if(StringUtils.isNotEmpty(alog.getIlceKod())){
	            				ilceKod = alog.getIlceKod();
	            			}
	            		}
	            	}
	            	if(addressTaken == false)
	            	{
	            		GnlMusteriAps mAlog = (GnlMusteriAps) session.get(GnlMusteriAps.class, rSet.getBigDecimal("MUSTERI_NO"));
	            		if(mAlog != null){
	            			if(StringUtils.isNotEmpty(mAlog.getApsIl())){
	            				il = mAlog.getApsIl();
	            			}
	            			if(StringUtils.isNotEmpty(mAlog.getApsIlce())){
	            				ilce = mAlog.getApsIlce();
	            			}
	            			if(mAlog.getApsIlKodu() != null){
	            				ilKod = mAlog.getApsIlKodu().toString();
	            			}
		            		if(mAlog.getApsIlceKodu() != null){
		            			ilceKod = mAlog.getApsIlceKodu().toString();
		            		}
	            		}
	            	}
				}
				
                oMap.put(tableName, row, "SORGU_NO", rSet.getObject("SORGU_NO"));
                oMap.put(tableName, row, "REC_OWNER", rSet.getObject("REC_OWNER"));
                oMap.put(tableName, row, "REC_DATE", rSet.getObject("REC_DATE"));
                oMap.put(tableName, row, "TC_KIMLIK_NO", rSet.getObject("TC_KIMLIK_NO"));
                oMap.put(tableName, row, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
                oMap.put(tableName, row, "AD_SOYAD", rSet.getObject("AD_SOYAD"));
                oMap.put(tableName, row, "IHTARNAME_EH", rSet.getObject("IHTARNAME_EH"));
                oMap.put(tableName, row, "ADRES", adress);
                oMap.put(tableName, row, "ADRES_ILCE", ilce);
                oMap.put(tableName, row, "ADRES_IL", il);
                oMap.put(tableName, row, "APS_SORGU_ID", rSet.getObject("APS_SORGU_ID"));
                oMap.put(tableName, row, "KREDI_BAKIYE", rSet.getObject("KREDI_BAKIYE"));
                oMap.put(tableName, row, "GECIKME_TUTAR", rSet.getObject("GECIKME_TUTAR"));
                oMap.put(tableName, row, "GECIKME_TARIH", rSet.getObject("GECIKME_TARIH"));
                oMap.put(tableName, row, "GECIKME_GUN", rSet.getObject("GECIKME_GUN"));
                oMap.put(tableName, row, "TOPLAM_BORC",  ConsumerLoanCommonServices.formatCurrency(rSet.getBigDecimal("TOPLAM_BORC")));
                oMap.put(tableName, row, "IHTAR_MASRAF",  ConsumerLoanCommonServices.formatCurrency(rSet.getBigDecimal("IHTAR_MASRAF")));
                oMap.put(tableName, row, "ADRES_IL_KOD", ilKod);
                oMap.put(tableName, row, "ADRES_ILCE_KOD", ilceKod);
                row++;
            }
            logger.info("------------------------------------- createBireyselIhtarname");
            logger.info("MUSTERI_SAYISI :"+row);
            
            tableName = "KREDI_LIST";
            row = 0;
            while (rSet2.next()) {
                oMap.put(tableName, row, "SORGU_NO", rSet2.getObject("SORGU_NO"));
                oMap.put(tableName, row, "REC_OWNER", rSet2.getObject("REC_OWNER"));
                oMap.put(tableName, row, "REC_DATE", rSet2.getObject("REC_DATE"));
                oMap.put(tableName, row, "MUSTERI_NO", rSet2.getString("MUSTERI_NO"));
                oMap.put(tableName, row, "BASVURU_NO", rSet2.getString("BASVURU_NO")); 
                oMap.put(tableName, row, "BAGLI_HESAP_NO", rSet2.getString("BAGLI_HESAP_NO"));
                oMap.put(tableName, row, "IBAN", rSet2.getString("IBAN"));
                oMap.put(tableName, row, "KULLANDIRIM_TARIH", StringUtils.isBlank(rSet2.getString("KULLANDIRIM_TARIH")) ? "" : sdf.format(rSet2.getDate("KULLANDIRIM_TARIH")));
                oMap.put(tableName, row, "KULLANDIRIM_TUTAR",  ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("KULLANDIRIM_TUTAR")));
                oMap.put(tableName, row, "FAIZ_ORAN",  ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("FAIZ_ORAN")));
                oMap.put(tableName, row, "YILLIK_FAIZ_ORAN", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("YILLIK_FAIZ_ORAN")));
                oMap.put(tableName, row, "TEMERRUT_ORAN",  ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("TEMERRUT_ORAN")));
                oMap.put(tableName, row, "TAKSIT_TUTAR",  ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("TAKSIT_TUTAR")));
                oMap.put(tableName, row, "ODENMEMIS_TAKSIT_SAYI",  ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("ODENMEMIS_TAKSIT_SAYI")));
                oMap.put(tableName, row, "ODENMEMIS_TAKSIT_TUTAR",  ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("ODENMEMIS_TAKSIT_TUTAR")));
                oMap.put(tableName, row, "GECIKME_FAIZ_TUTAR",  ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("GECIKME_FAIZ_TUTAR")));
                oMap.put(tableName, row, "ODENMEMIS_TAKSIT_TOPLAM",  ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("GECIKMIS_TAKSIT_TUTAR").add(rSet2.getBigDecimal("GECIKME_FAIZ_TUTAR"))));
                oMap.put(tableName, row, "GECIKMIS_TUTAR", rSet2.getObject("GECIKMIS_TUTAR"));
                oMap.put(tableName, row, "TOPLAM_BORC", rSet2.getObject("TOPLAM_BORC"));
                oMap.put(tableName, row, "GECIKME_TARIH", rSet2.getObject("GECIKME_TARIH"));
                oMap.put(tableName, row, "GECIKME_GUN", rSet2.getObject("GECIKME_GUN"));
                oMap.put(tableName, row, "TC_KIMLIK_NO", rSet2.getObject("TC_KIMLIK_NO"));
                oMap.put(tableName, row, "GECIKMIS_TAKSIT_SAYI", rSet2.getBigDecimal("GECIKMIS_TAKSIT_SAYI"));
                oMap.put(tableName, row, "GECIKMIS_TAKSIT_TUTAR", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("GECIKMIS_TAKSIT_TUTAR")));
                oMap.put(tableName, row, "DIGER_BORC", rSet2.getBigDecimal("DIGER_BORC"));               
                
                try {
                	oMap.put(tableName, row, "TOPLAM_BORC_TUTARI",
                    		ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("DIGER_BORC") == null ? rSet2.getBigDecimal("TOPLAM_BORC") : rSet2.getBigDecimal("TOPLAM_BORC").add(rSet2.getBigDecimal("DIGER_BORC"))));
				}
				catch (Exception e) {
					oMap.put(tableName, row, "TOPLAM_BORC_TUTARI", "0");
					logger.error(rSet2.getString("MUSTERI_NO") + " no'lu musteri TOPLAM_BORC_TUTARI hesaplanirken hata alindi", e);
				}
                
                row++;
            }
            logger.info("KREDI_SAYISI :"+row);
            stmt.close();
           
            oMap.put("TIP", iMap.getString("TIP"));
            oMap.putAll(GMServiceExecuter.call("BNSPR_HOBIM_NOTER_IHTAR_RAPOR", oMap));
      
            
            return oMap;
        } catch (Exception e) {
        	logger.error("createBireyselIhtarname islemi esnasinda hata alindi !!", e);
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(rSet2);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
	@GraymoundService("BNSPR_HOBIM_CREATE_KMH_IHTARNAME")
    public static GMMap createKMHIhtarname(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        ResultSet rSet2 = null;
        SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
        GMMap oMap = new GMMap();
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            String tableName = "TABLE_DATA";
            String serviceName = "BNSPR_KPS_GET_ADDRESS_INFO";
            for (int i = 0; i < iMap.getSize(tableName); i++) {
                iMap.put("TCKN", iMap.getString(tableName, i, "TC_KIMLIK_NO"));
                logger.info("------------ createKMHIhtarname - TCKN: " + iMap.getString("TCKN") + " icin kps get address info yapilacak..");
                BirihtarnameMusteriLog birihtarnameMusteriLog =
                    (BirihtarnameMusteriLog) session.createCriteria(BirihtarnameMusteriLog.class).add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal(tableName, i, "MUSTERI_NO")))
                        .add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).uniqueResult();
                if (iMap.getBoolean(tableName, i, "YAZDIR")) {
                	if(!StringUtils.isEmpty(iMap.getString("TCKN"))){
                		iMap.put("ADDRESS_LOG_ID", GMServiceExecuter.call(serviceName, iMap).getString("LOG_ID"));
                		birihtarnameMusteriLog.setApsSorguId(iMap.getBigDecimal("ADDRESS_LOG_ID"));
                	}
                    birihtarnameMusteriLog.setIhtarnameEh("E");
                } else {
                    birihtarnameMusteriLog.setIhtarnameEh("H");
                }
        
                session.saveOrUpdate(birihtarnameMusteriLog);
                session.flush();
            }
            logger.info("------------------------------------- createKMHIhtarname - kps get address info tamamlandi.");
            BirihtarnameSorguLog birihtarnameSorguLog = (BirihtarnameSorguLog)session.createCriteria(BirihtarnameSorguLog.class)
                    .add(Restrictions.eq("sorguNo", iMap.getBigDecimal("SORGU_NO"))).uniqueResult();
            birihtarnameSorguLog.setOlusturTarih(new java.util.Date());
            session.saveOrUpdate(birihtarnameSorguLog);
            session.flush();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_RC3295.ihtarname_olustur(?,?,?)}");
            stmt.setBigDecimal(1, iMap.getBigDecimal("SORGU_NO"));
            stmt.registerOutParameter(2, -10);
            stmt.registerOutParameter(3, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(2);
            rSet2 = (ResultSet) stmt.getObject(3);
            stmt.clearParameters();

            tableName = "MUSTERI_LIST";
            int row = 0;
            
            String il = null;
			String ilce = null;
			String ilKod = null;
			String ilceKod = null;
			boolean addressTaken = false;
            
            while (rSet.next()) {
            	String custKpsAdress = rSet.getString("ADRES");
				ResultSet addressSet = null;

				il = null;
				ilce = null;
				ilKod = null;
				ilceKod = null;
				addressTaken = false;
				
            	// APS den adres gelmediyse extre adresini kullaniyoruz
				if (custKpsAdress == null || custKpsAdress.contains("musteri adres sorgusu bulunamadi")) {
					stmt = conn.prepareCall("{call PKG_RC3295.get_musteri_extre_adresi(?,?)}");
					stmt.setBigDecimal(1, rSet.getBigDecimal("MUSTERI_NO"));
					stmt.registerOutParameter(2, -10);
					stmt.execute();
					addressSet = (ResultSet) stmt.getObject(2);
					addressSet.next();
					stmt.clearParameters();
					
					custKpsAdress = addressSet.getString("ADRES");
            		il = addressSet.getString("IL_ADI");
            		ilce = addressSet.getString("ILCE_ADI");
            		ilKod = addressSet.getString("KOD");
            		ilceKod = addressSet.getString("ILCE_KOD");
				}
				else
				{
	            	GnlApsLog alog = (GnlApsLog) session.get(GnlApsLog.class, rSet.getBigDecimal("APS_SORGU_ID"));
	            	if(alog != null && StringUtils.isNotEmpty(alog.getHataKod()))
	            	{
	            		if("0".equals(alog.getHataKod())){
	            			addressTaken= true;
	            			if(StringUtils.isNotEmpty(alog.getIl())){
	            				il = alog.getIl();
	            			}
	            			if(StringUtils.isNotEmpty(alog.getIlce())){
	            				ilce = alog.getIlce();
	            			}
	            			if(StringUtils.isNotEmpty(alog.getIlKod())){
	            				ilKod = alog.getIlKod();
	            			}
	            			if(StringUtils.isNotEmpty(alog.getIlceKod())){
	            				ilceKod = alog.getIlceKod();
	            			}
	            		}
	            	}
	            	if(addressTaken == false)
	            	{
	            		GnlMusteriAps mAlog = (GnlMusteriAps) session.get(GnlMusteriAps.class, rSet.getBigDecimal("MUSTERI_NO"));
	            		if(mAlog != null){
	            			if(StringUtils.isNotEmpty(mAlog.getApsIl())){
	            				il = mAlog.getApsIl();
	            			}
	            			if(StringUtils.isNotEmpty(mAlog.getApsIlce())){
	            				ilce = mAlog.getApsIlce();
	            			}
	            			if(mAlog.getApsIlKodu() != null){
	            				ilKod = mAlog.getApsIlKodu().toString();
	            			}
		            		if(mAlog.getApsIlceKodu() != null){
		            			ilceKod = mAlog.getApsIlceKodu().toString();
		            		}
	            		}
	            	}
				}
				            	
                oMap.put(tableName, row, "SORGU_NO", rSet.getObject("SORGU_NO"));
                oMap.put(tableName, row, "REC_OWNER", rSet.getObject("REC_OWNER"));
                oMap.put(tableName, row, "REC_DATE", rSet.getObject("REC_DATE"));
                oMap.put(tableName, row, "TC_KIMLIK_NO", rSet.getObject("TC_KIMLIK_NO"));
                oMap.put(tableName, row, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
                oMap.put(tableName, row, "AD_SOYAD", rSet.getObject("AD_SOYAD"));
                oMap.put(tableName, row, "IHTARNAME_EH", rSet.getObject("IHTARNAME_EH"));
                oMap.put(tableName, row, "ADRES", custKpsAdress);
                oMap.put(tableName, row, "ADRES_ILCE", ilce);
                oMap.put(tableName, row, "ADRES_IL", il);
                oMap.put(tableName, row, "APS_SORGU_ID", rSet.getObject("APS_SORGU_ID"));
                oMap.put(tableName, row, "KREDI_BAKIYE", rSet.getObject("KREDI_BAKIYE"));
                oMap.put(tableName, row, "GECIKME_TUTAR", rSet.getObject("GECIKME_TUTAR"));
                oMap.put(tableName, row, "GECIKME_TARIH", rSet.getObject("GECIKME_TARIH"));
                oMap.put(tableName, row, "GECIKME_GUN", rSet.getObject("GECIKME_GUN"));
                oMap.put(tableName, row, "TOPLAM_BORC",  ConsumerLoanCommonServices.formatCurrency(rSet.getBigDecimal("TOPLAM_BORC")));
                oMap.put(tableName, row, "IHTAR_MASRAF",  ConsumerLoanCommonServices.formatCurrency(rSet.getBigDecimal("IHTAR_MASRAF")));
                oMap.put(tableName, row, "ADRES_IL_KOD", ilKod);
                oMap.put(tableName, row, "ADRES_ILCE_KOD", ilceKod);
                row++;
            }
            logger.info("------------------------------------- createKMHIhtarname");
            logger.info("MUSTERI_SAYISI :"+row);
            tableName = "KREDI_LIST";
            row = 0;
            while (rSet2.next()) {
                oMap.put(tableName, row, "SORGU_NO", rSet2.getObject("SORGU_NO"));
                oMap.put(tableName, row, "REC_OWNER", rSet2.getObject("REC_OWNER"));
                oMap.put(tableName, row, "REC_DATE", rSet2.getObject("REC_DATE"));
                oMap.put(tableName, row, "MUSTERI_NO", rSet2.getString("MUSTERI_NO"));
                oMap.put(tableName, row, "BASVURU_NO", rSet2.getString("BASVURU_NO")); 
                oMap.put(tableName, row, "BAGLI_HESAP_NO", rSet2.getString("HESAP_NO"));
                oMap.put(tableName, row, "IBAN", rSet2.getString("IBAN"));
                oMap.put(tableName, row, "KULLANDIRIM_TARIH", StringUtils.isBlank(rSet2.getString("KULLANDIRIM_TARIH")) ? "" : sdf.format(rSet2.getDate("KULLANDIRIM_TARIH")));
                oMap.put(tableName, row, "KULLANDIRIM_TUTAR",  ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("KULLANDIRIM_TUTAR")));
                oMap.put(tableName, row, "FAIZ_ORAN",  ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("FAIZ_ORAN")));
                oMap.put(tableName, row, "YILLIK_FAIZ_ORAN", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("YILLIK_FAIZ_ORAN")));
                oMap.put(tableName, row, "TOPLAM_BORC", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("TOPLAM_BORC")));
                oMap.put(tableName, row, "GECIKME_TARIH", rSet2.getObject("GECIKME_TARIH"));
                oMap.put(tableName, row, "GECIKME_GUN", rSet2.getObject("GECIKME_GUN"));
                oMap.put(tableName, row, "TC_KIMLIK_NO", rSet2.getObject("TC_KIMLIK_NO"));
                oMap.put(tableName, row, "DIGER_BORC", rSet2.getBigDecimal("DIGER_BORC"));
                oMap.put(tableName, row, "ANAPARA_TUTARI",ConsumerLoanCommonServices.formatCurrency( rSet2.getBigDecimal("ANAPARA_TUTARI")));
                oMap.put(tableName, row, "GECIKME_FAIZ_TUTAR", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("GECIKME_FAIZ_TUTAR")));
                oMap.put(tableName, row, "KKDF_TUTARI", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("KKDF_TUTARI")));
                oMap.put(tableName, row, "BSMV_TUTARI", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("BSMV_TUTARI")));
                oMap.put(tableName, row, "TOPLAM_BORC_TUTARI",
                		ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("DIGER_BORC") == null ? rSet2.getBigDecimal("TOPLAM_BORC") : rSet2.getBigDecimal("TOPLAM_BORC").add(rSet2.getBigDecimal("DIGER_BORC"))));
                oMap.put(tableName, row, "GECIKMIS_TAKSIT_TUTAR", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("GECIKMIS_TAKSIT_TUTAR")));
                row++;
            }
            logger.info("------------------------------------- createKMHIhtarname");
            logger.info("KMH_SAYISI :"+row);
            stmt.close();
            oMap.put("TIP", iMap.getString("TIP"));
            oMap.putAll(GMServiceExecuter.call("BNSPR_HOBIM_NOTER_KMH_IHTAR_RAPOR", oMap));
            return oMap;
        } catch (Exception e) {
        	logger.error("createKMHIhtarname islemi esnasinda hata alindi !!", e);
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(rSet2);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
	@GraymoundService("BNSPR_HOBIM_KK_IHTARNAME_SORGULA")
	public static GMMap kkIhtarnameSorgula(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call Pkg_parametre.ParamTextAl (?,?)}";
			String maxGun =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "HOBIM_KK_IHTARNAME", BnsprType.STRING, "GECIKME_GUN_SAYISI_MAX"));
			String minGun =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "HOBIM_KK_IHTARNAME", BnsprType.STRING, "GECIKME_GUN_SAYISI_MIN"));
			String tipAPS =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "HOBIM_KK_IHTARNAME", BnsprType.STRING, "TIP_APS"));
			String tipNoter =  String.valueOf(DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.STRING, "HOBIM_KK_IHTARNAME", BnsprType.STRING, "TIP_NOTER"));
			if(!NumberUtils.isNumber(minGun)){
				throw new GMRuntimeException(0, "Min gecikme gun sayisi gecerli degil");
			}
			BigDecimal bmaxgun = null;
			BigDecimal bmingun = null;
			if(!StringUtils.isBlank(maxGun) && !"null".equalsIgnoreCase(maxGun)){
				bmaxgun = new BigDecimal(maxGun);
			}
			if(!StringUtils.isBlank(minGun) && !"null".equalsIgnoreCase(minGun)){
				bmingun = new BigDecimal(minGun);
			}else{
				throw new GMRuntimeException(0, "Min gecikme gun sayisi gecerli degil");
			}
			iMap.put("GECIKME_GUN_SAYISI_UST", bmaxgun);
			iMap.put("GECIKME_GUN_SAYISI_ALT", bmingun);
			boolean aps = "E".equals(tipAPS)? true : false;
			iMap.put("APS_IHTAR", aps);
			boolean noter = "E".equals(tipNoter)? true : false;
			iMap.put("NOTER_IHTAR", noter);
			logger.info("GECIKME_GUN_SAYISI_ALT : "+minGun);
			logger.info("GECIKME_GUN_SAYISI_UST : "+maxGun);
			logger.info("APS_IHTAR : "+aps);
			logger.info("NOTER_IHTAR : "+noter);
			
			GMMap tmpMap = new GMMap();
			tmpMap = GMServiceExecuter.call("BNSPR_QRY3297_QUERY_IHTAR", iMap);
			BigDecimal sorguNo = tmpMap.getBigDecimal("SORGU_NO");
			
			logger.info("----------------------------- kkIhtarnameSorgula");
			logger.info("----------------------------- SORGU_NO :"+sorguNo);
			logger.info("----------------------------- SORGU_KAYIT_SAYISI :"+tmpMap.getSize("TABLE_DATA"));
			//SORGU_NO
			//TABLE_DATA
			tmpMap.put("CHECKED", true);
			tmpMap = GMServiceExecuter.call("BNSPR_QRY3297_SELECT_ALL", tmpMap);
			tmpMap.put("SORGU_NO", sorguNo);
			oMap.putAll(GMServiceExecuter.call("BNSPR_HOBIM_CREATE_KK_IHTARNAME", tmpMap));	
			
			oMap.put("PARAMETRE", "HOBIM_IHTAR_MAIL");
			Date bankDate = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH");
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
            String mailTo = (String) GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", oMap).get("DEGER");
            
			sendMail("HOBIM KK Ihtarname Datasi Gonderimi", dateFormat.format(bankDate) + " tarihi icin " + tmpMap.getSize("TABLE_DATA") + " adet KK ihtarname datasi gonderilmistir.", mailTo);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_HOBIM_CREATE_KK_IHTARNAME")
	public static GMMap createKKIhtarname(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "TABLE_DATA";
			String serviceName = "BNSPR_KPS_GET_ADDRESS_INFO";
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				iMap.put("TCKN", iMap.getString(tableName, i, "TC_KIMLIK_NO"));
				BirihtarnameMusteriLog birihtarnameMusteriLog = (BirihtarnameMusteriLog) session.createCriteria(BirihtarnameMusteriLog.class).add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal(tableName, i, "MUSTERI_NO"))).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).uniqueResult();
				if (iMap.getBoolean(tableName, i, "YAZDIR")) {
                	if(!StringUtils.isEmpty(iMap.getString("TCKN"))){
                		iMap.put("ADDRESS_LOG_ID", GMServiceExecuter.call(serviceName, iMap).getString("LOG_ID"));
                		birihtarnameMusteriLog.setApsSorguId(iMap.getBigDecimal("ADDRESS_LOG_ID"));
                	}
                    birihtarnameMusteriLog.setIhtarnameEh("E");
                }
				else {
					birihtarnameMusteriLog.setIhtarnameEh("H");
				}
				session.saveOrUpdate(birihtarnameMusteriLog);
			}
			BirihtarnameSorguLog birihtarnameSorguLog = (BirihtarnameSorguLog) session.createCriteria(BirihtarnameSorguLog.class).add(Restrictions.eq("sorguNo", iMap.getBigDecimal("SORGU_NO"))).uniqueResult();
			birihtarnameSorguLog.setOlusturTarih(new java.util.Date());
			session.saveOrUpdate(birihtarnameSorguLog);
			session.flush();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC3297.ihtarname_olustur(?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("SORGU_NO"));
			stmt.registerOutParameter(2, -10);
			stmt.registerOutParameter(3, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(2);
			rSet2 = (ResultSet) stmt.getObject(3);

			tableName = "MUSTERI_LIST";
			int row = 0;
			
			String il = null;
			String ilce = null;
			String ilKod = null;
			String ilceKod = null;
			boolean addressTaken = false;
			
			while (rSet.next()) {
				String adress = rSet.getString("ADRES");
            	ResultSet addressSet = null;
            	
				il = null;
				ilce = null;
				ilKod = null;
				ilceKod = null;
				addressTaken = false;
				
            	// APS den adres gelmediyse extre adresini kullaniyoruz
				if (adress == null || adress.contains("musteri adres sorgusu bulunamadi")) {
					stmt = conn.prepareCall("{call PKG_RC3295.get_musteri_extre_adresi(?,?)}");
					stmt.setBigDecimal(1, rSet.getBigDecimal("MUSTERI_NO"));
					stmt.registerOutParameter(2, -10);
					stmt.execute();
					addressSet = (ResultSet) stmt.getObject(2);
					addressSet.next();
					stmt.clearParameters();
					
					adress = addressSet.getString("ADRES");
            		il = addressSet.getString("IL_ADI");
            		ilce = addressSet.getString("ILCE_ADI");
            		ilKod = addressSet.getString("KOD");
            		ilceKod = addressSet.getString("ILCE_KOD");
				}
				else
				{
	            	GnlApsLog alog = (GnlApsLog) session.get(GnlApsLog.class, rSet.getBigDecimal("APS_SORGU_ID"));
	            	if(alog != null && StringUtils.isNotEmpty(alog.getHataKod()))
	            	{
	            		if("0".equals(alog.getHataKod())){
	            			addressTaken = true;
	            			if(StringUtils.isNotEmpty(alog.getIl())){
	            				il = alog.getIl();
	            			}
	            			if(StringUtils.isNotEmpty(alog.getIlce())){
	            				ilce = alog.getIlce();
	            			}
	            			if(StringUtils.isNotEmpty(alog.getIlKod())){
	            				ilKod = alog.getIlKod();
	            			}
	            			if(StringUtils.isNotEmpty(alog.getIlceKod())){
	            				ilceKod = alog.getIlceKod();
	            			}
	            		}
	            	}
	            	if(addressTaken == false)
	            	{
	            		GnlMusteriAps mAlog = (GnlMusteriAps) session.get(GnlMusteriAps.class, rSet.getBigDecimal("MUSTERI_NO"));
	            		if(mAlog != null){
	            			if(StringUtils.isNotEmpty(mAlog.getApsIl())){
	            				il = mAlog.getApsIl();
	            			}
	            			if(StringUtils.isNotEmpty(mAlog.getApsIlce())){
	            				ilce = mAlog.getApsIlce();
	            			}
	            			if(mAlog.getApsIlKodu() != null){
	            				ilKod = mAlog.getApsIlKodu().toString();
	            			}
		            		if(mAlog.getApsIlceKodu() != null){
		            			ilceKod = mAlog.getApsIlceKodu().toString();
		            		}
	            		}
	            	}
				}
            	
				oMap.put(tableName, row, "TC_KIMLIK_NO", rSet.getString("TC_KIMLIK_NO"));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
				oMap.put(tableName, row, "AD_SOYAD", rSet.getString("AD_SOYAD"));
				oMap.put(tableName, row, "ADRES", adress);
				oMap.put(tableName, row, "ADRES_ILCE", ilce);
				oMap.put(tableName, row, "ADRES_IL", il);
				oMap.put(tableName, row, "TOPLAM_BORC", ConsumerLoanCommonServices.formatCurrency(rSet.getBigDecimal("TOPLAM_BORC")));
				oMap.put(tableName, row, "SORGU_NO", rSet.getBigDecimal("SORGU_NO"));
				oMap.put(tableName, row, "ADRES_IL_KOD", ilKod);
				oMap.put(tableName, row, "ADRES_ILCE_KOD", ilceKod);
				row++;
			}

			tableName = "KREDI_LIST";
			row = 0;
			while (rSet2.next()) {
				oMap.put(tableName, row, "MUSTERI_NO", rSet2.getString("MUSTERI_NO"));
				// basvuru no alanina kartin son 4 hanesi yazildi.
				oMap.put(tableName, row, "KART_NO", StringUtils.leftPad(rSet2.getString("BASVURU_NO"), 4, "0"));
				oMap.put(tableName, row, "ASGARI_ODEME_TUTAR", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("ASGARI_ODEME_TUTAR")));
				oMap.put(tableName, row, "ANAPARA_TUTAR", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("ANAPARA_TUTARI")));
				oMap.put(tableName, row, "GECIKME_FAIZ_TUTAR", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("GECIKME_FAIZ_TUTAR")));
				oMap.put(tableName, row, "KKDF_TUTAR", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("KKDF_TUTARI")));
				oMap.put(tableName, row, "BSMV_TUTAR", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("BSMV_TUTARI")));
				oMap.put(tableName, row, "TOPLAM_BORC_TUTARI", ConsumerLoanCommonServices.formatCurrency(rSet2.getBigDecimal("TOPLAM_BORC")));
				oMap.put(tableName, row, "SORGU_NO", rSet2.getBigDecimal("SORGU_NO"));
				oMap.put(tableName, row, "IBAN", rSet2.getString("IBAN"));
				oMap.put(tableName, row, "BAGLI_HESAP_NO", rSet2.getString("BAGLI_HESAP_NO"));
				row++;
			}
			 logger.info("------------------------------------- createKKIhtarname");
	            logger.info("MUSTERI_SAYISI :"+row);
			stmt.close();
			oMap.putAll(GMServiceExecuter.call("BNSPR_HOBIM_KK_IHTAR_RAPOR", oMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static void addLineToFtm(Session session, GMMap iMap) throws Exception{
		try {
			FtmFileContent fp = new FtmFileContent();
			
			fp.setOid(iMap.getString("OID"));
			fp.setFtmProcessOid(iMap.getBigDecimal("FTM_PROCESS_ID"));
			fp.setLine(iMap.getString("LINE"));
			fp.setLineNumber(iMap.getBigDecimal("LINE_NUMBER"));
			session.save(fp);
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	private static BigDecimal getNextValueOfFTMProcessId() {
		Session session = DAOSession.getSession("BNSPRDal");
		return new BigDecimal(((Number) session.createSQLQuery("SELECT ftm.seq_ftm_process.nextval FROM dual").uniqueResult()).longValue());
	}
	
	private static void sendFileByFtm(String fileName, BigDecimal ftmProcessId, String ftmGlbParamCode) throws Exception {
		GMConnection connection = GMConnection.getConnection("FTM");
		
		GMMap ftmMap = new GMMap();
		ftmMap.put("KOD", ftmGlbParamCode);
		String ftmFileOid = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", ftmMap).getString("DEGER");
		
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			GMMap putMap = new GMMap();
			putMap.put("FILE_NAME", fileName);
			putMap.put("FILE_DEF_ID", ftmFileOid);
			putMap.put("PROCESS_ID", ftmProcessId);
			putMap.put("PROCESS_DATE", sdf.format(new Date()));

			connection.serviceCall("BNSPR_FTM_CREATE_AND_TRANSFER_FILE", putMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			connection.close();
		}
	}
	
	private static GMMap getLineFromFTM(long start, long end, BigDecimal ftmTransferId) throws Exception{
		try {
			String fetchQuery = String.format("SELECT FFC.LINE_NUMBER, FFC.LINE FROM FTM.FTM_FILE_CONTENT FFC " +
											  "WHERE FFC.FTM_PROCESS_OID = %s AND FFC.LINE_NUMBER >= %s AND FFC.LINE_NUMBER <= %s " +
											  "ORDER BY FFC.LINE_NUMBER", ftmTransferId, start, end);
			final String tableName = "FILE_LINE";
			
			return  DALUtil.getResults(fetchQuery, tableName);
		}
		catch (Exception e) {
			throw e;
		}
	}
	
	@GraymoundService("BNSPR_GET_HOBIM_IHTAR_DATA_FILE")
	public static GMMap getHobimDataFile(GMMap iMap){
		GMMap oMap = new GMMap();
		int start = 1;
		int interval = 100;
		String line = StringUtils.EMPTY;
		BigDecimal lineNumber = BigDecimal.ZERO;
		BigDecimal ftmProcId = BigDecimal.ZERO;
		boolean updateIhtarDate = true;
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			ftmProcId = iMap.getBigDecimal("PROCESS_ID");
			oMap = getLineFromFTM(start, start + interval, ftmProcId);
			String query = StringUtils.EMPTY;
			
			conn = DALUtil.getGMConnection();
			
			while (oMap.get("FILE_LINE") != null) {
				for (int i = 0; i < oMap.getSize("FILE_LINE"); i++) {
					lineNumber = oMap.getBigDecimal("FILE_LINE", i, "LINE_NUMBER");
					line = oMap.getString("FILE_LINE", i, "LINE");

					//first line contains header info
					if(lineNumber.equals(BigDecimal.ONE)){
						continue;
					}
					
					String[] segments = line.split("\\|");
					int cursor = 0;
					String barcodeId = segments[cursor++];
					String tckn = segments[cursor++];
					String custId = segments[cursor++];
					String creditType = segments[cursor++];
					String accountNo = segments[cursor++];
					String appNo = segments[cursor++];
					String crdCardNo = segments[cursor++];
					String ihtarDate = segments[cursor++];
					BigDecimal sorguNo = new BigDecimal(segments[cursor++]);
					
					oMap.put("SORGU_NO", sorguNo);
					oMap.put("IHTAR_TARIHI", dateFormat.parse(ihtarDate));
					oMap.put("MUSTERI_NO", custId);
					oMap.put("BASVURU_NO", "KK".equals(creditType) ? StringUtils.right(crdCardNo, 4) : appNo);
					oMap.put("BARKOD_NO", barcodeId);
					
					try {
						GMServiceExecuter.call("BNSPR_QRY3295_BARKOD_NO_GUNCELLE", oMap);
					}
					catch (Exception e) {
						logger.error("Barkod güncelleme servisinde hata alındı.", e);
					}
					
					if(("BIREYSEL".equals(creditType) || "KMH".equals(creditType)) && (updateIhtarDate)){
						GMServiceExecuter.call("BNSPR_QRY3295_IHTARNAME_TARIHI_GUNCELLE", oMap);
						updateIhtarDate = false;
					}else if("KK".equals(creditType) && (updateIhtarDate)){
						GMServiceExecuter.call("BNSPR_QRY3297_IHTARNAME_TARIHI_GUNCELLE", oMap);
						updateIhtarDate = false;
					}
					
					/* ihtarname masraf hesap acilis */
					BigDecimal basvuruNo = null;
					if(StringUtils.isNotEmpty(appNo) && StringUtils.isNumeric(appNo)){
						basvuruNo = new BigDecimal(appNo);
					}
					
					BigDecimal musteriNo = null;
					if(StringUtils.isNotEmpty(custId) && StringUtils.isNumeric(custId)){
						musteriNo = new BigDecimal(custId);
					}
					
					if(musteriNo != null && sorguNo != null){
						conn = null;
						stmt = null;
						rSet = null;
						
						conn = DALUtil.getGMConnection(); 
						
						query = "select * from BNSPR.BIR_IHTARNAME_MASRAF_TX where sorgu_no=" + sorguNo.toString() + " and musteri_no=" + custId;						
						stmt = conn.prepareCall(query);
						rSet = stmt.executeQuery();
	
						if(rSet.next() == false) {
							try{
					    	   String func = "{call pkg_rc3295.ihtarname_masraf_hesabi(?,?,?) }";
					    	   Object[] inputValues = {
					    		  BnsprType.NUMBER, musteriNo,	   
					    		  BnsprType.NUMBER, sorguNo,
					    		  BnsprType.NUMBER, basvuruNo
					    	   };
					    	   Object[] outputValues = {};
					    	   DALUtil.callOracleProcedure(func, inputValues, outputValues);
					    	} catch(Exception e) {
					    		logger.error(custId + "no'lu müşteri için ihtarname masraf ataması yapılırken hata alındı!", e);
					    	}
						}else{
							logger.info(custId + "no'lu müşteri için ihtarname masraf ataması yapılmış!");
						}						
						GMServerDatasource.close(rSet);
						GMServerDatasource.close(conn);
						GMServerDatasource.close(stmt);
					}						
				}				
				start = start + interval;
				oMap = getLineFromFTM(start, start + interval, ftmProcId);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_SEND_HOBIM_IHTARNAME_TO_DYS")
	public static GMMap sendHobimIhtarnameToDYS(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
        ResultSet rSet = null;
        String fileName = StringUtils.EMPTY;
        String mailTo = StringUtils.EMPTY;
		
		try {
            conn = DALUtil.getGMConnection();
            oMap.put("PARAMETRE", "HOBIM_IHTAR_MAIL");
            mailTo = (String) GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", oMap).get("DEGER");

            stmt = conn.prepareCall("{? = call PKG_TRN2070.read_gnl_sifre(?) }");
            stmt.registerOutParameter(1, -10);
            stmt.setString(2, "IHTAR_ARS");
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            rSet.next();

            String serverName = rSet.getString("ip");
            String username = rSet.getString("user_name");
            String password = rSet.getString("passwd");
            String path = rSet.getString("path");
            BigDecimal port = rSet.getBigDecimal("port");

            AktifSFTPClient sftpClient = new AktifSFTPClient(serverName, username, password, port.intValue());
            String[] listFiles = sftpClient.listFilesAsStringArr(path);
            fileName = getFileNameFromFTM(iMap.getBigDecimal("PROCESS_ID"));
            
			for (int i = 0; i < listFiles.length; i++) {
				if (listFiles[i].equals(fileName)) {
					String zipFilePath = FILE_ROOT + File.separator + listFiles[i];
					sftpClient.get(path, listFiles[i], new File(zipFilePath));
					File tempDir = new File(FILE_ROOT + File.separator + "HOBIM_TEMP");

					if(!tempDir.exists()){
						tempDir.mkdir();
					}
					
					FileUtils.unzip(zipFilePath, tempDir.getPath());
					
					for(File f : tempDir.listFiles()){
						String[] dysParams = f.getName().split("_");
						GMMap dysMap = new GMMap();
			            dysMap.put("DOKUMAN_ADI", f.getName());
			            dysMap.put("DOKUMAN_TIPI", dysParams[0]);
			            dysMap.put("MUSTERI_NO", dysParams[1]);
			            dysMap.put("REFERANS_TIPI", "2");
			            dysMap.put("DOSYA_SAYFA", 0, "CONTENT", FileUtil.readFileToByteArray(f));
			            dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", f.getName());
			            dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER", BigDecimal.ONE);
			            dysMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));

		            	GMMap isExistMap = GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap);
		            	
						if(isExistMap.getBoolean("RESULT")){
							GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
						}else{
							GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
						}
					}
					sendMail("Hobimden Ihtarname Alimi", fileName + " dosyasi alindi.", mailTo);
				}
			}
		}
		catch (Exception e) {
			sendMail("Hobimden Ihtarname Alimi - HATA", fileName + " dosyasi alinamadi!" + e, mailTo);
		}finally{
			GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	private static void sendMail(String subject, String mailBody, String mailTo) {
        GMMap servisMap = new GMMap();
        servisMap.put("MAIL_FROM", "system@aktifbank.com.tr");
        GMMap xMap = new GMMap();
		try {
			xMap.put("PARAMETRE", "HOBIM_IHTAR_MAIL");
			servisMap.put("MAIL_TO", mailTo);
			servisMap.put("MAIL_SUBJECT", subject);
			servisMap.put("MAIL_BODY", mailBody);
			servisMap.put("IS_BODY_HTML", "H");
			GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
    }
	
	private static String getFileNameFromFTM(BigDecimal ftmProcessId) throws Exception{
		try {
			String tableName = "FILES";
			String fetchQuery = String.format("SELECT P.FILE_NAME FROM FTM.FTM_PROCESS P " +
											  "WHERE P.OID = %s ", ftmProcessId);
			
			return  DALUtil.getResults(fetchQuery, tableName).getString(tableName, 0, "FILE_NAME");
		}
		catch (Exception e) {
			throw e;
		}
	}
	
	@GraymoundService("BNSPR_HOBIM_IHTARNAME_TARIHI_SIL")
	public static GMMap ihtarnameTarihiSil(GMMap iMap) throws Exception{
		GMMap oMap = new GMMap();			
		try{
    	   String func = "{call pkg_rc3295.ihtar_tarihi_sil}";
    	   Object[] inputValues = {};
    	   Object[] outputValues = {};
    	   DALUtil.callOracleProcedure(func, inputValues, outputValues);
    	} catch(Exception e) {
    		logger.error("ihtarname tarihi sil job'u hata aldi!", e);
    	}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_HOBIM_IHTARNAME_SONUC_MUTABAKAT")
	public static GMMap ihtarnameSonucMutabakat(GMMap iMap) throws Exception{
		GMMap oMap = new GMMap();			
		try{
    	   String func = "{call pkg_rc3295.ihtarname_sonuc_mutabakat}";
    	   Object[] inputValues = {};
    	   Object[] outputValues = {};
    	   DALUtil.callOracleProcedure(func, inputValues, outputValues);
    	} catch(Exception e) {
    		logger.error("ihtarname sonuc mutabakat job'u hata aldi!", e);
    	}
		
		return oMap;
	}
}
