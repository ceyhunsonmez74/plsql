package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Calendar;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3135Services {

	@GraymoundService("BNSPR_QRY3135_GET_RECORD_FILL_LIST")
	public static GMMap getRecordQRY3135FillList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3135.RC_QRY3135_GET_RECORD_LIST(?,?,?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ODEME_PLAN_VERSIYON"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ASIL_ODEME_PLAN_VERSIYON"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			BigDecimal sumTaksitTutari = new BigDecimal(0);
			BigDecimal sumAnapara = new BigDecimal(0);
			BigDecimal sumFaiz = new BigDecimal(0);
			BigDecimal sumKKDF = new BigDecimal(0);
			BigDecimal sumBSMV = new BigDecimal(0);
			BigDecimal sumGecikmeFaizAlinan = new BigDecimal(0);
			BigDecimal sumOdemeTutari = new BigDecimal(0);

			GMMap s3Map = new GMMap();
			Calendar c = Calendar.getInstance();
			/** PY-11226 **/
			s3Map.put("BANKA_TARIH", c.getTime()); // (GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", s3Map ) );

			String tableName = "RESULTS";
			int row = 0;
			while (rSet.next()) {
				int j = 1;

				oMap.put(tableName, row, "SIRA_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "TAKSIT_TARIH", rSet.getDate(j++));
				oMap.put(tableName, row, "TAKSIT_TUT", rSet.getBigDecimal(j++));
				if (rSet.getString("DURUM_KOD").equals("ACIK"))
					sumTaksitTutari = sumTaksitTutari.add(rSet.getBigDecimal("TAKSIT_TUT"));
				else if (rSet.getString("DURUM_KOD").equals("KISMI"))
					sumTaksitTutari = sumTaksitTutari.add(rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARASI"));

				oMap.put(tableName, row, "ANAPARA", rSet.getBigDecimal(j++));
				if (rSet.getString("DURUM_KOD").equals("ACIK"))

					sumAnapara = sumAnapara.add(rSet.getBigDecimal("ANAPARA"));

				else if (rSet.getString("DURUM_KOD").equals("KISMI"))
					if (rSet.getFloat("KISMIDEN_KALAN_ANAPARASI") >= rSet.getFloat("ANAPARA")) {

						sumAnapara = sumAnapara.add(rSet.getBigDecimal("ANAPARA"));

					}
					else {
						sumAnapara = sumAnapara.add(rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARASI"));

					}
				oMap.put(tableName, row, "FAIZ", rSet.getBigDecimal(j++));
				if (rSet.getString("DURUM_KOD").equals("ACIK"))
					sumFaiz = sumFaiz.add(rSet.getBigDecimal("FAIZ"));
				oMap.put(tableName, row, "KKDF", rSet.getBigDecimal(j++));
				if (rSet.getString("DURUM_KOD").equals("ACIK"))
					sumKKDF = sumKKDF.add(rSet.getBigDecimal("KKDF"));
				oMap.put(tableName, row, "BSMV", rSet.getBigDecimal(j++));
				if (rSet.getString("DURUM_KOD").equals("ACIK"))
					sumBSMV = sumBSMV.add(rSet.getBigDecimal("BSMV"));
				oMap.put(tableName, row, "KALAN_ANAPARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DURUM_KOD", rSet.getString(j));
				String durum = rSet.getString(j);
				j++;

				oMap.put(tableName, row, "ODEME_TARIH", rSet.getDate(j));
				String odemeTarihi = rSet.getString(j);
				j++;

				if ((durum.compareTo("ACIK") == 0) && odemeTarihi == null && s3Map.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName, row, "TAKSIT_TARIH")) > 0 && rSet.getBigDecimal("TAKSIT_TUT").compareTo(new BigDecimal(0)) == 1) {
					oMap.put(tableName, row, "DURUM_KOD", "GECIKMEDE");

					GMMap inputDates = new GMMap();
					inputDates.put("FIRST_DATE", oMap.getDate(tableName, row, "TAKSIT_TARIH"));
					inputDates.put("SECOND_DATE", s3Map.getDate("BANKA_TARIH"));
					GMMap dayMap = GMServiceExecuter.call("BNSPR_COMMON_GUN_FARKI_HESAPLA", inputDates);
					oMap.put(tableName, row, "GECIKME_GUN_SAYISI", dayMap.getBigDecimal("DAYS"));
				}

				if ((durum.compareTo("ACIK") == 0) && s3Map.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName, row, "TAKSIT_TARIH")) > -1 && rSet.getBigDecimal("TAKSIT_TUT").compareTo(new BigDecimal(0)) == 0) {
					oMap.put(tableName, row, "DURUM_KOD", "ODENDI");
				}

				// oMap.put(tableName, row, "TAKSIT_TARIH",
				BigDecimal odemeTxNo = rSet.getBigDecimal(j++);
				if (rSet.getBigDecimal("TAKSIT_TUT").equals(BigDecimal.ZERO))
					odemeTxNo = null;
				oMap.put(tableName, row, "ODEME_TXNO", odemeTxNo);
				oMap.put(tableName, row, "ODEME_KURU", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "GECIKME_FAIZI", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "SIGORTA_TUTARI_MASRAF", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "AYLIK_TOPLAM_ODEME_TUTARI", rSet.getBigDecimal(j++));
				if (s3Map.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName, row, "TAKSIT_TARIH")) >= 0) {
					sumGecikmeFaizAlinan = sumGecikmeFaizAlinan.add(rSet.getBigDecimal("GECIKME_FAIZ_ALINAN") != null ? rSet.getBigDecimal("GECIKME_FAIZ_ALINAN") : new BigDecimal(0));
					sumGecikmeFaizAlinan = sumGecikmeFaizAlinan.add(oMap.getBigDecimal(tableName, row, "GECIKME_FAIZI") != null ? oMap.getBigDecimal(tableName, row, "GECIKME_FAIZI") : new BigDecimal(0));

				}
				if (oMap.getDate(tableName, row, "ODEME_TARIH") != null) {
					sumOdemeTutari = sumOdemeTutari.add(rSet.getBigDecimal("TAKSIT_TUT") != null ? rSet.getBigDecimal("TAKSIT_TUT") : new BigDecimal(0));
					// sumOdemeTutari = sumOdemeTutari.add(rSet.getBigDecimal("KKDF")!=null?rSet.getBigDecimal("KKDF"):new BigDecimal(0));
					// sumOdemeTutari = sumOdemeTutari.add(rSet.getBigDecimal("BSMV")!=null?rSet.getBigDecimal("BSMV"):new BigDecimal(0));
					sumOdemeTutari = sumOdemeTutari.add(rSet.getBigDecimal("GECIKME_FAIZ_ALINAN") != null ? rSet.getBigDecimal("GECIKME_FAIZ_ALINAN") : new BigDecimal(0));
					if (oMap.getString(tableName, row, "DURUM_KOD").equals("KISMI")) {
						sumOdemeTutari = sumOdemeTutari.subtract(rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARASI") != null ? rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARASI") : new BigDecimal(0));

						GMMap inputDates = new GMMap();
						inputDates.put("FIRST_DATE", oMap.getDate(tableName, row, "TAKSIT_TARIH"));
						inputDates.put("SECOND_DATE", s3Map.getDate("BANKA_TARIH"));
						GMMap dayMap = GMServiceExecuter.call("BNSPR_COMMON_GUN_FARKI_HESAPLA", inputDates);
						oMap.put(tableName, row, "GECIKME_GUN_SAYISI", dayMap.getBigDecimal("DAYS"));
					}
				}
				oMap.put(tableName, row, "GECIKME_FAIZ_ALINAN", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KISMIDEN_KALAN_ANAPARASI", rSet.getBigDecimal(j++));
				oMap.put("a", rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARA"));
				oMap.put(tableName, row, "KISMIDEN_KALAN_ANAPARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KISMIDEN_KALAN_FAIZ", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KISMIDEN_KALAN_KKDF", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KISMIDEN_KALAN_BSMV", rSet.getBigDecimal(j++));

				if (oMap.getString(tableName, row, "DURUM_KOD").equals("KISMI") || oMap.getString(tableName, row, "DURUM_KOD").equals("ODENDI")) {
					oMap.put(tableName, row, "TAHSIS_EDILMIS_TAKSIT_BORCU", rSet.getBigDecimal(j++));
				}
				else {
					oMap.put(tableName, row, "TAHSIS_EDILMIS_TAKSIT_BORCU", "0");
					j++;
				}

				oMap.put(tableName, row, "ERKEN_ODEME_FAIZ_INDIRIMI", rSet.getBigDecimal(j++));

				row++;
			}
			GMServerDatasource.close(rSet);

			stmt = conn.prepareCall("{? = call PKG_RC3135.hesap_takipten_kapalimi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR); // ref cursor
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			if (stmt.getString(1).compareTo("E") == 0) {
				oMap.put("SUM_TAKSIT_TUTAR", new BigDecimal(0));
				oMap.put("SUM_ANAPARA", new BigDecimal(0));
				oMap.put("SUM_FAIZ", new BigDecimal(0));
				oMap.put("SUM_KKDF", new BigDecimal(0));
				oMap.put("SUM_BSMV", new BigDecimal(0));
				oMap.put("SUMGECIKMEFAIZI", new BigDecimal(0));
				oMap.put("SUMODEMETUTARI", new BigDecimal(0));
			}
			else {
				oMap.put("SUM_TAKSIT_TUTAR", sumTaksitTutari);
				oMap.put("SUM_ANAPARA", sumAnapara);
				oMap.put("SUM_FAIZ", sumFaiz);
				oMap.put("SUM_KKDF", sumKKDF);
				oMap.put("SUM_BSMV", sumBSMV);
				oMap.put("SUMGECIKMEFAIZI", sumGecikmeFaizAlinan);
				oMap.put("SUMODEMETUTARI", sumOdemeTutari);
			}
			oMap.put("ROW_COUNT", row);
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("QRY3335_GET_KREDI_ODEME_IST")
	public static GMMap getRecordQRY3135GetList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3135.RC_QRY3135_GET_ODEME_LIST(?,?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SIRA_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			oMap = DALUtil.rSetResults(rSet, "ISLEM_LIST");

			oMap.put("KAYIT_SAYISI", oMap.getSize("ISLEM_LIST"));
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3135_GET_DEVIR_ODEME_PLANI")
	public static GMMap getDevirOdemePlani(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_VDMK.Get_Devir_Odeme_Plani(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			BigDecimal sumTaksitTutari = new BigDecimal(0);
			BigDecimal sumAnapara = new BigDecimal(0);
			BigDecimal sumFaiz = new BigDecimal(0);
			BigDecimal sumKKDF = new BigDecimal(0);
			BigDecimal sumBSMV = new BigDecimal(0);
			BigDecimal sumGecikmeFaizAlinan = new BigDecimal(0);
			BigDecimal sumOdemeTutari = new BigDecimal(0);

			GMMap s3Map = new GMMap();
			s3Map = (GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", s3Map));

			String tableName = "RESULTS";
			int row = 0;
			while (rSet.next()) {
				int j = 1;

				oMap.put(tableName, row, "SIRA_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "TAKSIT_TARIH", rSet.getDate(j++));
				oMap.put(tableName, row, "TAKSIT_TUT", rSet.getBigDecimal(j++));
				if (rSet.getString("DURUM_KOD").equals("ACIK"))
					sumTaksitTutari = sumTaksitTutari.add(rSet.getBigDecimal("TAKSIT_TUT"));
				else if (rSet.getString("DURUM_KOD").equals("KISMI"))
					sumTaksitTutari = sumTaksitTutari.add(rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARASI"));

				oMap.put(tableName, row, "ANAPARA", rSet.getBigDecimal(j++));
				if (rSet.getString("DURUM_KOD").equals("ACIK"))

					sumAnapara = sumAnapara.add(rSet.getBigDecimal("ANAPARA"));

				else if (rSet.getString("DURUM_KOD").equals("KISMI"))
					if (rSet.getFloat("KISMIDEN_KALAN_ANAPARASI") >= rSet.getFloat("ANAPARA")) {

						sumAnapara = sumAnapara.add(rSet.getBigDecimal("ANAPARA"));

					}
					else {
						sumAnapara = sumAnapara.add(rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARASI"));

					}
				oMap.put(tableName, row, "FAIZ", rSet.getBigDecimal(j++));
				if (rSet.getString("DURUM_KOD").equals("ACIK"))
					sumFaiz = sumFaiz.add(rSet.getBigDecimal("FAIZ"));
				oMap.put(tableName, row, "KKDF", rSet.getBigDecimal(j++));
				if (rSet.getString("DURUM_KOD").equals("ACIK"))
					sumKKDF = sumKKDF.add(rSet.getBigDecimal("KKDF"));
				oMap.put(tableName, row, "BSMV", rSet.getBigDecimal(j++));
				if (rSet.getString("DURUM_KOD").equals("ACIK"))
					sumBSMV = sumBSMV.add(rSet.getBigDecimal("BSMV"));
				oMap.put(tableName, row, "KALAN_ANAPARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DURUM_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "ODEME_TARIH", rSet.getDate(j++));
				// oMap.put(tableName, row, "TAKSIT_TARIH",
				BigDecimal odemeTxNo = rSet.getBigDecimal(j++);
				if (rSet.getBigDecimal("TAKSIT_TUT").equals(BigDecimal.ZERO))
					odemeTxNo = null;
				oMap.put(tableName, row, "ODEME_TXNO", odemeTxNo);
				oMap.put(tableName, row, "ODEME_KURU", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "GECIKME_FAIZI", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "SIGORTA_TUTARI_MASRAF", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "AYLIK_TOPLAM_ODEME_TUTARI", rSet.getBigDecimal(j++));
				if (s3Map.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName, row, "TAKSIT_TARIH")) > 0) {
					sumGecikmeFaizAlinan = sumGecikmeFaizAlinan.add(rSet.getBigDecimal("GECIKME_FAIZ_ALINAN") != null ? rSet.getBigDecimal("GECIKME_FAIZ_ALINAN") : new BigDecimal(0));
					sumGecikmeFaizAlinan = sumGecikmeFaizAlinan.add(oMap.getBigDecimal(tableName, row, "GECIKME_FAIZI") != null ? oMap.getBigDecimal(tableName, row, "GECIKME_FAIZI") : new BigDecimal(0));
					if (oMap.getDate(tableName, row, "ODEME_TARIH") != null) {
						sumOdemeTutari = sumOdemeTutari.add(rSet.getBigDecimal("TAKSIT_TUT") != null ? rSet.getBigDecimal("TAKSIT_TUT") : new BigDecimal(0));
						// sumOdemeTutari = sumOdemeTutari.add(rSet.getBigDecimal("KKDF")!=null?rSet.getBigDecimal("KKDF"):new BigDecimal(0));
						// sumOdemeTutari = sumOdemeTutari.add(rSet.getBigDecimal("BSMV")!=null?rSet.getBigDecimal("BSMV"):new BigDecimal(0));
						sumOdemeTutari = sumOdemeTutari.add(rSet.getBigDecimal("GECIKME_FAIZ_ALINAN") != null ? rSet.getBigDecimal("GECIKME_FAIZ_ALINAN") : new BigDecimal(0));
						if (oMap.getString(tableName, row, "DURUM_KOD").equals("KISMI")) {
							sumOdemeTutari = sumOdemeTutari.subtract(rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARASI") != null ? rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARASI") : new BigDecimal(0));

							GMMap inputDates = new GMMap();
							inputDates.put("FIRST_DATE", oMap.getDate(tableName, row, "TAKSIT_TARIH"));
							inputDates.put("SECOND_DATE", s3Map.getDate("BANKA_TARIH"));
							GMMap dayMap = GMServiceExecuter.call("BNSPR_COMMON_GUN_FARKI_HESAPLA", inputDates);
							oMap.put(tableName, row, "GECIKME_GUN_SAYISI", dayMap.getBigDecimal("DAYS"));
						}
					}
				}
				oMap.put(tableName, row, "GECIKME_FAIZ_ALINAN", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KISMIDEN_KALAN_ANAPARASI", rSet.getBigDecimal(j++));
				oMap.put("a", rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARA"));
				oMap.put(tableName, row, "KISMIDEN_KALAN_ANAPARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KISMIDEN_KALAN_FAIZ", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KISMIDEN_KALAN_KKDF", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KISMIDEN_KALAN_BSMV", rSet.getBigDecimal(j++));

				if (oMap.getString(tableName, row, "DURUM_KOD").equals("KISMI") || oMap.getString(tableName, row, "DURUM_KOD").equals("ODENDI")) {
					oMap.put(tableName, row, "TAHSIS_EDILMIS_TAKSIT_BORCU", rSet.getBigDecimal(j++));
				}
				else {
					oMap.put(tableName, row, "TAHSIS_EDILMIS_TAKSIT_BORCU", "0");
					j++;
				}
				oMap.put(tableName, row, "ERKEN_ODEME_FAIZ_INDIRIMI", rSet.getBigDecimal(j++));
				oMap.put("DEVIR_TARIHI", rSet.getDate(j++));
				row++;
			}
			GMServerDatasource.close(rSet);

			oMap.put("TOPLAM_TAKSIT_TUTARI", sumTaksitTutari);
			oMap.put("TOPLAM_ANAPARA", sumAnapara);
			oMap.put("TOPLAM_FAIZ", sumFaiz);
			oMap.put("TOPLAM_KKDF", sumKKDF);
			oMap.put("TOPLAM_BSMV", sumBSMV);

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
