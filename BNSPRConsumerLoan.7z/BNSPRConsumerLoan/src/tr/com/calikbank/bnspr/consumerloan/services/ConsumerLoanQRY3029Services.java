package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Map;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.util.ADCSession;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class ConsumerLoanQRY3029Services {

	@GraymoundService("BNSPR_QRY3029_GET_KULLANICI_BILGI")
	public static GMMap getKullaniciBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KULLANICI_KOD", iMap));
			oMap.put("ROLE_ID", ADCSession.get("ROLE_ID"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3029_GET_PROCESS_INSTANCE_IMAGE")
	public static GMMap getProcessInstanceImage(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap processImageMap = GMServiceExecuter.call("BPM_GET_PROCESS_INSTANCE_IMAGE_AS_BYTEARRAY", iMap);
			byte[] imageArray = (byte[]) processImageMap.get("IMAGE_BYTEARRAY");
			Icon icon = new ImageIcon(imageArray);
			oMap.put("ICON", icon);
			oMap.put("ICON_HEIGHT", icon.getIconHeight());
			oMap.put("ICON_WIDTH", icon.getIconWidth());
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3029_BPM_GET_ASSIGNED_TASK")
	public static GMMap getAssignedTask(GMMap iMap) {
		GMMap oMap = new GMMap();	
		try {
			iMap.putAll(GMServiceExecuter.call("BPM_GET_ASSIGNED_TASK", iMap));			
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3029_BPM_GET_TASK_LIST", iMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	

	@GraymoundService("BNSPR_QRY3029_BPM_GET_UNASSIGNED_TASK")
	public static GMMap getUnAssignedTask(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.putAll(GMServiceExecuter.call("BPM_GET_UNASSIGNED_TASK", iMap));			
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3029_BPM_GET_TASK_LIST", iMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY3029_BPM_GET_TASK_LIST")
	public static GMMap getTaskList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String tableName="TASK_LIST";
			oMap.put(tableName,iMap.get(tableName));
			for(int i=0;i<iMap.getSize(tableName);i++) {
				GMMap pMap = new GMMap();
				pMap.put("PROCESS_INSTANCE_ID",iMap.getString(tableName,i,"PROCESS_INSTANCE_ID"));
				pMap.putAll(GMServiceExecuter.execute("BPM_GET_PROCESS_INSTANCE_VARIABLES" , pMap));
			    oMap.put(tableName,i,"BASVURU_NO",pMap.getString("BASVURU_NO"));			  
			}
			return oMap;	
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_QRY3029_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {		
			String tnBELGELIST = "BELGE_LIST";			
			GMMap procInsMap=new GMMap();
	    	procInsMap.put("PROCESS_INSTANCE_ID", iMap.getString("PROCESS_INSTANCE_ID"));
	    	procInsMap.putAll(GMServiceExecuter.execute("BPM_GET_PROCESS_INSTANCE_VARIABLES",procInsMap));
	    	GMMap belgeMap=new GMMap();
	    	belgeMap = procInsMap.getMap("BELGE_LIST");
	    	String tableName="BELGELER";
	    	for(int i=0; i<belgeMap.getSize(tableName);i++){
	    		oMap.put(tnBELGELIST, i, "BELGE_KOD", belgeMap.getString(tableName, i, "BELGE_KOD"));
	    		oMap.put(tnBELGELIST, i, "KIMDEN", belgeMap.getString(tableName, i, "KIMDEN"));
	    		oMap.put(tnBELGELIST, i, "BELGE_ADI", belgeMap.getString(tableName, i, "BELGE_ADI"));
	    		oMap.put(tnBELGELIST, i, "DOSYA_ADI", belgeMap.getString(tableName, i, "DOSYA_ADI"));
	    		oMap.put(tnBELGELIST, i, "BELGE_HATA", belgeMap.getString(tableName, i, "BELGE_HATA"));
	    		oMap.put(tnBELGELIST, i, "DOKUMAN_UUID", belgeMap.getString(tableName, i, "DOKUMAN_UUID"));
	    	    
	 
	    		GMMap dMap = new GMMap();	    	
	    		dMap.put("DOKUMAN_UUID",belgeMap.getString(tableName, i, "DOKUMAN_UUID"));
	        	dMap.put("DOKUMAN_BYTE_ARRAY_NEEDED", true);
	        	dMap.putAll(GMServiceExecuter.execute("DYS_CMIS_GET_DOKUMAN_LINK_BY_UUID",dMap));
	        	oMap.put(tnBELGELIST,i,"CONTENT", dMap.get("DOKUMAN_BYTE_ARRAY"));
	        	oMap.put(tnBELGELIST,i,"DOSYA_YOL",dMap.get("DOKUMAN_LINK"));
	        	oMap.put(tnBELGELIST,i,"DOSYA_ADI",dMap.get("DOKUMAN_ADI"));
	        	oMap.put(tnBELGELIST,i,"URL",dMap.get("DOKUMAN_LINK"));
	    		//oMap.put(tnBELGELIST,i,"DOSYA_YOL",belgeMap.getString(tableName,i,"DOSYA_ADI"));
	    		//oMap.put(tnBELGELIST,i,"URL","http://sileuat.aktifbank.com.tr:8080/DysDokumanWeb/dokuman?UUID=workspace://SpacesStore/5d9aecf5-9786-4ba1-975d-46e8d65cf467");
	    	}			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_QRY3029_SAVE")
    public static GMMap belgeDurumGuncelleme(GMMap iMap){
    	GMMap oMap = new GMMap();
    	Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
    	try{
    		System.out.println("save.1:");
    		GMMap procInsMap=new GMMap();
	    	procInsMap.put("PROCESS_INSTANCE_ID", iMap.getString("PROCESS_INSTANCE_ID"));
	 		    			    
	    	iMap.put("IPTAL_GOSTER","H");
    		iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3182_GET_BASVURU_INFO"	,iMap)); // 3182 simule edildi.
    		
    		GMMap biMap = new GMMap();
    		GMMap boMap = new GMMap();
    		biMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
    		biMap.put("SOZLESME_TARIHI", iMap.get("SOZLESME_TARIHI"));
    		biMap.put("ORJ_EVRAK_GONDERIM_SURESI",iMap.get("ORJ_EVRAK_GONDERIM_SURESI"));
    	   	boMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_GET_BELGE_LIST",biMap));
    	 
    	   	GMMap bMap = new GMMap();
    	   //	bMap.put("BELGELER", iMap.get("BELGELER"));
        	int onayli_belge_sayisi = 0; 
        	int red_belge_sayisi=0;
    	   	for(int i=0;i<boMap.getSize("BELGELER");i++) {
    	   	    for(int j=0;j<iMap.getSize("BELGELER");j++) {	 
    	           if ((boMap.getString("BELGELER",i,"BELGE_KOD")).equals(iMap.getString("BELGELER",j,"BELGE_KOD"))) {      	   	
    	        	   String onayli_mi =  (String) iMap.get("BELGELER",j,"ONAY");
    	        	   if("1".equals(onayli_mi)) {    	        	    
    	        		   bMap.put("BELGELER",j,"BASVURU_NO",iMap.get("BASVURU_NO"));
    	        		   bMap.put("BELGELER",j,"BELGE_KOD", iMap.get("BELGELER",j,"BELGE_KOD"));
        	        	   bMap.put("BELGELER",j,"KIMDEN_KOD",boMap.get("BELGELER",j,"KIMDEN_KOD"));
        	        	   bMap.put("BELGELER",j,"BELGE_ADI",boMap.get("BELGELER",j,"BELGE_ADI"));
        	        	   bMap.put("BELGELER",j,"DOKUMAN_TIP_KOD",boMap.get("BELGELER",j,"DOKUMAN_TIP_KOD"));
        	        	   bMap.put("BELGELER",j,"DOSYA_ADI",bMap.get("BELGELER",j,"DOSYA_ADI"));
        	        	   bMap.put("BELGELER",j,"DOSYA_YOL",bMap.get("BELGELER",j,"DOSYA_YOL"));
        	        	   bMap.put("BELGELER",j,"URL",bMap.get("BELGELER",j,"URL"));
        	        	   bMap.put("BELGELER",j,"BELGE_KONTROL","5");
        	        	   bMap.put("BELGELER",j,"BELGE_HATA","");
        	        	   bMap.put("BELGELER",j,"GELIS_TARIHI",boMap.get("BELGELER",j,"GELIS_TARIHI"));
        	        	   bMap.put("BELGELER",j,"ORJINAL_EVRAK_MI",boMap.get("BELGELER",j,"ORJINAL_EVRAK_MI"));
        	        	   bMap.put("BELGELER",j,"KAYIT",boMap.get("BELGELER",j,"KAYIT"));
        	        	   bMap.put("BELGELER",j,"BELGE_TAMAMLAMA_TARIHI",boMap.get("BELGELER",j,"BELGE_TAMAMLAMA_TARIHI"));
        	        	   bMap.put("BELGELER",j,"BARKOD_NUMARASI",boMap.get("BELGELER",j,"BARKOD_NUMARASI"));
        	        	   bMap.put("BELGELER",j,"ONAYLI_MI",boMap.get("BELGELER",j,"ONAYLI_MI"));
        	        	   bMap.put("BELGELER",j,"UYUMSUZ_ACIKLAMA",boMap.get("BELGELER",j,"UYUMSUZ_ACIKLAMA"));
        	        	   bMap.put("BELGELER",j,"BELGE_ALINMA_ADIMI",boMap.get("BELGELER",j,"BELGE_ALINMA_ADIMI"));
        	        	   bMap.put("BELGELER",j,"KONTROL_NEDENI",boMap.get("BELGELER",j,"KONTROL_NEDENI"));
    	        	       onayli_belge_sayisi++;
    	        	   } else {
    	        		   red_belge_sayisi++;
    	        	   }
    	           }
    	   	    }	    	   		
    	   	}
    	   
    	   
    		if(onayli_belge_sayisi>0) {
    		   iMap.putAll(bMap);
    	   	   oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_SAVE"			,iMap));
    	   	}
    	
    		if(red_belge_sayisi==0) {
	    	   	Map<String, Object>  variableMap=new HashMap<String, Object>();
	        	variableMap.put("flow", "ONAY");
	        	procInsMap.put("INSTANCE_VARIABLES",variableMap);
	            GMServiceExecuter.execute("BPM_SET_PROCESS_INSTANCE_VARIABLES",procInsMap);
	    		iMap.putAll(GMServiceExecuter.execute("BPM_COMPLETE_TASK"			,iMap));  // end task
	    		conn = DALUtil.getGMConnection();	
	    		stmt= conn.prepareStatement("delete bpm_processes where reference_type='eksikBelgeTamamlamaAkisi' and process_instance_id = TO_NUMBER(?)");
				stmt.setString(1, iMap.getString("PROCESS_INSTANCE_ID"));				
				stmt.execute();
			} else {
			    Map<String, Object>  variableMap=new HashMap<String, Object>();
    			variableMap.put("flow", "RED");
    			procInsMap.put("INSTANCE_VARIABLES",variableMap);
        		GMServiceExecuter.execute("BPM_SET_PROCESS_INSTANCE_VARIABLES",procInsMap);
    			iMap.putAll(GMServiceExecuter.execute("BPM_COMPLETE_TASK",iMap));
    			oMap.put("MESSAGE", red_belge_sayisi+" adet belge i�in i�lem iade edildi");
			}
			
    	   //	oMap.put("MESSAGE", "Kaydedildi");
    		return oMap;
    	} catch (Exception e){
    		throw ExceptionHandler.convertException(e);
    	} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
	    }
    }
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_QRY3029_RED")
    public static GMMap belgeDurumRed(GMMap iMap){
    	GMMap oMap = new GMMap();
    	GMMap procInsMap=new GMMap();
    	procInsMap.put("PROCESS_INSTANCE_ID", iMap.getString("PROCESS_INSTANCE_ID"));
    	procInsMap.put("TASK_ID", iMap.getString("TASK_ID"));
    	Map<String, Object>  variableMap=new HashMap<String, Object>();
    	variableMap.put("flow", "RED");
    	procInsMap.put("INSTANCE_VARIABLES",variableMap);
        GMServiceExecuter.execute("BPM_SET_PROCESS_INSTANCE_VARIABLES",procInsMap);
    	iMap.putAll(GMServiceExecuter.execute("BPM_COMPLETE_TASK",iMap));
    	oMap.put("MESSAGE", "��lem �ade Edildi");
    	return oMap;
	}	

}
