package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanIVNServices {
	@GraymoundService("BNSPR_GECIKMELI_MUSTERI_LISTESI")
	public static GMMap getGecikmeliMusteriler(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_DCS_IVN.Gecikmeli_Musteriler}");
			stmt.registerOutParameter(1, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			while (rSet.next()) {
    			iMap.put("EVENT_TYPE_NO", "69");
    			iMap.put("EVENT_REF_NO", rSet.getBigDecimal("BASVURU_NO"));
    			GMServiceExecuter.execute("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
            }

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_GECIKMELI_MUSTERI_KONTROL")
	public static GMMap gecikmeliMusteriKontrol(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();
				
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call PKG_DCS_IVN.Gecikme_Kontrol(?,?, ?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("GGS"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("KONTROL"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "BASVURU_BILGI");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_GECIKMELI_MUSTERI_ARAMA_SONUCU_EKLE")
	public static GMMap aramaSonuclariEkleme(GMMap iMap) {
		//initial variables
		GMMap oMap = new GMMap();
				
		//initial database variables
		String query = null;
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			conn = DALUtil.getGMConnection();
			
			query = "{ ? = call PKG_DCS_IVN.Arama_Sonucu_Ekle(?,?,?) }";
			stmt = conn.prepareCall(query);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setDate(3, new Date(iMap.getDate("ARAMA_TARIHI").getTime()));
			stmt.setString(4, iMap.getString("IVN_ARAMA_SONUCU"));
			stmt.execute();
			
			oMap.put("SONUC", stmt.getString(1));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}	
}
