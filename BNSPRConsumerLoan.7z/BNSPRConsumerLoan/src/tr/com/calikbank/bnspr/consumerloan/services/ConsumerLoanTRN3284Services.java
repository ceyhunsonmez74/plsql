package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKapamaTalimat;
import tr.com.aktifbank.bnspr.dao.BirKapamaTalimatTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.services.transaction.ServiceExecuter;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3284Services {
	private static Logger logger = Logger.getLogger(ConsumerLoanTRN3284Services.class);
	
	@GraymoundService("BNSPR_TRN3284_GET_TAHSILAT_TUTAR")
	public static GMMap getTahsilatTutar(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_trn3284.Kapama_Tutari_Al(?,?)}");
			
			int i = 1;
			
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setDate(i++, iMap.getDate("KAPAMA_YAPILMASI_ISTENEN_TARIH") == null ? null : new java.sql.Date(iMap.getDate("KAPAMA_YAPILMASI_ISTENEN_TARIH").getTime()));
			
			stmt.execute();
			
			oMap.put("TAHSILAT_TUTAR", stmt.getBigDecimal(1));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3284_KAP_TAR_FORMAT")
	public static GMMap kapamaTarihFormat(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			Date kapamaTar = iMap.getDate("KAPAMA_YAPILMASI_ISTENEN_TARIH");

			if (kapamaTar != null) {

				SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");

				String kapamaTarStr = format.format(kapamaTar);

				oMap.put("TARIH_STR", kapamaTarStr);

			}
			
		}
		catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3284_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BirKapamaTalimatTx birKapamaTalimatTx = (BirKapamaTalimatTx)session.get(BirKapamaTalimatTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(birKapamaTalimatTx == null)
				birKapamaTalimatTx = new BirKapamaTalimatTx();
			
			birKapamaTalimatTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			
			birKapamaTalimatTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birKapamaTalimatTx.setDurum(iMap.getString("DURUM"));
			birKapamaTalimatTx.setKapamaTarihi(iMap.getDate("KAPAMA_YAPILMASI_ISTENEN_TARIH"));
			birKapamaTalimatTx.setKapamaTutari(iMap.getBigDecimal("KAPAMA_TUTARI"));
			birKapamaTalimatTx.setHayatSigortasiDevam(iMap.getBoolean("HAYAT_SIGORTASI_DEVAM")?"E":"H");
			birKapamaTalimatTx.setIptalTarihi(iMap.getDate("IPTAL_TARIHI"));
			birKapamaTalimatTx.setRecOwner(ADCSession.getString("USER_NAME"));
			birKapamaTalimatTx.setRecDate(new Date());
			
			session.save(birKapamaTalimatTx);
			session.flush();
			
			iMap.put("TRX_NAME", "3284");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3284_GET_TALIMAT_LIST")
	public static GMMap getTalimatList(GMMap iMap) {
		GMMap oMap = new GMMap();
		BirKapamaTalimatTx tx = null;
		SimpleDateFormat dt = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			@SuppressWarnings("unchecked")
			List<BirKapamaTalimatTx> list = session.createCriteria(BirKapamaTalimatTx.class)
					.add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).addOrder(Order.desc("recDate")).list();
			
			int count = 0;
			for (int i=0; i<list.size(); i++) {
				tx = list.get(i);
				if(i>0 && "A".equals(tx.getDurum())){
					continue;
				}
				oMap.put("RESULTS", count, "ISLEM_TARIH", dt.format(tx.getRecDate()));
				oMap.put("RESULTS", count, "IPTAL_TARIH", tx.getIptalTarihi());
				oMap.put("RESULTS", count, "KAPAMA_TARIHI", tx.getKapamaTarihi());
				oMap.put("RESULTS", count, "KAPAMA_TUTARI", tx.getKapamaTutari());
				if ("A".equals(tx.getDurum())){
					oMap.put("RESULTS", count, "DURUM", "Aktif");
				}else if ("I".equals(tx.getDurum())){
					oMap.put("RESULTS", count, "DURUM", "�ptal");
				}else if("K".equals(tx.getDurum())){
					oMap.put("RESULTS", count, "DURUM", "Kapand�");
				}
				oMap.put("RESULTS", count, "DURUM_KODU", tx.getDurum());
				oMap.put("RESULTS", count, "ISLEMI_YAPAN_KULLANICI", tx.getRecOwner());
				oMap.put("RESULTS", count, "TRX_NO", tx.getTxNo());
				count++;
			}
			oMap.put("AKTIF_TALIMAT", "H");
			BirKapamaTalimat birKapamaTalimat = (BirKapamaTalimat)session.get(BirKapamaTalimat.class, iMap.getBigDecimal("BASVURU_NO"));
			
			if(birKapamaTalimat != null &&  "A".equals(birKapamaTalimat.getDurum())){
				oMap.put("AKTIF_TALIMAT", "E");
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3284_TALIMAT_IPTAL")
	public static GMMap talimatIptal(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BirKapamaTalimat birKapamaTalimat = (BirKapamaTalimat)session.get(BirKapamaTalimat.class, iMap.getBigDecimal("BASVURU_NO"));
			
			iMap.put("TRX_NO", ServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).get("TRX_NO"));
			iMap.put("BASVURU_NO", birKapamaTalimat.getBasvuruNo());
			iMap.put("KAPAMA_YAPILMASI_ISTENEN_TARIH", birKapamaTalimat.getKapamaTarihi());
			iMap.put("KAPAMA_TUTARI", birKapamaTalimat.getKapamaTutari());
			iMap.put("HAYAT_SIGORTASI_DEVAM", "E".equals(birKapamaTalimat.getHayatSigortasiDevam())?true:false);
			iMap.put("DURUM", "I");
			iMap.put("IPTAL_TARIHI", new Date());
			
			oMap.putAll(ServiceExecuter.execute("BNSPR_TRN3284_SAVE", iMap));
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3284_REHIN_KALDIRIM_JOB")
	public static GMMap rehinKaldirimJob(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		BigDecimal basvuruNo = null;
		
		try{
            conn = DALUtil.getGMConnection();            
            stmt = conn.prepareCall("{ call pkg_trn3284.kapama_rehin_kaldirim_data(?) }");
            stmt.registerOutParameter(1, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);

            while (rSet.next()) {
            	try{
	            	basvuruNo = rSet.getBigDecimal(1);
	            	
	            	iMap.put("BASVURU_NO", basvuruNo);
	            	iMap.put("CEP_TEL", rSet.getString(2));
	            	
	            	GMServiceExecuter.call("BNSPR_TRN3133_REHIN_KALDIRIM", iMap);
            	}
				catch(Exception e){
					if(!"".equals(basvuruNo)){
						logger.error(basvuruNo + " no lu basvuruda hata alindi!");
					}
					e.printStackTrace();
				}
            }
			return oMap;
	    } catch (Exception e) {
	        throw ExceptionHandler.convertException(e);
	    } finally {
	        GMServerDatasource.close(rSet);
	        GMServerDatasource.close(stmt);
	        GMServerDatasource.close(conn);
	    }
	}
}
