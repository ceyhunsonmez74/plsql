package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruHakemHeyetiTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruHakemHeyetiTxId;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.dao.BirKullandirimTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.services.transaction.ServiceExecuter;

import com.graymound.annotation.GraymoundService;
import com.graymound.module.custom.services.LOVExecuter;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3280Services {
	
	private static Logger logger = Logger.getLogger(ConsumerLoanTRN3280Services.class);
	
	@GraymoundService("BNSPR_TRN3280_GET_LIST")
	public static GMMap sorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
	    GMMap tMap = new GMMap();
		try{
			if(iMap.getBigDecimal("MUSTERI_NO")==null){
				throw new GMRuntimeException(0,"M��teri Se�iniz.");
			}
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(BirKullandirim.class).add(Restrictions.eq("musteriNo",iMap.getBigDecimal("MUSTERI_NO") )).addOrder(Order.asc("islemTar")).list();
			int i=0;
			String tableName="TABLO";
			Date lastCreditDate = null;
			BigDecimal lastCreditAccount = null;
			BigDecimal toplamMasraf = BigDecimal.ZERO;
			BigDecimal toplamSigorta = BigDecimal.ZERO;
			BigDecimal toplamIadeMasraf = BigDecimal.ZERO;
			BigDecimal toplamIadeSigorta = BigDecimal.ZERO;
			
			for(Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
            	BirKullandirim birKullandirim = (BirKullandirim) iterator.next();
            	oMap.put(tableName, i, "BASVURU_NO", birKullandirim.getBasvuruNo());
            	oMap.put(tableName, i, "KULLANDIRIM_TARIHI", birKullandirim.getIslemTar());
            	oMap.put(tableName, i, "ALINAN_MASRAF_TUTARI", birKullandirim.getDosyaMasraf());
            	oMap.put(tableName, i, "ALINAN_SIGORTA_TUTARI", birKullandirim.getKrediSigPrim());
            	oMap.put(tableName, i, "ALACAK_HESAP_NO", birKullandirim.getAlacHesapNo());
            	oMap.put(tableName, i, "DOSYA_MASRAF_GELIR",birKullandirim.getBrkMasrafRees());
            	oMap.put(tableName, i, "DOSYA_MASRAF_NET",birKullandirim.getDosyaMasrafNet());
                oMap.put(tableName, i, "KRD_HESAP_NO", birKullandirim.getKrdHesapNo());
                toplamMasraf = toplamMasraf.add(nvl(birKullandirim.getDosyaMasraf(), BigDecimal.ZERO));
                toplamSigorta = toplamSigorta.add(nvl(birKullandirim.getKrediSigPrim(), BigDecimal.ZERO));
                
            	List<?> listx = (List<?>) session.createCriteria(BirKullandirimTx.class)
                        .add(Restrictions.eq("basvuruNo",birKullandirim.getBasvuruNo()))                        
                        .addOrder(Order.desc("txNo"))
                        .list();            	
                BirKullandirimTx birKullandirimTx = null; 
                if(listx.size()>0) {            
                	 birKullandirimTx = (BirKullandirimTx) listx.get(0);
                }
                if(birKullandirimTx == null) {
                	 throw new GMRuntimeException(0,"Ba�vurunun Tx Kayd� bulunamad�.Ba�vuru No= "+birKullandirim.getBasvuruNo());
                }
            	oMap.put(tableName, i, "PTT_BASVURU_MASRAF", birKullandirimTx.getPttBasvuruMasraf());
            	oMap.put(tableName, i, "PTT_KUL_MASRAF", birKullandirimTx.getPttKulMasraf());
                oMap.put(tableName, i, "DIGER_MASRAF", birKullandirimTx.getDigerMasraf());
                oMap.put(tableName, i, "DOSYA_MASRAF_BSMV",birKullandirimTx.getDosyaBsmv());
                oMap.put(tableName, i, "VERGI_ODENDI_MI", true);                
                String func = "{ ? = call pkg_trn3280.rc_iade_bilgileri(?) }";
                Object[] inputValues = {
                	BnsprType.NUMBER, birKullandirim.getBasvuruNo()
                };
                tMap.clear();
                tMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues));
                int size = tMap.getSize("RESULTS");
                if(size>0) {
                	 oMap.put(tableName, i, "IADE_EDILEN_MASRAF_TUTARI",tMap.get("RESULTS",0,"IADE_MASRAF_TUTARI")); 
                	 oMap.put(tableName, i, "IADE_EDILEN_SIGORTA_TUTARI",tMap.get("RESULTS",0,"IADE_SIGORTA_TUTARI")); 
                	 oMap.put(tableName, i, "VERGI_ODENDI_MI", tMap.get("RESULTS",0,"VERGI_ODENDI_MI").equals("E"));  
                	 toplamIadeMasraf = toplamIadeMasraf.add(nvl(tMap.getBigDecimal("RESULTS",0,"IADE_MASRAF_TUTARI"), BigDecimal.ZERO));
                	 toplamIadeSigorta = toplamIadeSigorta.add(nvl(tMap.getBigDecimal("RESULTS",0,"IADE_SIGORTA_TUTARI"), BigDecimal.ZERO));
                }
                List<Object> inputList = new ArrayList<Object>();
    			inputList.add(birKullandirim.getBasvuruNo());
    			List<?> listHesap = LOVExecuter.execute("3135Q/LOV_BASVURU_2", "%", inputList);
    			if(listHesap.size() > 0){
    				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
    				Date creditDate = dateFormat.parse((String)((HashMap<?, ?>)listHesap.get(0)).get("KULLANDIRIM_TARIHI"));
    				oMap.put(tableName, i, "HESAP_DURUM", ((HashMap<?, ?>)listHesap.get(0)).get("HESAP_DURUM"));
    				if(lastCreditDate == null || creditDate.after(lastCreditDate)){
    					lastCreditDate = creditDate;
    					lastCreditAccount =  birKullandirim.getAlacHesapNo();
    				}
    			}
                i++;
            }
			
			oMap.put("TOPLAM_MASRAF", toplamMasraf);
			oMap.put("TOPLAM_SIGORTA", toplamSigorta);
			oMap.put("TOPLAM_IADE_MASRAF", toplamIadeMasraf);
			oMap.put("TOPLAM_IADE_SIGORTA", toplamIadeSigorta);
			oMap.put("TOPLAM_IADE_TUTARI", toplamIadeMasraf.add(toplamIadeSigorta));
			oMap.put("IADE_HESAP_NO", lastCreditAccount);
			
			if(i == 0) {
				throw new GMRuntimeException(0,"Bu M��terinin Kulland�r�lm�� Ba�vurusu Bulunmamaktad�r.");
			}
		}		
		catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN3280_SAVE")
	public static GMMap save3280(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName="TABLO";
			int len = iMap.getSize(tableName);	
			int count=0;
			if(iMap.getBigDecimal("MUSTERI_NO")==null){
				throw new GMRuntimeException(0,"M��teri Se�iniz.");
			}
			
	        for(int i=0;i<len;i++) {
	        	if ((iMap.getBigDecimal(tableName,i,"BASVURU_NO")!=null) && (iMap.getBoolean(tableName, i, "SEC"))) { 
		        	BirBasvuruHakemHeyetiTx birBasvuruHakemHeyetiTx =  new BirBasvuruHakemHeyetiTx(); 		        	
		        	BirBasvuruHakemHeyetiTxId birBasvuruHakemHeyetiTxId =  new BirBasvuruHakemHeyetiTxId(); 
		        	birBasvuruHakemHeyetiTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
		        	birBasvuruHakemHeyetiTxId.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));		        
		        	birBasvuruHakemHeyetiTxId.setBasvuruNo(iMap.getBigDecimal(tableName, i, "BASVURU_NO"));
		        	birBasvuruHakemHeyetiTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
		        	birBasvuruHakemHeyetiTx.setAciklama(iMap.getString("ACIKLAMA"));
		        	birBasvuruHakemHeyetiTx.setHakemHeyeti(iMap.getString("HAKEM_HEYETI"));
		        	birBasvuruHakemHeyetiTx.setKararNo(iMap.getString("KARAR_NO"));
		        	birBasvuruHakemHeyetiTx.setAlacakHesapNo(iMap.getBigDecimal("IADE_HESAP_NO"));
		        	birBasvuruHakemHeyetiTx.setAlinanMasrafTutari(iMap.getBigDecimal(tableName, i, "ALINAN_MASRAF_TUTARI"));
		        	birBasvuruHakemHeyetiTx.setAlinanSigortaTutari(iMap.getBigDecimal(tableName, i, "ALINAN_SIGORTA_TUTARI"));
		        	birBasvuruHakemHeyetiTx.setKullandirimTarihi(iMap.getDate(tableName, i, "KULLANDIRIM_TARIHI"));
		        	birBasvuruHakemHeyetiTx.setDosyaMasrafGelir(iMap.getBigDecimal(tableName, i, "DOSYA_MASRAF_GELIR"));
		        	birBasvuruHakemHeyetiTx.setDosyaMasrafNet(iMap.getBigDecimal(tableName, i, "DOSYA_MASRAF_NET"));
		        	birBasvuruHakemHeyetiTx.setDosyaMasrafBsmv(iMap.getBigDecimal(tableName, i, "DOSYA_MASRAF_BSMV"));
		        	birBasvuruHakemHeyetiTx.setKrdHesapNo(iMap.getBigDecimal(tableName, i, "KRD_HESAP_NO"));
		        	birBasvuruHakemHeyetiTx.setPttBasvuruMasraf(iMap.getBigDecimal(tableName, i, "PTT_BASVURU_MASRAF"));
		        	birBasvuruHakemHeyetiTx.setPttKulMasraf(iMap.getBigDecimal(tableName, i, "PTT_KUL_MASRAF"));
		        	birBasvuruHakemHeyetiTx.setDigerMasraf(iMap.getBigDecimal(tableName, i, "DIGER_MASRAF"));		        
		        	birBasvuruHakemHeyetiTx.setIadeMasrafTutari(iMap.getBigDecimal(tableName, i, "IADE_MASRAF_TUTARI"));
		            birBasvuruHakemHeyetiTx.setIadeSigortaTutari(iMap.getBigDecimal(tableName, i, "IADE_SIGORTA_TUTARI"));      
		        	birBasvuruHakemHeyetiTx.setVergiOdendiMi(iMap.getBoolean(tableName, i, "VERGI_ODENDI_MI")?"E":"H");
		        	birBasvuruHakemHeyetiTx.setHesapDurum(iMap.getString(tableName, i, "HESAP_DURUM"));
		        	birBasvuruHakemHeyetiTx.setTebligatTutari(iMap.getBigDecimal("TEBLIGAT_TUTARI"));
		        	birBasvuruHakemHeyetiTx.setTebligatTarihi(iMap.getDate("TEBLIGAT_TARIHI"));
		        	birBasvuruHakemHeyetiTx.setOdemeTarihi(iMap.getDate("ODEME_TARIHI"));
		        	if (i==0) {
		        		birBasvuruHakemHeyetiTx.setInkarTazminati(iMap.getBigDecimal("INKAR_TAZMINATI"));
					}else{
						birBasvuruHakemHeyetiTx.setInkarTazminati(new BigDecimal(0));
					}
		        	
		            birBasvuruHakemHeyetiTx.setId(birBasvuruHakemHeyetiTxId);	        		        		        	
		        	session.saveOrUpdate(birBasvuruHakemHeyetiTx);
		        	count++;
	        	}
	        }
	        if(count==0) {
	        	throw new GMRuntimeException(0,"Kay�t Se�iniz.");
	        }
	        session.flush();
	       
	        iMap.put("TRX_NAME", "3280");	      
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));

			}
		
		catch(Exception e) {
			logger.error("BNSPR_TRN3280_SAVE err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3280_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String tableName="TABLO";
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> list = (List<?>) session
					.createCriteria(BirBasvuruHakemHeyetiTx.class)
					.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
					.addOrder(Order.asc("kullandirimTarihi"))
					.list();
			
			int i=0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {

				BirBasvuruHakemHeyetiTx tx = (BirBasvuruHakemHeyetiTx) iterator.next();
				BirBasvuruHakemHeyetiTxId txId = tx.getId();
				
				oMap.put("MUSTERI_NO", txId.getMusteriNo());
				oMap.put("TC_KIMLIK_NO", tx.getTcKimlikNo());
				oMap.put("HAKEM_HEYETI", tx.getHakemHeyeti());
				oMap.put("KARAR_NO", tx.getKararNo());
				oMap.put("ACIKLAMA", tx.getAciklama());
				oMap.put("TEBLIGAT_UCRETI", tx.getTebligatTutari());
				oMap.put("TEBLIGAT_TARIHI", tx.getTebligatTarihi());
				oMap.put("INKAR_TAZMINATI", tx.getInkarTazminati());
				oMap.put(tableName, i, "BASVURU_NO", txId.getBasvuruNo());
				oMap.put(tableName, i, "ALACAK_HESAP_NO", tx.getAlacakHesapNo());
				oMap.put(tableName, i, "ALINAN_MASRAF_TUTARI", tx.getAlinanMasrafTutari() );
				oMap.put(tableName, i, "ALINAN_SIGORTA_TUTARI", tx.getAlinanSigortaTutari());
				oMap.put(tableName, i, "KULLANDIRIM_TARIHI", tx.getKullandirimTarihi());
				oMap.put(tableName, i, "DOSYA_MASRAF_GELIR", tx.getDosyaMasrafGelir());
				oMap.put(tableName, i, "DOSYA_MASRAF_NET", tx.getDosyaMasrafNet());
				oMap.put(tableName, i, "DOSYA_MASRAF_BSMV", tx.getDosyaMasrafBsmv());
				oMap.put(tableName, i, "KRD_HESAP_NO", tx.getKrdHesapNo());
				oMap.put(tableName, i, "PTT_BASVURU_MASRAF", tx.getPttBasvuruMasraf());
				oMap.put(tableName, i, "PTT_KUL_MASRAF", tx.getPttKulMasraf());
				oMap.put(tableName, i, "DIGER_MASRAF", tx.getDigerMasraf());		        
				oMap.put(tableName, i, "IADE_MASRAF_TUTARI", tx.getIadeMasrafTutari());
				oMap.put(tableName, i, "IADE_SIGORTA_TUTARI", tx.getIadeSigortaTutari());      
				oMap.put(tableName, i, "VERGI_ODENDI_MI", tx.getVergiOdendiMi()=="E"?true:false);
				oMap.put(tableName, i, "HESAP_DURUM", tx.getHesapDurum());
				
				i++;
			}
			return oMap;
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3280_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		GMMap kLInput = new GMMap();
		GnlMusteri mus = null;
		
		BigDecimal iadeSigortaTutari = BigDecimal.ZERO;
		BigDecimal iadeMasrafTutari = BigDecimal.ZERO;
		BigDecimal inkarTazminati = BigDecimal.ZERO;
		BigDecimal iadeTutari = BigDecimal.ZERO;
		String telefonNo = null;
		String adSoyad = null;
		BigDecimal musteriNo = null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		String date = sdf.format(new Date()); 
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> list = (List<?>) session
					.createCriteria(BirBasvuruHakemHeyetiTx.class)
					.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("ISLEM_NO")))
					.addOrder(Order.asc("kullandirimTarihi"))
					.list();
				
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirBasvuruHakemHeyetiTx tx = (BirBasvuruHakemHeyetiTx) iterator.next();
				BirBasvuruHakemHeyetiTxId txId = tx.getId();
				if(mus == null){
					mus =(GnlMusteri)session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", txId.getMusteriNo())).list().get(0);
				}
				
				musteriNo = mus.getMusteriNo();
				
				kLInput = new GMMap();
				kLInput.clear();
				
				kLInput.put("TRX_NO", ServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
				kLInput.put("TCKN", mus.getTcKimlikNo());
				kLInput.put("ISIM", mus.getAdi().toUpperCase());
				if(mus.getIkinciAdi() != null && !"".equals(mus.getIkinciAdi())){
					kLInput.put("IKINCI_ISIM", mus.getIkinciAdi().toUpperCase());
				}
				kLInput.put("SOYADI", mus.getSoyadi().toUpperCase());
				kLInput.put("KAYIT_SEBEBI", "32");
				kLInput.put("KAYNAK", "5");
				kLInput.put("KAYNAK_ACIKLAMA", "HAKEM HEYETI GERI IADE EKRANINDAN YAPILAN ��LEM");
				kLInput.put("KAYIT_DURUM", "A");
				kLInput.put("KAYIT_KATEGORISI", "9");
				
				if(!(tx.getIadeMasrafTutari() == null || tx.getIadeMasrafTutari().equals(BigDecimal.ZERO))){
					if(tx.getIadeSigortaTutari() == null || tx.getIadeSigortaTutari().equals(BigDecimal.ZERO)){
						kLInput.put("TARAF_BILGISI", "27");
					}
					else{
						kLInput.put("TARAF_BILGISI", "26");
					}
				}else{
					kLInput.put("TARAF_BILGISI", "26");
				}
				
				ServiceExecuter.execute("BNSPR_TRN3921_SAVE", kLInput);
				
	        	iadeMasrafTutari = iadeMasrafTutari.add(nvl(tx.getIadeMasrafTutari(), BigDecimal.ZERO));
	        	iadeSigortaTutari = iadeSigortaTutari.add(nvl(tx.getIadeSigortaTutari(), BigDecimal.ZERO)); 
	        	inkarTazminati = inkarTazminati.add(nvl(tx.getInkarTazminati(), BigDecimal.ZERO)); 
	        	
			}
	        iadeTutari = iadeMasrafTutari.add(iadeSigortaTutari);
	        iadeTutari = iadeTutari.add(inkarTazminati);
	        
	        List<Object> inputList = new ArrayList<Object>();
	        List<?> listMusteri = LOVExecuter.execute("3280/LOV_MUSTERI_NO", musteriNo.toString() + "%", inputList);
			if(listMusteri.size() > 0){
				telefonNo = (String) ((HashMap<?, ?>)listMusteri.get(0)).get("TELEFON_NO");
				adSoyad = (String) ((HashMap<?, ?>)listMusteri.get(0)).get("AD_SOYAD");
			}
	        
			// Case: Musteri uzerinde kayitli gsm + iletisim telefonu mevcut ise ve iade tutari var ise SMS gonderimi yapilacak
			if(telefonNo != null && iadeTutari.compareTo(BigDecimal.ZERO) == 1) {
				
				GMMap smsMap = new GMMap();
				smsMap.put("MSISDN", telefonNo);
				smsMap.put("CONTENT", 
					(iadeMasrafTutari.compareTo(BigDecimal.ZERO) == 1 && iadeSigortaTutari.equals(BigDecimal.ZERO)) ? 
					// Case: Iade masraf tutari var, iade sigorta tutari yok ise
					GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 5226).put("P1", adSoyad).put("P2", iadeTutari).put("P3", date)).getString("ERROR_MESSAGE") :
					// Case: Iade masraf tutari ve iade sigorta tutari var ise
					GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", new GMMap().put("MESSAGE_NO", 5227).put("P1", adSoyad).put("P2", iadeTutari).put("P3", date)).getString("ERROR_MESSAGE"));
				smsMap.put("MUSTERI_NO", musteriNo);
				smsMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
				GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS_ASYNC", smsMap);
			}
			
		}catch (Exception e) {
			logger.error("BNSPR_TRN3280_AFTER_APPROVAL err: " + e);
			throw new GMRuntimeException(0, e);
		}
		
		return new GMMap();
	}
	
	@GraymoundService("BNSPR_TRN3280_IADE_HESAPLA")
	public static GMMap iadeHesapla(GMMap iMap) {
		String tableName = "TABLO";
		GMMap oMap = new GMMap();
		BigDecimal iadeMasraf = BigDecimal.ZERO;
		BigDecimal iadeSigorta = BigDecimal.ZERO;
		
		for (int i = 0; i < iMap.getSize(tableName); i++) {
			iadeMasraf = iadeMasraf.add(nvl(iMap.getBigDecimal(tableName, i, "IADE_MASRAF_TUTARI"), BigDecimal.ZERO));
			iadeSigorta = iadeSigorta.add(nvl(iMap.getBigDecimal(tableName, i, "IADE_SIGORTA_TUTARI"), BigDecimal.ZERO));
		}
        
		oMap.put("IADE_MASRAF", iadeMasraf);
		oMap.put("IADE_SIGORTA", iadeSigorta);
		oMap.put("IADE_TUTARI", iadeMasraf.add(iadeSigorta));
		
        return oMap;
	}
	
	public static <T> T nvl(T a, T b) {
		return (a != null) ? a : b;
	}
	
	
	@GraymoundService("BNSPR_TRN3280_COMPARE_PARAMETER_AND_USED_CREDIT_DATE")
	public static GMMap compareParameterAndUsedCreditDate(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "TABLO";
		boolean greaterThanParemeterDate = false;
		int len = iMap.getSize(tableName);

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", iMap.getString("PARAMETER"))).uniqueResult();
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
			Date parameterDate = formatter.parse(parametre.getDeger());

			for (int i = 0; i < len; i++) {
				if ((iMap.getBigDecimal(tableName, i, "BASVURU_NO") != null) && (iMap.getBoolean(tableName, i, "SEC"))) {
					if (iMap.getDate(tableName, i, "KULLANDIRIM_TARIHI").compareTo(parameterDate) > 0) {
						greaterThanParemeterDate = true;
					}
				}
			}
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}

		oMap.put("IS_WARN", greaterThanParemeterDate);

		return oMap;

	}
}
