package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirHakemHeyetiiadeYazi;
import tr.com.aktifbank.bnspr.dao.BirHakemHeyetiiadeYaziId;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriAdres;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3257Services {
	
	private static String IADE_YOK = "0";
	private static String IADE_TIP_MASRAF = "1";
	private static String IADE_TIP_SIGORTA = "2";
	private static String IADE_TIP_MASRAF_SIGORTA = "3";
	
	@GraymoundService("BNSPR_GET_IADE_LIST_FROM_BIR_BASVURU_HAKEM_HEYET")
	public static GMMap getIadeListFromBirBasvuruHakemHeyet(GMMap iMap){
		GMMap oMap = new GMMap();
		GMMap tMap = new GMMap();
		BigDecimal custId = BigDecimal.ZERO;
		BigDecimal appNo = BigDecimal.ZERO;
		String tableName = "RESULTS";
		
		try {
			custId = iMap.getBigDecimal("MUSTERI_NO", BigDecimal.ZERO);
			appNo = iMap.getBigDecimal("BASVURU_NO", BigDecimal.ZERO);
			String fetchQuery = String.format("SELECT H.MUSTERI_NO, H.TC_KIMLIK_NO, H.BASVURU_NO, H.ALINAN_MASRAF_TUTARI, H.IADE_MASRAF_TUTARI, TRUNC(REC_DATE) IADE_TARIHI, " +
												"H.ALINAN_SIGORTA_TUTARI, H.IADE_SIGORTA_TUTARI, H.VERGI_ODENDI_MI, H.KULLANDIRIM_TARIHI, H.ALACAK_HESAP_NO " +
												"FROM BNSPR.BIR_BASVURU_HAKEM_HEYETI_TX H, MUH_ISLEM M " +
												"WHERE H.MUSTERI_NO = NVL(%s, H.MUSTERI_NO) AND H.BASVURU_NO = NVL(%s, H.BASVURU_NO) AND M.NUMARA = H.TX_NO AND M.DURUM='P' ", custId, appNo);
			
			tMap =  DALUtil.getResults(fetchQuery, tableName);

			for (int i = 0; i < tMap.getSize(tableName); i++) {
				BigDecimal iadeMasraf = tMap.getBigDecimal(tableName, i, "IADE_MASRAF_TUTARI");
				BigDecimal iadeSigorta = tMap.getBigDecimal(tableName, i, "IADE_SIGORTA_TUTARI");

				if (iadeMasraf != null && iadeMasraf.compareTo(BigDecimal.ZERO) == 1 && iadeSigorta != null && iadeSigorta.compareTo(BigDecimal.ZERO) == 1) {
					oMap.put(tableName, i, "IADE_TIP", IADE_TIP_MASRAF_SIGORTA);
				}
				else if (iadeMasraf != null && iadeMasraf.compareTo(BigDecimal.ZERO) == 1) {
					oMap.put(tableName, i, "IADE_TIP", IADE_TIP_MASRAF);
				}
				else if(iadeSigorta != null && iadeSigorta.compareTo(BigDecimal.ZERO) == 1){
					oMap.put(tableName, i, "IADE_TIP", IADE_TIP_SIGORTA);
				}else {
					oMap.put(tableName, i, "IADE_TIP", IADE_YOK);
				}

				oMap.put(tableName, i, "MUSTERI_NO", tMap.get("RESULTS", i, "MUSTERI_NO"));
				oMap.put(tableName, i, "BASVURU_NO", tMap.get("RESULTS", i, "BASVURU_NO"));
				oMap.put(tableName, i, "ALACAK_HESAP_NO", tMap.get("RESULTS", i, "ALACAK_HESAP_NO"));
				oMap.put(tableName, i, "ALINAN_MASRAF_TUTARI", tMap.get("RESULTS", i, "ALINAN_MASRAF_TUTARI"));
				oMap.put(tableName, i, "IADE_EDILEN_MASRAF_TUTARI", tMap.get("RESULTS", i, "IADE_MASRAF_TUTARI"));
				oMap.put(tableName, i, "ALINAN_SIGORTA_TUTARI", tMap.get("RESULTS", i, "ALINAN_SIGORTA_TUTARI"));
				oMap.put(tableName, i, "IADE_EDILEN_SIGORTA_TUTARI", tMap.get("RESULTS", i, "IADE_SIGORTA_TUTARI"));
				oMap.put(tableName, i, "IADE_TARIHI", tMap.get("RESULTS", i, "IADE_TARIHI"));
				oMap.put(tableName, i, "VERGI_ODENDI_MI", nvl(tMap.get("RESULTS", i, "VERGI_ODENDI_MI"), StringUtils.EMPTY).equals("E"));
				oMap.put(tableName, i, "KULLANDIRIM_TARIHI", tMap.get("RESULTS", i, "KULLANDIRIM_TARIHI"));
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3257_CREATE_HAKEM_HEYET_IADE_TEXT")
	public static GMMap createHakemIadeText(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = null;
		BigDecimal custId = BigDecimal.ZERO;
		BigDecimal masrafTutar = BigDecimal.ZERO;
		BigDecimal sigortaTutar = BigDecimal.ZERO;
		int oMapTableSize = 0;
		
		try {
			session = DAOSession.getSession("BNSPRDal");
			
			for(int i = 0; i < iMap.getSize("TABLE"); i++){
				if(iMap.getInt("TABLE", i, "SEC") == 1 && !iMap.getString("TABLE", i, "IADE_TIP").equals(IADE_YOK)){
					custId = iMap.getBigDecimal("TABLE", i, "MUSTERI_NO");
					masrafTutar = nvl(iMap.getBigDecimal("TABLE", i, "IADE_EDILEN_MASRAF_TUTARI"), BigDecimal.ZERO);
				    sigortaTutar = nvl(iMap.getBigDecimal("TABLE", i, "IADE_EDILEN_SIGORTA_TUTARI"), BigDecimal.ZERO);
				    
					GnlMusteri gnlMusteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("musteriNo", custId)).uniqueResult();
					String custName = gnlMusteri.getAdi().concat(" ").concat(nvl(gnlMusteri.getIkinciAdi(), StringUtils.EMPTY));
					String lastName = gnlMusteri.getSoyadi();
					String tckn = gnlMusteri.getTcKimlikNo();
					String address = StringUtils.EMPTY;
					
					List<GnlMusteriAdres> musteriAdres = (List<GnlMusteriAdres>) session.createCriteria(GnlMusteriAdres.class).add(Restrictions.eq("id.musteriNo", custId)).list();
					
					for (GnlMusteriAdres gnlMusteriAdres : musteriAdres) {
						if("E".equals(gnlMusteriAdres.getExtreAdresiMi())){
							 address = gnlMusteriAdres.getAdres();
						}
					}
					
					if(StringUtils.isEmpty(address)){
						oMap.put("MESSAGE", "M��teriye ait adres bulunamad�!");
						return oMap;
					}
					
					oMap.put("TABLE", oMapTableSize, "AD_SOYAD", custName.trim().concat(" ").concat(lastName));
					oMap.put("TABLE", oMapTableSize, "TC_KIMLIK_NO", tckn);
					oMap.put("TABLE", oMapTableSize, "ADRES", address);
					oMap.put("TABLE", oMapTableSize, "HESAP_NO", iMap.getString("TABLE", i, "ALACAK_HESAP_NO"));
					oMap.put("TABLE", oMapTableSize, "IADE_TUTAR", masrafTutar.add(sigortaTutar));
					oMap.put("TABLE", oMapTableSize, "IADE_TARIHI", iMap.getString("TABLE", i, "IADE_TARIHI"));

					if(iMap.getString("TABLE", i, "IADE_TIP").equals(IADE_TIP_MASRAF)){
						oMap.put("TABLE", oMapTableSize, "IADE_TIP_TEXT", "kredi tahsis �creti");
						oMap.put("TABLE", oMapTableSize, "IADE_TIP_TEXT2", "kredi tahsis �creti");
					}else if(iMap.getString("TABLE", i, "IADE_TIP").equals(IADE_TIP_SIGORTA)) {
						oMap.put("TABLE", oMapTableSize, "IADE_TIP_TEXT", "kredi sigorta prim tutar�");
						oMap.put("TABLE", oMapTableSize,"IADE_TIP_TEXT2", "kredi sigorta prim tutar�");
					}else if (iMap.getString("TABLE", i, "IADE_TIP").equals(IADE_TIP_MASRAF_SIGORTA)) {
						oMap.put("TABLE", oMapTableSize,"IADE_TIP_TEXT", "kredi tahsis �creti, kredi sigorta prim tutar�");
						oMap.put("TABLE", oMapTableSize,"IADE_TIP_TEXT2", "kredi tahsis �creti ve kredi sigorta prim tutar�");
					}
					
					oMapTableSize++;
				}
				
			}
			
			if(oMapTableSize < 1){
				oMap.put("MESSAGE", "D�k�man olu�turmak i�in iadesi olan, en az bir kay�t se�melisiniz!");
			}else {
				oMap.putAll(GMServiceExecuter.call("BNSPR_HAKEM_HEYET_IADE_TEXT", oMap));
			}
			
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_LOG_HAKEM_HEYET_IADE_DOCUMENT")
	public static GMMap logHakemHeyetIadeDocument(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		BigDecimal masrafTutar = BigDecimal.ZERO;
		BigDecimal sigortaTutar = BigDecimal.ZERO;
		
		try {

			for (int i = 0; i < iMap.getSize("TABLE"); i++) {
				masrafTutar = nvl(iMap.getBigDecimal("TABLE", i, "IADE_EDILEN_MASRAF_TUTARI"), BigDecimal.ZERO);
			    sigortaTutar = nvl(iMap.getBigDecimal("TABLE", i, "IADE_EDILEN_SIGORTA_TUTARI"), BigDecimal.ZERO);
			    
			    if(masrafTutar.add(sigortaTutar).compareTo(BigDecimal.ZERO) == 1){
			    	BirHakemHeyetiiadeYazi iadeYazi = new BirHakemHeyetiiadeYazi();
			    	BirHakemHeyetiiadeYaziId iadeYAziId = new BirHakemHeyetiiadeYaziId();
			    	iadeYAziId.setBasvuruNo(iMap.getBigDecimal("TABLE", i, "BASVURU_NO"));
			    	iadeYAziId.setMusteriNo(iMap.getBigDecimal("TABLE", i, "MUSTERI_NO"));
			    	iadeYAziId.setIadeMasrafTutari(nvl(iMap.getBigDecimal("TABLE", i, "IADE_EDILEN_MASRAF_TUTARI"), BigDecimal.ZERO));
			    	iadeYAziId.setIadeSigortaTutari(nvl(iMap.getBigDecimal("TABLE", i, "IADE_EDILEN_SIGORTA_TUTARI"), BigDecimal.ZERO));
			    	iadeYazi.setId(iadeYAziId);
			    	session.save(iadeYazi);
			    }
			}
			
			session.flush();
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}finally{
			session.close();
		}
		
		return oMap;
	}
	
	private static <T> T nvl(T a, T b) {
		return (a != null) ? a : b;
	}
	
	@GraymoundService("BNSPR_QRY3257_SELECT_ALL")
	public static GMMap selectAll(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (iMap.getBoolean("CHECKED")) {
				for (int i = 0; i < iMap.getSize("TABLE"); i++) {
					iMap.put("TABLE", i, "SEC", 1);
				}
			}
			else {
				for (int i = 0; i < iMap.getSize("TABLE"); i++) {
					iMap.put("TABLE", i, "SEC", 0);
				}
			}
			oMap.put("TABLE", iMap.get("TABLE"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}

	}

}
