package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3183Services {

	@SuppressWarnings("unchecked")
	private static <T, T1, T2> T2 nvl(T a, T1 b) {
        if (a instanceof String) {
            return (T2) (StringUtils.isBlank((String) a) ? b : a);
        }
        return (T2) ((a == null) ? b : a);
    }

	@GraymoundService("BNSPR_QRY3183_GET_ODEME_PLANI")
	public static GMMap getOdemePlani(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rs = null;
		
		int indexSozlesmeOrani;
		int indexOdemePlani;
		int indexCostRatio;
		int indexDosyaMasraf;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_basvuru.OdemePlaniSimulasyonu(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			int pc = 1;
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("FAIZ_ORANI"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KREDI_TURU"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
			if(iMap.getBigDecimal("KRD_TUR_ALT_KOD") == null)
				stmt.setBigDecimal(pc++, iMap.getBigDecimal("KAMPANYA_KODU"));
			else
				stmt.setBigDecimal(pc++, null);
			stmt.setString(pc++, iMap.getString("KANAL_KOD"));
			stmt.setString(pc++, iMap.getString("DOVIZ_KOD"));

			BigDecimal krediTutari = iMap.getBigDecimal("KREDI_TUTARI", BigDecimal.ZERO);
			{
				String sigortalar="SIGORTALAR", prim = "PRIM", adet = "ADET";
				if (iMap.containsKey(sigortalar) && iMap.get(sigortalar)!=null){
					for (int i=0, size=iMap.getSize(sigortalar); i<size;i++) {
						krediTutari = krediTutari.add(((BigDecimal) nvl(iMap.getBigDecimal(sigortalar, i, prim), BigDecimal.ZERO)).multiply((BigDecimal) nvl(iMap.getBigDecimal(sigortalar, i, adet), BigDecimal.ZERO)));
					}
				}
			}

			stmt.setBigDecimal(pc++, krediTutari);
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KREDI_VADE"));
			stmt.setString(pc++, iMap.getString("ODEME_TIP_KOD"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("ODEME_TIP_PERIYOD"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("ODEME_TIP_TUTAR"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("ODEME_TIP_ORAN"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("ODEME_TIP_VADE"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KATKI_PAYI"));
			stmt.setDate(pc++, null); //pd_sozlesme_tarihi
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("GECIKME_GUN_SAYISI")); //pn_gecikme_gun_sayisi
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("FARK_FAIZI"));
			stmt.setString(pc++, iMap.getString("FAIZ_ODEME_SEKLI")); //pc_ilk_taksit_yontem
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("WEEKEND")); //weekend care
			stmt.setString(pc++, (iMap.getString("PERIYOD_TIPI") == null) ? "M" : iMap.getString("PERIYOD_TIPI")); //odeme periyod tipi
			stmt.setBigDecimal(pc++, (iMap.getBigDecimal("PERIYOD") == null || iMap.getBigDecimal("PERIYOD").compareTo(BigDecimal.ZERO) <= 0)? BigDecimal.ONE : iMap.getBigDecimal("PERIYOD")); //odeme periyodu
			indexOdemePlani = pc;
			stmt.registerOutParameter(pc++, -10); //ref cursor
			indexSozlesmeOrani = pc;
			stmt.registerOutParameter(pc++, Types.NUMERIC);
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("MAAS_TARIH_SIKLIGI"));
			if(iMap.get("PTT_ILK_TAKSIT_TARIHI")!=null)
				stmt.setDate(pc++, new Date(iMap.getDate("PTT_ILK_TAKSIT_TARIHI").getTime()));
			else 
				stmt.setDate(pc++, null);
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("DOSYA_MASRAFI"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KAMP_KNL_KOD"));
			indexCostRatio = pc;
			stmt.registerOutParameter(pc++, Types.NUMERIC);
			indexDosyaMasraf = pc;
			stmt.registerOutParameter(pc++, Types.NUMERIC);
			
			stmt.execute();
			BigDecimal faizOrani = stmt.getBigDecimal(indexSozlesmeOrani);
			oMap.put("SOZLESME_FAIZ_ORANI", faizOrani);
			stmt.getMoreResults();
			rs = (ResultSet)stmt.getObject(indexOdemePlani);
			String tableName = "ODEME_PLANI";
			oMap.put("COST_RATIO", stmt.getBigDecimal(indexCostRatio));
			oMap.put("MAX_DOSYA_MASRAFI", stmt.getBigDecimal(indexDosyaMasraf));
			BigDecimal toplamTaksitTutari = BigDecimal.ZERO;
			BigDecimal toplamAnapara = BigDecimal.ZERO;
			BigDecimal toplamFaiz = BigDecimal.ZERO;
			BigDecimal toplamKKDF = BigDecimal.ZERO;
			BigDecimal toplamBSMV = BigDecimal.ZERO;
			int i = 0;
			while (rs.next()) {
				oMap.put(tableName, i, "OP_TAKSIT_TARIHI", rs.getDate(1));
				oMap.put(tableName, i, "OP_TAKSIT_TUTAR", rs.getBigDecimal(2));
				toplamTaksitTutari = toplamTaksitTutari.add(rs.getBigDecimal(2));
				oMap.put(tableName, i, "OP_ANAPARA", rs.getBigDecimal(3));
				toplamAnapara = toplamAnapara.add(rs.getBigDecimal(3));
				oMap.put(tableName, i, "OP_FAIZ", rs.getBigDecimal(4));
				toplamFaiz = toplamFaiz.add(rs.getBigDecimal(4));
				oMap.put(tableName, i, "OP_KKDF", rs.getBigDecimal(5));
				toplamKKDF = toplamKKDF.add(rs.getBigDecimal(5));
				oMap.put(tableName, i, "OP_BSMV", rs.getBigDecimal(6));
				toplamBSMV = toplamBSMV.add(rs.getBigDecimal(6));
				oMap.put(tableName, i, "OP_KALAN_TUTAR", rs.getBigDecimal(7));
				oMap.put(tableName, i, "OP_TAKSIT_NO", i + 1);
				oMap.put(tableName, i, "OP_MASRAF", new BigDecimal(0)); // simulasyon i�in �imdilik masraf s�f�r isteniyor 
				oMap.put(tableName, i, "OP_AYLIK_TOPLAM", rs.getBigDecimal(2)); // masraf s�f�r oldu�u i�in taksit tutar� ile ayn�
				oMap.put(tableName, i, "GRP", 1 + i / 12); //raporda y�ll�k t oplamlar� bulmak i�in grup bu alan g�re gruplama yap�l�yor
				i++;
			}
			oMap.put("TOPLAM_TAKSIT_TUTARI", toplamTaksitTutari);
			oMap.put("TOPLAM_ANAPARA", toplamAnapara);
			oMap.put("TOPLAM_FAIZ", toplamFaiz);
			oMap.put("TOPLAM_KKDF", toplamKKDF);
			oMap.put("TOPLAM_BSMV", toplamBSMV);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(rs);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3183_ODEME_PLANI_REPORT_DATA_SOURCE")
	public static GMMap reportDataSource(GMMap iMap) {
		try {
			GMMap oMap =new GMMap();
//			HashMap<String, Object> oMap = new HashMap<String, Object>();
			ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
			String listName = "COLLECTION";
			for (int i = 0; i < iMap.getSize(listName); i++) {
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				
				rowData.put("OP_TAKSIT_TARIHI", iMap.getDate(listName, i, "OP_TAKSIT_TARIHI"));
				rowData.put("OP_TAKSIT_TUTAR", iMap.getBigDecimal(listName, i, "OP_TAKSIT_TUTAR"));
				rowData.put("OP_ANAPARA", iMap.getBigDecimal(listName, i, "OP_ANAPARA"));
				rowData.put("OP_FAIZ", iMap.getBigDecimal(listName, i, "OP_FAIZ"));
				rowData.put("OP_KKDF", iMap.getBigDecimal(listName, i, "OP_KKDF"));
				rowData.put("OP_BSMV", iMap.getBigDecimal(listName, i, "OP_BSMV"));
				rowData.put("OP_KALAN_TUTAR", iMap.getBigDecimal(listName, i, "OP_KALAN_TUTAR"));
				rowData.put("OP_TAKSIT_NO", i + 1);
				rowData.put("OP_MASRAF", new BigDecimal(0));  
				rowData.put("OP_AYLIK_TOPLAM", iMap.getBigDecimal(listName, i, "OP_AYLIK_TOPLAM")); 
				rowData.put("GRP", new BigDecimal(1 + i / 12)); 
				
				list.add(rowData);
			}
			oMap.put("REPORT_DATA", list);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY3183_GET_ODEME_TIP")
	public static GMMap getOdemeTipAciklama(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_bireysel.OdemeTip(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ODEME_TIP_KOD"));
			stmt.execute();
			
			GMMap oMap =  new GMMap();
			oMap.put("ODEME_SEKLI", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3183_GET_KAMP_KNL_KOD_WITHOUT_EXEPTION")
	public static GMMap getKampKanalKodWithoutExp(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_KAMP_KNL_KOD", iMap));
		} catch (Exception e) {}
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY3183_KREDI_TAKSIT_HESAPLA")
	public static GMMap krediTaksitHesapla(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap =  new GMMap();
			if(iMap.getBigDecimal("KREDI_VADE") == null || iMap.getBigDecimal("KREDI_VADE").equals(new BigDecimal(0)))
				return oMap;
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_basvuru.taksit_hesapla(?,?,?,?,?,?,?,?,?)}");
			int pc = 1;
			stmt.registerOutParameter(pc++, Types.FLOAT);
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KREDI_TURU"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
			if(iMap.getBigDecimal("KRD_TUR_ALT_KOD") == null)
				stmt.setBigDecimal(pc++, iMap.getBigDecimal("KAMP_KOD"));
			else
				stmt.setBigDecimal(pc++, null);
			stmt.setString(pc++, iMap.getString("KANAL_KOD"));
			stmt.setString(pc++, iMap.getString("DOVIZ_KOD"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KREDI_TUTARI"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KREDI_VADE"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KAMP_KNL_KOD"));
			
			stmt.execute();
			
			oMap.put("KREDI_TAKSIT_TUTARI", stmt.getBigDecimal(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3183_KREDI_VADE_HESAPLA")
	public static GMMap krediVadeHesapla(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap =  new GMMap();
			if(iMap.getBigDecimal("KREDI_TAKSIT_TUTARI") == null || iMap.getBigDecimal("KREDI_TAKSIT_TUTARI").equals(new BigDecimal(0)))
				return oMap;
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_basvuru.vade_hesapla(?,?,?,?,?,?,?,?,?,?)}");
			int pc = 1;
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KREDI_TURU"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
			if(iMap.getBigDecimal("KRD_TUR_ALT_KOD") == null)
				stmt.setBigDecimal(pc++, iMap.getBigDecimal("KAMP_KOD"));
			else
				stmt.setBigDecimal(pc++, null);
			stmt.setString(pc++, iMap.getString("KANAL_KOD"));
			stmt.setString(pc++, iMap.getString("DOVIZ_KOD"));
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KREDI_TUTARI"));
			stmt.setBigDecimal(pc, iMap.getBigDecimal("KREDI_TAKSIT_TUTARI"));
			stmt.registerOutParameter(pc++, Types.FLOAT);
			stmt.registerOutParameter(pc++, Types.FLOAT);
			stmt.setBigDecimal(pc++, iMap.getBigDecimal("KAMP_KNL_KOD"));
			
			stmt.execute();

			oMap.put("KREDI_VADE", stmt.getBigDecimal(9));
			oMap.put("KREDI_TAKSIT_TUTARI", stmt.getBigDecimal(8));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
