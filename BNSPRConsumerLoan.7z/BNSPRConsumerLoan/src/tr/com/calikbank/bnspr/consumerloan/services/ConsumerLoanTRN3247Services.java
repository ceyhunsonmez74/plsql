package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.FileNotFoundException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.tree.DefaultMutableTreeNode;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirSaticiYetkiTanimTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiYetkiTanimTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirSatici;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisan;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisanTx;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisanTxId;
import tr.com.calikbank.bnspr.dao.BirSaticiIliski;
import tr.com.calikbank.bnspr.dao.BirSaticiIliskiTx;
import tr.com.calikbank.bnspr.dao.BirSaticiIliskiTxId;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisFaaliyet;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisFaaliyetTx;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisFaaliyetTxId;
import tr.com.calikbank.bnspr.dao.BirSaticiTx;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3247Services {
    
    @GraymoundService("BNSPR_3247_FILL_COMBOBOX_INITIAL_VALUE")
    public static GMMap fillComboBoxInitialValues(GMMap iMap) {
        try{
            GMMap oMap = new GMMap();
            
            iMap.put("ADD_EMPTY_KEY" , "E");
            iMap.put("KOD" , "SATICI_TIP_KOD");
            oMap.put("SATICI_TIP" , GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS" , iMap).get("RESULTS"));
            
            iMap.put("ADD_EMPTY_KEY" , "E");
            iMap.put("KOD" , "FIRMA_TIPI");
            oMap.put("SIRKET_TIP" , GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS" , iMap).get("RESULTS"));
            
            iMap.put("ADD_EMPTY_KEY" , "E");
            iMap.put("KOD" , "SATIS_GORUS_KOD");
            oMap.put("SATICI_GORUSU" , GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS" , iMap).get("RESULTS"));
            
            iMap.put("ADD_EMPTY_KEY" , "E");
            iMap.put("KOD" , "BAGLI_OLD_BOLGE_KOD");
            oMap.put("BAGLI_OLDUGU_BOLGE" , GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS" , iMap).get("RESULTS"));
            
            iMap.put("ADD_EMPTY_KEY" , "E");
            iMap.put("KOD" , "DOK_YOLLAMA_KOD");
            oMap.put("DOKUMAN_YOLLAMA_TIPI" , GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS" , iMap).get("RESULTS"));
            
            iMap.put("ADD_EMPTY_KEY" , "E");
            iMap.put("KOD" , "YETKI_SEVIYE_KOD");
            oMap.put("YETKI_SEVIYESI" , GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS" , iMap).get("RESULTS"));
            
            iMap.put("ADD_EMPTY_KEY" , "H");
            iMap.put("KOD" , "CAL_STATU_KOD");
            oMap.put("CALISAN_STATU" , GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS" , iMap).get("RESULTS"));
            
            iMap.put("ADD_EMPTY_KEY" , "H");
            iMap.put("KOD" , "YETKI_SEVIYE_KOD");
            oMap.put("YETKI_SEVIYESI" , GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS" , iMap).get("RESULTS"));
            
            iMap.put("ADD_EMPTY_KEY" , "H");
            iMap.put("KOD" , "TUTTUGU_TAKIM_KOD");
            oMap.put("TUTTUGU_TAKIM" , GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS" , iMap).get("RESULTS"));
            
            iMap.put("ADD_EMPTY_KEY" , "H");
            iMap.put("KOD" , "POZISYON_KOD");
            oMap.put("POZISYONU" , GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS" , iMap).get("RESULTS"));
            
            iMap.put("LOV" , "3247/LOV_UYRUK");
            iMap.put("VALUE" , "KOD");
            iMap.put("NAME" , "ACIKLAMA");
            oMap.put("UYRUK_LIST" , GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_LOV" , iMap).get("RESULTS"));
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    // BPM i�in
    @GraymoundService("BNSPR_TRN3247_SAVE")
    public static Map<?, ?> saveTRN3247(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            BirSaticiTx birSaticiTx = new BirSaticiTx();
            birSaticiTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            birSaticiTx.setKod(iMap.getBigDecimal("KOD"));
            birSaticiTx.setSaticiAdi(iMap.getString("SATICI_ADI"));
            birSaticiTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
            // birSaticiTx.setTanimlamaTar(iMap.getDate("TANIMLAMA_TAR"));
            birSaticiTx.setSaticiTipKod(iMap.getString("SATICI_TIP_KOD"));
            birSaticiTx.setBagliMerkezBayi(iMap.getBigDecimal("BAGLI_MERKEZ_BAYI"));
            birSaticiTx.setKurulusTar(iMap.getDate("KURULUS_TAR"));
            String krdTur = GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("F_IHTIYAC"));
            krdTur = krdTur + GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("F_KONUT"));
            krdTur = krdTur + GuimlUtil.convertBinaryFromCheckBoxValue(iMap.getBoolean("F_TASIT"));
            birSaticiTx.setKrdTurKodlari(krdTur);
            birSaticiTx.setAdres(iMap.getString("SATICI_ADRES"));
            birSaticiTx.setAdresIl(iMap.getString("SATICI_IL"));
            birSaticiTx.setAdresIlce(iMap.getString("SATICI_ILCE"));
            birSaticiTx.setAlanKodTel(iMap.getString("SATICI_ALAN_KOD_TEL"));
            birSaticiTx.setTelNo(iMap.getString("SATICI_TEL_NO"));
            birSaticiTx.setAlanKodFaks(iMap.getString("SATICI_ALAN_KOD_FAKS"));
            birSaticiTx.setFaksNo(iMap.getString("SATICI_FAKS_NO"));
            birSaticiTx.setEmail(iMap.getString("EMAIL"));
            birSaticiTx.setWebAdres(iMap.getString("WEB_ADRES"));
            birSaticiTx.setBankaKod(iMap.getString("BANKA_KOD"));
            birSaticiTx.setBankaSube(iMap.getString("BANKA_SUBE"));
            birSaticiTx.setBankaHesap(iMap.getString("BANKA_HESAP"));
            birSaticiTx.setParaCikisOtoEh(iMap.getString("PARA_CIKIS_OTO_EH"));
            birSaticiTx.setSatisGorusKod(iMap.getString("SATIS_GORUS_KOD"));
            birSaticiTx.setDrm(iMap.getString("DRM"));
            birSaticiTx.setBagliOldBolgeKod(iMap.getString("BAGLI_OLD_BOLGE_KOD"));
            birSaticiTx.setDokYollamaKod(iMap.getString("DOK_YOLLAMA_KOD"));
            birSaticiTx.setBayiSorumluKisi(iMap.getBigDecimal("BAYI_SORUMLU_KISI"));
            birSaticiTx.setPortfoyKod("PORTFOY_KOD");
            session.save(birSaticiTx);
            session.flush();
            
            List<?> saticiCalisanGuiList = (List<?>) iMap.get("SATICI_CALISAN");
            String tableName = "SATICI_CALISAN";
            for (int i = 0; i < saticiCalisanGuiList.size(); i++){
                BirSaticiCalisanTx saticiCalisanTx = new BirSaticiCalisanTx();
                BirSaticiCalisanTxId id = new BirSaticiCalisanTxId();
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                id.setKod(iMap.getBigDecimal(tableName , i , "KOD"));
                saticiCalisanTx.setId(id);
                saticiCalisanTx.setSaticiKod(iMap.getBigDecimal(tableName , i , "SATICI_KOD"));
                saticiCalisanTx.setTcKimlikNo(iMap.getString(tableName , i , "TC_KIMLIK_NO"));
                saticiCalisanTx.setAdi(iMap.getString(tableName , i , "ADI"));
                saticiCalisanTx.setSoyadi(iMap.getString(tableName , i , "SOYADI"));
                saticiCalisanTx.setUyrukKod(iMap.getString(tableName , i , "UYRUK_KOD"));
                saticiCalisanTx.setDogumTarihi(iMap.getDate(tableName , i , "DOGUM_TARIHI"));
                saticiCalisanTx.setDogumYeri(iMap.getString(tableName , i , "DOGUM_YERI"));
                saticiCalisanTx.setBabaAdi(iMap.getString(tableName , i , "BABA_ADI"));
                /*
                 * saticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "YETKI_GIRIS_KOD"));
                 */
                
                if (iMap.getString(tableName , i , "YETKI_SEVIYESI") != null && iMap.getString(tableName , i , "YETKI_SEVIYESI").compareTo(iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI")) != 0){
                    saticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName , i , "YETKI_SEVIYESI"));
                    saticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate("BANKA_TARIHI"));
                    saticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI"));
                    saticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName , i , "YETKI_SEVIYESI_GUNCELLEME_TAR"));
                    
                } else
                    if (iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI") != null
                            && iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI").compareTo(iMap.getString(tableName , i , "YETKI_SEVIYESI")) != 0){
                        saticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName , i , "YETKI_SEVIYESI"));
                        saticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate("BANKA_TARIHI"));
                        saticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI"));
                        saticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName , i , "YETKI_SEVIYESI_GUNCELLEME_TAR"));
                        
                    } else
                        if (iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI") == null && iMap.getString(tableName , i , "YETKI_SEVIYESI") == null
                                || iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI").compareTo(iMap.getString(tableName , i , "YETKI_SEVIYESI")) == 0){
                            saticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName , i , "YETKI_SEVIYESI"));
                            saticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate(tableName , i , "YETKI_SEVIYESI_GUNCELLEME_TAR"));
                            saticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName , i , "ONCEKI_YETKI_SEVIYESI"));
                            saticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName , i , "ONCEKI_YETKI_SEVIYESI_GUNCELLEME_TAR"));
                        }
                
                saticiCalisanTx.setCepAlanKod(iMap.getString(tableName , i , "CEP_ALAN_KOD"));
                saticiCalisanTx.setCepTelNo(iMap.getString(tableName , i , "CEP_TEL_NO"));
                saticiCalisanTx.setEposta(iMap.getString(tableName , i , "EPOSTA"));
                saticiCalisanTx.setIseBaslamaTar(iMap.getDate(tableName , i , "ISE_BASLAMA_TAR"));
                saticiCalisanTx.setPozisyonKod(iMap.getString(tableName , i , "POZISYON_KOD"));
                saticiCalisanTx.setTuttuguTakimKod(iMap.getString(tableName , i , "TUTTUGU_TAKIM_KOD"));
                saticiCalisanTx.setHobiKod(iMap.getString(tableName , i , "HOBI_KOD"));
                saticiCalisanTx.setMusteriNo(iMap.getBigDecimal(tableName , i , "MUSTERI_NO"));
                saticiCalisanTx.setHesapNo(iMap.getBigDecimal(tableName , i , "HESAP_NO"));
                saticiCalisanTx.setDigerBankaKod(iMap.getString(tableName , i , "DIGER_BANKA_KOD"));
                saticiCalisanTx.setDigerSubeKod(iMap.getString(tableName , i , "DIGER_SUBE_KOD"));
                saticiCalisanTx.setDigerHesapNo(iMap.getString(tableName , i , "DIGER_HESAP_NO"));
                saticiCalisanTx.setArmaganKartNo(iMap.getString(tableName , i , "ARMAGAN_KART_NO"));
                // saticiCalisanTx.setCalStatuKod(iMap.getString(tableName, i, "CAL_STATU_KOD"));
                // saticiCalisanTx.setCalKismiKapanmaNedenKod(iMap.getString(tableName, i,
                // "CAL_KISMI_KAPANMA_NEDEN_KOD"));
                session.save(saticiCalisanTx);
            }
            session.flush();
            
            List<?> teminatlarGuiList = (List<?>) iMap.get("SATICI_ILISKI");
            tableName = "SATICI_ILISKI";
            for (int i = 0; i < teminatlarGuiList.size(); i++){
                BirSaticiIliskiTx birSaticiIliskiTx = new BirSaticiIliskiTx();
                BirSaticiIliskiTxId id = new BirSaticiIliskiTxId();
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                // id.setKod(iMap.getBigDecimal(tableName, i, "KOD"));
                birSaticiIliskiTx.setId(id);
                // birSaticiIliskiTx.setSaticiKod(iMap.getBigDecimal(tableName,
                // i, "SATICI_KOD"));
                // birSaticiIliskiTx.setBagliOldSatKod(iMap.getBigDecimal(tableName,
                // i, "BAGLI_OLD_SAT_KOD"));
                session.save(birSaticiIliskiTx);
            }
            session.flush();
            
            iMap.put("TRX_NAME" , "3247");
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3247_SAVE_AND_CREATE_CONTAKT")
    public static Map<?, ?> trn3247SaveAndCreateContakt(GMMap iMap) {
        try{
        	
            if (iMap.getBigDecimal("MUSTERI_NO") == null || iMap.getString("MUSTERI_NO").isEmpty()){
                iMap.put("MUSTERI_NO" , GMServiceExecuter.execute("BNSPR_TRN3247_KONTAKT_SATICI" , iMap).get("MUSTERI_NO"));
                iMap.put("MUSTERI_HESAP_NO" , iMap.getBigDecimal("DI_HESAP_NO"));
                if(iMap.getString("SATICI_TIP").equals("S")){
                  iMap.put("SUBE_MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
                }
            }else{
            	if (iMap.getString("SATICI_TIP").equals("S") && iMap.getBigDecimal("SUBE_MUSTERI_NO") == null){
                  iMap.remove("VERGI_TCK_NO");
            	  iMap.put("SUBE_MUSTERI_NO" , GMServiceExecuter.execute("BNSPR_TRN3247_KONTAKT_SATICI" , iMap).get("MUSTERI_NO"));
            	}
            	else if(iMap.getString("SATICI_TIP") == "S" && iMap.getBigDecimal("SUBE_MUSTERI_NO") != null){
            	  iMap.put("SUBE_MUSTERI_NO", iMap.getBigDecimal("SUBE_MUSTERI_NO"));	
            	}
            	
            }
             
            return GMServiceExecuter.execute("BNSPR_TRN3247_SCREEN_SAVE" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    // 3247 Ekran�na ili�kin
    @SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3247_SCREEN_SAVE")
    public static Map<?, ?> screenSaveTRN3247(GMMap iMap) {
        
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            
            BirSaticiTx birSaticiTx = (BirSaticiTx) session.get(BirSaticiTx.class , iMap.getBigDecimal("TRX_NO"));
            if (birSaticiTx == null)
                birSaticiTx = new BirSaticiTx();
            
            birSaticiTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
            birSaticiTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            birSaticiTx.setKod(iMap.getBigDecimal("SATICI_KOD"));
            birSaticiTx.setSaticiAdi(iMap.getString("DI_SATICI_KOD"));
            birSaticiTx.setSaticiTipKod(iMap.getString("SATICI_TIP"));
            birSaticiTx.setBagliOldBolgeKod(iMap.getString("BAGLI_OLDUGU_BOLGE"));
            birSaticiTx.setBagliMerkezBayi(iMap.getBigDecimal("BAGLI_OLDUGU_MERKEZ_BAYI_KOD"));
            birSaticiTx.setDokYollamaKod(iMap.getString("DOKUMAN_YOLLAMA_TIPI"));
            birSaticiTx.setDrm(iMap.getString("DURUM"));
            
            birSaticiTx.setKurulusTar(iMap.getDate("KURULUS_TARIHI"));
            birSaticiTx.setAlanKodTel(iMap.getString("SATICI_TELEFON_ALAN"));
            birSaticiTx.setTelNo(iMap.getString("SATICI_TELEFON"));
            birSaticiTx.setAlanKodFaks(iMap.getString("SATICI_FAX_ALAN"));
            birSaticiTx.setFaksNo(iMap.getString("SATICI_FAKS"));
            String emailName = iMap.getString("E_POSTA_NAME");
            String emailNet = iMap.getString("E_POSTA_NET");
            if (emailName != null && !"".equals(emailName))
                emailName = emailName + "@";
            if (emailNet != null && !"".equals(emailNet))
                emailName = emailName + emailNet;
            birSaticiTx.setEmail(emailName);
            
            birSaticiTx.setWebAdres(iMap.getString("WEB_ADRESI"));
            birSaticiTx.setAdres(iMap.getString("SATICI_ADRES"));
            birSaticiTx.setAdresIl(iMap.getString("SATICI_IL"));
            birSaticiTx.setAdresIlce(iMap.getString("SATICI_ILCE"));
            birSaticiTx.setHesapNo(iMap.getBigDecimal("MUSTERI_HESAP_NO"));
            birSaticiTx.setParaCikisOtoEh(iMap.getString("PARA_CIKISI"));
            birSaticiTx.setBankaKod(iMap.getString("BANKA_KOD"));
            birSaticiTx.setBankaSube(iMap.getString("SUBE_KOD"));
            birSaticiTx.setBankaHesap(iMap.getString("HESAP_A"));
            birSaticiTx.setSatisGorusKod(iMap.getString("SATICI_GORUSU"));
            birSaticiTx.setKrdTurKodlari(iMap.getString("KREDI_TURU"));
            birSaticiTx.setAciklama(iMap.getString("ACIKLAMA"));
            Date bankaTarih = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH" , new GMMap()).getDate("BANKA_TARIH");
            birSaticiTx.setTanimlamaTar(bankaTarih);
            birSaticiTx.setBayiSorumluKisi(iMap.getBigDecimal("BAYI_SORUMLU_KISI"));
            birSaticiTx.setPortfoyKod(iMap.getString("PORTFOY_KOD"));
            birSaticiTx.setSubeMusteriNo(iMap.getBigDecimal("SUBE_MUSTERI_NO"));
            birSaticiTx.setDistributorHesapNo(iMap.getBigDecimal("FIRMA_HESAP_NO"));
            
            if(iMap.getBoolean("SIGORTA_SATISI")){
            	birSaticiTx.setSigortaSatisiEh("E");
            }else{
            	birSaticiTx.setSigortaSatisiEh("H");
            }

            session.saveOrUpdate(birSaticiTx);
            
            List<?> listDagiticilar = session.createCriteria(BirSaticiIliskiTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            Object[] arrayDagiticilar = listDagiticilar.toArray();
            for (Object element : arrayDagiticilar) {
                listDagiticilar.remove(element);
                session.delete(element);
            }
            session.flush();
            
            List<?> dagitiFirmalar = (List<?>) iMap.get("BAGLI_OLDUGU_DAGITICI_FIRMALAR");
            String tableName = "BAGLI_OLDUGU_DAGITICI_FIRMALAR";
            for (int i = 0; i < dagitiFirmalar.size(); i++){
                BirSaticiIliskiTx birSaticiIliskiTx = new BirSaticiIliskiTx();
                BirSaticiIliskiTxId id = new BirSaticiIliskiTxId();
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                id.setSaticiKod(iMap.getBigDecimal("SATICI_KOD"));
                id.setBagliOldSatKod(iMap.getBigDecimal(tableName , i , "VALUE"));
                birSaticiIliskiTx.setId(id);
                birSaticiIliskiTx.setSec(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName , i , "SEC")));
                session.save(birSaticiIliskiTx);
            }
            session.flush();
            
            tableName = "YETKI_SEVIYE_TREE";
            DefaultMutableTreeNode root = (DefaultMutableTreeNode) iMap.get(tableName);
            if(root != null){
            	Enumeration<DefaultMutableTreeNode> enumeration = root.breadthFirstEnumeration();
            	while(enumeration.hasMoreElements()){
            		DefaultMutableTreeNode node = enumeration.nextElement();
            		if(!root.equals(node)){
            			GMMap roleMap = (GMMap)node.getUserObject();

            			BirSaticiYetkiTanimTxId yetkiTxId = new BirSaticiYetkiTanimTxId();
            			yetkiTxId.setTrxNo(iMap.getBigDecimal("TRX_NO"));
            			yetkiTxId.setRoleOid(roleMap.getString("OID"));

            			BirSaticiYetkiTanimTx yetkiTx = (BirSaticiYetkiTanimTx) session.get(BirSaticiYetkiTanimTx.class, yetkiTxId);
            			if(yetkiTx == null){
            				yetkiTx = new BirSaticiYetkiTanimTx(yetkiTxId);
            			}

            			yetkiTx.setRoleName(roleMap.getString("NAME"));
            			yetkiTx.setSelected(GuimlUtil.convertFromCheckBoxValue(roleMap.getBoolean("SELECTED")));

            			session.saveOrUpdate(yetkiTx);
            		}
            	}
            	session.flush();
            }
            
            List<?> listCalisanlar = session.createCriteria(BirSaticiCalisanTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            Object[] arrayCalisanlar = listCalisanlar.toArray();
            for (Object element : arrayCalisanlar) {
                listCalisanlar.remove(element);
                session.delete(element);
                
            }
            session.flush();
            
            List<?> calisanlarList = (List<?>) iMap.get("CALISANLAR");
            tableName = "CALISANLAR";
            for (int i = 0; i < calisanlarList.size(); i++){
                
                BirSaticiCalisanTx birSaticiCalisanTx = new BirSaticiCalisanTx();
                
                BirSaticiCalisanTxId id = new BirSaticiCalisanTxId();
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                
                HashMap<String, Object> xMap = new HashMap<String, Object>();
                xMap.put("TABLE_NAME" , "BIR_SATICI_CALISAN");
                
                if (iMap.get(tableName , i , "KOD") == null || iMap.get(tableName , i , "KOD").equals(""))
                    id.setKod((BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID" , xMap).get("ID"));
                else id.setKod(iMap.getBigDecimal(tableName , i , "KOD"));
                BigDecimal musteriNo = iMap.getBigDecimal(tableName , i , "MUSTERI_NO");
                
                if (iMap.getBoolean(tableName , i , "YENI_MUSTERI_MI")){
                    iMap.put("CALISAN_ROW" , i);
                    musteriNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRN3247_KONTAKT_CALISAN" , iMap).get("MUSTERI_NO").toString());
                }
                
                birSaticiCalisanTx.setId(id);
                birSaticiCalisanTx.setSaticiKod(iMap.getBigDecimal("SATICI_KOD"));
                birSaticiCalisanTx.setMusteriNo(musteriNo);
                birSaticiCalisanTx.setTcKimlikNo(iMap.getString(tableName , i , "TCK_NO"));
                birSaticiCalisanTx.setAdi(iMap.getString(tableName , i , "ADI"));
                birSaticiCalisanTx.setIkinciAd(iMap.getString(tableName , i , "IKINCI_ADI"));
                birSaticiCalisanTx.setSoyadi(iMap.getString(tableName , i , "SOYADI"));
                birSaticiCalisanTx.setUyrukKod(iMap.getString(tableName , i , "UYRUK"));
                birSaticiCalisanTx.setDogumTarihi(iMap.getDate(tableName , i , "DOGUM_TARIHI"));
                birSaticiCalisanTx.setDogumYeri(iMap.getString(tableName , i , "DOGUM_YERI"));
                birSaticiCalisanTx.setBabaAdi(iMap.getString(tableName , i , "BABA_ADI"));
                birSaticiCalisanTx.setCepAlanKod(iMap.getString(tableName , i , "CEP_TEL_ALAN"));
                birSaticiCalisanTx.setCepTelNo(iMap.getString(tableName , i , "CEP_TEL"));
                String calisanEmailName = iMap.getString(tableName , i , "EPOSTA_NAME");
                String calisanEmailNet = iMap.getString(tableName , i , "EPOSTA_NET");
                if (calisanEmailName != null && !"".equals(calisanEmailName))
                    calisanEmailName = calisanEmailName + "@";
                if (calisanEmailNet != null && !"".equals(calisanEmailNet))
                    calisanEmailName = calisanEmailName + calisanEmailNet;
                birSaticiCalisanTx.setEposta(calisanEmailName);
                birSaticiCalisanTx.setOrtakEh(iMap.getString(tableName , i , "ORTAK_MI"));
                birSaticiCalisanTx.setOrtaklikPayi(iMap.getBigDecimal(tableName , i , "ORTAKLIK_PAYI"));
                birSaticiCalisanTx.setIseBaslamaTar(iMap.getDate(tableName , i , "ISE_BASLAMA_TARIHI"));
                birSaticiCalisanTx.setPozisyonKod(iMap.getString(tableName , i , "POZISYONU"));
                birSaticiCalisanTx.setTuttuguTakimKod(iMap.getString(tableName , i , "TUTTUGU_TAKIM"));
                birSaticiCalisanTx.setHobiKod(iMap.getString(tableName , i , "HOBILERI"));
                birSaticiCalisanTx.setCalStatuKod(iMap.getString(tableName, i, "CALISAN_STATUSU"));
                birSaticiCalisanTx.setCalKismiKapanmaNedenKod(iMap.getString(tableName, i, "KAPANMA_NEDENI"));
                birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName, i, "YETKI_SEVIYESI"));
                
                if (iMap.getString(tableName , i , "YETKI_SEVIYESI") != null && !iMap.getString(tableName , i , "YETKI_SEVIYESI").equals(iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI"))){
                    birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName , i , "YETKI_SEVIYESI"));
                    birSaticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate("BANKA_TARIHI"));
                    birSaticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI"));
                    birSaticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName , i , "YETKI_SEVIYESI_GUNCELLEME_TAR"));
                    
                } else
                    if (iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI") != null
                            && !iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI").equals(iMap.getString(tableName , i , "YETKI_SEVIYESI"))){
                        birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName , i , "YETKI_SEVIYESI"));
                        birSaticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate("BANKA_TARIHI"));
                        birSaticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI"));
                        birSaticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName , i , "YETKI_SEVIYESI_GUNCELLEME_TAR"));
                        
                    } else
                        if (iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI") == null && iMap.getString(tableName , i , "YETKI_SEVIYESI") == null
                                || iMap.getString(tableName , i , "GIZLI_YETKI_SEVIYESI").equals(iMap.getString(tableName , i , "YETKI_SEVIYESI"))){
                            birSaticiCalisanTx.setYetkiGirisKod(iMap.getString(tableName , i , "YETKI_SEVIYESI"));
                            birSaticiCalisanTx.setYetkiGirisKodGuncellemeTar(iMap.getDate(tableName , i , "YETKI_SEVIYESI_GUNCELLEME_TAR"));
                            birSaticiCalisanTx.setOncekiYetkiGirisKod(iMap.getString(tableName , i , "ONCEKI_YETKI_SEVIYESI"));
                            birSaticiCalisanTx.setOncekiYetkiGuncellemeTar(iMap.getDate(tableName , i , "ONCEKI_YETKI_SEVIYESI_GUNCELLEME_TAR"));
                        }
                
                birSaticiCalisanTx.setDigerBankaKod(iMap.getString(tableName , i , "BANKA_KOD"));
                birSaticiCalisanTx.setDigerSubeKod(iMap.getString(tableName , i , "SUBE_KOD"));
                birSaticiCalisanTx.setDigerHesapNo(iMap.getString(tableName , i , "HESAP_A"));
                birSaticiCalisanTx.setHesapNo(iMap.getBigDecimal(tableName , i , "MUSTERI_HESAP_NO"));
                
                session.save(birSaticiCalisanTx);
                session.flush();
            }

			List<?> saticiTahsisFaaliyetList = session.createCriteria(BirSaticiTahsisFaaliyetTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : saticiTahsisFaaliyetList) {
				BirSaticiTahsisFaaliyetTx birSaticiTahsisFaaliyetTx = (BirSaticiTahsisFaaliyetTx) name;
				session.delete(birSaticiTahsisFaaliyetTx);
			}
			session.flush();

			saticiTahsisFaaliyetList = (List<?>) iMap.get("FAALIYET_KONUSU");
			tableName = "FAALIYET_KONUSU";
			for (int i = 0; i < saticiTahsisFaaliyetList.size(); i++) {
				if (iMap.getBoolean(tableName, i, "SEC")) {
					BirSaticiTahsisFaaliyetTx birSaticiTahsisFaaliyetTx = new BirSaticiTahsisFaaliyetTx();
					BirSaticiTahsisFaaliyetTxId birSaticiTahsisFaaliyetTxId = new BirSaticiTahsisFaaliyetTxId();

					birSaticiTahsisFaaliyetTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					birSaticiTahsisFaaliyetTxId.setFaaliyetKodu(iMap.getString(tableName, i, "FAALIYET_KODU"));
					birSaticiTahsisFaaliyetTxId.setSaticiKod(iMap.getBigDecimal("SATICI_KOD"));
					birSaticiTahsisFaaliyetTxId.setTur("X");
					birSaticiTahsisFaaliyetTx.setId(birSaticiTahsisFaaliyetTxId);

					session.save(birSaticiTahsisFaaliyetTx);
				}
			}
			session.flush();

            iMap.put("TRX_NAME" , "3247");
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3247_KONTAKT_SATICI")
    public static GMMap trn3247KontaktSatici(GMMap iMap) {
        try{
            
            GMMap kontakt = new GMMap();
            
            if ("D".equals(iMap.getString("SATICI_TIP")) && (iMap.getString("DI_MUSTERI_NO") == null || iMap.getString("DI_MUSTERI_NO").isEmpty()))
                return kontakt;
            
            Date bankaTarih = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH" , new GMMap()).getDate("BANKA_TARIH");
            String firmaTipi = iMap.getString("SIRKET_TIPI");
            
            String trxNo = GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO" , new GMMap()).get("TRX_NO").toString();
            kontakt.put("TRX_NO" , trxNo);
            
            if ("M".equals(iMap.getString("SATICI_TIP"))){
                if (iMap.getString("ADRES") == null || iMap.getString("ADRES").isEmpty()){
                    iMap.put("HATA_NO" , new BigDecimal(330));
                    iMap.put("P1" , "Adres");
                    return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                }
                if (iMap.getString("IL") == null || iMap.getString("IL").isEmpty()){
                    iMap.put("HATA_NO" , new BigDecimal(330));
                    iMap.put("P1" , "Adres �l");
                    return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                }
                if (iMap.getString("ILCE") == null || iMap.getString("ILCE").isEmpty()){
                    iMap.put("HATA_NO" , new BigDecimal(330));
                    iMap.put("P1" , "Adres �l�e");
                    return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                }
                if (iMap.getString("ADRES") == null || iMap.getString("ADRES").isEmpty()){
                    iMap.put("HATA_NO" , new BigDecimal(330));
                    iMap.put("P1" , "Adres");
                    return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                }
                if (iMap.getString("TELEFON_ALAN") == null || iMap.getString("TELEFON_ALAN").isEmpty() || iMap.getString("TELEFON") == null || iMap.getString("TELEFON").isEmpty()){
                    iMap.put("HATA_NO" , new BigDecimal(330));
                    iMap.put("P1" , "Telefon");
                    return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                }
            }
            // ADRES
            List<HashMap<String, Object>> adresList = new ArrayList<HashMap<String, Object>>();
            
            HashMap<String, Object> adresData = new HashMap<String, Object>();
            adresData.put("ADRES_KOD" , "I");
            adresData.put("ISYERI_UNVANI" , iMap.getString("DI_MUSTERI_NO"));
            adresData.put("ADRES" , iMap.getString("ADRES"));
            adresData.put("ADRES_IL_KOD" , iMap.getString("IL"));
            adresData.put("ADRES_ILCE_KOD" , iMap.getString("ILCE"));
            adresData.put("ULKE_KOD" , "TR");
            adresData.put("EXTRE_ADRES_KOD_F" , "E");
            adresData.put("UPD_DATE" , bankaTarih);
            adresList.add(adresData);
            
            kontakt.put("ADRES_LIST" , adresList);
            
            // TELEFON
            List<HashMap<String, Object>> telefonList = new ArrayList<HashMap<String, Object>>();
            
            if (iMap.getString("TELEFON_ALAN") != null && !iMap.getString("TELEFON_ALAN").isEmpty() && iMap.getString("TELEFON") != null && !iMap.getString("TELEFON").isEmpty()){
                HashMap<String, Object> telefonData = new HashMap<String, Object>();
                telefonData.put("TEL_TIP" , "2");
                telefonData.put("ALAN_KOD" , iMap.getString("TELEFON_ALAN"));
                telefonData.put("TEL_NO" , iMap.getString("TELEFON"));
                telefonData.put("F_ILETISIM" , "E");
                telefonData.put("ULKE_KODU" , "90");
                telefonData.put("UPD_DATE" , bankaTarih);
                telefonList.add(telefonData);
            }
            
            if (iMap.getString("FAX_ALAN") != null && !iMap.getString("FAX_ALAN").isEmpty() && iMap.getString("FAKS") != null && !iMap.getString("FAKS").isEmpty()){
                HashMap<String, Object> faxData = new HashMap<String, Object>();
                faxData.put("TEL_TIP" , "5");
                faxData.put("ALAN_KOD" , iMap.getString("FAX_ALAN"));
                faxData.put("TEL_NO" , iMap.getString("FAKS"));
                faxData.put("F_ILETISIM" , "H");
                faxData.put("ULKE_KODU" , "90");
                faxData.put("UPD_DATE" , bankaTarih);
                telefonList.add(faxData);
            }
            
            kontakt.put("TELEFON_LIST" , telefonList);
            
            if (firmaTipi == null){
                iMap.put("HATA_NO" , new BigDecimal(330));
                iMap.put("P1" , "�irket Tipi");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
            }
            
            if (!"7".equals(firmaTipi)){
                kontakt.put("MUSTERI_TIPI_KOD" , "T");
                kontakt.put("DK_GRUP_KOD" , "1044");
                kontakt.put("PROFIL_KODU" , "1");
                kontakt.put("PROFIL_ALT1_KODU" , "1");
                kontakt.put("TICARI_UNVAN" , iMap.getString("DI_MUSTERI_NO"));
                kontakt.put("BOLUM_KODU" , GMServiceExecuter.execute("BNSPR_TRN2201_GET_SUBE_KODU" , new GMMap()).get("SUBE_KODU"));
                kontakt.put("UYRUK_KOD" , "TR");
                kontakt.put("VERGI_DAIRE_KODU" , iMap.getString("VERGI_DAIRESI"));
                kontakt.put("VERGI_DAIRE_IL_KODU" , iMap.getString("VERGI_DAIRESI_IL"));
                kontakt.put("VERGI_NO" , iMap.getString("VERGI_TCK_NO"));
                kontakt.put("YERLESIM_KOD" , "I");
                if (iMap.getString("DI_MUSTERI_NO").length() <= 50)
                    kontakt.put("KISA_AD" , iMap.getString("DI_MUSTERI_NO"));
                else kontakt.put("KISA_AD" , iMap.getString("DI_MUSTERI_NO").substring(0 , 50));
                kontakt.put("MUSTERI_KONTAKT" , "K");
                kontakt.put("ILK_ILISKI_TARIHI" , bankaTarih);
                kontakt.put("BAGLI_KANAL_GRUBU" , GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD" , new GMMap()).get("KANAL_KOD"));
                kontakt.put("KANAL_KODU" , GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_ALT_KOD" , new GMMap()).get("KANAL_ALT_KOD"));
                kontakt.put("HESAP_UCRETI_F" , "H");
                kontakt.put("MUSTERI_SEGMENTI" , "B");
                String emailName = iMap.getString("E_POSTA_NAME");
                String emailNet = iMap.getString("E_POSTA_NET");
                if (!emailName.equals("") || !emailNet.equals(""))
                    kontakt.put("EMAIL_IS" , emailName + "@" + emailNet);
                else kontakt.put("EMAIL_IS" , "");
                kontakt.put("WEB_ADRESI" , iMap.getString("WEB_ADRESI"));
                kontakt.put("ORIJINAL_EVRAKLIMI" , "H");
                
                kontakt.put("FIRMA_TIPI" , firmaTipi);
                kontakt.put("KURULUS_TARIHI" , iMap.getDate("KURULUS_TARIHI"));
                
                //Musteri tanimlama + guncelleme islemlerinin onaysiz gerceklesmesi
                kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
                kontakt.put("TRX_NAME" , "10012");
                GMServiceExecuter.execute("BNSPR_TRN10012_SAVE" , kontakt);
                
            } else
                if ("7".equals(firmaTipi)){
                    kontakt.put("MUSTERI_TIPI_KOD" , "G");
                    kontakt.put("TICARI_UNVAN" , iMap.getString("DI_MUSTERI_NO"));
                    
                    if(iMap.containsKey("VERGI_TCK_NO") && iMap.getBigDecimal("VERGI_TCK_NO") != null && !"".equals(iMap.getBigDecimal("VERGI_TCK_NO")))
                    {
	                    GMMap kps = new GMMap();
	                    kps.put("tckno_in" , iMap.getBigDecimal("VERGI_TCK_NO"));
	                    kps.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_KPS_KIMLIK_SORGULAMA" , kps));
	                    
	                    kontakt.put("TC_KIMLIK_NO" , kps.get("tckno_out"));
	                    kontakt.put("TCKNO_IN" , kps.get("tckno_out"));
	                    String ad1 = kps.get("ad1").toString();
	                    String ad2 = "";
	                    String soyad = kps.get("soyad").toString();
	                    String kisaAd = ad1 + " " + soyad;
	                    if (kps.get("ad2") != null){
	                        ad2 = kps.get("ad2").toString();
	                        kisaAd = ad1 + " " + ad2 + " " + soyad;
	                    }
	                    kontakt.put("ISIM" , ad1);
	                    kontakt.put("IKINCI_ISIM" , ad2);
	                    kontakt.put("SOYADI" , soyad);
	                    kontakt.put("UYRUK_KOD" , "TR");
	                    kontakt.put("DOGUM_TARIHI" , kps.get("dogumTarihi"));
	                    kontakt.put("DOGUM_YERI" , kps.get("dogumyeri"));
	                    kontakt.put("BABA_ADI" , kps.get("babaad"));
	                    kontakt.put("ANNE_ADI" , kps.get("anaad"));
	                    // kontakt.put("ANNE_KIZLIK_SOYADI",);
	                    kontakt.put("CINSIYET" , kps.get("cinsiyet"));
	                    kontakt.put("CINSIYET_KOD" , GMServiceExecuter.execute("BNSPR_COMMON_GET_CINSIYET_KOD" , kontakt).get("KOD"));
	                    
	                    kontakt.put("MEDENI_HAL" , kps.get("medenihali"));
	                    kontakt.put("MEDENI_HAL_KOD" , GMServiceExecuter.execute("BNSPR_COMMON_GET_MEDENI_HAL_KOD" , kontakt).get("KOD"));
	                    
	                    kontakt.put("AILE_SIRA_NO" , kps.get("ailesirano"));
	                    kontakt.put("CILT_NO" , kps.get("ciltkodu"));
	                    kontakt.put("SIRA_NO" , kps.get("bireysirano"));
	                    kontakt.put("KIZLIK_SOYADI" , kps.get("kizliksoyad"));
	                    kontakt.put("KISA_AD" , kisaAd);
                    }
                    else
                    {
                    	kontakt.put("ISIM" , iMap.getString("ISIM"));
                    	kontakt.put("SOYADI" , iMap.getString("SOYADI"));
                    	kontakt.put("TICARI_UNVAN" , iMap.getString("TICARI_UNVAN"));
                    	kontakt.put("UYRUK_KOD" , "TR");
                    }                    
                    kontakt.put("MUSTERI_KONTAKT" , "K");
                    String emailName = iMap.getString("E_POSTA_NAME");
                    String emailNet = iMap.getString("E_POSTA_NET");
                    if (!emailName.equals("") || !emailNet.equals(""))
                        kontakt.put("EMAIL_KISISEL" , emailName + "@" + emailNet);
                    else kontakt.put("EMAIL_KISISEL" , "");
                    kontakt.put("BAGLI_KANAL_GRUBU" , GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD" , new GMMap()).get("KANAL_KOD"));
                    kontakt.put("KANAL_KODU" , GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_ALT_KOD" , new GMMap()).get("KANAL_ALT_KOD"));
                    kontakt.put("DK_GRUP_KOD" , "1043");
                    kontakt.put("PROFIL_KOD" , "4");
                    kontakt.put("BOLUM_KODU" , GMServiceExecuter.execute("BNSPR_TRN2201_GET_SUBE_KODU" , new GMMap()).get("SUBE_KODU"));
                    kontakt.put("YERLESIM_KOD" , "I");

                    kontakt.put("ILK_ILISKI_TARIHI" , bankaTarih);
                    kontakt.put("HESAP_UCRETI_F" , "H");
                    kontakt.put("MUSTERI_SEGMENTI" , "B");
                    kontakt.put("ORIJINAL_EVRAKLIMI" , "H");
                    kontakt.put("TICARI_SICIL_KAYIT_TARIHI" , iMap.getDate("KURULUS_TARIHI"));
                    
                    //Musteri tanimlama + guncelleme islemlerinin onaysiz gerceklesmesi
                    kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
                    kontakt.put("TRX_NAME" , "10011");
                    
                    // ekranda bunlar i�in alan bulunmuyor, default olarak
    				// �ifte vatanda�l�k : R ("Hay�r")
    				// Green Card : R("De�ilim")
    				kontakt.put("F_CIFTE_VATANDAS", "R");
    				kontakt.put("F_GREEN_CARD", "R");
                    
                    GMServiceExecuter.execute("BNSPR_TRN10011_SAVE" , kontakt);
                    
                }
            GMMap oMap = new GMMap();
            
            oMap.put("TRX_NO" , trxNo);
            oMap.put("MUSTERI_NO" , GMServiceExecuter.execute("BNSPR_COMMON_GET_MUSTERI_NO_BY_TRX_NO" , oMap).get("MUSTERI_NO"));
            
            return oMap;
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    @GraymoundService("BNSPR_TRN3247_KONTAKT_CALISAN")
    public static GMMap trn3247KontaktCalisan(GMMap iMap) {
        
        try{
            GMMap kontakt = new GMMap();
            GMMap oMap = new GMMap();
            
            Date bankaTarih = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH" , new GMMap()).getDate("BANKA_TARIH");
            
            String tableName = "CALISANLAR";
            int row = iMap.getInt("CALISAN_ROW");
            
            String trxNo = GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO" , new GMMap()).get("TRX_NO").toString();
            kontakt.put("TRX_NO" , trxNo);
            kontakt.put("MUSTERI_TIPI_KOD" , "G");
            
            if (iMap.getBigDecimal(tableName , row , "TCK_NO") == null){
                iMap.put("HATA_NO" , new BigDecimal(330));
                iMap.put("P1" , "�al��an TC Kimlik No");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
            }
            
            GMMap kps = new GMMap();
            kps.put("tckno_in" , iMap.getBigDecimal(tableName , row , "TCK_NO"));
            kps.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_KPS_KIMLIK_SORGULAMA" , kps));
            
            // if(kps.get("tckno_out").toString() != kps.get("tckno_in").toString())
            // {
            // oMap.put("MUSTERI_NO", GMServiceExecuter.execute("BNSPR_COMMON_GET_MUSTERI_NO_BY_TRX_NO",
            // oMap).get("MUSTERI_NO"));
            // return oMap;
            // }
            
            kontakt.put("TC_KIMLIK_NO" , kps.get("tckno_out"));
            kontakt.put("TCKNO_IN" , kps.get("tckno_out"));
            String ad1 = kps.get("ad1").toString();
            String ad2 = "";
            String soyad = kps.get("soyad").toString();
            String kisaAd = ad1 + " " + soyad;
            if (kps.get("ad2") != null){
                ad2 = kps.get("ad2").toString();
                kisaAd = ad1 + " " + ad2 + " " + soyad;
            }
            kontakt.put("ISIM" , ad1);
            kontakt.put("IKINCI_ISIM" , ad2);
            kontakt.put("SOYADI" , soyad);
            kontakt.put("UYRUK_KOD" , "TR");
            kontakt.put("DOGUM_TARIHI" , kps.get("dogumTarihi"));
            kontakt.put("DOGUM_YERI" , kps.get("dogumyeri"));
            kontakt.put("BABA_ADI" , kps.get("babaad"));
            kontakt.put("ANNE_ADI" , kps.get("anaad"));
            // kontakt.put("ANNE_KIZLIK_SOYADI",);
            kontakt.put("CINSIYET" , kps.get("cinsiyet"));
            kontakt.put("CINSIYET_KOD" , GMServiceExecuter.execute("BNSPR_COMMON_GET_CINSIYET_KOD" , kontakt).get("KOD"));
            
            kontakt.put("MEDENI_HAL" , kps.get("medenihali"));
            kontakt.put("MEDENI_HAL_KOD" , GMServiceExecuter.execute("BNSPR_COMMON_GET_MEDENI_HAL_KOD" , kontakt).get("KOD"));
            
            kontakt.put("AILE_SIRA_NO" , kps.get("ailesirano"));
            kontakt.put("CILT_NO" , kps.get("ciltkodu"));
            kontakt.put("SIRA_NO" , kps.get("bireysirano"));
            kontakt.put("KIZLIK_SOYADI" , kps.get("kizliksoyad"));
            kontakt.put("MUSTERI_KONTAKT" , "K");
            String emailName = iMap.getString(tableName , row , "EPOSTA_NAME");
            String emailNet = iMap.getString(tableName , row , "EPOSTA_NET");
            if (!emailName.equals("") || !emailNet.equals(""))
                kontakt.put("EMAIL_KISISEL" , emailName + "@" + emailNet);
            else kontakt.put("EMAIL_KISISEL" , "");
            kontakt.put("BAGLI_KANAL_GRUBU" , GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD" , new GMMap()).get("KANAL_KOD"));
            kontakt.put("KANAL_KODU" , GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_ALT_KOD" , new GMMap()).get("KANAL_ALT_KOD"));
            kontakt.put("DK_GRUP_KOD" , "1042");
            kontakt.put("PROFIL_KOD" , "1");
            kontakt.put("BOLUM_KODU" , GMServiceExecuter.execute("BNSPR_TRN2201_GET_SUBE_KODU" , new GMMap()).get("SUBE_KODU"));
            kontakt.put("YERLESIM_KOD" , "I");
            kontakt.put("KISA_AD" , kisaAd);
            kontakt.put("ILK_ILISKI_TARIHI" , bankaTarih);
            kontakt.put("HESAP_UCRETI_F" , "H");
            kontakt.put("MUSTERI_SEGMENTI" , "N");
            kontakt.put("ORIJINAL_EVRAKLIMI" , "H");
            
            // ADRES
            List<HashMap<String, Object>> adresList = new ArrayList<HashMap<String, Object>>();
            
            HashMap<String, Object> adresData = new HashMap<String, Object>();
            adresData.put("ADRES_KOD" , "I");
            adresData.put("ISYERI_UNVANI" , iMap.getString("DI_MUSTERI_NO").isEmpty() ? kisaAd : iMap.getString("DI_MUSTERI_NO"));
            adresData.put("ADRES" , iMap.getString("ADRES"));
            adresData.put("ADRES_IL_KOD" , iMap.getString("IL"));
            adresData.put("ADRES_ILCE_KOD" , iMap.getString("ILCE"));
            adresData.put("ULKE_KOD" , "TR");
            adresData.put("EXTRE_ADRES_KOD_F" , "E");
            adresData.put("UPD_DATE" , bankaTarih);
            adresList.add(adresData);
            
            kontakt.put("ADRES_LIST" , adresList);
            
            // TELEFON
            List<HashMap<String, Object>> telefonList = new ArrayList<HashMap<String, Object>>();
            
            if (iMap.getBigDecimal(tableName , row , "CEP_TEL") != null && !iMap.getString(tableName , row , "CEP_TEL").isEmpty()){
                HashMap<String, Object> telefonData = new HashMap<String, Object>();
                telefonData.put("TEL_TIP" , "3");
                telefonData.put("ALAN_KOD" , iMap.getBigDecimal(tableName , row , "CEP_TEL_ALAN"));
                telefonData.put("TEL_NO" , iMap.getString(tableName , row , "CEP_TEL"));
                telefonData.put("F_ILETISIM" , "E");
                telefonData.put("ULKE_KODU" , "90");
                telefonData.put("UPD_DATE" , bankaTarih);
                telefonList.add(telefonData);
            }
            
            HashMap<String, Object> isTelefonData = new HashMap<String, Object>();
            isTelefonData.put("TEL_TIP" , "2");
            isTelefonData.put("ALAN_KOD" , iMap.getString("TELEFON_ALAN"));
            isTelefonData.put("TEL_NO" , iMap.getString("TELEFON"));
            isTelefonData.put("F_ILETISIM" , "H");
            isTelefonData.put("ULKE_KODU" , "90");
            isTelefonData.put("UPD_DATE" , bankaTarih);
            telefonList.add(isTelefonData);
            
            kontakt.put("TELEFON_LIST" , telefonList);
            
            List<HashMap<String, Object>> nullList = new ArrayList<HashMap<String, Object>>();
            kontakt.put("VELI_VASI" , nullList);
            kontakt.put("CBS_MUSTERI_BASVURU_NOTLAR" , nullList);
            kontakt.put("CBS_MUSTERI_BASVURU_DOKUMAN" , nullList);
            kontakt.put("CBS_MUSTERI_BASVURU_GORUSME" , nullList);
            
            //Musteri tanimlama + guncelleme islemlerinin onaysiz gerceklesmesi
            kontakt.put("TRX_ONAYSIZ_ISLEM", "E");
            kontakt.put("TRX_NAME" , "10011");
            
            // ekranda bunlar i�in alan bulunmuyor, default olarak
			// �ifte vatanda�l�k : R ("Hay�r")
			// Green Card : R("De�ilim")
			kontakt.put("F_CIFTE_VATANDAS", "R");
			kontakt.put("F_GREEN_CARD", "R");
            
            GMServiceExecuter.execute("BNSPR_TRN10011_SAVE" , kontakt);
            
            oMap.put("TRX_NO" , trxNo);
            oMap.put("MUSTERI_NO" , GMServiceExecuter.execute("BNSPR_COMMON_GET_MUSTERI_NO_BY_TRX_NO" , oMap).get("MUSTERI_NO"));
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
    @GraymoundService("BNSPR_TRN3247_GET_DAGITICI_FOR_BAYI")
    public static GMMap trn3247GetDagiticiForBayi(GMMap iMap) {
        try{
            GMMap oMap = new GMMap();
            Session session = DAOSession.getSession("BNSPRDal");
            
            if ("S".equals(iMap.getString("SATICI_TIP")))
                iMap.put("COMBO" , "DAGITICI");
            else iMap.put("COMBO" , "DAGITICI_ALL");
            List<?> dagiciFirmalar = (List<?>) GMServiceExecuter.execute("BPM_PRC3299_FILL_COMBOBOX" , iMap).get("RESULTS");
            
            String tableName = "BAGLI_OLDUGU_DAGITICI_FIRMALAR";
            int row = 0;
            
            if (dagiciFirmalar == null)
                return oMap;
            
            for (Object name : dagiciFirmalar) {
                HashMap<?, ?> data = (HashMap<?, ?>) name;
                BirSaticiIliski birSaticiIliski =
                        (BirSaticiIliski) session.createCriteria(BirSaticiIliski.class).add(Restrictions.eq("id.saticiKod" , iMap.getBigDecimal("BAGLI_OLDUGU_MERKEZ_BAYI_KOD")))
                                .add(Restrictions.eq("id.bagliOldSatKod" , new BigDecimal((String) data.get("VALUE")))).uniqueResult();
                if (birSaticiIliski != null)
                    oMap.put(tableName , row , "SEC" , GuimlUtil.convertToCheckBoxSelected(birSaticiIliski.getSec()));
                oMap.put(tableName , row , "VALUE" , data.get("VALUE"));
                oMap.put(tableName , row , "NAME" , data.get("NAME"));
                row++;
            }
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3247_GET_INFO_FOR_UPDATE")
    public static GMMap trn3247GetInfoForUpdate(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            BirSatici birSatici = (BirSatici) session.get(BirSatici.class , iMap.getBigDecimal("SATICI_KOD"));
            
            BigDecimal musteriNo = birSatici.getMusteriNo();
            oMap.put("MUSTERI_NO" , musteriNo);
            
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall(LovHelper.getLOVQuery("3247/LOV_TUZEL_MUSTERI_GET_INFO"));
            stmt.setBigDecimal(1 , musteriNo);
            stmt.setBigDecimal(2 , musteriNo);
            rSet = stmt.executeQuery();
            
            if (rSet.next()){
                oMap.put("DI_MUSTERI_NO" , rSet.getString("UNVAN"));
                oMap.put("VERGI_NUMARASI" , rSet.getString("VERGI_NO"));
                oMap.put("VERGI_DAIRESI_IL" , rSet.getString("VERGI_IL_KODU"));
                oMap.put("VERGI_DAIRESI" , rSet.getString("VERGI_DAIRE_KODU"));
                oMap.put("SIRKET_TIPI" , rSet.getString("FIRMA_TIPI"));
                oMap.put("ADI" , rSet.getString("ADI"));
                oMap.put("SOYADI" , rSet.getString("SOYADI"));
                oMap.put("TICARI_UNVAN" , rSet.getString("TICARI_UNVAN"));                
                
                GMMap xMap = new GMMap();
                xMap.put("EMAIL_1" , rSet.getString("EMAIL_IS"));
                GMMap eMap = new GMMap();
                eMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_PARSE_EMAILS" , xMap));
                oMap.put("E_POSTA_NAME" , eMap.getString("EMAIL_11"));
                oMap.put("E_POSTA_NET" , eMap.getString("EMAIL_12"));
                
                oMap.put("TELEFON_ALAN" , rSet.getString("TEL_ALAN"));
                oMap.put("TELEFON" , rSet.getString("TELEFON"));
                oMap.put("FAX_ALAN" , rSet.getString("FAX_ALAN"));
                oMap.put("FAKS" , rSet.getString("FAX"));
                oMap.put("ADRES" , rSet.getString("ADRES"));
                oMap.put("IL_KOD" , rSet.getString("ADRES_IL"));
                oMap.put("ILCE_KOD" , rSet.getString("ADRES_ILCE"));
                
                oMap.put("WEB_ADRESI" , rSet.getString("WEB_ADRES"));
                oMap.put("KURULUS_TARIHI" , rSet.getDate("KURULUS_TARIHI"));
            }
            
            oMap.put("SATICI_TELEFON_ALAN" , birSatici.getAlanKodTel());
            oMap.put("SATICI_TELEFON" , birSatici.getTelNo());
            oMap.put("SATICI_FAX_ALAN" , birSatici.getAlanKodFaks());
            oMap.put("SATICI_FAX" , birSatici.getFaksNo());
            oMap.put("SATICI_ADRES" , birSatici.getAdres());
            oMap.put("SATICI_IL_KOD" , birSatici.getAdresIl());
            oMap.put("SATICI_ILCE_KOD" , birSatici.getAdresIlce());
            
            oMap.put("SATICI_TIP" , birSatici.getSaticiTipKod());
            oMap.put("YETKI_SEVIYESI" , birSatici.getYetkiSeviyeKod());
            oMap.put("BAGLI_OLDUGU_BOLGE" , birSatici.getBagliOldBolgeKod());
            oMap.put("BAGLI_OLDUGU_MERKEZ_BAYI_KOD" , birSatici.getBagliMerkezBayi());
            oMap.put("DI_BAGLI_OLDUGU_MERKEZ_BAYI_KOD" , LovHelper.diLov(birSatici.getBagliMerkezBayi() , "3247/LOV_MERKEZ_BAYI" , "SATICI_ADI"));
            oMap.put("DOKUMAN_YOLLAMA_TIPI" , birSatici.getDokYollamaKod());
            oMap.put("DURUM" , birSatici.getDrm());
            oMap.put("PARA_CIKISI" , birSatici.getParaCikisOtoEh());
            oMap.put("MUSTERI_HESAP_NO" , birSatici.getHesapNo());
            oMap.put("DI_MUSTERI_HESAP_NO" , LovHelper.diLov(birSatici.getHesapNo() , musteriNo , "3247/LOV_VDSZ_HESAP" , "KISA_ISIM"));
            oMap.put("BANKA_KOD" , birSatici.getBankaKod());
            oMap.put("DI_BANKA_KOD" , LovHelper.diLov(birSatici.getBankaKod() , "3247/LOV_BANKA" , "BANKA_ADI"));
            oMap.put("SUBE_KOD" , birSatici.getBankaSube());
            oMap.put("DI_SUBE_KOD" , LovHelper.diLov(birSatici.getBankaSube() , birSatici.getBankaKod() , oMap.getString("IL_KOD") , "3247/LOV_BANKA_SUBE" , "SUBE_ADI"));
            oMap.put("HESAP_A" , birSatici.getBankaHesap());
            oMap.put("SATICI_GORUSU" , birSatici.getSatisGorusKod());
            oMap.put("BAYI_SORUMLU_KISI" , birSatici.getBayiSorumluKisi());
            String krediTurKodlari = birSatici.getKrdTurKodlari();
            oMap.put("PORTFOY_KOD" , birSatici.getPortfoyKod());
            oMap.put("F_IHTIYAC" , false);
            oMap.put("F_TASIT" , false);
            oMap.put("F_KONUT" , false);
            oMap.put("F_MIKRO" , false);
            if (krediTurKodlari.charAt(0) == '1')
                oMap.put("F_IHTIYAC" , true);
            if (krediTurKodlari.charAt(1) == '1')
                oMap.put("F_KONUT" , true);
            if (krediTurKodlari.charAt(2) == '1')
                oMap.put("F_TASIT" , true);
            if (krediTurKodlari.charAt(3) == '1')
                oMap.put("F_MIKRO" , true);
            
            oMap.put("ACIKLAMA" , birSatici.getAciklama());
            oMap.put("SUBE_MUSTERI_NO", birSatici.getSubeMusteriNo());
            oMap.put("FIRMA_HESAP_NO" , birSatici.getDistributorHesapNo());
            oMap.put("DI_FIRMA_HESAP_NO" , LovHelper.diLov(birSatici.getDistributorHesapNo(), musteriNo, "3247/LOV_FIRMA_HESAP_NO", "KISA_ISIM"));
            
            if("E".equals(birSatici.getSigortaSatisiEh())){
                oMap.put("SIGORTA_SATISI" , true);	
            }else{
                oMap.put("SIGORTA_SATISI" , false);	
            }
            
            if ("D".equals(birSatici.getSaticiTipKod()))
                iMap.put("COMBO" , "DAGITICI");
            else iMap.put("COMBO" , "DAGITICI_ALL");
            List<?> dagiciFirmalar = (List<?>) GMServiceExecuter.execute("BPM_PRC3299_FILL_COMBOBOX" , iMap).get("RESULTS");
            
            String tableName = "BAGLI_OLDUGU_DAGITICI_FIRMALAR";
            int row = 0;
            if (dagiciFirmalar != null && dagiciFirmalar.size() > 0){
                for (Object name : dagiciFirmalar) {
                    HashMap<?, ?> data = (HashMap<?, ?>) name;
                    BirSaticiIliski birSaticiIliski =
                            (BirSaticiIliski) session.createCriteria(BirSaticiIliski.class).add(Restrictions.eq("id.saticiKod" , birSatici.getKod()))
                                    .add(Restrictions.eq("id.bagliOldSatKod" , new BigDecimal((String) data.get("VALUE")))).uniqueResult();
                    if (birSaticiIliski != null)
                        oMap.put(tableName , row , "SEC" , GuimlUtil.convertToCheckBoxSelected(birSaticiIliski.getSec()));
                    oMap.put(tableName , row , "VALUE" , data.get("VALUE"));
                    oMap.put(tableName , row , "NAME" , data.get("NAME"));
                    row++;
                }
            }
            
            List<?> calisanlarList =
                    session.createCriteria(BirSaticiCalisan.class).add(Restrictions.eq("birSatici.kod" , iMap.getBigDecimal("SATICI_KOD"))).add(Restrictions.eq("durum" , "ONAY")).list(); // .add(Restrictions.eq("durum","ONAY"))
            tableName = "CALISANLAR";
            row = 0;
            for (int i = 0; i < calisanlarList.size(); i++){
                
                BirSaticiCalisan birSaticiCalisan = (BirSaticiCalisan) calisanlarList.get(i);
                oMap.put(tableName , row , "KOD" , birSaticiCalisan.getKod());
                oMap.put(tableName , row , "MUSTERI_NO" , birSaticiCalisan.getMusteriNo());
                
                ArrayList<Object> listPar = new ArrayList<Object>();
                listPar.add(birSaticiCalisan.getMusteriNo());
                HashMap<?, ?> gercekMusteri = LovHelper.diLovAll(birSaticiCalisan.getMusteriNo() , "3247/LOV_GERCEK_MUSTERI_GET_INFO" , listPar);
                if (gercekMusteri != null){
                    oMap.put(tableName , row , "DI_MUSTERI_NO" , (String) gercekMusteri.get("UNVAN"));
                    oMap.put(tableName , row , "TCK_NO" , (String) gercekMusteri.get("TC_KIMLIK_NO"));
                    oMap.put(tableName , row , "ADI" , (String) gercekMusteri.get("ADI"));
                    oMap.put(tableName , row , "IKINCI_ADI" , (String) gercekMusteri.get("IKINCI_ADI"));
                    oMap.put(tableName , row , "SOYADI" , (String) gercekMusteri.get("SOYADI"));
                    oMap.put(tableName , row , "UYRUK" , (String) gercekMusteri.get("UYRUK_KOD"));
                    oMap.put(tableName , row , "DOGUM_TARIHI" , (String) gercekMusteri.get("DOGUM_TARIHI"));
                    oMap.put(tableName , row , "DOGUM_YERI" , (String) gercekMusteri.get("DOGUM_YERI"));
                    oMap.put(tableName , row , "BABA_ADI" , (String) gercekMusteri.get("BABA_ADI"));
                    oMap.put(tableName , row , "ANNE_ADI" , (String) gercekMusteri.get("ANNE_ADI"));
                    
                    oMap.put(tableName , row , "CEP_TEL_ALAN" , (String) gercekMusteri.get("GSM_ALAN"));
                    oMap.put(tableName , row , "CEP_TEL" , (String) gercekMusteri.get("GSM"));
                    
                    GMMap xMap = new GMMap();
                    xMap.put("EMAIL_1" , (String) gercekMusteri.get("EMAIL_KISISEL"));
                    oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_PARSE_EMAILS" , xMap));
                    oMap.put(tableName , row , "EPOSTA_NAME" , oMap.get("EMAIL_11"));
                    oMap.put(tableName , row , "EPOSTA_NET" , oMap.get("EMAIL_12"));
                }
                
                oMap.put(tableName , row , "ORTAK_MI" , birSaticiCalisan.getOrtakEh());
                oMap.put(tableName , row , "ORTAKLIK_PAYI" , birSaticiCalisan.getOrtaklikPayi());
                oMap.put(tableName , row , "ISE_BASLAMA_TARIHI" , birSaticiCalisan.getIseBaslamaTar());
                oMap.put(tableName , row , "POZISYONU" , birSaticiCalisan.getPozisyonKod());
                oMap.put(tableName , row , "TUTTUGU_TAKIM" , birSaticiCalisan.getTuttuguTakimKod());
                oMap.put(tableName , row , "HOBILERI" , birSaticiCalisan.getHobiKod());
                oMap.put(tableName , row , "CALISAN_STATUSU" , birSaticiCalisan.getCalStatuKod());
                oMap.put(tableName , row , "KAPANMA_NEDENI" , birSaticiCalisan.getCalKismiKapanmaNedenKod());
                oMap.put(tableName , row , "YETKI_SEVIYESI" , birSaticiCalisan.getYetkiGirisKod());
                oMap.put(tableName , row , "YETKI_SEVIYESI_GUNCELLEME_TAR" , birSaticiCalisan.getYetkiGirisKodGuncellemeTar());
                oMap.put(tableName , row , "ONCEKI_YETKI_SEVIYESI" , birSaticiCalisan.getOncekiYetkiGirisKod());
                oMap.put(tableName , row , "ONCEKI_YETKI_SEVIYESI_GUNCELLEME_TAR" , birSaticiCalisan.getOncekiYetkiGuncellemeTar());
                oMap.put(tableName , row , "GIZLI_YETKI_SEVIYESI" , birSaticiCalisan.getYetkiGirisKod());
                oMap.put(tableName , row , "BANKA_KOD" , birSaticiCalisan.getDigerBankaKod());
                oMap.put(tableName , row , "DI_BANKA_KOD" , LovHelper.diLov(birSaticiCalisan.getDigerBankaKod() , "3247/LOV_BANKA" , "BANKA_ADI"));
                oMap.put(tableName , row , "SUBE_KOD" , birSaticiCalisan.getDigerSubeKod());
                oMap.put(tableName , row , "DI_SUBE_KOD" ,
                        LovHelper.diLov(birSaticiCalisan.getDigerSubeKod() , birSaticiCalisan.getDigerBankaKod() , oMap.getString("IL_KOD") , "3247/LOV_BANKA_SUBE" , "SUBE_ADI"));
                oMap.put(tableName , row , "HESAP_A" , birSaticiCalisan.getDigerHesapNo());
                oMap.put(tableName , row , "MUSTERI_HESAP_NO" , birSaticiCalisan.getHesapNo());
                oMap.put(tableName , row , "DI_MUSTERI_HESAP_NO" , LovHelper.diLov(birSaticiCalisan.getHesapNo() , birSaticiCalisan.getMusteriNo() , "3247/LOV_VDSZ_HESAP" , "KISA_ISIM"));
                oMap.put(tableName , row , "YENI_MUSTERI_MI" , false);
                
                row++;
            }
            
			List<?> saticiTahsisFaaliyetList = (List<?>) iMap.get("FAALIYET_KONULARI");

			tableName = "FAALIYET_KONULARI";
			row = 0;
			for (int i = 0; i < saticiTahsisFaaliyetList.size(); i++) {
				BirSaticiTahsisFaaliyet birSaticiTahsisFaaliyet = (BirSaticiTahsisFaaliyet) session.createCriteria(BirSaticiTahsisFaaliyet.class)
						.add(Restrictions.eq("id.saticiKod", iMap.getBigDecimal("SATICI_KOD")))
						.add(Restrictions.eq("id.faaliyetKodu", iMap.getString(tableName, i, "FAALIYET_KODU")))
						.add(Restrictions.eq("id.tur", "X"))
					.uniqueResult();

				if (birSaticiTahsisFaaliyet != null)
					oMap.put(tableName, row, "SEC", true);
				oMap.put(tableName, row, "FAALIYET_KODU", iMap.getString(tableName, row, "FAALIYET_KODU"));
				oMap.put(tableName, row, "FAALIYET_KONUSU", iMap.getString(tableName, row, "FAALIYET_KONUSU"));
				row++;
			}
			oMap.get(tableName);
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN3247_GET_INFO_BY_TRX_NO")
    public static GMMap trn3247GetInfoByTrxNo(GMMap iMap) {
        
        try{
            
            GMMap oMap = new GMMap();
            
            setBirSaticiMap(iMap.getBigDecimal("TRX_NO") , oMap);
            

			String faaliyetKonulari = "FAALIYET_KONULARI";
			ConsumerLoanTRN3162Services.setFaaliyetKonulariTable(iMap.getBigDecimal("TRX_NO"), faaliyetKonulari, oMap.getBigDecimal("SATICI_KOD"), (List<?>) iMap.get("FAALIYET_KONULARI"), oMap);
            
            String dagiticiFirmaTableName = "BAGLI_OLDUGU_DAGITICI_FIRMALAR";
            setDagiticiFirmalarTable(iMap.getBigDecimal("TRX_NO") , dagiticiFirmaTableName , oMap);
            String calisanlarTableName = "CALISANLAR";
            setCalisanlarTable(iMap.getBigDecimal("TRX_NO") , calisanlarTableName , oMap);
            
            GMMap roleTreeMap = GMServiceExecuter.call("BNSPR_TRN3161_GET_DLR_ROLE_TREE_BY_TRX_NO", iMap);
            oMap.put("YETKI_SEVIYE_TREE", roleTreeMap.get("LIST"));
            
            // Renklendirme
            
            if ("ISLEM_GORUNTULE".equals(iMap.getString("ACTION"))){
                GMMap i2Map = new GMMap();
                i2Map.put("TRX_NO" , iMap.get("TRX_NO"));
                i2Map.put("SATICI_KOD" , oMap.get("SATICI_KOD"));
                BigDecimal oldTxNo = GMServiceExecuter.call("BNSPR_TRN3247_GET_ONCEKI_TX_NO" , i2Map).getBigDecimal("OLD_TRX_NO");
                
                GMMap oldMap = new GMMap();
                if (oldTxNo != null){
                    setBirSaticiMap(oldTxNo , oldMap);
                } else{
                    oldMap = null;
                }
                
                oMap.putAll(BeanSetProperties.mapDifference(oldMap , oMap));
                
				String oldFaaliyetKonulari = "OLD_FAALIYET_KONULARI";
				ConsumerLoanTRN3162Services.setFaaliyetKonulariTable(oldTxNo, oldFaaliyetKonulari, i2Map.getBigDecimal("SATICI_KOD"), (List<?>) iMap.get("FAALIYET_KONULARI"), oMap);
				oMap.put("FAALIYET_KONULARI_COLOR_DATA", BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get(oldFaaliyetKonulari), (ArrayList<?>) oMap.get(faaliyetKonulari), "FAALIYET_KODU").get("COLOR_DATA"));
                
                // Tablolar i�in renklendirme
                String oldDagiticiFirmaTableName = "OLD_BAGLI_OLDUGU_DAGITICI_FIRMALAR";
                setDagiticiFirmalarTable(oldTxNo , oldDagiticiFirmaTableName , oMap);
                oMap.put("DAGITICI_FIRMALAR_COLOR_DATA" , BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get(oldDagiticiFirmaTableName) ,
                        (ArrayList<?>) oMap.get(dagiticiFirmaTableName) , "VALUE").get("COLOR_DATA"));
                
                // Tablolar i�in renklendirme
                String oldCalisanlarTableName = "OLD_CALISANLAR";
                setCalisanlarTable(oldTxNo , oldCalisanlarTableName , oMap);
                oMap.put("CALISANLAR_COLOR_DATA" , BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get(oldCalisanlarTableName) ,
                        (ArrayList<?>) oMap.get(calisanlarTableName) , "KOD").get("COLOR_DATA"));
                
            }
            // Renklendirme biti�
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    private static void setBirSaticiMap(BigDecimal txNo, GMMap oMap) throws SQLException, FileNotFoundException {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            BirSaticiTx birSaticiTx = (BirSaticiTx) session.get(BirSaticiTx.class , txNo);
            
            oMap.put("SATICI_KOD" , birSaticiTx.getKod());
            oMap.put("DI_SATICI_KOD" , birSaticiTx.getSaticiAdi());
            
            BigDecimal musteriNo = birSaticiTx.getMusteriNo();
            oMap.put("MUSTERI_NO" , musteriNo);
            
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall(LovHelper.getLOVQuery("3247/LOV_TUZEL_MUSTERI_GET_INFO"));
            stmt.setBigDecimal(1 , musteriNo);
            stmt.setBigDecimal(2 , musteriNo);
            rSet = stmt.executeQuery();
            
            if (rSet.next()){
                oMap.put("DI_MUSTERI_NO" , rSet.getString("UNVAN"));
                oMap.put("VERGI_NUMARASI" , rSet.getString("VERGI_NO"));
                oMap.put("VERGI_DAIRESI_IL" , rSet.getString("VERGI_IL_KODU"));
                oMap.put("VERGI_DAIRESI" , rSet.getString("VERGI_DAIRE_KODU"));
                oMap.put("SIRKET_TIPI" , rSet.getString("FIRMA_TIPI"));
                
                GMMap xMap = new GMMap();
                xMap.put("EMAIL_1" , rSet.getString("EMAIL_IS"));
                GMMap eMap = new GMMap();
                eMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_PARSE_EMAILS" , xMap));
                oMap.put("E_POSTA_NAME" , eMap.getString("EMAIL_11"));
                oMap.put("E_POSTA_NET" , eMap.getString("EMAIL_12"));
                
                oMap.put("TELEFON_ALAN" , rSet.getString("TEL_ALAN"));
                oMap.put("TELEFON" , rSet.getString("TELEFON"));
                oMap.put("FAX_ALAN" , rSet.getString("FAX_ALAN"));
                oMap.put("FAKS" , rSet.getString("FAX"));
                oMap.put("ADRES" , rSet.getString("ADRES"));
                oMap.put("IL_KOD" , rSet.getString("ADRES_IL"));
                oMap.put("ILCE_KOD" , rSet.getString("ADRES_ILCE"));
                
                oMap.put("WEB_ADRESI" , rSet.getString("WEB_ADRES"));
                oMap.put("KURULUS_TARIHI" , rSet.getDate("KURULUS_TARIHI"));
            }
            
            GMMap aMap = new GMMap();
            aMap.put("MUSTERI_NO" , musteriNo);
            /* oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2033_GET_MUSTERI_ADRES", aMap)); */
            
            oMap.put("SATICI_TIP" , birSaticiTx.getSaticiTipKod());
            oMap.put("YETKI_SEVIYESI" , birSaticiTx.getYetkiSeviyeKod());
            oMap.put("BAGLI_OLDUGU_BOLGE" , birSaticiTx.getBagliOldBolgeKod());
            oMap.put("BAGLI_OLDUGU_MERKEZ_BAYI_KOD" , birSaticiTx.getBagliMerkezBayi());
            oMap.put("DI_BAGLI_OLDUGU_MERKEZ_BAYI_KOD" , LovHelper.diLov(birSaticiTx.getBagliMerkezBayi() , "3247/LOV_MERKEZ_BAYI" , "SATICI_ADI"));
            oMap.put("DOKUMAN_YOLLAMA_TIPI" , birSaticiTx.getDokYollamaKod());
            oMap.put("DURUM" , birSaticiTx.getDrm());
            oMap.put("PARA_CIKISI" , birSaticiTx.getParaCikisOtoEh());
            oMap.put("MUSTERI_HESAP_NO" , birSaticiTx.getHesapNo());
            oMap.put("DI_MUSTERI_HESAP_NO" , LovHelper.diLov(birSaticiTx.getHesapNo() , musteriNo , "3247/LOV_VDSZ_HESAP" , "KISA_ISIM"));
            oMap.put("BANKA_KOD" , birSaticiTx.getBankaKod());
            oMap.put("DI_BANKA_KOD" , LovHelper.diLov(birSaticiTx.getBankaKod() , "3247/LOV_BANKA" , "BANKA_ADI"));
            oMap.put("SUBE_KOD" , birSaticiTx.getBankaSube());
            oMap.put("DI_SUBE_KOD" , LovHelper.diLov(birSaticiTx.getBankaSube() , birSaticiTx.getBankaKod() , oMap.getString("IL_KOD") , "3247/LOV_BANKA_SUBE" , "SUBE_ADI"));
            oMap.put("HESAP_A" , birSaticiTx.getBankaHesap());
            oMap.put("SATICI_GORUSU" , birSaticiTx.getSatisGorusKod());
            
            oMap.put("SATICI_ADRES" , birSaticiTx.getAdres());
            oMap.put("SATICI_IL_KOD" , birSaticiTx.getAdresIl());
            oMap.put("SATICI_ILCE_KOD" , birSaticiTx.getAdresIlce());
            oMap.put("SATICI_TELEFON_ALAN" , birSaticiTx.getAlanKodTel());
            oMap.put("SATICI_TELEFON" , birSaticiTx.getTelNo());
            oMap.put("SATICI_FAX_ALAN" , birSaticiTx.getAlanKodFaks());
            oMap.put("SATICI_FAX" , birSaticiTx.getFaksNo());
            oMap.put("BAYI_SORUMLU_KISI" , birSaticiTx.getBayiSorumluKisi());
            oMap.put("PORTFOY_KOD" , birSaticiTx.getPortfoyKod());
            oMap.put("SUBE_MUSTERI_NO" , birSaticiTx.getSubeMusteriNo());
            oMap.put("DISTRIBUTOR_HESAP_NO" , birSaticiTx.getDistributorHesapNo());
            oMap.put("DI_FIRMA_HESAP_NO" , LovHelper.diLov(birSaticiTx.getDistributorHesapNo() , musteriNo , "3247/LOV_FIRMA_HESAP_NO" , "KISA_ISIM"));
            
            if("E".equals(birSaticiTx.getSigortaSatisiEh())){
                oMap.put("SIGORTA_SATISI" , true);	
            }else{
                oMap.put("SIGORTA_SATISI" , false);	
            }
            
            String krediTurKodlari = birSaticiTx.getKrdTurKodlari();
            oMap.put("F_IHTIYAC" , false);
            oMap.put("F_TASIT" , false);
            oMap.put("F_KONUT" , false);
            oMap.put("F_MIKRO" , false);
            if (krediTurKodlari.charAt(0) == '1')
                oMap.put("F_IHTIYAC" , true);
            if (krediTurKodlari.charAt(1) == '1')
                oMap.put("F_KONUT" , true);
            if (krediTurKodlari.charAt(2) == '1')
                oMap.put("F_TASIT" , true);
            if (krediTurKodlari.charAt(3) == '1')
                oMap.put("F_MIKRO" , true);
            
            oMap.put("ACIKLAMA" , birSaticiTx.getAciklama());
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
    }
    
    private static void setDagiticiFirmalarTable(BigDecimal txNo, String tableName, GMMap oMap) {
        Session session = DAOSession.getSession("BNSPRDal");
        List<?> dagitiFirmalar = session.createCriteria(BirSaticiIliskiTx.class).add(Restrictions.eq("id.txNo" , txNo)).list();
        int row = 0;
        for (int i = 0; i < dagitiFirmalar.size(); i++){
            BirSaticiIliskiTx birSaticiIliskiTx = (BirSaticiIliskiTx) dagitiFirmalar.get(i);
            oMap.put(tableName , row , "SEC" , GuimlUtil.convertToCheckBoxSelected(birSaticiIliskiTx.getSec()));
            oMap.put(tableName , row , "VALUE" , birSaticiIliskiTx.getId().getBagliOldSatKod());
            oMap.put(tableName , row , "NAME" , LovHelper.diLov(birSaticiIliskiTx.getId().getBagliOldSatKod() , "3247/LOV_DAG_FIRMA_ALL" , "SATICI_ADI"));
            row++;
        }
    }
    
    private static void setCalisanlarTable(BigDecimal txNo, String tableName, GMMap oMap) {
        Session session = DAOSession.getSession("BNSPRDal");
        
        List<?> calisanlarList = session.createCriteria(BirSaticiCalisanTx.class).add(Restrictions.eq("id.txNo" , txNo)).list();
        
        int row = 0;
        for (int i = 0; i < calisanlarList.size(); i++){
            
            BirSaticiCalisanTx birSaticiCalisanTx = (BirSaticiCalisanTx) calisanlarList.get(i);
            oMap.put(tableName , row , "MUSTERI_NO" , birSaticiCalisanTx.getMusteriNo());
            
            ArrayList<Object> listPar = new ArrayList<Object>();
            listPar.add(birSaticiCalisanTx.getMusteriNo());
            HashMap<?, ?> musteriLovMap = LovHelper.diLovAll(birSaticiCalisanTx.getMusteriNo() , "3247/LOV_GERCEK_MUSTERI_GET_INFO" , listPar);
            if (musteriLovMap != null){
                oMap.put(tableName , row , "DI_MUSTERI_NO" , (String) musteriLovMap.get("UNVAN"));
                oMap.put(tableName , row , "TCK_NO" , (String) musteriLovMap.get("TC_KIMLIK_NO"));
                oMap.put(tableName , row , "ADI" , (String) musteriLovMap.get("ADI"));
                oMap.put(tableName , row , "IKINCI_ADI" , (String) musteriLovMap.get("IKINCI_ADI"));
                oMap.put(tableName , row , "SOYADI" , (String) musteriLovMap.get("SOYADI"));
                oMap.put(tableName , row , "UYRUK" , (String) musteriLovMap.get("UYRUK_KOD"));
                oMap.put(tableName , row , "DOGUM_TARIHI" , musteriLovMap.get("DOGUM_TARIHI"));
                oMap.put(tableName , row , "DOGUM_YERI" , (String) musteriLovMap.get("DOGUM_YERI"));
                oMap.put(tableName , row , "BABA_ADI" , (String) musteriLovMap.get("BABA_ADI"));
                oMap.put(tableName , row , "ANNE_ADI" , (String) musteriLovMap.get("ANNE_ADI"));
                
                GMMap xMap = new GMMap();
                xMap.put("EMAIL_1" , (String) musteriLovMap.get("EMAIL_KISISEL"));
                oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN10011_PARSE_EMAILS" , xMap));
                oMap.put(tableName , row , "EPOSTA_NAME" , oMap.get("EMAIL_11"));
                oMap.put(tableName , row , "EPOSTA_NET" , oMap.get("EMAIL_12"));
                
                oMap.put(tableName , row , "CEP_TEL_ALAN" , (String) musteriLovMap.get("GSM_ALAN"));
                oMap.put(tableName , row , "CEP_TEL" , (String) musteriLovMap.get("GSM"));
            }
            oMap.put(tableName , row , "KOD" , birSaticiCalisanTx.getId().getKod());
            oMap.put(tableName , row , "ORTAK_MI" , birSaticiCalisanTx.getOrtakEh());
            oMap.put(tableName , row , "ORTAKLIK_PAYI" , birSaticiCalisanTx.getOrtaklikPayi());
            oMap.put(tableName , row , "ISE_BASLAMA_TARIHI" , birSaticiCalisanTx.getIseBaslamaTar());
            oMap.put(tableName , row , "POZISYONU" , birSaticiCalisanTx.getPozisyonKod());
            oMap.put(tableName , row , "TUTTUGU_TAKIM" , birSaticiCalisanTx.getTuttuguTakimKod());
            oMap.put(tableName , row , "HOBILERI" , birSaticiCalisanTx.getHobiKod());
            oMap.put(tableName , row , "CALISAN_STATUSU" , birSaticiCalisanTx.getCalStatuKod());
            oMap.put(tableName , row , "KAPANMA_NEDENI" , birSaticiCalisanTx.getCalKismiKapanmaNedenKod());
            oMap.put(tableName , row , "YETKI_SEVIYESI" , birSaticiCalisanTx.getYetkiGirisKod());
            oMap.put(tableName , row , "YETKI_SEVIYESI_GUNCELLEME_TAR" , birSaticiCalisanTx.getYetkiGirisKodGuncellemeTar());
            oMap.put(tableName , row , "ONCEKI_YETKI_SEVIYESI" , birSaticiCalisanTx.getOncekiYetkiGirisKod());
            oMap.put(tableName , row , "ONCEKI_YETKI_SEVIYESI_GUNCELLEME_TAR" , birSaticiCalisanTx.getOncekiYetkiGuncellemeTar());
            oMap.put(tableName , row , "GIZLI_YETKI_SEVIYESI" , birSaticiCalisanTx.getYetkiGirisKod());
            oMap.put(tableName , row , "BANKA_KOD" , birSaticiCalisanTx.getDigerBankaKod());
            oMap.put(tableName , row , "DI_BANKA_KOD" , LovHelper.diLov(birSaticiCalisanTx.getDigerBankaKod() , "3247/LOV_BANKA" , "BANKA_ADI"));
            oMap.put(tableName , row , "SUBE_KOD" , birSaticiCalisanTx.getDigerSubeKod());
            oMap.put(tableName , row , "DI_SUBE_KOD" ,
                    LovHelper.diLov(birSaticiCalisanTx.getDigerSubeKod() , birSaticiCalisanTx.getDigerBankaKod() , oMap.getString("IL_KOD") , "3247/LOV_BANKA_SUBE" , "SUBE_ADI"));
            oMap.put(tableName , row , "HESAP_A" , birSaticiCalisanTx.getDigerHesapNo());
            oMap.put(tableName , row , "MUSTERI_HESAP_NO" , birSaticiCalisanTx.getHesapNo());
            oMap.put(tableName , row , "DI_MUSTERI_HESAP_NO" , LovHelper.diLov(birSaticiCalisanTx.getHesapNo() , birSaticiCalisanTx.getMusteriNo() , "3247/LOV_VDSZ_HESAP" , "KISA_ISIM"));
            oMap.put(tableName , row , "YENI_MUSTERI_MI" , false);
            
            row++;
        }
    }
    
    @GraymoundService("BNSPR_TRN3247_GET_ONCEKI_TX_NO")
    public static GMMap getOncekiTxNo(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN3247.onceki_txno_3247(?,?)}");
            stmt.registerOutParameter(1 , Types.NUMERIC);
            stmt.setBigDecimal(2 , iMap.getBigDecimal("TRX_NO"));
            stmt.setBigDecimal(3 , iMap.getBigDecimal("SATICI_KOD"));
            stmt.execute();
            
            oMap.put("OLD_TRX_NO" , stmt.getBigDecimal(1));
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN3247_GET_MUSTERI_BAYI_BILGILERI")
    // [1]MUSTERI_NO IN NUMBER,
    // [2]VERGI_IL_KODU OUT VARCHAR2,
    // [3]VERGI_DAIRE_KODU OUT VARCHAR2,
    // [4]VERGI_NO OUT NUMBER,
    // [5]EMAIL OUT VARCHAR2,
    // [6]WEB_ADRES OUT VARCHAR2,
    // [7]TICARI_UNVAN OUT VARCHAR2,
    // [8]FIRMA_TIPI OUT VARCHAR2,
    // [9]KURULUS_TARIHI OUT DATE,
    // [10]ADRES_KOD OUT VARCHAR2,
    // [11]ISYERI_UNVANI OUT VARCHAR2,
    // [12]ADRES OUT VARCHAR2,
    // [13]SEMT OUT VARCHAR2,
    // [14]IL_KOD OUT VARCHAR2,
    // [15]ILCE_KOD OUT VARCHAR2,
    // [16]POSTA_KOD OUT VARCHAR2,
    // [17]ULKE_KOD OUT VARCHAR2,
    // [18]TEL_TIP OUT VARCHAR2,
    // [19]ALAN_KOD OUT VARCHAR2,
    // [20]TELEFON_NO OUT VARCHAR2,
    public static GMMap getMusteriBayiBilgileri(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{call pkg_musteri_bpm.musteri_bayi_bilgileri(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
            
            stmt.setBigDecimal(1 , GuimlUtil.getTableCellBigDecimal(iMap.get("MUSTERI_NO")));
            
            stmt.registerOutParameter(2 , Types.VARCHAR);
            stmt.registerOutParameter(3 , Types.VARCHAR);
            stmt.registerOutParameter(4 , Types.NUMERIC);
            stmt.registerOutParameter(5 , Types.VARCHAR);
            stmt.registerOutParameter(6 , Types.VARCHAR);
            stmt.registerOutParameter(7 , Types.VARCHAR);
            stmt.registerOutParameter(8 , Types.VARCHAR);
            stmt.registerOutParameter(9 , Types.DATE);
            stmt.registerOutParameter(10 , Types.VARCHAR);
            stmt.registerOutParameter(11 , Types.VARCHAR);
            stmt.registerOutParameter(12 , Types.VARCHAR);
            stmt.registerOutParameter(13 , Types.VARCHAR);
            stmt.registerOutParameter(14 , Types.VARCHAR);
            stmt.registerOutParameter(15 , Types.VARCHAR);
            stmt.registerOutParameter(16 , Types.VARCHAR);
            stmt.registerOutParameter(17 , Types.VARCHAR);
            stmt.registerOutParameter(18 , Types.VARCHAR);
            stmt.registerOutParameter(19 , Types.VARCHAR);
            stmt.registerOutParameter(20 , Types.VARCHAR);
            stmt.registerOutParameter(21 , Types.VARCHAR);
            
            stmt.execute();
            
            int i = 2;
            
            oMap.put("VERGI_IL_KODU" , stmt.getString(i++));
            oMap.put("VERGI_DAIRE_KODU" , stmt.getString(i++));
            oMap.put("VERGI_NO" , stmt.getBigDecimal(i++));
            /*
             * if(stmt.getBigDecimal(i) != null) oMap.put("VERGI_NO", stmt.getBigDecimal(i++).toString()); else{
             * oMap.put("VERGI_NO", null); i++; }
             */
            oMap.put("EMAIL" , stmt.getString(i++));
            oMap.put("WEB_ADRES" , stmt.getString(i++));
            oMap.put("TICARI_UNVAN" , stmt.getString(i++));
            oMap.put("FIRMA_TIPI" , stmt.getString(i++));
            oMap.put("KURULUS_TARIHI" , stmt.getDate(i++));
            /*
             * if(stmt.getDate(i) != null) oMap.put("KURULUS_TARIHI", stmt.getDate(i++).toString()); else{
             * oMap.put("KURULUS_TARIHI", null); i++; }
             */
            oMap.put("ADRES_KOD" , stmt.getString(i++));
            oMap.put("ISYERI_UNVANI" , stmt.getString(i++));
            oMap.put("ADRES" , stmt.getString(i++));
            oMap.put("SEMT" , stmt.getString(i++));
            oMap.put("IL_KOD" , stmt.getString(i++));
            oMap.put("ILCE_KOD" , stmt.getString(i++));
            oMap.put("POSTA_KOD" , stmt.getString(i++));
            oMap.put("ULKE_KOD" , stmt.getString(i++));
            oMap.put("TEL_TIP" , stmt.getString(i++));
            oMap.put("ALAN_KOD" , stmt.getString(i++));
            oMap.put("TELEFON_NO" , stmt.getString(i++));
            oMap.put("MUSTERI_KONTAKT" , stmt.getString(i++));
            
            return oMap;
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
       
    @GraymoundService("BNSPR_TRN3247_AFTER_APPROVAL")
    public static GMMap afterApproval(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            BirSaticiTx birSaticiTx = (BirSaticiTx) session.createCriteria(BirSaticiTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
            
            GMMap adcMap = new GMMap();
            if("S".equals(birSaticiTx.getSaticiTipKod())){
            	adcMap.put("MUSTERI_NO", birSaticiTx.getSubeMusteriNo());
            }else{
            	adcMap.put("MUSTERI_NO", birSaticiTx.getMusteriNo());
            }
            
            GMMap roleMap = new GMMap();
            iMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO")); 
            roleMap.putAll(GMServiceExecuter.call("BNSPR_TRN3161_GET_DLR_ROLE_TREE_BY_TRX_NO", iMap));
            adcMap.put("ROLES", roleMap.get("ROLES"));            
            adcMap.putAll(GMServiceExecuter.call("BNSPR_TRN3161_CREATE_DLR_ADC_USER", adcMap));         
            adcMap.put("TREE", roleMap.get("LIST"));
            GMServiceExecuter.execute("ADC_CORE_USER_ROLE_UPDATE", adcMap);
            
            List<?> list = session.createCriteria(BirSaticiCalisan.class).add(Restrictions.eq("birSatici.kod" , birSaticiTx.getKod())).list();
            GMMap oMap = new GMMap();
            String calisanKod = null;
            String calStatuKod = null;
            for (Object name : list) {
                BirSaticiCalisan birSaticiCalisan = (BirSaticiCalisan) name;
                calisanKod = birSaticiCalisan.getKod().toString();
                calStatuKod = birSaticiCalisan.getCalStatuKod();
                iMap.put("UID" , calisanKod);
                oMap = GMServiceExecuter.call("BNSPR_SYSTEM_IS_LDAP_USER_DLR" , iMap);
                if ("IPTAL".equals(birSaticiCalisan.getDurum())){
                    iMap.put("USER_STATUS" , "Inactive");
                } else{
                    if ("K".equals(calStatuKod)){
                        iMap.put("USER_STATUS" , "Inactive");
                    } else{
                        iMap.put("USER_STATUS" , "Active");
                    }
                }
                if (oMap.getBoolean("LDAP_USER")){
                    GMServiceExecuter.execute("BNSPR_SYSTEM_LDAP_SET_USER_STATUS_DLR" , iMap);
                }
            }
            
            @SuppressWarnings("unchecked")
			List<BirSaticiCalisanTx> calisanTxList  = session.createCriteria(BirSaticiCalisanTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("ISLEM_NO"))).list();
            if(calisanTxList != null) {
	            for (BirSaticiCalisanTx birSaticiCalisanTx : calisanTxList){
	                GMMap serviceMap = new GMMap();
	                try {
		                serviceMap.put("USERNAME" , birSaticiCalisanTx.getId().getKod());
		                serviceMap.put("ROLE_CODE" , birSaticiCalisanTx.getYetkiGirisKod());
		                serviceMap.put("SERVICE_NAME" , "ADC_CORE_REMOTE_USER_ROLE_UPDATE");
		                GMServiceExecuter.call("ADK_CALL_SERVICE" , serviceMap);
	                } catch (Exception e) {
	                	// Ilgili kullanicinin ADC_USER yok. Sonraki ile devam et
	                	System.out.println("Cannot update dealer employee user role " +serviceMap);
	                }                
	            }
            }
            
            return new GMMap();
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_3247_GET_MERKEZ_BAYI_INFO")
    public static GMMap getMerkezBayiInfo(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            GMMap oMap = new GMMap();
            BirSatici birSatici = (BirSatici) session.get(BirSatici.class , iMap.getBigDecimal("MERKEZ_BAYI_KOD"));
            
            oMap.put("MUSTERI_NO" , birSatici.getMusteriNo());
            oMap.put("HESAP_NO" , birSatici.getHesapNo());
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3247_GET_BAYI_SORUMLU_KISI")
    public static GMMap getBayiSorumluKisi(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_TRN3247.bayi_sorumlu_personeller(?)}");
            
            stmt.registerOutParameter(1 , -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            
            while (rSet.next()){
                GuimlUtil.wrapMyCombo(oMap , "BAYI_SORUMLU_KISI" , rSet.getString(1) , rSet.getString(2));
            }
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
}
