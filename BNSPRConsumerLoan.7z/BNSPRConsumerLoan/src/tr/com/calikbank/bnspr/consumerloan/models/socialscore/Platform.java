package tr.com.calikbank.bnspr.consumerloan.models.socialscore;

public class Platform {
	private String Brand;

    private String Version;

    private String Bits;

    public String getBrand ()
    {
        return Brand;
    }

    public void setBrand (String Brand)
    {
        this.Brand = Brand;
    }

    public String getVersion ()
    {
        return Version;
    }

    public void setVersion (String Version)
    {
        this.Version = Version;
    }

    public String getBits ()
    {
        return Bits;
    }

    public void setBits (String Bits)
    {
        this.Bits = Bits;
    }

}
