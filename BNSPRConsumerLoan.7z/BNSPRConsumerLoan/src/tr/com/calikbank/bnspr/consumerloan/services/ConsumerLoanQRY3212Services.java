package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
/**
 * 
 * Service class for QRY3212 
 * 
 * Depended page is BNSPR_QRY3212.guiml
 * 
 * @author yasar.yasa
 *
 */
public class ConsumerLoanQRY3212Services {
	
	
	@GraymoundService("BNSPR_QRY3212_BAYI_BLOKE_SORGULA")
	public static GMMap queryBayiBloke(GMMap iMap) {
		GMMap resultMap = new GMMap();
		try {
			Object[] inputValues = new Object[12];
			inputValues[0] = BnsprType.NUMBER;
			inputValues[1] = iMap.getBigDecimal("basvuru_no");
			inputValues[2] = BnsprType.NUMBER;
			inputValues[3] = iMap.getBigDecimal("musteri_no");
			inputValues[4] = BnsprType.NUMBER;
			inputValues[5] = iMap.getBigDecimal("bayi_kod");
			inputValues[6] = BnsprType.DATE;
			inputValues[7] = iMap.getDate("baslangic_tarihi");
			inputValues[8] = BnsprType.DATE;
			inputValues[9] = iMap.getDate("bitis_tarihi");
			inputValues[10] = BnsprType.STRING;
			inputValues[11] = iMap.getString("DURUM");
			
			String func = "{? = call PKG_RC3212.BLOKE_HESAP_SORGULA(?,?,?,?,?,?)}";
			//TABLO_BLOKE aray�zde out edilecek de�erdir. Map seklinde outjection yap�l�yor
			resultMap = (GMMap) DALUtil.callOracleRefCursorFunction(func, "TABLO_BLOKE", inputValues);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return resultMap;
	}
	
	
	@GraymoundService("BNSPR_QRY3212_GET_DATES")
	public static GMMap getDates(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		Date toDay;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_muhasebe.Banka_Tarihi_Bul()}");
			stmt.registerOutParameter(1, Types.DATE);
			stmt.execute();
			toDay = stmt.getDate(1);
			
			BigDecimal ayOnce = new BigDecimal(-1);
			stmt = conn.prepareCall("{? = call pkg_tarih.ay_sonra(?,?)}");
			stmt.registerOutParameter(1, Types.DATE);
			stmt.setDate(2, toDay) ;
			stmt.setBigDecimal(3, ayOnce);
			stmt.execute();
			oMap.put("BASLANGIC_TARIHI", stmt.getDate(1));
			oMap.put("BITIS_TARIHI", toDay);
			
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3212_GET_DESCRIPTION")
	public static GMMap queryBlokeTx(GMMap iMap) {
		GMMap resultMap = new GMMap();
		try {
			Object[] inputValues = new Object[2];
			inputValues[0] = BnsprType.NUMBER;
			inputValues[1] = iMap.getBigDecimal("basvuruNo");
			
			String func = "{? = call PKG_RC3212.BLOKE_HESAP_TX_SORGULA(?)}";
			resultMap = (GMMap) DALUtil.callOracleRefCursorFunction(func, "TABLO_BLOKE_TX", inputValues);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return resultMap;
	}
}
