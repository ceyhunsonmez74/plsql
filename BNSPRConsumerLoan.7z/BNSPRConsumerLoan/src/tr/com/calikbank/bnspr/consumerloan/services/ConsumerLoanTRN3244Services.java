package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruNoterAcilisTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruTakipKapaTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruTakipTahsilTx;
import tr.com.aktifbank.bnspr.dao.KkbVefatRisk;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3244Services {

    @GraymoundService("BNSPR_TRN3244_SAVE")
    public static Map<?, ?> save(GMMap iMap) {

	try {
	    Session session = DAOSession.getSession("BNSPRDal");

	    if (iMap.getBigDecimal("TAB").compareTo(new BigDecimal(0)) == 0) {

		BirBasvuruNoterAcilisTx birBasvuruNoterAcilisTx = new BirBasvuruNoterAcilisTx();

		birBasvuruNoterAcilisTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		birBasvuruNoterAcilisTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO_NOTER"));
		birBasvuruNoterAcilisTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO_NOTER"));
		birBasvuruNoterAcilisTx.setKrediHesapNo(iMap.getBigDecimal("KREDI_HESAP_NO_NOTER"));
		birBasvuruNoterAcilisTx.setVadesizHesapNo(iMap.getBigDecimal("VADESIZ_HESAP_NO_NOTER"));
		birBasvuruNoterAcilisTx.setTckn(iMap.getString("TCKN_NOTER"));
		birBasvuruNoterAcilisTx.setNoterMasrafTutar(iMap.getBigDecimal("NOTER_MASRAF_TUTAR"));
		birBasvuruNoterAcilisTx.setDovizKod("TRY");

		session.save(birBasvuruNoterAcilisTx);

		session.flush();

	    } else if (iMap.getBigDecimal("TAB").compareTo(new BigDecimal(1)) == 0) {

		BirBasvuruTakipKapaTx birBasvuruTakipKapaTx = new BirBasvuruTakipKapaTx();

		birBasvuruTakipKapaTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		birBasvuruTakipKapaTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO_TAKIP"));
		birBasvuruTakipKapaTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO_TAKIP"));
		birBasvuruTakipKapaTx.setTakipHesapNo(iMap.getBigDecimal("TAKIP_HESAP_NO_TAKIP"));

		session.save(birBasvuruTakipKapaTx);

		session.flush();

	    } else if (iMap.getBigDecimal("TAB").compareTo(new BigDecimal(2)) == 0) {

		BirBasvuruTakipTahsilTx birBasvuruTakipTahsilTx = new BirBasvuruTakipTahsilTx();

		birBasvuruTakipTahsilTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		birBasvuruTakipTahsilTx.setAvukatlikHesapNo(iMap.getBigDecimal("AVUKATLIK_HESAP_NO_TAHSIL"));
		birBasvuruTakipTahsilTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO_TAHSIL"));
		birBasvuruTakipTahsilTx.setKrediHesapNo(iMap.getBigDecimal("KREDI_HESAP_NO_TAHSIL"));
		birBasvuruTakipTahsilTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO_TAHSIL"));
		birBasvuruTakipTahsilTx.setNoterHesapNo(iMap.getBigDecimal("NOTER_HESAP_NO_TAHSIL"));
		birBasvuruTakipTahsilTx.setRiskDkHesap(iMap.getBigDecimal("RISK_DK_HESAP_NO_TAHSIL"));
		birBasvuruTakipTahsilTx.setTahsilAvukatlikTutar(iMap.getBigDecimal("AVUKATLIK_TUTAR_TAHSIL"));
		birBasvuruTakipTahsilTx.setTahsilBsmv(iMap.getBigDecimal("BSMV_TAHSIL"));
		birBasvuruTakipTahsilTx.setTahsilFaiz(iMap.getBigDecimal("FAIZ_TAHSIL"));
		birBasvuruTakipTahsilTx.setTahsilKkdf(iMap.getBigDecimal("KKDF_TAHSIL"));
		birBasvuruTakipTahsilTx.setTahsilNoterTutar(iMap.getBigDecimal("NOTER_TUTAR_TAHSIL"));
		birBasvuruTakipTahsilTx.setTahsilRiskTutar(iMap.getBigDecimal("RISK_TUTAR_TAHSIL"));
		birBasvuruTakipTahsilTx.setTakipHesapNo(iMap.getBigDecimal("TAKIP_HESAP_NO_TAHSIL"));
		birBasvuruTakipTahsilTx.setTahsilTemerrutFaiz(iMap.getBigDecimal("TEMERRUT_FAIZ_TAHSIL"));
		birBasvuruTakipTahsilTx.setTahsilGecikmeFaiz(iMap.getBigDecimal("GECIKME_FAIZ_TAHSIL"));
		birBasvuruTakipTahsilTx.setTahsilKtvu(iMap.getBigDecimal("KTVU_TAHSIL"));
		birBasvuruTakipTahsilTx.setKtvuHesapNo(iMap.getBigDecimal("KTVU_HESAP_NO_TAHSIL"));
		
		birBasvuruTakipTahsilTx.setTahsilTemerrutBsmv(iMap.getBigDecimal("TEMERRUT_BSMV"));
		birBasvuruTakipTahsilTx.setTahsilGecikmeKkdf(iMap.getBigDecimal("GECIKME_KKDF"));
		birBasvuruTakipTahsilTx.setTahsilGecikmeBsmv(iMap.getBigDecimal("GECIKME_BSMV"));
		

		if (iMap.getBoolean("TAKIPTEN_KAPALIYA_MI")) {
		    birBasvuruTakipTahsilTx.setTakiptenKapaliyaMi("E");
		} else {
		    birBasvuruTakipTahsilTx.setTakiptenKapaliyaMi("H");
		}
		if (iMap.getBoolean("ONAYSIZ_MASRAF_IPTAL_MI")) {
		    birBasvuruTakipTahsilTx.setOnaysizMasrafIptal("E");
		} else {
		    birBasvuruTakipTahsilTx.setOnaysizMasrafIptal("H");
		}		

		birBasvuruTakipTahsilTx.setVadesizHesapNo(iMap.getBigDecimal("VADESIZ_HESAP_NO_TAHSIL"));
		birBasvuruTakipTahsilTx.setKrediHesapBakiye(iMap.getBigDecimal("KREDI_HESAP_BAKIYE_TAHSIL"));
		birBasvuruTakipTahsilTx.setTakipHesapBakiye(iMap.getBigDecimal("TAKIP_HESAP_BAKIYE_TAHSIL"));
		birBasvuruTakipTahsilTx.setVadesizHesapBakiye(iMap.getBigDecimal("VADESIZ_HESAP_BAKIYE_TAHSIL"));

		session.save(birBasvuruTakipTahsilTx);

		session.flush();

	    }

	    iMap.put("TRX_NAME", "3244");
	    return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
	} catch (Exception e) {
	    throw ExceptionHandler.convertException(e);
	}
    }

    @GraymoundService("BNSPR_TRN3244_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
	try {
	    GMMap oMap = new GMMap();
	    Session session = DAOSession.getSession("BNSPRDal");

	    List<?> list = (List<?>) session.createCriteria(BirBasvuruNoterAcilisTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();

	    for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {

		BirBasvuruNoterAcilisTx birBasvuruNoterAcilisTx = (BirBasvuruNoterAcilisTx) iterator.next();

		oMap.put("BASVURU_NO_NOTER", birBasvuruNoterAcilisTx.getBasvuruNo());
		oMap.put("MUSTERI_NO_NOTER", birBasvuruNoterAcilisTx.getMusteriNo());
		oMap.put("UNVAN_NOTER", LovHelper.diLov(birBasvuruNoterAcilisTx.getMusteriNo(), birBasvuruNoterAcilisTx.getMusteriNo(), "3244/LOV_MUSTERI_NO_NOTER", "UNVAN"));
		oMap.put("KREDI_HESAP_NO_NOTER", birBasvuruNoterAcilisTx.getKrediHesapNo());
		oMap.put("VADESIZ_HESAP_NOTER", birBasvuruNoterAcilisTx.getVadesizHesapNo());
		oMap.put("TCKN_NOTER", birBasvuruNoterAcilisTx.getTckn());
		oMap.put("NOTER_MASRAF_TUTAR", birBasvuruNoterAcilisTx.getNoterMasrafTutar());
		oMap.put("TAB", new BigDecimal(0));

	    }

	    List<?> list2 = (List<?>) session.createCriteria(BirBasvuruTakipKapaTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();

	    for (Iterator<?> iterator = list2.iterator(); iterator.hasNext();) {

		BirBasvuruTakipKapaTx birBasvuruTakipKapaTx = (BirBasvuruTakipKapaTx) iterator.next();

		oMap.put("BASVURU_NO_TAKIP", birBasvuruTakipKapaTx.getBasvuruNo());
		oMap.put("MUSTERI_NO_TAKIP", birBasvuruTakipKapaTx.getMusteriNo());
		oMap.put("UNVAN_TAKIP", LovHelper.diLov(birBasvuruTakipKapaTx.getMusteriNo(), birBasvuruTakipKapaTx.getBasvuruNo(), "3244/LOV_MUSTERI_NO_TAKIP", "UNVAN"));
		oMap.put("TAKIP_HESAP_NO_TAKIP", birBasvuruTakipKapaTx.getTakipHesapNo());
		oMap.put("TAB", new BigDecimal(1));

	    }

	    List<?> list3 = (List<?>) session.createCriteria(BirBasvuruTakipTahsilTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();

	    for (Iterator<?> iterator = list3.iterator(); iterator.hasNext();) {

		BirBasvuruTakipTahsilTx birBasvuruTakipTahsilTx = (BirBasvuruTakipTahsilTx) iterator.next();

		oMap.put("MUSTERI_NO_TAHSIL", birBasvuruTakipTahsilTx.getMusteriNo());
		oMap.put("UNVAN_TAHSIL", LovHelper.diLov(birBasvuruTakipTahsilTx.getMusteriNo(), birBasvuruTakipTahsilTx.getBasvuruNo(), "3244/LOV_MUSTERI_NO_TAHSIL", "UNVAN"));
		oMap.put("BASVURU_NO_TAHSIL", birBasvuruTakipTahsilTx.getBasvuruNo());
		oMap.put("KREDI_HESAP_NO_TAHSIL", birBasvuruTakipTahsilTx.getKrediHesapNo());
		oMap.put("VADESIZ_HESAP_NO_TAHSIL", birBasvuruTakipTahsilTx.getVadesizHesapNo());
		oMap.put("NOTER_HESAP_NO_TAHSIL", birBasvuruTakipTahsilTx.getNoterHesapNo());
		oMap.put("AVUKATLIK_HESAP_NO_TAHSIL", birBasvuruTakipTahsilTx.getAvukatlikHesapNo());
		oMap.put("RISK_TUTAR_TAHSIL", birBasvuruTakipTahsilTx.getTahsilRiskTutar());
		oMap.put("RISK_DK_HESAP_TAHSIL", birBasvuruTakipTahsilTx.getRiskDkHesap());
		oMap.put("NOTER_TUTAR_TAHSIL", birBasvuruTakipTahsilTx.getTahsilNoterTutar());
		oMap.put("AVUKATLIK_TUTAR_TAHSIL", birBasvuruTakipTahsilTx.getTahsilAvukatlikTutar());
		oMap.put("FAIZ_TAHSIL", birBasvuruTakipTahsilTx.getTahsilFaiz());
		oMap.put("BSMV_TAHSIL", birBasvuruTakipTahsilTx.getTahsilBsmv());
		oMap.put("KKDF_TAHSIL", birBasvuruTakipTahsilTx.getTahsilKkdf());
		oMap.put("TAKIP_HESAP_NO_TAHSIL", birBasvuruTakipTahsilTx.getTakipHesapNo());
		oMap.put("TEMERRUT_FAIZ_TAHSIL", birBasvuruTakipTahsilTx.getTahsilTemerrutFaiz());
		oMap.put("GECIKME_FAIZ_TAHSIL", birBasvuruTakipTahsilTx.getTahsilGecikmeFaiz());
		oMap.put("KTVU_TAHSIL", birBasvuruTakipTahsilTx.getTahsilKtvu());
		oMap.put("KTVU_HESAP_NO_TAHSIL", birBasvuruTakipTahsilTx.getKtvuHesapNo());
		oMap.put("TEMERRUT_KKDF_TAHSIL", birBasvuruTakipTahsilTx.getTahsilTemerrutKkdf());
		oMap.put("TEMERRUT_BSMV_TAHSIL", birBasvuruTakipTahsilTx.getTahsilTemerrutBsmv());
		oMap.put("GECIKME_KKDF_TAHSIL", birBasvuruTakipTahsilTx.getTahsilGecikmeKkdf());
		oMap.put("GECIKME_BSMV_TAHSIL", birBasvuruTakipTahsilTx.getTahsilGecikmeBsmv());

		oMap.put("KREDI_HESAP_BAKIYE_TAHSIL", birBasvuruTakipTahsilTx.getKrediHesapBakiye());
		oMap.put("TAKIP_HESAP_BAKIYE_TAHSIL", birBasvuruTakipTahsilTx.getTakipHesapBakiye());
		oMap.put("VADESIZ_HESAP_BAKIYE_TAHSIL", birBasvuruTakipTahsilTx.getVadesizHesapBakiye());

		if (birBasvuruTakipTahsilTx.getTakiptenKapaliyaMi().compareTo("E") == 0) {
		    oMap.put("TAKIPTEN_KAPALIYA_MI", true);
		} else {
		    oMap.put("TAKIPTEN_KAPALIYA_MI", false);
		}
		
		if (birBasvuruTakipTahsilTx.getOnaysizMasrafIptal().compareTo("E") == 0) {
		    oMap.put("ONAYSIZ_MASRAF_IPTAL_MI", true);
		} else {
		    oMap.put("ONAYSIZ_MASRAF_IPTAL_MI", false);
		}

		oMap.put("TAB", new BigDecimal(2));

	    }
	    return oMap;

	} catch (Exception e) {
	    throw new GMRuntimeException(0, e);
	}
    }

    @GraymoundService("BNSPR_TRN3244_GET_TAB_INFO")
    public static GMMap getTabInfo(GMMap iMap) {
	GMMap oMap = new GMMap();
	try {
	    Object[] inputValues = new Object[2];

	    String func = "{? = call PKG_TRN3244.islem_yapilan_tab_bulma(?)}";
	    int i = 0;
	    inputValues = new Object[2];
	    inputValues[i++] = BnsprType.NUMBER;
	    inputValues[i++] = iMap.getBigDecimal("TRX_NO");

	    oMap.put("ISLEM_TABI", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));

	} catch (Exception e) {
	    throw ExceptionHandler.convertException(e);
	}
	return oMap;

    }
    
    @GraymoundService("BNSPR_TRN3244_BASVURU_SORGULA")
    public static GMMap basvuruSorgula(GMMap iMap) {
    	Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSetBasvuru = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC3196.get_takip_basvuru_bilgi(?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			stmt.getMoreResults();
			rSetBasvuru = (ResultSet) stmt.getObject(2);
			
			oMap.putAll(DALUtil.rSetMap(rSetBasvuru));
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSetBasvuru);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

    }

}
