package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTxId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruDegerlendirmeTx;
import tr.com.aktifbank.bnspr.dao.BirDogrulamaKayit;
import tr.com.aktifbank.bnspr.dao.BirDogrulamaKayitTx;
import tr.com.aktifbank.bnspr.dao.BirSgkHizmetDokum;
import tr.com.aktifbank.bnspr.dao.BirSgkHizmetDokumDetay;
import tr.com.aktifbank.bnspr.dao.BirSgkHizmetDokumisyeri;
import tr.com.aktifbank.bnspr.dao.GnlEkranAlanRolTanim;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruFraudTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlik;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlikTx;
import tr.com.calikbank.bnspr.dao.BirDogrulamaDetayTx;
import tr.com.calikbank.bnspr.dao.BirDogrulamaDetayTxId;
import tr.com.calikbank.bnspr.dao.BirDogrulamaTx;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsisFaaliyet;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

@SuppressWarnings("deprecation")
public class ConsumerLoanTRN3180Services {

	private static final String DOG_KOD_ULASILDI = "1";
	private static final String DOG_KOD_ULASILMADI = "2";
	private static final String DOG_KOD_TEKRAR_ARANACAK = "3";
	private static final String DOG_SEBEP_KOD_ARAMA_SAYISI_ASILDI = "24";

	private static final String DOG_KOD_ULASILDI_NEDEN = "28";

	private static final String NBSM_SONUC_ARANACAK_MUS = "N";
	private static final String NBSM_SONUC_ARANACAK_ISYERI = "Not Required";

	private static final String ISLEM_SONRASI_DURUM_KODU_NBSM = "NBSM";
	private static final String ISLEM_SONRASI_DURUM_KODU_IPTAL = "IPTAL";
	private static final String ISLEM_SONRASI_DURUM_KODU_KANAL_IADE = "KANALIADE";

	private static final String AKSIYON_KODU_IPTAL = "C";
	private static final String AKSIYON_KODU_KANAL_IADE = "I";
	private static final String AKSIYON_KARAR_KODU_IPTAL = "2";
	private static final String AKSIYON_KARAR_KODU_KANAL_IADE = "6";

	final static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd HHmmss");
	final static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd.MM.yyyy");
	final static SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyyMMdd");

	@GraymoundService("BNSPR_TRN3180_GET_BASVURU")
	public static GMMap getBasvuruBilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			if (iMap.getDate("BASVURU_TARIHI_BAS") != null && iMap.getDate("BASVURU_TARIHI_BIT") != null) {
				if (iMap.getDate("BASVURU_TARIHI_BAS").after(iMap.getDate("BASVURU_TARIHI_BIT"))) {
					iMap.put("HATA_NO", new BigDecimal(915));
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3180.RC_TRN3180_Musteri_Dogrulama(?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;

			stmt.registerOutParameter(i++, -10);

			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TCKN"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));

			if (iMap.getDate("BASVURU_TARIHI_BAS") != null)
				stmt.setDate(i++, new Date(iMap.getDate("BASVURU_TARIHI_BAS").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getDate("BASVURU_TARIHI_BIT") != null)
				stmt.setDate(i++, new Date(iMap.getDate("BASVURU_TARIHI_BIT").getTime()));
			else
				stmt.setDate(i++, null);

			stmt.setBigDecimal(i++, iMap.getBigDecimal("IS_TEL_NO"));
			stmt.setString(i++, iMap.getString("IS_YERI_ADI"));
			stmt.setString(i++, iMap.getString("CALISMA_SEKLI"));
			stmt.setString(i++, iMap.getString("KONTROL_TIPI"));
			stmt.setString(i++, iMap.getString("KANAL_KODU"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResultsPutStr(rSet, "RESULTS"));
			GMServerDatasource.close(rSet);

			/**
			 * TODO:performans iyilestirmesi yapilacak
			 */
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			int row = 0;
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
			while (rSet.next()) {
				java.util.Date havuzaGelis = dateFormat.parse(dateFormat.format(rSet.getTimestamp("HAVUZA_GELIS_TARIHI")));
				java.util.Date basvuruTarihi = dateFormat.parse(dateFormat.format(rSet.getTimestamp("BASVURU_TARIH")));
				oMap.put("RESULTS", row, "HAVUZA_GELIS_TARIHI", dateFormat.format(havuzaGelis));
				oMap.put("RESULTS", row, "BASVURU_TARIH", dateFormat.format(basvuruTarihi));
				row++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3180_MUSTERI_GETIR")
	public static GMMap getOncelikliMusteri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String userName = GMServiceExecuter.call("BNSPR_COMMON_GET_USER_NAME", iMap).getString("USER_NAME");

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3180.RC_TRN3180_Oncelikli_Musteri}");
			int i = 1;

			stmt.registerOutParameter(i++, -10);

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			boolean kayitYok = true;
			while (rSet.next()) {
				// Oncelik sirasina gore gelen kayitlardan ilkini alir.

				oMap.put("ONCEKI_DURUM_KOD", rSet.getString("ONCEKI_DURUM_KOD"));
				oMap.put("KANAL_ADI", rSet.getString("KANAL_AD"));
				oMap.put("ALT_KANAL_ADI", rSet.getString("ALT_KANAL_AD"));
				oMap.put("M_DURUM", rSet.getString("M_DURUM"));
				oMap.put("MI_DURUM", rSet.getString("MI_DURUM"));
				oMap.put("K1I_DURUM", rSet.getString("K1I_DURUM"));
				oMap.put("K2I_DURUM", rSet.getString("K2I_DURUM"));

				GMMap rMap = new GMMap();
				rMap.put("BASVURU_NO", rSet.getBigDecimal("BASVURU_NO"));
				GMServiceExecuter.call("BNSPR_TRN3174_BASVURU_KILITLE", rMap);

				kayitYok = false;
				oMap.put("BASVURU_NO", rSet.getBigDecimal("BASVURU_NO"));

			}
			if (kayitYok) {
				HashMap<String, Object> myMap = new HashMap<String, Object>();
				myMap.put("HATA_NO", new BigDecimal(442));
				throw new GMRuntimeException(0, (String) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", myMap).get("ERROR_MESSAGE"));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3180_BASVURU_KILIT_KONTROL")
	public static GMMap getBasvuruKilitKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3174.basvuru_kilit_kontrol(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("CEK_KUL_KOD", stmt.getString(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3180_ARAMA_ENGELLE")
	public static GMMap aramaEngelle(GMMap iMap) {
		GMMap oMap = new GMMap();

		String tableName = "BASVURU_LIST";
		List<?> recordList = (List<?>) iMap.get(tableName);

		if (recordList.size() == 0) {
			HashMap<String, Object> myMap = new HashMap<String, Object>();
			myMap.put("HATA_NO", new BigDecimal(442));
			throw new GMRuntimeException(0, (String) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", myMap).get("ERROR_MESSAGE"));
		}

		for (int i = 0; i < recordList.size(); i++) {
			try {
				if (iMap.getBoolean(tableName, i, "SEC")) {
					GMMap rMap = new GMMap();
					rMap.put("BASVURU_NO", iMap.getBigDecimal(tableName, i, "BASVURU_NO"));

					if (GMServiceExecuter.call("BNSPR_TRN3180_BASVURU_KILIT_KONTROL", rMap).getString("CEK_KUL_KOD") == null)
						GMServiceExecuter.call("BNSPR_TRN3174_BASVURU_KILITLE", rMap);
					else
						GMServiceExecuter.call("BNSPR_TRN3174_BASVURU_KILIT_COZ", rMap);
				}
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_SIL")
	public static Map<?, ?> basvuruSil(GMMap iMap) {
		Map<?, ?> oMap = new GMMap();
		org.hibernate.Session session = DAOSession.getSession("BNSPRDal");

		String tableName = "BASVURU_LIST";
		List<?> recordList = (List<?>) iMap.get(tableName);
		boolean secili = false;
		String gorus = iMap.getString("FRAUD_ACIKLAMA");
		String islemSonrasiDurumKodu = ISLEM_SONRASI_DURUM_KODU_IPTAL;
		String aksiyonKodu = iMap.getString("AKSIYON_KODU");
		String aksiyonKararKodu = iMap.getString("AKSIYON_KARAR_KODU");
		if (iMap.getString("ISLEM_TIPI").equals("KANAL_IADE")) {
			islemSonrasiDurumKodu = ISLEM_SONRASI_DURUM_KODU_KANAL_IADE;
			// aksiyonKodu = AKSIYON_KODU_KANAL_IADE;
			// aksiyonKararKodu = AKSIYON_KARAR_KODU_KANAL_IADE;
		}
		BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");

		try {
			BirBasvuruFraudTx birBasvuruFraudTx = null;
			for (int i = 0; i < recordList.size(); i++) {

				if (iMap.getBoolean(tableName, i, "SEC")) {
					GMMap rMap = new GMMap();
					rMap.put("BASVURU_NO", iMap.getBigDecimal(tableName, i, "BASVURU_NO"));
					GMServiceExecuter.call("BNSPR_TRN3174_BASVURU_KILITLE", rMap);

					secili = true;
					BirDogrulamaTx birDogrulamaTx = new BirDogrulamaTx();
					birDogrulamaTx.setTxNo(txNo);
					if (iMap.getBigDecimal(tableName, i, "ID_NO") != null) {
						birDogrulamaTx.setIdNo(iMap.getBigDecimal(tableName, i, "ID_NO"));
					}
					else {
						birDogrulamaTx.setIdNo(getIdNo(iMap.getBigDecimal(tableName, i, "BASVURU_NO")));
					}
					birDogrulamaTx.setBasvuruNo(iMap.getBigDecimal(tableName, i, "BASVURU_NO"));
					birDogrulamaTx.setIslemSonrasiDurumKodu(islemSonrasiDurumKodu);
					birDogrulamaTx.setAksiyonKod(aksiyonKodu);
					birDogrulamaTx.setAksiyonKararKod(aksiyonKararKodu);

					session.saveOrUpdate(birDogrulamaTx);

					updateBirBasvuru(iMap.getBigDecimal(tableName, i, "BASVURU_NO"), islemSonrasiDurumKodu, aksiyonKodu, aksiyonKararKodu);
					/*
					 * PY-3489 kapsaminda iptal icin girilen aciklamanin bir_basvuru_fraud_tx tablosuna gorus olarak eklenmesi*/
					if (!(gorus.isEmpty())) {

						birBasvuruFraudTx = new BirBasvuruFraudTx();
						birBasvuruFraudTx.setBasvuruNo(iMap.getBigDecimal(tableName, i, "BASVURU_NO"));
						birBasvuruFraudTx.setTxNo(txNo);
						birBasvuruFraudTx.setGorus(gorus);
						session.save(birBasvuruFraudTx);

					}

					GMServiceExecuter.call("BNSPR_TRN3174_BASVURU_KILIT_COZ", rMap);
				}
			}
			session.flush();
			if (secili) {
				iMap.put("TRX_NAME", "3180");
				iMap.put("TRX_NO", txNo);
				oMap = GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3180_BASVURU_TARIH_KONTROL")
	public static GMMap basvuruTarihKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3180.Dogrulama_Arama_Tarih_Kontrol(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			GMMap oMap = new GMMap();
			oMap.put("TARIH_GECERLI", stmt.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3180_BASVURU_GETIRSIN_MI")
	public static GMMap validateBasvuruGetir(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (iMap.getBoolean("SEC")) {
				GMServiceExecuter.call("BNSPR_TRN3174_BASVURU_KILITLE", iMap);
			}
			else {
				GMServiceExecuter.call("BNSPR_TRN3174_BASVURU_KILIT_COZ", iMap);
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3180_GET_SELECTED_ROW_COUNT")
	public static GMMap getSelectedRowCount(GMMap iMap) {
		GMMap oMap = new GMMap();

		String tableName = "BASVURU_LIST";
		int selectedRowCount = 0;
		List<?> recordList = (List<?>) iMap.get(tableName);
		for (int i = 0; i < recordList.size(); i++) {
			if (iMap.getBoolean(tableName, i, "SEC")) {
				selectedRowCount++;
			}
		}
		oMap.put("SELECTED_ROW_COUNT", selectedRowCount);
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_DETAY_KIMLIK")
	public static GMMap getDetayKimlik(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_TRN3180.RC_TRN3180_Detay_Kimlik(?,?)}";
			Object inputValues[] = { BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"), BnsprType.STRING, iMap.getString("KONTROL_TIPI") };
			String tableName = "RESULTS";
			GMMap rMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
			int len = rMap.getSize(tableName);
			int ind = 0;
			if (len == 2 && inputValues[3].equals("K2I")) {
				ind = 1; // 2. kefil ise ikinci kayida gec
			}
			if (len > 0) {
				Set<?> keySet = rMap.getMap(tableName, 0).keySet();
				for (Object k : keySet) {
					String key = (String) k;
					Object val = rMap.get(tableName, ind, key);
					oMap.put(key, val);
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3180_GET_SGK_BARKOD")
	public static GMMap getSgkBarkodNo(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			Session session = DAOSession.getSession("BNSPRDal");

			BirSgkHizmetDokum dokum = (BirSgkHizmetDokum) session.createCriteria(BirSgkHizmetDokum.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			oMap.put("BARKOD_NO", dokum.getBarkodNo());

			return oMap;

		}
		catch (Exception e) {
			oMap.put("BARKOD_NO", "Barkod y�klenmemi�tir");
			return oMap;
		}
	}

	@GraymoundService("BNSPR_TRN3180_SET_SGK_VALUES")
	public static GMMap setValuesFromSgk(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			Session session = DAOSession.getSession("BNSPRDal");

			BirSgkHizmetDokum dokum = (BirSgkHizmetDokum) session.createCriteria(BirSgkHizmetDokum.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			if (dokum == null) {
				return oMap;
			}
			String maxDonem = (String) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.ne("belgeTuru", "�ptal")).setProjection(Projections.max("donem")).uniqueResult();
			List<BirSgkHizmetDokumDetay> detayListesi = (List<BirSgkHizmetDokumDetay>) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("donem", maxDonem)).list();

			try {
				BigDecimal toplamGun = BigDecimal.ZERO;
				for (BirSgkHizmetDokumDetay detay : detayListesi) {
					toplamGun = toplamGun.add(detay.getGun());

					if (toplamGun.compareTo(new BigDecimal(30)) > 0) {
						maxDonem = (String) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.ne("belgeTuru", "�ptal")).setProjection(Projections.max("detayNo")).uniqueResult();
						detayListesi = (List<BirSgkHizmetDokumDetay>) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("donem", maxDonem)).list();
						break;
					}
				}
			}
			catch (Exception e) {
				GMMap hataMap = new GMMap();
				hataMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				hataMap.put("HATA_ACK", e.getMessage());
				GMServiceExecuter.call("BNSPR_EXT_ESGM_SGK_MAIL_AT", hataMap);
			}

			SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
			SimpleDateFormat format2 = new SimpleDateFormat("dd.MM.yyyy");

			if ("4b".equalsIgnoreCase(dokum.getSonSigortaKolu())) {
				oMap.put("KAYDI_YOK", true);
			}
			else {
				oMap.put("KAYDI_YOK", false);
				BigDecimal topPrimGunu = BigDecimal.ZERO;
				if ("4a".equalsIgnoreCase(dokum.getSonSigortaKolu())) {
					oMap.put("CALISMA_SEKLI", "O");
					topPrimGunu = dokum.getToplam4aPogs();
				}
				else if ("4c".equalsIgnoreCase(dokum.getSonSigortaKolu())) {
					List<BirSgkHizmetDokumisyeri> isyeriList = (List<BirSgkHizmetDokumisyeri>) session.createCriteria(BirSgkHizmetDokumisyeri.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).addOrder(Order.desc("id.siraNo")).list();

					if (!isyeriList.isEmpty() && isyeriList.get(0).getMahiyet().startsWith("Kamu")) {
						oMap.put("CALISMA_SEKLI", "K");
					}

					topPrimGunu = dokum.getToplam4cPogs();
				}

				if (topPrimGunu.compareTo(BigDecimal.ZERO) <= 0) {
					BigDecimal dokumToplami = (BigDecimal) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).setProjection(Projections.sum("gun")).uniqueResult();

					if (dokumToplami.compareTo(new BigDecimal(361)) > 0) {
						oMap.put("PRIM_GUNU", new BigDecimal(361));
					}
					else {
						oMap.put("PRIM_GUNU", dokumToplami);
					}
				}
				else {
					oMap.put("PRIM_GUNU", topPrimGunu);
				}

				try {
					if (detayListesi.get(0).getCikisTarihi() != null && detayListesi.get(0).getCikisTarihi().length() > 0) {
						oMap.put("PRIM_SON_ODEME_TARIHI", format2.parse(detayListesi.get(0).getCikisTarihi()));
					}
					else {
						oMap.put("PRIM_SON_ODEME_TARIHI", format.parse(detayListesi.get(0).getDonem() + "/" + detayListesi.get(0).getGun()));
					}

				}
				catch (ParseException e) {
					oMap.put("HATA_ACK1", "Prim son �deme tarihi hesaplanamad�:" + e.getMessage());
				}

				try {
					oMap.put("SON_EKSIK_GUN_NEDENI", detayListesi.get(0).getEksikGunNedeni());
				}
				catch (Exception e) {
					oMap.put("HATA_ACK5", "Eksik g�n nedeni:" + e.getMessage());
				}

				try {
					oMap.put("SON_DONEM_GUN", detayListesi.get(0).getGun());
				}
				catch (Exception e) {
					oMap.put("HATA_ACK6", "Son d�nem g�n:" + e.getMessage());
				}

				maxDonem = (String) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.isNotNull("girisTarihi")).setProjection(Projections.max("donem")).uniqueResult();
				List<BirSgkHizmetDokumDetay> iseGirisDetay = (List<BirSgkHizmetDokumDetay>) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.isNotNull("girisTarihi")).add(Restrictions.ne("belgeTuru", "�ptal")).add(Restrictions.eq("donem", maxDonem)).list();

				try {
					if (iseGirisDetay.size() == 0) {
						String minDonem = (String) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.ne("belgeTuru", "�ptal")).add(Restrictions.eq("sigortaKolu", dokum.getSonSigortaKolu())).setProjection(Projections.min("donem")).uniqueResult();
						iseGirisDetay = (List<BirSgkHizmetDokumDetay>) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("donem", minDonem)).list();

						java.util.Date donemTar = format.parse(iseGirisDetay.get(0).getDonem() + "/01");
						java.util.Date sonIsyeriDonemTar = format.parse(iMap.getString("SON_ISYERI_DONEM") + "/01");

						if (donemTar.before(sonIsyeriDonemTar)) {
							oMap.put("GIRIS_TARIHI", sonIsyeriDonemTar);
						}
						else {
							oMap.put("GIRIS_TARIHI", donemTar);
						}

					}
					else {
						java.util.Date girisTar = format2.parse(iseGirisDetay.get(0).getGirisTarihi());
						oMap.put("GIRIS_TARIHI", girisTar);
					}
				}
				catch (ParseException e) {

					try {
						maxDonem = (String) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("sigortaKolu", dokum.getSonSigortaKolu())).setProjection(Projections.min("donem")).uniqueResult();
						oMap.put("GIRIS_TARIHI", format.parse(maxDonem + "/01"));
					}
					catch (Exception ex2) {
						oMap.put("HATA_ACK2", "��e giri� tarihi hesaplanamad�:" + e.getMessage());
					}

				}

				try {
					oMap.put("ILK_GIRIS_TARIHI", format2.parse(dokum.getIseBaslamaTarihi()));
				}
				catch (Exception e) {
					try {
						maxDonem = (String) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.isNotNull("girisTarihi")).setProjection(Projections.min("donem")).uniqueResult();
						List<BirSgkHizmetDokumDetay> ilkIseGirisDetay = (List<BirSgkHizmetDokumDetay>) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.isNotNull("girisTarihi")).add(Restrictions.eq("donem", maxDonem)).list();
						oMap.put("ILK_GIRIS_TARIHI", format2.parse(ilkIseGirisDetay.get(0).getGirisTarihi()));
					}
					catch (Exception ex) {

						try {
							maxDonem = (String) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("sigortaKolu", dokum.getSonSigortaKolu())).setProjection(Projections.min("donem")).uniqueResult();
							oMap.put("ILK_GIRIS_TARIHI", format.parse(maxDonem + "/01"));
						}
						catch (Exception ex2) {
							oMap.put("HATA_ACK3", "�lk i�e giri� tarihi hesaplanamad�:" + ex2.getMessage());
						}
					}
				}

				maxDonem = (String) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).setProjection(Projections.max("donem")).uniqueResult();
				List<BirSgkHizmetDokumDetay> cikisDetayListe = (List<BirSgkHizmetDokumDetay>) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("donem", maxDonem)).list();

				try {

					for (BirSgkHizmetDokumDetay detay : cikisDetayListe) {
						if (detay.getCikisTarihi() != null) {
							oMap.put("CIKIS_TARIHI", format2.parse(detay.getCikisTarihi()));
						}
					}

				}
				catch (ParseException e) {
					oMap.put("HATA_ACK4", "��k�� tarihi hesaplanamad�:" + e.getMessage());
				}

				BigDecimal topPrimTutar = BigDecimal.ZERO;
				for (BirSgkHizmetDokumDetay detay : detayListesi) {
					if ("�ptal".equalsIgnoreCase(detay.getBelgeTuru())) {
						topPrimTutar = topPrimTutar.subtract(detay.getPrimTutari());
					}
					else {
						topPrimTutar = topPrimTutar.add(detay.getPrimTutari());
					}
				}

				oMap.put("PRIM_TUTARI", topPrimTutar);
				List<String> donemler = sonNAyDonemleri(12);
				try {

					int aktifDonemSayisi = (Integer) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.in("donem", donemler)).add(Restrictions.ne("belgeTuru", "�ptal")).setProjection(Projections.countDistinct("donem")).uniqueResult();
					oMap.put("DONEM_SAYISI", aktifDonemSayisi);
				}
				catch (Exception e) {
					oMap.put("DONEM_SAYISI", 0);
				}

				try {
					BigDecimal gunSayisi = (BigDecimal) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.in("donem", donemler)).add(Restrictions.ne("belgeTuru", "�ptal")).setProjection(Projections.sum("gun")).uniqueResult();
					BigDecimal iptalGunSayisi = (BigDecimal) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.in("donem", donemler)).add(Restrictions.eq("belgeTuru", "�ptal")).setProjection(Projections.sum("gun")).uniqueResult();

					oMap.put("GUN1", gunSayisi.subtract(iptalGunSayisi != null ? iptalGunSayisi : BigDecimal.ZERO));
				}
				catch (Exception e) {
					oMap.put("GUN1", BigDecimal.ZERO);
				}
				donemler = sonNAyDonemleri(24);
				try {
					BigDecimal gunSayisi = (BigDecimal) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.in("donem", donemler)).add(Restrictions.ne("belgeTuru", "�ptal")).setProjection(Projections.sum("gun")).uniqueResult();
					BigDecimal iptalGunSayisi = (BigDecimal) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.in("donem", donemler)).add(Restrictions.eq("belgeTuru", "�ptal")).setProjection(Projections.sum("gun")).uniqueResult();
					oMap.put("GUN2", gunSayisi.subtract(iptalGunSayisi != null ? iptalGunSayisi : BigDecimal.ZERO));
				}
				catch (Exception e) {
					oMap.put("GUN2", BigDecimal.ZERO);
				}

				try {
					int isyeriAdet = (Integer) session.createCriteria(BirSgkHizmetDokumDetay.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.in("donem", donemler)).add(Restrictions.ne("belgeTuru", "�ptal")).setProjection(Projections.countDistinct("isyeriNo")).uniqueResult();
					oMap.put("ISYERI_ADET", isyeriAdet);
				}
				catch (Exception e) {
					oMap.put("ISYERI_ADET", 0);
				}
			}

		}
		catch (Exception e) {
			oMap.put("ANA_HATA", e.getMessage());
		}

		return oMap;
	}

	private static List<String> sonNAyDonemleri(int n) {
		int yil = Calendar.getInstance().get(Calendar.YEAR);
		int ay = Calendar.getInstance().get(Calendar.MONTH);
		int size = 0;
		List<String> donemler = new ArrayList<String>();

		while (size < n) {
			if (ay > 9) {
				donemler.add(yil + "/" + ay);
				ay--;
			}
			else if (ay > 0) {
				donemler.add(yil + "/0" + ay);
				ay--;
			}
			else {
				ay = 12;
				yil--;
				size--;
			}
			size++;
		}

		return donemler;
	}

	@GraymoundService("BNSPR_TRN3180_GET_DETAY_ISYERI")
	public static GMMap getDetayIsyeri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3180.RC_TRN3180_Detay_Isyeri(?,?)}");
			int i = 1;

			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("KONTROL_TIPI"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			boolean flag = true;
			while (rSet.next()) {
				if ("K2I".equals(iMap.getString("KONTROL_TIPI")) && flag) {
					// 2. kefil ise ikinci kayida gec
					flag = false;
					continue;
				}
				oMap.put("UNVAN", rSet.getString("UNVAN"));
				oMap.put("UNVAN_KOD", rSet.getString("UNVAN_KOD"));
				oMap.put("GELIR", rSet.getString("GELIR"));
				oMap.put("CALISMA_SEKLI", rSet.getString("CALISMA_SEKLI"));
				oMap.put("CALISMA_YIL", rSet.getString("CALISMA_YIL"));
				oMap.put("CALISMA_AY", rSet.getString("CALISMA_AY"));
				oMap.put("ISYERI_ADI", rSet.getString("ISYERI_ADI"));
				oMap.put("MESLEK", rSet.getString("MESLEK"));
				oMap.put("IS_ADRES", rSet.getString("IS_ADRES"));
				oMap.put("IS_TELEFON", rSet.getString("IS_TELEFON"));
				oMap.put("DAHILI", rSet.getString("DAHILI"));
				oMap.put("DOGUM_TARIHI", rSet.getDate("DOGUM_TARIHI"));
				oMap.put("EGITIM_DURUM_KOD", rSet.getString("EGITIM_DURUM_KOD"));
				break;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3180_GET_SON_DOGRULAMA")
	public static GMMap getSonDogrulama(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN3180.Son_Durum(?,?,?,?,?,?,?,?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, iMap.getString("KONTROL_TIPI"));
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.TIMESTAMP);
			stmt.registerOutParameter(5, Types.VARCHAR);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.registerOutParameter(7, Types.VARCHAR);
			stmt.registerOutParameter(8, Types.VARCHAR);
			stmt.registerOutParameter(9, Types.VARCHAR);
			stmt.registerOutParameter(10, Types.VARCHAR);
			stmt.setBigDecimal(11, iMap.getBigDecimal("KEFIL_NO"));

			stmt.execute();
			oMap.put("SON_DOG_SONUC_KOD", stmt.getString(3));
			if (stmt.getTimestamp(4) != null) {
				String[] tarihSaat = splitDateAndTime(stmt.getTimestamp(4));

				oMap.put("SON_DOG_TARIH", tarihSaat[0]);
				oMap.put("SON_DOG_TARIH_SAAT", tarihSaat[1]);
			}
			oMap.put("SON_DOG_SONUC_ACIKLAMA", stmt.getString(5));
			oMap.put("SON_DOG_SEBEP_KOD", stmt.getString(6));
			oMap.put("SON_DOG_SEBEP_ACIKLAMA", stmt.getString(7));
			String randevu_mu = stmt.getString(8);

			oMap.put("SON_DOG_RANDEVU_MU", randevu_mu);
			if (randevu_mu != null)
				oMap.put("SON_DOG_RANDEVU_MU_ACIKLAMA", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", new GMMap().put("KEY", randevu_mu).put("KOD", "EVET_HAYIR")).getString("TEXT"));

			oMap.put("SON_GORUSULEN_KISI", stmt.getString(9));
			oMap.put("SON_GORUSULEN_UNVAN", stmt.getString(10));

			GMServerDatasource.close(stmt);

			stmt = conn.prepareCall("{? = call PKG_TRN3180.RC_TRN3180_Guncelleme(?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, iMap.getString("KONTROL_TIPI"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetMap(rSet));

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet);

			stmt = conn.prepareCall("{? = call PKG_TRN3180.RC_TRN3180_GUNCELLEME_KAYIT(?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, iMap.getString("KONTROL_TIPI"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			GMMap tMap = DALUtil.rSetMap(rSet);
			oMap.putAll(tMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3180_GET_BRM_BILGILERI")
	public static GMMap getBRMBilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN3180.RC_TRN3180_BRM_Dogrulama(?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			String comboListName = "AKSIYON_COMBO";
			oMap.put(comboListName, (String) null);

			if (rSet.next()) {
				try {
					oMap.put("MF_AKS_KOD", rSet.getString("MF_AKS_KOD"));
					GuimlUtil.wrapMyCombo(oMap, comboListName, rSet.getString("MF_AKS_KOD"), rSet.getString("MUS_FRAUD_DOG_ACIKLAMA"));
				}
				catch (Exception e) {
				}

				try {
					oMap.put("M_ADET", rSet.getBigDecimal("MUS_DOG_ADET"));
					oMap.put("M_AKS_KOD", rSet.getString("M_AKS_KOD"));
					GuimlUtil.wrapMyCombo(oMap, comboListName, rSet.getString("M_AKS_KOD"), rSet.getString("MUS_DOG_ACIKLAMA"));
				}
				catch (Exception e) {
				}

				try {
					oMap.put("MI_ADET", rSet.getBigDecimal("MUS_ISYERI_ADET"));
					oMap.put("MI_AKS_KOD", rSet.getString("MI_AKS_KOD"));
					GuimlUtil.wrapMyCombo(oMap, comboListName, rSet.getString("MI_AKS_KOD"), rSet.getString("MUS_ISYERI_ACIKLAMA"));
				}
				catch (Exception e) {
				}

				try {
					oMap.put("K1_VISIBLE", !rSet.getString("K1I_AKS_KOD").equals("Not Required"));
					oMap.put("K1_ADET", rSet.getBigDecimal("K1_ISYERI_ADET"));
					oMap.put("K1_AKS_KOD", rSet.getString("K1I_AKS_KOD"));
					GuimlUtil.wrapMyCombo(oMap, comboListName, rSet.getString("K1I_AKS_KOD"), rSet.getString("K1_ISYERI_ACIKLAMA"));
				}
				catch (Exception e) {
				}

				try {
					oMap.put("K2_VISIBLE", !rSet.getString("K2I_AKS_KOD").equals("Not Required"));
					oMap.put("K2_ADET", rSet.getBigDecimal("K2_ISYERI_ADET"));
					oMap.put("K2_AKS_KOD", rSet.getString("K2I_AKS_KOD"));
					GuimlUtil.wrapMyCombo(oMap, comboListName, rSet.getString("K2I_AKS_KOD"), rSet.getString("K2_ISYERI_ACIKLAMA"));
				}
				catch (Exception e) {
				}

				try {
					oMap.put("WEB_ACIKLAMA", "(" + rSet.getString("WEB_ACIKLAMA") + ")");
					oMap.put("MW_AKS_KOD", rSet.getString("MW_AKS_KOD"));
					GuimlUtil.wrapMyCombo(oMap, comboListName, rSet.getString("MW_AKS_KOD"), rSet.getString("MUS_WEB_DOG_ACIKLAMA"));
				}
				catch (Exception e) {
				}

				try {
					oMap.put("K1F_VISIBLE", !rSet.getString("K1F_AKS_KOD").equals("N"));
					oMap.put("K1F_AKS_KOD", rSet.getString("K1F_AKS_KOD"));
					GuimlUtil.wrapMyCombo(oMap, comboListName, rSet.getString("K1F_AKS_KOD"), rSet.getString("K1F_ISYERI_ACIKLAMA"));
				}
				catch (Exception e) {
				}

				try {
					oMap.put("K2F_VISIBLE", !rSet.getString("K2F_AKS_KOD").equals("N"));
					oMap.put("K2F_AKS_KOD", rSet.getString("K2F_AKS_KOD"));
					GuimlUtil.wrapMyCombo(oMap, comboListName, rSet.getString("K2F_AKS_KOD"), rSet.getString("K2F_ISYERI_ACIKLAMA"));
				}
				catch (Exception e) {
				}
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_TARIHCE")
	public static GMMap getBasvuruTarihce(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3180.RC_TRN3180_Tarihce(?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3183_INFO")
	public static GMMap infoTRN3183(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap oMap = new GMMap();
		String cepTel = "";
		String yeniCepTel = "";

		BirBasvuruKimlikTx birBasvuruKimlikTx = (BirBasvuruKimlikTx) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

		BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", birBasvuruKimlikTx.getBasvuruNo())).uniqueResult();

		oMap.put("ANNE_KIZLIK_SOYADI", birBasvuruKimlik.getAnneKizlik());
		oMap.put("YENI_ANNE_KIZLIK_SOYADI", birBasvuruKimlikTx.getAnneKizlik());
		cepTel = birBasvuruKimlik.getCepTelAlanKodu() + birBasvuruKimlik.getCepTelNo();
		yeniCepTel = birBasvuruKimlikTx.getCepTelAlanKodu() + birBasvuruKimlikTx.getCepTelNo();
		oMap.put("CEP_TEL", cepTel);
		oMap.put("YENI_CEP_TEL", yeniCepTel);
		oMap.put("BASVURU_NO", birBasvuruKimlikTx.getBasvuruNo());

		return oMap;

	}

	@GraymoundService("BNSPR_TRN3183_SAVE")
	public static GMMap saveTRN3183(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");

		BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

		BirBasvuruKimlikTx birBasvuruKimlikTx = (BirBasvuruKimlikTx) session.createCriteria(BirBasvuruKimlikTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
		if (birBasvuruKimlikTx == null) {
			birBasvuruKimlikTx = new BirBasvuruKimlikTx();
			birBasvuruKimlikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		}
		String cepTel = iMap.getString("YENI_CEP_TEL");
		String cepTelAlan = "";
		String cepTelNo = "";
		if (StringUtils.isNotBlank(cepTel)) {
			cepTelNo = cepTel.substring(3, 10);
			cepTelAlan = cepTel.substring(0, 3);
		}
		birBasvuruKimlikTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
		birBasvuruKimlikTx.setAnneKizlik(iMap.getString("YENI_ANNE_KIZLIK_SOYADI"));
		birBasvuruKimlikTx.setCepTelNo(cepTelNo);
		birBasvuruKimlikTx.setCepTelAlanKodu(cepTelAlan);
		birBasvuruKimlikTx.setTcKimlikNo(birBasvuru.getTcKimlikNo());
		session.saveOrUpdate(birBasvuruKimlikTx);
		session.flush();

		iMap.put("TRX_NAME", "3183");
		return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3180_SAVE")
	public static GMMap saveTRN3180(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		CallableStatement stmt2 = null;
		String nbsm_ilerlet = null;

		try {
			save: {
				Object dogrulamaInstance = DogrulamaTipKodu.getInstance();

				DogrulamaTipKodu.putAll(ADCSession.get("3180_DYN_INS_" + iMap.getString("TRX_NO")), dogrulamaInstance);

				Session session = DAOSession.getSession("BNSPRDal");

				// 3189 Fraud kaydi:
				{
					if (!"6".equals(iMap.get("FRAUD_KARAR"))) {
						GMMap tMap = new GMMap();

						tMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
						tMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));

						tMap.put("FRAUD_KARAR", iMap.get("FRAUD_KARAR"));
						tMap.put("FRAUD_KAYNAK_KOD", iMap.get("FRAUD_KAYNAK_KOD"));
						tMap.put("FRAUD_GEREKCE", iMap.get("FRAUD_GEREKCE"));
						tMap.put("GORUS", iMap.get("GORUS"));
						tMap.put("DT_GORUS", iMap.get("DT_GORUS"));
						tMap.put("KARA_LISTEYE_EKLENSIN", iMap.get("KARA_LISTEYE_EKLENSIN"));
						tMap.put("KARA_LISTE_DURUM_KOD", iMap.get("KARA_LISTE_DURUM_KOD"));
						tMap.put("KARA_LISTE_TARAF_KOD", iMap.get("KARA_LISTE_TARAF_KOD"));
						tMap.put("KARA_LISTE_KAYNAK_KOD", iMap.get("KARA_LISTE_KAYNAK_KOD"));
						tMap.put("KARA_LISTE_KAYIT_SEBEP_KOD", iMap.get("KARA_LISTE_KAYIT_SEBEP_KOD"));
						tMap.put("SON_TX_NO", iMap.get("SON_TX_NO"));
						tMap.put("OZET_TABLE", iMap.get("OZET_TABLE"));

						tMap.put("DONT_SEND_TRANSACTION", true);

						GMServiceExecuter.execute("BNSPR_TRN3189_SAVE", tMap);
					}
				}

				// 3174 Belge kaydi:
				{
					List<BirBasvuruBelgeTx> birBasvuruBelgeTxList = session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

					for (BirBasvuruBelgeTx belgeTx : birBasvuruBelgeTxList) {
						session.delete(belgeTx);
					}
					session.flush();

					List<?> belgeList = (List<?>) iMap.get("BELGE");
					String tableName = "BELGE";
					for (int i = 0; i < belgeList.size(); i++) {
						if (iMap.getBoolean(tableName, i, "EKLENDI"))
							continue;

						BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.kimden", iMap.getString(tableName, i, "KIMDEN_KOD"))).add(Restrictions.eq("id.dokumanKod", iMap.getString(tableName, i, "BELGE_KOD"))).uniqueResult();

						if (birBasvuruBelgeTx == null) {
							birBasvuruBelgeTx = new BirBasvuruBelgeTx();
							BirBasvuruBelgeTxId birBasvuruBelgeTxId = new BirBasvuruBelgeTxId();

							birBasvuruBelgeTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
							birBasvuruBelgeTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
							birBasvuruBelgeTxId.setDokumanKod(iMap.getString(tableName, i, "BELGE_KOD"));
							birBasvuruBelgeTxId.setKimden(iMap.getString(tableName, i, "KIMDEN_KOD"));

							birBasvuruBelgeTx.setId(birBasvuruBelgeTxId);
							String belgeAlinmaAdim = iMap.getString(tableName, i, "BELGE_ALINMA_ADIMI") != null && !iMap.getString(tableName, i, "BELGE_ALINMA_ADIMI").trim().isEmpty() ? iMap.getString(tableName, i, "BELGE_ALINMA_ADIMI") : "S";
							birBasvuruBelgeTx.setBelgeAlinmaAdim(belgeAlinmaAdim);
						}
						session.save(birBasvuruBelgeTx);
					}
					session.flush();
				}

				boolean dogrulamaYapildiMi = false;
				BigDecimal maxAramaSayisi = GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", new GMMap().put("PARAMETRE", "MAX_ARAMA_SAYISI")).getBigDecimal("DEGER");
				BigDecimal idNo = getIdNo(iMap.getBigDecimal("BASVURU_NO"));

				BirDogrulamaTx birDogrulamaTx = (BirDogrulamaTx) session.createCriteria(BirDogrulamaTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
				if (birDogrulamaTx == null) {
					birDogrulamaTx = new BirDogrulamaTx();
					birDogrulamaTx.setIdNo(idNo);
					birDogrulamaTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				}
				birDogrulamaTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				birDogrulamaTx.setOncekiDurumKodu(iMap.getString("ONCEKI_DURUM_KOD"));
				birDogrulamaTx.setYeniAnneKizlikSoyadi(iMap.getString("ANNE_KIZLIK_SOYADI"));

				if (DOG_KOD_TEKRAR_ARANACAK.equals(iMap.getString("MUS_DOGRULAMA_KOD")) || DOG_KOD_TEKRAR_ARANACAK.equals(iMap.getString("MF_DOGRULAMA_KOD"))) {
					if (iMap.getDate("MUS_RANDEVU_TARIHI") != null) {
						birDogrulamaTx.setMusDogSaat(concatDateAndTime(iMap.getString("MUS_RANDEVU_TARIHI"), iMap.getString("MUS_RANDEVU_SAATI")));
						birDogrulamaTx.setMusDogSaatTip("E");
					}
					else {
						birDogrulamaTx.setMusDogSaat((Timestamp) DALUtil.callNoParameterFunction("{? = call PKG_TRN3180.randevu_tarih_saati()}", Types.TIMESTAMP));
						birDogrulamaTx.setMusDogSaatTip("H");
					}
				}

				/*
				 * --------------------------------------------- Musteri Dogrulama ---------------------------------------
				 * */
				if (iMap.getString("MUS_DOGRULAMA_KOD") != null && iMap.getString("M_AKSIYON") != null && !(iMap.getString("M_AKSIYON").equals("N") || iMap.getString("M_AKSIYON").equals("Not Required"))) {
					birDogrulamaTx.setMusDogKod(iMap.getString("MUS_DOGRULAMA_KOD"));

					// Bir Dogrulama Detay
					BirDogrulamaDetayTxId id = new BirDogrulamaDetayTxId();
					id.setDogrulamaTipKod(DogrulamaTipKodu.M.name());
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));

					BirDogrulamaDetayTx birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.get(BirDogrulamaDetayTx.class, id);

					if (birDogrulamaDetayTx == null) {
						birDogrulamaDetayTx = new BirDogrulamaDetayTx(id, idNo);
					}
					birDogrulamaDetayTx.setAciklama(iMap.getString("MUS_ACIKLAMA"));
					// Arama Adedi, bir arttirilarak gonderilir.
					birDogrulamaDetayTx.setAramaAdedi(iMap.getBigDecimal("MUS_ARAMA_ADEDI").add(new BigDecimal(1)));
					birDogrulamaDetayTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birDogrulamaDetayTx.setDigerTelefon(iMap.getString("MUS_DIGER_TELEFON"));
					birDogrulamaDetayTx.setDogrulamaKod(iMap.getString("MUS_DOGRULAMA_KOD"));
					birDogrulamaDetayTx.setDogrulamaSebepKod(iMap.getString("MF_DOGRULAMA_SEBEP_KOD"));
					birDogrulamaDetayTx.setGorusulenTelefon(iMap.getString("MUS_GORUSULEN_TELEFON"));
					birDogrulamaDetayTx.setDigerTelefonKaynak(iMap.getString("DIGER_TELEFON_KAYNAK"));

					// Tekrar aranacak ise ve max arama sayisina ulasildiysa Ulasilmadi(2)/Max Arama Sayisi Asildi(24) olarak gonder
					if (DOG_KOD_TEKRAR_ARANACAK.equals(iMap.getString("MUS_DOGRULAMA_KOD")) && maxAramaSayisi.equals(birDogrulamaDetayTx.getAramaAdedi())) {
						birDogrulamaDetayTx.setDogrulamaKod(DOG_KOD_ULASILMADI);
						birDogrulamaDetayTx.setDogrulamaSebepKod(DOG_SEBEP_KOD_ARAMA_SAYISI_ASILDI);
						birDogrulamaTx.setMusDogKod(DOG_KOD_ULASILMADI);
					}

					session.saveOrUpdate(birDogrulamaDetayTx);
					session.flush();

					dogrulamaYapildiMi = true;
				}
				else if (birDogrulamaTx.getMusDogSaatTip() == null) { // bos ise son dogrulamadaki degerleri gonder, onceki dogrulamalari ezmesin
																		// diye.
					GMMap xMap = new GMMap();
					GMMap yMap = new GMMap();
					xMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
					xMap.put("KONTROL_TIPI", DogrulamaTipKodu.M.name());

					yMap = GMServiceExecuter.call("BNSPR_TRN3180_GET_SON_DOGRULAMA", xMap);

					birDogrulamaTx.setMusDogSaatTip(yMap.getString("SON_DOG_RANDEVU_MU"));
					birDogrulamaTx.setMusDogKod(yMap.getString("SON_DOG_SONUC_KOD"));
					if (yMap.getBigDecimal("SON_DOG_TARIH") != null)
						birDogrulamaTx.setMusDogSaat(concatDateAndTime(yMap.getString("SON_DOG_TARIH"), yMap.getString("SON_DOG_TARIH_SAAT")));
				}

				if (iMap.getString("MF_DOGRULAMA_KOD") != null && iMap.getString("MF_AKSIYON") != null && !(iMap.getString("MF_AKSIYON").equals("N") || iMap.getString("MF_AKSIYON").equals("Not Required"))) {
					birDogrulamaTx.setMusFraudDogKod(iMap.getString("MF_DOGRULAMA_KOD"));

					BirDogrulamaDetayTxId id = new BirDogrulamaDetayTxId();
					id.setDogrulamaTipKod(DogrulamaTipKodu.MF.name());
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));

					BirDogrulamaDetayTx birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.get(BirDogrulamaDetayTx.class, id);

					if (birDogrulamaDetayTx == null) {
						birDogrulamaDetayTx = new BirDogrulamaDetayTx(id, idNo);
					}
					birDogrulamaDetayTx.setDogrulamaKod(iMap.getString("MF_DOGRULAMA_KOD"));
					birDogrulamaDetayTx.setDogrulamaSebepKod(iMap.getString("MF_DOGRULAMA_SEBEP_KOD"));

					birDogrulamaDetayTx.setAciklama(iMap.getString("MUS_ACIKLAMA"));
					birDogrulamaDetayTx.setAramaAdedi(iMap.getBigDecimal("MUS_ARAMA_ADEDI").add(new BigDecimal(1)));
					birDogrulamaDetayTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birDogrulamaDetayTx.setDigerTelefon(iMap.getString("MUS_DIGER_TELEFON"));
					birDogrulamaDetayTx.setGorusulenTelefon(iMap.getString("MUS_GORUSULEN_TELEFON"));
					birDogrulamaDetayTx.setDigerTelefonKaynak(iMap.getString("DIGER_TELEFON_KAYNAK"));

					// Tekrar aranacak ise ve max arama sayisina ulasildiysa Ulasilmadi(2)/Max Arama Sayisi Asildi(24) olarak gonder
					if (DOG_KOD_TEKRAR_ARANACAK.equals(iMap.getString("MF_DOGRULAMA_KOD")) && maxAramaSayisi.equals(birDogrulamaDetayTx.getAramaAdedi())) {
						birDogrulamaDetayTx.setDogrulamaKod(DOG_KOD_ULASILMADI);
						birDogrulamaDetayTx.setDogrulamaSebepKod(DOG_SEBEP_KOD_ARAMA_SAYISI_ASILDI);
						birDogrulamaTx.setMusDogKod(DOG_KOD_ULASILMADI);
					}

					session.saveOrUpdate(birDogrulamaDetayTx);
					session.flush();

					dogrulamaYapildiMi = true;
				}
				/*
								if (iMap.getString("MW_DOGRULAMA_KOD") != null) {
									birDogrulamaTx.setMusWebDogKod(iMap.getString("MW_DOGRULAMA_KOD"));

									BirDogrulamaDetayTxId id = new BirDogrulamaDetayTxId();
									id.setDogrulamaTipKod(DogrulamaTipKodu.MW.name());
									id.setTxNo(iMap.getBigDecimal("TRX_NO"));

									BirDogrulamaDetayTx birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.get(BirDogrulamaDetayTx.class, id);

									if (birDogrulamaDetayTx == null) {
										birDogrulamaDetayTx = new BirDogrulamaDetayTx(id, idNo);
									}
									birDogrulamaDetayTx.setDogrulamaKod(iMap.getString("MW_DOGRULAMA_KOD"));
									birDogrulamaDetayTx.setDogrulamaSebepKod(iMap.getString("MW_DOGRULAMA_SEBEP_KOD"));
									birDogrulamaDetayTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));

									session.saveOrUpdate(birDogrulamaDetayTx);
									session.flush();

									dogrulamaYapildiMi = true;
								}*/

				if (iMap.getString("K1F_DOGRULAMA_KOD") != null && iMap.getString("K1F_AKSIYON_KOD").equals("Y")) {
					birDogrulamaTx.setK1fDogKod(iMap.getString("K1F_DOGRULAMA_KOD"));

					BirDogrulamaDetayTxId id = new BirDogrulamaDetayTxId();
					id.setDogrulamaTipKod(DogrulamaTipKodu.K1F.name());
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));

					BirDogrulamaDetayTx birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.get(BirDogrulamaDetayTx.class, id);

					if (birDogrulamaDetayTx == null) {
						birDogrulamaDetayTx = new BirDogrulamaDetayTx(id, idNo);
					}
					birDogrulamaDetayTx.setDogrulamaKod(iMap.getString("K1F_DOGRULAMA_KOD"));
					birDogrulamaDetayTx.setDogrulamaSebepKod(iMap.getString("K1F_DOGRULAMA_SEBEP_KOD"));
					birDogrulamaDetayTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birDogrulamaDetayTx.setAciklama(iMap.getString("MUS_ACIKLAMA"));
					birDogrulamaDetayTx.setAramaAdedi(iMap.getBigDecimal("MUS_ARAMA_ADEDI").add(new BigDecimal(1)));
					birDogrulamaDetayTx.setDigerTelefon(iMap.getString("MUS_DIGER_TELEFON"));
					birDogrulamaDetayTx.setGorusulenTelefon(iMap.getString("MUS_GORUSULEN_TELEFON"));
					birDogrulamaDetayTx.setDigerTelefonKaynak(iMap.getString("DIGER_TELEFON_KAYNAK"));

					session.saveOrUpdate(birDogrulamaDetayTx);
					session.flush();

					dogrulamaYapildiMi = true;
				}

				if (iMap.getString("K2F_DOGRULAMA_KOD") != null && iMap.getString("K2F_AKSIYON_KOD").equals("Y")) {
					birDogrulamaTx.setK2fDogKod(iMap.getString("K2F_DOGRULAMA_KOD"));

					BirDogrulamaDetayTxId id = new BirDogrulamaDetayTxId();
					id.setDogrulamaTipKod(DogrulamaTipKodu.K1F.name());
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));

					BirDogrulamaDetayTx birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.get(BirDogrulamaDetayTx.class, id);

					if (birDogrulamaDetayTx == null) {
						birDogrulamaDetayTx = new BirDogrulamaDetayTx(id, idNo);
					}
					birDogrulamaDetayTx.setDogrulamaKod(iMap.getString("K2F_DOGRULAMA_KOD"));
					birDogrulamaDetayTx.setDogrulamaSebepKod(iMap.getString("K2F_DOGRULAMA_SEBEP_KOD"));
					birDogrulamaDetayTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birDogrulamaDetayTx.setAciklama(iMap.getString("MUS_ACIKLAMA"));
					birDogrulamaDetayTx.setAramaAdedi(iMap.getBigDecimal("MUS_ARAMA_ADEDI").add(new BigDecimal(1)));
					birDogrulamaDetayTx.setDigerTelefon(iMap.getString("MUS_DIGER_TELEFON"));
					birDogrulamaDetayTx.setGorusulenTelefon(iMap.getString("MUS_GORUSULEN_TELEFON"));
					birDogrulamaDetayTx.setDigerTelefonKaynak(iMap.getString("DIGER_TELEFON_KAYNAK"));

					session.saveOrUpdate(birDogrulamaDetayTx);
					session.flush();

					dogrulamaYapildiMi = true;
				}

				/*
				 * --------------------------------------- Musteri Isyeri Dogrulama -----------------------------------
				 */
				if (iMap.getString("MUS_ISYERI_DOGRULAMA_KOD") != null) {
					birDogrulamaTx.setMusIsyeriDogKod(iMap.getString("MUS_ISYERI_DOGRULAMA_KOD"));

					if (DOG_KOD_TEKRAR_ARANACAK.equals(iMap.getString("MUS_ISYERI_DOGRULAMA_KOD"))) {
						if (iMap.getString("MUS_ISYERI_RANDEVU_TARIHI") != null) {
							birDogrulamaTx.setMusIsyeriDogSaat(concatDateAndTime(iMap.getString("MUS_ISYERI_RANDEVU_TARIHI"), iMap.getString("MUS_ISYERI_RANDEVU_SAATI")));
							birDogrulamaTx.setMusDogIsyeriSaatTip("E");
						}
						else {
							birDogrulamaTx.setMusIsyeriDogSaat((Timestamp) DALUtil.callNoParameterFunction("{? = call PKG_TRN3180.randevu_tarih_saati()}", Types.TIMESTAMP));
							birDogrulamaTx.setMusDogIsyeriSaatTip("H");
						}
					}
					BirDogrulamaDetayTxId id = new BirDogrulamaDetayTxId();
					id.setDogrulamaTipKod(DogrulamaTipKodu.MI.name());
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));

					BirDogrulamaDetayTx birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.get(BirDogrulamaDetayTx.class, id);

					if (birDogrulamaDetayTx == null) {
						birDogrulamaDetayTx = new BirDogrulamaDetayTx(id, idNo);
					}
					birDogrulamaDetayTx.setAciklama(iMap.getString("MUS_ISYERI_ACIKLAMA"));
					// Arama Adedi, bir arttirilarak gonderilir.
					birDogrulamaDetayTx.setAramaAdedi(iMap.getBigDecimal("MUS_ISYERI_ARAMA_ADEDI").add(new BigDecimal(1)));
					birDogrulamaDetayTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birDogrulamaDetayTx.setDogrulamaKod(iMap.getString("MUS_ISYERI_DOGRULAMA_KOD"));
					birDogrulamaDetayTx.setDogrulamaSebepKod(iMap.getString("MUS_ISYERI_DOGRULAMA_SEBEP_KOD"));
					birDogrulamaDetayTx.setGorusulenIsim(iMap.getString("MUS_GORUSULEN_ISIM"));
					birDogrulamaDetayTx.setGorusulenUnvan(iMap.getString("MUS_GORUSULEN_UNVAN"));

					DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_CALISMA_SEKLI_KOD", iMap.getString("MUS_YENI_CALISMA_SEKLI_KOD"));
					DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_IS_ADRES", iMap.getString("MUS_YENI_IS_ADRESI"));
					DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_ISYERI_ADI", iMap.getString("MUS_YENI_ISYERI_ADI"));
					DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_ISYERINDE_CALISMA_SURESI", ConsumerLoanTRN3171Services.concatYilAy(iMap.getString("MUS_YENI_YIL"), iMap.getString("MUS_YENI_AY")));
					DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_MESLEK_KOD", iMap.getString("MUS_YENI_MESLEK_KOD"));
					DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_UNVAN", iMap.getString("MUS_YENI_UNVAN"));
					DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_ISYERI_FAAL_KONU_KOD", iMap.getString("MUS_YENI_ISYERINDE_FAAL_KONU_KOD"));
					DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "YENI_GELIR", iMap.getBigDecimal("MUS_YENI_GELIR"));
					DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "DOGRULAMA_NEDENI", iMap.getString("MUS_DOGRULAMA_NEDENI"));
					DogrulamaTipKodu.MI.addItem(dogrulamaInstance, "ISYERI_DOGRULAMA", iMap.getString("MUS_ISYERI_KARAR"));

					birDogrulamaDetayTx.setWebDogrulamaSebepKod(iMap.getString("MUS_WEB_DOGRULAMA_KOD"));
					birDogrulamaDetayTx.setGorusulenTelefon(iMap.getString("MUS_GORUSULEN_TELEFON"));

					// Tekrar aranacak ise ve max arama sayisina ulasildiysa Ulasilmadi(2)/Max Arama Sayisi Asildi(24) olarak gonder
					if (DOG_KOD_TEKRAR_ARANACAK.equals(iMap.getString("MUS_ISYERI_DOGRULAMA_KOD")) && maxAramaSayisi.equals(birDogrulamaDetayTx.getAramaAdedi())) {
						birDogrulamaDetayTx.setDogrulamaKod(DOG_KOD_ULASILMADI);
						birDogrulamaDetayTx.setDogrulamaSebepKod(DOG_SEBEP_KOD_ARAMA_SAYISI_ASILDI);
						birDogrulamaTx.setMusIsyeriDogKod(DOG_KOD_ULASILMADI);
					}

					session.saveOrUpdate(birDogrulamaDetayTx);
					session.flush();

					dogrulamaYapildiMi = true;
				}
				else { // bos ise son dogrulamadaki degerleri gonder, onceki dogrulamalari ezmesin diye.
					GMMap xMap = new GMMap();
					GMMap yMap = new GMMap();
					xMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
					xMap.put("KONTROL_TIPI", DogrulamaTipKodu.MI.name());
					yMap = GMServiceExecuter.call("BNSPR_TRN3180_GET_SON_DOGRULAMA", xMap);

					birDogrulamaTx.setMusDogIsyeriSaatTip(yMap.getString("SON_DOG_RANDEVU_MU"));
					birDogrulamaTx.setMusIsyeriDogKod(yMap.getString("SON_DOG_SONUC_KOD"));
					if (yMap.getBigDecimal("SON_DOG_TARIH") != null)
						birDogrulamaTx.setMusIsyeriDogSaat(concatDateAndTime(yMap.getString("SON_DOG_TARIH"), yMap.getString("SON_DOG_TARIH_SAAT")));
				}

				/*
				 * --------------------------------------- Kefil 1 Dogrulama -----------------------------------
				 */
				if (iMap.getString("K1_DOGRULAMA_KOD") != null) {
					birDogrulamaTx.setK1IsyeriDogKod(iMap.getString("K1_DOGRULAMA_KOD"));

					if (DOG_KOD_TEKRAR_ARANACAK.equals(iMap.getString("K1_DOGRULAMA_KOD"))) {
						if (iMap.getString("K1_RANDEVU_TARIHI") != null) {
							birDogrulamaTx.setK1IsyeriDogSaat(concatDateAndTime(iMap.getString("K1_RANDEVU_TARIHI"), iMap.getString("K1_RANDEVU_SAATI")));
							birDogrulamaTx.setK1IsyeriDogSaatTip("E");
						}
						else {
							birDogrulamaTx.setK1IsyeriDogSaat((Timestamp) DALUtil.callNoParameterFunction("{? = call PKG_TRN3180.randevu_tarih_saati()}", Types.TIMESTAMP));
							birDogrulamaTx.setK1IsyeriDogSaatTip("H");
						}
					}

					BirDogrulamaDetayTxId id = new BirDogrulamaDetayTxId();
					id.setDogrulamaTipKod(DogrulamaTipKodu.K1I.name());
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));

					BirDogrulamaDetayTx birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.get(BirDogrulamaDetayTx.class, id);

					if (birDogrulamaDetayTx == null) {
						birDogrulamaDetayTx = new BirDogrulamaDetayTx(id, idNo);
					}
					birDogrulamaDetayTx.setAciklama(iMap.getString("K1_ACIKLAMA"));
					// Arama Adedi, bir arttirilarak gonderilir.
					birDogrulamaDetayTx.setAramaAdedi(iMap.getBigDecimal("K1_ARAMA_ADEDI").add(new BigDecimal(1)));
					birDogrulamaDetayTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birDogrulamaDetayTx.setDogrulamaKod(iMap.getString("K1_DOGRULAMA_KOD"));
					birDogrulamaDetayTx.setDogrulamaSebepKod(iMap.getString("K1_DOGRULAMA_SEBEP_KOD"));
					birDogrulamaDetayTx.setGorusulenIsim(iMap.getString("K1_GORUSULEN_ISIM"));
					birDogrulamaDetayTx.setGorusulenUnvan(iMap.getString("K1_GORUSULEN_UNVAN"));

					DogrulamaTipKodu.K1I.addItem(dogrulamaInstance, "YENI_CALISMA_SEKLI_KOD", iMap.getString("K1_YENI_CALISMA_SEKLI_KOD"));
					DogrulamaTipKodu.K1I.addItem(dogrulamaInstance, "YENI_IS_ADRES", iMap.getString("K1_YENI_IS_ADRESI"));
					DogrulamaTipKodu.K1I.addItem(dogrulamaInstance, "YENI_ISYERI_ADI", iMap.getString("K1_YENI_ISYERI_ADI"));
					DogrulamaTipKodu.K1I.addItem(dogrulamaInstance, "YENI_ISYERINDE_CALISMA_SURESI", ConsumerLoanTRN3171Services.concatYilAy(iMap.getString("K1_YENI_YIL"), iMap.getString("K1_YENI_YIL")));
					DogrulamaTipKodu.K1I.addItem(dogrulamaInstance, "YENI_MESLEK_KOD", iMap.getString("K1_YENI_MESLEK_KOD"));
					DogrulamaTipKodu.K1I.addItem(dogrulamaInstance, "YENI_UNVAN", iMap.getString("K1_YENI_UNVAN"));
					DogrulamaTipKodu.K1I.addItem(dogrulamaInstance, "YENI_ISYERI_FAAL_KONU_KOD", iMap.getString("K1_YENI_ISYERINDE_FAAL_KONU_KOD"));
					DogrulamaTipKodu.K1I.addItem(dogrulamaInstance, "YENI_GELIR", iMap.getBigDecimal("K1_YENI_GELIR"));

					birDogrulamaDetayTx.setWebDogrulamaSebepKod(iMap.getString("K1_WEB_DOGRULAMA_KOD"));
					birDogrulamaDetayTx.setKefilNo(iMap.getBigDecimal("K1_NO"));
					birDogrulamaDetayTx.setGorusulenTelefon(iMap.getString("K1_GORUSULEN_TELEFON"));

					// Tekrar aranacak ise ve max arama sayisina ulasildiysa Ulasilmadi(2)/Max Arama Sayisi Asildi(24) olarak gonder
					if (DOG_KOD_TEKRAR_ARANACAK.equals(iMap.getString("K1_DOGRULAMA_KOD")) && maxAramaSayisi.equals(birDogrulamaDetayTx.getAramaAdedi())) {
						birDogrulamaDetayTx.setDogrulamaKod(DOG_KOD_ULASILMADI);
						birDogrulamaDetayTx.setDogrulamaSebepKod(DOG_SEBEP_KOD_ARAMA_SAYISI_ASILDI);

						birDogrulamaTx.setK1IsyeriDogKod(DOG_KOD_ULASILMADI);
					}

					session.saveOrUpdate(birDogrulamaDetayTx);
					session.flush();

					dogrulamaYapildiMi = true;
				}
				else { // bos ise son dogrulamadaki degerleri gonder, onceki dogrulamalari ezmesin diye.
					GMMap xMap = new GMMap();
					GMMap yMap = new GMMap();
					xMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
					xMap.put("KONTROL_TIPI", DogrulamaTipKodu.K1I.name());
					yMap = GMServiceExecuter.call("BNSPR_TRN3180_GET_SON_DOGRULAMA", xMap);

					birDogrulamaTx.setK1IsyeriDogSaatTip(yMap.getString("SON_DOG_RANDEVU_MU"));
					birDogrulamaTx.setK1IsyeriDogKod(yMap.getString("SON_DOG_SONUC_KOD"));
					if (yMap.getBigDecimal("SON_DOG_TARIH") != null)
						birDogrulamaTx.setK1IsyeriDogSaat(concatDateAndTime(yMap.getString("SON_DOG_TARIH"), yMap.getString("SON_DOG_TARIH_SAAT")));
				}

				/*
				 * --------------------------------------- Kefil 2 Dogrulama -----------------------------------
				 */
				if (iMap.getString("K2_DOGRULAMA_KOD") != null) {
					birDogrulamaTx.setK2IsyeriDogKod(iMap.getString("K2_DOGRULAMA_KOD"));

					if (DOG_KOD_TEKRAR_ARANACAK.equals(iMap.getString("K2_DOGRULAMA_KOD"))) {
						if (iMap.getString("K2_RANDEVU_TARIHI") != null) {
							birDogrulamaTx.setK2IsyeriDogSaat(concatDateAndTime(iMap.getString("K2_RANDEVU_TARIHI"), iMap.getString("K2_RANDEVU_SAATI")));
							birDogrulamaTx.setK2IsyeriDogSaatTip("E");
						}
						else {
							birDogrulamaTx.setK2IsyeriDogSaat((Timestamp) DALUtil.callNoParameterFunction("{? = call PKG_TRN3180.randevu_tarih_saati()}", Types.TIMESTAMP));
							birDogrulamaTx.setK2IsyeriDogSaatTip("H");
						}
					}

					BirDogrulamaDetayTxId id = new BirDogrulamaDetayTxId();
					id.setDogrulamaTipKod(DogrulamaTipKodu.K2I.name());
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));

					BirDogrulamaDetayTx birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.get(BirDogrulamaDetayTx.class, id);

					if (birDogrulamaDetayTx == null) {
						birDogrulamaDetayTx = new BirDogrulamaDetayTx(id, idNo);
					}
					birDogrulamaDetayTx.setAciklama(iMap.getString("K2_ACIKLAMA"));
					// Arama Adedi, bir arttirilarak gonderilir.
					birDogrulamaDetayTx.setAramaAdedi(iMap.getBigDecimal("K2_ARAMA_ADEDI").add(new BigDecimal(1)));
					birDogrulamaDetayTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birDogrulamaDetayTx.setDogrulamaKod(iMap.getString("K2_DOGRULAMA_KOD"));
					birDogrulamaDetayTx.setDogrulamaSebepKod(iMap.getString("K2_DOGRULAMA_SEBEP_KOD"));
					birDogrulamaDetayTx.setGorusulenIsim(iMap.getString("K2_GORUSULEN_ISIM"));
					birDogrulamaDetayTx.setGorusulenUnvan(iMap.getString("K2_GORUSULEN_UNVAN"));

					DogrulamaTipKodu.K2I.addItem(dogrulamaInstance, "YENI_CALISMA_SEKLI_KOD", iMap.getString("K2_YENI_CALISMA_SEKLI_KOD"));
					DogrulamaTipKodu.K2I.addItem(dogrulamaInstance, "YENI_IS_ADRES", iMap.getString("K2_YENI_IS_ADRESI"));
					DogrulamaTipKodu.K2I.addItem(dogrulamaInstance, "YENI_ISYERI_ADI", iMap.getString("K2_YENI_ISYERI_ADI"));
					DogrulamaTipKodu.K2I.addItem(dogrulamaInstance, "YENI_ISYERINDE_CALISMA_SURESI", ConsumerLoanTRN3171Services.concatYilAy(iMap.getString("K2_YENI_YIL"), iMap.getString("K2_YENI_YIL")));
					DogrulamaTipKodu.K2I.addItem(dogrulamaInstance, "YENI_MESLEK_KOD", iMap.getString("K2_YENI_MESLEK_KOD"));
					DogrulamaTipKodu.K2I.addItem(dogrulamaInstance, "YENI_UNVAN", iMap.getString("K2_YENI_UNVAN"));
					DogrulamaTipKodu.K2I.addItem(dogrulamaInstance, "YENI_ISYERI_FAAL_KONU_KOD", iMap.getString("K2_YENI_ISYERINDE_FAAL_KONU_KOD"));
					DogrulamaTipKodu.K2I.addItem(dogrulamaInstance, "YENI_GELIR", iMap.getBigDecimal("K2_YENI_GELIR"));

					birDogrulamaDetayTx.setWebDogrulamaSebepKod(iMap.getString("K2_WEB_DOGRULAMA_KOD"));
					birDogrulamaDetayTx.setKefilNo(iMap.getBigDecimal("K2_NO"));
					birDogrulamaDetayTx.setGorusulenTelefon(iMap.getString("K2_GORUSULEN_TELEFON"));

					// Tekrar aranacak ise ve max arama sayisina ulasildiysa Ulasilmadi(2)/Max Arama Sayisi Asildi(24) olarak gonder
					if (DOG_KOD_TEKRAR_ARANACAK.equals(iMap.getString("K2_DOGRULAMA_KOD")) && maxAramaSayisi.equals(birDogrulamaDetayTx.getAramaAdedi())) {
						birDogrulamaDetayTx.setDogrulamaKod(DOG_KOD_ULASILMADI);
						birDogrulamaDetayTx.setDogrulamaSebepKod(DOG_SEBEP_KOD_ARAMA_SAYISI_ASILDI);
						birDogrulamaTx.setK2IsyeriDogKod(DOG_KOD_ULASILMADI);
					}

					session.saveOrUpdate(birDogrulamaDetayTx);
					session.flush();

					dogrulamaYapildiMi = true;
				}
				else { // bos ise son dogrulamadaki degerleri gonder, onceki dogrulamalari ezmesin diye.
					GMMap xMap = new GMMap();
					GMMap yMap = new GMMap();
					xMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
					xMap.put("KONTROL_TIPI", DogrulamaTipKodu.K2I.name());
					yMap = GMServiceExecuter.call("BNSPR_TRN3180_GET_SON_DOGRULAMA", xMap);

					birDogrulamaTx.setK2IsyeriDogSaatTip(yMap.getString("SON_DOG_RANDEVU_MU"));
					birDogrulamaTx.setK2IsyeriDogKod(yMap.getString("SON_DOG_SONUC_KOD"));
					if (yMap.getBigDecimal("SON_DOG_TARIH") != null)
						birDogrulamaTx.setK2IsyeriDogSaat(concatDateAndTime(yMap.getString("SON_DOG_TARIH"), yMap.getString("SON_DOG_TARIH_SAAT")));
				}

				if (iMap.getString("MW_AKSIYON_KOD").equals("Y")) {
					birDogrulamaTx.setMusWebDogKod(DOG_KOD_ULASILDI);

					BirDogrulamaDetayTxId id = new BirDogrulamaDetayTxId();
					id.setDogrulamaTipKod(DogrulamaTipKodu.MW.name());
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));

					BirDogrulamaDetayTx birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.get(BirDogrulamaDetayTx.class, id);

					if (birDogrulamaDetayTx == null) {
						birDogrulamaDetayTx = new BirDogrulamaDetayTx(id, idNo);
					}
					birDogrulamaDetayTx.setAciklama(iMap.getString("Web dogrulama yapildi"));
					// Arama Adedi, bir arttirilarak gonderilir.
					birDogrulamaDetayTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					birDogrulamaDetayTx.setDogrulamaKod(DOG_KOD_ULASILDI);
					birDogrulamaDetayTx.setDogrulamaSebepKod(DOG_KOD_ULASILDI_NEDEN);
					birDogrulamaDetayTx.setGorusulenIsim(iMap.getString("MUS_GORUSULEN_ISIM"));
					birDogrulamaDetayTx.setGorusulenUnvan(iMap.getString("MUS_GORUSULEN_UNVAN"));
					birDogrulamaDetayTx.setWebDogrulamaSebepKod(iMap.getString("MUS_WEB_DOGRULAMA_KOD"));
					birDogrulamaDetayTx.setGorusulenTelefon(iMap.getString("MUS_GORUSULEN_TELEFON"));

					session.saveOrUpdate(birDogrulamaDetayTx);
					session.flush();
				}

				if (iMap.getString("M_AKSIYON_KOD").equals("N") //
						&& iMap.getString("MF_AKSIYON_KOD").equals("N") //
						&& iMap.getString("MI_AKSIYON_KOD").equals("Not Required") //
						&& iMap.getString("K1I_AKSIYON_KOD").equals("Not Required") //
						&& iMap.getString("K2I_AKSIYON_KOD").equals("Not Required") //
						&& iMap.getString("MW_AKSIYON_KOD").equals("Y") //
						&& iMap.getString("K1F_AKSIYON_KOD").equals("N") //
						&& iMap.getString("K2F_AKSIYON_KOD").equals("N")) {

					dogrulamaYapildiMi = true;
				}

				if (!dogrulamaYapildiMi) {
					break save;
				}

				DogrulamaTipKodu.M.addItem(dogrulamaInstance, "DOGRULAMA_NEDENI_1", iMap.getString("M_DOGRULAMA_NEDENI_1"));
				DogrulamaTipKodu.M.addItem(dogrulamaInstance, "DOGRULAMA_NEDENI_2", iMap.getString("M_DOGRULAMA_NEDENI_2"));
				DogrulamaTipKodu.M.addItem(dogrulamaInstance, "DOGRULAMA_NEDENI_3", iMap.getString("M_DOGRULAMA_NEDENI_3"));
				DogrulamaTipKodu.M.addItem(dogrulamaInstance, "TESLIMAT_TARIH", iMap.getDate("M_TESLIMAT_TARIH") == null ? null : simpleDateFormat2.format(iMap.getDate("M_TESLIMAT_TARIH")));
				DogrulamaTipKodu.M.addItem(dogrulamaInstance, "ERKEN_TESLIM_NEDENI", iMap.getString("M_ERKEN_TESLIM_NEDENI"));
				DogrulamaTipKodu.M.addItem(dogrulamaInstance, "GEC_TESLIM_NEDENI", iMap.getString("M_GEC_TESLIM_NEDENI"));
				DogrulamaTipKodu.M.addItem(dogrulamaInstance, "TESLIMAT_ADRESI", iMap.getString("M_TESLIMAT_ADRESI"));
				DogrulamaTipKodu.M.addItem(dogrulamaInstance, "MOBIL_URUN_MU", iMap.getString("M_MOBIL_URUN_MU"));
				// TY-1412 ao 22.10.2014
				/*if (iMap.getBoolean("M_URUN_BASKASINA_MI"))
					DogrulamaTipKodu.M.addItem(dogrulamaInstance, "URUN_BASKASINA_MI", "Y");
				else if (iMap.getBoolean("M_URUN_BASKASINA_MI_HAYIR"))
					DogrulamaTipKodu.M.addItem(dogrulamaInstance, "URUN_BASKASINA_MI", "N");
				else
					DogrulamaTipKodu.M.addItem(dogrulamaInstance, "URUN_BASKASINA_MI", null);*/
				if (iMap.getBoolean("M_ADRES_FARKLI_MI"))
					DogrulamaTipKodu.M.addItem(dogrulamaInstance, "ADRES_FARKLI_MI", "Y");
				else if (iMap.getBoolean("M_ADRES_FARKLI_MI_HAYIR"))
					DogrulamaTipKodu.M.addItem(dogrulamaInstance, "ADRES_FARKLI_MI", "N");
				else
					DogrulamaTipKodu.M.addItem(dogrulamaInstance, "ADRES_FARKLI_MI", null);
				DogrulamaTipKodu.M.addItem(dogrulamaInstance, "FARKLI_OLMA_NEDENI", iMap.getString("M_FARKLI_OLMA_NEDENI"));
				DogrulamaTipKodu.M.addItem(dogrulamaInstance, "URUN_KIME", iMap.getString("M_URUN_KIME"));
				DogrulamaTipKodu.M.addItem(dogrulamaInstance, "DETAY_PAYLASILMADI", iMap.getBoolean("M_DETAY_PAYLASILMADI") ? "Y" : "N");
				DogrulamaTipKodu.M.addItem(dogrulamaInstance, "URUN_DOGRULAMA", iMap.getString("M_URUN_DOGRULAMA"));

				DogrulamaTipKodu.DS.addItem(dogrulamaInstance, "KIMLIK_DOGRULAMA_NF_VER_TAR", iMap.getString("KIMLIK_DOGRULAMA_NF_VER_TAR"));
				DogrulamaTipKodu.DS.addItem(dogrulamaInstance, "KIMLIK_DOGRULAMA_NF_VER_YER", iMap.getString("KIMLIK_DOGRULAMA_NF_VER_YER"));
				DogrulamaTipKodu.DS.addItem(dogrulamaInstance, "KIMLIK_DOGRULAMA_NF_VER_NEDEN", iMap.getString("KIMLIK_DOGRULAMA_NF_VER_NEDEN"));
				DogrulamaTipKodu.DS.addItem(dogrulamaInstance, "ARAC_DOGRULAMA", iMap.getString("DS_ARAC_DOGRULAMA"));

				DogrulamaTipKodu.A.addItem(dogrulamaInstance, "ARAC_PLAKA", iMap.getString("A_ARAC_PLAKA"));
				DogrulamaTipKodu.A.addItem(dogrulamaInstance, "ARAC_MARKA", iMap.getString("A_ARAC_MARKA"));
				DogrulamaTipKodu.A.addItem(dogrulamaInstance, "ARAC_MODEL", iMap.getString("A_ARAC_MODEL"));
				DogrulamaTipKodu.A.addItem(dogrulamaInstance, "ARAC_DEGER", iMap.getString("A_ARAC_DEGER"));
				DogrulamaTipKodu.A.addItem(dogrulamaInstance, "ARAC_RENK", iMap.getString("A_ARAC_RENK"));
				DogrulamaTipKodu.A.addItem(dogrulamaInstance, "SERH_DURUM", iMap.getString("A_SERH_DURUM"));
				DogrulamaTipKodu.A.addItem(dogrulamaInstance, "SERH_TIPI", iMap.getString("A_SERH_TIPI"));
				DogrulamaTipKodu.A.addItem(dogrulamaInstance, "ARAC_ACIKLAMA", iMap.getString("A_ARAC_ACIKLAMA"));

				String dogrulamaValues = DogrulamaTipKodu.valuesOf(dogrulamaInstance);

				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call PKG_TRN3180.save_trn3180_tx(?,?,?)}");
				stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
				stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
				stmt.setString(3, dogrulamaValues);
				stmt.execute();

				if (iMap.getString("MF_DOGRULAMA_SEBEP_KOD") != null && iMap.getString("MF_DOGRULAMA_SEBEP_KOD").equals("3")) {
					birDogrulamaTx.setIslemSonrasiDurumKodu(ISLEM_SONRASI_DURUM_KODU_IPTAL);
				}

				if (birDogrulamaTx.getIslemSonrasiDurumKodu() == "IPTAL") {
					nbsm_ilerlet = "N";
					birDogrulamaTx.setAksiyonKararKod(AKSIYON_KARAR_KODU_IPTAL);
					birDogrulamaTx.setAksiyonKod(AKSIYON_KODU_IPTAL);
					BirBasvuruFraudTx birBasvuruFraudTx = (BirBasvuruFraudTx) session.createCriteria(BirBasvuruFraudTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
					if (birBasvuruFraudTx == null) {
						birBasvuruFraudTx = new BirBasvuruFraudTx();
						birBasvuruFraudTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						birBasvuruFraudTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
						birBasvuruFraudTx.setGorus(iMap.getString("GORUS"));
						session.saveOrUpdate(birBasvuruFraudTx);
					}
					else {
						birBasvuruFraudTx.setGorus(iMap.getString("GORUS"));
						session.update(birBasvuruFraudTx);
					}

				}
				else if ("6".equals(iMap.getString("FRAUD_KARAR"))) {
					nbsm_ilerlet = "Y";
					birDogrulamaTx.setAksiyonKod(iMap.getString("FRAUD_KARAR"));
					birDogrulamaTx.setAksiyonKararKod(iMap.getString("FRAUD_GEREKCE"));

					BirBasvuruFraudTx birBasvuruFraudTx = (BirBasvuruFraudTx) session.createCriteria(BirBasvuruFraudTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
					if (birBasvuruFraudTx == null) {
						birBasvuruFraudTx = new BirBasvuruFraudTx();
						birBasvuruFraudTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						birBasvuruFraudTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
						birBasvuruFraudTx.setGorus(iMap.getString("GORUS"));
						birBasvuruFraudTx.setFraudSonucKod(iMap.getString("FRAUD_KARAR"));
						birBasvuruFraudTx.setFraudKaynakKod(iMap.getString("FRAUD_KAYNAK_KOD"));
						birBasvuruFraudTx.setFraudNedenKod(iMap.getString("FRAUD_GEREKCE"));
						birBasvuruFraudTx.setDogrulamaTahsisGorus(iMap.getString("DT_GORUS"));
						session.saveOrUpdate(birBasvuruFraudTx);
					}
					else {
						birBasvuruFraudTx.setFraudSonucKod(iMap.getString("FRAUD_KARAR"));
						birBasvuruFraudTx.setFraudKaynakKod(iMap.getString("FRAUD_KAYNAK_KOD"));
						birBasvuruFraudTx.setFraudNedenKod(iMap.getString("FRAUD_GEREKCE"));
						birBasvuruFraudTx.setGorus(iMap.getString("GORUS"));
						birBasvuruFraudTx.setDogrulamaTahsisGorus(iMap.getString("DT_GORUS"));
						session.update(birBasvuruFraudTx);
					}
				}
				else {
					stmt2 = conn.prepareCall("{? = call PKG_TRN3180.f_dogrulama_nbsm_ilerlet(?)}");
					stmt2.registerOutParameter(1, Types.VARCHAR);
					stmt2.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
					stmt2.execute();
					nbsm_ilerlet = stmt2.getString(1);
				}
				// Dogrulama yapilmasi gereken alanlarin hepsinin dogrulamasi yapildiysa IslemSonrasiDurumKodu'na NBSM set edilir.
				if (nbsm_ilerlet.equals("Y")) {
					birDogrulamaTx.setIslemSonrasiDurumKodu(ISLEM_SONRASI_DURUM_KODU_NBSM);
				}
				else {
					GMMap bMap = new GMMap();
					bMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					bMap.put("DURUM_KOD", new BigDecimal(98));
					GMServiceExecuter.execute("BNSPR_CL_UPDATE_DEBIT_CARD_REQUEST", bMap);
				}

				session.saveOrUpdate(birDogrulamaTx);
				session.flush();

				iMap.put("TRX_NAME", "3180");
				GMMap oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);

				oMap.put("NBSM_ILERLET", nbsm_ilerlet);

				ADCSession.remove("3180_DYN_INS_" + iMap.getString("TRX_NO"));
				return oMap;
			}

			throw new GMRuntimeException(0, GMMessageFactory.getMessage("3180_DOGRULAMA_YAPILMADI", null));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3180_SGK_OTO_ILERLET")
	public static GMMap otomatikIlerlet(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", "WEB_DOG_OTO_ILERLET")).uniqueResult();
			if ("E".equals(parametre.getDeger())) {
				GMMap sgkMap = GMServiceExecuter.call("BNSPR_TRN3180_SET_SGK_VALUES", iMap);

				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
				iMap.put("MW/GUN_1_YIL", sgkMap.getBigDecimal("GUN1"));
				iMap.put("MW/GUN_2_YIL", sgkMap.getBigDecimal("GUN2"));
				iMap.put("OZEL_SANDIK", false);
				iMap.put("SSK", false);
				iMap.put("BAGKUR", false);
				iMap.put("EMEKLI_SANDIGI", false);
				iMap.put("MW/MANUEL_WEB_DOGRULAMA_YOK", "Y");
				iMap.put("MW/SSK_PRIM_GUN_TOPLAM", sgkMap.getBigDecimal("PRIM_GUNU"));
				iMap.put("MW/SSK_IS_BASLANGIC_TARIHI", sgkMap.getDate("GIRIS_TARIHI"));
				iMap.put("MW/KAMU_CALISMA_DURUMU", "KAPALI");
				iMap.put("MW/CALISAN_EMEKLI_KAYIT_YOK", sgkMap.getBoolean("KAYDI_YOK") ? "Y" : "N");
				iMap.put("MW/DONEM_SAYISI", sgkMap.getBigDecimal("DONEM_SAYISI"));
				iMap.put("MW/SSK_IS_BITIS_TARIHI", sgkMap.getDate("CIKIS_TARIHI"));
				iMap.put("PREPARING_SERVICE", "BNSPR_TRN3180_GET_WEB_DOG_DYN_DATA");
				iMap.put("MW/CALISMA_SEKLI", sgkMap.getString("CALISMA_SEKLI"));
				iMap.put("MW/SSK_BASLANGIC_TARIHI", sgkMap.getDate("ILK_GIRIS_TARIHI"));
				iMap.put("MW/SSK_SON_PRIM_TARIHI", sgkMap.getDate("PRIM_SON_ODEME_TARIHI"));
				iMap.put("MW/DEGISTIRILEN_IS_SAYISI_2_YIL", sgkMap.getInt("ISYERI_ADET"));
				iMap.put("MW/SON_EKSIK_GUN_NEDENI", sgkMap.getString("SON_EKSIK_GUN_NEDENI"));
				iMap.put("MW/SON_DONEM_GUN", sgkMap.getBigDecimal("SON_DONEM_GUN"));

				iMap.put("KONTROL_TIPI", "MW");
				iMap.put("MW/MW/BAGKUR_ISYERI", GMServiceExecuter.call("BNSPR_TRN3180_GET_DETAY_ISYERI", iMap).getString("IS_ADRES"));

				iMap.put("MW/SSK_SON_PRIM_TUTARI", sgkMap.getBigDecimal("PRIM_TUTARI"));

				iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3180_CREATE_DYN_INS", iMap));

				iMap.put("M_AKSIYON", "N");
				iMap.put("MF_AKSIYON", "N");
				iMap.put("K1I_AKSIYON_KOD", "Not Required");
				iMap.put("M_ADRES_FARKLI_MI_HAYIR", false);
				iMap.put("K2I_AKSIYON_KOD", "Not Required");
				iMap.put("M_NBSM_KOD", "N");
				iMap.put("MW_AKSIYON_KOD", "Y");
				iMap.put("M_AKSIYON_KOD", "N");
				iMap.put("MI_AKSIYON_KOD", "Not Required");
				iMap.put("K2I_NBSM_KOD", "Not Required");
				iMap.put("M_ADRES_FARKLI_MI", false);
				iMap.put("MUS_DOGRULAMA_NEDENI", "Aranmayacak(Kalan)");
				iMap.put("ISLEM_KODU", "3180");
				iMap.put("K2F_AKSIYON_KOD", "N");
				iMap.put("K1F_AKSIYON_KOD", "N");
				iMap.put("MF_AKSIYON_KOD", "N");
				iMap.put("MI_NBSM_KOD", "Not Required");
				iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3174_GET_BELGE_LIST", iMap));

				iMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3180_SAVE", iMap));
				if ("Y".equalsIgnoreCase(iMap.getString("NBSM_ILERLET"))) {
					iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3180_NBSM_CALL", iMap));
					// iMap.putAll(GMServiceExecuter.call("BNSPR_BASVURU_SEND_SMS", iMap));

					if (!"RED".equalsIgnoreCase(iMap.getString("DURUM"))) {
						GMMap sMap = new GMMap();
						BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

						GnlMusteri musteri = (GnlMusteri) session.get(GnlMusteri.class, birBasvuru.getMusteriNo());
						session.refresh(musteri);

						sMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
						sMap.put("MUSTERI_KONTAKT", musteri.getMusteriKontakt());
						sMap.putAll(GMServiceExecuter.execute("BNSPR_MUSTERI_BHS_KONTROL", sMap));
						sMap.putAll(GMServiceExecuter.execute("BNSPR_CL_KART_BHS_KONTROL", sMap));
						if (("K".equals(sMap.getString("MUSTERI_KONTAKT")) && (!"E".equals(sMap.getString("F_BHS")) || !"E".equals(sMap.getString("KK_BHS")))) || "7".equalsIgnoreCase(birBasvuru.getKanalKodu())) {

							String mesaj = "";
							String cepTel = iMap.getString("CEPTEL");

							iMap.put("P1", birBasvuru.getBasvuruNo());
							iMap.put("P5", birBasvuru.getKanalKodu());

							if (new BigDecimal(8).equals(birBasvuru.getOdemeTipKod())) {
								iMap.put("MESSAGE_NO", new java.math.BigDecimal(6173));
							}
							else {
								iMap.put("MESSAGE_NO", new java.math.BigDecimal(5232));
							}

							mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
							if (!"".equals(cepTel) && !"".equals(mesaj)) {
								GMMap smsMap = new GMMap();
								smsMap.put("MSISDN", iMap.getString("CEPTEL"));
								smsMap.put("CONTENT", mesaj);
								if (new BigDecimal(8).equals(birBasvuru.getOdemeTipKod())) {
									smsMap.put("HEADER", ".NKOLAY");
								}
								else {
									smsMap.put("HEADER", "AktifBank");
								}
								GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsMap).get("RESULT");
							}
						}
					}
				}

			}

		}
		catch (ParseException e) {
			e.printStackTrace();
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_NBSM_CALL")
	public static GMMap nbsmCall(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap bMap = new GMMap();

		// Islem sonrasinda basvurunun durumkodu NBSM olmussa NBSM Call yapilir.
		BirDogrulamaTx islemSonrasi = (BirDogrulamaTx) session.get(BirDogrulamaTx.class, iMap.getBigDecimal("TRX_NO"));
		if (ISLEM_SONRASI_DURUM_KODU_NBSM.equals(islemSonrasi.getIslemSonrasiDurumKodu()) || "Y".equals(iMap.getString("NBSM_ILERLET"))) {

			bMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			bMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));

			bMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_FINAL_SORGULAR", bMap));

			/** Web kanalinda Onay Ciktiysa **/
			if ("SOZLESME".equals(bMap.getString("DURUM"))) {
				BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				if ("8".equals(birBasvuru.getKanalKodu()) || "5".equals(birBasvuru.getKanalKodu())) {
					GMServiceExecuter.execute("BNSPR_CL_WEB_AUTOMATIC_AGREEMENT_PROCESS", iMap);
				}
				else if ("7".equals(birBasvuru.getKanalKodu()) && "PTT_SMS".equals(birBasvuru.getWebSatisKanali()) && "K".equals(birBasvuru.getKuryeSecimi())) {
					GMMap sMap = new GMMap();
					sMap.put("BASVURU_NO", birBasvuru.getBasvuruNo());
					sMap.putAll(GMServiceExecuter.call("CLKS_GET_PAY_PLN_3181_REQUEST_INFO", iMap));
					sMap.put("TAKSIT_GUNU", birBasvuru.getTaksitGunu());
					sMap.putAll(GMServiceExecuter.call("BNSPR_TRN3172_CREATE_AGREEMENT", sMap));
					sMap.put("AGREEMENT_TRX_NO", sMap.get("TRX_NO"));
					GMServiceExecuter.execute("BNSPR_TRN3172_SAVE_AGREEMENT", sMap);
				}
			}

			/** kart talebi varsa guncelleyen servisi cagir **/
			if ("ISTIHBARAT".equals(bMap.getString("DURUM")) || "SOZLESME".equals(bMap.getString("DURUM"))) {
				bMap.put("DURUM_KOD", BigDecimal.ZERO);
			}
			else {
				bMap.put("DURUM_KOD", new BigDecimal(98));
			}
			GMServiceExecuter.execute("BNSPR_CL_UPDATE_DEBIT_CARD_REQUEST", bMap);
		}
		return bMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_INFO")
	public static GMMap getInfoTRN3180(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			org.hibernate.Session session = DAOSession.getSession("BNSPRDal");
			String[] tarihSaat;

			BirDogrulamaTx birDogrulamaTx = (BirDogrulamaTx) session.get(BirDogrulamaTx.class, iMap.getBigDecimal("TRX_NO"));

			oMap.put("BASVURU_NO", birDogrulamaTx.getBasvuruNo());

			tarihSaat = splitDateAndTime(birDogrulamaTx.getK1IsyeriDogSaat());

			oMap.put("K1_RANDEVU_TARIHI", tarihSaat[0]);
			oMap.put("K1_RANDEVU_SAATI", tarihSaat[1]);

			tarihSaat = splitDateAndTime(birDogrulamaTx.getK2IsyeriDogSaat());
			oMap.put("K2_RANDEVU_TARIHI", tarihSaat[0]);
			oMap.put("K2_RANDEVU_SAATI", tarihSaat[1]);

			tarihSaat = splitDateAndTime(birDogrulamaTx.getMusDogSaat());
			oMap.put("MUS_RANDEVU_TARIHI", tarihSaat[0]);
			oMap.put("MUS_RANDEVU_SAATI", tarihSaat[1]);

			tarihSaat = splitDateAndTime(birDogrulamaTx.getMusIsyeriDogSaat());
			oMap.put("MUS_ISYERI_RANDEVU_TARIHI", tarihSaat[0]);
			oMap.put("MUS_ISYERI_RANDEVU_SAATI", tarihSaat[1]);

			// Musteri Dogrulama
			BirDogrulamaDetayTx birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", "M")).uniqueResult();

			if (birDogrulamaDetayTx != null) {
				oMap.put("MUS_ACIKLAMA", birDogrulamaDetayTx.getAciklama());
				oMap.put("MUS_DIGER_TELEFON", birDogrulamaDetayTx.getDigerTelefon());
				oMap.put("MUS_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
				oMap.put("MUS_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
				oMap.put("MUS_GORUSULEN_TELEFON", birDogrulamaDetayTx.getGorusulenTelefon());
				oMap.put("DIGER_TELEFON_KAYNAK", birDogrulamaDetayTx.getDigerTelefonKaynak());
			}

			// Musteri Web Dogrulama
			birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", DogrulamaTipKodu.MF.name())).uniqueResult();

			if (birDogrulamaDetayTx != null) {
				oMap.put("MF_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
				oMap.put("MF_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
			}
			else {
				oMap.put("MF_DOGRULAMA_KOD", oMap.get("MUS_DOGRULAMA_KOD"));
			}

			// Musteri Web Dogrulama
			birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", DogrulamaTipKodu.MW.name())).uniqueResult();

			/*
			if(birDogrulamaDetayTx != null) {
				oMap.put("MW_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
				oMap.put("MW_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
			}*/

			// Musteri Web Dogrulama
			birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", DogrulamaTipKodu.K1F.name())).uniqueResult();

			if (birDogrulamaDetayTx != null) {
				oMap.put("K1F_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
				oMap.put("K1F_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
			}

			// Musteri Web Dogrulama
			birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", DogrulamaTipKodu.K2F.name())).uniqueResult();

			if (birDogrulamaDetayTx != null) {
				oMap.put("K2F_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
				oMap.put("K2F_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
			}

			// Musteri Isyeri Dogrulama
			birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", "MI")).uniqueResult();
			if (birDogrulamaDetayTx != null) {
				oMap.put("MUS_ISYERI_ACIKLAMA", birDogrulamaDetayTx.getAciklama());
				oMap.put("MUS_ISYERI_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
				oMap.put("MUS_ISYERI_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
				oMap.put("MUS_ISYERI_GORUSULEN_ISIM", birDogrulamaDetayTx.getGorusulenIsim());
				oMap.put("MUS_ISYERI_GORUSULEN_UNVAN", birDogrulamaDetayTx.getGorusulenUnvan());
				oMap.put("MUS_ISYERI_YENI_CALISMA_SEKLI_KOD", birDogrulamaDetayTx.getYeniCalismaSekliKod());
				oMap.put("MUS_ISYERI_YENI_IS_ADRES", birDogrulamaDetayTx.getYeniIsAdres());
				oMap.put("MUS_ISYERI_YENI_ISYERI_ADI", birDogrulamaDetayTx.getYeniIsyeriAdi());
				String calismaSuresi = birDogrulamaDetayTx.getYeniIsyerindeCalismaSuresi();
				if (calismaSuresi != null) {
					oMap.put("MUS_ISYERI_YENI_YIL", calismaSuresi.substring(0, 2));
					oMap.put("MUS_ISYERI_YENI_AY", calismaSuresi.substring(2, 4));
				}
				oMap.put("MUS_ISYERI_YENI_MESLEK_KOD", birDogrulamaDetayTx.getYeniMeslekKod());
				oMap.put("MUS_ISYERI_YENI_UNVAN", birDogrulamaDetayTx.getYeniUnvan());
				oMap.put("MUS_YENI_ISYERINDE_FAAL_KONU_KOD", birDogrulamaDetayTx.getYeniIsyeriFaalKonuKod());
				oMap.put("MUS_YENI_GELIR", birDogrulamaDetayTx.getYeniGelir());
				oMap.put("MUS_WEB_DOGRULAMA_KOD", birDogrulamaDetayTx.getWebDogrulamaSebepKod());
			}

			// Kefil 1 Dogrulama
			birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", "K1I")).uniqueResult();
			if (birDogrulamaDetayTx != null) {
				oMap.put("K1_ISYERI_ACIKLAMA", birDogrulamaDetayTx.getAciklama());
				oMap.put("K1_ISYERI_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
				oMap.put("K1_ISYERI_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
				oMap.put("K1_ISYERI_GORUSULEN_ISIM", birDogrulamaDetayTx.getGorusulenIsim());
				oMap.put("K1_ISYERI_GORUSULEN_UNVAN", birDogrulamaDetayTx.getGorusulenUnvan());
				oMap.put("K1_ISYERI_YENI_CALISMA_SEKLI_KOD", birDogrulamaDetayTx.getYeniCalismaSekliKod());
				oMap.put("K1_ISYERI_YENI_IS_ADRES", birDogrulamaDetayTx.getYeniIsAdres());
				oMap.put("K1_ISYERI_YENI_ISYERI_ADI", birDogrulamaDetayTx.getYeniIsyeriAdi());
				String calismaSuresi = birDogrulamaDetayTx.getYeniIsyerindeCalismaSuresi();
				if (calismaSuresi != null) {
					oMap.put("K1_ISYERI_YENI_YIL", calismaSuresi.substring(0, 2));
					oMap.put("K1_ISYERI_YENI_AY", calismaSuresi.substring(2, 4));
				}
				oMap.put("K1_ISYERI_YENI_MESLEK_KOD", birDogrulamaDetayTx.getYeniMeslekKod());
				oMap.put("K1_ISYERI_YENI_UNVAN", birDogrulamaDetayTx.getYeniUnvan());
				oMap.put("K1_YENI_ISYERINDE_FAAL_KONU_KOD", birDogrulamaDetayTx.getYeniIsyeriFaalKonuKod());
				oMap.put("K1_YENI_GELIR", birDogrulamaDetayTx.getYeniGelir());
				oMap.put("K1_WEB_DOGRULAMA_KOD", birDogrulamaDetayTx.getWebDogrulamaSebepKod());
				oMap.put("K1_NO", birDogrulamaDetayTx.getKefilNo());
			}

			// Kefil 2 Dogrulama
			birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", "K2I")).uniqueResult();
			if (birDogrulamaDetayTx != null) {
				oMap.put("K2_ISYERI_ACIKLAMA", birDogrulamaDetayTx.getAciklama());
				oMap.put("K2_ISYERI_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
				oMap.put("K2_ISYERI_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
				oMap.put("K2_ISYERI_GORUSULEN_ISIM", birDogrulamaDetayTx.getGorusulenIsim());
				oMap.put("K2_ISYERI_GORUSULEN_UNVAN", birDogrulamaDetayTx.getGorusulenUnvan());
				oMap.put("K2_ISYERI_YENI_CALISMA_SEKLI_KOD", birDogrulamaDetayTx.getYeniCalismaSekliKod());
				oMap.put("K2_ISYERI_YENI_IS_ADRES", birDogrulamaDetayTx.getYeniIsAdres());
				oMap.put("K2_ISYERI_YENI_ISYERI_ADI", birDogrulamaDetayTx.getYeniIsyeriAdi());
				String calismaSuresi = birDogrulamaDetayTx.getYeniIsyerindeCalismaSuresi();
				if (calismaSuresi != null) {
					oMap.put("K2_ISYERI_YENI_YIL", calismaSuresi.substring(0, 2));
					oMap.put("K2_ISYERI_YENI_AY", calismaSuresi.substring(2, 4));
				}
				oMap.put("K2_ISYERI_YENI_MESLEK_KOD", birDogrulamaDetayTx.getYeniMeslekKod());
				oMap.put("K2_ISYERI_YENI_UNVAN", birDogrulamaDetayTx.getYeniUnvan());
				oMap.put("K2_YENI_ISYERINDE_FAAL_KONU_KOD", birDogrulamaDetayTx.getYeniIsyeriFaalKonuKod());
				oMap.put("K2_YENI_GELIR", birDogrulamaDetayTx.getYeniGelir());
				oMap.put("K2_WEB_DOGRULAMA_KOD", birDogrulamaDetayTx.getWebDogrulamaSebepKod());
				oMap.put("K2_NO", birDogrulamaDetayTx.getKefilNo());
			}

			String tableName = "BELGE";
			int row = 0;
			List<?> belgeList = session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : belgeList) {
				BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) name;
				oMap.put(tableName, row, "KIMDEN", LovHelper.diLov(birBasvuruBelgeTx.getId().getKimden(), "3181/LOV_BASVURU_KISI", "ACIKLAMA"));
				oMap.put(tableName, row, "KIMDEN_KOD", birBasvuruBelgeTx.getId().getKimden());
				oMap.put(tableName, row, "BELGE_KOD", birBasvuruBelgeTx.getId().getDokumanKod());
				oMap.put(tableName, row, "BELGE_ADI", LovHelper.diLov(birBasvuruBelgeTx.getId().getDokumanKod(), "3174/LOV_BELGE_KOD", "ACIKLAMA"));
				oMap.put(tableName, row, "BELGE_ALINMA_ADIMI", birBasvuruBelgeTx.getBelgeAlinmaAdim());

				row++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3180_GET_INFO_BASVURU")
	public static GMMap getInfoBasvuruTRN3180(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			org.hibernate.Session session = DAOSession.getSession("BNSPRDal");
			String[] tarihSaat;

			BigDecimal trxNo = new BigDecimal(-1);

			List<?> dogrulamaList = session.createCriteria(BirDogrulamaTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
			Object[] arrayDogrulama = dogrulamaList.toArray();
			for (int i = 0; i < arrayDogrulama.length; i++) {
				if (trxNo.compareTo(((BirDogrulamaTx) dogrulamaList.get(i)).getTxNo()) == -1) {
					trxNo = ((BirDogrulamaTx) dogrulamaList.get(i)).getTxNo();
				}
			}
			if (trxNo.compareTo(new BigDecimal(-1)) == 1) {
				BirDogrulamaTx birDogrulamaTx = (BirDogrulamaTx) session.get(BirDogrulamaTx.class, trxNo);

				oMap.put("TRX_NO", trxNo);
				tarihSaat = splitDateAndTime(birDogrulamaTx.getK1IsyeriDogSaat());
				oMap.put("K1_RANDEVU_TARIHI", tarihSaat[0]);
				oMap.put("K1_RANDEVU_SAATI", tarihSaat[1]);

				tarihSaat = splitDateAndTime(birDogrulamaTx.getK2IsyeriDogSaat());
				oMap.put("K2_RANDEVU_TARIHI", tarihSaat[0]);
				oMap.put("K2_RANDEVU_SAATI", tarihSaat[1]);

				tarihSaat = splitDateAndTime(birDogrulamaTx.getMusDogSaat());
				oMap.put("MUS_RANDEVU_TARIHI", tarihSaat[0]);
				oMap.put("MUS_RANDEVU_SAATI", tarihSaat[1]);

				tarihSaat = splitDateAndTime(birDogrulamaTx.getMusIsyeriDogSaat());
				oMap.put("MUS_ISYERI_RANDEVU_TARIHI", tarihSaat[0]);
				oMap.put("MUS_ISYERI_RANDEVU_SAATI", tarihSaat[1]);

				// Musteri Dogrulama
				BirDogrulamaDetayTx birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", "M")).uniqueResult();

				if (birDogrulamaDetayTx != null) {
					oMap.put("MUS_ACIKLAMA", birDogrulamaDetayTx.getAciklama());
					oMap.put("MUS_DIGER_TELEFON", birDogrulamaDetayTx.getDigerTelefon());
					oMap.put("MUS_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
					oMap.put("MUS_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
					oMap.put("MUS_GORUSULEN_TELEFON", birDogrulamaDetayTx.getGorusulenTelefon());
					oMap.put("DIGER_TELEFON_KAYNAK", birDogrulamaDetayTx.getDigerTelefonKaynak());
				}

				// Musteri Web Dogrulama
				birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", DogrulamaTipKodu.MF.name())).uniqueResult();

				if (birDogrulamaDetayTx != null) {
					oMap.put("MF_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
					oMap.put("MF_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
				}
				else {
					oMap.put("MF_DOGRULAMA_KOD", oMap.get("MUS_DOGRULAMA_KOD"));
				}

				// Musteri Web Dogrulama
				birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", DogrulamaTipKodu.MW.name())).uniqueResult();

				/*
				if(birDogrulamaDetayTx != null) {
					oMap.put("MW_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
					oMap.put("MW_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
				}
				*/

				// Musteri Web Dogrulama
				birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", DogrulamaTipKodu.K1F.name())).uniqueResult();

				if (birDogrulamaDetayTx != null) {
					oMap.put("K1F_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
					oMap.put("K1F_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
				}

				// Musteri Web Dogrulama
				birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", DogrulamaTipKodu.K2F.name())).uniqueResult();

				if (birDogrulamaDetayTx != null) {
					oMap.put("K2F_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
					oMap.put("K2F_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
				}

				// Musteri Isyeri Dogrulama
				birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", "MI")).uniqueResult();
				if (birDogrulamaDetayTx != null) {
					oMap.put("MUS_ISYERI_ACIKLAMA", birDogrulamaDetayTx.getAciklama());
					oMap.put("MUS_ISYERI_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
					oMap.put("MUS_ISYERI_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
					oMap.put("MUS_ISYERI_GORUSULEN_ISIM", birDogrulamaDetayTx.getGorusulenIsim());
					oMap.put("MUS_ISYERI_GORUSULEN_UNVAN", birDogrulamaDetayTx.getGorusulenUnvan());
					oMap.put("MUS_ISYERI_YENI_CALISMA_SEKLI_KOD", birDogrulamaDetayTx.getYeniCalismaSekliKod());
					oMap.put("MUS_ISYERI_YENI_IS_ADRES", birDogrulamaDetayTx.getYeniIsAdres());
					oMap.put("MUS_ISYERI_YENI_ISYERI_ADI", birDogrulamaDetayTx.getYeniIsyeriAdi());
					String calismaSuresi = birDogrulamaDetayTx.getYeniIsyerindeCalismaSuresi();
					if (calismaSuresi != null) {
						oMap.put("MUS_ISYERI_YENI_YIL", calismaSuresi.substring(0, 2));
						oMap.put("MUS_ISYERI_YENI_AY", calismaSuresi.substring(2, 4));
					}
					oMap.put("MUS_ISYERI_YENI_MESLEK_KOD", birDogrulamaDetayTx.getYeniMeslekKod());
					oMap.put("MUS_ISYERI_YENI_UNVAN", birDogrulamaDetayTx.getYeniUnvan());
					oMap.put("MUS_YENI_ISYERINDE_FAAL_KONU_KOD", birDogrulamaDetayTx.getYeniIsyeriFaalKonuKod());
					oMap.put("MUS_YENI_GELIR", birDogrulamaDetayTx.getYeniGelir());
					oMap.put("MUS_WEB_DOGRULAMA_KOD", birDogrulamaDetayTx.getWebDogrulamaSebepKod());
				}

				// Kefil 1 Dogrulama
				birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", "K1I")).uniqueResult();
				if (birDogrulamaDetayTx != null) {
					oMap.put("K1_ISYERI_ACIKLAMA", birDogrulamaDetayTx.getAciklama());
					oMap.put("K1_ISYERI_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
					oMap.put("K1_ISYERI_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
					oMap.put("K1_ISYERI_GORUSULEN_ISIM", birDogrulamaDetayTx.getGorusulenIsim());
					oMap.put("K1_ISYERI_GORUSULEN_UNVAN", birDogrulamaDetayTx.getGorusulenUnvan());
					oMap.put("K1_ISYERI_YENI_CALISMA_SEKLI_KOD", birDogrulamaDetayTx.getYeniCalismaSekliKod());
					oMap.put("K1_ISYERI_YENI_IS_ADRES", birDogrulamaDetayTx.getYeniIsAdres());
					oMap.put("K1_ISYERI_YENI_ISYERI_ADI", birDogrulamaDetayTx.getYeniIsyeriAdi());
					String calismaSuresi = birDogrulamaDetayTx.getYeniIsyerindeCalismaSuresi();
					if (calismaSuresi != null) {
						oMap.put("K1_ISYERI_YENI_YIL", calismaSuresi.substring(0, 2));
						oMap.put("K1_ISYERI_YENI_AY", calismaSuresi.substring(2, 4));
					}
					oMap.put("K1_ISYERI_YENI_MESLEK_KOD", birDogrulamaDetayTx.getYeniMeslekKod());
					oMap.put("K1_ISYERI_YENI_UNVAN", birDogrulamaDetayTx.getYeniUnvan());
					oMap.put("K1_YENI_ISYERINDE_FAAL_KONU_KOD", birDogrulamaDetayTx.getYeniIsyeriFaalKonuKod());
					oMap.put("K1_YENI_GELIR", birDogrulamaDetayTx.getYeniGelir());
					oMap.put("K1_WEB_DOGRULAMA_KOD", birDogrulamaDetayTx.getWebDogrulamaSebepKod());
					oMap.put("K1_NO", birDogrulamaDetayTx.getKefilNo());
				}

				// Kefil 2 Dogrulama
				birDogrulamaDetayTx = (BirDogrulamaDetayTx) session.createCriteria(BirDogrulamaDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.dogrulamaTipKod", "K2I")).uniqueResult();
				if (birDogrulamaDetayTx != null) {
					oMap.put("K2_ISYERI_ACIKLAMA", birDogrulamaDetayTx.getAciklama());
					oMap.put("K2_ISYERI_DOGRULAMA_KOD", birDogrulamaDetayTx.getDogrulamaKod());
					oMap.put("K2_ISYERI_DOGRULAMA_SEBEP_KOD", birDogrulamaDetayTx.getDogrulamaSebepKod());
					oMap.put("K2_ISYERI_GORUSULEN_ISIM", birDogrulamaDetayTx.getGorusulenIsim());
					oMap.put("K2_ISYERI_GORUSULEN_UNVAN", birDogrulamaDetayTx.getGorusulenUnvan());
					oMap.put("K2_ISYERI_YENI_CALISMA_SEKLI_KOD", birDogrulamaDetayTx.getYeniCalismaSekliKod());
					oMap.put("K2_ISYERI_YENI_IS_ADRES", birDogrulamaDetayTx.getYeniIsAdres());
					oMap.put("K2_ISYERI_YENI_ISYERI_ADI", birDogrulamaDetayTx.getYeniIsyeriAdi());
					String calismaSuresi = birDogrulamaDetayTx.getYeniIsyerindeCalismaSuresi();
					if (calismaSuresi != null) {
						oMap.put("K2_ISYERI_YENI_YIL", calismaSuresi.substring(0, 2));
						oMap.put("K2_ISYERI_YENI_AY", calismaSuresi.substring(2, 4));
					}
					oMap.put("K2_ISYERI_YENI_MESLEK_KOD", birDogrulamaDetayTx.getYeniMeslekKod());
					oMap.put("K2_ISYERI_YENI_UNVAN", birDogrulamaDetayTx.getYeniUnvan());
					oMap.put("K2_YENI_ISYERINDE_FAAL_KONU_KOD", birDogrulamaDetayTx.getYeniIsyeriFaalKonuKod());
					oMap.put("K2_YENI_GELIR", birDogrulamaDetayTx.getYeniGelir());
					oMap.put("K2_WEB_DOGRULAMA_KOD", birDogrulamaDetayTx.getWebDogrulamaSebepKod());
					oMap.put("K2_NO", birDogrulamaDetayTx.getKefilNo());
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3180_TUMUNE_ATA")
	public static GMMap tumuneAtaGel(GMMap iMap) {
		String tableName = "TABLE_DATA";
		int rowCount = iMap.getSize(tableName);
		for (int i = 0; i < rowCount; i++) {
			iMap.put(tableName, i, iMap.getString("COLUMN_NAME"), iMap.getString("VALUE"));
		}
		return iMap;
	}

	public static void updateBirBasvuru(BigDecimal basvuruNo, String durumKodu, String aksiyonKodu, String aksiyonKararKodu) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call Pkg_Basvuru.BasvuruStatuUpdate(?,?,?,?)}");
			stmt.setBigDecimal(1, basvuruNo);
			stmt.setString(2, durumKodu);
			stmt.setString(3, aksiyonKodu);
			stmt.setString(4, aksiyonKararKodu);

			stmt.execute();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static String[] splitDateAndTime(java.util.Date date) {
		String[] tarihSaat = date == null ? new String[] { "", "" } : dateFormat.format(date).split(" ");
		return tarihSaat;
	}

	public static java.util.Date concatDateAndTime(String date, String time) {
		try {
			return dateFormat.parse((date == null ? "00000000" : date) + " " + (time == null ? "000000" : time));
		}
		catch (Exception e) {
			e.printStackTrace();
			return null; // akis devam etsin diye
		}
	}

	public static BigDecimal getIdNo(BigDecimal basvuruNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3180.ID_No_Al(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, basvuruNo);
			stmt.execute();

			return stmt.getBigDecimal(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	// @GraymoundService("BNSPR_TRN3180_WEB_LINK")
	// public static GMMap getWebLink(GMMap iMap){
	// try {
	// GMMap oMap = new GMMap();
	// iMap.put("PARAMETRE", "SSK_TCKN_LINK");
	// oMap.put("SSK_TCKN_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));
	//
	// iMap.put("PARAMETRE", "EMEK_SAN_TCKN_LINK");
	// oMap.put("EMEK_SAN_TCKN_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));
	//
	// iMap.put("PARAMETRE", "E_VERGI_LINK");
	// oMap.put("E_VERGI_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));
	//
	// iMap.put("PARAMETRE", "TC_SANAYI_ODASI_LINK");
	// oMap.put("TC_SANAYI_ODASI_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));
	//
	// iMap.put("PARAMETRE", "BAGKUR_BORC_BILGISI_LINK");
	// oMap.put("BAGKUR_BORC_BILGISI_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));
	//
	// iMap.put("PARAMETRE", "SSK_EMEKLI_1_LINK");
	// oMap.put("SSK_EMEKLI_1_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));
	//
	// iMap.put("PARAMETRE", "SSK_EMEKLI_2_LINK");
	// oMap.put("SSK_EMEKLI_2_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));
	//
	// iMap.put("PARAMETRE", "ES_EMEKLI_LINK");
	// oMap.put("ES_EMEKLI_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));
	//
	// iMap.put("PARAMETRE", "BAGKUR_EMEKLI_TCKN_LINK");
	// oMap.put("BAGKUR_EMEKLI_TCKN_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));
	//
	// iMap.put("PARAMETRE", "SGK_MAAS_SORGULAMA_LINK");
	// oMap.put("SGK_MAAS_SORGULAMA_LINK", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER"));
	//
	// return oMap;
	// } catch (Exception e) {
	// throw ExceptionHandler.convertException(e);
	// }
	// }

	@GraymoundService("BNSPR_TRN3180_GET_DISTRIBUTOR_LIST")
	public static GMMap getDistributorList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			GMMap oMap = new GMMap();

			// Distributor Tablosu

			if (iMap.getBigDecimal("SATICI_KOD") != null) {
				conn = DALUtil.getGMConnection();

				stmt = conn.prepareCall("{? = call pkg_trn3174.RC_QRY3174_GET_DISTRIBUTOR(?)}");
				stmt.registerOutParameter(1, -10);
				stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KOD"));

				stmt.execute();

				rSet = (ResultSet) stmt.getObject(1);

				String tableName = "DISTRIBUTOR";
				int row = 0;
				while (rSet.next()) {
					oMap.put(tableName, row, "KOD", rSet.getBigDecimal(1));
					oMap.put(tableName, row, "SATICI_ADI", rSet.getString(2));
					row++;
				}

				Session session = DAOSession.getSession("BNSPRDal");

				iMap.put("FAALIYET_KONULARI", GMServiceExecuter.execute("BNSPR_TRN3162_GET_FAALIYET_KONULARI", iMap).get("FAALIYET_KONULARI"));
				List<?> saticiTahsisFaaliyetList = (List<?>) iMap.get("FAALIYET_KONULARI");

				tableName = "FAALIYET_KONULARI";
				row = 0;
				for (int i = 0; i < saticiTahsisFaaliyetList.size(); i++) {
					BirSaticiTahsisFaaliyet birSaticiTahsisFaaliyet = (BirSaticiTahsisFaaliyet) session.createCriteria(BirSaticiTahsisFaaliyet.class).add(Restrictions.eq("id.saticiKod", iMap.getBigDecimal("SATICI_KOD"))).add(Restrictions.eq("id.faaliyetKodu", iMap.getString(tableName, i, "FAALIYET_KODU"))).add(Restrictions.eq("id.tur", "X")).uniqueResult();

					if (birSaticiTahsisFaaliyet != null) {
						oMap.put(tableName, row, "SEC", true);
						oMap.put(tableName, row, "FAALIYET_KONUSU", iMap.getString(tableName, i, "FAALIYET_KONUSU"));
						row++;
					}

				}
			}

			// Distributor Tablosu Sonu

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3180_WEB_BILGILERI_GETIR")
	public static GMMap getWebBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3180_ESGM_SORGU", iMap));
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_ESGM_SORGU")
	public static GMMap getApplicationCaptcha(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BirBasvuruKimlik basvuruKimlik = iMap.getBigDecimal("BASVURU_NO") == null ? null : (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, iMap.getBigDecimal("BASVURU_NO"));

			conn = DALUtil.getGMConnection();

			if (basvuruKimlik != null) {
				GMMap tMap = new GMMap();

				tMap.put("ANSWER", iMap.getString("GUVENLIK_KODU"));

				tMap.put("TCKN", basvuruKimlik.getTcKimlikNo());
				tMap.put("IL_KODU", basvuruKimlik.getNufusIlKod());
				tMap.put("DOGUM_YILI", new SimpleDateFormat("yyyy").format(basvuruKimlik.getDogumTar()));
				tMap.put("CILT_NO", basvuruKimlik.getCiltNo());
				tMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				tMap.put("CAPTCHA", iMap.getString("CAPTCHA"));
				oMap.putAll(GMServiceExecuter.call("BNSPR_EXT_ESGMSGK_SOLVE_CAPTCHA", tMap));

				if (oMap.getString("RESPONSE").equals("0")) {
					oMap.put("RESPONSE", 0);
					oMap.put("RESPONSE_DATA", GMMessageFactory.getMessage("ADCWEBCAPT", null));

					return oMap;
				}

				ADCSession.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
				GMServiceExecuter.call("BNSPR_EXT_ESGMSGK_PARSE", tMap);

				stmt = conn.prepareCall("{? = call PKG_NBSM_3APPL.ESGM_DOGRULAMA_DEGER('VerAppWebSystemF',?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

				stmt.execute();

				if (stmt.getString(1).equals("Y")) {
					if ("DOGRULAMA".equals(iMap.getString("EKRAN"))) {
						iMap.put("HATA_NO", new BigDecimal(2580));
						iMap.put("MESSAGE_NO", new BigDecimal(2580));
					}
					else {
						iMap.put("HATA_NO", new BigDecimal(2828));
						iMap.put("MESSAGE_NO", new BigDecimal(2828));
					}
					if ("N".equals(iMap.getString("RAISE_ERROR"))) {
						System.out.println((String) GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));
					}
					else {
						throw new GMRuntimeException(0, (String) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap).get("ERROR_MESSAGE"));
					}
				}

				ADCSession.remove("BASVURU_NO");
			}

			oMap.put("RESPONSE", 2);
			oMap.put("RESPONSE_DATA", "");

		}
		catch (Exception e) {
			if ("N".equals(iMap.getString("RAISE_ERROR"))) {
				System.out.println(e.getMessage());
			}
			else {
				throw ExceptionHandler.convertException(e);
			}
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_DETAY_KIMLIK_NUFUS")
	public static GMMap kimlikNufus(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{ ? = call PKG_TRN3180.rc_trn3180_detay_kimlik_nufus(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			if (rSet.next()) {
				oMap.put("KIMLIK_SERI_NO", rSet.getObject("KIMLIK_SERI_NO"));
				oMap.put("KIMLIK_SERI_NO_KPS", rSet.getObject("KIMLIK_SERI_NO_KPS"));
				oMap.put("KIMLIK_SIRA_NO", rSet.getObject("KIMLIK_SIRA_NO"));
				oMap.put("KIMLIK_SIRA_NO_KPS", rSet.getObject("KIMLIK_SIRA_NO_KPS"));
				oMap.put("NUFUS_VER_TAR", rSet.getObject("NUFUS_VER_TAR"));
				oMap.put("NUFUS_VER_YER", rSet.getObject("NUFUS_VER_YER"));
				oMap.put("NUFUS_VER_NEDENI", rSet.getObject("NUFUS_VER_NEDENI"));
				oMap.put("ANNE_KIZLIK_SOYADI", rSet.getObject("ANNE_KIZLIK"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_DYN_PAGE_NAME")
	public static GMMap dynPageName(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{ ? = call PKG_TRN3180.dogrulanacak_ekran(?) }");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			String ekranTipi = stmt.getString(1);
			if (StringUtils.isNotBlank(ekranTipi)) {
				oMap.put("DYN_PAGE", "BNSPR_TRN3180_Dyn-" + ekranTipi + ".guiml"); // KKB_KISI KKB_KEFIL ARAC
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_COMBO_MODELS")
	public static GMMap getComboModels(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("TABLE_NAME", "ISYERI_FAAL_KONU_KOD");
			iMap.put("KOD", "ISYERI_FAAL_KONU_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			iMap.put("TABLE_NAME", "DOGRULAMA_SONUCU");
			iMap.put("KOD", "BAS_DOGRULAMA_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			iMap.put("TABLE_NAME", "RANDEVU_MU");
			iMap.put("KOD", "EVET_HAYIR");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			iMap.put("TABLE_NAME", "DOGRULAMA_NEDENI");
			iMap.put("KOD", "3180_DOGRULAMA_NEDENI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			iMap.put("TABLE_NAME", "TESLIM_NEDENI");
			iMap.put("KOD", "3180_TESLIM_NEDENI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			iMap.put("TABLE_NAME", "ADRES_FARKLI_OLMA_NEDENI");
			iMap.put("KOD", "3180_ADRES_FARKLI_OLMA_NEDENI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			iMap.put("TABLE_NAME", "URUN_BASKASINA_MI");
			iMap.put("KOD", "EVET_HAYIR");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			iMap.put("TABLE_NAME", "URUN_KIME_ALINIYOR");
			iMap.put("KOD", "3180_URUN_KIME_ALINIYOR");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			String listName = "CAPRAZ_VE_KARA_LISTE_DURUM";

			GuimlUtil.wrapMyCombo(oMap, listName, "X", " ");
			GuimlUtil.wrapMyCombo(oMap, listName, "B", "Benzer");
			GuimlUtil.wrapMyCombo(oMap, listName, "K", "Kesin");
			GuimlUtil.wrapMyCombo(oMap, listName, "Y", "Yok");
			GuimlUtil.wrapMyCombo(oMap, listName, "Z", "Kesin-Fraud Yok");

			iMap.put("TABLE_NAME", "FRAUD_KARAR");
			iMap.put("KOD", "FRAUD_SONUC_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			iMap.put("TABLE_NAME", "FRAUD_KAYNAK_KOD");
			iMap.put("KOD", "FRAUD_KAYNAK");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			listName = "FRAUD_KARARSIZ";
			DALUtil.fillComboBox(oMap, listName, true, "SELECT KEY1, TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = 'FRAUD_SONUC_KOD' and key1 <>'2' ORDER BY SIRA_NO");

			iMap.put("TABLE_NAME", "KARA_LISTE_KAYNAK_KOD");
			iMap.put("KOD", "KARA_LISTE_KAYNAK_KOD");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			iMap.put("TABLE_NAME", "URUN_KARAR");
			iMap.put("KOD", "BAS_URUN_DOG_SONUC");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			listName = "ISYERI_KARAR";
			GuimlUtil.wrapMyCombo(oMap, listName, "KABUL", "Kabul");
			GuimlUtil.wrapMyCombo(oMap, listName, "RED", "Red");

			iMap.put("TABLE_NAME", "MOBIL_URUN_MU");
			iMap.put("KOD", "EVET_HAYIR");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			listName = "GEC_TESLIM_NEDENI";
			DALUtil.fillComboBox(oMap, listName, true, "SELECT KEY1, TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KEY3 = 'G' and KOD='3180_TESLIM_NEDENI'");

			iMap.put("TABLE_NAME", "ERKEN_TESLIM_NEDENI");
			iMap.put("KOD", "3180_TESLIM_NEDENI");
			iMap.put("KEY2", "E");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_3180_KKB_SORGU_KK_KMH")
	public static GMMap sorguKKKmh(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{ ? = call PKG_TRN3180.RC_TRN3180_KKB_SORGU_KK_KMH(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, "TABLE_DATA"));

			oMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_3180_KKB_SORGU_KAYIT_ACIK_MI", oMap));
			oMap.put("RESPONSE", 1);
		}
		catch (Exception e) {
			oMap.put("RESPONSE", 0);
			oMap.put("MESSAGE", e.getMessage());
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_3180_KKB_SORGU_KREDI")
	public static GMMap sorguKKKredi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{ ? = call PKG_TRN3180.RC_TRN3180_KKB_SORGU_KREDI(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "TABLE_DATA"));

			oMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_3180_KKB_SORGU_KAYIT_ACIK_MI", oMap));
			oMap.put("RESPONSE", 1);
		}
		catch (Exception e) {
			oMap.put("RESPONSE", 0);
			oMap.put("MESSAGE", e.getMessage());
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_3180_KKB_SORGU_KEFIL")
	public static GMMap sorguKkbKefil(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{ ? = call PKG_TRN3180.RC_TRN3180_KKB_SORGU_KEFIL(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, "TABLE_DATA"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_3180_KKB_SORGU_KAYIT_ACIK_MI")
	public static GMMap sorguKkbKayitAcikMi(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmtGetMaxSorguNo = null;
		CallableStatement stmtGetAcikKapli = null;
		ResultSet rSet = null;
		try {
			String tableName = "TABLE_DATA";

			conn = DALUtil.getGMConnection();

			stmtGetMaxSorguNo = conn.prepareStatement("SELECT MAX (sorgu_no) SORGU_NO FROM kkb_sorgu_islem WHERE basvuru_no = ?");
			stmtGetAcikKapli = conn.prepareCall("{ ? = call pkg_nbsm_5kkb.acik_kapali(?,?,?) }");

			stmtGetAcikKapli.registerOutParameter(1, Types.VARCHAR);

			stmtGetMaxSorguNo.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			rSet = stmtGetMaxSorguNo.executeQuery();

			rSet.next();
			BigDecimal sorguNo = rSet.getBigDecimal("SORGU_NO");

			GMServerDatasource.close(rSet);

			String kayitNo = "KAYIT_NO";
			String acikMi = "ACIK_MI";
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				stmtGetAcikKapli.setBigDecimal(2, sorguNo);
				stmtGetAcikKapli.setBigDecimal(3, iMap.getBigDecimal(tableName, i, kayitNo));
				stmtGetAcikKapli.setString(4, "XXX"); // bu parametreyi bos gecmeden gonderelim dedik
				stmtGetAcikKapli.execute();

				iMap.put(tableName, i, acikMi, stmtGetAcikKapli.getString(1) != null && stmtGetAcikKapli.getString(1).equals("A") ? true : false);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmtGetMaxSorguNo);
			GMServerDatasource.close(stmtGetAcikKapli);
			GMServerDatasource.close(conn);
		}
		return iMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_ARAC_COMBO_MODELS")
	public static GMMap getAracComboModels(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("TABLE_NAME", "SERH_TIPI");
			iMap.put("KOD", "3180_SERH_TIPI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			iMap.put("TABLE_NAME", "SERH_DURUMU");
			iMap.put("KOD", "3180_SERH_DURUMU");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			String listName = "MARKA";
			DALUtil.fillComboBox(oMap, listName, true, "SELECT kod, aciklama FROM BNSPR.BIR_MARKA_PR WHERE BIR_KRD_TUR = 3 and drm = 'G' order by aciklama asc");

			if (oMap.getSize(listName) > 0) {
				oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3180_GET_ARAC_MARKA_MODEL", iMap.put("MODEL", oMap.getString(listName, 0, "VALUE"))));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_ARAC_MARKA_MODEL")
	public static GMMap getMarkaModels(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String listName = "MODEL";
			DALUtil.fillComboBox(oMap, listName, true, "SELECT kod, aciklama FROM BNSPR.BIR_MARKA_MODEL_PR WHERE BIR_KRD_TUR = 3 and drm = 'G' and marka_kod = '" + iMap.getString("MARKA") + "'  order by aciklama asc");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_WEB_COMBO_MODELS")
	public static GMMap getWebComboModels(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3171_GET_CALISMA_SEKILLERI", iMap));

			iMap.put("TABLE_NAME", "IL");
			iMap.put("LOV", "3271/LOV_IL_KOD");
			iMap.put("VALUE", "KOD");
			iMap.put("NAME", "IL_ADI");
			iMap.put("ADD_EMPTY_KEY", true);

			oMap.putAll(GMServiceExecuter.call("BNSPR_TRN3271_GET_COMBO_PARAMETERS_BY_LOV", iMap));

			iMap.put("TABLE_NAME", "DOGRULA");
			iMap.put("KOD", "BAS_DOG_SONUC");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

			oMap.put("LIST_NAME", "ISYERI_IL");
			oMap.put("ADD_EMPTY_KEY", true);
			oMap.put("LIST_QUERY", "SELECT kod, (CASE WHEN kod >= '100' THEN kod||'-'||il_adi ELSE SUBSTR (kod,2)||'-'||il_adi END) il_adi FROM gnl_il_kod_pr ORDER BY kod");
			DALUtil.fillComboBox(oMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_CONVERT_STRING_TO_COMBO")
	public static GMMap fillComboViaString(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String[] values = iMap.getString("VALUES").split(";");
			String[] names = iMap.getString("NAMES").split(";");
			boolean contolNull = iMap.getBoolean("ALLOW_NULL");

			String listName = "RESULT";
			for (int i = 0; i < names.length; i++) {
				oMap.put(listName, i, "NAME", names[i]);
				oMap.put(listName, i, "VALUE", contolNull && values[i].equals("") ? null : values[i]);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_ESGM_SORGU_SONUC")
	public static GMMap esgmSorguSonuc(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{ ? = call PKG_TRN3180.rc_trn3180_esgm_sorgu(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, "TABLE_DATA"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_WEB_DOG_DYN_DATA")
	public static GMMap getWebDogData(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			boolean ucretli = false;
			boolean kamu = false;
			boolean serbestMeslek = false;
			boolean emekli = false;

			if (StringUtils.isNotBlank(iMap.getString("MW/SSK_SON_PRIM_TARIHI")) || StringUtils.isNotBlank(iMap.getString("MW/SSK_CALISMA_SURESI")) || StringUtils.isNotBlank(iMap.getString("MW/SSK_PRIM_TUTARI")) || StringUtils.isNotBlank(iMap.getString("MW/SSK_BASLANGIC_TARIHI")) || StringUtils.isNotBlank(iMap.getString("MW/SSK_TESPIT")) || StringUtils.isNotBlank(iMap.getString("MW/SSK_ISYERI_ILI"))) {
				ucretli = true;
			}

			if (StringUtils.isNotBlank(iMap.getString("MW/KAMU_CALISMA_DURUMU")) && iMap.getString("MW/KAMU_CALISMA_DURUMU").equals("AKT\u0130F")) {
				kamu = true;
			}

			if (StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_CALISMA_DURUMU")) || StringUtils.isNotBlank(iMap.getString("MW/BAKUR_CALISMA_SURESI")) || StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_ISYERI")) || StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_ISYERI_UYUMLU")) || StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_VERGI_MATRAHI")) || StringUtils.isNotBlank(iMap.getString("MW/SSK_ISYERI_ILI"))) {
				serbestMeslek = true;
			}

			if (StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_AYLIK")) || StringUtils.isNotBlank(iMap.getString("OKE")) || StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_AYLIK_KIMDEN")) || iMap.getBoolean("SSK") || iMap.getBoolean("BAGKUR") || iMap.getBoolean("EMEKLI_SANDIGI") || iMap.getBoolean("OZEL_SANDIK")) {
				emekli = true;
			}

			GMMap tMap = new GMMap();
			tMap.put("KOD", "CALISAN_EMEKLI_TUR");

			if ((ucretli || kamu || serbestMeslek) && emekli) {
				tMap.put("KEY", "CE");
			}
			else if (ucretli) {
				tMap.put("KEY", "CS");
			}
			else if (kamu) {
				tMap.put("KEY", "CES");
			}
			else if (serbestMeslek) {
				tMap.put("KEY", "CB");
			}
			else if (iMap.getBoolean("SSK")) {
				tMap.put("KEY", "ES");
			}
			else if (iMap.getBoolean("EMEKLI_SANDIGI")) {
				tMap.put("KEY", "EK");
			}
			else if (iMap.getBoolean("OZEL_SANDIK")) {
				tMap.put("KEY", "EOS");
			}
			else if (iMap.getBoolean("BAGKUR")) {
				tMap.put("KEY", "EB");
			}

			if (tMap.containsKey("KEY")) {
				oMap.put("MW/CALISAN_EMEKLI_TUR", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", tMap).getString("TEXT"));
			}
			else {
				oMap.put("MW/CALISAN_EMEKLI_TUR", "");
			}

			tMap.remove("KEY");

			if (iMap.getBoolean("SSK")) {
				tMap.put("KEY", "ES");
			}
			else if (iMap.getBoolean("EMEKLI_SANDIGI")) {
				tMap.put("KEY", "EK");
			}
			else if (iMap.getBoolean("OZEL_SANDIK")) {
				tMap.put("KEY", "EOS");
			}
			else if (iMap.getBoolean("BAGKUR")) {
				tMap.put("KEY", "EB");
			}

			if (tMap.containsKey("KEY")) {
				oMap.put("MW/EMEKLI_TUR", GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", tMap).getString("TEXT"));
			}
			else {
				oMap.put("MW/EMEKLI_TUR", "");
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_SET_WEB_DOG_DYN_DATA")
	public static GMMap setWebDogData(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			oMap.put("MW/SSK_CALISMA_SURESI_1", StringUtils.isNotBlank(iMap.getString("MW/SSK_CALISMA_SURESI")) && iMap.getString("MW/SSK_CALISMA_SURESI").equals("1F"));
			oMap.put("MW/SSK_CALISMA_SURESI_2", StringUtils.isNotBlank(iMap.getString("MW/SSK_CALISMA_SURESI")) && iMap.getString("MW/SSK_CALISMA_SURESI").equals("1A"));

			oMap.put("MW/BAGKUR_CALISMA_DURUMU_1", StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_CALISMA_DURUMU")) && iMap.getString("MW/BAGKUR_CALISMA_DURUMU").equals("AKT�F"));
			oMap.put("MW/BAGKUR_CALISMA_DURUMU_2", StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_CALISMA_DURUMU")) && iMap.getString("MW/BAGKUR_CALISMA_DURUMU").equals("KAPALI"));

			oMap.put("MW/BAGKUR_CALISMA_DURUMU_1", StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_CALISMA_DURUMU")) && iMap.getString("MW/BAGKUR_CALISMA_DURUMU").equals("AKT�F"));
			oMap.put("MW/BAGKUR_CALISMA_DURUMU_2", StringUtils.isNotBlank(iMap.getString("MW/BAGKUR_CALISMA_DURUMU")) && iMap.getString("MW/BAGKUR_CALISMA_DURUMU").equals("KAPALI"));

			oMap.put("MW/BAKUR_CALISMA_SURESI_1", StringUtils.isNotBlank(iMap.getString("MW/BAKUR_CALISMA_SURESI")) && iMap.getString("MW/BAKUR_CALISMA_SURESI").equals("1F"));
			oMap.put("MW/BAKUR_CALISMA_SURESI_2", StringUtils.isNotBlank(iMap.getString("MW/BAKUR_CALISMA_SURESI")) && iMap.getString("MW/BAKUR_CALISMA_SURESI").equals("1A"));

			oMap.put("MW/SSK_TESPIT_1", StringUtils.isNotBlank(iMap.getString("MW/SSK_TESPIT")) && iMap.getString("MW/SSK_TESPIT").contains("S�k is degistiriyor"));
			oMap.put("MW/SSK_TESPIT_2", StringUtils.isNotBlank(iMap.getString("MW/SSK_TESPIT")) && iMap.getString("MW/SSK_TESPIT").contains("Duzensiz pirim odemesi var"));

			oMap.put("MW/KAMU_CALISMA_DURUMU", StringUtils.isNotBlank(iMap.getString("MW/KAMU_CALISMA_DURUMU")) && iMap.getString("MW/KAMU_CALISMA_DURUMU").equals("AKT�F"));

			oMap.put("MW/EMEKLI_AYLIK_KIMDEN_1", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_AYLIK_KIMDEN")) && iMap.getString("MW/EMEKLI_AYLIK_KIMDEN").equals("K"));
			oMap.put("MW/EMEKLI_AYLIK_KIMDEN_2", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_AYLIK_KIMDEN")) && iMap.getString("MW/EMEKLI_AYLIK_KIMDEN").equals("A"));
			oMap.put("MW/EMEKLI_AYLIK_KIMDEN_3", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_AYLIK_KIMDEN")) && iMap.getString("MW/EMEKLI_AYLIK_KIMDEN").equals("D"));

			GMMap tMap = new GMMap();
			tMap.put("KOD", "CALISAN_EMEKLI_TUR");
			tMap = GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", tMap);

			String result = "RESULTS";
			for (int i = 0; i < tMap.getSize(result); i++) {
				if (tMap.getString(result, i, "NAME").equals(iMap.getString("MW/EMEKLI_TUR"))) {
					iMap.put("MW/EMEKLI_TUR", tMap.getString(result, i, "VALUE"));
					break;
				}
			}

			oMap.put("MW/EMEKLI_TUR_1", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_TUR")) && iMap.getString("MW/EMEKLI_TUR").equals("ES"));
			oMap.put("MW/EMEKLI_TUR_2", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_TUR")) && iMap.getString("MW/EMEKLI_TUR").equals("EB"));
			oMap.put("MW/EMEKLI_TUR_3", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_TUR")) && iMap.getString("MW/EMEKLI_TUR").equals("EK"));
			oMap.put("MW/EMEKLI_TUR_4", StringUtils.isNotBlank(iMap.getString("MW/EMEKLI_TUR")) && iMap.getString("MW/EMEKLI_TUR").equals("EOS"));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN3180_GET_DOGRULAMA_KODLARI")
	public static GMMap getDogrulamaKodlari(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			// Eger bir alt bilesenden cagriliyorsa ve veriler onceden sessiona kaydedilmis ise (popup tarzi kapanip acilan ekranlar icin bunu if
			// icerisinde kontrol ettigimiz ekrana ozgu bir variable degeri varsa anlayacagiz) onlari dondur:
			if (StringUtils.isNotBlank(iMap.getString("CHECKING_VARIABLE")) && StringUtils.isNotBlank(iMap.getString("TRX_NO"))) {
				Object instance = ADCSession.get("3180_DYN_INS_" + iMap.getString("TRX_NO"));
				String[] keyPair = iMap.getString("CHECKING_VARIABLE").split("/", 2);

				if (instance != null && DogrulamaTipKodu.valueOf(keyPair[0]).contains(instance, keyPair[1])) {
					Map<String, Object> result = DogrulamaTipKodu.getForView(instance);
					oMap.putAll(result);

					return oMap;
				}
			}

			// Eger ana ekran disindaki bir bilesenden cagrilirsa(popup, dynamik part gibi) onceden veriler if altindaki kodlardan alinmis olacagi
			// icin on bellekten verileri al:
			if (iMap.getBoolean("DYN_VIEW")) {
				Map<String, Object> result = (Map<String, Object>) ADCSession.get("3180_VIEW_DYN_INS_" + iMap.getBigDecimal("TRX_NO"));
				oMap.putAll(result);

				return oMap;
			}

			ADCSession.remove("3180_VIEW_DYN_INS_" + iMap.getBigDecimal("TRX_NO"));

			Session session = DAOSession.getSession("BNSPRDal");

			Object instance = DogrulamaTipKodu.getInstance();
			List<?> list;

			if (iMap.getString("ACTION").equals("MESAJ_KUTUSU_CAGIRDI") || iMap.getString("ACTION").equals("BASVURU_IZLE")) {
				list = session.createCriteria(BirDogrulamaKayitTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

				for (BirDogrulamaKayitTx birTx : (List<BirDogrulamaKayitTx>) list) {
					DogrulamaTipKodu.valueOf(birTx.getId().getDogrulamaTipKod()).addItem(instance, birTx.getId().getDogrulamaParam(), birTx.getDogrulamaDeger());
				}
			}
			else {
				list = session.createCriteria(BirDogrulamaKayit.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();

				for (BirDogrulamaKayit bir : (List<BirDogrulamaKayit>) list) {
					DogrulamaTipKodu.valueOf(bir.getId().getDogrulamaTipKod()).addItem(instance, bir.getId().getDogrulamaParam(), bir.getDogrulamaDeger());
				}
			}

			Map<String, Object> result = DogrulamaTipKodu.getForView(instance);
			ADCSession.put("3180_VIEW_DYN_INS_" + iMap.getBigDecimal("TRX_NO"), result);

			oMap.putAll(result);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			if (StringUtils.isNotBlank(iMap.getString("FINALIZING_SERVICE"))) {
				oMap.putAll(GMServiceExecuter.call(iMap.getString("FINALIZING_SERVICE"), oMap));
			}
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_CREATE_DYN_INS")
	public static GMMap getDynIns(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Object instance = ADCSession.get("3180_DYN_INS_" + iMap.getBigDecimal("TRX_NO"));

			if (StringUtils.isNotBlank(iMap.getString("PREPARING_SERVICE"))) {
				iMap.putAll(GMServiceExecuter.call(iMap.getString("PREPARING_SERVICE"), iMap));
			}

			if (instance == null)
				instance = DogrulamaTipKodu.getInstance();

			String key;
			for (Object str : iMap.keySet()) {
				key = (String) str;

				String[] tmp = key.split("/", 2);
				if (tmp.length == 2) {
					DogrulamaTipKodu.valueOf(tmp[0]).addItem(instance, tmp[1], StringUtils.isBlank(iMap.getString(key)) ? null : iMap.getString(key));
				}
			}

			ADCSession.put("3180_DYN_INS_" + iMap.getBigDecimal("TRX_NO"), instance);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@SuppressWarnings("unchecked")
	enum DogrulamaTipKodu {
		MF, M, MI, MW, K1I, K2I, DS, KRD, KK, A, K1F, K2F;

		static Map<DogrulamaTipKodu, Map<String, Object>> actionList = getInstance();
		static {
			DogrulamaTipKodu.DS.addItem(actionList, "KIMLIK_DOGRULAMA_NF_VER_TAR", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KIMLIK_DOGRULAMA_NF_VER_YER", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KIMLIK_DOGRULAMA_NF_VER_NEDEN", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KRD_DOGRULAMA_ACIK", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KRD_DOGRULAMA_KAPALI", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KK_DOGRULAMA_ACIK", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KK_DOGRULAMA_KAPALI", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "ARAC_DOGRULAMA", "Boolean");
			// DogrulamaTipKodu.DS.addItem(actionList, "URUN_BASKASINA_MI", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KKB_ADRES_DOGRULAMA", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KKB_AKS_DOGRULAMA", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KKB_AKS_DOGRULAMA", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KKB_CEPTEL_DOGRULAMA", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KKB_EVTEL_DOGRULAMA", "Boolean");
			DogrulamaTipKodu.DS.addItem(actionList, "KKB_ISTEL_DOGRULAMA", "Boolean");

			// DogrulamaTipKodu.M.addItem(actionList, "ADRES_FARKLI_MI", "Boolean");
			DogrulamaTipKodu.M.addItem(actionList, "DETAY_PAYLASILMADI", "Boolean");
			// DogrulamaTipKodu.M.addItem(actionList, "URUN_BASKASINA_MI", "Boolean");
			DogrulamaTipKodu.M.addItem(actionList, "TESLIMAT_TARIH", "Date");

			DogrulamaTipKodu.MW.addItem(actionList, "MANUEL_WEB_DOGRULAMA_YOK", "Boolean");
			DogrulamaTipKodu.MW.addItem(actionList, "CALISAN_EMEKLI_KAYIT_YOK", "Boolean");
			DogrulamaTipKodu.MW.addItem(actionList, "BAGKUR_ISYERI_UYUMLU", "Boolean");
			DogrulamaTipKodu.MW.addItem(actionList, "SSK_SON_PRIM_TARIHI", "Date");
			DogrulamaTipKodu.MW.addItem(actionList, "SSK_BASLANGIC_TARIHI", "Date");
			DogrulamaTipKodu.MW.addItem(actionList, "BAGKUR_ISYERI_ADI_UYUMLU", "Boolean");
		};

		@Override
		public String toString() {
			return this.name();
		};

		public static Map<DogrulamaTipKodu, Map<String, Object>> getInstance() {
			Map<DogrulamaTipKodu, Map<String, Object>> map = new HashMap<DogrulamaTipKodu, Map<String, Object>>();

			for (DogrulamaTipKodu tip : DogrulamaTipKodu.values()) {
				map.put(tip, new HashMap<String, Object>());
			}
			return map;
		}

		public void addItem(Object instance, String key, Object value) {
			Map<String, Object> map = ((Map<DogrulamaTipKodu, Map<String, Object>>) instance).get(this);
			map.put(key, value == null ? "" : value.toString());
		}

		public boolean contains(Object instance, String key) {
			Map<String, Object> map = ((Map<DogrulamaTipKodu, Map<String, Object>>) instance).get(this);
			return map.containsKey(key);
		}

		public Object getValue(Object instance, String key) {
			Map<DogrulamaTipKodu, Map<String, Object>> source = (Map<DogrulamaTipKodu, Map<String, Object>>) instance;
			return source.get(this).get(key);
		}

		public static String valuesOf(Object instance) {
			Map<DogrulamaTipKodu, Map<String, Object>> map = (Map<DogrulamaTipKodu, Map<String, Object>>) instance;
			Map<String, Object> tmp;
			StringBuilder tmpRTN = new StringBuilder();
			Object value;

			String postfix = "";

			for (DogrulamaTipKodu tip : DogrulamaTipKodu.values()) {
				tmp = map.get(tip);

				for (String key : tmp.keySet()) {
					value = tmp.get(key);
					tmpRTN.append(postfix).append(tip.name()).append("/").append(key).append("=").append(value == null ? "" : value.toString());

					if (postfix.isEmpty()) {
						postfix = "|";
					}
				}
			}

			return tmpRTN.toString();
		}

		public static void putAll(Object sourceInstance, Object targetInstance) {
			if (sourceInstance == null)
				return;

			Map<DogrulamaTipKodu, Map<String, Object>> source = (Map<DogrulamaTipKodu, Map<String, Object>>) sourceInstance;
			Map<DogrulamaTipKodu, Map<String, Object>> target = (Map<DogrulamaTipKodu, Map<String, Object>>) targetInstance;
			Map<String, Object> tempSRC;
			Map<String, Object> tempDES;

			for (DogrulamaTipKodu tip : source.keySet()) {
				tempSRC = source.get(tip);
				tempDES = target.get(tip);

				tempDES.putAll(tempSRC);
			}
		}

		public static Map<String, Object> getForView(Object instance) throws ParseException {
			Map<DogrulamaTipKodu, Map<String, Object>> source = (Map<DogrulamaTipKodu, Map<String, Object>>) instance;
			Map<String, Object> returnData = new HashMap<String, Object>();
			Map<String, Object> tmp, tmp2;
			String type;
			boolean isBlank;
			String value;

			for (DogrulamaTipKodu tip : actionList.keySet()) { // Varsayilan degerler
				tmp = actionList.get(tip);
				for (String str : tmp.keySet()) {
					type = (String) tmp.get(str);
					if (type.equals("Boolean")) {
						returnData.put(tip + "/" + str + "_0", true);
						returnData.put(tip + "/" + str + "_1", false);
						returnData.put(tip + "/" + str + "_2", false);
					}
				}
			}

			for (DogrulamaTipKodu tip : source.keySet()) {
				tmp = source.get(tip);
				for (String tmpKEY : tmp.keySet()) {
					tmp2 = actionList.get(tip);
					type = (String) tmp2.get(tmpKEY);
					value = tmp.get(tmpKEY).toString();
					isBlank = StringUtils.isBlank(value);

					if (type != null && type.equals("Boolean")) {
						returnData.put(tip + "/" + tmpKEY + "_0", isBlank);
						returnData.put(tip + "/" + tmpKEY + "_1", !isBlank && value.equals("Y"));
						returnData.put(tip + "/" + tmpKEY + "_2", !isBlank && value.equals("N"));
					}
					else if (type != null && type.equals("Date") && !isBlank) {
						try {
							returnData.put(tip + "/" + tmpKEY, simpleDateFormat.parse(value));
						}
						catch (Exception e) {
							try {
								returnData.put(tip + "/" + tmpKEY, simpleDateFormat2.parse(value));
							}
							catch (Exception e1) {
								returnData.put(tip + "/" + tmpKEY, null);
							}
						}
					}
					else {
						returnData.put(tip + "/" + tmpKEY, value);
					}
				}
			}

			return returnData;
		}
	}

	@GraymoundService("BNSPR_TRN3180_GET_KKB_BILGI")
	public static GMMap getKkbBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyyMMdd");
		SimpleDateFormat sdf3 = new SimpleDateFormat("dd/MM/yyyy");
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{ ? = call pkg_trn3180.rc_trn3180_kkb_dog_kkb_bilgi(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			String tableName = "KKB_BILGI";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "SORGU_NO", rSet.getObject("SORGU_NO"));
				oMap.put(tableName, row, "SIRA_NO", rSet.getObject("SIRA_NO"));
				oMap.put(tableName, row, "SIRALAMA", rSet.getObject("SIRALAMA"));
				oMap.put(tableName, row, "KAYIT_TURU", rSet.getObject("KAYIT_TURU"));
				oMap.put(tableName, row, "ACILIS_TARIHI", rSet.getObject("ACILIS_TARIHI") == null ? null : sdf.format(sdf2.parse(rSet.getString("ACILIS_TARIHI"))));
				oMap.put(tableName, row, "KAPANIS_TARIHI", rSet.getObject("KAPANIS_TARIHI") == null ? null : sdf.format(sdf3.parse(rSet.getString("KAPANIS_TARIHI"))));
				oMap.put(tableName, row, "LIMIT", rSet.getObject("LIMIT"));
				oMap.put(tableName, row, "RISK", rSet.getObject("RISK"));
				oMap.put(tableName, row, "SOP", rSet.getObject("SOP"));
				oMap.put(tableName, row, "DONEM", rSet.getObject("DONEM"));
				oMap.put(tableName, row, "VADE", rSet.getObject("VADE"));
				oMap.put(tableName, row, "TCKN", rSet.getObject("TCKN"));
				oMap.put(tableName, row, "AD_SOYAD", rSet.getObject("AD_SOYAD"));
				oMap.put(tableName, row, "ANNE_KIZLIK_SOYADI", rSet.getObject("ANNE_KIZLIK_SOYADI"));
				oMap.put(tableName, row, "EV_TEL", rSet.getObject("EV_TEL"));
				oMap.put(tableName, row, "IS_TEL", rSet.getObject("IS_TEL"));
				oMap.put(tableName, row, "CEP_TEL", rSet.getObject("CEP_TEL"));
				oMap.put(tableName, row, "EV_ADRES", rSet.getObject("EV_ADRES"));
				oMap.put(tableName, row, "IS_ADRES", rSet.getObject("IS_ADRES"));
				oMap.put(tableName, row, "KIMLIK_TURU", rSet.getObject("KIMLIK_TURU"));
				oMap.put(tableName, row, "KIMLIK_NO", rSet.getObject("KIMLIK_NO"));
				oMap.put(tableName, row, "DOGUM_TARIHI", rSet.getObject("DOGUM_TARIHI") == null ? null : sdf.format(sdf2.parse(rSet.getString("DOGUM_TARIHI"))));
				oMap.put(tableName, row, "ANNE_AD", rSet.getObject("ANNE_AD"));
				row++;
			}
			stmt.close();

			stmt = conn.prepareCall("{ ? = call pkg_trn3180.rc_trn3180_kkb_dog_basvuru(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				oMap.put("BASVURU_TC_KIMLIK_NO", rSet.getObject("TC_KIMLIK_NO"));
				oMap.put("BASVURU_AD_SOYAD", rSet.getObject("AD_SOYAD"));
				oMap.put("BASVURU_ANNE_KIZLIK_SOYADI", rSet.getObject("ANNE_KIZLIK_SOYADI"));
				oMap.put("BASVURU_EV_TEL", rSet.getObject("EV_TEL"));
				oMap.put("BASVURU_IS_TEL", rSet.getObject("IS_TEL"));
				oMap.put("BASVURU_CEP_TEL", rSet.getObject("CEP_TEL"));
				oMap.put("BASVURU_EV_ADRES", rSet.getObject("EV_ADRES"));
				oMap.put("BASVURU_IS_ADRES", rSet.getObject("IS_ADRES"));
				oMap.put("BASVURU_KIMLIK_TURU", rSet.getObject("KIMLIK_TURU"));
				oMap.put("BASVURU_KIMLIK_NO", rSet.getObject("KIMLIK_NO"));
				oMap.put("BASVURU_DOGUM_TARIHI", rSet.getObject("DOGUM_TARIHI") == null ? null : sdf.format(rSet.getObject("DOGUM_TARIHI")));
				oMap.put("BASVURU_ANNE_AD", rSet.getObject("ANNE_AD"));
			}

			stmt.close();
			stmt = conn.prepareCall("{ ? = call pkg_trn3180.rc_trn3180_kkb_dog_musteri(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				oMap.put("MUSTERI_TC_KIMLIK_NO", rSet.getObject("TC_KIMLIK_NO"));
				oMap.put("MUSTERI_AD_SOYAD", rSet.getObject("AD_SOYAD"));
				oMap.put("MUSTERI_ANNE_KIZLIK_SOYADI", rSet.getObject("ANNE_KIZLIK_SOYADI"));
				oMap.put("MUSTERI_EV_TEL", rSet.getObject("EV_TEL"));
				oMap.put("MUSTERI_IS_TEL", rSet.getObject("IS_TEL"));
				oMap.put("MUSTERI_CEP_TEL", rSet.getObject("CEP_TEL"));
				oMap.put("MUSTERI_EV_ADRES", rSet.getObject("EV_ADRES"));
				oMap.put("MUSTERI_IS_ADRES", rSet.getObject("IS_ADRES"));
				oMap.put("MUSTERI_KIMLIK_TURU", rSet.getObject("KIMLIK_TURU"));
				oMap.put("MUSTERI_KIMLIK_NO", rSet.getObject("KIMLIK_NO"));
				oMap.put("MUSTERI_DOGUM_TARIHI", rSet.getObject("DOGUM_TARIHI") == null ? null : sdf.format(rSet.getObject("DOGUM_TARIHI")));
				oMap.put("MUSTERI_ANNE_AD", rSet.getObject("ANNE_AD"));
				oMap.put("MUSTERI_MUSTERI_NO", rSet.getObject("MUSTERI_NO"));
			}
			stmt.close();

			stmt = conn.prepareCall("{ ? = call pkg_trn3180.rc_trn3180_kkb_dog_aps(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			while (rSet.next()) {
				oMap.put("APS_TC_KIMLIK_NO", rSet.getObject("TC_KIMLIK_NO"));
				oMap.put("APS_AD_SOYAD", rSet.getObject("AD_SOYAD"));
				oMap.put("APS_ANNE_KIZLIK_SOYADI", rSet.getObject("ANNE_KIZLIK_SOYADI"));
				oMap.put("APS_EV_TEL", rSet.getObject("EV_TEL"));
				oMap.put("APS_IS_TEL", rSet.getObject("IS_TEL"));
				oMap.put("APS_CEP_TEL", rSet.getObject("CEP_TEL"));
				oMap.put("APS_EV_ADRES", rSet.getObject("EV_ADRES"));
				oMap.put("APS_IS_ADRES", rSet.getObject("IS_ADRES"));
				oMap.put("APS_KIMLIK_TURU", rSet.getObject("KIMLIK_TURU"));
				oMap.put("APS_KIMLIK_NO", rSet.getObject("KIMLIK_NO"));
				oMap.put("APS_DOGUM_TARIHI", rSet.getObject("DOGUM_TARIHI") == null ? null : sdf.format(rSet.getObject("DOGUM_TARIHI")));
				oMap.put("APS_ANNE_AD", rSet.getObject("ANNE_AD"));
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_BAYI_BILGI")
	public static GMMap getBayiBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{ ? = call PKG_TRN3180.BAYI_BILGI(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			while (rSet.next()) {
				oMap.put("BAYI_TEL", rSet.getString("BAYI_TEL"));
				oMap.put("BAYI_ADI", rSet.getString("BAYI_CALISAN"));
				oMap.put("BAYI_TUTARI", rSet.getBigDecimal("BAYI_TUTARI"));
				oMap.put("ONAY_TUTAR", rSet.getBigDecimal("ONAY_TUTAR"));
				oMap.put("TESLIM_TARIHI", rSet.getDate("TESLIM_TARIHI"));
				oMap.put("BAYI_BULUNDUGU_IL", rSet.getString("BAYI_BULUNDUGU_IL"));
				oMap.put("BAYI_SORUMLU_KISI", rSet.getString("BAYI_SORUMLU_KISI"));
				oMap.put("ISLEMI_YAPAN_KULLANICI", rSet.getString("ISLEMI_YAPAN_KULLANICI"));
				oMap.put("ISLEMI_YAPAN_KULL_ADSOYAD", rSet.getString("ISLEMI_YAPAN_KULL_ADSOYAD"));
			}

			if (!"".equals(iMap.getString("BASVURU_NO"))) {
				Session session = DAOSession.getSession("BNSPRDal");
				BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

				if (birBasvuru.getKanalKodu() != null && birBasvuru.getKanalKodu().compareTo("7") == 0) {
					int i = 1;
					GMServerDatasource.close(stmt);
					stmt = conn.prepareCall("{call PKG_TRN3172.PTT_GET_IL_SUBE_MERKEZ(?,?,?,?,?,?)}"); // PROSEDUR
					stmt.setString(i++, birBasvuru.getPttSubeIli());
					stmt.setString(i++, birBasvuru.getPttIsleminYapildigiSube());
					stmt.setString(i++, birBasvuru.getPttIsleminYapildigiMerkez());

					stmt.registerOutParameter(i++, Types.VARCHAR);
					stmt.registerOutParameter(i++, Types.VARCHAR);
					stmt.registerOutParameter(i++, Types.VARCHAR);
					stmt.execute();

					oMap.put("D_ISLEMIN_YAPILDIGI_IL", stmt.getString(4));
					oMap.put("D_ISLEMIN_YAPILDIGI_SUBE", stmt.getString(5));
					oMap.put("D_ISLEMIN_YAPILDIGI_MERKEZ", stmt.getString(6));

				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_URUN_DOGRULAMA")
	public static GMMap getUrunDogrulama(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{ ? = call PKG_TRN3180.URUN_DOGRULAMA_NEDENLERI(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			int i = 1;
			while (rSet.next()) {
				oMap.put("DOGRULAMA_NEDENI_" + i, rSet.getString("NEDEN_KOD"));
				i++;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_ISYERI_DOGRULAMA")
	public static GMMap getIsyerinDogrulama(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{ ? = call PKG_TRN3180.ISYERI_DOGRULAMA_NEDENI(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			int i = 1;
			while (rSet.next()) {
				oMap.put("DOGRULAMA_NEDENI", rSet.getString("NEDEN_KOD"));
				i++;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_FRAUD_DOGRULAMA")
	public static GMMap getFraudDogrulama(GMMap iMap) {

		GMMap oMap = new GMMap();

		DALUtil.fillComboBox(oMap, "FRAUD_DOGRULAMA_URUN", true, "SELECT KEY1,TEXT FROM GNL_PARAM_TEXT WHERE KOD='BAS_MUSTERI_DOG_SEBEP' AND KEY1<>11 AND KEY2=1");
		return oMap;
	}

	@GraymoundService("BNSPR_TRN_3180_GET_KKB_LINKS")
	public static GMMap getKKBLinks(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rSet = null;
		String query = "SELECT * FROM GNL_PARAM_TEXT WHERE KOD='3180_SORGU_LINK'";
		try {
			conn = DALUtil.getGMConnection();
			pstmt = conn.prepareStatement(query);
			rSet = pstmt.executeQuery();
			int i = 0;
			while (rSet.next()) {
				oMap.put(rSet.getString("KEY1"), rSet.getString("TEXT"));
				i++;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(pstmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_DOGRULAMA_SONUC_NEDEN")
	public static GMMap getDogrulamaSonucNeden(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3180.f_dogrulama_sonuc_neden(?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(2, "MF");
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.VARCHAR);
			stmt.execute();

			oMap.put("MF_DOGRULAMA_SONUC_DEFAULT", stmt.getString(3));
			oMap.put("MF_DOGRULAMA_NEDEN_DEFAULT", stmt.getString(4));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_DEGERLENDIRME_ACIKLAMA_EKLE")
	public static GMMap saveAciklamaEkle(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3180_DEGERLENDIRME_ACIKLAMA_KAYDET", iMap));
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_DEGERLENDIRME_ACIKLAMA_KAYDET")
	public static GMMap saveAciklama(GMMap iMap) {
		GMMap oMap = new GMMap();

		if (iMap.getBigDecimal("BASVURU_NO") == null) {
			iMap.put("HATA_NO", new BigDecimal(660));
			iMap.put("P1", "Basvuru No secilmelidir!");
			return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}

		iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", (GMMap) null).getBigDecimal("TRX_NO"));

		Session session = DAOSession.getSession("BNSPRDal");

		// Degerlendirme aciklamasi
		BirBasvuruDegerlendirmeTx basvuruDegerlendirme = new BirBasvuruDegerlendirmeTx();
		basvuruDegerlendirme.setTxNo(iMap.getBigDecimal("TRX_NO"));
		basvuruDegerlendirme.setIslemTxNo(iMap.getBigDecimal("ISLEM_TRX_NO"));
		basvuruDegerlendirme.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
		basvuruDegerlendirme.setAciklama(iMap.getString("ISLEM_ACIKLAMA"));
		basvuruDegerlendirme.setIslemKod(new BigDecimal(iMap.getString("EKRAN_NO")));

		session.save(basvuruDegerlendirme);
		session.flush();

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_DEGERLENDIRME_ACIKLAMA_VAR_MI")
	public static GMMap degerlendirmeAciklamaVarmi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{ ? = call PKG_TRN3180.DEGERLENDIRME_ACIKLAMA_VAR_MI(?) }");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			String str = stmt.getString(1);
			oMap.put("DEGERLENDIRME_ACIKLAMA_VAR_MI", (str.equals("H")) ? "HAYIR" : "EVET");

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_DEGERLENDIRME_ACIKLAMA_LIST")
	public static GMMap getAciklamaGecmis(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap oMap2 = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			if (iMap.getBigDecimal("BASVURU_NO") == null) {
				iMap.put("HATA_NO", new BigDecimal(660));
				iMap.put("P1", "Basvuru No secilmelidir!");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			oMap2.putAll(GMServiceExecuter.execute("BNSPR_TRN1101_GET_TARIH_AND_KULLANICI", iMap));

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3180.degerlendirme_aciklama_list(?,?)}");

			int parameterIndex = 1;
			stmt.registerOutParameter(parameterIndex++, -10);
			stmt.setBigDecimal(parameterIndex++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(parameterIndex++, oMap2.get("KULLANICI_KOD").toString());
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			DALUtil.fillComboBox(oMap, "ISLEM_ACIKLAMA_GECMISI", false, rSet);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_COMBO_PARAMETERS")
	public static GMMap getComboParameters(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("LIST_NAME", "RESULTS");
			iMap.put("LIST_QUERY", "SELECT KEY1,TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = ? and KEY2 = ? and NVL(KEY3,'A') = 'A' ORDER BY KEY1");
			List<String> queryParameters = new ArrayList<String>();
			queryParameters.add(iMap.getString("KOD"));
			queryParameters.add(iMap.getString("KEY2"));
			iMap.put("QUERY_PARAMETERS", queryParameters);
			iMap.put("ADD_EMPTY_KEY", iMap.getString("ADD_EMPTY_KEY"));
			oMap.putAll(DALUtil.fillComboBox(iMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_PASSO_LIG_VARMI")
	public static GMMap musteriPassoLigBasvurusuVarMi(GMMap iMap) {
		GMMap oMap = new GMMap();

		String RESULT_TABLE = "RESULT_TABLE";

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String query = null;
		try {

			conn = DALUtil.getGMConnection();
			query = "{call PKG_TFF_BASVURU.listBasvuruOzetBilgi(?,?,?,?,?,?,?,?,?,?,?)}";
			stmt = conn.prepareCall(query);

			stmt.setString(1, iMap.getString("TCKN"));
			stmt.setString(2, null);
			stmt.setString(3, null);

			stmt.setString(4, null);
			stmt.setString(5, null);
			stmt.registerOutParameter(6, -10);
			stmt.registerOutParameter(7, Types.CHAR);
			stmt.registerOutParameter(8, Types.CHAR);
			stmt.registerOutParameter(9, Types.CHAR);
			stmt.registerOutParameter(10, Types.CHAR);
			stmt.registerOutParameter(11, Types.CHAR);

			stmt.execute();
			String ad = stmt.getString(9);

			if (StringUtils.isEmpty(ad)) {
				oMap.put("PASSOLIG_VAR_MI", 0);
				return oMap;
			}
			rSet = (ResultSet) stmt.getObject(6);
			GMMap resultMap = DALUtil.rSetResults(rSet, RESULT_TABLE);

			if (resultMap == null || resultMap.isEmpty() || resultMap.getSize(RESULT_TABLE) == 0) {
				oMap.put("PASSOLIG_VAR_MI", 0);
				return oMap;
			}
			oMap.put("PASSOLIG_VAR_MI", 1);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

		return oMap;

	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_QRY3180_GET_COMPONENT_ROLE")
	public static GMMap getComponentRoles(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<GnlEkranAlanRolTanim> roleList = null;
		String currentRole = StringUtils.EMPTY;
		String alanAdi = "webDogrulama";
		BigDecimal islemKod = new BigDecimal(3180);

		try {
			roleList = (List<GnlEkranAlanRolTanim>) session.createCriteria(GnlEkranAlanRolTanim.class).add(Restrictions.eq("id.islemKod", islemKod)).add(Restrictions.eq("id.alanAdi", alanAdi)).list();

			currentRole = (String) DALUtil.callNoParameterFunction("{? = call pkg_global.get_rolkod}", Types.VARCHAR);
			oMap.put("WEB_DOGRULAMA", false);
			for (GnlEkranAlanRolTanim gnlEkranAlanRolTanim : roleList) {
				if (gnlEkranAlanRolTanim.getErisimsizRol() != null && Arrays.asList(gnlEkranAlanRolTanim.getErisimsizRol().split(";")).contains(currentRole)) {
					oMap.put("WEB_DOGRULAMA", true);
				}
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3180_GET_KKB_TEL_LIST")
	public static GMMap getKKBTelList(GMMap iMap) {
		GMMap oMap = new GMMap();
		CallableStatement stmt = null;
		ResultSet rSet = null;
		Connection conn = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call pkg_trn3180.kkb_iletisim_list(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.rSetResults(rSet, "RESULTS"));
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;

	}

}
