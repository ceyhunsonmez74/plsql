package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMeslekEgitimMatrixTx;
import tr.com.calikbank.bnspr.dao.GnlMeslekEgitimMatrixTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3117Services {
	@GraymoundService("BNSPR_TRN3117_GET_MESLEK_KOD")
	public static GMMap trn3117GetMeslekKod(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

//			select kod, aciklama from v_ml_gnl_meslek_kod_pr
			StringBuffer query = new StringBuffer();
			query.append("SELECT ");
			query.append("KOD, ACIKLAMA, EGITIM_DIZI, YAS_DIZI ");
			query.append("FROM ");
			query.append("V_ML_GNL_MESLEK_KOD_PR ");
			query.append("ORDER BY ACIKLAMA");

			stmt = conn.prepareStatement(query.toString());

			rSet = stmt.executeQuery();
			
			String tableName = "MESLEK_MATRIX";

			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "KOD", rSet.getString("KOD"));
				oMap.put(tableName, row, "MESLEKLER", rSet.getString("ACIKLAMA"));
				
				String egitimDizi = rSet.getString("EGITIM_DIZI");
				if(egitimDizi == null)
				{
					for (Integer i = 1; i <= 6; i++) {
						oMap.put(tableName, row, "EGITIM" + i.toString(), false);
					}
				}
				else
				{
					for (Integer i = 1; i <= egitimDizi.length(); i++) {
						oMap.put(tableName, row, "EGITIM" + i.toString(), GuimlUtil.convertBinaryToCheckBoxSelected(egitimDizi.substring(i-1, i)));
					}
				}
				String yasDizi = rSet.getString("YAS_DIZI");
				if(yasDizi == null)
				{
					for (Integer i = 1; i <= 5; i++) {
						oMap.put(tableName, row, "YAS" + i.toString(), false);
					}
				}
				else
				{
					for (Integer i = 1; i <= yasDizi.length(); i++) {
						oMap.put(tableName, row, "YAS" + i.toString(), GuimlUtil.convertBinaryToCheckBoxSelected(yasDizi.substring(i-1, i)));
					}
				}
				row++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3117_GET_EGITIM_KOD")
	public static GMMap trn3117GetEgitimKod(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			
			conn = DALUtil.getGMConnection();
			
//			select kod, aciklama from v_ml_gnl_egitim_kod_pr order by sira_no
			StringBuffer query = new StringBuffer();
			query.append("SELECT ");
			query.append("KOD, ACIKLAMA ");
			query.append("FROM ");
			query.append("V_ML_GNL_EGITIM_KOD_PR ");
			query.append("ORDER BY SIRA_NO ");

			stmt = conn.prepareStatement(query.toString());

			rSet = stmt.executeQuery();
			String tableName = "EGITIM_TABLE";
			
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "EGITIMLER", rSet.getString(2));
				row++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3117_GET_YAS_KOD")
	public static GMMap trn3117GetYasKod(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			
			conn = DALUtil.getGMConnection();
			
//			select kod, aciklama from v_ml_gnl_egitim_kod_pr order by sira_no
			StringBuffer query = new StringBuffer();
			query.append("SELECT ");
			query.append("TEXT ");
			query.append("FROM ");
			query.append("V_ML_GNL_PARAM_TEXT ");
			query.append("WHERE KOD = 'YAS_ARALIGI' ");
			query.append("ORDER BY SIRA_NO ");

			stmt = conn.prepareStatement(query.toString());

			rSet = stmt.executeQuery();
			String tableName = "YAS_TABLE";
			
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "YASLAR", rSet.getString(1));
				row++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3117_SAVE_MESLEK_EGITIM")
	public static Map<?, ?> saveMarkaModel(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "MESLEK_MATRIX";
			List<?> list = (List<?>) iMap.get(tableName);
			
			for (int j = 0; j < list.size(); j++) {
				GnlMeslekEgitimMatrixTx meslekEgitimMatrixTx = (GnlMeslekEgitimMatrixTx) session.createCriteria(GnlMeslekEgitimMatrixTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
																																			.add(Restrictions.eq("id.kod", iMap.getString(tableName, j, "KOD"))).uniqueResult();
				if (meslekEgitimMatrixTx == null)
				{
					meslekEgitimMatrixTx = new GnlMeslekEgitimMatrixTx();
					GnlMeslekEgitimMatrixTxId id = new GnlMeslekEgitimMatrixTxId();
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setKod(iMap.getString(tableName, j, "KOD"));
					meslekEgitimMatrixTx.setId(id);
				}
				meslekEgitimMatrixTx.setAciklama(iMap.getString(tableName, j, "MESLEKLER"));
	
				StringBuffer egitimDizi = new StringBuffer();
				for (Integer i = 1; i <= 6; i++) {
					Boolean val = iMap.getBoolean(tableName, j, "EGITIM"+i.toString());
					egitimDizi.append(GuimlUtil.convertBinaryFromCheckBoxValue(val));
				}
				meslekEgitimMatrixTx.setEgitimDizi(egitimDizi.toString());
				
				StringBuffer yasDizi = new StringBuffer();
				for (Integer i = 1; i <= 5; i++) {
					Boolean val = iMap.getBoolean(tableName, j, "YAS"+i.toString());
					yasDizi.append(GuimlUtil.convertBinaryFromCheckBoxValue(val));
				}				
				meslekEgitimMatrixTx.setYasDizi(yasDizi.toString());
				
				session.saveOrUpdate(meslekEgitimMatrixTx);
				session.flush();
			}
			iMap.put("TRX_NAME", "3117");
			return GMServiceExecuter
					.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3117_GET_INFO")
	public static GMMap trn3117GetInfo(GMMap iMap) {
		Connection conn = null;
		//PreparedStatement stmt = null;
		ResultSet rSet = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			
			conn = DALUtil.getGMConnection();
			String tx_no = iMap.getString("TRX_NO");
			
			stmt = conn.prepareCall("{? = call PKG_TRN3117.get_meslek_egitim(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, tx_no);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			String tableName = "MESLEK_MATRIX";

			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "KOD", rSet.getString("KOD"));
				oMap.put(tableName, row, "MESLEKLER", rSet.getString("ACIKLAMA"));
				
				String egitimDizi = rSet.getString("EGITIM_DIZI");
				if(egitimDizi == null)
				{
					for (Integer i = 1; i <= 6; i++) {
						oMap.put(tableName, row, "EGITIM" + i.toString(), false);
					}
				}
				else
				{
					for (Integer i = 1; i <= egitimDizi.length(); i++) {
						oMap.put(tableName, row, "EGITIM" + i.toString(), GuimlUtil.convertBinaryToCheckBoxSelected(egitimDizi.substring(i-1, i)));
					}
				}
				String yasDizi = rSet.getString("YAS_DIZI");
				if(yasDizi == null)
				{
					for (Integer i = 1; i <= 5; i++) {
						oMap.put(tableName, row, "YAS" + i.toString(), false);
					}
				}
				else
				{
					for (Integer i = 1; i <= yasDizi.length(); i++) {
						oMap.put(tableName, row, "YAS" + i.toString(), GuimlUtil.convertBinaryToCheckBoxSelected(yasDizi.substring(i-1, i)));
					}
				}
				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
