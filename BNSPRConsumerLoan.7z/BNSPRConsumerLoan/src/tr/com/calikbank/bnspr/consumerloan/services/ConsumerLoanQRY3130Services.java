package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3130Services {
	@GraymoundService("BNSPR_QRY3130_GET_REESKONT_RAP")
	public static GMMap getReeskontRap(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3130.RC_QRY3130_GET_REESKONT_RAP(?,?)}");
			
			stmt.registerOutParameter(1, -10);
			stmt.setDate(2, iMap.get("TARIH")!=null?new Date(iMap.getDate("TARIH").getTime()):null);
			stmt.setBigDecimal(3, iMap.getBigDecimal("BASVURU_NO"));
			
			stmt.execute();
			stmt.getMoreResults();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, "REESKONT_LIST");
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
