package tr.com.calikbank.bnspr.consumerloan.netmera;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.google.gson.Gson;
import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanNetmeraServices {
	private static final int RUNTIME_EXCEPTION_CODE = 99;
	private static final int SUCCEEDED_CODE = 0;
	private static final String SUCCEEDED_DESC = "BASARILI_ISLEM";
	private static final String GECERSIZ_EVENT = "GECERSIZ EVENT TIPI";

	@GraymoundService("BNSPR_CL_SEND_EVENT_TO_NETMERA")
	public static GMMap clSendEventToNetmera(GMMap iMap) {
		GMMap oMap = new GMMap();
		Gson gson = new Gson();
		Object objEventDetail = null;
		List<Object> objList = new ArrayList<Object>();

		try {
			if (StringUtils.isEmpty(iMap.getString("EVENT_TYPE")))
				throw new RuntimeException(GECERSIZ_EVENT);

			EventTypeEnum eventType = EventTypeEnum.valueOf(iMap.getString("EVENT_TYPE"));

			if (eventType == EventTypeEnum.OnOnayEvent) {
				Profile profile = new Profile();
				profile.setKrediOnOnayTutar((iMap.getBigDecimal("KREDI_ON_ONAY_TUTAR").floatValue()));
				profile.setKdhOnOnayTutar((iMap.getBigDecimal("KDH_ON_ONAY_TUTAR").floatValue()));

				OnOnayEventDetail eventDetail = new OnOnayEventDetail();
				eventDetail.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
				eventDetail.setProfile(profile);
				objEventDetail = eventDetail;

			}
			else if (eventType == EventTypeEnum.KullandirimEvent){
				KullandirimEventDetail eventDetail = new KullandirimEventDetail();
				eventDetail.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
				eventDetail.setName(EventTypeEnum.KullandirimEvent.getEventName());
				eventDetail.setKullanimTuru(iMap.getInt("KREDI_TUR"));
				eventDetail.setKullandirimTutar(iMap.getBigDecimal("TUTAR").floatValue());
				eventDetail.setOnOnayliMi(iMap.getString("ON_ONAY_FLAG"));
				eventDetail.setSegment(iMap.getString("SEGMENT"));
				eventDetail.setSigortaliMi(iMap.getString("SIGORTA_FLAG"));
				eventDetail.setSpotMu("SPOT_KREDI_FLAG");
				objEventDetail = eventDetail;
			}
			else
				throw new RuntimeException(GECERSIZ_EVENT);

			/*Pojo �zerideki alanlar�n bos olmamas� kontrol�*/
			((INullController) (objEventDetail)).checkNull();

			/*Json'a �evrilecek list olusturuluyor*/
			objList.add(objEventDetail);

			iMap.clear();
			String [] appList = eventType.getAppName().split(",");
			for (int i=0; i<appList.length; i++) {
				iMap.put("APP_LIST", i, "NAME", appList[i]);
			}

			// Event i�in olu�turulan arraylist, json format�na �evriliyor.
			iMap.put("JSON_DATA", gson.toJson(objList));
			iMap.put("SERVICE_ID", eventType.getServiceId());

			GMServiceExecuter.call("BNSPR_PUSH_MESSAGE_INSERT_INTO_SAF", iMap);

		}
		catch (IllegalArgumentException e) {
			System.out.println(StringUtils.left(e.getMessage(), 200));
			oMap.put("RESPONSE_CODE", RUNTIME_EXCEPTION_CODE);
			oMap.put("RESPONSE_DESC", GECERSIZ_EVENT);

			return oMap;
		}
		catch (Exception e) {
			oMap.put("RESPONSE_CODE", RUNTIME_EXCEPTION_CODE);
			oMap.put("RESPONSE_DESC", StringUtils.left(e.getMessage(), 200));

			return oMap;
		}

		oMap.put("RESPONSE_CODE", SUCCEEDED_CODE);
		oMap.put("RESPONSE_DESC", SUCCEEDED_DESC);
		return oMap;
	}

}
