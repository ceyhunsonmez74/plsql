package tr.com.calikbank.bnspr.consumerloan.utils;

public class Enums {

	public enum CreditDocTypes{
		CONSUMER_CREDIT(2081, "WEB"),
		BEFORE_AGGREEMENT(2082, "WEB"),
		BANKING_SERVICE_AGGREEMENT(2074, "WEB"),
		BANKING_SERVICE_PRE_AGGREEMENT(2075, "WEB"),
		CREDIT_INFO(544, "WEB"),
		CREDIT_CARD_INFO(545, "WEB"),
		CREDIT_PAYMENT_PLAN(546, "WEB"),
		PRODUCT_INFO(547, "WEB"),
		PRE_AGGREEMENT(582, "WEB"),
		KDH_AGGREEMENT(1998, "KDH"),
		KDH_PRE_INFO_FORM(1997, "KDH"),
		KDH_INFO_FORM(1996, "KDH"),
		TRANSFER_FORM(1976,"WEB"),
		KVK_FORM(1097 ,"WEB");
		
        private int code;
        private String type;

        private CreditDocTypes(int code, String type) {
                this.code = code;
                this.type = type;
        }
        
		public int getCode() {
			return code;
		}
		
		public String getType() {
			return type;
		}
	};
	
	public enum CreditDocMailTypes{
		BHS_KK("BHS_kredi_kullandirim"),
		DEBIT_KK("DEBIT_kredi_kullandirim"),
		PP_KK("PP_kredi_kullandirim"),
		PP_TB("PP_tamamlanan_basvuru"),
		YM_KK("YM_kredi_kullandirim"),
		YM_TB("YM_tamamlanan_basvuru"),
		ON_BF("ON_BILGILENDIRME"),
		SOBF("SOBF"),
		KDH("KDH_kullandirim"),
		PP_CS("PP_CS_tamamlanan_basvuru"),
		KVK("KVK_FORM"),
		SPOT_KK("SPOT_kredi_kullandirim"),
		SPOT_KURYE("SPOT_kurye"),
		SPOT_SOBF("SPOT_SOBF"),
		KAPAMA_FORM("eft_kapama_formu"),
		OP_GUNC("op_gunc");
		
        private String vmName;
        
        private CreditDocMailTypes(String vmName) {
                this.vmName = vmName;
        }
        
		public String getVmName() {
			return vmName;
		}
	};
	
}
