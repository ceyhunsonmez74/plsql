package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirSaticiLimitTx;
import tr.com.calikbank.bnspr.dao.BirSaticiLimitTxId;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3163Services {
	@GraymoundService("BNSPR_TRN3163_SAVE")
	public static Map<?, ?> saveTRN3151(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> saticiTahsisFaaliyetList = (List<?>) iMap.get("BIR_SATICI_LIMIT");
			String tableName = "BIR_SATICI_LIMIT";
			for (int i = 0; i < saticiTahsisFaaliyetList.size(); i++) {
				
				BirSaticiLimitTx birSaticiLimitTx = new BirSaticiLimitTx();
				BirSaticiLimitTxId birSaticiLimitTxId = new BirSaticiLimitTxId();
				
				birSaticiLimitTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birSaticiLimitTxId.setSaticiLimitTip(iMap.getBigDecimal(tableName, i, "SATIC_LIMIT_TIP"));
				birSaticiLimitTxId.setDovizCins(iMap.getString(tableName, i, "DOVIZ_CINS"));
				
				birSaticiLimitTx.setId(birSaticiLimitTxId);
				///birSaticiLimitTx.setOrjLimit(iMap.getBigDecimal(tableName, i, "ORJ_LIMIT"));
				///birSaticiLimitTx.setIade(iMap.getString(tableName, i, "IADE"));
				///birSaticiLimitTx.setBelgeTaahMaxOran(iMap.getBigDecimal(tableName, i, "BELGE_TAAH_MAX_ORAN"));
				///birSaticiLimitTx.setGarantorBelgeTip(iMap.getString(tableName, i, "GARANTOR_BELGE_TIP"));
				///birSaticiLimitTx.setGarantorMaxOran(iMap.getBigDecimal(tableName, i, "GARANTOR_MAX_ORAN"));
				///birSaticiLimitTx.setGarantiTaahBelgeTip(iMap.getString(tableName, i, "GARANTI_TAAH_BELGE_TIP"));
				///birSaticiLimitTx.setGarantiTaahMaxOran(iMap.getBigDecimal(tableName, i, "GARANTI_TAAH_MAX_ORAN"));
				
				session.save(birSaticiLimitTx);
			}
			
			session.flush();
			
			iMap.put("TRX_NAME", "3163");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3163_GET_BIR_SATICI_LIMIT_LIST")
	public static GMMap getBirSaticiLimitList(GMMap iMap) {
		try {
			Connection conn = null;
			CallableStatement stmt = null;
			try{
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call pkg_trn3163.isleme_kayit_at(?)}");
				stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
				
				stmt.execute();
			}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}finally{
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}	
			
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(BirSaticiLimitTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			String tableName = "BIR_SATICI_LIMIT";
			GMMap oMap = new GMMap();
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				BirSaticiLimitTx birSaticiLimitTx = (BirSaticiLimitTx)iterator.next();
				oMap.put(tableName, row, "SATIC_LIMIT_TIP",birSaticiLimitTx.getId().getSaticiLimitTip());
				oMap.put(tableName, row, "DOVIZ_CINS", birSaticiLimitTx.getId().getDovizCins());
				///oMap.put(tableName, row, "ORJ_LIMIT", birSaticiLimitTx.getOrjLimit());
				///oMap.put(tableName, row, "IADE", birSaticiLimitTx.getIade());
				///oMap.put(tableName, row, "BELGE_TAAH_MAX_ORAN", birSaticiLimitTx.getBelgeTaahMaxOran());
				///oMap.put(tableName, row, "GARANTOR_BELGE_TIP", birSaticiLimitTx.getGarantorBelgeTip());
				///oMap.put(tableName, row, "GARANTOR_MAX_ORAN", birSaticiLimitTx.getGarantorMaxOran());
				///oMap.put(tableName, row, "GARANTI_TAAH_BELGE_TIP", birSaticiLimitTx.getGarantiTaahBelgeTip());
				///oMap.put(tableName, row, "GARANTI_TAAH_MAX_ORAN", birSaticiLimitTx.getGarantiTaahMaxOran());
				
				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
