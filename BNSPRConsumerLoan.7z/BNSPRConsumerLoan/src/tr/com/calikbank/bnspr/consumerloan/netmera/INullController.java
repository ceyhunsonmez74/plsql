package tr.com.calikbank.bnspr.consumerloan.netmera;

public interface INullController {

	public void checkNull();

}
