package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3123Services {
	
	@GraymoundService("BNSPR_QRY3123_GET_BASVURU")
	public static GMMap getBasvuruBilgileri(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		GMMap				oMap = new GMMap();
		try {
			if(iMap.getDate("BASVURU_TARIHI_BAS") != null && iMap.getDate("BASVURU_TARIHI_BIT") != null) {
				if(iMap.getDate("BASVURU_TARIHI_BAS").after(iMap.getDate("BASVURU_TARIHI_BIT"))) {
					iMap.put("HATA_NO", new BigDecimal(915));
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}
			
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_RC3123.RC_QRY3123_Musteri_Dogrulama(?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			
			stmt.registerOutParameter(i++, -10);
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TCKN"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			
			if( iMap.getDate("BASVURU_TARIHI_BAS") != null) 
				stmt.setDate(i++, new Date(iMap.getDate("BASVURU_TARIHI_BAS").getTime()));
			else
				stmt.setDate(i++, null);
			if( iMap.getDate("BASVURU_TARIHI_BIT") != null) 
				stmt.setDate(i++, new Date(iMap.getDate("BASVURU_TARIHI_BIT").getTime()));
			else
				stmt.setDate(i++, null);

			stmt.setBigDecimal(i++, iMap.getBigDecimal("IS_TEL_NO"));
			stmt.setString(i++, iMap.getString("IS_YERI_ADI"));
			stmt.setString(i++, iMap.getString("CALISMA_SEKLI"));
			stmt.setString(i++, iMap.getString("KONTROL_TIPI"));
			
			if( iMap.getDate("HAVUZA_GELIS_TARIH_BAS") != null) 
				stmt.setDate(i++, new Date(iMap.getDate("HAVUZA_GELIS_TARIH_BAS").getTime()));
			else
				stmt.setDate(i++, null);
			if( iMap.getDate("HAVUZA_GELIS_TARIH_SON") != null) 
				stmt.setDate(i++, new Date(iMap.getDate("HAVUZA_GELIS_TARIH_SON").getTime()));
			else
				stmt.setDate(i++, null);
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "RESULTS"));
			GMServerDatasource.close(rSet);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			int row = 0;
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
			while(rSet.next()) {
				java.util.Date havuzaGelis 		= dateFormat.parse(dateFormat.format(rSet.getTimestamp("HAVUZA_GELIS_TARIHI")));
				java.util.Date basvuruTarihi 	= dateFormat.parse(dateFormat.format(rSet.getTimestamp("BASVURU_TARIH")));
				oMap.put("RESULTS", row, "HAVUZA_GELIS_TARIHI"	, dateFormat.format(havuzaGelis));
				oMap.put("RESULTS", row, "BASVURU_TARIH"		, dateFormat.format(basvuruTarihi));
				row++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
