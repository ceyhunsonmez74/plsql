package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBayiSorumluGuncTx;
import tr.com.aktifbank.bnspr.dao.BirBayiSorumluGuncTxId;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3285Services {

	@GraymoundService("BNSPR_TRN3285_DOSYA_YUKLE")
	public static GMMap dosyaYukle(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			WorkbookSettings ws = new WorkbookSettings();
			ws.setEncoding("iso-8859-9");

			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("DOSYA")), ws);
			Sheet sheet = workbook.getSheet(0);
			String tableName = "SONUC";
			int tableRow = 0;

			for (int excelRow = 1; excelRow < sheet.getRows(); excelRow++) {

				String saticiKod = sheet.getCell(0, excelRow).getContents().trim();
				String bagliOldBolgeKod = sheet.getCell(1, excelRow).getContents().trim();
				String bayiSorumluKisi = sheet.getCell(2, excelRow).getContents().trim();

				if (!StringUtil.isEmpty(saticiKod) && (!StringUtil.isEmpty(bayiSorumluKisi) || !StringUtil.isEmpty(bagliOldBolgeKod))) {
					oMap.put(tableName, tableRow, "SATICI_KOD", saticiKod);
					oMap.put(tableName, tableRow, "BAGLI_OLD_BOLGE_KOD", bagliOldBolgeKod);
					oMap.put(tableName, tableRow, "BAYI_SORUMLU_KISI", bayiSorumluKisi);
					tableRow++;
				}
			}
			workbook.close();
		}
		catch (IndexOutOfBoundsException e) {
			throw new GMRuntimeException(0, "Excel s�tunu eksik");
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3285_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		String tableName = "SONUC";
		List<?> liste = (List<?>) iMap.get(tableName);
		if (liste.size() == 0) {
			iMap.put("HATA_NO", new BigDecimal(1064));
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}

		for (int i = 0; i < liste.size(); i++) {
			BirBayiSorumluGuncTx tx = new BirBayiSorumluGuncTx();
			BirBayiSorumluGuncTxId id = new BirBayiSorumluGuncTxId();
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setSaticiKod(iMap.getBigDecimal(tableName, i, "SATICI_KOD"));
			tx.setId(id);
			tx.setBagliOldBolgeKod(iMap.getString(tableName, i, "BAGLI_OLD_BOLGE_KOD"));
			tx.setBayiSorumluKisi(iMap.getBigDecimal(tableName, i, "BAYI_SORUMLU_KISI"));

			session.save(tx);
		}

		session.flush();
		iMap.put("TRX_NAME", "3285");
		return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
	}

	@GraymoundService("BNSPR_TRN3285_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String tableName = "SONUC";

		List<BirBayiSorumluGuncTx> list = (List<BirBayiSorumluGuncTx>) session.createCriteria(BirBayiSorumluGuncTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
		
		for (int i = 0; i < list.size(); i++) {
			oMap.put(tableName, i, "SATICI_KOD", list.get(i).getId().getSaticiKod());
			oMap.put(tableName, i, "BAGLI_OLD_BOLGE_KOD", list.get(i).getBagliOldBolgeKod());
			oMap.put(tableName, i, "BAYI_SORUMLU_KISI", list.get(i).getBayiSorumluKisi());
		}
		
		return oMap;
	}

}
