package tr.com.calikbank.bnspr.consumerloan.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruBelge;
import tr.com.aktifbank.bnspr.dao.BirKrediOdemeplaniGunTx;
import tr.com.aktifbank.bnspr.dao.BirKrediOdemeplaniSatirTx;
import tr.com.aktifbank.bnspr.dao.BirKrediOdemeplaniSatirTxId;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.aktifbank.bnspr.dao.MusteriUrunRisk;
import tr.com.calikbank.bnspr.consumerloan.utils.Enums.CreditDocMailTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlik;
import tr.com.calikbank.bnspr.dao.BirKullandirim;
import tr.com.calikbank.bnspr.dao.GnlKanalGrupKodPr;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.ReportUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3199Services {

	private static final Logger logger = Logger.getLogger(ConsumerLoanTRN3199Services.class);

	private static final String SOBF_DOKUMAN_KOD = "1016";
	private static final String YAPILANDIRMA_ODEME_PLANI_DOKUMAN_KOD = "1017";
	private static final String YAPILANDIRMA_SOZLESME_DOKUMAN_KOD = "1018";

	@GraymoundService("BNSPR_TRN3199_GET_RECORD_LIST")
	public static GMMap getRecordTRN3199List(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		Session session = DAOSession.getSession("BNSPRDal");
		try {
			GMMap oMap = new GMMap();
			GMMap dateMap = new GMMap();
			dateMap = (GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", dateMap));
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3199.RC_GET_CURRENT_ODEME_PLANI(?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.getMoreResults();
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			// Toplamlar
			BigDecimal sumTaksitTutari = BigDecimal.ZERO;
			BigDecimal sumAnapara = BigDecimal.ZERO;
			BigDecimal sumFaiz = BigDecimal.ZERO;
			BigDecimal sumKKDF = BigDecimal.ZERO;
			BigDecimal sumBSMV = BigDecimal.ZERO;
			BigDecimal sumGecikmeFaiz = BigDecimal.ZERO;
			int sumAcikTaksit = 0;

			Date ilktaksit = null;

			String tableName = "GUNCEL_RESULTS";
			String tableName2 = "MEVCUT_RESULTS";
			int ilkAcikTaksitKontrol = 0;
			int row = 0;
			oMap.put("KISMI", false);
			while (rSet.next()) {
				int j = 1;

				// A��k olan ilk taksitin s�ra no'sunun belirlenmesi
				if (ilkAcikTaksitKontrol == 0 && rSet.getString("DURUM_KOD").equals("ACIK")) {
					oMap.put("ILK_TAKSIT_SIRA_NO", rSet.getString("SIRA_NO"));
					ilkAcikTaksitKontrol = 1;
				}

				oMap.put(tableName, row, "SIRA_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "TAKSIT_TARIH", rSet.getDate(j++));
				oMap.put(tableName, row, "TAKSIT_TUT", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "ANAPARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "FAIZ", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KKDF", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "BSMV", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KALAN_ANAPARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DURUM_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "MASRAF", rSet.getBigDecimal(j++));

				j = 1;

				oMap.put(tableName2, row, "SIRA_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName2, row, "TAKSIT_TARIH", rSet.getDate(j++));
				oMap.put(tableName2, row, "TAKSIT_TUT", rSet.getBigDecimal(j++));
				oMap.put(tableName2, row, "ANAPARA", rSet.getBigDecimal(j++));
				oMap.put(tableName2, row, "FAIZ", rSet.getBigDecimal(j++));
				oMap.put(tableName2, row, "KKDF", rSet.getBigDecimal(j++));
				oMap.put(tableName2, row, "BSMV", rSet.getBigDecimal(j++));
				oMap.put(tableName2, row, "KALAN_ANAPARA", rSet.getBigDecimal(j++));
				oMap.put(tableName2, row, "DURUM_KOD", rSet.getString(j++));
				oMap.put(tableName2, row, "MASRAF", rSet.getBigDecimal(j++));

				if (row == 0) {
					ilktaksit = rSet.getDate("TAKSIT_TARIH");
				}

				// Toplamlar�n hesaplanmas�

				if (rSet.getString("DURUM_KOD").equals("ACIK")) {
					sumAcikTaksit++;
					sumTaksitTutari = sumTaksitTutari.add(rSet.getBigDecimal("TAKSIT_TUT"));
					sumAnapara = sumAnapara.add(rSet.getBigDecimal("ANAPARA"));
					sumFaiz = sumFaiz.add(rSet.getBigDecimal("FAIZ"));
					sumKKDF = sumKKDF.add(rSet.getBigDecimal("KKDF"));
					sumBSMV = sumBSMV.add(rSet.getBigDecimal("BSMV"));

				}
				else if (rSet.getString("DURUM_KOD").equals("KISMI")) {
					sumAcikTaksit++;
					sumTaksitTutari = sumTaksitTutari.add(rSet.getBigDecimal("KALAN_ANAPARA"));
					if (rSet.getFloat("KALAN_ANAPARA") >= rSet.getFloat("ANAPARA")) {
						sumAnapara = sumAnapara.add(rSet.getBigDecimal("ANAPARA"));
					}
					else {
						sumAnapara = sumAnapara.add(rSet.getBigDecimal("KALAN_ANAPARA"));
					}
					oMap.put("KISMI", true);
				}

				sumGecikmeFaiz = sumGecikmeFaiz.add(rSet.getBigDecimal("GECIKME_FAIZ_TUTARI"));
				row++;
			}

			oMap.put("SUM_TAKSIT_TUTAR", sumTaksitTutari);
			oMap.put("SUM_ANAPARA", sumAnapara);
			oMap.put("SUM_FAIZ", sumFaiz);
			oMap.put("SUM_KKDF", sumKKDF);
			oMap.put("SUM_BSMV", sumBSMV);
			oMap.put("ILK_TAKSIT", ilktaksit);
			oMap.put("SUM_ACIK_TAKSIT", sumAcikTaksit);
			oMap.put("GECIKME_FAIZ_TUTARI", sumGecikmeFaiz);
			i = 0;
			while (i < oMap.getSize(tableName)) {
				if ("ACIK".equals(oMap.getString(tableName, i, "DURUM_KOD")) && dateMap.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName, i, "TAKSIT_TARIH")) > 0 && oMap.getBigDecimal(tableName, i, "TAKSIT_TUT").compareTo(new BigDecimal(0)) == 1) {
					oMap.put(tableName, i, "DURUM_KOD_G", "GECIKMEDE");
					oMap.put("GECIKMEDE", true);
				}
				else
					oMap.put(tableName, i, "DURUM_KOD_G", oMap.getString(tableName, i, "DURUM_KOD"));
				i++;
			}
			i = 0;
			oMap.put("GECIKMEDE", false);
			while (i < oMap.getSize(tableName2)) {
				if ("ACIK".equals(oMap.getString(tableName2, i, "DURUM_KOD")) && dateMap.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName2, i, "TAKSIT_TARIH")) > 0 && oMap.getBigDecimal(tableName, i, "TAKSIT_TUT").compareTo(new BigDecimal(0)) == 1) {
					oMap.put(tableName2, i, "DURUM_KOD_G", "GECIKMEDE");
					oMap.put("GECIKMEDE", true);
				}
				else
					oMap.put(tableName2, i, "DURUM_KOD_G", oMap.getString(tableName2, i, "DURUM_KOD"));
				i++;
			}
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			stmt = conn.prepareCall("{?=call PKG_VDMK.Devredildi_Mi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("DEVREDILDI_MI", "E".equals(stmt.getString(1)));

			/* E-posta ve Telefon Bilgileri */
			BirBasvuru b = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			GMMap tMap = new GMMap();
			tMap.put("CUSTOMER_NO", b.getMusteriNo());

			// tMap = GMServiceExecuter.call("BNSPR_CUSTOMER_GET_CUSTOMER_CONTACT_PHONE_NO", tMap);
			tMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_OTP", tMap));

			String phoneNum = StringUtils.EMPTY;
			phoneNum = tMap.getString("PHONE_NUMBER");
			if (StringUtils.isNotEmpty(phoneNum)) {
				if (phoneNum.length() > 11) {
					oMap.put("PHONE_NUMBER", phoneNum.substring(phoneNum.length() - 11, phoneNum.length()));
				}
				else {
					oMap.put("PHONE_NUMBER", phoneNum);
				}
			}

			stmt = null;
			stmt = conn.prepareCall("{? = call Pkg_musteri.email_kisisel(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, b.getMusteriNo());
			stmt.execute();

			oMap.put("EMAIL_ADDRESS", stmt.getString(1));

			oMap.put("YAPILANDIRMA_MIN_TARIH", DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_D('BIR_YAPILANDIRMA_MIN_TARIH')}", Types.DATE));

			// Renklendirme
			oMap.putAll(BeanSetProperties.tableDifference((ArrayList<?>) oMap.get("MEVCUT_RESULTS"), (ArrayList<?>) oMap.get("GUNCEL_RESULTS"), "SIRA_NO", "setForeground", Color.RED));
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			stmt = conn.prepareCall("{? = call pkg_trn3199.Gecikmeli_Taksit_Varmi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR); // ref cursor
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("MESSAGE", stmt.getString(1));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3199_SAVE")
	public static GMMap save(GMMap iMap) {
		try {

			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "MEVCUT_LIST";
			String tableName2 = "GUNCEL_LIST";

			// Eski kayitlarin silimesi (satir sayisi degismis olabilir)
			List<BirKrediOdemeplaniSatirTx> txSatirList = (List<BirKrediOdemeplaniSatirTx>) session.createCriteria(BirKrediOdemeplaniSatirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			if (txSatirList != null) {
				for (int i = 0; i < txSatirList.size(); i++) {
					session.delete(txSatirList.get(i));
				}
				session.flush();
			}

			// Guncel tablonun kaydedilmesi
			List<?> list2 = (List<?>) iMap.get(tableName2);
			if (list2 != null) {
				for (int i = 0; i < list2.size(); i++) {

					BirKrediOdemeplaniSatirTx birKrediOdemeplaniSatirTx = (BirKrediOdemeplaniSatirTx) session.createCriteria(BirKrediOdemeplaniSatirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.siraNo", iMap.getBigDecimal(tableName2, i, "SIRA_NO"))).add(Restrictions.eq("id.eskiYeni", "Y")).uniqueResult();
					if (birKrediOdemeplaniSatirTx == null) {
						birKrediOdemeplaniSatirTx = new BirKrediOdemeplaniSatirTx();
						BirKrediOdemeplaniSatirTxId birKrediOdemeplaniSatirTxId = new BirKrediOdemeplaniSatirTxId();

						birKrediOdemeplaniSatirTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
						birKrediOdemeplaniSatirTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						birKrediOdemeplaniSatirTxId.setSiraNo(iMap.getBigDecimal(tableName2, i, "SIRA_NO"));
						birKrediOdemeplaniSatirTxId.setEskiYeni("Y");
						birKrediOdemeplaniSatirTx.setId(birKrediOdemeplaniSatirTxId);
					}

					birKrediOdemeplaniSatirTx.setTaksitTarih(iMap.getDate(tableName2, i, "TAKSIT_TARIH"));
					birKrediOdemeplaniSatirTx.setTaksitTut(iMap.getBigDecimal(tableName2, i, "TAKSIT_TUT"));
					birKrediOdemeplaniSatirTx.setAnapara(iMap.getBigDecimal(tableName2, i, "ANAPARA"));
					birKrediOdemeplaniSatirTx.setFaiz(iMap.getBigDecimal(tableName2, i, "FAIZ"));
					birKrediOdemeplaniSatirTx.setKkdf(iMap.getBigDecimal(tableName2, i, "KKDF"));
					birKrediOdemeplaniSatirTx.setBsmv(iMap.getBigDecimal(tableName2, i, "BSMV"));
					birKrediOdemeplaniSatirTx.setMasraf(iMap.getBigDecimal(tableName2, i, "MASRAF"));
					birKrediOdemeplaniSatirTx.setDurumKod(iMap.getString(tableName2, i, "DURUM_KOD"));
					birKrediOdemeplaniSatirTx.setKalanAnapara(iMap.getBigDecimal(tableName2, i, "KALAN_ANAPARA"));

					session.save(birKrediOdemeplaniSatirTx);

				}
				session.flush();
			}

			// Mevcut tablosu al�n�r ve eski de�erler olarak i�aretlenir.

			List<?> list = (List<?>) iMap.get(tableName);
			if (list != null) {
				for (int i = 0; i < list.size(); i++) {

					BirKrediOdemeplaniSatirTx birKrediOdemeplaniSatirTx = (BirKrediOdemeplaniSatirTx) session.createCriteria(BirKrediOdemeplaniSatirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.siraNo", iMap.getBigDecimal(tableName, i, "SIRA_NO"))).add(Restrictions.eq("id.eskiYeni", "E")).uniqueResult();
					if (birKrediOdemeplaniSatirTx == null) {
						birKrediOdemeplaniSatirTx = new BirKrediOdemeplaniSatirTx();
						BirKrediOdemeplaniSatirTxId birKrediOdemeplaniSatirTxId = new BirKrediOdemeplaniSatirTxId();

						birKrediOdemeplaniSatirTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
						birKrediOdemeplaniSatirTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						birKrediOdemeplaniSatirTxId.setSiraNo(iMap.getBigDecimal(tableName, i, "SIRA_NO"));
						birKrediOdemeplaniSatirTxId.setEskiYeni("E");

						birKrediOdemeplaniSatirTx.setId(birKrediOdemeplaniSatirTxId);
					}

					birKrediOdemeplaniSatirTx.setTaksitTarih(iMap.getDate(tableName, i, "TAKSIT_TARIH"));
					birKrediOdemeplaniSatirTx.setTaksitTut(iMap.getBigDecimal(tableName, i, "TAKSIT_TUT"));
					birKrediOdemeplaniSatirTx.setAnapara(iMap.getBigDecimal(tableName, i, "ANAPARA"));
					birKrediOdemeplaniSatirTx.setFaiz(iMap.getBigDecimal(tableName, i, "FAIZ"));
					birKrediOdemeplaniSatirTx.setKkdf(iMap.getBigDecimal(tableName, i, "KKDF"));
					birKrediOdemeplaniSatirTx.setBsmv(iMap.getBigDecimal(tableName, i, "BSMV"));
					birKrediOdemeplaniSatirTx.setMasraf(iMap.getBigDecimal(tableName, i, "MASRAF"));
					birKrediOdemeplaniSatirTx.setDurumKod(iMap.getString(tableName, i, "DURUM_KOD"));
					birKrediOdemeplaniSatirTx.setKalanAnapara(iMap.getBigDecimal(tableName, i, "KALAN_ANAPARA"));

					session.save(birKrediOdemeplaniSatirTx);
				}
				session.flush();
			}

			BirKrediOdemeplaniGunTx birKrediOdemeplaniGunTx = (BirKrediOdemeplaniGunTx) session.createCriteria(BirKrediOdemeplaniGunTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

			// Ust alanlar�n kaydedilmesi
			if (birKrediOdemeplaniGunTx == null)
				birKrediOdemeplaniGunTx = new BirKrediOdemeplaniGunTx();

			birKrediOdemeplaniGunTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birKrediOdemeplaniGunTx.setGerekceKod(iMap.getString("GEREKCE_KOD"));
			birKrediOdemeplaniGunTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birKrediOdemeplaniGunTx.setIslemTip(iMap.getString("ISLEM_TIPI"));
			birKrediOdemeplaniGunTx.setKullandirimYapilmisMi("1".equals(iMap.getString("ISLEM_TIPI")) ? "H" : "E");

			birKrediOdemeplaniGunTx.setBsmvOrani(iMap.getBigDecimal("BSMV_ORANI"));
			birKrediOdemeplaniGunTx.setDosyaMasrafi(iMap.getBigDecimal("DOSYA_MASRAFI"));
			birKrediOdemeplaniGunTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			birKrediOdemeplaniGunTx.setFarkFaizi(iMap.getBigDecimal("FARK_FAIZI"));
			birKrediOdemeplaniGunTx.setGecikmeFaizOrani(iMap.getBigDecimal("GECIKME_FAIZ_ORANI"));
			birKrediOdemeplaniGunTx.setIlkTaksitTarihi(iMap.getDate("ILK_TAKSIT_TARIHI"));
			birKrediOdemeplaniGunTx.setIlkTaksitYontem(iMap.getString("ILK_TAKSIT_YONTEM"));
			birKrediOdemeplaniGunTx.setKkdfOrani(iMap.getBigDecimal("KKDF_ORANI"));
			birKrediOdemeplaniGunTx.setSigortaPrimi(iMap.getBigDecimal("SIGORTA_PRIMI"));
			if (iMap.getString("URUN_KAMP_KOD") == null) {
				birKrediOdemeplaniGunTx.setKampKod(iMap.getBigDecimal("KAMP_KOD"));
				birKrediOdemeplaniGunTx.setKrediAltTur(iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
				birKrediOdemeplaniGunTx.setKrediAltTur2(iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
				birKrediOdemeplaniGunTx.setKampKnlKod(iMap.getBigDecimal("KAMP_KNL_KOD"));
			}
			else if (iMap.getString("URUN_KAMP_KOD").indexOf('-') < 0) {
				birKrediOdemeplaniGunTx.setKampKod(iMap.getBigDecimal("KAMP_KOD"));
				birKrediOdemeplaniGunTx.setKrediAltTur(null);
				birKrediOdemeplaniGunTx.setKrediAltTur2(null);
				birKrediOdemeplaniGunTx.setKampKnlKod(iMap.getBigDecimal("KAMP_KNL_KOD"));
			}
			else {
				birKrediOdemeplaniGunTx.setKampKod(null);
				birKrediOdemeplaniGunTx.setKrediAltTur(iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
				birKrediOdemeplaniGunTx.setKrediAltTur2(iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
				birKrediOdemeplaniGunTx.setKampKnlKod(null);
			}
			birKrediOdemeplaniGunTx.setKrediTur(iMap.getBigDecimal("KREDI_TUR"));
			birKrediOdemeplaniGunTx.setKrediTutar(iMap.getBigDecimal("KREDI_TUTAR"));
			birKrediOdemeplaniGunTx.setOdemeTipKod(iMap.getString("ODEME_TIP_KOD"));
			birKrediOdemeplaniGunTx.setOdemeTipOran(iMap.getBigDecimal("ODEME_TIP_ORAN"));
			birKrediOdemeplaniGunTx.setOdemeTipPeriyod(iMap.getBigDecimal("ODEME_TIP_PERIYOD"));
			birKrediOdemeplaniGunTx.setOdemeTipTut(iMap.getBigDecimal("ODEME_TIP_TUT"));
			birKrediOdemeplaniGunTx.setOdemeTipVade(iMap.getBigDecimal("ODEME_TIP_VADE"));
			birKrediOdemeplaniGunTx.setOtelemeGunSayisi(iMap.getBigDecimal("OTELEME_GUN_SAYISI"));
			birKrediOdemeplaniGunTx.setPttMaasTarihSikligi(iMap.getBigDecimal("PTT_MAAS_TARIH_SIKLIGI"));
			birKrediOdemeplaniGunTx.setSerbestKatkiPayi(iMap.getBigDecimal("SERBEST_KATKI_PAYI"));
			birKrediOdemeplaniGunTx.setSozlesmeFaizi(iMap.getBigDecimal("SOZLESME_FAIZI"));
			birKrediOdemeplaniGunTx.setSozlesmeTarihi(iMap.getDate("SOZLESME_TARIHI"));
			birKrediOdemeplaniGunTx.setVade(iMap.getBigDecimal("VADE"));
			birKrediOdemeplaniGunTx.setVadesizHesapNo(iMap.getBigDecimal("VADESIZ_HESAP_NO"));
			birKrediOdemeplaniGunTx.setEskiKrediTutari(iMap.getBigDecimal("ESKI_KREDI_TUTARI"));
			birKrediOdemeplaniGunTx.setEskiSerbestKatkiPayi(iMap.getBigDecimal("ESKI_SERBEST_KATKI_PAYI"));
			birKrediOdemeplaniGunTx.setMusHesapNo(iMap.getBigDecimal("MUS_HESAP_NO"));
			birKrediOdemeplaniGunTx.setBayiHesapNo(iMap.getBigDecimal("BAYI_HESAP_NO"));
			birKrediOdemeplaniGunTx.setDistHesapNo(iMap.getBigDecimal("DIST_HESAP_NO"));
			birKrediOdemeplaniGunTx.setKrdHesapNo(iMap.getBigDecimal("KRD_HESAP_NO"));
			birKrediOdemeplaniGunTx.setCostRatio(iMap.getBigDecimal("YILLIK_MALIYET"));
			birKrediOdemeplaniGunTx.setTaksitGunu(iMap.getBigDecimal("TAKSIT_GUNU"));
			birKrediOdemeplaniGunTx.setTaksitGunuAysonuMu(iMap.getBoolean("AY_SONU") ? "E" : "H");
			birKrediOdemeplaniGunTx.setOtelemeAySayisi(iMap.getBigDecimal("OTELEME_AY_SAYISI"));
			birKrediOdemeplaniGunTx.setGecikmeFaizTutari(iMap.getBigDecimal("GECIKME_FAIZ_TUTARI"));

			if (StringUtils.isNotEmpty(iMap.getString("TAHSIS_NO")))
				birKrediOdemeplaniGunTx.setTahsisNo(iMap.getString("TAHSIS_NO"));
			else
				birKrediOdemeplaniGunTx.setTahsisNo(null);
			if (StringUtils.isNotEmpty(iMap.getString("PTT_MAAS_KURUM")))
				birKrediOdemeplaniGunTx.setMaasAlinanKurum(iMap.getString("PTT_MAAS_KURUM"));
			else
				birKrediOdemeplaniGunTx.setMaasAlinanKurum(null);

			/*if (StringUtils.isNotEmpty(birKrediOdemeplaniGunTx.getGerekceKod())) {
				if (birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("1") == false && birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("2") == false && birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("3") == false
								&& birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("16") == false) {
					birKrediOdemeplaniGunTx.setSozlesmeCepTel(iMap.getBigDecimal("SOZLESME_CEP"));
					birKrediOdemeplaniGunTx.setSozlesmeEmail(iMap.getString("SOZLESME_EMAIL"));
				}
			}*/
			if(iMap.getBigDecimal("SOZLESME_CEP") != null)
				birKrediOdemeplaniGunTx.setSozlesmeCepTel(iMap.getBigDecimal("SOZLESME_CEP"));
			if(StringUtils.isNotEmpty(iMap.getString("SOZLESME_EMAIL")))
					birKrediOdemeplaniGunTx.setSozlesmeEmail(iMap.getString("SOZLESME_EMAIL"));
			
			birKrediOdemeplaniGunTx.setFarkFaiziTaksit(iMap.getBigDecimal("FARK_FAIZI_TAKSIT"));
			birKrediOdemeplaniGunTx.setFarkFaiziTaksitOnceki(iMap.getBigDecimal("FARK_FAIZI_TAKSIT_ONCEKI"));

			session.saveOrUpdate(birKrediOdemeplaniGunTx);
			session.flush();
			
			GMMap iMap2 = new GMMap();
			iMap2.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			iMap2.put("PHONE_NUM", iMap.getBigDecimal("SOZLESME_CEP"));
			iMap2.put("EMAIL", iMap.getString("SOZLESME_EMAIL"));
			iMap2.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			
			String islemTipi = iMap.getString("ISLEM_TIPI");

			iMap.put("TRX_NAME", "3199");
			iMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
			if("2".equals(islemTipi) || "3".equals(islemTipi) || "5".equals(islemTipi)){
				GMServiceExecuter.call("BNSPR_TRN3199_SEND_EMAIL_SMS_BEFORE_SAVE",iMap2);
			}
			
			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3199_SAVE_REPORT")
	public static GMMap saveReport(GMMap iMap) {
		try {

			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "MEVCUT_LIST";
			String tableName2 = "GUNCEL_LIST";

			// Eski kayitlarin silimesi (satir sayisi degismis olabilir)
			List<BirKrediOdemeplaniSatirTx> txSatirList = (List<BirKrediOdemeplaniSatirTx>) session.createCriteria(BirKrediOdemeplaniSatirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			if (txSatirList != null) {
				for (int i = 0; i < txSatirList.size(); i++) {
					session.delete(txSatirList.get(i));
				}
				session.flush();
			}

			// Guncel tablonun kaydedilmesi
			List<?> list2 = (List<?>) iMap.get(tableName2);
			if (list2 != null) {
				for (int i = 0; i < list2.size(); i++) {

					BirKrediOdemeplaniSatirTx birKrediOdemeplaniSatirTx = (BirKrediOdemeplaniSatirTx) session.createCriteria(BirKrediOdemeplaniSatirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.siraNo", iMap.getBigDecimal(tableName2, i, "SIRA_NO"))).add(Restrictions.eq("id.eskiYeni", "Y")).uniqueResult();
					if (birKrediOdemeplaniSatirTx == null) {
						birKrediOdemeplaniSatirTx = new BirKrediOdemeplaniSatirTx();
						BirKrediOdemeplaniSatirTxId birKrediOdemeplaniSatirTxId = new BirKrediOdemeplaniSatirTxId();

						birKrediOdemeplaniSatirTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
						birKrediOdemeplaniSatirTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						birKrediOdemeplaniSatirTxId.setSiraNo(iMap.getBigDecimal(tableName2, i, "SIRA_NO"));
						birKrediOdemeplaniSatirTxId.setEskiYeni("Y");
						birKrediOdemeplaniSatirTx.setId(birKrediOdemeplaniSatirTxId);
					}

					birKrediOdemeplaniSatirTx.setTaksitTarih(iMap.getDate(tableName2, i, "TAKSIT_TARIH"));
					birKrediOdemeplaniSatirTx.setTaksitTut(iMap.getBigDecimal(tableName2, i, "TAKSIT_TUT"));
					birKrediOdemeplaniSatirTx.setAnapara(iMap.getBigDecimal(tableName2, i, "ANAPARA"));
					birKrediOdemeplaniSatirTx.setFaiz(iMap.getBigDecimal(tableName2, i, "FAIZ"));
					birKrediOdemeplaniSatirTx.setKkdf(iMap.getBigDecimal(tableName2, i, "KKDF"));
					birKrediOdemeplaniSatirTx.setBsmv(iMap.getBigDecimal(tableName2, i, "BSMV"));
					birKrediOdemeplaniSatirTx.setMasraf(iMap.getBigDecimal(tableName2, i, "MASRAF"));
					birKrediOdemeplaniSatirTx.setDurumKod(iMap.getString(tableName2, i, "DURUM_KOD"));
					birKrediOdemeplaniSatirTx.setKalanAnapara(iMap.getBigDecimal(tableName2, i, "KALAN_ANAPARA"));

					session.save(birKrediOdemeplaniSatirTx);

				}
				session.flush();
			}

			// Mevcut tablosu al�n�r ve eski de�erler olarak i�aretlenir.

			List<?> list = (List<?>) iMap.get(tableName);
			if (list != null) {
				for (int i = 0; i < list.size(); i++) {

					BirKrediOdemeplaniSatirTx birKrediOdemeplaniSatirTx = (BirKrediOdemeplaniSatirTx) session.createCriteria(BirKrediOdemeplaniSatirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.siraNo", iMap.getBigDecimal(tableName, i, "SIRA_NO"))).add(Restrictions.eq("id.eskiYeni", "E")).uniqueResult();
					if (birKrediOdemeplaniSatirTx == null) {
						birKrediOdemeplaniSatirTx = new BirKrediOdemeplaniSatirTx();
						BirKrediOdemeplaniSatirTxId birKrediOdemeplaniSatirTxId = new BirKrediOdemeplaniSatirTxId();

						birKrediOdemeplaniSatirTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
						birKrediOdemeplaniSatirTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
						birKrediOdemeplaniSatirTxId.setSiraNo(iMap.getBigDecimal(tableName, i, "SIRA_NO"));
						birKrediOdemeplaniSatirTxId.setEskiYeni("E");

						birKrediOdemeplaniSatirTx.setId(birKrediOdemeplaniSatirTxId);
					}

					birKrediOdemeplaniSatirTx.setTaksitTarih(iMap.getDate(tableName, i, "TAKSIT_TARIH"));
					birKrediOdemeplaniSatirTx.setTaksitTut(iMap.getBigDecimal(tableName, i, "TAKSIT_TUT"));
					birKrediOdemeplaniSatirTx.setAnapara(iMap.getBigDecimal(tableName, i, "ANAPARA"));
					birKrediOdemeplaniSatirTx.setFaiz(iMap.getBigDecimal(tableName, i, "FAIZ"));
					birKrediOdemeplaniSatirTx.setKkdf(iMap.getBigDecimal(tableName, i, "KKDF"));
					birKrediOdemeplaniSatirTx.setBsmv(iMap.getBigDecimal(tableName, i, "BSMV"));
					birKrediOdemeplaniSatirTx.setMasraf(iMap.getBigDecimal(tableName, i, "MASRAF"));
					birKrediOdemeplaniSatirTx.setDurumKod(iMap.getString(tableName, i, "DURUM_KOD"));
					birKrediOdemeplaniSatirTx.setKalanAnapara(iMap.getBigDecimal(tableName, i, "KALAN_ANAPARA"));

					session.save(birKrediOdemeplaniSatirTx);
				}
				session.flush();
			}

			BirKrediOdemeplaniGunTx birKrediOdemeplaniGunTx = (BirKrediOdemeplaniGunTx) session.createCriteria(BirKrediOdemeplaniGunTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

			// Ust alanlar�n kaydedilmesi
			if (birKrediOdemeplaniGunTx == null)
				birKrediOdemeplaniGunTx = new BirKrediOdemeplaniGunTx();

			birKrediOdemeplaniGunTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			birKrediOdemeplaniGunTx.setGerekceKod(iMap.getString("GEREKCE_KOD"));
			birKrediOdemeplaniGunTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birKrediOdemeplaniGunTx.setIslemTip(iMap.getString("ISLEM_TIPI"));
			birKrediOdemeplaniGunTx.setKullandirimYapilmisMi("1".equals(iMap.getString("ISLEM_TIPI")) ? "H" : "E");

			birKrediOdemeplaniGunTx.setBsmvOrani(iMap.getBigDecimal("BSMV_ORANI"));
			birKrediOdemeplaniGunTx.setDosyaMasrafi(iMap.getBigDecimal("DOSYA_MASRAFI"));
			birKrediOdemeplaniGunTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI"));
			birKrediOdemeplaniGunTx.setFarkFaizi(iMap.getBigDecimal("FARK_FAIZI"));
			birKrediOdemeplaniGunTx.setGecikmeFaizOrani(iMap.getBigDecimal("GECIKME_FAIZ_ORANI"));
			birKrediOdemeplaniGunTx.setIlkTaksitTarihi(iMap.getDate("ILK_TAKSIT_TARIHI"));
			birKrediOdemeplaniGunTx.setIlkTaksitYontem(iMap.getString("ILK_TAKSIT_YONTEM"));
			birKrediOdemeplaniGunTx.setKkdfOrani(iMap.getBigDecimal("KKDF_ORANI"));
			birKrediOdemeplaniGunTx.setSigortaPrimi(iMap.getBigDecimal("SIGORTA_PRIMI"));
			if (iMap.getString("URUN_KAMP_KOD") == null) {
				birKrediOdemeplaniGunTx.setKampKod(iMap.getBigDecimal("KAMP_KOD"));
				birKrediOdemeplaniGunTx.setKrediAltTur(iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
				birKrediOdemeplaniGunTx.setKrediAltTur2(iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
				birKrediOdemeplaniGunTx.setKampKnlKod(iMap.getBigDecimal("KAMP_KNL_KOD"));
			}
			else if (iMap.getString("URUN_KAMP_KOD").indexOf('-') < 0) {
				birKrediOdemeplaniGunTx.setKampKod(iMap.getBigDecimal("KAMP_KOD"));
				birKrediOdemeplaniGunTx.setKrediAltTur(null);
				birKrediOdemeplaniGunTx.setKrediAltTur2(null);
				birKrediOdemeplaniGunTx.setKampKnlKod(iMap.getBigDecimal("KAMP_KNL_KOD"));
			}
			else {
				birKrediOdemeplaniGunTx.setKampKod(null);
				birKrediOdemeplaniGunTx.setKrediAltTur(iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
				birKrediOdemeplaniGunTx.setKrediAltTur2(iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
				birKrediOdemeplaniGunTx.setKampKnlKod(null);
			}
			birKrediOdemeplaniGunTx.setKrediTur(iMap.getBigDecimal("KREDI_TUR"));
			birKrediOdemeplaniGunTx.setKrediTutar(iMap.getBigDecimal("KREDI_TUTAR"));
			birKrediOdemeplaniGunTx.setOdemeTipKod(iMap.getString("ODEME_TIP_KOD"));
			birKrediOdemeplaniGunTx.setOdemeTipOran(iMap.getBigDecimal("ODEME_TIP_ORAN"));
			birKrediOdemeplaniGunTx.setOdemeTipPeriyod(iMap.getBigDecimal("ODEME_TIP_PERIYOD"));
			birKrediOdemeplaniGunTx.setOdemeTipTut(iMap.getBigDecimal("ODEME_TIP_TUT"));
			birKrediOdemeplaniGunTx.setOdemeTipVade(iMap.getBigDecimal("ODEME_TIP_VADE"));
			birKrediOdemeplaniGunTx.setOtelemeGunSayisi(iMap.getBigDecimal("OTELEME_GUN_SAYISI"));
			birKrediOdemeplaniGunTx.setPttMaasTarihSikligi(iMap.getBigDecimal("PTT_MAAS_TARIH_SIKLIGI"));
			birKrediOdemeplaniGunTx.setSerbestKatkiPayi(iMap.getBigDecimal("SERBEST_KATKI_PAYI"));
			birKrediOdemeplaniGunTx.setSozlesmeFaizi(iMap.getBigDecimal("SOZLESME_FAIZI"));
			birKrediOdemeplaniGunTx.setSozlesmeTarihi(iMap.getDate("SOZLESME_TARIHI"));
			birKrediOdemeplaniGunTx.setVade(iMap.getBigDecimal("VADE"));
			birKrediOdemeplaniGunTx.setVadesizHesapNo(iMap.getBigDecimal("VADESIZ_HESAP_NO"));
			birKrediOdemeplaniGunTx.setEskiKrediTutari(iMap.getBigDecimal("ESKI_KREDI_TUTARI"));
			birKrediOdemeplaniGunTx.setEskiSerbestKatkiPayi(iMap.getBigDecimal("ESKI_SERBEST_KATKI_PAYI"));
			birKrediOdemeplaniGunTx.setMusHesapNo(iMap.getBigDecimal("MUS_HESAP_NO"));
			birKrediOdemeplaniGunTx.setBayiHesapNo(iMap.getBigDecimal("BAYI_HESAP_NO"));
			birKrediOdemeplaniGunTx.setDistHesapNo(iMap.getBigDecimal("DIST_HESAP_NO"));
			birKrediOdemeplaniGunTx.setKrdHesapNo(iMap.getBigDecimal("KRD_HESAP_NO"));
			birKrediOdemeplaniGunTx.setCostRatio(iMap.getBigDecimal("YILLIK_MALIYET"));
			birKrediOdemeplaniGunTx.setTaksitGunu(iMap.getBigDecimal("TAKSIT_GUNU"));
			birKrediOdemeplaniGunTx.setTaksitGunuAysonuMu(iMap.getBoolean("AY_SONU") ? "E" : "H");
			birKrediOdemeplaniGunTx.setOtelemeAySayisi(iMap.getBigDecimal("OTELEME_AY_SAYISI"));

			birKrediOdemeplaniGunTx.setSozlesmeCepTel(iMap.getBigDecimal("SOZLESME_CEP"));
			birKrediOdemeplaniGunTx.setSozlesmeEmail(iMap.getString("SOZLESME_EMAIL"));
			birKrediOdemeplaniGunTx.setGecikmeFaizTutari(iMap.getBigDecimal("GECIKME_FAIZ_TUTARI"));

			session.saveOrUpdate(birKrediOdemeplaniGunTx);
			session.flush();

			return new GMMap();

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3199_AFTER_CANCEL_ODEME_PLANI")
	public static GMMap afterCancelOdemePlani(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			if (trxNo != null) {
				@SuppressWarnings("unchecked")
				List<BirKrediOdemeplaniSatirTx> txSatirList = (List<BirKrediOdemeplaniSatirTx>) session.createCriteria(BirKrediOdemeplaniSatirTx.class).add(Restrictions.eq("id.txNo", trxNo)).list();
				if (txSatirList != null) {
					for (int i = 0; i < txSatirList.size(); i++) {
						session.delete(txSatirList.get(i));
					}
					session.flush();
				}
				BirKrediOdemeplaniGunTx birKrediOdemeplaniGunTx = (BirKrediOdemeplaniGunTx) session.createCriteria(BirKrediOdemeplaniGunTx.class).add(Restrictions.eq("txNo", trxNo)).uniqueResult();
				if (birKrediOdemeplaniGunTx != null) {
					session.delete(birKrediOdemeplaniGunTx);
					session.flush();
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3199_BASVURU_LOV")
	public static GMMap getBasvuruLov(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String lov = "3199/LOV_BASVURU_" + iMap.getString("ISLEM_TIPI");
			if (iMap.getString("ISLEM_TIPI").equals("1")) {
				lov += "_VIEW";
			}
			oMap.putAll(LovHelper.diLovAll(iMap.getBigDecimal("BASVURU_NO"), iMap.getBigDecimal("MUSTERI_NO"), lov));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3199_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "MEVCUT_LIST";
			String tableName2 = "GUNCEL_LIST";

			// Guncel tablo
			List<BirKrediOdemeplaniSatirTx> list2 = (List<BirKrediOdemeplaniSatirTx>) session.createCriteria(BirKrediOdemeplaniSatirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.eskiYeni", "Y")).list();
			if (list2 != null) {
				for (int i = 0; i < list2.size(); i++) {

					BirKrediOdemeplaniSatirTx birKrediOdemeplaniSatirTx = list2.get(i);

					oMap.put(tableName2, i, "SIRA_NO", birKrediOdemeplaniSatirTx.getId().getSiraNo());
					oMap.put(tableName2, i, "TAKSIT_TARIH", birKrediOdemeplaniSatirTx.getTaksitTarih());
					oMap.put(tableName2, i, "TAKSIT_TUT", birKrediOdemeplaniSatirTx.getTaksitTut());
					oMap.put(tableName2, i, "ANAPARA", birKrediOdemeplaniSatirTx.getAnapara());
					oMap.put(tableName2, i, "FAIZ", birKrediOdemeplaniSatirTx.getFaiz());
					oMap.put(tableName2, i, "KKDF", birKrediOdemeplaniSatirTx.getKkdf());
					oMap.put(tableName2, i, "BSMV", birKrediOdemeplaniSatirTx.getBsmv());
					oMap.put(tableName2, i, "MASRAF", birKrediOdemeplaniSatirTx.getMasraf());
					oMap.put(tableName2, i, "DURUM_KOD", birKrediOdemeplaniSatirTx.getDurumKod());
					oMap.put(tableName2, i, "KALAN_ANAPARA", birKrediOdemeplaniSatirTx.getKalanAnapara());
				}
			}

			// Mevcut tablo

			List<BirKrediOdemeplaniSatirTx> list = (List<BirKrediOdemeplaniSatirTx>) session.createCriteria(BirKrediOdemeplaniSatirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.eskiYeni", "E")).list();
			if (list != null) {
				for (int i = 0; i < list.size(); i++) {

					BirKrediOdemeplaniSatirTx birKrediOdemeplaniSatirTx = list.get(i);

					oMap.put(tableName, i, "SIRA_NO", birKrediOdemeplaniSatirTx.getId().getSiraNo());
					oMap.put(tableName, i, "TAKSIT_TARIH", birKrediOdemeplaniSatirTx.getTaksitTarih());
					oMap.put(tableName, i, "TAKSIT_TUT", birKrediOdemeplaniSatirTx.getTaksitTut());
					oMap.put(tableName, i, "ANAPARA", birKrediOdemeplaniSatirTx.getAnapara());
					oMap.put(tableName, i, "FAIZ", birKrediOdemeplaniSatirTx.getFaiz());
					oMap.put(tableName, i, "KKDF", birKrediOdemeplaniSatirTx.getKkdf());
					oMap.put(tableName, i, "BSMV", birKrediOdemeplaniSatirTx.getBsmv());
					oMap.put(tableName, i, "MASRAF", birKrediOdemeplaniSatirTx.getMasraf());
					oMap.put(tableName, i, "DURUM_KOD", birKrediOdemeplaniSatirTx.getDurumKod());
					oMap.put(tableName, i, "KALAN_ANAPARA", birKrediOdemeplaniSatirTx.getKalanAnapara());
				}
			}
			GMMap dateMap = new GMMap();
			dateMap = (GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", dateMap));
			int i = 0;
			while (i < oMap.getSize(tableName)) {
				if ("ACIK".equals(oMap.getString(tableName, i, "DURUM_KOD")) && dateMap.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName, i, "TAKSIT_TARIH")) > 0 && oMap.getBigDecimal(tableName, i, "TAKSIT_TUT").compareTo(new BigDecimal(0)) == 1) {
					oMap.put(tableName, i, "DURUM_KOD_G", "GECIKMEDE");
				}
				else
					oMap.put(tableName, i, "DURUM_KOD_G", oMap.getString(tableName, i, "DURUM_KOD"));
				i++;
			}
			i = 0;
			while (i < oMap.getSize(tableName2)) {
				if ("ACIK".equals(oMap.getString(tableName2, i, "DURUM_KOD")) && dateMap.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName2, i, "TAKSIT_TARIH")) > 0 && oMap.getBigDecimal(tableName2, i, "TAKSIT_TUT").compareTo(new BigDecimal(0)) == 1) {
					oMap.put(tableName2, i, "DURUM_KOD_G", "GECIKMEDE");
				}
				else
					oMap.put(tableName2, i, "DURUM_KOD_G", oMap.getString(tableName2, i, "DURUM_KOD"));
				i++;
			}

			oMap.putAll(BeanSetProperties.tableDifference((ArrayList<?>) oMap.get(tableName), (ArrayList<?>) oMap.get(tableName2), "SIRA_NO", "setForeground", Color.RED));

			setBirKrediOdemeplaniGunMap(iMap.getBigDecimal("TRX_NO"), oMap);

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3199_SOZLESME_SONRASI_MI")
	public static GMMap getSozlesmeSonrasiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_BASVURU.Durumundan_Once_Mi(?,?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(3, "SOZLESME");
			stmt.execute();

			oMap.put("SONRA", "H".equals(stmt.getString(1)));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	private static void setBirKrediOdemeplaniGunMap(BigDecimal txNo, GMMap oMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		BirKrediOdemeplaniGunTx birKrediOdemeplaniGunTx = (BirKrediOdemeplaniGunTx) session.createCriteria(BirKrediOdemeplaniGunTx.class).add(Restrictions.eq("txNo", txNo)).uniqueResult();

		// Ust alanlar
		oMap.put("GEREKCE_KOD", birKrediOdemeplaniGunTx.getGerekceKod());
		oMap.put("BASVURU_NO", birKrediOdemeplaniGunTx.getBasvuruNo());
		oMap.put("ISLEM_TIPI", birKrediOdemeplaniGunTx.getIslemTip());
		oMap.put("BSMV_ORANI", birKrediOdemeplaniGunTx.getBsmvOrani());
		oMap.put("FAIZ_ORANI", birKrediOdemeplaniGunTx.getFaizOrani());
		oMap.put("FARK_FAIZI", birKrediOdemeplaniGunTx.getFarkFaizi());
		oMap.put("GECIKME_FAIZ_ORANI", birKrediOdemeplaniGunTx.getGecikmeFaizOrani());
		oMap.put("ILK_TAKSIT_TARIHI", birKrediOdemeplaniGunTx.getIlkTaksitTarihi());
		oMap.put("ILK_TAKSIT_YONTEM", birKrediOdemeplaniGunTx.getIlkTaksitYontem());
		oMap.put("KKDF_ORANI", birKrediOdemeplaniGunTx.getKkdfOrani());
		if (birKrediOdemeplaniGunTx.getKrediAltTur() != null) {
			oMap.put("URUN_KAMP_KOD", "" + birKrediOdemeplaniGunTx.getKrediAltTur() + "-" + birKrediOdemeplaniGunTx.getKrediAltTur2());
		}
		else {
			oMap.put("URUN_KAMP_KOD", birKrediOdemeplaniGunTx.getKampKod());
		}
		oMap.put("KAMP_KOD", birKrediOdemeplaniGunTx.getKampKod());
		oMap.put("KRD_TUR_ALT_KOD", birKrediOdemeplaniGunTx.getKrediAltTur());
		oMap.put("KRD_TUR_ALT_KOD2", birKrediOdemeplaniGunTx.getKrediAltTur2());
		oMap.put("KAMP_KNL_KOD", birKrediOdemeplaniGunTx.getKampKnlKod());
		oMap.put("KREDI_TUR", birKrediOdemeplaniGunTx.getKrediTur());
		oMap.put("KREDI_TUTAR", birKrediOdemeplaniGunTx.getKrediTutar());
		oMap.put("ODEME_TIP_KOD", birKrediOdemeplaniGunTx.getOdemeTipKod());
		oMap.put("ODEME_TIP_ORAN", birKrediOdemeplaniGunTx.getOdemeTipOran());
		oMap.put("ODEME_TIP_PERIYOD", birKrediOdemeplaniGunTx.getOdemeTipPeriyod());
		oMap.put("ODEME_TIP_TUT", birKrediOdemeplaniGunTx.getOdemeTipTut());
		oMap.put("ODEME_TIP_VADE", birKrediOdemeplaniGunTx.getOdemeTipVade());
		oMap.put("OTELEME_GUN_SAYISI", birKrediOdemeplaniGunTx.getOtelemeGunSayisi());
		oMap.put("PTT_MAAS_TARIH_SIKLIGI", birKrediOdemeplaniGunTx.getPttMaasTarihSikligi());
		oMap.put("SERBEST_KATKI_PAYI", birKrediOdemeplaniGunTx.getSerbestKatkiPayi());
		oMap.put("SOZLESME_FAIZI", birKrediOdemeplaniGunTx.getSozlesmeFaizi());
		oMap.put("SOZLESME_TARIHI", birKrediOdemeplaniGunTx.getSozlesmeTarihi());
		oMap.put("VADE", birKrediOdemeplaniGunTx.getVade());
		oMap.put("VADESIZ_HESAP_NO", birKrediOdemeplaniGunTx.getVadesizHesapNo());
		oMap.put("ESKI_KREDI_TUTARI", birKrediOdemeplaniGunTx.getEskiKrediTutari());
		oMap.put("ESKI_SERBEST_KATKI_PAYI", birKrediOdemeplaniGunTx.getEskiSerbestKatkiPayi());
		oMap.put("MUS_HESAP_NO", birKrediOdemeplaniGunTx.getMusHesapNo());
		oMap.put("BAYI_HESAP_NO", birKrediOdemeplaniGunTx.getBayiHesapNo());
		oMap.put("DIST_HESAP_NO", birKrediOdemeplaniGunTx.getDistHesapNo());
		oMap.put("KRD_HESAP_NO", birKrediOdemeplaniGunTx.getKrdHesapNo());
		oMap.put("DOSYA_MASRAFI", birKrediOdemeplaniGunTx.getDosyaMasrafi());
		oMap.put("SIGORTA_PRIMI", birKrediOdemeplaniGunTx.getSigortaPrimi());
		if (null == (birKrediOdemeplaniGunTx.getTaksitGunuAysonuMu()))
			oMap.put("AY_SONU", false);
		else
			oMap.put("AY_SONU", (birKrediOdemeplaniGunTx.getTaksitGunuAysonuMu().equals("E")) ? true : false);
		oMap.put("TAKSIT_GUNU", birKrediOdemeplaniGunTx.getTaksitGunu());
		oMap.put("YILLIK_MALIYET", birKrediOdemeplaniGunTx.getCostRatio());
		oMap.put("OTELEME_AY_SAYISI", birKrediOdemeplaniGunTx.getOtelemeAySayisi());

	}

	/**
	 * procedure Oteleme_gun_Hesapla( pd_taksit_tarihi date,
	 * pd_sozlesme_tarihi date,
	 * pn_odeme_tipi number,
	 * pn_odeme_periyodu number,
	 * pn_oteleme_gun_sayisi out number,
	 * pd_ilk_odeme_tarihi out date,
	 * pc_taksit_gunu out varchar2,
	 * pb_odeme_gun_hatali out boolean );
	 */
	@GraymoundService("BNSPR_TRN3199_OTELEME_GUN_HESAPLA")
	public static GMMap otelemeGunHesapla(GMMap iMap) {
		GMMap oMap = new GMMap(), mMap = new GMMap();
		try {
			/**
			 * TY-319
			 */
			BigDecimal odemePeriyodu2 = BigDecimal.ZERO;
			BigDecimal pttMaasSikligi = BigDecimal.ONE;
			BigDecimal ilkAcikTaksitNo = BigDecimal.ONE;

			if (iMap.getString("PTT_MAAS_SIKLIGI") != null && !iMap.getString("PTT_MAAS_SIKLIGI").isEmpty()) {
				pttMaasSikligi = iMap.getString("PTT_MAAS_SIKLIGI").equals("0") ? BigDecimal.ONE : iMap.getBigDecimal("PTT_MAAS_SIKLIGI");
			}
			if (iMap.getString("ILK_ACIK_TAKSIT_NO") != null && !iMap.getString("ILK_ACIK_TAKSIT_NO").isEmpty()) {
				ilkAcikTaksitNo = iMap.getString("ILK_ACIK_TAKSIT_NO").equals("0") ? BigDecimal.ONE : iMap.getBigDecimal("ILK_ACIK_TAKSIT_NO");
			}
			if (iMap.getString("ODEME_VADESI") != null && !iMap.getString("ODEME_VADESI").isEmpty()) {
				odemePeriyodu2 = iMap.getBigDecimal("ODEME_VADESI");
			}
			if (iMap.getString("ODEME_PERIYODU") != null && !iMap.getString("ODEME_PERIYODU").isEmpty()) {
				odemePeriyodu2 = iMap.getBigDecimal("ODEME_PERIYODU");
			}
			String procStr = "{call BNSPR.PKG_trn3199.Oteleme_gun_Hesapla (?,?,?,?,?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[12];
			Object[] outputValues = new Object[10];
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("TAKSIT_GUNU");
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("SOZLESME_TARIHI");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ODEME_TIPI");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = odemePeriyodu2;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = pttMaasSikligi;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = ilkAcikTaksitNo;
			i = 0;
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "OTELEME_GUN_SAYISI";
			outputValues[i++] = BnsprType.DATE;
			outputValues[i++] = "ODENMEK_ISTENILEN_TARIH";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "TAKSIT_GUNU";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "ODEME_GUNU_HATALI";
			outputValues[i++] = BnsprType.STRING;
			outputValues[i++] = "AY_SONU_MU";

			mMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

			mMap.put("ODENMEK_ISTENILEN_TARIH", mMap.getString("ODENMEK_ISTENILEN_TARIH"));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return mMap;

	}

	@GraymoundService("BNSPR_TRN3199_GET_COMBOBOX_INITIAL_VALUES")
	public static GMMap getComboboxInitialValues(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		CallableStatement stmt3 = null;
		ResultSet rSet = null;

		Session session = DAOSession.getSession("BNSPRDal");
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3181.FarkFaiziOdemeSekli2(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			String listName = "FAIZ_ODEME_SEKLI_LIST";
			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString("KEY1"), rSet.getString("TEXT"));
			}

			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "BIR_FARK_FAIZ_SEKLI_KOD");
			oMap.put("FAIZ_ODEME_SEKLI_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			DALUtil.fillComboBox(oMap, "ODEME_TIP_LIST", true, "select kod,aciklama from bir_odm_tip_pr where kod <> 1");

			/* Son G�ncelleme Gerek�esi */
			stmt2 = conn.prepareCall("{? = call PKG_TRN3199.Son_Guncelleme_Gerekcesi(?)}");
			stmt2.registerOutParameter(1, Types.VARCHAR);
			stmt2.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt2.execute();

			oMap.put("SON_ISLEM_GEREKCE", stmt2.getString(1));

			/* E-posta ve Telefon Bilgileri */
			BirBasvuru b = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			GMMap tMap = new GMMap();
			tMap.put("CUSTOMER_NO", b.getMusteriNo());

			// tMap = GMServiceExecuter.call("BNSPR_CUSTOMER_GET_CUSTOMER_CONTACT_PHONE_NO", tMap);
			tMap.putAll(GMServiceExecuter.execute("BNSPR_GET_CUSTOMER_OTP", tMap));

			String phoneNum = StringUtils.EMPTY;
			phoneNum = tMap.getString("PHONE_NUMBER");
			if (StringUtils.isNotEmpty(phoneNum)) {
				if (phoneNum.length() > 11) {
					oMap.put("PHONE_NUMBER", phoneNum.substring(phoneNum.length() - 11, phoneNum.length()));
				}
				else {
					oMap.put("PHONE_NUMBER", phoneNum);
				}
			}

			stmt3 = conn.prepareCall("{? = call Pkg_musteri.email_kisisel(?)}");
			stmt3.registerOutParameter(1, Types.VARCHAR);
			stmt3.setBigDecimal(2, b.getMusteriNo());
			stmt3.execute();

			oMap.put("EMAIL_ADDRESS", stmt3.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(stmt3);
			GMServerDatasource.close(conn);
		}

	}

	@GraymoundService("BNSPR_TRN3199_NEW_GUNCEL_LIST")
	public static GMMap getNewGuncelList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		GMMap dateMap = new GMMap();
		dateMap = (GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", dateMap));
		BigDecimal farkFaizi = BigDecimal.ZERO;

		try {
			GMMap oMap = new GMMap();

			/**
			 * pn_basvuruNo number, pc_islemTip varchar2, pn_krediTutar number, pn_vade number, pd_sozlesmeTaksitTarihi
			 * date default null pn_gecikmeGunSayisi number default 0, pn_serbestKatkiPayi number, pn_dosyaMasrafi
			 * number, pn_farkFaizi number, pc_ilkTaksitYontem varchar2, pn_faizOrani number, pn_kkdfOrani number,
			 * pn_bsmvOrani number, pn_odemeTipKod number pn_odemeTipVade number, pn_odemeTipPeriyod number,
			 * pn_odemeTipTutar number, pn_odemeTipOran number, pn_pttMaasOdemeSikligi number, prc_recordList out
			 * RC_3199, pn_sozlesmeFaizi in out number, pn_yillikMaaliyet out number
			 */
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call pkg_trn3199.RC_GET_NEW_ODEME_PLANI(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setString(i++, iMap.getString("ISLEM_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("VADE"));
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("SOZLESME_TARIHI").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("OTELEME_GUN_SAYISI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SERBEST_KATKI_PAYI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("DOSYA_MASRAFI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FARK_FAIZI"));
			stmt.setString(i++, iMap.getString("ILK_TAKSIT_YONTEM"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BAZ_FAIZ"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KKDF_ORANI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BSMV_ORANI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ODEME_TIP_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ODEME_TIP_VADE"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ODEME_TIP_PERIYOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ODEME_TIP_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ODEME_TIP_ORAN"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("PTT_MAAS_ODEME_SIKLIGI"));
			stmt.setString(i++, iMap.getString("SOZLESME_TELEFON"));
			stmt.setString(i++, iMap.getString("SOZLESME_EMAIL"));
			stmt.registerOutParameter(i++, -10); // ref cursor
			// INOUT
			stmt.registerOutParameter(i, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SOZLESME_FAIZI"));
			//
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("OTELEME_TAKSIT_SAYISI"));
			stmt.registerOutParameter(i, Types.NUMERIC);
			stmt.execute();

			oMap.put("FARK_FAIZI_TAKSIT", stmt.getBigDecimal(i));
			i--;
			oMap.put("YILLIK_MALIYET", stmt.getBigDecimal(--i));
			oMap.put("SOZLESME_FAIZI", stmt.getBigDecimal(--i));
			rSet = (ResultSet) stmt.getObject(--i);

			String tableName = "GUNCEL_LIST";
			String tableName2 = "MEVCUT_LIST";

			// Yeni Listenin Olusturulmasi
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "SIRA_NO", rSet.getBigDecimal("ORDER_NO"));
				int mevcutRow = -1;
				for (int j = 0; j < iMap.getSize(tableName2); j++) {
					if (oMap.getBigDecimal(tableName, row, "SIRA_NO").equals(iMap.getBigDecimal(tableName2, j, "SIRA_NO"))) {
						mevcutRow = j;
						break;
					}
				}
				if (mevcutRow != -1) {
					oMap.put(tableName, row, "DURUM_KOD", iMap.getString(tableName2, mevcutRow, "DURUM_KOD"));
					oMap.put(tableName, row, "MASRAF", iMap.getBigDecimal(tableName2, mevcutRow, "MASRAF"));
				}
				else {
					oMap.put(tableName, row, "DURUM_KOD", "ACIK");
					oMap.put(tableName, row, "MASRAF", BigDecimal.ZERO);
				}
				oMap.put(tableName, row, "TAKSIT_TARIH", rSet.getDate("DUEDATE"));
				oMap.put(tableName, row, "TAKSIT_TUT", rSet.getBigDecimal("INSTALMENTAMOUNT"));
				oMap.put(tableName, row, "ANAPARA", rSet.getBigDecimal("PRINCIPALAMOUNT"));
				oMap.put(tableName, row, "FAIZ", rSet.getBigDecimal("INTERESTAMOUNT"));
				oMap.put(tableName, row, "KKDF", rSet.getBigDecimal("TAX1"));
				oMap.put(tableName, row, "BSMV", rSet.getBigDecimal("TAX2"));
				oMap.put(tableName, row++, "KALAN_ANAPARA", rSet.getBigDecimal("REMAININGPRINCIPALAMOUNT"));
				farkFaizi = farkFaizi.add(rSet.getBigDecimal("OVERDUEINTEREST"));
			}

			if (oMap.get("FARK_FAIZI_TAKSIT") != null) {
				oMap.put("FARK_FAIZI", farkFaizi.setScale(2, RoundingMode.HALF_UP).add(oMap.getBigDecimal("FARK_FAIZI_TAKSIT")));
			}

			if (iMap.getString("ISLEM_TIPI").equalsIgnoreCase("2")) { // Kredi Taksitlerinde De�i�iklik
				i = 0;
				while (i < oMap.getSize(tableName)) {
					if ("KISMI".equals(oMap.getString(tableName, i, "DURUM_KOD"))) {
						oMap.put(tableName, i, "DURUM_KOD", "ACIK");
					}
					i++;
				}
			}

			i = 0;
			while (i < oMap.getSize(tableName)) {
				if ("ACIK".equals(oMap.getString(tableName, i, "DURUM_KOD")) && dateMap.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName, i, "TAKSIT_TARIH")) > 0 && oMap.getBigDecimal(tableName, i, "TAKSIT_TUT").compareTo(new BigDecimal(0)) == 1) {
					oMap.put(tableName, i, "DURUM_KOD_G", "GECIKMEDE");
				}
				else
					oMap.put(tableName, i, "DURUM_KOD_G", oMap.getString(tableName, i, "DURUM_KOD"));
				i++;
			}
			i = 0;
			while (i < oMap.getSize(tableName2)) {
				if ("ACIK".equals(oMap.getString(tableName2, i, "DURUM_KOD")) && dateMap.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName2, i, "TAKSIT_TARIH")) > 0 && oMap.getBigDecimal(tableName, i, "TAKSIT_TUT").compareTo(new BigDecimal(0)) == 1) {
					oMap.put(tableName2, i, "DURUM_KOD_G", "GECIKMEDE");
				}
				else
					oMap.put(tableName2, i, "DURUM_KOD_G", oMap.getString(tableName2, i, "DURUM_KOD"));
				i++;
			}
			// Renklendirme
			oMap.putAll(BeanSetProperties.tableDifference((ArrayList<?>) iMap.get("MEVCUT_LIST"), (ArrayList<?>) oMap.get("GUNCEL_LIST"), "SIRA_NO", "setForeground", Color.RED));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3199_ODEME_PLANI_TARIHCE")
	public static GMMap getTarihce(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3199.Kredi_Guncelleme_Tarihce(?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetResults(rSet, "TABLO");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3199_LIST_GUNCELLENEBILIR_MI")
	public static GMMap getListGuncellenebilirMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3199.Odeme_Plani_Guncellenebilir_Mi(?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3199_GECIKME_FAIZ_ORAN")
	public static GMMap getGecikmeFaizOrani(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_Bireysel.GecikmeOranKatsayi(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("KRD_TUR"));
			stmt.execute();

			oMap.put("SONUC", stmt.getBigDecimal(1));
			oMap.put("GECIKME_FAIZ_ORAN", iMap.getBigDecimal("FAIZ_ORAN").multiply(oMap.getBigDecimal("SONUC")));
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3199_TOPLAM_GUNCELLE")
	public static GMMap getToplamGuncelle(GMMap iMap) {

		GMMap oMap = new GMMap();

		// Toplamlar
		BigDecimal sumTaksitTutari = BigDecimal.ZERO;
		BigDecimal sumAnapara = BigDecimal.ZERO;
		BigDecimal sumFaiz = BigDecimal.ZERO;
		BigDecimal sumKKDF = BigDecimal.ZERO;
		BigDecimal sumBSMV = BigDecimal.ZERO;

		String tableName = "GUNCEL";

		List<?> list = (List<?>) iMap.get(tableName);
		for (int i = 0; i < list.size(); i++) {

			float kalanAnapara = Float.valueOf(iMap.getString(tableName, i, "KALAN_ANAPARA")).floatValue();
			float anapara = Float.valueOf(iMap.getString(tableName, i, "ANAPARA")).floatValue();

			// Toplamlar�n hesaplanmas�

			if (iMap.getString(tableName, i, "DURUM_KOD").equals("ACIK")) {
				sumTaksitTutari = sumTaksitTutari.add(iMap.getBigDecimal(tableName, i, "TAKSIT_TUT"));
				sumAnapara = sumAnapara.add(iMap.getBigDecimal(tableName, i, "ANAPARA"));
				sumFaiz = sumFaiz.add(iMap.getBigDecimal(tableName, i, "FAIZ"));
				sumKKDF = sumKKDF.add(iMap.getBigDecimal(tableName, i, "KKDF"));
				sumBSMV = sumBSMV.add(iMap.getBigDecimal(tableName, i, "BSMV"));
			}
			else if (iMap.getString(tableName, i, "DURUM_KOD").equals("KISMI")) {
				sumTaksitTutari = sumTaksitTutari.add(iMap.getBigDecimal(tableName, i, "KALAN_ANAPARA"));
				if (kalanAnapara >= anapara) {
					sumAnapara = sumAnapara.add(iMap.getBigDecimal(tableName, i, "ANAPARA"));
				}
				else {
					sumAnapara = sumAnapara.add(iMap.getBigDecimal(tableName, i, "KALAN_ANAPARA"));
				}
			}
		}
		oMap.put("SUM_TAKSIT_TUTAR", sumTaksitTutari);
		oMap.put("SUM_ANAPARA", sumAnapara);
		oMap.put("SUM_FAIZ", sumFaiz);
		oMap.put("SUM_KKDF", sumKKDF);
		oMap.put("SUM_BSMV", sumBSMV);

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3199_ARA_ODEME_TAKSIT_GUNU_DISI_KONTROL")
	public static GMMap araOdemeTaksitGunuDisiKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call Pkg_trn3133.ara_odeme_taksit_gunu_disi(?,?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setDate(2, new java.sql.Date(iMap.getDate("ODENECEK_TAKSIT_VADE").getTime()));
			stmt.setBigDecimal(3, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();
			oMap.put("DEGER", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3199_GET_AY_SONU")
	public static GMMap getAySonu(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(iMap.getDate("SOZLESME_TARIHI"));
			int i = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
			calendar.set(Calendar.DATE, i);
			long k = (calendar.getTime().getTime() - iMap.getDate("SOZLESME_TARIHI").getTime()) / (1000 * 60 * 60 * 24);
			calendar.setTime(iMap.getDate("SOZLESME_TARIHI"));
			calendar.add(Calendar.MONTH, 1);
			i = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);
			calendar.set(Calendar.DATE, i);
			oMap.put("AY_SONU_TARIHI", calendar.getTime());
			oMap.put("OTELEME_GUN_SAYISI", k);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	/**
	 * 2 - Esit Odemeli
	 * 3 - Ara Odemeli
	 * 4 - Aran Odemeli
	 * 5 - Donemsel Odemeli
	 * 6 - Balon Odemeli
	 * 7 - Odemesiz Sureli
	 * 8 - Esnek Odemeli Gunluk
	 * 9 - Esnek Odemeli Haftalik
	 * 10 - Esnek Odemeli Aylik
	 * 11 - Esnek Odemeli Yillik
	 * 
	 * @param iMap
	 * @return
	 */
	/*
	 * procedure Odenmek_Istenen_Tarih( pd_sozlesme_tarihi date, 
	                             pn_odeme_tipi number, 
	                             pn_odeme_periyodu number, 
	                             pn_oteleme_gun_sayisi number,
	                             pn_taksit_gunu out number, 
	                             pd_odenmek_istenilen_tarih out date  )
	 */
	@GraymoundService("BNSPR_TRN3199_GET_ODENMEK_ISTENILEN_TARIH")
	public static GMMap getOdenmekIstenilenTarih(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			BigDecimal odemePeriyodu = BigDecimal.ZERO;
			BigDecimal pttMaasSikligi = BigDecimal.ONE;
			BigDecimal ilkAcikTaksitNo = BigDecimal.ONE;

			if (iMap.getString("PTT_MAAS_SIKLIGI") != null && !iMap.getString("PTT_MAAS_SIKLIGI").isEmpty()) {
				pttMaasSikligi = iMap.getString("PTT_MAAS_SIKLIGI").equals("0") ? BigDecimal.ONE : iMap.getBigDecimal("PTT_MAAS_SIKLIGI");
			}
			if (iMap.getString("ILK_ACIK_TAKSIT_NO") != null && !iMap.getString("ILK_ACIK_TAKSIT_NO").isEmpty()) {
				ilkAcikTaksitNo = iMap.getString("ILK_ACIK_TAKSIT_NO").equals("0") ? BigDecimal.ONE : iMap.getBigDecimal("ILK_ACIK_TAKSIT_NO");
			}
			if (iMap.getString("ODEME_VADESI") != null && !iMap.getString("ODEME_VADESI").isEmpty()) {
				odemePeriyodu = iMap.getBigDecimal("ODEME_VADESI");
			}
			if (iMap.getString("ODEME_PERIYODU") != null && !iMap.getString("ODEME_PERIYODU").isEmpty()) {
				odemePeriyodu = iMap.getBigDecimal("ODEME_PERIYODU");
			}
			String procStr = "{call BNSPR.PKG_trn3199.Odenmek_Istenen_Tarih (?,?,?,?,?,?,?,?)}";
			int i = 0;
			Object[] inputValues = new Object[12];
			Object[] outputValues = new Object[4];
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("SOZLESME_TARIHI");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("ODEME_TIPI");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = odemePeriyodu;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("OTELEME_GUN_SAYISI");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = pttMaasSikligi;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = ilkAcikTaksitNo;
			i = 0;
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "TAKSIT_GUNU";
			outputValues[i++] = BnsprType.DATE;
			outputValues[i++] = "ODENMEK_ISTENILEN_TARIH";
			oMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3199_GET_SOBF_REPORT")
	public static GMMap getReports(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;

		Session session = DAOSession.getSession("BNSPRDal");
		try {

			JasperPrint jasperPrint = null;
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			ArrayDeque<String> reports = new ArrayDeque<String>();

			String currentDateStr = new SimpleDateFormat("dd.MM.yyyy").format(Calendar.getInstance().getTime());

			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			if ("E".equals(birBasvuru.getFaizsizFinansman())) {
				reports.add("BNSPR_RAP3199_SOBF_1_FZ");
				reports.add("BNSPR_RAP3199_SOBF_2_FZ");
			}
			else {
				reports.add("BNSPR_RAP3199_SOBF_1");
				reports.add("BNSPR_RAP3199_SOBF_2");
			}

			// Page 1
			parameters.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			parameters.put("GUNCEL_BORC", iMap.getBigDecimal("GUNCEL_BORC"));

			// Page 2
			parameters.put("AD_SOYAD", iMap.getString("AD_SOYAD").toString());
			parameters.put("ILETISIM_NO", iMap.getBigDecimal("ILETISIM_NO").toString());
			parameters.put("EMAIL", iMap.getString("EMAIL").toString());
			parameters.put("VADESIZ_HESAP_NO", iMap.getBigDecimal("VADESIZ_HESAP_NO").toString());
			parameters.put("TARIH", currentDateStr);

			BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			if (birBasvuruKimlik != null) {
				parameters.put("TCKN", birBasvuruKimlik.getTcKimlikNo());
			}

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_MUSTERI.adres_extre(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.execute();

			String adres = stmt.getString(1);
			adres = adres.replaceAll("\n", "").replaceAll("\r", "").replaceAll("  ", " ");

			parameters.put("ADRES", adres);

			jasperPrint = ReportUtil.generateAndConcatReports(reports, parameters);

			oMap.put("REPORT", jasperPrint);

			reports = new ArrayDeque<String>();

			parameters.put("IBAN", (String) DALUtil.callOneParameterFunction("{? = call Pkg_Iban.sp_IBAN_al(pkg_trn3181.onceki_basvuru_hesap_no(?))}", Types.VARCHAR, iMap.getBigDecimal("BASVURU_NO")));
			parameters.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));

			if ("E".equals(birBasvuru.getFaizsizFinansman())) {
				reports.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME_FZ");
			}
			else {
				reports.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME");
			}

			jasperPrint = ReportUtil.generateAndConcatReports(reports, parameters);
			oMap.put("REPORT2", jasperPrint);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3199_SEND_EMAIL_SMS_BEFORE_SAVE")
	public static GMMap newPaymentPlanSendSmsBeforeSave(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");

			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", basvuruNo)).uniqueResult();
			if (birBasvuru != null) {
				iMap.put("TCKN", birBasvuru.getTcKimlikNo());
			}

			BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, basvuruNo);

			String fileNameGeriOdeme = basvuruNo + "_GERI_ODEME_" + System.currentTimeMillis() + ".pdf";
			String fileNameSOBF = basvuruNo + "_SOBF_" + System.currentTimeMillis() + ".pdf";

			String musteriAdSoyad = StringUtils.EMPTY;
			if (birBasvuruKimlik != null) {
				musteriAdSoyad = musteriAdSoyad + birBasvuruKimlik.getAd();
				if (StringUtils.isNotEmpty(birBasvuruKimlik.getIkinciAd())) {
					musteriAdSoyad = musteriAdSoyad + " " + birBasvuruKimlik.getIkinciAd();
				}
				musteriAdSoyad = musteriAdSoyad + " " + birBasvuruKimlik.getSoyad();
			}

			GnlKanalGrupKodPr gnlKanalGrupKodPr = (GnlKanalGrupKodPr) session.createCriteria(GnlKanalGrupKodPr.class).add(Restrictions.eq("kod", birBasvuru.getKanalKodu())).uniqueResult();

			String kanalAdi = StringUtils.EMPTY;
			if (gnlKanalGrupKodPr != null) {
				kanalAdi = gnlKanalGrupKodPr.getAciklama();
			}

			String sozlesmeFormLink = StringUtils.EMPTY;

			GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", "YAPILANDIRMA_SOZLESME_URL")).uniqueResult();
			if (parametre != null) {
				sozlesmeFormLink = parametre.getDeger();
			}

			// SEND SMS
			GMMap messageMap = new GMMap();
			messageMap.put("MESSAGE_NO", "5360");
			messageMap.put("P1", musteriAdSoyad);
			messageMap.put("P2", kanalAdi);
			messageMap.put("P3", sozlesmeFormLink);
			messageMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", messageMap));

			String phoneNum = iMap.getString("PHONE_NUM");
			if (StringUtils.isNotEmpty(phoneNum)) {
				if (phoneNum.length() > 10) {
					phoneNum = phoneNum.substring(phoneNum.length() - 10, phoneNum.length());
				}
				
				GMMap smsMap = new GMMap();
				smsMap.put("MSISDN", phoneNum); // ekrandan girilen telefon no
				smsMap.put("HEADER", "AKTIF BANK");
				smsMap.put("CONTENT", messageMap.getString("ERROR_MESSAGE"));

				GMServiceExecuter.call("BNSPR_SMS_SEND_SMS", smsMap);
			}

			// SEND SMS
			
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3199_PAYMENT_PLAN_AND_SOBF", iMap));
			byte[] sobf = (byte[]) oMap.get("REPORT_SOBF");
			byte[] geriOdeme = (byte[]) oMap.get("REPORT_GERI_ODEME");

			// SEND EMAIL
			/*String emailAddress = StringUtils.EMPTY;
			emailAddress = iMap.getString("EMAIL");

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3199_PAYMENT_PLAN_AND_SOBF", iMap));
			byte[] geriOdeme = (byte[]) oMap.get("REPORT_GERI_ODEME");
			byte[] sobf = (byte[]) oMap.get("REPORT_SOBF");

			if (StringUtils.isNotEmpty(emailAddress)) {
				List<String> emailList = new ArrayList<String>();
				emailList.add(iMap.getString("EMAIL"));

				GMMap emailMap = new GMMap();
				emailMap.put("FROM", "aktifbank@aktifbank.com.tr");
				emailMap.put("RECIPIENTS_TO", emailList);
				emailMap.put("SUBJECT", "Yap�land�rmaya Konu Kredinin S�zle�me �ncesi Bilgilendirme Formu ve �deme Plan�");

				String adSoyad = StringUtils.EMPTY;
				if (birBasvuruKimlik != null) {
					if (StringUtils.isNotEmpty(birBasvuruKimlik.getIkinciAd())) {
						adSoyad = birBasvuruKimlik.getAd() + " " + birBasvuruKimlik.getIkinciAd() + " " + birBasvuruKimlik.getSoyad();
					}
					else {
						adSoyad = birBasvuruKimlik.getAd() + " " + birBasvuruKimlik.getSoyad();
					}
				}
				emailMap.put("MESSAGE_BODY", getSozlesmeOncesiEmailBanner(adSoyad, kanalAdi, basvuruNo.toString()));

				emailMap.put("IS_BODY_HTML", true);
				emailMap.put("SEND_ATTACHMENT_WITHOUT_DYS", true);
				emailMap.put("ATTACMENT_FILE_LIST", 0, "FILE_NAME", fileNameGeriOdeme);
				emailMap.put("ATTACMENT_FILE_LIST", 0, "FILE_BYTE_ARRAY", geriOdeme);
				emailMap.put("ATTACMENT_FILE_LIST", 1, "FILE_NAME", fileNameSOBF);
				emailMap.put("ATTACMENT_FILE_LIST", 1, "FILE_BYTE_ARRAY", sobf);
				GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", emailMap);
				// GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_SYSTEM_MAIL_SEND_EMAIL", emailMap);
				oMap.put("MESSAGE", "Mail ba�ar�l� �ekilde g�nderilmi�tir.");
			}*/
			// SEND EMAIL

			//BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");

			// DOCUMENT -> DYS
			GMMap dysMap = new GMMap();
			dysMap.put("DOKUMAN_ADI", fileNameSOBF);
			dysMap.put("DOKUMAN_TIPI", SOBF_DOKUMAN_KOD); // d�k�man kodu
			dysMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
			dysMap.put("REFERANS_TIPI", "2");
			dysMap.put("REFERANS_NO", basvuruNo);
			dysMap.put("TRX_NO", GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).get("TRX_NO"));
			dysMap.put("DOSYA_SAYFA", 0, "CONTENT", sobf);
			dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", fileNameSOBF);
			dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER", BigDecimal.ONE);

			dysMap.put("ONAYSIZ_ISLEM_MI", true);

			GMMap isExistMap = GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap);
			if (isExistMap.getBoolean("RESULT")) {
				GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
			}
			else {
				GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
			}

			dysMap = new GMMap();
			dysMap.put("DOKUMAN_ADI", fileNameGeriOdeme);
			dysMap.put("DOKUMAN_TIPI", YAPILANDIRMA_ODEME_PLANI_DOKUMAN_KOD); // d�k�man kodu
			dysMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
			dysMap.put("REFERANS_TIPI", "2");
			dysMap.put("REFERANS_NO", basvuruNo);
			dysMap.put("TRX_NO", GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).get("TRX_NO"));
			dysMap.put("DOSYA_SAYFA", 0, "CONTENT", geriOdeme);
			dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", fileNameGeriOdeme);
			dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER", BigDecimal.ONE);

			dysMap.put("ONAYSIZ_ISLEM_MI", true);

			isExistMap = GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap);
			if (isExistMap.getBoolean("RESULT")) {
				GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
			}
			else {
				GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
			}
			// DOCUMENT -> DYS
			/*
			GMMap cancelMap = new GMMap();
			cancelMap.put("TRX_NO", trxNo);
			GMServiceExecuter.execute("BNSPR_TRN3199_AFTER_CANCEL_ODEME_PLANI",cancelMap);
			*/
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/* 
	 * Yeni odeme Plan� olusturuldu�unda kaydedilmeden �nce   
	 * m��teriye g�nderilecek SOBF ve �deme planlar�n� i�erir
	 * 
	 * */

	@GraymoundService("BNSPR_TRN3199_PAYMENT_PLAN_AND_SOBF")
	public static GMMap createPaymentPlanAndSOBF(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;

		try {
			if (iMap.getBigDecimal("BASVURU_NO") == null || iMap.getString("TCKN") == null) {
				oMap.put("ERROR_MESSAGE", "Hatal� veya eksik parametre.");
				return oMap;
			}
			Session session = DAOSession.getSession("BNSPRDal");
			String currentDateStr = new SimpleDateFormat("dd.MM.yyyy").format(Calendar.getInstance().getTime());

			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", basvuruNo)).uniqueResult();
			if (birBasvuru == null) {
				oMap.put("ERROR_MESSAGE", "Hatal� veya eksik parametre.");
				return oMap;
			}
			else {
				if (!birBasvuru.getTcKimlikNo().equalsIgnoreCase(iMap.getString("TCKN"))) {
					oMap.put("ERROR_MESSAGE", "Hatal� veya eksik parametre.");
					return oMap;
				}
			}

			BigDecimal trxNo = null;
			if (iMap.getBigDecimal("TRX_NO") != null) {
				trxNo = iMap.getBigDecimal("TRX_NO");
			}
			else {
				String query = "select max(t.tx_no) tx_no from bir_kredi_odemeplani_satir_tx t where t.basvuru_no = ";
				String txNo = DALUtil.getResult(query + basvuruNo + "");
				if (StringUtils.isNotEmpty(txNo)) {
					trxNo = new BigDecimal(txNo);
				}
				else {
					oMap.put("ERROR_MESSAGE", "Ba�vuruya ait yap�land�rma kayd� bulunamad�.");
					return oMap;
				}
			}

			BirKrediOdemeplaniGunTx birKrediOdemeplaniGunTx = (BirKrediOdemeplaniGunTx) session.createCriteria(BirKrediOdemeplaniGunTx.class).add(Restrictions.eq("txNo", trxNo)).uniqueResult();

			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", basvuruNo);
			parameters.put("TRX_NO", trxNo);
			parameters.put("TARIH", currentDateStr);
			parameters.put("IBAN", (String) DALUtil.callOneParameterFunction("{? = call Pkg_Iban.sp_IBAN_al(pkg_trn3181.onceki_basvuru_hesap_no(?))}", Types.VARCHAR, basvuruNo));

			BirKullandirim birKullandirim = (BirKullandirim) session.get(BirKullandirim.class, basvuruNo);
			if (iMap.getString("VADESIZ_HESAP_NO") != null) {
				parameters.put("VADESIZ_HESAP_NO", iMap.getString("VADESIZ_HESAP_NO"));
			}
			else {
				parameters.put("VADESIZ_HESAP_NO", (String) DALUtil.callOneParameterFunction("{? = call pkg_trn3181.onceki_basvuru_hesap_no(?)}", Types.VARCHAR, basvuruNo));
			}
			if (iMap.getBigDecimal("GUNCEL_BORC") != null) {
				parameters.put("GUNCEL_BORC", iMap.getBigDecimal("GUNCEL_BORC"));
			}
			else {
				String query = "select sum(t.taksit_tut) from bir_kredi_odemeplani_satir_tx t where t.eski_yeni = 'Y' and t.tx_no = " + trxNo.toString();
				parameters.put("GUNCEL_BORC", new BigDecimal(DALUtil.getResult(query)));
			}

			BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, basvuruNo);
			if (birBasvuruKimlik != null) {
				if (StringUtils.isNotEmpty(birBasvuruKimlik.getIkinciAd())) {
					parameters.put("AD_SOYAD", birBasvuruKimlik.getAd() + " " + birBasvuruKimlik.getIkinciAd() + " " + birBasvuruKimlik.getSoyad());
				}
				else {
					parameters.put("AD_SOYAD", birBasvuruKimlik.getAd() + " " + birBasvuruKimlik.getSoyad());
				}
				parameters.put("TCKN", birBasvuruKimlik.getTcKimlikNo());
			}

			String phoneNum = StringUtils.EMPTY;
			if (iMap.getString("PHONE_NUM") != null) {
				phoneNum = iMap.getString("PHONE_NUM");
			}
			else {
				if (birKrediOdemeplaniGunTx != null && birKrediOdemeplaniGunTx.getSozlesmeCepTel() != null) {
					phoneNum = birKrediOdemeplaniGunTx.getSozlesmeCepTel().toString();
				}
			}

			if (StringUtils.isNotEmpty(phoneNum)) {
				if (phoneNum.length() > 11) {
					parameters.put("ILETISIM_NO", phoneNum.substring(phoneNum.length() - 11, phoneNum.length()));
				}
				else {
					parameters.put("ILETISIM_NO", phoneNum);
				}
			}

			if (iMap.getString("EMAIL") != null) {
				parameters.put("EMAIL", iMap.getString("EMAIL"));
			}
			else {
				String kisiselEmail = StringUtils.EMPTY;
				if (birKrediOdemeplaniGunTx != null && StringUtils.isNotEmpty(birKrediOdemeplaniGunTx.getSozlesmeEmail())) {
					kisiselEmail = birKrediOdemeplaniGunTx.getSozlesmeEmail();
				}
				parameters.put("EMAIL", kisiselEmail);
			}

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_MUSTERI.adres_extre(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, birKullandirim.getMusteriNo());
			stmt.execute();

			String adres = stmt.getString(1);
			adres = adres.replaceAll("\n", "").replaceAll("\r", "").replaceAll("  ", " ");

			parameters.put("ADRES", adres);

			ArrayDeque<String> reportNames = new ArrayDeque<String>();
			if ("E".equals(birBasvuru.getFaizsizFinansman())) {
				reportNames.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME_FZ");
			}
			else {
				reportNames.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME");
			}

			JasperPrint reportGeriOdeme = ReportUtil.generateAndConcatReports(reportNames, parameters);

			ArrayDeque<String> reportNames2 = new ArrayDeque<String>();
			if ("E".equals(birBasvuru.getFaizsizFinansman())) {
				reportNames2.add("BNSPR_RAP3199_SOBF_1_FZ");
				reportNames2.add("BNSPR_RAP3199_SOBF_2_FZ");
			}
			else {
				reportNames2.add("BNSPR_RAP3199_SOBF_1");
				reportNames2.add("BNSPR_RAP3199_SOBF_2");
			}

			JasperPrint reportSobf = ReportUtil.generateAndConcatReports(reportNames2, parameters);
			if (iMap.getBoolean("JASPER_PRINT")) {
				oMap.put("REPORT_GERI_ODEME_JASPER", reportGeriOdeme);
				oMap.put("REPORT_SOBF_JASPER", reportSobf);
			}
			else { /* return BYTE array */
				byte[] outReportGeriOdeme = JasperExportManager.exportReportToPdf(reportGeriOdeme);
				byte[] outReportSobf = JasperExportManager.exportReportToPdf(reportSobf);
				oMap.put("REPORT_GERI_ODEME", outReportGeriOdeme);
				oMap.put("REPORT_SOBF", outReportSobf);

				ArrayDeque<String> reportNamesConcat = new ArrayDeque<String>();
				if ("E".equals(birBasvuru.getFaizsizFinansman())) {
					reportNamesConcat.add("BNSPR_RAP3199_SOBF_1_FZ");
					reportNamesConcat.add("BNSPR_RAP3199_SOBF_2_FZ");
					reportNamesConcat.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME_FZ");
				}
				else {
					reportNamesConcat.add("BNSPR_RAP3199_SOBF_1");
					reportNamesConcat.add("BNSPR_RAP3199_SOBF_2");
					reportNamesConcat.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME");
				}

				JasperPrint reportConcat = ReportUtil.generateAndConcatReports(reportNamesConcat, parameters);
				byte[] outReportConcat = JasperExportManager.exportReportToPdf(reportConcat);

				oMap.put("REPORT_GERI_ODEME_AND_SOBF", outReportConcat);
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/* 
	 * Yeni odeme Plan� olusturuldu�unda kaydettikten sonra m��teriye   
	 * g�nderilecek Yap�land�rma Sozlesmesi ve �deme planlar�n� i�erir
	 * 
	 * */

	@GraymoundService("BNSPR_TRN3199_PAYMENT_PLAN_AND_RECONSTRUCTION")
	public static GMMap createPaymentPlanAndYapilandirmaSozlesme(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;

		try {
			if (iMap.getBigDecimal("BASVURU_NO") == null || iMap.getString("TCKN") == null) {
				oMap.put("ERROR_MESSAGE", "Hatal� veya eksik parametre.");
				return oMap;
			}

			Session session = DAOSession.getSession("BNSPRDal");
			String currentDateStr = new SimpleDateFormat("dd.MM.yyyy").format(Calendar.getInstance().getTime());

			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", basvuruNo)).uniqueResult();
			if (birBasvuru == null) {
				oMap.put("ERROR_MESSAGE", "Hatal� veya eksik parametre.");
				return oMap;
			}
			else {
				if (!birBasvuru.getTcKimlikNo().equalsIgnoreCase(iMap.getString("TCKN"))) {
					oMap.put("ERROR_MESSAGE", "Hatal� veya eksik parametre.");
					return oMap;
				}
			}

			BigDecimal trxNo = null;

			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("BASVURU_NO", basvuruNo);
			if (iMap.getBigDecimal("ISLEM_NO") != null) {
				trxNo = iMap.getBigDecimal("ISLEM_NO");
			}
			else {
				String query = "select max(tx_no) tx_no from bir_kredi_odemeplani_satir_tx t where t.basvuru_no = ";
				String txNo = DALUtil.getResult(query + basvuruNo + "");
				if (StringUtils.isNotEmpty(txNo)) {
					trxNo = new BigDecimal(txNo);
				}
				else {
					oMap.put("ERROR_MESSAGE", "Ba�vuruya ait yap�land�rma kayd� bulunamad�.");
					return oMap;
				}

			}
			parameters.put("TRX_NO", trxNo);

			String queryGuncelBorc = "select sum(t.taksit_tut) from bir_kredi_odemeplani_satir_tx t where t.eski_yeni = 'Y' and t.tx_no = " + trxNo.toString();
			if (StringUtils.isNotEmpty(queryGuncelBorc)) {
				parameters.put("GUNCEL_BORC", new BigDecimal(DALUtil.getResult(queryGuncelBorc)));
			}
			else {
				parameters.put("GUNCEL_BORC", BigDecimal.ZERO);
			}

			parameters.put("VADESIZ_HESAP_NO", (String) DALUtil.callOneParameterFunction("{? = call pkg_trn3181.onceki_basvuru_hesap_no(?)}", Types.VARCHAR, basvuruNo));
			parameters.put("TARIH", currentDateStr);

			BirKrediOdemeplaniGunTx birKrediOdemeplaniGunTx = (BirKrediOdemeplaniGunTx) session.createCriteria(BirKrediOdemeplaniGunTx.class).add(Restrictions.eq("txNo", trxNo)).uniqueResult();

			BirKullandirim birKullandirim = (BirKullandirim) session.get(BirKullandirim.class, basvuruNo);

			BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, basvuruNo);
			if (birBasvuruKimlik != null) {
				if (StringUtils.isNotEmpty(birBasvuruKimlik.getIkinciAd())) {
					parameters.put("AD_SOYAD", birBasvuruKimlik.getAd() + " " + birBasvuruKimlik.getIkinciAd() + " " + birBasvuruKimlik.getSoyad());
				}
				else {
					parameters.put("AD_SOYAD", birBasvuruKimlik.getAd() + " " + birBasvuruKimlik.getSoyad());
				}
				parameters.put("TCKN", birBasvuruKimlik.getTcKimlikNo());
			}

			String phoneNum = StringUtils.EMPTY;
			if (birKrediOdemeplaniGunTx != null && birKrediOdemeplaniGunTx.getSozlesmeCepTel() != null) {
				phoneNum = birKrediOdemeplaniGunTx.getSozlesmeCepTel().toString();
			}

			if (StringUtils.isNotEmpty(phoneNum)) {
				if (phoneNum.length() > 11) {
					parameters.put("ILETISIM_NO", phoneNum.substring(phoneNum.length() - 11, phoneNum.length()));
				}
				else {
					parameters.put("ILETISIM_NO", phoneNum);
				}
			}

			if (birKrediOdemeplaniGunTx != null && StringUtils.isNotEmpty(birKrediOdemeplaniGunTx.getSozlesmeEmail())) {
				parameters.put("EMAIL", birKrediOdemeplaniGunTx.getSozlesmeEmail());
			}
			else {
				parameters.put("EMAIL", StringUtils.EMPTY);
			}

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_MUSTERI.adres_extre(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, birKullandirim.getMusteriNo());
			stmt.execute();

			String adres = stmt.getString(1);
			adres = adres.replaceAll("\n", "").replaceAll("\r", "").replaceAll("  ", " ");

			parameters.put("ADRES", adres);
			parameters.put("IBAN", (String) DALUtil.callOneParameterFunction("{? = call Pkg_Iban.sp_IBAN_al(pkg_trn3181.onceki_basvuru_hesap_no(?))}", Types.VARCHAR, basvuruNo));

			ArrayDeque<String> reportNames = new ArrayDeque<String>();
			if ("E".equals(birBasvuru.getFaizsizFinansman())) {
				reportNames.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME_FZ");
			}
			else {
				reportNames.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME");
			}

			JasperPrint reportGeriOdeme = ReportUtil.generateAndConcatReports(reportNames, parameters);

			ArrayDeque<String> reportNames2 = new ArrayDeque<String>();
			if ("E".equals(birBasvuru.getFaizsizFinansman())) {
				reportNames2.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_1_FZ");
				reportNames2.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_2_FZ");
				reportNames2.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_3_FZ");
				reportNames2.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_4_FZ");
			}
			else {
				reportNames2.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_1");
				reportNames2.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_2");
				reportNames2.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_3");
				reportNames2.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_4");
			}

			JasperPrint reportYapilandirma = ReportUtil.generateAndConcatReports(reportNames2, parameters);
			if (iMap.getBoolean("JASPER_PRINT")) {
				oMap.put("REPORT_GERI_ODEME_JASPER", reportGeriOdeme);
				oMap.put("REPORT_YAPILANDIRMA_JASPER", reportYapilandirma);
			}
			else { /* return BYTE array */
				byte[] outReportGeriOdeme = JasperExportManager.exportReportToPdf(reportGeriOdeme);
				byte[] outReportYapilandirma = JasperExportManager.exportReportToPdf(reportYapilandirma);
				oMap.put("REPORT_GERI_ODEME", outReportGeriOdeme);
				oMap.put("REPORT_YAPILANDIRMA", outReportYapilandirma);

				ArrayDeque<String> reportNamesConcat = new ArrayDeque<String>();
				if ("E".equals(birBasvuru.getFaizsizFinansman())) {
					reportNamesConcat.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_1_FZ");
					reportNamesConcat.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_2_FZ");
					reportNamesConcat.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_3_FZ");
					reportNamesConcat.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_4_FZ");
					reportNamesConcat.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME_FZ");
				}
				else {
					reportNamesConcat.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_1");
					reportNamesConcat.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_2");
					reportNamesConcat.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_3");
					reportNamesConcat.add("BNSPR_RAP3199_YAPILANDIRMA_SOZLESME_4");
					reportNamesConcat.add("BNSPR_RAP3199_KREDI_SART_GERI_ODEME");
				}

				JasperPrint reportConcat = ReportUtil.generateAndConcatReports(reportNamesConcat, parameters);
				byte[] outReportConcat = JasperExportManager.exportReportToPdf(reportConcat);

				oMap.put("REPORT_GERI_ODEME_AND_YAPILANDIRMA", outReportConcat);
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3199_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {

		GMMap oMap = new GMMap();
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			BigDecimal islemNo = iMap.getBigDecimal("ISLEM_NO");
			BirKrediOdemeplaniGunTx birKrediOdemeplaniGunTx = (BirKrediOdemeplaniGunTx) session.createCriteria(BirKrediOdemeplaniGunTx.class).add(Restrictions.eq("txNo", islemNo)).uniqueResult();

			BigDecimal basvuruNo = null;
			if (birKrediOdemeplaniGunTx == null || !birKrediOdemeplaniGunTx.getIslemTip().equalsIgnoreCase("2")) { /* Kredi taksitlerinde de�i�iklik de�il ise */
				return oMap;
			}
			else {
				basvuruNo = birKrediOdemeplaniGunTx.getBasvuruNo();
				iMap.put("BASVURU_NO", basvuruNo);
			}

			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", basvuruNo)).uniqueResult();

			BigDecimal musteriNo = BigDecimal.ZERO;
			if (birBasvuru != null) {
				musteriNo = birBasvuru.getMusteriNo();
				iMap.put("TCKN", birBasvuru.getTcKimlikNo());
			}

			String phoneNum = StringUtils.EMPTY;
			if (birKrediOdemeplaniGunTx.getSozlesmeCepTel() != null) {
				phoneNum = birKrediOdemeplaniGunTx.getSozlesmeCepTel().toString();
				if (phoneNum.length() > 10) {
					phoneNum = phoneNum.substring(phoneNum.length() - 10, phoneNum.length());
				}
			}

			String eMailAddress = StringUtils.EMPTY;
			if (StringUtils.isNotEmpty(birKrediOdemeplaniGunTx.getSozlesmeEmail())) {
				eMailAddress = birKrediOdemeplaniGunTx.getSozlesmeEmail();
			}

			BirBasvuruKimlik birBasvuruKimlik = (BirBasvuruKimlik) session.get(BirBasvuruKimlik.class, basvuruNo);

			String musteriAdSoyad = StringUtils.EMPTY;
			if (birBasvuruKimlik != null) {
				iMap.put("TCKN", birBasvuruKimlik.getTcKimlikNo());

				musteriAdSoyad = musteriAdSoyad + birBasvuruKimlik.getAd();
				if (StringUtils.isNotEmpty(birBasvuruKimlik.getIkinciAd())) {
					musteriAdSoyad = musteriAdSoyad + " " + birBasvuruKimlik.getIkinciAd();
				}
				musteriAdSoyad = musteriAdSoyad + " " + birBasvuruKimlik.getSoyad();
			}

			GnlKanalGrupKodPr gnlKanalGrupKodPr = (GnlKanalGrupKodPr) session.createCriteria(GnlKanalGrupKodPr.class).add(Restrictions.eq("kod", birBasvuru.getKanalKodu())).uniqueResult();

			String kanalAdi = StringUtils.EMPTY;
			if (gnlKanalGrupKodPr != null) {
				kanalAdi = gnlKanalGrupKodPr.getAciklama();
			}

			String sozlesmeOnayFormLink = StringUtils.EMPTY;

			GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", "YAPILANDIRMA_ONAY_SOZLESME_URL")).uniqueResult();
			if (parametre != null) {
				sozlesmeOnayFormLink = parametre.getDeger();
			}

			// SEND SMS
			if (StringUtils.isNotEmpty(phoneNum)) {

				GMMap smsMap2 = null;
				GMMap messageMap = new GMMap();
				if (birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("1") || birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("2") || birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("3")
						|| birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("16")) {
					messageMap.put("MESSAGE_NO", "5361");
					messageMap.put("P1", musteriAdSoyad);
					messageMap.put("P2", kanalAdi);
					messageMap.put("P3", sozlesmeOnayFormLink);

					messageMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", messageMap));

					GMMap smsMap = new GMMap();
					smsMap.put("MSISDN", phoneNum); // ekrandan girilen telefon no
					smsMap.put("HEADER", "AKTIF BANK");
					smsMap.put("CONTENT", messageMap.getString("ERROR_MESSAGE")); // pkg_HATA.kodsuzMesajOlustur()

					GMServiceExecuter.call("BNSPR_SMS_SEND_SMS", smsMap);
				}
				else {
					smsMap2 = new GMMap();
					// messageMap.put("MESSAGE_NO", "5940");
					// messageMap.put("P1", musteriAdSoyad);
					// messageMap.put("P2", basvuruNo);
					/*if(birKrediOdemeplaniGunTx.getIlkTaksitTarihi() != null){
						messageMap.put("P3", dateFormat.format(birKrediOdemeplaniGunTx.getIlkTaksitTarihi()).substring(0, 2));						
					}*/
					try {
						iMap.put("TRX_NO", birKrediOdemeplaniGunTx.getTxNo());
						iMap.put("SERVICE_NAME", "BNSPR_CL_YENIDEN_YAPILANDIRMA_RAPOR");
						iMap.put("SAVE_DOCUMENT", false);
						iMap.put("DOCUMENT_CODE", birKrediOdemeplaniGunTx.getTxNo());
						iMap.put("CUSTOMER_NO", musteriNo);
						iMap.put("REFERENCE", basvuruNo);
						iMap.put("REFERENCE_TYPE", "2");
						iMap.put("MSISDN", phoneNum);
						iMap.put("MESSAGE_NO", "5940");
						iMap.put("MESSAGE_CONTENT", new GMMap().put("P2", musteriAdSoyad).put("P3", basvuruNo));
						// iMap.put("DOCUMENT_REPORT_NAME", reportNames);
						// iMap.put("DOCUMENT_PARAMETERS", parameters);
						smsMap2 = GMServiceExecuter.call("BNSPR_COMMON_SEND_QS_DOCUMENT", iMap);
					}
					catch (Exception e) {
						logger.error("BNSPR_TRN3199_AFTER_APPROVAL sms2 error:", e);
						throw ExceptionHandler.convertException(e);
					}
				}
			}
			// SEND SMS

			String fileNameGeriOdeme = birBasvuru.getBasvuruNo() + "_GERI_ODEME_" + System.currentTimeMillis() + ".pdf";
			String fileNameYapilandirma = birBasvuru.getBasvuruNo() + "_YAPILANDIRMA_" + System.currentTimeMillis() + ".pdf";

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3199_PAYMENT_PLAN_AND_RECONSTRUCTION", iMap));
			byte[] geriOdeme = (byte[]) oMap.get("REPORT_GERI_ODEME");
			byte[] yapilandirma = (byte[]) oMap.get("REPORT_YAPILANDIRMA");

			// SEND EMAIL
			// TYBK-3727 ile mail gonderimi kaldirildi
			if (StringUtils.isNotEmpty(eMailAddress)) {

				List<String> emailList = new ArrayList<String>();
				emailList.add(eMailAddress);

				GMMap emailMap = new GMMap();
				emailMap.put("FROM", "aktifbank@aktifbank.com.tr");
				emailMap.put("RECIPIENTS_TO", emailList);
				/*
				if (birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("1") || birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("2") || birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("3")) {
					emailMap.put("SUBJECT", "Yap�land�r�lan Kredinin S�zle�me Formu ve �deme Plan�");
				}
				else {
					emailMap.put("SUBJECT", "Yap�land�r�lan Kredinin �deme Plan�");
				}
				*/

				String adSoyad = StringUtils.EMPTY;

				if (birBasvuruKimlik != null) {
					if (StringUtils.isNotEmpty(birBasvuruKimlik.getIkinciAd())) {
						adSoyad = birBasvuruKimlik.getAd() + " " + birBasvuruKimlik.getIkinciAd() + " " + birBasvuruKimlik.getSoyad();
					}
					else {
						adSoyad = birBasvuruKimlik.getAd() + " " + birBasvuruKimlik.getSoyad();
					}
				}
				if (birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("1") || birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("2") || birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("3")) {
					// emailMap.put("MESSAGE_BODY",getSozlesmeOnayEmailBanner(adSoyad,kanalAdi,basvuruNo.toString()));
				}
				else {

					GMMap inputMap = new GMMap();
					inputMap.put("FOLDER_NAME", "webCredit");
					inputMap.put("TEMPLATE_NAME", CreditDocMailTypes.OP_GUNC.getVmName());
					inputMap.put("ENCODING", "ISO-8859-9");
					
					HashMap<String,Object> inputs=new HashMap<String, Object>();
					inputMap.put("INPUTS", inputs);

					emailMap.put("SUBJECT", "Bireysel Kredi �deme Plan�n�za Ait Bilgilendirme");
					emailMap.put("MESSAGE_BODY", GMServiceExecuter.call("BNSPR_GENERATE_DYNAMIC_HTML", inputMap).getString("HTML_DATA"));

					emailMap.put("IS_BODY_HTML", true);
					emailMap.put("SEND_ATTACHMENT_WITHOUT_DYS", false);
					/*
					emailMap.put("ATTACMENT_FILE_LIST", 0, "FILE_NAME", fileNameGeriOdeme);
					emailMap.put("ATTACMENT_FILE_LIST", 0, "FILE_BYTE_ARRAY", geriOdeme);
					if (birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("1") || birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("2") || birKrediOdemeplaniGunTx.getGerekceKod().equalsIgnoreCase("3")) {
						emailMap.put("ATTACMENT_FILE_LIST", 1, "FILE_NAME", fileNameYapilandirma);
						emailMap.put("ATTACMENT_FILE_LIST", 1, "FILE_BYTE_ARRAY", yapilandirma);
					}
					*/
					GMServiceExecuter.executeAsync("BNSPR_SYSTEM_MAIL_SEND_EMAIL", emailMap);
					oMap.put("MESSAGE", "Mail ba�ar�l� �ekilde g�nderilmi�tir.");
				}

			}
			// SEND EMAIL

			// DOCUMENT -> DYS
			GMMap dysMap = new GMMap();
			dysMap.put("DOKUMAN_ADI", fileNameGeriOdeme);
			dysMap.put("DOKUMAN_TIPI", YAPILANDIRMA_ODEME_PLANI_DOKUMAN_KOD); // d�k�man kodu
			dysMap.put("MUSTERI_NO", musteriNo);
			dysMap.put("REFERANS_TIPI", "2");
			dysMap.put("REFERANS_NO", basvuruNo);
			dysMap.put("TRX_NO", GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).get("TRX_NO"));
			dysMap.put("DOSYA_SAYFA", 0, "CONTENT", geriOdeme);
			dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", fileNameGeriOdeme);
			dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER", BigDecimal.ONE);

			dysMap.put("ONAYSIZ_ISLEM_MI", true);

			GMMap isExistMap = GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap);
			if (isExistMap.getBoolean("RESULT")) {
				GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
			}
			else {
				GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
			}

			dysMap = new GMMap();
			dysMap.put("DOKUMAN_ADI", fileNameYapilandirma);
			dysMap.put("DOKUMAN_TIPI", YAPILANDIRMA_SOZLESME_DOKUMAN_KOD); // d�k�man kodu
			dysMap.put("MUSTERI_NO", musteriNo);
			dysMap.put("REFERANS_TIPI", "2");
			dysMap.put("REFERANS_NO", basvuruNo);
			dysMap.put("TRX_NO", GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).get("TRX_NO"));
			dysMap.put("DOSYA_SAYFA", 0, "CONTENT", yapilandirma);
			dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", fileNameYapilandirma);
			dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER", BigDecimal.ONE);

			dysMap.put("ONAYSIZ_ISLEM_MI", true);

			isExistMap = GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap);
			if (isExistMap.getBoolean("RESULT")) {
				GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
			}
			else {
				GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
			}
			// DOCUMENT -> DYS
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	private static String getSozlesmeOncesiEmailBanner(String adSoyad, String kanal, String basvuruNo) {
		String bannerContent =

		"<tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'><td valign=top style='border-top:none;border-left:solid #DBDCDF 1.0pt;border-bottom:none;border-right:solid #DBDCDF 1.0pt;padding:0cm 0cm 0cm 0cm'>" + "<div align=center><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=668 style='width:501.0pt;mso-cellspacing:0cm;background:white;mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'>" + "<tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'><td width=670 valign=top style='width:502.5pt;padding:0cm 0cm 0cm 0cm'><div align=center><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=670" + " style='width:502.5pt;mso-cellspacing:0cm;background:white;mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'><tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'><td width=1 style='width:1.0pt;padding:0cm 0cm 0cm 0cm'></td>" + "<td width=640 style='width:479.8pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal style='mso-margin-top-alt:auto;margin-bottom:12.0pt;line-height:15.75pt'><b><span style='font-size:11.5pt'>" + "Sn." + adSoyad + ",</span></b><span style='font-size:11.5pt;font-family:\"Arial\",sans-serif;color:#293E45'> <o:p></o:p></span></p><p class=MsoNormal style='mso-margin-top-alt:auto;margin-bottom:12.0pt;" + "line-height:15.75pt'><span style='font-size:11.5pt;font-family:\"Arial\",sans-serif;color:#293E45'>" + kanal + " kanal� ile Aktifbank'tan kulland���n�z " + basvuruNo + " ba�vuru numaral� krediniz ile ilgili yap�land�rma talebiniz" + " de�erlendirilerek gecikmi� taksitlerinizi d�zenli �deyebilmeniz i�in taraf�n�zla yap�lan kay�tl� g�r��mede teklif edilen �ekilde gelirinize uygun olarak yeni �deme plan� olu�turulmu�tur.<o:p></o:p></span></p></td><td width=29 style='width:21.7pt;padding:0cm 0cm 0cm 0cm'></td></tr>" + "<tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes'><td width=1 style='width:1.0pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal style='line-height:105%'><span style='font-size:12.0pt;line-height:105%;font-family:\"Times New Roman\",serif'>&nbsp;</span></p>" + "</td><td width=640 style='width:479.8pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal style='mso-margin-top-alt:auto;margin-bottom:12.0pt;line-height:15.75pt'>" + "<p class=MsoNormal style='mso-margin-top-alt:auto;margin-bottom:12.0pt;line-height:15.75pt'><b><span style='font-size:11.5pt;font-family:\"Arial\",sans-serif;color:#293E45'><o:p></o:p></span></b></p>" + "</td><td width=29 style='width:21.7pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal style='line-height:105%'><span style='font-size:12.0pt;line-height:105%;font-family:\"Times New Roman\",serif'>&nbsp;</span></p>" + "</td></tr></table></div></td></tr><tr style='mso-yfti-irow:1'><td width=670 valign=top style='width:502.5pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal style='mso-margin-top-alt:auto;margin-bottom:12.0pt;" + "line-height:15.75pt'><span style='font-size:11.5pt;font-family:\"Arial\",sans-serif;color:#293E45'>Detayl� bilgi i�in <strong><span style='font-family:\"Arial\",sans-serif'><a href=\"tel:08507243050\" target=\"_blank\">0 850 724 30 50</a></span></strong>" + " numaral� telefondan veya <strong><span style='font-family:\"Arial\",sans-serif'><a href=\"mailto:iletisim@aktifbank.com.tr\" target=\"_blank\">iletisim@aktifbank.com.tr</a></span></strong> adresinden bankam�z ile irtibata ge�ebilirsiniz.<o:p></o:p></span></p>" + "<p class=MsoNormal style='mso-margin-top-alt:auto;margin-bottom:12.0pt;line-height:15.75pt'><span style='font-size:11.5pt;font-family:\"Arial\",sans-serif;color:#293E45'>Sayg�lar�m�zla</span><span style='font-size:10.0pt;" + "font-family:\"Times New Roman\",serif;mso-fareast-language:TR'><o:p></o:p></span></p></td></tr><tr style='mso-yfti-irow:2;mso-yfti-lastrow:yes'><td width=670 valign=top style='width:502.5pt;padding:0cm 0cm 0cm 0cm'></td>" + "</tr></table></div></td></tr>"

		+ "<tr style='mso-yfti-irow:1'><td style='padding:0cm 0cm 0cm 0cm'><div align=center><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=672 style='width:504.0pt;mso-cellspacing:0cm;background:#E9EAED;mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'>" + "<tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'><td style='padding:0cm 0cm 0cm 0cm'><p class=MsoNormal><span style='font-family:\"Arial\",sans-serif'><a href=\"tel:08507243050\" target=\"_blank\"><span style='color:blue;border:none windowtext 1.0pt;" + "mso-border-alt:none windowtext 0cm;padding:0cm;text-decoration:none;text-underline:none'><img border=0 width=336 id=\"_x0000_i1030\" src=\"http://cdn.aktifbank.com.tr/20160406/20160406-gecikme/_i/telephone.jpg\"" + "alt=\"Aktif Bank\"></span></a></span><span style='font-size:12.0pt;font-family:\"Arial\",sans-serif'><o:p></o:p></span></p></td><td style='padding:0cm 0cm 0cm 0cm'><p class=MsoNormal><span style='font-family:\"Arial\",sans-serif'>" + "<a href=\"mailto:iletisim@aktifbank.com.tr\" target=\"_blank\"><span style='color:blue;border:none windowtext 1.0pt;mso-border-alt:none windowtext 0cm;padding:0cm;text-decoration:none;text-underline:none'><img border=0" + "width=336 id=\"_x0000_i1031\" src=\"http://cdn.aktifbank.com.tr/20160406/20160406-gecikme/_i/email1.jpg\" alt=\"Aktif Bank\"></span></a><o:p></o:p></span></p></td></tr></table></div></td></tr>"

		+ "<tr style='mso-yfti-irow:2'><td style='padding:0cm 0cm 0cm 0cm'><div align=center><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=672 style='width:504.0pt;mso-cellspacing:0cm;background:#E9EAED;mso-yfti-tbllook:" + "1184;mso-padding-alt:0cm 0cm 0cm 0cm'><tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'><td width=120 style='width:90.0pt;padding:0cm 0cm 0cm 0cm'></td><td width=450 style='width:337.5pt;padding:0cm 0cm 0cm 0cm'>" + "<p class=MsoNormal align=center style='margin-bottom:12.0pt;text-align:center'><span style='font-size:8.5pt;font-family:\"Arial\",sans-serif;color:#7D98AB'><br>AKT�F YATIRIM BANKASI A.�. Aktif Bank Genel M�d�rl�k Esentepe Mahallesi Kore �ehitleri Caddesi No:8/1 �i�li �STANBUL <o:p></o:p></span></p>" + "<div align=center><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=384 style='width:288.0pt;mso-cellspacing:0cm;background:#E9EAED;mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'>" + "<tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'><td width=112 style='width:84.0pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Arial\",sans-serif;" + "color:#7D98AB'><img border=0 id=\"_x0000_i1032\" src=\"http://cdn.aktifbank.com.tr/20160406/20160406-gecikme/_i/icon-small-telephone.jpg\" alt=\"Aktif Bank\"><a href=\"tel:02123408000\"><span style='color:#7D98AB;" + "text-decoration:none;text-underline:none'>0212 340 80 00 </span></a><o:p></o:p></span></p></td><td width=111 style='width:83.25pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Arial\",sans-serif;" + "color:#7D98AB'><img border=0 id=\"_x0000_i1033\" src=\"http://cdn.aktifbank.com.tr/20160406/20160406-gecikme/_i/icon-small-fax.jpg\" alt=\"Aktif Bank\"><a href=\"tel:02123408865\"><span style='color:#7D98AB;" + "text-decoration:none;text-underline:none'>0212 340 88 65 </span></a><o:p></o:p></span></p></td><td width=161 style='width:120.75pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Arial\",sans-serif;" + "color:#7D98AB'><img border=0 id=\"_x0000_i1034\" src=\"http://cdn.aktifbank.com.tr/20160406/20160406-gecikme/_i/icon-small-mail.jpg\" alt=\"Aktif Bank\"><a href=\"mailto:iletisim@aktifbank.com.tr\"><span" + " style='color:#7D98AB;text-decoration:none;text-underline:none'>iletisim@aktifbank.com.tr</span></a><o:p></o:p></span></p></td></tr></table></div>"

		+ "<p class=MsoNormal align=center style='margin-bottom:12.0pt;text-align:center'><span style='font-size:8.5pt;font-family:\"Arial\",sans-serif;color:#7D98AB'><br></span><span style='font-size:7.5pt;font-family:\"Arial\",sans-serif;" + "color:#7D98AB'>�stanbul Ticaret Sicil M�d�rl��� - Ticaret Sicil No: 424040 - Mersis No: 0225013653700015 </span><span style='font-size:8.5pt;font-family:\"Arial\",sans-serif;color:#7D98AB'><o:p></o:p></span></p></td>" + "<td width=120 style='width:90.0pt;padding:0cm 0cm 0cm 0cm'></td></tr></table></div></td></tr><tr style='mso-yfti-irow:3;mso-yfti-lastrow:yes'><td style='padding:0cm 0cm 0cm 0cm'><div align=center><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=672" + " style='width:504.0pt;mso-cellspacing:0cm;background:#E9EAED;mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'><tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'><td style='padding:0cm 0cm 0cm 0cm'>" + "<p class=MsoNormal align=center style='margin-bottom:12.0pt;text-align:center'><span style='font-size:7.5pt;font-family:\"Arial\",sans-serif;color:#7D98AB'>Ki�iye �zel bu mesaj ve i�eri�indeki bilgiler gizlidir." + "Aktif Yat�r�m Bankas� A.�. bu mesaj�n i�eri�i ve ekleri ile ilgili olarak<br> hukuksal hi�bir sorumluluk kabul etmez. Yetkili al�c� de�ilseniz, bu mesaj�n herhangi bir �ekilde if�a edilmesi, kullan�lmas�,<br>" + "kopyalanmas�, yay�lmas� veya mesajda yer alan hususlarla ilgili olarak herhangi bir i�lem yap�lmas�n�n kesinlikle<br> yasak oldu�unu bildiririz. B�yle bir durumda l�tfen hemen mesaj�n g�ndericisini bilgilendiriniz ve mesaj�<br>" + "sisteminizden siliniz. �nternet ortam�nda g�nderilen e-posta mesajlar�ndaki hata ve/veya eksikliklerden veya<br> vir�slerden dolay� mesaj�n g�ndericisi herhangi bir sorumluluk kabul etmemektedir. Te�ekk�r ederiz.<o:p></o:p></span></p>" + "</td></tr></table></div></td></tr>";

		return bannerContent;
	}

	private static String getSozlesmeOnayEmailBanner(String adSoyad, String kanal, String basvuruNo) {
		String bannerContent =

		"<tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'><td valign=top style='border-top:none;border-left:solid #DBDCDF 1.0pt;border-bottom:none;border-right:solid #DBDCDF 1.0pt;padding:0cm 0cm 0cm 0cm'>" + "<div align=center><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=668 style='width:501.0pt;mso-cellspacing:0cm;background:white;mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'>" + "<tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'><td width=670 valign=top style='width:502.5pt;padding:0cm 0cm 0cm 0cm'><div align=center><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=670" + " style='width:502.5pt;mso-cellspacing:0cm;background:white;mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'><tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes'><td width=1 style='width:1.0pt;padding:0cm 0cm 0cm 0cm'></td>" + "<td width=640 style='width:479.8pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal style='mso-margin-top-alt:auto;margin-bottom:12.0pt;line-height:15.75pt'><b><span style='font-size:11.5pt'>" + "Sn." + adSoyad + ",</span></b><span style='font-size:11.5pt;font-family:\"Arial\",sans-serif;color:#293E45'> <o:p></o:p></span></p><p class=MsoNormal style='mso-margin-top-alt:auto;margin-bottom:12.0pt;" + "line-height:15.75pt'><span style='font-size:11.5pt;font-family:\"Arial\",sans-serif;color:#293E45'>" + kanal + " kanal� ile Aktifbank'tan kulland���n�z " + basvuruNo + " ba�vuru numaral� krediniz ile ilgili yap�land�rma talebiniz" + " sonu�land�r�larak yeni �deme plan� olu�turulmu�tur. <o:p></o:p></span></p></td><td width=29 style='width:21.7pt;padding:0cm 0cm 0cm 0cm'></td></tr>" + "<tr style='mso-yfti-irow:1;mso-yfti-lastrow:yes'><td width=1 style='width:1.0pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal style='line-height:105%'><span style='font-size:12.0pt;line-height:105%;font-family:\"Times New Roman\",serif'>&nbsp;</span></p>" + "</td><td width=640 style='width:479.8pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal style='mso-margin-top-alt:auto;margin-bottom:12.0pt;line-height:15.75pt'>" + "<p class=MsoNormal style='mso-margin-top-alt:auto;margin-bottom:12.0pt;line-height:15.75pt'><b><span style='font-size:11.5pt;font-family:\"Arial\",sans-serif;color:#293E45'><o:p></o:p></span></b></p>" + "</td><td width=29 style='width:21.7pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal style='line-height:105%'><span style='font-size:12.0pt;line-height:105%;font-family:\"Times New Roman\",serif'>&nbsp;</span></p>" + "</td></tr></table></div></td></tr><tr style='mso-yfti-irow:1'><td width=670 valign=top style='width:502.5pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal style='mso-margin-top-alt:auto;margin-bottom:12.0pt;" + "line-height:15.75pt'><span style='font-size:11.5pt;font-family:\"Arial\",sans-serif;color:#293E45'>Detayl� bilgi i�in <strong><span style='font-family:\"Arial\",sans-serif'><a href=\"tel:08507243050\" target=\"_blank\">0 850 724 30 50</a></span></strong>" + " numaral� telefondan veya <strong><span style='font-family:\"Arial\",sans-serif'><a href=\"mailto:iletisim@aktifbank.com.tr\" target=\"_blank\">iletisim@aktifbank.com.tr</a></span></strong> adresinden bankam�z ile irtibata ge�ebilirsiniz.<o:p></o:p></span></p>" + "<p class=MsoNormal style='mso-margin-top-alt:auto;margin-bottom:12.0pt;line-height:15.75pt'><span style='font-size:11.5pt;font-family:\"Arial\",sans-serif;color:#293E45'>�demelerinizi IBAN numaran�z ile EFT yaparak (al�c� k�sm�na " + "kredi sahibinin ismi eklenmeli); PTT �ubelerinden, N'Kolay i�lem merkezlerinden TCKN niz ile; veya hesap numaran�zla karts�z i�lemler men�s�nden Akbank,Vak�fbank ve PTT ATM lerinden ger�ekle�tirebilirsiniz.<o:p></o:p></span></p>" + "<p class=MsoNormal style='mso-margin-top-alt:auto;margin-bottom:12.0pt;line-height:15.75pt'><span style='font-size:11.5pt;font-family:\"Arial\",sans-serif;color:#293E45'>Sayg�lar�m�zla</span><span style='font-size:10.0pt;" + "font-family:\"Times New Roman\",serif;mso-fareast-language:TR'><o:p></o:p></span></p></td></tr><tr style='mso-yfti-irow:2;mso-yfti-lastrow:yes'><td width=670 valign=top style='width:502.5pt;padding:0cm 0cm 0cm 0cm'></td>" + "</tr></table></div></td></tr>"

		+ "<tr style='mso-yfti-irow:1'><td style='padding:0cm 0cm 0cm 0cm'><div align=center><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=672 style='width:504.0pt;mso-cellspacing:0cm;background:#E9EAED;mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'>" + "<tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'><td style='padding:0cm 0cm 0cm 0cm'><p class=MsoNormal><span style='font-family:\"Arial\",sans-serif'><a href=\"tel:08507243050\" target=\"_blank\"><span style='color:blue;border:none windowtext 1.0pt;" + "mso-border-alt:none windowtext 0cm;padding:0cm;text-decoration:none;text-underline:none'><img border=0 width=336 id=\"_x0000_i1030\" src=\"http://cdn.aktifbank.com.tr/20160406/20160406-gecikme/_i/telephone.jpg\"" + "alt=\"Aktif Bank\"></span></a></span><span style='font-size:12.0pt;font-family:\"Arial\",sans-serif'><o:p></o:p></span></p></td><td style='padding:0cm 0cm 0cm 0cm'><p class=MsoNormal><span style='font-family:\"Arial\",sans-serif'>" + "<a href=\"mailto:iletisim@aktifbank.com.tr\" target=\"_blank\"><span style='color:blue;border:none windowtext 1.0pt;mso-border-alt:none windowtext 0cm;padding:0cm;text-decoration:none;text-underline:none'><img border=0" + "width=336 id=\"_x0000_i1031\" src=\"http://cdn.aktifbank.com.tr/20160406/20160406-gecikme/_i/email1.jpg\" alt=\"Aktif Bank\"></span></a><o:p></o:p></span></p></td></tr></table></div></td></tr>"

		+ "<tr style='mso-yfti-irow:2'><td style='padding:0cm 0cm 0cm 0cm'><div align=center><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=672 style='width:504.0pt;mso-cellspacing:0cm;background:#E9EAED;mso-yfti-tbllook:" + "1184;mso-padding-alt:0cm 0cm 0cm 0cm'><tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'><td width=120 style='width:90.0pt;padding:0cm 0cm 0cm 0cm'></td><td width=450 style='width:337.5pt;padding:0cm 0cm 0cm 0cm'>" + "<p class=MsoNormal align=center style='margin-bottom:12.0pt;text-align:center'><span style='font-size:8.5pt;font-family:\"Arial\",sans-serif;color:#7D98AB'><br>AKT�F YATIRIM BANKASI A.�. Aktif Bank Genel M�d�rl�k Esentepe Mahallesi Kore �ehitleri Caddesi No:8/1 �i�li �STANBUL <o:p></o:p></span></p>" + "<div align=center><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=384 style='width:288.0pt;mso-cellspacing:0cm;background:#E9EAED;mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'>" + "<tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'><td width=112 style='width:84.0pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Arial\",sans-serif;" + "color:#7D98AB'><img border=0 id=\"_x0000_i1032\" src=\"http://cdn.aktifbank.com.tr/20160406/20160406-gecikme/_i/icon-small-telephone.jpg\" alt=\"Aktif Bank\"><a href=\"tel:02123408000\"><span style='color:#7D98AB;" + "text-decoration:none;text-underline:none'>0212 340 80 00 </span></a><o:p></o:p></span></p></td><td width=111 style='width:83.25pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Arial\",sans-serif;" + "color:#7D98AB'><img border=0 id=\"_x0000_i1033\" src=\"http://cdn.aktifbank.com.tr/20160406/20160406-gecikme/_i/icon-small-fax.jpg\" alt=\"Aktif Bank\"><a href=\"tel:02123408865\"><span style='color:#7D98AB;" + "text-decoration:none;text-underline:none'>0212 340 88 65 </span></a><o:p></o:p></span></p></td><td width=161 style='width:120.75pt;padding:0cm 0cm 0cm 0cm'><p class=MsoNormal><span style='font-size:8.5pt;font-family:\"Arial\",sans-serif;" + "color:#7D98AB'><img border=0 id=\"_x0000_i1034\" src=\"http://cdn.aktifbank.com.tr/20160406/20160406-gecikme/_i/icon-small-mail.jpg\" alt=\"Aktif Bank\"><a href=\"mailto:iletisim@aktifbank.com.tr\"><span" + " style='color:#7D98AB;text-decoration:none;text-underline:none'>iletisim@aktifbank.com.tr</span></a><o:p></o:p></span></p></td></tr></table></div>"

		+ "<p class=MsoNormal align=center style='margin-bottom:12.0pt;text-align:center'><span style='font-size:8.5pt;font-family:\"Arial\",sans-serif;color:#7D98AB'><br></span><span style='font-size:7.5pt;font-family:\"Arial\",sans-serif;" + "color:#7D98AB'>�stanbul Ticaret Sicil M�d�rl��� - Ticaret Sicil No: 424040 - Mersis No: 0225013653700015 </span><span style='font-size:8.5pt;font-family:\"Arial\",sans-serif;color:#7D98AB'><o:p></o:p></span></p></td>" + "<td width=120 style='width:90.0pt;padding:0cm 0cm 0cm 0cm'></td></tr></table></div></td></tr><tr style='mso-yfti-irow:3;mso-yfti-lastrow:yes'><td style='padding:0cm 0cm 0cm 0cm'><div align=center><table class=MsoNormalTable border=0 cellspacing=0 cellpadding=0 width=672" + " style='width:504.0pt;mso-cellspacing:0cm;background:#E9EAED;mso-yfti-tbllook:1184;mso-padding-alt:0cm 0cm 0cm 0cm'><tr style='mso-yfti-irow:0;mso-yfti-firstrow:yes;mso-yfti-lastrow:yes'><td style='padding:0cm 0cm 0cm 0cm'>" + "<p class=MsoNormal align=center style='margin-bottom:12.0pt;text-align:center'><span style='font-size:7.5pt;font-family:\"Arial\",sans-serif;color:#7D98AB'>Ki�iye �zel bu mesaj ve i�eri�indeki bilgiler gizlidir." + "Aktif Yat�r�m Bankas� A.�. bu mesaj�n i�eri�i ve ekleri ile ilgili olarak<br> hukuksal hi�bir sorumluluk kabul etmez. Yetkili al�c� de�ilseniz, bu mesaj�n herhangi bir �ekilde if�a edilmesi, kullan�lmas�,<br>" + "kopyalanmas�, yay�lmas� veya mesajda yer alan hususlarla ilgili olarak herhangi bir i�lem yap�lmas�n�n kesinlikle<br> yasak oldu�unu bildiririz. B�yle bir durumda l�tfen hemen mesaj�n g�ndericisini bilgilendiriniz ve mesaj�<br>" + "sisteminizden siliniz. �nternet ortam�nda g�nderilen e-posta mesajlar�ndaki hata ve/veya eksikliklerden veya<br> vir�slerden dolay� mesaj�n g�ndericisi herhangi bir sorumluluk kabul etmemektedir. Te�ekk�r ederiz.<o:p></o:p></span></p>" + "</td></tr></table></div></td></tr>";

		return bannerContent;
	}

	@GraymoundService("BNSPR_TRN3199_GET_PTT_MAAS_KURUM")
	public static GMMap getPttMaasKurum(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");

		GMMap oMap = new GMMap();
		try {
			String query = "select key1,text from gnl_param_text where kod = 'PTT_KREDI_MAAS_ALINAN_KURUM' order by id";
			DALUtil.fillComboBox(oMap, "PTT_MAAS_KURUM_LIST", true, query);

			if (iMap.getBigDecimal("BASVURU_NO") != null) {
				BirBasvuru basvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				if (basvuru != null) {
					oMap.put("MAAS_ALINAN_KURUM", basvuru.getPttMaasAlinanKurum());
					oMap.put("TAHSIS_NO", basvuru.getPttTahsisNumarasi());
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3199_OTELEME_KONTROL")
	public static GMMap otelemeKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap sMap = new GMMap();
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String errorMessage = "";
		BigDecimal taksitTutari = BigDecimal.ZERO;
		Date sonTaksitTarihi = new Date();
		
		try {			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3199.RC_GET_CURRENT_ODEME_PLANI(?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.getMoreResults();
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			
			String tableName = "ODEME_PLANI";
			String ilkTaksitDurum = "";
			int row = 0;
			oMap.put("KISMI", false);
			while (rSet.next()) {
				int j = 1;

				// ilk taksitin s�ra no'sunun belirlenmesi
				if (row == 0) {
					ilkTaksitDurum = rSet.getString("DURUM_KOD");					
				}

				oMap.put(tableName, row, "SIRA_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "TAKSIT_TARIH", rSet.getDate(j++));
				oMap.put(tableName, row, "TAKSIT_TUT", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "ANAPARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "FAIZ", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KKDF", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "BSMV", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "KALAN_ANAPARA", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "DURUM_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "MASRAF", rSet.getBigDecimal(j++));
				row++;
			}
			
			BirKullandirim birKullandirim = (BirKullandirim) session.createCriteria(BirKullandirim.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			//	Bir_kullandirim.ara_odeme_no > 1 ve ilk taksit ODENDI degilse (bir_kredi_taksit�teki min sira_no) is kesici mesaj 
			if(birKullandirim.getAraOdemeNo().compareTo(BigDecimal.ONE) == 1 && !ilkTaksitDurum.equals("ODENDI")){
				//Talebinizi gerceklestirebilmemiz icin ilk taksitinizi odemeniz gerekmektedir.
				iMap.put("HATA_NO", new BigDecimal(6063));
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);				
			}
			
			//	Gecikme gun say�s� > 60 ise kaydet�e basildiginda is kesici verecegiz			
			MusteriUrunRisk musteriUrunRisk = (MusteriUrunRisk) session.createCriteria(MusteriUrunRisk.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).addOrder(Order.desc("id.islemTarihi")).list().get(0);			
			if(musteriUrunRisk.getGgs().compareTo(new BigDecimal(60)) == 1) {
			// Krediniz 3 taksit gecikmede bulundugundan oteleme talebiniz olumlu degerlendirilememektedir. Kredi gecikmenizin 30 g�ne d�s�r�lmesi durumda talebiniz degerlendirilebilecektir.
				iMap.put("HATA_NO", new BigDecimal(6113));
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			// taksit gunu kontrolleri			
			GMServiceExecuter.call("BNSPR_TRN3199_CHECK_TAKSIT_GUNU", iMap);
			
			// sozlesme faizi kontrolu
			GMServiceExecuter.call("BNSPR_TRN3199_CHECK_SOZLESME_FAIZI", iMap);
			
			// max vade kontrolu
			GMServiceExecuter.call("BNSPR_TRN3199_CHECK_VADE", iMap);
			
			Calendar sonOdenenTaksitTarihi = Calendar.getInstance();
			Calendar taksitOdenmekIstenilenTarih = Calendar.getInstance();
			
			sonOdenenTaksitTarihi.setTime(iMap.getDate("SON_ODENEN_TAKSIT_TARIHI"));
			taksitOdenmekIstenilenTarih.setTime(iMap.getDate("TAKSIT_ODENMEK_ISTENILEN_TARIH"));
			
			//int yearsInBetween = taksitOdenmekIstenilenTarih.get(Calendar.YEAR) - sonOdenenTaksitTarihi.get(Calendar.YEAR);
			//int monthsDiff = taksitOdenmekIstenilenTarih.get(Calendar.MONTH) - sonOdenenTaksitTarihi.get(Calendar.MONTH);
			//int ageInMonths = yearsInBetween * 12 + monthsDiff;
			
			//int ageInMonths = iMap.getBigDecimal("OTELEME_GUN_SAYISI").divide(new BigDecimal(30), BigDecimal.ROUND_UP).intValue();

			taksitTutari = iMap.getBigDecimal("GUNCEL_ODEME_PLANI", 0, "TAKSIT_TUT");
			sonTaksitTarihi = iMap.getDate("GUNCEL_ODEME_PLANI", iMap.getSize("GUNCEL_ODEME_PLANI") - 1, "TAKSIT_TARIH");
						
			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			
			// guncelleme onay mesaji-1
			sMap.put("MESSAGE_NO", "6114");
			sMap.put("P1", iMap.getBigDecimal("BASVURU_NO"));
			sMap.put("P2", iMap.getBigDecimal("OTELEME_GUN_SAYISI"));
			sMap.put("P3", df.format(iMap.getDate("TAKSIT_ODENMEK_ISTENILEN_TARIH")));
			sMap.put("P4", iMap.getBigDecimal("SOZLESME_FAIZI"));						
			sMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", sMap));
			errorMessage = errorMessage.concat(sMap.getString("ERROR_MESSAGE"));
			
			// guncelleme onay mesaji
			sMap = new GMMap();
			sMap.put("MESSAGE_NO", "6115");
			sMap.put("P1", taksitTutari);
			sMap.put("P2", iMap.getBigDecimal("VADE"));
			sMap.put("P3", iMap.getBigDecimal("TOPLAM_TAKSIT_TUTARI"));
			sMap.put("P4", iMap.getBigDecimal("SOZLESME_FAIZI"));					
			sMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", sMap));
			errorMessage = errorMessage.concat(sMap.getString("ERROR_MESSAGE"));
			
			// guncelleme onay mesaji
			sMap = new GMMap();
			sMap.put("MESSAGE_NO", "6116");
			sMap.put("P1", iMap.getBigDecimal("YILLIK_MALIYET"));
			sMap.put("P2", iMap.getBigDecimal("GECIKME_FAIZ_ORANI"));	
			sMap.put("P3", df.format(sonTaksitTarihi));
			sMap.put("P4", iMap.getBigDecimal("OTELEME_GUN_SAYISI"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", sMap));
			errorMessage = errorMessage.concat(sMap.getString("ERROR_MESSAGE"));
			
			// guncelleme onay mesaji
			sMap = new GMMap();
			sMap.put("MESSAGE_NO", "6156");
			sMap.put("P1", iMap.getBigDecimal("FARK_FAIZI"));
			sMap.put("P2", iMap.getBigDecimal("OTELEME_GUN_SAYISI"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", sMap));
			errorMessage = errorMessage.concat(sMap.getString("ERROR_MESSAGE"));
			
			oMap.put("ERROR_MESSAGE", errorMessage);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3199_CHECK_TAKSIT_GUNU")
	public static GMMap checkTaksitGunu(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("ERROR_MESSAGE", "");
			
			Calendar sonOdenenTaksitTarihi = Calendar.getInstance();
			Calendar taksitOdenmekIstenilenTarih = Calendar.getInstance();
			Calendar sonEmekliMaasTarihi = Calendar.getInstance();
			Calendar compareDate = Calendar.getInstance();
			
			taksitOdenmekIstenilenTarih.setTime(iMap.getDate("TAKSIT_ODENMEK_ISTENILEN_TARIH"));
			
			// PBIBK-587 gun kontrolu 100 gun			
			if(BigDecimal.valueOf(100).compareTo(iMap.getBigDecimal("OTELEME_GUN_SAYISI")) == -1){
				iMap.put("HATA_NO", new BigDecimal(6061));
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			if(iMap.getDate("SON_EMEKLI_MAAS_TARIHI") != null) {
				sonEmekliMaasTarihi.setTime(iMap.getDate("SON_EMEKLI_MAAS_TARIHI"));
				if(sonEmekliMaasTarihi.get(Calendar.DAY_OF_MONTH) != taksitOdenmekIstenilenTarih.get(Calendar.DAY_OF_MONTH)){				
					iMap.put("HATA_NO", new BigDecimal(6060));
					return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);				
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3199_CHECK_SOZLESME_FAIZI")
	public static GMMap checkSozlesmeFaizi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("ERROR_MESSAGE", "");
			iMap.put("KOD", "3199_SOZLESME_FAIZI_MIN");
			BigDecimal minFaiz = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMap).getBigDecimal("DEGER");
			iMap.put("KOD", "3199_SOZLESME_FAIZI_MAX");
			BigDecimal maxFaiz = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMap).getBigDecimal("DEGER");
			
			if(iMap.getBigDecimal("SOZLESME_FAIZI").compareTo(minFaiz) == -1 || iMap.getBigDecimal("SOZLESME_FAIZI").compareTo(maxFaiz) == 1){
				iMap.put("HATA_NO", new BigDecimal(6062));
				iMap.put("P1", minFaiz);
				iMap.put("P2", maxFaiz);
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3199_CHECK_VADE")
	public static GMMap checkVade(GMMap iMap) {		
		GMMap oMap = new GMMap();
		try {
			oMap.put("ERROR_MESSAGE", "");
			iMap.put("KOD", "3199_OTELEME_VADE_MAX");
			
			BigDecimal maxVade = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMap).getBigDecimal("DEGER");
			
			if(iMap.getBigDecimal("VADE").compareTo(maxVade) == 1){
				iMap.put("HATA_NO", new BigDecimal(6168));
				iMap.put("P1", maxVade);				
				return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3199_GET_OTELEME_COMBOBOX_VALUES")
	public static GMMap getOtelemeComboboxValues(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			DALUtil.fillComboBox(oMap, "GEREKCE_LISTE", false, "SELECT KEY1 KOD, TEXT ACIKLAMA from gnl_param_text where kod like 'ODEME_PLAN_GUNCELLEME_GEREKCE%' and key3 = 'O'");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;		
	}
	
	@GraymoundService("BNSPR_TRN3199_GET_OTELEME_GECMISI")
	public static GMMap getOtelemeGecmisi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn3199.Oteleme_Gecmisi(?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "OTELEME_GECMISI");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}	
	}

	@GraymoundService("BNSPR_TRN3199_GUNCELLEME_GEREKCELERI_LIST")
	public static GMMap guncellemeGerekceleriList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("KOD", "ODEME_PLAN_GUNCELLEME_GEREKCE");
			oMap.put("GUNCELLEME_GEREKCE_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;		
	}

	@GraymoundService("BNSPR_TRN3199_GEREKCE_GUNCELLEME_KAYDET")
	public static GMMap gerekceGuncellemeKaydet(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirKrediOdemeplaniGunTx birKrediOdemeplaniGunTx = (BirKrediOdemeplaniGunTx) session.createCriteria(BirKrediOdemeplaniGunTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TX_NO"))).uniqueResult();

			if (birKrediOdemeplaniGunTx != null) {
				birKrediOdemeplaniGunTx.setGerekceKod(iMap.getString("GEREKCE_KOD"));
			}
			
			session.saveOrUpdate(birKrediOdemeplaniGunTx);
			session.flush();
			
			iMap.put("MESSAGE_NO", 1544);
			oMap.put("MESSAGE",GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;		
	}
}
