package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.Types;
import java.util.Date;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.BirTesvikOdemeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanKrediTesvikServices {
	
	private static Logger logger = Logger.getLogger(ConsumerLoanKrediTesvikServices.class);
	
	@GraymoundService("SCHEDULER_KREDI_TESVIK_ODEME_GUNLUK")
	public static GMMap schedulerKrediTesvikOdemeGunluk(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try {
			oMap.put("START_DATE", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
			oMap.put("END_DATE", GMServiceExecuter.call("BNSPR_COMMON_GET_ONCEKI_BANKA_TARIHI", iMap).getDate("BANKA_TARIHI"));
			GMServiceExecuter.call("SCHEDULER_KREDI_TESVIK_ODEME", oMap);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("SCHEDULER_KREDI_TESVIK_ODEME_AYLIK")
	public static GMMap schedulerKrediTesvikOdemeAylik(GMMap iMap) throws Exception{
		GMMap oMap = new GMMap();
		String tesvikOdemeTarihGlbParam = "TESVIK_ODEME_BASLANGIC_TARIH";
		
		try {
			oMap.put("KOD", tesvikOdemeTarihGlbParam);
			Date startDate = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", oMap).getDate("DEGER");
			Date endDate = (Date)DALUtil.callNoParameterFunction("{? = call PKG_TRN3258.last_day_of_previous_month}", Types.DATE);
			oMap.put("START_DATE", startDate);
			oMap.put("END_DATE", endDate);
			
			GMServiceExecuter.call("SCHEDULER_KREDI_TESVIK_ODEME", oMap);
		}
		catch (Exception e) {
			logger.error(e.getMessage());
			throw e;
		}
		return new GMMap();
	}
	
	@GraymoundService("SCHEDULER_KREDI_TESVIK_ODEME")
	public static GMMap schedulerKrediTesvikOdeme(GMMap iMap){
		GMMap oMap = new GMMap();
		GMMap odemeMap = new GMMap();
		BigDecimal trxNo = BigDecimal.ZERO;
		String tableName = "RESULT";
		String tesvikHakedisGlbParam = "TESVIK_HAKEDIS_ALT_LIMITI";
		
		try {
			Date startDate = iMap.getDate("START_DATE");
			Date endDate = iMap.getDate("END_DATE");
			
			if(startDate.after(endDate)){
				throw new Exception("Tesvik hesaplanacak gecerli tarih araligi bulunamad�. StartDate: " + startDate + "  EndDate: " + endDate);
			}
			
			oMap.put("KOD", tesvikHakedisGlbParam);
			BigDecimal tesvikHakedisLimit = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", oMap).getBigDecimal("DEGER");
			Session session = DAOSession.getSession("BNSPRDal");
				
			odemeMap = GMServiceExecuter.call("BNSPR_GET_KREDI_TESVIK_ODEME_LIST", iMap);
			
			for (int i = 0; i < odemeMap.getSize(tableName); i++) {
				BigDecimal tutar = odemeMap.getBigDecimal(tableName, i, "TUTAR");
				BigDecimal hesapNo = odemeMap.getBigDecimal(tableName, i, "HESAP_NO");
				
				if(tutar.compareTo(tesvikHakedisLimit) != -1 && hesapNo != null && hesapNo.compareTo(BigDecimal.ZERO) == 1){
					trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
					
					BirTesvikOdemeTx tesvikOdemeTx = new BirTesvikOdemeTx();
					tesvikOdemeTx.setBayiHesap(odemeMap.getBigDecimal(tableName, i, "BAYI_HESAP_NO"));
					/*
					tesvikOdemeTx.setCalisanHesap(hesapNo);
					tesvikOdemeTx.setCalisanKod(odemeMap.getBigDecimal(tableName, i, "CALISAN_KOD"));
					tesvikOdemeTx.setCalisanTutari(odemeMap.getBigDecimal(tableName, i, "TUTAR"));
					*/
					tesvikOdemeTx.setKartNo(odemeMap.getBigDecimal(tableName, i, "KART_NO"));
					tesvikOdemeTx.setKartTipi(odemeMap.getString(tableName, i, "KART_TIPI"));
					tesvikOdemeTx.setTesvikDonem(odemeMap.getString(tableName, i, "TESVIK_DONEM"));
					tesvikOdemeTx.setTarih1(startDate);
					tesvikOdemeTx.setTarih2(endDate);
					tesvikOdemeTx.setTxNo(trxNo);
					oMap.put (tableName, oMap.getSize(tableName), "TRX_NO", trxNo);
					session.save(tesvikOdemeTx);
				}
			}
			
			session.flush();
			
			oMap = GMServiceExecuter.call("BNSPR_KREDI_TESVIK_ODEME", oMap);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_GET_KREDI_TESVIK_ODEME_LIST")
	public static GMMap getKrediTesvikOdemeList(GMMap iMap){
		GMMap oMap = new GMMap();
		String tableName = "RESULT";
		
		try {
			Date startDate = iMap.getDate("START_DATE");
			Date endDate = iMap.getDate("END_DATE");
			Object[] inputValues = {BnsprType.DATE, startDate, BnsprType.DATE, endDate};
			Object[] outputValues = {BnsprType.REFCURSOR, tableName};
			
			oMap.putAll((GMMap)DALUtil.callOracleProcedure("{ call PKG_TRN3258.getKrediTesvikOdemeList(?, ?, ?) }", inputValues, outputValues));
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_KREDI_TESVIK_ODEME")
	public static GMMap krediTesvikOdeme(GMMap iMap){
		GMMap oMap = new GMMap();
		String tableName = "RESULT";
		
		try {
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				GMMap txMap = new GMMap();
				txMap.put("TRX_NAME", "3258");
				txMap.put("TRX_NO", iMap.getBigDecimal(tableName, i, "TRX_NO"));
				GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", txMap);
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
}
