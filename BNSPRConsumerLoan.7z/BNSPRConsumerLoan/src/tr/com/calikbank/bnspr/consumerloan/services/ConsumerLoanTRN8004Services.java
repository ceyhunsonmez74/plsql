package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Order;

import tr.com.aktifbank.bnspr.dao.DcsGecikmeGonderiKarar;
import tr.com.aktifbank.bnspr.dao.DcsGecikmeGonderiKararTx;
import tr.com.aktifbank.bnspr.dao.DcsGecikmeGonderiKararTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN8004Services {

	@GraymoundService("BNSPR_TRN8004_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listDcsGecikmeGonderiKarar = (List<?>) session.createCriteria(DcsGecikmeGonderiKarar.class).addOrder(Order.desc("id")).list();

			String tableName = "DCS_GECIKME_GONDERI_KARAR";
			int row = 0;
			for (Iterator<?> iterator = listDcsGecikmeGonderiKarar.iterator(); iterator.hasNext(); row++) {

				DcsGecikmeGonderiKarar dcsGecikmeGonderiKarar = (DcsGecikmeGonderiKarar) iterator.next();

				oMap.put(tableName, row, "ID", dcsGecikmeGonderiKarar.getId());
				oMap.put(tableName, row, "URUN_TIP", dcsGecikmeGonderiKarar.getUrunTip());
				oMap.put(tableName, row, "GONDERI_TIP", dcsGecikmeGonderiKarar.getGonderiTip());
				oMap.put(tableName, row, "GECIKME_GUN_SAYISI", dcsGecikmeGonderiKarar.getGecikmeGunSayisi());
				oMap.put(tableName, row, "TAKSIT_SIRA_NO", dcsGecikmeGonderiKarar.getTaksitSiraNo());
				oMap.put(tableName, row, "KANAL_KOD", dcsGecikmeGonderiKarar.getKanalKod());
				oMap.put(tableName, row, "KMH_TUR_KOD", dcsGecikmeGonderiKarar.getKmhTurKod());
				if (dcsGecikmeGonderiKarar.getKmhTurKod() != null)
					oMap.put(tableName, row, "KMH_TUR_KOD_ACIKLAMA", getKmhTurKodAciklama(dcsGecikmeGonderiKarar));
				oMap.put(tableName, row, "KISMI_ODEME", dcsGecikmeGonderiKarar.getKismiOdeme());
				oMap.put(tableName, row, "ICERIK", dcsGecikmeGonderiKarar.getIcerik());
				oMap.put(tableName, row, "TOPLU_MU", dcsGecikmeGonderiKarar.getTopluMu());
				oMap.put(tableName, row, "MINI_KREDI_MI", dcsGecikmeGonderiKarar.getMiniKrediMi());
				oMap.put(tableName, row, "FAIZSIZ_FINANSMAN_EH", dcsGecikmeGonderiKarar.getFaizsizFinansmanEh());
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN8004_GET_COMBO_BOX_DATA")
	public static GMMap getComboBoxData(GMMap iMap) {

		String listName = "COMBO_BOX_URUN_TIP";
		GuimlUtil.wrapMyCombo(iMap, listName, "KMH", "KMH");
		GuimlUtil.wrapMyCombo(iMap, listName, "BK", "Bireysel Krediler");
		GuimlUtil.wrapMyCombo(iMap, listName, "KK", "Kredi Kartı");
		
		listName = "COMBO_BOX_GONDERI_TIP";
		GuimlUtil.wrapMyCombo(iMap, listName, "SMS", "SMS");
		GuimlUtil.wrapMyCombo(iMap, listName, "EMAIL", "E-Mail");
		GuimlUtil.wrapMyCombo(iMap, listName, "IVN", "IVN");
		
		listName = "COMBO_BOX_TOPLU_MU";
		GuimlUtil.wrapMyCombo(iMap, listName, "E", "EVET");
		GuimlUtil.wrapMyCombo(iMap, listName, "H", "HAYIR");

		listName = "COMBO_BOX_KISMI_ODEME";
		GuimlUtil.wrapMyCombo(iMap, listName, "E", "EVET");
		GuimlUtil.wrapMyCombo(iMap, listName, "H", "HAYIR");
		
		listName = "COMBO_BOX_MINI_KREDI_MI";
		GuimlUtil.wrapMyCombo(iMap, listName, "E", "EVET");
		GuimlUtil.wrapMyCombo(iMap, listName, "H", "HAYIR");		
		
		listName = "COMBO_BOX_FAIZSIZ_FINANSMAN_EH";
		GuimlUtil.wrapMyCombo(iMap, listName, "E", "EVET");
		GuimlUtil.wrapMyCombo(iMap, listName, "H", "HAYIR");

		return iMap;
	}

	@GraymoundService("BNSPR_TRN8004_SAVE")
	public static Map<?, ?> saveTRN8004(GMMap iMap) {

		//System.out.println("maxId" + new GMMap(getMaxId(iMap)).getBigDecimal("maxId"));

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "DCS_GECIKME_GONDERI_KARAR";
			ArrayList<?> list = (ArrayList<?>) iMap.get(tableName);
			for (int i = 0; i < list.size(); i++) {
				DcsGecikmeGonderiKararTx dcsGecikmeGonderiKararTx = new DcsGecikmeGonderiKararTx();
				DcsGecikmeGonderiKararTxId id = new DcsGecikmeGonderiKararTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));

				if (iMap.getBigDecimal(tableName, i, "ID") != null)
					id.setId(iMap.getBigDecimal(tableName, i, "ID"));
				else
					id.setId((new GMMap(getMaxId(iMap)).getBigDecimal("maxId")));

				dcsGecikmeGonderiKararTx.setId(id);
				dcsGecikmeGonderiKararTx.setGecikmeGunSayisi(iMap.getBigDecimal(tableName, i, "GECIKME_GUN_SAYISI"));
				dcsGecikmeGonderiKararTx.setKanalKod(iMap.getString(tableName, i, "KANAL_KOD"));

				if (iMap.getString(tableName, i, "KISMI_ODEME") != null && iMap.getString(tableName, i, "KISMI_ODEME").length() > 0)
					dcsGecikmeGonderiKararTx.setKismiOdeme(iMap.getString(tableName, i, "KISMI_ODEME"));
				else
					dcsGecikmeGonderiKararTx.setKismiOdeme("H");

				dcsGecikmeGonderiKararTx.setKmhTurKod(iMap.getBigDecimal(tableName, i, "KMH_TUR_KOD"));
				dcsGecikmeGonderiKararTx.setIcerik(iMap.getString(tableName, i, "ICERIK"));
				dcsGecikmeGonderiKararTx.setTaksitSiraNo(iMap.getBigDecimal(tableName, i, "TAKSIT_SIRA_NO"));
				dcsGecikmeGonderiKararTx.setUrunTip(iMap.getString(tableName, i, "URUN_TIP"));
				dcsGecikmeGonderiKararTx.setGonderiTip(iMap.getString(tableName, i, "GONDERI_TIP"));

				if (iMap.getString(tableName, i, "TOPLU_MU") != null && iMap.getString(tableName, i, "TOPLU_MU").length() > 0)
					dcsGecikmeGonderiKararTx.setTopluMu(iMap.getString(tableName, i, "TOPLU_MU"));
				else
					dcsGecikmeGonderiKararTx.setTopluMu("H");
				
				if (iMap.getString(tableName, i, "MINI_KREDI_MI") != null && iMap.getString(tableName, i, "MINI_KREDI_MI").length() > 0)
					dcsGecikmeGonderiKararTx.setMiniKrediMi(iMap.getString(tableName, i, "MINI_KREDI_MI"));
				else
					dcsGecikmeGonderiKararTx.setMiniKrediMi("H");
				
				if (iMap.getString(tableName, i, "FAIZSIZ_FINANSMAN_EH") != null && iMap.getString(tableName, i, "FAIZSIZ_FINANSMAN_EH").length() > 0)
					dcsGecikmeGonderiKararTx.setFaizsizFinansmanEh(iMap.getString(tableName, i, "FAIZSIZ_FINANSMAN_EH"));
				else
					dcsGecikmeGonderiKararTx.setFaizsizFinansmanEh("H");
				session.save(dcsGecikmeGonderiKararTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "8004");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static Map<?, ?> getMaxId(GMMap iMap) {

		DcsGecikmeGonderiKararTx dcsGecikmeGonderiKararTx;
		DcsGecikmeGonderiKarar dcsGecikmeGonderiKarar;
		BigDecimal maxId = BigDecimal.ZERO;

		Session session = DAOSession.getSession("BNSPRDal");

		List<?> listDcsGecikmeGonderiKararTx = session.createCriteria(DcsGecikmeGonderiKararTx.class).addOrder(Order.desc("id")).setMaxResults(1).list();
		List<?> listDcsGecikmeGonderiKarar = session.createCriteria(DcsGecikmeGonderiKarar.class).addOrder(Order.desc("id")).setMaxResults(1).list();

		if (listDcsGecikmeGonderiKararTx.size() != 0) {
			dcsGecikmeGonderiKararTx = (DcsGecikmeGonderiKararTx) listDcsGecikmeGonderiKararTx.get(0);
			maxId = dcsGecikmeGonderiKararTx.getId().getId();
		}
		else {
			if(listDcsGecikmeGonderiKarar.size() != 0){
				dcsGecikmeGonderiKarar = (DcsGecikmeGonderiKarar) listDcsGecikmeGonderiKarar.get(0);
				maxId = dcsGecikmeGonderiKarar.getId();
			}
		}

		iMap.put("maxId", maxId.add(BigDecimal.ONE));
		return iMap;
	}

	public static String getKmhTurKodAciklama(DcsGecikmeGonderiKarar dcsGecikmeGonderiKarar) {

		String kmhTurkodAciklama = null;

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			session.beginTransaction();

			String hql = "select aciklama,kod from (" + LovHelper.getLOVQuery("3119/LOV_KDH_TUR_KOD") + ") where kod = :kod";

			SQLQuery query = session.createSQLQuery(hql);
			if (dcsGecikmeGonderiKarar.getKmhTurKod() != null)
				query.setString("kod", dcsGecikmeGonderiKarar.getKmhTurKod().toString());
			else
				query.setString("kod", null);

			List<Object[]> rows = query.list();
			for (Object[] row : rows) {
				kmhTurkodAciklama = (String) row[0];
			}

			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return kmhTurkodAciklama;

	}
}
