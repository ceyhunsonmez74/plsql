package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirihtarnameMusteriLog;
import tr.com.aktifbank.bnspr.dao.BirihtarnameSorguLog;
import tr.com.aktifbank.bnspr.dao.Kkihtarname;
import tr.com.aktifbank.bnspr.dao.KkihtarnameId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprOceanCommonFunctions;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class ConsumerLoanQRY3297Services {
	protected static Charset charset = Charset.forName("iso-8859-9");

	@GraymoundService("BNSPR_QRY3297_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc3297.kk_ihtar_min_gun}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.execute();
			oMap.put("MIN_GUN", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3297_QUERY_IHTAR")
	public static GMMap queryIhtar(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3295.sorgu_no_al()}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.execute();

			oMap.put("SORGU_NO", stmt.getBigDecimal(1));
			stmt.close();
			stmt = conn.prepareCall("{call pkg_rc3297.kk_sorgu_sonucu_hazirla(?,?,?,?,?,?)}");
			stmt.setBigDecimal(1, oMap.getBigDecimal("SORGU_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(3, iMap.getString("KART_NO"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("GECIKME_GUN_SAYISI_ALT"));
			stmt.setBigDecimal(5, iMap.getBigDecimal("GECIKME_GUN_SAYISI_UST"));
			stmt.registerOutParameter(6, -10); // ref cursor

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(6);
			String tableName = "TABLE_DATA";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "TC_KIMLIK_NO", rSet.getObject("TC_KIMLIK_NO"));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getObject("MUSTERI_NO"));
				oMap.put(tableName, row, "AD_SOYAD", rSet.getObject("AD_SOYAD"));
				oMap.put(tableName, row, "TOPLAM_BORC", rSet.getObject("TOPLAM_BORC"));
				oMap.put(tableName, row, "GECIKME_GUN", rSet.getObject("GECIKME_GUN"));
				oMap.put(tableName, row, "IHTARNAME_TIP", rSet.getObject("IHTARNAME_TIP"));
				row++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY3297_IHTARNAME")
	public static GMMap setIhtarname(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "TABLE_DATA";
			String serviceName = "BNSPR_KPS_GET_ADDRESS_INFO";
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				iMap.put("TCKN", iMap.getString(tableName, i, "TC_KIMLIK_NO"));
				BirihtarnameMusteriLog birihtarnameMusteriLog = (BirihtarnameMusteriLog) session.createCriteria(BirihtarnameMusteriLog.class).add(Restrictions.eq("id.musteriNo", iMap.getBigDecimal(tableName, i, "MUSTERI_NO"))).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).uniqueResult();
				if (iMap.getBoolean(tableName, i, "YAZDIR") && !StringUtils.isEmpty(iMap.getString("TCKN"))) {
					iMap.put("ADDRESS_LOG_ID", GMServiceExecuter.call(serviceName, iMap).getString("LOG_ID"));
					birihtarnameMusteriLog.setApsSorguId(iMap.getBigDecimal("ADDRESS_LOG_ID"));
					birihtarnameMusteriLog.setIhtarnameEh("E");
				}
				else {
					birihtarnameMusteriLog.setIhtarnameEh("H");
				}
				session.saveOrUpdate(birihtarnameMusteriLog);
			}
			BirihtarnameSorguLog birihtarnameSorguLog = (BirihtarnameSorguLog) session.createCriteria(BirihtarnameSorguLog.class).add(Restrictions.eq("sorguNo", iMap.getBigDecimal("SORGU_NO"))).uniqueResult();
			birihtarnameSorguLog.setOlusturTarih(new java.util.Date());
			session.saveOrUpdate(birihtarnameSorguLog);
			session.flush();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC3297.ihtarname_olustur(?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("SORGU_NO"));
			stmt.registerOutParameter(2, -10);
			stmt.registerOutParameter(3, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(2);
			rSet2 = (ResultSet) stmt.getObject(3);

			tableName = "MUSTERI_LIST";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "TC_KIMLIK_NO", rSet.getString("TC_KIMLIK_NO"));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
				oMap.put(tableName, row, "AD_SOYAD", rSet.getString("AD_SOYAD"));
				oMap.put(tableName, row, "ADRES", rSet.getString("ADRES"));
				oMap.put(tableName, row, "TOPLAM_BORC", formatCurrency(rSet.getBigDecimal("TOPLAM_BORC")));
				oMap.put(tableName, row, "IHTAR_MASRAF", formatCurrency(rSet.getBigDecimal("IHTAR_MASRAF")));
				row++;
			}

			tableName = "KREDI_LIST";
			row = 0;
			while (rSet2.next()) {
				oMap.put(tableName, row, "MUSTERI_NO", rSet2.getString("MUSTERI_NO"));
				// basvuru no alanina kartin son 4 hanesi yazildi.
				String cardNumber = StringUtils.leftPad(rSet2.getString("BASVURU_NO"), 4, "0");
				oMap.put(tableName, row, "KART_NO", cardNumber);
				oMap.put(tableName, row, "ASGARI_ODEME_TUTAR", formatCurrency(rSet2.getBigDecimal("ASGARI_ODEME_TUTAR")));
				oMap.put(tableName, row, "ANAPARA_TUTAR", formatCurrency(rSet2.getBigDecimal("ANAPARA_TUTARI")));
				oMap.put(tableName, row, "GECIKME_FAIZ_TUTAR", formatCurrency(rSet2.getBigDecimal("GECIKME_FAIZ_TUTAR")));
				oMap.put(tableName, row, "KKDF_TUTAR", formatCurrency(rSet2.getBigDecimal("KKDF_TUTARI")));
				oMap.put(tableName, row, "BSMV_TUTAR", formatCurrency(rSet2.getBigDecimal("BSMV_TUTARI")));
				oMap.put(tableName, row, "TOPLAM_BORC_TUTARI", formatCurrency(rSet2.getBigDecimal("TOPLAM_BORC")));
                oMap.put(tableName, row, "BAGLI_HESAP_NO", rSet2.getString("BAGLI_HESAP_NO"));
                oMap.put(tableName, row, "IBAN", rSet2.getString("IBAN"));
				row++;
			}

			stmt.close();
			oMap.putAll(GMServiceExecuter.call("BNSPR_KK_IHTAR_RAPOR", oMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static String formatCurrency(BigDecimal value) {
		if (value == null || value.compareTo(BigDecimal.ZERO) == 0)
        	return "0,00";
		DecimalFormat formatter = new DecimalFormat("###,###.00");
		DecimalFormatSymbols symbols = new DecimalFormatSymbols(Locale.getDefault());
		symbols.setDecimalSeparator(',');
		symbols.setGroupingSeparator('.');
		formatter.setDecimalFormatSymbols(symbols);
		return formatter.format(value);
	}

	@GraymoundService("BNSPR_QRY3297_SELECT_ALL")
	public static GMMap selectAll(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (iMap.getBoolean("CHECKED")) {
				for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
					iMap.put("TABLE_DATA", i, "YAZDIR", true);
				}
			}
			else {
				for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
					iMap.put("TABLE_DATA", i, "YAZDIR", false);
				}
			}
			oMap.put("TABLE_DATA", iMap.get("TABLE_DATA"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}

	}

	@GraymoundService("BNSPR_QRY3297_IHTARNAME_TARIHI_GUNCELLE")
	public static GMMap ihtarnameTarihiGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{call pkg_rc3297.ihtarname_tarihi_guncelle(?) }";
			Object[] inputValues = { BnsprType.NUMBER, iMap.getBigDecimal("SORGU_NO") };
			Object[] outputValues = {};
			DALUtil.callOracleProcedure(func, inputValues, outputValues);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY3297_DOSYA_YUKLE")
	public static GMMap dosyaYukle(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			GMMap oMap = new GMMap();
			OutputStreamWriter wr = null;
			BufferedReader br = null;
			File file = FileUtil.createTempDirFile("txtread");
			wr = new OutputStreamWriter(new FileOutputStream(file), charset);
			wr.write(new String((byte[]) iMap.get("CONTENT"), charset));
			wr.close();

			br = new BufferedReader(new InputStreamReader(new FileInputStream(file), charset));
			String line = "";
			String dosyaAdi = br.readLine().substring(0, 23).trim();
			GMMap tMap = new GMMap();
			tMap.put("TABLE_NAME", "KK_IHTARNAME");
			BigDecimal dosyaNo = (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", tMap).get("ID");
			while ((line = br.readLine()).charAt(0) != 'F') {
				KkihtarnameId kkihtarnameId = new KkihtarnameId();
				kkihtarnameId.setKartNo(line.substring(12, 31).trim());
				kkihtarnameId.setDosyaNo(dosyaNo);
				Kkihtarname kkihtarname = new Kkihtarname();
				kkihtarname.setId(kkihtarnameId);
				kkihtarname.setMusteriNo(new BigDecimal(line.substring(1, 11).trim()));
				kkihtarname.setDosyaAdi(dosyaAdi);
				kkihtarname.setToplamBorcTutar(new BigDecimal(line.substring(32, 50).trim()));
				kkihtarname.setGecikmeGunSay(new BigDecimal(line.substring(51, 55).trim()));
				kkihtarname.setAsgariOdemeTutar(new BigDecimal(line.substring(56, 74).trim()));
				kkihtarname.setAnaparaTutar(new BigDecimal(line.substring(75, 93).trim()));
				kkihtarname.setGecikmeFaizTutar(new BigDecimal(line.substring(94, 112).trim()));
				kkihtarname.setAkdiFaiz(new BigDecimal(line.substring(113, 131).trim()));
				kkihtarname.setKkdfTutar(new BigDecimal(line.substring(132, 150).trim()));
				kkihtarname.setBsmvTutar(new BigDecimal(line.substring(151, 169).trim()));
				kkihtarname.setToplamKartLimit(new BigDecimal(line.substring(170, 188).trim()));
				kkihtarname.setStatu(line.substring(189, 192).trim());
				kkihtarname.setYuklemeTarihi(new java.util.Date());
				kkihtarname.setGecikmeBaslangicTarihi(subtractDay(Integer.valueOf(line.substring(51, 55).trim())));
				kkihtarname.setVadesizHesapNo(new BigDecimal(line.substring(193, 203).trim()));
				session.save(kkihtarname);
			}
			session.flush();
			br.close();
			file.delete();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static GMMap getLineFromFTM(long start, long end, BigDecimal ftmTransferId) throws Exception {
		try {
			String fetchQuery = String.format("SELECT FFC.LINE_NUMBER, FFC.LINE FROM FTM.FTM_FILE_CONTENT FFC " + "WHERE FFC.FTM_PROCESS_OID = %s AND FFC.LINE_NUMBER >= %s AND FFC.LINE_NUMBER <= %s " + "ORDER BY FFC.LINE_NUMBER", ftmTransferId, start, end);
			final String tableName = "FILE_LINE";

			return DALUtil.getResults(fetchQuery, tableName);
		}
		catch (Exception e) {
			throw e;
		}
	}

	@GraymoundService("BNSPR_QRY3297_FTP_DOSYA_YUKLE")
	public static GMMap ftpDosyaYukle(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			long start = 1;
			long end = 100;
			long interval = 100;
			BigDecimal ftmTransferId = iMap.getBigDecimal("PROCESS_ID");

			GMMap fileMap = getLineFromFTM(start, end, ftmTransferId);

			String dosyaAd = "";
			String line = "";
			String lineType = "";
			Session session = DAOSession.getSession("BNSPRDal");

			GMMap tMap = new GMMap();
			tMap.put("TABLE_NAME", "KK_IHTARNAME");
			BigDecimal dosyaNo = (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", tMap).get("ID");
			String clearCardNo = StringUtils.EMPTY;

			while (fileMap.get("FILE_LINE") != null) {
				int lineCount = fileMap.getSize("FILE_LINE");

				for (int i = 0; i < lineCount; i++) {
					line = fileMap.getString("FILE_LINE", i, "LINE");
					lineType = line.substring(0, 1);

					if (!lineType.equals("F")) {
						if (lineType.equals("H")) {
							dosyaAd = line.substring(0, 23).trim();
						}
						else if (lineType.equals("D")) {
							KkihtarnameId kkihtarnameId = new KkihtarnameId();
							
							clearCardNo = BnsprOceanCommonFunctions.getClearCardNo(line.substring(12, 31).trim());							
							//kkihtarnameId.setKartNo(line.substring(12, 31).trim());
							kkihtarnameId.setKartNo(clearCardNo);
							
							kkihtarnameId.setDosyaNo(dosyaNo);
							Kkihtarname kkihtarname = new Kkihtarname();
							kkihtarname.setId(kkihtarnameId);
							kkihtarname.setMusteriNo(new BigDecimal(line.substring(1, 11).trim()));
							kkihtarname.setDosyaAdi(dosyaAd);
							kkihtarname.setToplamBorcTutar(new BigDecimal(line.substring(32, 50).trim()));
							kkihtarname.setGecikmeGunSay(new BigDecimal(line.substring(51, 55).trim()));
							kkihtarname.setAsgariOdemeTutar(new BigDecimal(line.substring(56, 74).trim()));
							kkihtarname.setAnaparaTutar(new BigDecimal(line.substring(75, 93).trim()));
							kkihtarname.setGecikmeFaizTutar(new BigDecimal(line.substring(94, 112).trim()));
							kkihtarname.setAkdiFaiz(new BigDecimal(line.substring(113, 131).trim()));
							kkihtarname.setKkdfTutar(new BigDecimal(line.substring(132, 150).trim()));
							kkihtarname.setBsmvTutar(new BigDecimal(line.substring(151, 169).trim()));
							kkihtarname.setToplamKartLimit(new BigDecimal(line.substring(170, 188).trim()));
							kkihtarname.setStatu(line.substring(189, 192).trim());
							kkihtarname.setYuklemeTarihi(new java.util.Date());
							kkihtarname.setGecikmeBaslangicTarihi(subtractDay(Integer.valueOf(line.substring(51, 55).trim())));
							kkihtarname.setVadesizHesapNo(new BigDecimal(line.substring(193, 203).trim()));
							session.save(kkihtarname);
						}
					}
				}

				session.flush();

				fileMap.clear();
				start = interval + start;
				end = interval + end;
				fileMap = getLineFromFTM(start, end, ftmTransferId);
			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static Date subtractDay(Integer day) {
		Calendar c = Calendar.getInstance();    
		c.setTime(new Date());
		c.add(Calendar.DATE, -day);
		return c.getTime();		
	}
}