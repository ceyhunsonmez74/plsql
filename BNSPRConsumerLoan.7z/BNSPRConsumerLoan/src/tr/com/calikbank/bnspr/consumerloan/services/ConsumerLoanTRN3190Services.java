package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTxId;
import tr.com.aktifbank.bnspr.dao.BirBasvuruistTcmbTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruistTcmbTxId;
import tr.com.aktifbank.bnspr.dao.BirTahsisDegerGorusTx;
import tr.com.aktifbank.bnspr.dao.BirTahsisDegerGorusTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuruTeminatTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruTeminatTxId;
import tr.com.calikbank.bnspr.dao.BirBasvuruistTcmbKayitTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruistTcmbKayitTxId;
import tr.com.calikbank.bnspr.dao.BirBasvuruistihbaratTx;
import tr.com.calikbank.bnspr.dao.BirTahsisDegerTx;
import tr.com.calikbank.bnspr.dao.BirTahsisDogrulamaTx;
import tr.com.calikbank.bnspr.dao.BirTahsisDogrulamaTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

@SuppressWarnings("deprecation")
public class ConsumerLoanTRN3190Services {
    @GraymoundService("BNSPR_TRN3190_FILL_COMBOBOX_INITIAL_VALUE")
    public static GMMap fillComboBoxInitialValues(GMMap iMap) {
        try{
            GMMap oMap = new GMMap();
            
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3174_FILL_COMBOBOX_INITIAL_VALUE" , iMap));
            
            oMap.remove("DURUM");
            String listName = "DURUM";
            GuimlUtil.wrapMyCombo(oMap , listName , "B" , "Benzer");
            GuimlUtil.wrapMyCombo(oMap , listName , "K" , "Kesin");
            GuimlUtil.wrapMyCombo(oMap , listName , "Y" , "Yok");
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3190_GET_ISTIHBARAT_AKSIYON_KARAR_KOD")
    public static GMMap getBasvuruAksiyonKararKod(GMMap iMap) {
        try{
            GMMap oMap = new GMMap();
            StringBuffer query = new StringBuffer("select key2,text from gnl_param_text where kod = 'ISTIHBARAT_AKSIYON_KARAR_KOD' and key1='" + iMap.getString("KARAR") + "'");
            if (iMap.getString("IADE_KOD") != null)
                query.append(" and key3 = '" + iMap.getString("IADE_KOD") + "'");
            query.append(" order by to_number(key2)");
            DALUtil.fillComboBox(oMap , "AKSIYON_KARAR_KOD" , true , query.toString());
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3190_GET_DETAY")
    public static GMMap getDetay(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        ResultSet rSet2 = null;
        try{
            GMMap oMap = new GMMap();
            
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call PKG_TRN3174.RC_QRY3174_GET_DETAY_LIST(?)}");
            stmt.registerOutParameter(1 , -10);
            stmt.setBigDecimal(2 , iMap.getBigDecimal("BASVURU_NO"));
            
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            
            oMap.putAll(DALUtil.rSetMap(rSet));
            
			if (oMap.getString("ANNE_KIZLIK_SOYADI") != null) {

				StringBuffer anneOncekiSoyad = new StringBuffer(oMap.getString("ANNE_KIZLIK_SOYADI"));

				for (int i = 0; i < anneOncekiSoyad.length(); i++) {
					if (i % 2 == 1) {
						anneOncekiSoyad.setCharAt(i, '*');
					}
				}

				oMap.put("ANNE_KIZLIK_SOYADI", anneOncekiSoyad);
			}
			
			BigDecimal onOnayTut = oMap.getBigDecimal("ON_ONAY_TUTAR");
		    oMap.put("ON_ONAYLI_MI", onOnayTut.signum() > 0);
            
            if (oMap.getString("BAYI_GORUS") != null){
                oMap.put("BAYI_GORUS" , (oMap.getString("BAYI_GORUS").replace(", " , "\n")).trim());
            }
            oMap.put("TEMINAT" , GMServiceExecuter.execute("BNSPR_TRN3174_GET_TEMINAT_LIST" , iMap).get("TEMINAT"));
            oMap.put("TAHSIS_GORUS_LIST" , GMServiceExecuter.execute("BNSPR_TRN3174_GET_TAHSIS_GORUS_LIST" , iMap).get("TAHSIS_GORUS_LIST"));
            oMap.put("MUSTERI_KONTROL_LIST" , GMServiceExecuter.execute("BNSPR_TRN3174_GET_MUSTERI_KONTROL_TAKIP" , iMap).get("MUSTERI_KONTROL_LIST"));
            oMap.put("BELGE" , GMServiceExecuter.execute("BNSPR_TRN3174_GET_BELGE_LIST" , iMap).get("BELGE"));
            if(oMap.getString("SATICI_KOD") == null && oMap.getString("MERKEZ_BAYI_KOD") != null)
            	iMap.put("SATICI_KOD" , oMap.getString("MERKEZ_BAYI_KOD"));
            else
            	iMap.put("SATICI_KOD" , oMap.getString("SATICI_KOD"));
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3174_GET_SATICI_TAHSIS_DATA" , iMap));
            oMap.put("KONTAKT_MUSTERI" , "K".equals(oMap.getString("KONTAKT_MUSTERI")) ? true : false);
            oMap.put("ISTEGE_BAGLI_SIGORTALI" , "E".equals(oMap.getString("KONTAKT_MUSTERI")) ? true : false);
            if (oMap.get("KREDI_TUR") != null){
                oMap.put("KREDI_TUR" , oMap.remove("KREDI_TUR").toString());
            }
            if (oMap.get("ODEME_TIP_KOD") != null){
                oMap.put("ODEME_TIP_KOD" , oMap.remove("ODEME_TIP_KOD").toString());
            }
            
            // Distributor Tablosu
            stmt.clearParameters();
            
            stmt = conn.prepareCall("{? = call pkg_trn3174.RC_QRY3174_GET_DISTRIBUTOR(?)}");
            stmt.registerOutParameter(1 , -10);
            if(oMap.getString("SATICI_KOD") == null && oMap.getString("MERKEZ_BAYI_KOD") != null)
            	stmt.setBigDecimal(2 , oMap.getBigDecimal("MERKEZ_BAYI_KOD"));
            else
            	stmt.setBigDecimal(2 , oMap.getBigDecimal("SATICI_KOD"));
            
            stmt.execute();
            
            rSet2 = (ResultSet) stmt.getObject(1);
            
            String tableName = "DISTRIBUTOR";
            int row = 0;
            
            while (rSet2.next()){
                oMap.put(tableName , row , "KOD" , rSet2.getBigDecimal(1));
                oMap.put(tableName , row , "SATICI_ADI" , rSet2.getString(2));
                row++;
            }
            // Distributor Tablosu Sonu
            
            String kanal = oMap.getString("DST_KAZANIM_KANAL");
	    if (kanal != null && !kanal.isEmpty()) {
		//bayi kazan�m kanal� degeri parametreden al�n�r
		iMap.clear();
		iMap.put("KOD", "BAYI_KAZANIM_KANAL");
		iMap.put("KEY", oMap.getString("DST_KAZANIM_KANAL"));
		oMap.put("DST_KAZANIM_KANAL", GMServiceExecuter.execute("BNSPR_COMMON_GET_PARAM_TEXT", iMap).get("TEXT"));
	    }
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet2);
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN3190_GET_BASVURU_SORGU_SONUC")
    public static GMMap getBasvuruSorguSonuc(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call pkg_basvuru_sorgu.BasvuruSorguSonuc(?,?,?,?,?,?,?,?,?) }");
            
            int i = 1;
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("BASVURU_NO"));
            stmt.registerOutParameter(i++ , Types.VARCHAR);
            stmt.registerOutParameter(i++ , Types.VARCHAR);
            stmt.registerOutParameter(i++ , Types.VARCHAR);
            stmt.registerOutParameter(i++ , Types.VARCHAR);
            stmt.registerOutParameter(i++ , Types.VARCHAR);
            stmt.registerOutParameter(i++ , Types.VARCHAR);
            stmt.registerOutParameter(i++ , Types.VARCHAR);
            stmt.registerOutParameter(i++ , Types.VARCHAR);
            
            stmt.execute();
            GMMap oMap = new GMMap();
            oMap.put("FRAUD_SONUC" , stmt.getString(--i));
            oMap.put("CAPRAZ_SORGU_SONUC" , stmt.getString(--i));
            oMap.put("KARA_LISTE_SONUC" , stmt.getString(--i));
            oMap.put("TCMB_MAHKEME_SONUC" , stmt.getString(--i));
            oMap.put("TCMB_SENET_SONUC" , stmt.getString(--i));
            oMap.put("TCMB_CEK_SONUC" , stmt.getString(--i));
            oMap.put("TCMB_KREDI_SONUC" , stmt.getString(--i));
            oMap.put("KKB_SONUC" , stmt.getString(--i));
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(conn);
            GMServerDatasource.close(stmt);
        }
    }
    
    @GraymoundService("BNSPR_TRN3190_SAVE")
    public static GMMap save(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            
            BirBasvuruistihbaratTx birBasvuruIstihbaratTx =
                    (BirBasvuruistihbaratTx) session.createCriteria(BirBasvuruistihbaratTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            if (birBasvuruIstihbaratTx == null)
                birBasvuruIstihbaratTx = new BirBasvuruistihbaratTx();
            
            birBasvuruIstihbaratTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            birBasvuruIstihbaratTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            birBasvuruIstihbaratTx.setAksiyonKod(iMap.getString("AKSIYON_KOD"));// karar
            birBasvuruIstihbaratTx.setAksiyonKararKod(iMap.getString("AKSIYON_KARAR_KOD"));
            birBasvuruIstihbaratTx.setIadeKod(iMap.getString("IADE_KOD"));
            birBasvuruIstihbaratTx.setGorus(iMap.getString("GORUS"));
            birBasvuruIstihbaratTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
            birBasvuruIstihbaratTx.setTahsisGorus(iMap.getString("IT_GORUS"));
            birBasvuruIstihbaratTx.setYeniAnneKizlikSoyad(iMap.getString("YENI_ANNE_KIZLIK_SOYAD"));
            
            session.saveOrUpdate(birBasvuruIstihbaratTx);
            session.flush();
                        
            List<?> lastTeminatList =
                session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
                    .list();
            for (Iterator<?> iterator = lastTeminatList.iterator(); iterator.hasNext();) {
                BirBasvuruTeminatTx birBasvuruTeminatTx = (BirBasvuruTeminatTx) iterator.next();
                session.delete(birBasvuruTeminatTx);
            }
            session.flush();

            List<?> teminatList = (List<?>) iMap.get("TEMINAT");
            String tableName = "TEMINAT";

            for (int i = 0; i < teminatList.size(); i++) {
                BirBasvuruTeminatTx birBasvuruTeminatTx =
                    (BirBasvuruTeminatTx) session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
                        .add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.teminatKod", iMap.getString(tableName, i, "TEMINAT_ADI"))).uniqueResult();
                if (birBasvuruTeminatTx == null) {
                    birBasvuruTeminatTx = new BirBasvuruTeminatTx();
                    BirBasvuruTeminatTxId birBasvuruTeminatTxId = new BirBasvuruTeminatTxId();

                    birBasvuruTeminatTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    birBasvuruTeminatTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                    birBasvuruTeminatTxId.setTeminatKod(iMap.getString(tableName, i, "TEMINAT_ADI"));
                    birBasvuruTeminatTx.setId(birBasvuruTeminatTxId);
                }

                birBasvuruTeminatTx.setTeminatAdedi(iMap.getBigDecimal(tableName, i, "TEMINAT_ADEDI"));
                session.save(birBasvuruTeminatTx);
            }
            session.flush();
            
            List<?> lastBelgeList =
                session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
                    .list();
            for (Iterator<?> iterator = lastBelgeList.iterator(); iterator.hasNext();) {
                BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) iterator.next();
                session.delete(birBasvuruBelgeTx);
            }
            session.flush();
            String calendarFormat = "yyyyMMdd kkmmss";
            List<?> belgeList = (List<?>) iMap.get("BELGE");
            tableName = "BELGE";
            for (int i = 0; i < belgeList.size(); i++){
                BirBasvuruBelgeTx birBasvuruBelgeTx =
                        (BirBasvuruBelgeTx) session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                Restrictions.eq("id.basvuruNo" , iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.kimden" , iMap.getString(tableName , i , "KIMDEN_KOD"))).add(
                                Restrictions.eq("id.dokumanKod" , iMap.getString(tableName , i , "BELGE_KOD"))).uniqueResult();
                if (birBasvuruBelgeTx == null){
                    birBasvuruBelgeTx = new BirBasvuruBelgeTx();
                    BirBasvuruBelgeTxId birBasvuruBelgeTxId = new BirBasvuruBelgeTxId();
                    
                    birBasvuruBelgeTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    birBasvuruBelgeTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                    birBasvuruBelgeTxId.setDokumanKod(iMap.getString(tableName , i , "BELGE_KOD"));
                    birBasvuruBelgeTxId.setKimden(iMap.getString(tableName , i , "KIMDEN_KOD"));
                    birBasvuruBelgeTx.setAlindi(iMap.getString(tableName, i, "ALINDI"));
                    birBasvuruBelgeTx.setBelgeKontrol(iMap.getString(tableName, i, "BELGE_KONTROL"));
                    birBasvuruBelgeTx.setOrjinalEvrakMi(iMap.getString(tableName, i, "ORJINAL_EVRAK_MI"));
                    if (iMap.getString(tableName, i, "BELGE_GELIS_TARIHI") != null)                    	
                    	birBasvuruBelgeTx.setBelgeGelisTarihi(new SimpleDateFormat(calendarFormat).parse(iMap.getString(tableName, i, "BELGE_GELIS_TARIHI")));
                    if (iMap.getString(tableName, i, "ISLEM_TARIHI") != null)
                    	birBasvuruBelgeTx.setIslemTarihi(new SimpleDateFormat(calendarFormat).parse(iMap.getString(tableName, i, "ISLEM_TARIHI")));
                    birBasvuruBelgeTx.setBelgeHata(iMap.getString(tableName, i, "BELGE_HATA"));
                    birBasvuruBelgeTx.setBarkodNumarasi(iMap.getString(tableName, i, "BARKOD_NUMARASI"));
                    birBasvuruBelgeTx.setOnayliMi(iMap.getString(tableName, i, "ONAYLI_MI"));
                    birBasvuruBelgeTx.setUyumsuzAciklama(iMap.getString(tableName, i, "UYUMSUZ_ACIKLAMA"));
                    birBasvuruBelgeTx.setBelgeYeri(iMap.getString(tableName, i, "BELGE_YERI"));
                    birBasvuruBelgeTx.setKontrolNedeni(iMap.getString(tableName, i, "KONTROL_NEDENI"));
                    birBasvuruBelgeTx.setIslemYapanKullanici(iMap.getString(tableName, i, "ISLEM_YAPAN_KULLANICI"));
                    birBasvuruBelgeTx.setId(birBasvuruBelgeTxId);
                    String belgeAlinmaAdim = iMap.getString(tableName , i , "BELGE_ALINMA_ADIMI") != null &&
												!iMap.getString(tableName , i , "BELGE_ALINMA_ADIMI").trim().isEmpty() 
													? iMap.getString(tableName , i , "BELGE_ALINMA_ADIMI") : "S" ;
					birBasvuruBelgeTx.setBelgeAlinmaAdim(belgeAlinmaAdim);
                }
                session.save(birBasvuruBelgeTx);
            }
            session.flush();
            
            String tcmbTableName = "TCMB_OZET_TABLE";
            String krediTableName = "KREDI_MODEL";
            String cekTableName = "CEK_MODEL";
            String mahkemeTableName = "MAHKEME_MODEL";
            String senetTableName = "SENET_MODEL";
            String temp;
            
            List<?> tcmbList = (List<?>) iMap.get(tcmbTableName);
            if (tcmbList != null){
                for (int i = 0; i < tcmbList.size(); i++){
                    String krediSonuc = "Y";
                    String cekSonuc = "Y";
                    String senetSonuc = "Y";
                    String mahkemeSonuc = "Y";
                    
                    List<?> krediList = (List<?>) iMap.get(tcmbTableName , i , krediTableName);
                    if (krediList != null){
                        for (int j = 0; j < krediList.size(); j++){
                            GMMap krediListMap = new GMMap((HashMap<?, ?>) krediList.get(j));
                            if (krediListMap.getString("IST_DURUM").equals("X")){
                                temp = krediListMap.getString("DURUM");
                            } else{
                                temp = krediListMap.getString("IST_DURUM");
                                
                                BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx =
                                        (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                                Restrictions.eq("id.kayitId" , krediListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
                                if (birBasvuruistTcmbKayitTx == null){
                                    birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO") , krediListMap.getBigDecimal("KAYIT_ID")));
                                }
                                
                                birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                                birBasvuruistTcmbKayitTx.setTahsisSonuc(krediListMap.getString("IST_DURUM"));
                                birBasvuruistTcmbKayitTx.setSorguTip("K");
                                birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(tcmbTableName , i , "ID"));
                                
                                session.saveOrUpdate(birBasvuruistTcmbKayitTx);
                            }
                            if (temp.equals("Y") && !(krediSonuc.equals("B") || krediSonuc.equals("K"))){
                                krediSonuc = "Y";
                            }
                            if (temp.equals("B") && !krediSonuc.equals("K")){
                                krediSonuc = "B";
                            }
                            if (temp.equals("K")){
                                krediSonuc = "K";
                            }
                            
                        }
                    }
                    List<?> cekList = (List<?>) iMap.get(tcmbTableName , i , cekTableName);
                    if (cekList != null){
                        for (int j = 0; j < cekList.size(); j++){
                            GMMap cekListMap = new GMMap((HashMap<?, ?>) cekList.get(j));
                            if (cekListMap.getString("IST_DURUM").equals("X")){
                                temp = cekListMap.getString("DURUM");
                            } else{
                                temp = cekListMap.getString("IST_DURUM");
                                
                                BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx =
                                        (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                                Restrictions.eq("id.kayitId" , cekListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
                                if (birBasvuruistTcmbKayitTx == null){
                                    birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO") , cekListMap.getBigDecimal("KAYIT_ID")));
                                }
                                
                                birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                                birBasvuruistTcmbKayitTx.setTahsisSonuc(cekListMap.getString("IST_DURUM"));
                                birBasvuruistTcmbKayitTx.setSorguTip("C");
                                birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(tcmbTableName , i , "ID"));
                                
                                session.saveOrUpdate(birBasvuruistTcmbKayitTx);
                            }
                            if (temp.equals("Y") && !(cekSonuc.equals("B") || cekSonuc.equals("K"))){
                                cekSonuc = "Y";
                            }
                            if (temp.equals("B") && !cekSonuc.equals("K")){
                                cekSonuc = "B";
                            }
                            if (temp.equals("K")){
                                cekSonuc = "K";
                            }
                            
                        }
                    }
                    List<?> mahkemeList = (List<?>) iMap.get(tcmbTableName , i , mahkemeTableName);
                    if (mahkemeList != null){
                        for (int j = 0; j < mahkemeList.size(); j++){
                            GMMap mahkemeListMap = new GMMap((HashMap<?, ?>) mahkemeList.get(j));
                            if (mahkemeListMap.getString("IST_DURUM").equals("X")){
                                temp = mahkemeListMap.getString("DURUM");
                            } else{
                                temp = mahkemeListMap.getString("IST_DURUM");
                                
                                BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx =
                                        (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                                Restrictions.eq("id.kayitId" , mahkemeListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
                                if (birBasvuruistTcmbKayitTx == null){
                                    birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO") , mahkemeListMap.getBigDecimal("KAYIT_ID")));
                                }
                                
                                birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                                birBasvuruistTcmbKayitTx.setTahsisSonuc(mahkemeListMap.getString("IST_DURUM"));
                                birBasvuruistTcmbKayitTx.setSorguTip("M");
                                birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(tcmbTableName , i , "ID"));
                                
                                session.saveOrUpdate(birBasvuruistTcmbKayitTx);
                            }
                            if (temp.equals("Y") && !(mahkemeSonuc.equals("B") || mahkemeSonuc.equals("K"))){
                                mahkemeSonuc = "Y";
                            }
                            if (temp.equals("B") && !mahkemeSonuc.equals("K")){
                                mahkemeSonuc = "B";
                            }
                            if (temp.equals("K")){
                                mahkemeSonuc = "K";
                            }
                            
                        }
                    }
                    List<?> senetList = (List<?>) iMap.get(tcmbTableName , i , senetTableName);
                    if (senetList != null){
                        for (int j = 0; j < senetList.size(); j++){
                            GMMap senetListMap = new GMMap((HashMap<?, ?>) senetList.get(j));
                            if (senetListMap.getString("IST_DURUM").equals("X")){
                                temp = senetListMap.getString("DURUM");
                            } else{
                                temp = senetListMap.getString("IST_DURUM");
                                
                                BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx =
                                        (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                                Restrictions.eq("id.kayitId" , senetListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
                                if (birBasvuruistTcmbKayitTx == null){
                                    birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO") , senetListMap.getBigDecimal("KAYIT_ID")));
                                }
                                
                                birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                                birBasvuruistTcmbKayitTx.setTahsisSonuc(senetListMap.getString("IST_DURUM"));
                                birBasvuruistTcmbKayitTx.setSorguTip("S");
                                birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(tcmbTableName , i , "ID"));
                                
                                session.saveOrUpdate(birBasvuruistTcmbKayitTx);
                            }
                            if (temp.equals("Y") && !(senetSonuc.equals("B") || senetSonuc.equals("K"))){
                                senetSonuc = "Y";
                            }
                            if (temp.equals("B") && !senetSonuc.equals("K")){
                                senetSonuc = "B";
                            }
                            if (temp.equals("K")){
                                senetSonuc = "K";
                            }
                            
                        }
                    }
                    
                    if (!(krediSonuc.equals(iMap.getString(tcmbTableName , i , "KREDI_SONUC")) && cekSonuc.equals(iMap.getString(tcmbTableName , i , "CEK_SONUC"))
                            && mahkemeSonuc.equals(iMap.getString(tcmbTableName , i , "MAHKEME_SONUC")) && senetSonuc.equals(iMap.getString(tcmbTableName , i , "SENET_SONUC")))){
                        
                        BirBasvuruistTcmbTx birBasvuruistTcmbTx =
                                (BirBasvuruistTcmbTx) session.createCriteria(BirBasvuruistTcmbTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                        Restrictions.eq("id.sorguId" , iMap.getBigDecimal(tcmbTableName , i , "ID"))).uniqueResult();
                        if (birBasvuruistTcmbTx == null){
                            birBasvuruistTcmbTx = new BirBasvuruistTcmbTx();
                            BirBasvuruistTcmbTxId birBasvuruistTcmbTxId = new BirBasvuruistTcmbTxId();
                            birBasvuruistTcmbTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                            birBasvuruistTcmbTxId.setSorguId(iMap.getBigDecimal(tcmbTableName , i , "ID"));
                            birBasvuruistTcmbTx.setId(birBasvuruistTcmbTxId);
                            
                        }
                        birBasvuruistTcmbTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                        birBasvuruistTcmbTx.setIslemKod("3190");
                        birBasvuruistTcmbTx.setKrediSonuc(krediSonuc);
                        birBasvuruistTcmbTx.setCekSonuc(cekSonuc);
                        birBasvuruistTcmbTx.setMahkemeSonuc(mahkemeSonuc);
                        birBasvuruistTcmbTx.setSenetSonuc(senetSonuc);
                        
                        session.saveOrUpdate(birBasvuruistTcmbTx);
                        
                    }
                }
            }
            
            session.flush();
            
            String fraudTableName = "FRAUD_OZET_TABLE";
            String caprazTableName = "CAPRAZ_MODEL";
            String karaTableName = "KARA_MODEL";
            
            List<?> fraudList = (List<?>) iMap.get(fraudTableName);
            if (fraudList != null){
                for (int i = 0; i < fraudList.size(); i++){
                    
                    String karaSonuc = "Y";
                    String caprazSonuc = "Y";
                    
                    List<?> caprazList = (List<?>) iMap.get(fraudTableName , i , caprazTableName);
                    if (caprazList != null){
                        for (int j = 0; j < caprazList.size(); j++){
                            GMMap caprazListMap = new GMMap((HashMap<?, ?>) caprazList.get(j));
                            if (caprazListMap.getString("IST_DURUM").equals("X")){
                                temp = caprazListMap.getString("SONUC");
                            } else{
                                temp = caprazListMap.getString("IST_DURUM");
                                
                                BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx =
                                        (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                                Restrictions.eq("id.kayitId" , caprazListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
                                if (birBasvuruistTcmbKayitTx == null){
                                    birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO") , caprazListMap.getBigDecimal("KAYIT_ID")));
                                }
                                
                                birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                                birBasvuruistTcmbKayitTx.setTahsisSonuc(caprazListMap.getString("IST_DURUM"));
                                birBasvuruistTcmbKayitTx.setSorguTip("E");
                                birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(fraudTableName , i , "ID"));
                                
                                session.saveOrUpdate(birBasvuruistTcmbKayitTx);
                            }
                            if (temp.equals("Y") && !(caprazSonuc.equals("B") || caprazSonuc.equals("K"))){
                                caprazSonuc = "Y";
                            }
                            if (temp.equals("B") && !caprazSonuc.equals("K")){
                                caprazSonuc = "B";
                            }
                            if (temp.equals("K")){
                                caprazSonuc = "K";
                            }
                            
                        }
                    }
                    List<?> karaList = (List<?>) iMap.get(fraudTableName , i , karaTableName);
                    if (karaList != null){
                        
                        for (int j = 0; j < karaList.size(); j++){
                            GMMap karaListMap = new GMMap((HashMap<?, ?>) karaList.get(j));
                            if (karaListMap.getString("IST_DURUM").equals("X")){
                                temp = karaListMap.getString("DURUM");
                            } else{
                                temp = karaListMap.getString("IST_DURUM");
                                
                                BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx =
                                        (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                                Restrictions.eq("id.kayitId" , karaListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
                                if (birBasvuruistTcmbKayitTx == null){
                                    birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO") , karaListMap.getBigDecimal("KAYIT_ID")));
                                }
                                
                                birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                                birBasvuruistTcmbKayitTx.setTahsisSonuc(karaListMap.getString("IST_DURUM"));
                                birBasvuruistTcmbKayitTx.setSorguTip("B");
                                birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(fraudTableName , i , "ID"));
                                
                                session.saveOrUpdate(birBasvuruistTcmbKayitTx);
                            }
                            
                            if (temp.equals("Y") && !(karaSonuc.equals("B") || karaSonuc.equals("K"))){
                                karaSonuc = "Y";
                            }
                            if (temp.equals("B") && !karaSonuc.equals("K")){
                                karaSonuc = "B";
                            }
                            if (temp.equals("K")){
                                karaSonuc = "K";
                            }
                            
                        }
                    }
                    
                    if (!(karaSonuc.equals(iMap.getString(fraudTableName , i , "KARA_LISTE_SONUC")) && caprazSonuc.equals(iMap.getString(fraudTableName , i , "ESKI_BASVURU_SONUC")))){
                        
                        BirBasvuruistTcmbTx birBasvuruistTcmbTx =
                                (BirBasvuruistTcmbTx) session.createCriteria(BirBasvuruistTcmbTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                        Restrictions.eq("id.sorguId" , iMap.getBigDecimal(fraudTableName , i , "ID"))).uniqueResult();
                        if (birBasvuruistTcmbTx == null){
                            birBasvuruistTcmbTx = new BirBasvuruistTcmbTx();
                            BirBasvuruistTcmbTxId birBasvuruistTcmbTxId = new BirBasvuruistTcmbTxId();
                            birBasvuruistTcmbTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                            birBasvuruistTcmbTxId.setSorguId(iMap.getBigDecimal(fraudTableName , i , "ID"));
                            birBasvuruistTcmbTx.setId(birBasvuruistTcmbTxId);
                            
                        }
                        
                        birBasvuruistTcmbTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                        birBasvuruistTcmbTx.setIslemKod("3190");
                        birBasvuruistTcmbTx.setCaprazSorguSonuc(caprazSonuc);
                        birBasvuruistTcmbTx.setKaraListeSonuc(karaSonuc);
                        
                        session.saveOrUpdate(birBasvuruistTcmbTx);
                        
                    }
                }
            }
            
            session.flush();
            
            List<?> musteriKontrolList = (List<?>) iMap.get("MUSTERI_KONTROL_LIST");
            tableName = "MUSTERI_KONTROL_LIST";
            for (int i = 0; i < musteriKontrolList.size(); i++){
                BirTahsisDegerGorusTx birTahsisDegerGorusTx =
                        (BirTahsisDegerGorusTx) session.createCriteria(BirTahsisDegerGorusTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                Restrictions.eq("id.basvuruNo" , iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.gorusKod" , iMap.getString(tableName , i , "GORUS_KOD"))).uniqueResult();
                if (birTahsisDegerGorusTx == null){
                    birTahsisDegerGorusTx = new BirTahsisDegerGorusTx();
                    BirTahsisDegerGorusTxId id = new BirTahsisDegerGorusTxId();
                    id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                    id.setGorusKod(iMap.getString(tableName , i , "GORUS_KOD"));
                    birTahsisDegerGorusTx.setId(id);
                    if (iMap.getBoolean(tableName , i , "SEC")){
                        birTahsisDegerGorusTx.setEH("E");
                    } else{
                        birTahsisDegerGorusTx.setEH("H");
                    }
                }
                session.saveOrUpdate(birTahsisDegerGorusTx);
            }
            session.flush();
            // TY-3188 ao 09.02.2015    	    
    	    if (iMap.getString("AKSIYON_KOD") != null && 
    	        "I".equals(iMap.getString("AKSIYON_KOD")) && 
    	        iMap.getString("IADE_KOD") != null && 
    	        "DOGRULAMA".equals(iMap.getString("IADE_KOD"))) {
    	    	
    	    	BirTahsisDegerTx birTahsisDegerTx = (BirTahsisDegerTx) session.get(BirTahsisDegerTx.class, iMap.getBigDecimal("TRX_NO"));

        	    if (birTahsisDegerTx == null)
        		birTahsisDegerTx = new BirTahsisDegerTx();
        	    
        	    birTahsisDegerTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
        	    birTahsisDegerTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
        	    birTahsisDegerTx.setAciklama(iMap.getString("GORUS"));
        	    birTahsisDegerTx.setTahsisGorus(iMap.getString("IT_GORUS"));
        	    birTahsisDegerTx.setDurumKod(iMap.getString("DURUM"));
        	    birTahsisDegerTx.setOnayTutar(iMap.getBigDecimal("ONAY_TUTAR"));
        	    birTahsisDegerTx.setAksiyonKod(iMap.getString("AKSIYON_KOD"));
        	    birTahsisDegerTx.setIadeKod(iMap.getString("IADE_KOD"));
        	    birTahsisDegerTx.setAksiyonKararKod(iMap.getString("AKSIYON_KARAR_KOD"));
        	    birTahsisDegerTx.setAksiyonAltKararKod(iMap.getString("AKSIYON_ALT_KARAR_KOD"));
        	    birTahsisDegerTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
        	    birTahsisDegerTx.setHasarAdedi(iMap.getBigDecimal("HASAR_ADEDI"));
        	    birTahsisDegerTx.setHasarTutari(iMap.getBigDecimal("HASAR_TUTARI"));
        	    birTahsisDegerTx.setAracKmBilgisi(iMap.getBigDecimal("ARAC_KM_BILGISI"));
        	    birTahsisDegerTx.setKmMuayeneTarihi(iMap.getDate("KM_MUAYENE_TARIHI"));

        	    if (iMap.getString("AKSIYON_KOD") != null && 
        	        !("I".equals(iMap.getString("AKSIYON_KOD")) && 
        	        iMap.getString("IADE_KOD") == null))
        		birTahsisDegerTx.setIslemSonrasiDurumKodu("ISTIHBARAT");
        	    
        	    BirTahsisDogrulamaTx birTahsisDogrulamaTxM = (BirTahsisDogrulamaTx) session.createCriteria(BirTahsisDogrulamaTx.class)
        				.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kimIcin", "M")).uniqueResult();

    			if (birTahsisDogrulamaTxM == null) {
    			    birTahsisDogrulamaTxM = new BirTahsisDogrulamaTx();
    			    BirTahsisDogrulamaTxId birTahsisDogrulamaTxId = new BirTahsisDogrulamaTxId();
    			    birTahsisDogrulamaTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
    			    birTahsisDogrulamaTxId.setKimIcin("M");

    			    birTahsisDogrulamaTxM.setId(birTahsisDogrulamaTxId);
    			}

    			birTahsisDogrulamaTxM.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
        			
        	    String nbsmDogSonucStr = "";
        		nbsmDogSonucStr = nbsmDogSonucStr + "MAppVer:"
        			+ (iMap.getString("MUSTERI_DOG_IADE") == null ? "N" : iMap.getString("MUSTERI_DOG_IADE")) + "-";
        		nbsmDogSonucStr = nbsmDogSonucStr + "MEmptVer:"
        			+ (iMap.getString("MUSTERI_ISYERI_DOG_IADE") == null ? "Not Required" : iMap.getString("MUSTERI_ISYERI_DOG_IADE")) + "-";
        	
        		nbsmDogSonucStr = nbsmDogSonucStr + "MFraudVer:"
        			+ (iMap.getString("MUSTERI_FRAUD_DOG_IADE") == null ? "N" : iMap.getString("MUSTERI_FRAUD_DOG_IADE")) + "-";
        		nbsmDogSonucStr = nbsmDogSonucStr + "MWebVer:"
        			+ (iMap.getString("MUSTERI_WEB_DOG_IADE") == null ? "N" : iMap.getString("MUSTERI_WEB_DOG_IADE"));
        		
        	      	    
        		birTahsisDogrulamaTxM.setNbsmDogSonucStr(nbsmDogSonucStr);
        		birTahsisDegerTx.setNbsmDogSonucStrM(nbsmDogSonucStr);

        		session.saveOrUpdate(birTahsisDogrulamaTxM);
        		session.save(birTahsisDegerTx);
        		session.flush();
    	    } else {
    	    
//    	    if (iMap.getString("AKSIYON_KOD") != null && 
//        	        "R".equals(iMap.getString("AKSIYON_KOD"))){ // TY-12490 
    	    	BirTahsisDegerTx birTahsisDegerTx = (BirTahsisDegerTx) session.get(BirTahsisDegerTx.class, iMap.getBigDecimal("TRX_NO"));

        	    if (birTahsisDegerTx == null)
        		birTahsisDegerTx = new BirTahsisDegerTx();
        	    
        	    birTahsisDegerTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
        	    birTahsisDegerTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
        	    birTahsisDegerTx.setAciklama(iMap.getString("GORUS"));
        	    birTahsisDegerTx.setTahsisGorus(iMap.getString("IT_GORUS"));
        	    birTahsisDegerTx.setDurumKod(iMap.getString("DURUM"));
        	    birTahsisDegerTx.setOnayTutar(iMap.getBigDecimal("ONAY_TUTAR"));
        	    birTahsisDegerTx.setAksiyonKod(iMap.getString("AKSIYON_KOD"));
        	    birTahsisDegerTx.setIadeKod(iMap.getString("IADE_KOD"));
        	    birTahsisDegerTx.setAksiyonKararKod(iMap.getString("AKSIYON_KARAR_KOD"));
        	    birTahsisDegerTx.setAksiyonAltKararKod(iMap.getString("AKSIYON_ALT_KARAR_KOD"));
        	    birTahsisDegerTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO")); 
        	    if (iMap.getString("AKSIYON_KOD") != null && "R".equals(iMap.getString("AKSIYON_KOD"))){
        	    	birTahsisDegerTx.setIslemSonrasiDurumKodu("RED");
        	    }
        	    else if(iMap.getString("AKSIYON_KOD") != null && "U".equals(iMap.getString("AKSIYON_KOD"))){
        	    	birTahsisDegerTx.setIslemSonrasiDurumKodu("ONAY1");
        	    } 
        	    birTahsisDegerTx.setHasarAdedi(iMap.getBigDecimal("HASAR_ADEDI"));
        	    birTahsisDegerTx.setHasarTutari(iMap.getBigDecimal("HASAR_TUTARI"));
        	    birTahsisDegerTx.setAracKmBilgisi(iMap.getBigDecimal("ARAC_KM_BILGISI"));
        	    birTahsisDegerTx.setKmMuayeneTarihi(iMap.getDate("KM_MUAYENE_TARIHI"));
        		
        		session.save(birTahsisDegerTx);
        		session.flush();
    	    }
    	    	
    	    
            iMap.put("TRX_NAME" , "3190");
            return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw new GMRuntimeException(0 , e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3190_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
    	Connection conn = null;
    	CallableStatement stmt = null;
    	ResultSet rSet3 = null;
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            GMMap oMap = new GMMap();
            
            BirBasvuruistihbaratTx birBasvuruIstihbaratTx = (BirBasvuruistihbaratTx) session.get(BirBasvuruistihbaratTx.class , iMap.getBigDecimal("TRX_NO"));
            
            oMap.put("BASVURU_NO" , birBasvuruIstihbaratTx.getBasvuruNo());
            oMap.put("AKSIYON_KOD" , birBasvuruIstihbaratTx.getAksiyonKod());
            oMap.put("AKSIYON_KARAR_KOD" , birBasvuruIstihbaratTx.getAksiyonKararKod()); 
            oMap.put("IADE_KOD" , birBasvuruIstihbaratTx.getIadeKod());
            oMap.put("GORUS" , birBasvuruIstihbaratTx.getGorus());
            oMap.put("I_TAHSIS_GORUS" , birBasvuruIstihbaratTx.getTahsisGorus());
            oMap.put("YENI_ANNE_KIZLIK_SOYAD" , birBasvuruIstihbaratTx.getYeniAnneKizlikSoyad());
            /*TY-3188 ao 09.02.2015*/
            BirTahsisDogrulamaTx birTahsisDogrulamaTx = (BirTahsisDogrulamaTx) session.createCriteria(BirTahsisDogrulamaTx.class)
        			.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kimIcin", "M")).uniqueResult();

    		String nbsmDogSonucStr = birTahsisDogrulamaTx.getNbsmDogSonucStr();
    		if (nbsmDogSonucStr != null && !nbsmDogSonucStr.equals("")) {
    		    int size = nbsmDogSonucStr.split("-").length;
    		    for (int i = 0; i < size; i++) {
    			if (nbsmDogSonucStr.split("-")[i].contains("MAppVer")) {
    			    oMap.put("MUSTERI_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
    			} else if (nbsmDogSonucStr.split("-")[i].contains("MEmptVer")) {
    			    oMap.put("MUSTERI_ISYERI_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
    			}    			
    			else if (nbsmDogSonucStr.split("-")[i].contains("MFraudVer")) {
    			    oMap.put("MUSTERI_FRAUD_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
    			} else if (nbsmDogSonucStr.split("-")[i].contains("MWebVer")) {
    			    oMap.put("MUSTERI_WEB_DOG_IADE", nbsmDogSonucStr.split("-")[i].split(":")[1]);
    			}
    		    }
    		}

            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_trn3174.get_musteri_kontrol_takip_info(?)}");
            stmt.registerOutParameter(1 , -10);
            stmt.setBigDecimal(2 , iMap.getBigDecimal("TRX_NO"));
            stmt.execute();
            rSet3 = (ResultSet) stmt.getObject(1);
            String tableNameKont = "MUSTERI_KONTROL_LIST";
            int rowKont = 0;
            while (rSet3.next()){
                oMap.put(tableNameKont , rowKont , "SEC" , rSet3.getString("SEC"));
                oMap.put(tableNameKont , rowKont , "GORUS_KOD" , rSet3.getString("GORUS_KOD"));
                oMap.put(tableNameKont , rowKont , "GORUS" , rSet3.getString("GORUS"));
                
                rowKont++;
            }
            GMServerDatasource.close(rSet3);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
            return oMap;
        } catch (Exception e){
            throw new GMRuntimeException(0 , e);
        }
        finally{
        	GMServerDatasource.close(rSet3);
        	GMServerDatasource.close(stmt);
        	GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN3190_CHECK_KAYIT_GETIR")
    public static GMMap checkKayitGetir(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall(LovHelper.getLOVQuery("3190/LOV_BASVURU_NO"));
            rSet = stmt.executeQuery();
            boolean result = false;
            while (rSet.next()){
                if (rSet.getBigDecimal("BASVURU_NO").compareTo(iMap.getBigDecimal("BASVURU_NO")) == 0){
                    result = true;
                    break;
                }
            }
            oMap.put("RESULT" , result);
            return oMap;
        } catch (Exception e){
            throw new GMRuntimeException(0 , e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN3190_TEMP")
    public static GMMap saveTemp(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            
            BirBasvuruistihbaratTx birBasvuruIstihbaratTx =
                    (BirBasvuruistihbaratTx) session.createCriteria(BirBasvuruistihbaratTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            if (birBasvuruIstihbaratTx == null)
                birBasvuruIstihbaratTx = new BirBasvuruistihbaratTx();
            
            birBasvuruIstihbaratTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            birBasvuruIstihbaratTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
            birBasvuruIstihbaratTx.setAksiyonKod(iMap.getString("AKSIYON_KOD"));// karar
            birBasvuruIstihbaratTx.setAksiyonKararKod(iMap.getString("AKSIYON_KARAR_KOD"));
            birBasvuruIstihbaratTx.setIadeKod(iMap.getString("IADE_KOD"));
            birBasvuruIstihbaratTx.setGorus(iMap.getString("GORUS"));
            birBasvuruIstihbaratTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));
            birBasvuruIstihbaratTx.setTahsisGorus(iMap.getString("IT_GORUS"));
            birBasvuruIstihbaratTx.setYeniAnneKizlikSoyad(iMap.getString("YENI_ANNE_KIZLIK_SOYAD"));
            
            session.saveOrUpdate(birBasvuruIstihbaratTx);
            
            session.flush();
            
            String tcmbTableName = "TCMB_OZET_TABLE";
            String krediTableName = "KREDI_MODEL";
            String cekTableName = "CEK_MODEL";
            String mahkemeTableName = "MAHKEME_MODEL";
            String senetTableName = "SENET_MODEL";
            String temp;
            
            List<?> tcmbList = (List<?>) iMap.get(tcmbTableName);
            if (tcmbList != null){
                for (int i = 0; i < tcmbList.size(); i++){
                    String krediSonuc = "Y";
                    String cekSonuc = "Y";
                    String senetSonuc = "Y";
                    String mahkemeSonuc = "Y";
                    
                    List<?> krediList = (List<?>) iMap.get(tcmbTableName , i , krediTableName);
                    if (krediList != null){
                        for (int j = 0; j < krediList.size(); j++){
                            GMMap krediListMap = new GMMap((HashMap<?, ?>) krediList.get(j));
                            if (krediListMap.getString("IST_DURUM").equals("X")){
                                temp = krediListMap.getString("DURUM");
                            } else{
                                temp = krediListMap.getString("IST_DURUM");
                                
                                BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx =
                                        (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                                Restrictions.eq("id.kayitId" , krediListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
                                if (birBasvuruistTcmbKayitTx == null){
                                    birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO") , krediListMap.getBigDecimal("KAYIT_ID")));
                                }
                                
                                birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                                birBasvuruistTcmbKayitTx.setTahsisSonuc(krediListMap.getString("IST_DURUM"));
                                birBasvuruistTcmbKayitTx.setSorguTip("K");
                                birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(tcmbTableName , i , "ID"));
                                
                                session.saveOrUpdate(birBasvuruistTcmbKayitTx);
                            }
                            if (temp.equals("Y") && !(krediSonuc.equals("B") || krediSonuc.equals("K"))){
                                krediSonuc = "Y";
                            }
                            if (temp.equals("B") && !krediSonuc.equals("K")){
                                krediSonuc = "B";
                            }
                            if (temp.equals("K")){
                                krediSonuc = "K";
                            }
                            
                        }
                    }
                    List<?> cekList = (List<?>) iMap.get(tcmbTableName , i , cekTableName);
                    if (cekList != null){
                        for (int j = 0; j < cekList.size(); j++){
                            GMMap cekListMap = new GMMap((HashMap<?, ?>) cekList.get(j));
                            if (cekListMap.getString("IST_DURUM").equals("X")){
                                temp = cekListMap.getString("DURUM");
                            } else{
                                temp = cekListMap.getString("IST_DURUM");
                                
                                BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx =
                                        (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                                Restrictions.eq("id.kayitId" , cekListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
                                if (birBasvuruistTcmbKayitTx == null){
                                    birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO") , cekListMap.getBigDecimal("KAYIT_ID")));
                                }
                                
                                birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                                birBasvuruistTcmbKayitTx.setTahsisSonuc(cekListMap.getString("IST_DURUM"));
                                birBasvuruistTcmbKayitTx.setSorguTip("C");
                                birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(tcmbTableName , i , "ID"));
                                
                                session.saveOrUpdate(birBasvuruistTcmbKayitTx);
                            }
                            if (temp.equals("Y") && !(cekSonuc.equals("B") || cekSonuc.equals("K"))){
                                cekSonuc = "Y";
                            }
                            if (temp.equals("B") && !cekSonuc.equals("K")){
                                cekSonuc = "B";
                            }
                            if (temp.equals("K")){
                                cekSonuc = "K";
                            }
                            
                        }
                    }
                    List<?> mahkemeList = (List<?>) iMap.get(tcmbTableName , i , mahkemeTableName);
                    if (mahkemeList != null){
                        for (int j = 0; j < mahkemeList.size(); j++){
                            GMMap mahkemeListMap = new GMMap((HashMap<?, ?>) mahkemeList.get(j));
                            if (mahkemeListMap.getString("IST_DURUM").equals("X")){
                                temp = mahkemeListMap.getString("DURUM");
                            } else{
                                temp = mahkemeListMap.getString("IST_DURUM");
                                
                                BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx =
                                        (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                                Restrictions.eq("id.kayitId" , mahkemeListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
                                if (birBasvuruistTcmbKayitTx == null){
                                    birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO") , mahkemeListMap.getBigDecimal("KAYIT_ID")));
                                }
                                
                                birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                                birBasvuruistTcmbKayitTx.setTahsisSonuc(mahkemeListMap.getString("IST_DURUM"));
                                birBasvuruistTcmbKayitTx.setSorguTip("M");
                                birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(tcmbTableName , i , "ID"));
                                
                                session.saveOrUpdate(birBasvuruistTcmbKayitTx);
                            }
                            if (temp.equals("Y") && !(mahkemeSonuc.equals("B") || mahkemeSonuc.equals("K"))){
                                mahkemeSonuc = "Y";
                            }
                            if (temp.equals("B") && !mahkemeSonuc.equals("K")){
                                mahkemeSonuc = "B";
                            }
                            if (temp.equals("K")){
                                mahkemeSonuc = "K";
                            }
                            
                        }
                    }
                    List<?> senetList = (List<?>) iMap.get(tcmbTableName , i , senetTableName);
                    if (senetList != null){
                        for (int j = 0; j < senetList.size(); j++){
                            GMMap senetListMap = new GMMap((HashMap<?, ?>) senetList.get(j));
                            if (senetListMap.getString("IST_DURUM").equals("X")){
                                temp = senetListMap.getString("DURUM");
                            } else{
                                temp = senetListMap.getString("IST_DURUM");
                                
                                BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx =
                                        (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                                Restrictions.eq("id.kayitId" , senetListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
                                if (birBasvuruistTcmbKayitTx == null){
                                    birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO") , senetListMap.getBigDecimal("KAYIT_ID")));
                                }
                                
                                birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                                birBasvuruistTcmbKayitTx.setTahsisSonuc(senetListMap.getString("IST_DURUM"));
                                birBasvuruistTcmbKayitTx.setSorguTip("S");
                                birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(tcmbTableName , i , "ID"));
                                
                                session.saveOrUpdate(birBasvuruistTcmbKayitTx);
                            }
                            if (temp.equals("Y") && !(senetSonuc.equals("B") || senetSonuc.equals("K"))){
                                senetSonuc = "Y";
                            }
                            if (temp.equals("B") && !senetSonuc.equals("K")){
                                senetSonuc = "B";
                            }
                            if (temp.equals("K")){
                                senetSonuc = "K";
                            }
                            
                        }
                    }
                    
                    if (!(krediSonuc.equals(iMap.getString(tcmbTableName , i , "KREDI_SONUC")) && cekSonuc.equals(iMap.getString(tcmbTableName , i , "CEK_SONUC"))
                            && mahkemeSonuc.equals(iMap.getString(tcmbTableName , i , "MAHKEME_SONUC")) && senetSonuc.equals(iMap.getString(tcmbTableName , i , "SENET_SONUC")))){
                        
                        BirBasvuruistTcmbTx birBasvuruistTcmbTx =
                                (BirBasvuruistTcmbTx) session.createCriteria(BirBasvuruistTcmbTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                        Restrictions.eq("id.sorguId" , iMap.getBigDecimal(tcmbTableName , i , "ID"))).uniqueResult();
                        if (birBasvuruistTcmbTx == null){
                            birBasvuruistTcmbTx = new BirBasvuruistTcmbTx();
                            BirBasvuruistTcmbTxId birBasvuruistTcmbTxId = new BirBasvuruistTcmbTxId();
                            birBasvuruistTcmbTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                            birBasvuruistTcmbTxId.setSorguId(iMap.getBigDecimal(tcmbTableName , i , "ID"));
                            birBasvuruistTcmbTx.setId(birBasvuruistTcmbTxId);
                            
                        }
                        birBasvuruistTcmbTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                        birBasvuruistTcmbTx.setIslemKod("3190");
                        birBasvuruistTcmbTx.setKrediSonuc(krediSonuc);
                        birBasvuruistTcmbTx.setCekSonuc(cekSonuc);
                        birBasvuruistTcmbTx.setMahkemeSonuc(mahkemeSonuc);
                        birBasvuruistTcmbTx.setSenetSonuc(senetSonuc);
                        
                        session.saveOrUpdate(birBasvuruistTcmbTx);
                        
                    }
                }
            }
            
            session.flush();
            
            String fraudTableName = "FRAUD_OZET_TABLE";
            String caprazTableName = "CAPRAZ_MODEL";
            String karaTableName = "KARA_MODEL";
            
            List<?> fraudList = (List<?>) iMap.get(fraudTableName);
            if (fraudList != null){
                for (int i = 0; i < fraudList.size(); i++){
                    
                    String karaSonuc = "Y";
                    String caprazSonuc = "Y";
                    
                    List<?> caprazList = (List<?>) iMap.get(fraudTableName , i , caprazTableName);
                    if (caprazList != null){
                        for (int j = 0; j < caprazList.size(); j++){
                            GMMap caprazListMap = new GMMap((HashMap<?, ?>) caprazList.get(j));
                            if (caprazListMap.getString("IST_DURUM").equals("X")){
                                temp = caprazListMap.getString("SONUC");
                            } else{
                                temp = caprazListMap.getString("IST_DURUM");
                                
                                BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx =
                                        (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                                Restrictions.eq("id.kayitId" , caprazListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
                                if (birBasvuruistTcmbKayitTx == null){
                                    birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO") , caprazListMap.getBigDecimal("KAYIT_ID")));
                                }
                                
                                birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                                birBasvuruistTcmbKayitTx.setTahsisSonuc(caprazListMap.getString("IST_DURUM"));
                                birBasvuruistTcmbKayitTx.setSorguTip("E");
                                birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(fraudTableName , i , "ID"));
                                
                                session.saveOrUpdate(birBasvuruistTcmbKayitTx);
                            }
                            if (temp.equals("Y") && !(caprazSonuc.equals("B") || caprazSonuc.equals("K"))){
                                caprazSonuc = "Y";
                            }
                            if (temp.equals("B") && !caprazSonuc.equals("K")){
                                caprazSonuc = "B";
                            }
                            if (temp.equals("K")){
                                caprazSonuc = "K";
                            }
                            
                        }
                    }
                    List<?> karaList = (List<?>) iMap.get(fraudTableName , i , karaTableName);
                    if (karaList != null){
                        
                        for (int j = 0; j < karaList.size(); j++){
                            GMMap karaListMap = new GMMap((HashMap<?, ?>) karaList.get(j));
                            if (karaListMap.getString("IST_DURUM").equals("X")){
                                temp = karaListMap.getString("DURUM");
                            } else{
                                temp = karaListMap.getString("IST_DURUM");
                                
                                BirBasvuruistTcmbKayitTx birBasvuruistTcmbKayitTx =
                                        (BirBasvuruistTcmbKayitTx) session.createCriteria(BirBasvuruistTcmbKayitTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                                Restrictions.eq("id.kayitId" , karaListMap.getBigDecimal("KAYIT_ID"))).uniqueResult();
                                if (birBasvuruistTcmbKayitTx == null){
                                    birBasvuruistTcmbKayitTx = new BirBasvuruistTcmbKayitTx(new BirBasvuruistTcmbKayitTxId(iMap.getBigDecimal("TRX_NO") , karaListMap.getBigDecimal("KAYIT_ID")));
                                }
                                
                                birBasvuruistTcmbKayitTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                                birBasvuruistTcmbKayitTx.setTahsisSonuc(karaListMap.getString("IST_DURUM"));
                                birBasvuruistTcmbKayitTx.setSorguTip("B");
                                birBasvuruistTcmbKayitTx.setIsttcmbsorguId(iMap.getBigDecimal(fraudTableName , i , "ID"));
                                
                                session.saveOrUpdate(birBasvuruistTcmbKayitTx);
                            }
                            
                            if (temp.equals("Y") && !(karaSonuc.equals("B") || karaSonuc.equals("K"))){
                                karaSonuc = "Y";
                            }
                            if (temp.equals("B") && !karaSonuc.equals("K")){
                                karaSonuc = "B";
                            }
                            if (temp.equals("K")){
                                karaSonuc = "K";
                            }
                            
                        }
                    }
                    
                    if (!(karaSonuc.equals(iMap.getString(fraudTableName , i , "KARA_LISTE_SONUC")) && caprazSonuc.equals(iMap.getString(fraudTableName , i , "ESKI_BASVURU_SONUC")))){
                        
                        BirBasvuruistTcmbTx birBasvuruistTcmbTx =
                                (BirBasvuruistTcmbTx) session.createCriteria(BirBasvuruistTcmbTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                        Restrictions.eq("id.sorguId" , iMap.getBigDecimal(fraudTableName , i , "ID"))).uniqueResult();
                        if (birBasvuruistTcmbTx == null){
                            birBasvuruistTcmbTx = new BirBasvuruistTcmbTx();
                            BirBasvuruistTcmbTxId birBasvuruistTcmbTxId = new BirBasvuruistTcmbTxId();
                            birBasvuruistTcmbTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                            birBasvuruistTcmbTxId.setSorguId(iMap.getBigDecimal(fraudTableName , i , "ID"));
                            birBasvuruistTcmbTx.setId(birBasvuruistTcmbTxId);
                            
                        }
                        
                        birBasvuruistTcmbTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                        birBasvuruistTcmbTx.setIslemKod("3190");
                        birBasvuruistTcmbTx.setCaprazSorguSonuc(caprazSonuc);
                        birBasvuruistTcmbTx.setKaraListeSonuc(karaSonuc);
                        
                        session.saveOrUpdate(birBasvuruistTcmbTx);
                        
                    }
                }
            }
            
            session.flush();
            
            List<?> musteriKontrolList = (List<?>) iMap.get("MUSTERI_KONTROL_LIST");
            String tableName = "MUSTERI_KONTROL_LIST";
            for (int i = 0; i < musteriKontrolList.size(); i++){
                BirTahsisDegerGorusTx birTahsisDegerGorusTx =
                        (BirTahsisDegerGorusTx) session.createCriteria(BirTahsisDegerGorusTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                Restrictions.eq("id.basvuruNo" , iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.gorusKod" , iMap.getString(tableName , i , "GORUS_KOD"))).uniqueResult();
                if (birTahsisDegerGorusTx == null){
                    birTahsisDegerGorusTx = new BirTahsisDegerGorusTx();
                    BirTahsisDegerGorusTxId id = new BirTahsisDegerGorusTxId();
                    id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                    id.setGorusKod(iMap.getString(tableName , i , "GORUS_KOD"));
                    birTahsisDegerGorusTx.setId(id);
                    if (iMap.getBoolean(tableName , i , "SEC")){
                        birTahsisDegerGorusTx.setEH("E");
                    } else{
                        birTahsisDegerGorusTx.setEH("H");
                    }
                }
                session.saveOrUpdate(birTahsisDegerGorusTx);
            }
            session.flush();
            
            List<?> lastTeminatList =
                    session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                            Restrictions.eq("id.basvuruNo" , iMap.getBigDecimal("BASVURU_NO"))).list();
            for (Iterator<?> iterator = lastTeminatList.iterator(); iterator.hasNext();){
                BirBasvuruTeminatTx birBasvuruTeminatTx = (BirBasvuruTeminatTx) iterator.next();
                session.delete(birBasvuruTeminatTx);
            }
            session.flush();
            
            List<?> teminatList = (List<?>) iMap.get("TEMINAT");
            tableName = "TEMINAT";
            
            for (int i = 0; i < teminatList.size(); i++){
                BirBasvuruTeminatTx birBasvuruTeminatTx =
                        (BirBasvuruTeminatTx) session.createCriteria(BirBasvuruTeminatTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                Restrictions.eq("id.basvuruNo" , iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.teminatKod" , iMap.getString(tableName , i , "TEMINAT_ADI")))
                                .uniqueResult();
                if (birBasvuruTeminatTx == null){
                    birBasvuruTeminatTx = new BirBasvuruTeminatTx();
                    BirBasvuruTeminatTxId birBasvuruTeminatTxId = new BirBasvuruTeminatTxId();
                    
                    birBasvuruTeminatTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    birBasvuruTeminatTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                    birBasvuruTeminatTxId.setTeminatKod(iMap.getString(tableName , i , "TEMINAT_ADI"));
                    birBasvuruTeminatTx.setId(birBasvuruTeminatTxId);
                }
                birBasvuruTeminatTx.setTeminatAdedi(iMap.getBigDecimal(tableName , i , "TEMINAT_ADEDI"));
                
                session.save(birBasvuruTeminatTx);
            }
            session.flush();
            
            List<?> lastBelgeList =
                session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO")))
                    .list();
            for (Iterator<?> iterator = lastBelgeList.iterator(); iterator.hasNext();) {
                BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) iterator.next();
                session.delete(birBasvuruBelgeTx);
            }
            session.flush();
            
            List<?> belgeList = (List<?>) iMap.get("BELGE");
            tableName = "BELGE";
            for (int i = 0; i < belgeList.size(); i++){
                BirBasvuruBelgeTx birBasvuruBelgeTx =
                        (BirBasvuruBelgeTx) session.createCriteria(BirBasvuruBelgeTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).add(
                                Restrictions.eq("id.basvuruNo" , iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.eq("id.kimden" , iMap.getString(tableName , i , "KIMDEN_KOD"))).add(
                                Restrictions.eq("id.dokumanKod" , iMap.getString(tableName , i , "BELGE_KOD"))).uniqueResult();
                if (birBasvuruBelgeTx == null){
                    birBasvuruBelgeTx = new BirBasvuruBelgeTx();
                    BirBasvuruBelgeTxId birBasvuruBelgeTxId = new BirBasvuruBelgeTxId();
                    
                    birBasvuruBelgeTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    birBasvuruBelgeTxId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
                    birBasvuruBelgeTxId.setDokumanKod(iMap.getString(tableName , i , "BELGE_KOD"));
                    birBasvuruBelgeTxId.setKimden(iMap.getString(tableName , i , "KIMDEN_KOD"));
                    
                    birBasvuruBelgeTx.setId(birBasvuruBelgeTxId);
                    
                    birBasvuruBelgeTx.setAlindi(iMap.getString(tableName, i, "ALINDI"));
                    birBasvuruBelgeTx.setBelgeKontrol(iMap.getString(tableName, i, "BELGE_KONTROL"));
                    birBasvuruBelgeTx.setOrjinalEvrakMi(iMap.getString(tableName, i, "ORJINAL_EVRAK_MI"));
                    birBasvuruBelgeTx.setBelgeGelisTarihi(iMap.getCalendar(tableName, i, "BELGE_GELIS_TARIHI").getTime());
                    birBasvuruBelgeTx.setIslemTarihi(iMap.getCalendar(tableName, i, "ISLEM_TARIHI").getTime());
                    birBasvuruBelgeTx.setBelgeHata(iMap.getString(tableName, i, "BELGE_HATA"));
                    birBasvuruBelgeTx.setBarkodNumarasi(iMap.getString(tableName, i, "BARKOD_NUMARASI"));
                    birBasvuruBelgeTx.setOnayliMi(iMap.getString(tableName, i, "ONAYLI_MI"));
                    birBasvuruBelgeTx.setUyumsuzAciklama(iMap.getString(tableName, i, "UYUMSUZ_ACIKLAMA"));
                    birBasvuruBelgeTx.setBelgeYeri(iMap.getString(tableName, i, "BELGE_YERI"));
                    birBasvuruBelgeTx.setKontrolNedeni(iMap.getString(tableName, i, "KONTROL_NEDENI"));
                    birBasvuruBelgeTx.setIslemYapanKullanici(iMap.getString(tableName, i, "ISLEM_YAPAN_KULLANICI"));
                    
                    String belgeAlinmaAdim = iMap.getString(tableName , i , "BELGE_ALINMA_ADIMI") != null &&
												!iMap.getString(tableName , i , "BELGE_ALINMA_ADIMI").trim().isEmpty() 
													? iMap.getString(tableName , i , "BELGE_ALINMA_ADIMI") : "S" ;
					birBasvuruBelgeTx.setBelgeAlinmaAdim(belgeAlinmaAdim);
                }
                session.save(birBasvuruBelgeTx);
            }
            session.flush();
         // TY-3188 ao 09.02.2015    	    
    	    if (iMap.getString("AKSIYON_KOD") != null && 
    	        "I".equals(iMap.getString("AKSIYON_KOD")) && 
    	        iMap.getString("IADE_KOD") != null && 
    	        "DOGRULAMA".equals(iMap.getString("IADE_KOD"))) {
    	    	
    	    	BirTahsisDegerTx birTahsisDegerTx = (BirTahsisDegerTx) session.get(BirTahsisDegerTx.class, iMap.getBigDecimal("TRX_NO"));

        	    if (birTahsisDegerTx == null)
        		birTahsisDegerTx = new BirTahsisDegerTx();
        	    
        	    birTahsisDegerTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
        	    birTahsisDegerTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
        	    birTahsisDegerTx.setAciklama(iMap.getString("GORUS"));
        	    birTahsisDegerTx.setTahsisGorus(iMap.getString("IT_GORUS"));
        	    birTahsisDegerTx.setDurumKod(iMap.getString("DURUM"));
        	    birTahsisDegerTx.setOnayTutar(iMap.getBigDecimal("ONAY_TUTAR"));
        	    birTahsisDegerTx.setAksiyonKod(iMap.getString("AKSIYON_KOD"));
        	    birTahsisDegerTx.setIadeKod(iMap.getString("IADE_KOD"));
        	    birTahsisDegerTx.setAksiyonKararKod(iMap.getString("AKSIYON_KARAR_KOD"));
        	    birTahsisDegerTx.setAksiyonAltKararKod(iMap.getString("AKSIYON_ALT_KARAR_KOD"));
        	    birTahsisDegerTx.setSonTxNo(iMap.getBigDecimal("SON_TX_NO"));

        	    if (iMap.getString("AKSIYON_KOD") != null && 
        	        !("I".equals(iMap.getString("AKSIYON_KOD")) && 
        	        iMap.getString("IADE_KOD") == null))
        		birTahsisDegerTx.setIslemSonrasiDurumKodu("ISTIHBARAT");
        	    
        	    BirTahsisDogrulamaTx birTahsisDogrulamaTxM = (BirTahsisDogrulamaTx) session.createCriteria(BirTahsisDogrulamaTx.class)
        				.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kimIcin", "M")).uniqueResult();

    			if (birTahsisDogrulamaTxM == null) {
    			    birTahsisDogrulamaTxM = new BirTahsisDogrulamaTx();
    			    BirTahsisDogrulamaTxId birTahsisDogrulamaTxId = new BirTahsisDogrulamaTxId();
    			    birTahsisDogrulamaTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
    			    birTahsisDogrulamaTxId.setKimIcin("M");

    			    birTahsisDogrulamaTxM.setId(birTahsisDogrulamaTxId);
    			}

    			birTahsisDogrulamaTxM.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
        			
        	    String nbsmDogSonucStr = "";
        		nbsmDogSonucStr = nbsmDogSonucStr + "MAppVer:"
        			+ (iMap.getString("MUSTERI_DOG_IADE") == null ? "N" : iMap.getString("MUSTERI_DOG_IADE")) + "-";
        		nbsmDogSonucStr = nbsmDogSonucStr + "MEmptVer:"
        			+ (iMap.getString("MUSTERI_ISYERI_DOG_IADE") == null ? "Not Required" : iMap.getString("MUSTERI_ISYERI_DOG_IADE")) + "-";
        	
        		nbsmDogSonucStr = nbsmDogSonucStr + "MFraudVer:"
        			+ (iMap.getString("MUSTERI_FRAUD_DOG_IADE") == null ? "N" : iMap.getString("MUSTERI_FRAUD_DOG_IADE")) + "-";
        		nbsmDogSonucStr = nbsmDogSonucStr + "MWebVer:"
        			+ (iMap.getString("MUSTERI_WEB_DOG_IADE") == null ? "N" : iMap.getString("MUSTERI_WEB_DOG_IADE"));
        		
        	      	    
        		birTahsisDogrulamaTxM.setNbsmDogSonucStr(nbsmDogSonucStr);
        		birTahsisDegerTx.setNbsmDogSonucStrM(nbsmDogSonucStr);

        		session.saveOrUpdate(birTahsisDogrulamaTxM);
        		session.save(birTahsisDegerTx);
        		session.flush();
    	    }
            iMap.put("TRX_NAME" , "3190");
            return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION_TEMP" , iMap);
        } catch (Exception e){
            throw new GMRuntimeException(0 , e);
        }
    }
    
    @GraymoundService("BNSPR_TRN3190_GET_SAKLA_TX_NO")
    public static GMMap getoncekiSaklaTxNo(GMMap iMap) {
        try{
            GMMap oMap = new GMMap();
            String query = "select max(tx_no) tx_no from bir_basvuru_istihbarat_tx where basvuru_no = ";
            oMap.put("TRX_NO" , DALUtil.getResult(query + iMap.getBigDecimal("BASVURU_NO") + ""));
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
}
