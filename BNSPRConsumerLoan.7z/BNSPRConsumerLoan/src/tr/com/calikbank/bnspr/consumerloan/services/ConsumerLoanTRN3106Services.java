package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.List;

import javax.swing.tree.DefaultMutableTreeNode;

import org.apache.commons.lang.StringUtils;
import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirAzamiFaizOranPr;
import tr.com.aktifbank.bnspr.dao.BirRiskFiyatlamaTanim;
import tr.com.aktifbank.bnspr.dao.BirRiskFiyatlamaTanimTx;
import tr.com.aktifbank.bnspr.dao.BirRiskFiyatlamaTanimTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirKampKnl;
import tr.com.calikbank.bnspr.dao.BirKampanya;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.uiml.bean.tree.checkbox.TristateTreeNode;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3106Services {
	
	@GraymoundService("BNSPR_TRN3106_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		int row = 0;
		String tableName = "RISK_FIYAT_TABLO";
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		BigDecimal kanalKodu = null;
		BigDecimal tempKanalKodu = null;
		int i = 0;
		
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<BirRiskFiyatlamaTanim> liste = session.createCriteria(BirRiskFiyatlamaTanim.class).list();

			for (BirRiskFiyatlamaTanim birRiskFiyatlamaTanim : liste) {
				oMap.put(tableName, row, "KAMP_KOD", birRiskFiyatlamaTanim.getId().getKampKod());
				oMap.put(tableName, row, "KAMP_ADI", LovHelper.diLov(birRiskFiyatlamaTanim.getId().getKampKod(), "3112/LOV_KAMPANYA", "ACIKLAMA"));
				oMap.put(tableName, row, "SEGMENT", birRiskFiyatlamaTanim.getId().getSegment());
				if(birRiskFiyatlamaTanim.getBps() != null){
					oMap.put(tableName, row, "BPS_ISARET", birRiskFiyatlamaTanim.getBps().compareTo(BigDecimal.ZERO) < 0 ? "-" : "+");
					oMap.put(tableName, row, "BPS", Math.abs(birRiskFiyatlamaTanim.getBps().intValue()));
				}
				
				if(birRiskFiyatlamaTanim.getEkPaketliBps() != null){
					oMap.put(tableName, row, "EK_PAKETLI_BPS_ISARET", birRiskFiyatlamaTanim.getEkPaketliBps().compareTo(BigDecimal.ZERO) < 0 ? "-" : "+");
					oMap.put(tableName, row, "EK_PAKETLI_BPS", Math.abs(birRiskFiyatlamaTanim.getEkPaketliBps().intValue()));
				}
				
				row++;
			}	
			
			String listName = "ISARET_DATA";
			GuimlUtil.wrapMyCombo(oMap, listName, "-", "-");
			GuimlUtil.wrapMyCombo(oMap, listName, "+", "+");

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("select kan.kanal_kod, a.aciklama, k.kod, k.aciklama kamp_adi,t.kamp_kod from bnspr.bir_kampanya k, bnspr.bir_kamp_knl kan, bnspr.gnl_kanal_grup_kod_pr a, bnspr.bir_risk_fiyatlama_tanim t where k.kod = kan.kamp_kod and kan.kanal_kod = a.kod and t.kamp_kod(+) = k.kod  group by kan.kanal_kod, a.aciklama, k.kod, k.aciklama, t.kamp_kod order by kan.kanal_kod, k.kod");

			rSet = stmt.executeQuery();
			
			GMMap kanalMap = new GMMap();
			GMMap kampMap = new GMMap();
			TristateTreeNode root = new TristateTreeNode(new GMMap());
			TristateTreeNode kampNode = null;
			while (rSet.next()) {
				kanalKodu = rSet.getBigDecimal(1);
				if(tempKanalKodu == null || tempKanalKodu.compareTo(kanalKodu) != 0){
					kanalMap = new GMMap();
					kanalMap.put("NAME", rSet.getString(2));
					tempKanalKodu = kanalKodu;
					
					kampNode = new TristateTreeNode(kanalMap);
					root.add(kampNode);
					
					i++;
				}
				kampMap = new GMMap();
				kampMap.put("CODE", rSet.getBigDecimal(3));
				kampMap.put("NAME", rSet.getString(3) + " - " + rSet.getString(4));
				kampMap.put("KAMP_ADI", rSet.getString(4));
				if(rSet.getString(5) != null){
					kampMap.put("SELECTED", true);
				}
				TristateTreeNode node = new TristateTreeNode(kampMap);
				kampNode.add(node);
				
			}
			oMap.put("KAMPANYA_LIST", root);
			
			
		}catch(Exception e){
			ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
		

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN3106_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String tableName = "RISK_FIYAT_TABLO";
		BirRiskFiyatlamaTanimTxId txId = null;
		BirRiskFiyatlamaTanimTx tx = null;
		GMMap fMap = new GMMap();
		BirAzamiFaizOranPr azamiFaizOrani = null;
		BirKampanya birKampanya = null;
		BigDecimal bazFaiz = null;
				
		int row =0;
		try{
			for (row = 0; row < iMap.getSize(tableName); row++) {
				if(iMap.getBigDecimal(tableName, row, "KAMP_KOD") == null){
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Kampanya Kodu");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				if(iMap.get(tableName, row, "SEGMENT") == null){
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Segment");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
				/** azami faiz oran kontrol **/ 
				birKampanya = (BirKampanya) session.get(BirKampanya.class, iMap.getBigDecimal(tableName, row, "KAMP_KOD"));
				fMap.put("TICARI_KREDI_EH", "E".equals(birKampanya.getTicariKrediEh()) ? true : false);
				fMap.put("KAMPANYA_KOD",  iMap.getBigDecimal(tableName, row, "KAMP_KOD"));
				fMap.put("KREDI_TURU", birKampanya.getKrdTurKod());
				azamiFaizOrani = ConsumerLoanTRN3112Services.findBirAzamiFaiz(fMap);
				
				List<?> kampanyaDetayList = session.createCriteria(BirKampKnl.class)
				.add(Restrictions.eq("kampKod", iMap.getBigDecimal(tableName, row, "KAMP_KOD"))).add(Restrictions.eq("drm", "G")).list(); 
				
				int i = 0;
				for (Iterator<?> iterator = kampanyaDetayList.iterator(); iterator.hasNext();i++) {
					BirKampKnl birKampKnl = (BirKampKnl) iterator.next();
					
					if("+".equals(iMap.getString(tableName, row, "BPS_ISARET"))){
						bazFaiz = birKampKnl.getBazOran().add(iMap.getBigDecimal(tableName, row, "BPS").divide(new BigDecimal(100)));
					}else{
						bazFaiz = birKampKnl.getBazOran().subtract(iMap.getBigDecimal(tableName, row, "BPS").divide(new BigDecimal(100)));
					}
					
					if("+".equals(iMap.getString(tableName, row, "EK_PAKETLI_BPS_ISARET"))){
						bazFaiz = bazFaiz.add(iMap.getBigDecimal(tableName, row, "EK_PAKETLI_BPS").divide(new BigDecimal(100)));
					}
					
					if(ConsumerLoanTRN3112Services.azamiFaizAsildi(bazFaiz, birKampKnl.getMinVade(), azamiFaizOrani) || 
							ConsumerLoanTRN3112Services.azamiFaizAsildi(bazFaiz, birKampKnl.getMaxVade(), azamiFaizOrani)) {
						throw new GMRuntimeException(0, iMap.getString(tableName, row, "KAMP_KOD") + " nolu kampanyada azami faiz oran�n�n �zerinde tan�mlama yapamazs�n�z!");
					}
				}
				
				txId = new BirRiskFiyatlamaTanimTxId();
				txId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				txId.setKampKod(iMap.getBigDecimal(tableName, row, "KAMP_KOD"));
				txId.setSegment(iMap.getString(tableName, row, "SEGMENT"));
				
				tx = new BirRiskFiyatlamaTanimTx(txId);
				if("-".equals(iMap.getString(tableName, row, "BPS_ISARET"))){
					tx.setBps(iMap.getBigDecimal(tableName, row, "BPS").negate());
				}else{
					tx.setBps(iMap.getBigDecimal(tableName, row, "BPS"));
				}
				if("-".equals(iMap.getString(tableName, row, "EK_PAKETLI_BPS_ISARET"))){
					tx.setEkPaketliBps(iMap.getBigDecimal(tableName, row, "EK_PAKETLI_BPS").negate());
				}else{
					tx.setEkPaketliBps(iMap.getBigDecimal(tableName, row, "EK_PAKETLI_BPS"));
				}
				
				session.saveOrUpdate(tx);
			}
			session.flush();
			
			iMap.put("TRX_NAME", "3106");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
		}catch(NonUniqueObjectException e){
			throw new GMRuntimeException(0, iMap.getString(tableName, row, "KAMP_KOD") + " nolu kampanya " + iMap.getString(tableName, row, "SEGMENT") + " segment i�in birden �ok tan�m yap�lm��t�r.");
		}catch(Exception e){
			ExceptionHandler.convertException(e);
		}
		
		return oMap;

	}
	
	@GraymoundService("BNSPR_TRN3106_TOPLU_EKLE")
	public static GMMap topluEkle(GMMap iMap) {
		GMMap oMap = new GMMap();
		String tableName = "RISK_FIYAT_TABLO";
		int row = 0;
		
		try{
			row = iMap.getSize(tableName);
			
			DefaultMutableTreeNode root = (DefaultMutableTreeNode) iMap.get("KAMPANYA_LIST");
			
			Enumeration<?> enumeration = root.breadthFirstEnumeration();
			while (enumeration.hasMoreElements()) {
				DefaultMutableTreeNode node = (DefaultMutableTreeNode) enumeration.nextElement();
				if (!root.equals(node)) {
					GMMap map = (GMMap) node.getUserObject();
					if(map.getBoolean("SELECTED") && StringUtils.isNotEmpty(map.getString("CODE")) && kayitEkle(iMap, map)){
						iMap.put(tableName, row, "KAMP_KOD", map.getString("CODE"));
						iMap.put(tableName, row, "KAMP_ADI", map.getString("KAMP_ADI"));
						iMap.put(tableName, row, "SEGMENT", iMap.getString("SEGMENT"));
						if(StringUtils.isNotEmpty(iMap.getString("BPS"))){
							iMap.put(tableName, row, "BPS_ISARET", iMap.getString("BPS_ISARET"));
							iMap.put(tableName, row, "BPS", iMap.getString("BPS"));
						}
						if(StringUtils.isNotEmpty(iMap.getString("EK_PAKETLI_BPS"))){
							iMap.put(tableName, row, "EK_PAKETLI_BPS_ISARET", iMap.getString("EK_PAKETLI_BPS_ISARET"));
							iMap.put(tableName, row, "EK_PAKETLI_BPS", iMap.getString("EK_PAKETLI_BPS"));
						}
						row++;
					}
				}
			}
			
			oMap.put(tableName, iMap.get(tableName));
		}
		catch(Exception e){
			ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	private static boolean kayitEkle(GMMap iMap, GMMap map) {
		for (int i = 0; i < iMap.getSize("RISK_FIYAT_TABLO"); i++) {
			if(iMap.getString("RISK_FIYAT_TABLO", i, "SEGMENT").equals(iMap.getString("SEGMENT")) && iMap.getString("RISK_FIYAT_TABLO", i, "KAMP_KOD").equals(map.getString("CODE"))){
				return false;
			}
		}
		return true;
	}
}
