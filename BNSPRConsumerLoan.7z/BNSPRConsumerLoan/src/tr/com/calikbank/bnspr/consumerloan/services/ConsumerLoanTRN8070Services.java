package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.HashMap;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBorcTransferiAramaTx;
import tr.com.aktifbank.bnspr.pdfViewerPanelBean.ByteArrayType;
import tr.com.calikbank.bnspr.consumerloan.utils.Enums.CreditDocMailTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN8070Services {
	final static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd HHmmss");
	
	@GraymoundService("BNSPR_TRN8070_GET_BASVURU_LIST")
	public static GMMap getBasvuruBilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			if (iMap.getDate("BASVURU_TARIHI_BAS") != null && iMap.getDate("BASVURU_TARIHI_BIT") != null) {
				if (iMap.getDate("BASVURU_TARIHI_BAS").after(iMap.getDate("BASVURU_TARIHI_BIT"))) {
					iMap.put("HATA_NO", new BigDecimal(915));
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN8070.get_basvuru_list(?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;

			stmt.registerOutParameter(i++, -10);

			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TCKN"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));

			if (iMap.getDate("BASVURU_TARIHI_BAS") != null)
				stmt.setDate(i++, new Date(iMap.getDate("BASVURU_TARIHI_BAS").getTime()));
			else
				stmt.setDate(i++, null);
			if (iMap.getDate("BASVURU_TARIHI_BIT") != null)
				stmt.setDate(i++, new Date(iMap.getDate("BASVURU_TARIHI_BIT").getTime()));
			else
				stmt.setDate(i++, null);
			
			if (iMap.getDate("ARAMA_TARIHI") != null)
				stmt.setDate(i++, new Date(iMap.getDate("ARAMA_TARIHI").getTime()));
			else
				stmt.setDate(i++, null);
			
			stmt.setString(i++, iMap.getString("ARAMA_SONUCU"));
			stmt.setString(i++, iMap.getString("ARAMA_SONUCU_ACK"));
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			stmt.setString(i++, GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("RANDEVU_GELMEMIS_DAHIL")));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResultsPutStr(rSet, "RESULTS"));
			GMServerDatasource.close(rSet);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN8070_GET_TARIHCE")
	public static GMMap getBasvuruTarihce(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN8070.get_arama_tarihce(?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);

			return DALUtil.rSetResultsPutStr(rSet, "RESULTS");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN8070_BASVURU_TARIH_KONTROL")
	public static GMMap basvuruTarihKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN8070.Arama_Tarih_Kontrol(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));
			stmt.execute();

			GMMap oMap = new GMMap();
			oMap.put("TARIH_GECERLI", stmt.getString(1));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN8070_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			BirBorcTransferiAramaTx birBorcTransferiAramaTx = (BirBorcTransferiAramaTx) session.createCriteria(BirBorcTransferiAramaTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (birBorcTransferiAramaTx == null) {
				birBorcTransferiAramaTx = new BirBorcTransferiAramaTx();
				birBorcTransferiAramaTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}
			birBorcTransferiAramaTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birBorcTransferiAramaTx.setAramaAdeti(iMap.getBigDecimal("ARAMA_SAYISI").add(new BigDecimal(1)));
			birBorcTransferiAramaTx.setAramaSonucKod(iMap.getString("ARAMA_SONUC_KOD"));
			birBorcTransferiAramaTx.setAramaSonucAckKod(iMap.getString("ARAMA_SONUC_ACK_KOD"));
			birBorcTransferiAramaTx.setGorusulenIsim(iMap.getString("GORUSULEN_ISIM"));
			birBorcTransferiAramaTx.setGorusulenTelefon(iMap.getString("SUBE_TELEFON"));
			birBorcTransferiAramaTx.setYeniTelefonAlan(iMap.getString("YENI_SUBE_TEL_ALAN"));
			birBorcTransferiAramaTx.setYeniTelefon(iMap.getString("YENI_SUBE_TEL_NO"));
			birBorcTransferiAramaTx.setYeniTelefonDahili(iMap.getString("YENI_SUBE_TEL_DAHILI"));
			if (iMap.getDate("SONRAKI_ARAMA_TARIHI") != null) {
				if(iMap.getString("SONRAKI_ARAMA_SAATI") == null || iMap.getString("SONRAKI_ARAMA_SAATI").length() != 6){
					throw new GMRuntimeException(0, "Randevu Saatini Eksik Girdiniz.");
				}
				birBorcTransferiAramaTx.setSonrakiAramaTarihi(concatDateAndTime(iMap.getString("SONRAKI_ARAMA_TARIHI"), iMap.getString("SONRAKI_ARAMA_SAATI")));
			}
			birBorcTransferiAramaTx.setAciklama(iMap.getString("ACIKLAMA"));
			
			session.save(birBorcTransferiAramaTx);
			session.flush();
			
			iMap.put("TRX_NAME", "8070");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}
	
	public static java.util.Date concatDateAndTime(String date, String time) {
		try {
			return dateFormat.parse((date == null ? "00000000" : date) + " " + (time == null ? "000000" : time));
		}
		catch (Exception e) {
			e.printStackTrace();
			return null; // akis devam etsin diye
		}
	}
	
	@GraymoundService("BNSPR_TRN8070_KAPAMA_FORM_GONDER")
	public static GMMap sendBasvuruOdemePlani(GMMap iMap) {
		GMMap oMap = new GMMap();

		try{
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY1021_GET_CUST_DOC_NAME", iMap));
			iMap.put("DOKUMAN_ADI", iMap.getString("IMAJ_FILE_NAME"));
			iMap.put("DOKUMAN_CLASS", "Musteri");
			iMap.put("DOKUMAN_BYTE_ARRAY_NEEDED", "true");
			
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY1021_GET_DOCUMENT_INFO", iMap));
			//iMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_QRY1021_GET_DOCUMENT_INFO", iMap));
			
			GMMap myMap = new GMMap();
			myMap.put("FROM", "aktifbank@aktifbank.com.tr");
			myMap.put("RECIPIENTS_TO", GuimlUtil.createFromCommaSeparatedList(iMap.getString("EMAIL")));
			myMap.put("IS_BODY_HTML", true);
			myMap.put("SUBJECT", "Kapama Talimat Formu");
			
			GMMap inputMap=new GMMap();
			inputMap.put("FOLDER_NAME","bayiPortal");
			inputMap.put("TEMPLATE_NAME", CreditDocMailTypes.valueOf("KAPAMA_FORM").getVmName());
			inputMap.put("ENCODING", "ISO-8859-9");
			HashMap<String,Object> inputs=new HashMap<String, Object>();
			inputMap.put("INPUTS", inputs);
			myMap.put("MESSAGE_BODY", GMServiceExecuter.call("BNSPR_GENERATE_DYNAMIC_HTML", inputMap).getString("HTML_DATA"));
			
			if(iMap.getString("IMAJ_FILE_TYPE") != null){
				myMap.put("ATTACMENT_FILE_LIST", 0, "FILE_NAME", "KapamaTalimatFormu.".concat(iMap.getString("IMAJ_FILE_TYPE")));
			}else{
				myMap.put("ATTACMENT_FILE_LIST", 0, "FILE_NAME", "KapamaTalimatFormu.pdf");
			}
			
			myMap.put("ATTACMENT_FILE_LIST", 0, "FILE_BYTE_ARRAY", ((ByteArrayType) iMap.get("DOKUMAN_BYTE_ARRAY")).getData());
			myMap.put("SEND_ATTACHMENT_WITHOUT_DYS", true);
			GMServiceExecuter.executeAsync("BNSPR_SYSTEM_MAIL_SEND_EMAIL", myMap);
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
}
