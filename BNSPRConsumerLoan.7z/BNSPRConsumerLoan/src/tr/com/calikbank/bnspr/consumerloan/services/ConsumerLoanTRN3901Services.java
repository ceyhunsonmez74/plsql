package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.istTcmbPuanPr;
import tr.com.calikbank.bnspr.dao.istTcmbPuanPrTx;
import tr.com.calikbank.bnspr.dao.istTcmbPuanPrTxId;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3901Services {
	@GraymoundService("BNSPR_TRN3901_GET_TCMB_PUAN_PR_LIST")
	public static GMMap getTcmbPuanPrList(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>)session.createCriteria(istTcmbPuanPr.class)
			.add(Restrictions.eq("tcmbKaraliste", "T")).list();
			
			GMMap oMap = new GMMap();
			String tableName = "IST_TCMB_PUAN";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				istTcmbPuanPr istTcmbPuanPr = (istTcmbPuanPr) iterator.next();
				
				oMap.put(tableName, row, "KOD", istTcmbPuanPr.getKod());
				oMap.put(tableName, row, "ACIKLAMA", istTcmbPuanPr.getAciklama());
				oMap.put(tableName, row, "CEK_PUAN", istTcmbPuanPr.getCekPuan());
				oMap.put(tableName, row, "KREDI_PUAN", istTcmbPuanPr.getKrediPuan());
				oMap.put(tableName, row, "MAHKEME_PUAN", istTcmbPuanPr.getMahkemePuan());
				oMap.put(tableName, row, "SENET_PUAN", istTcmbPuanPr.getSenetPuan());
				oMap.put(tableName, row, "KARA_LISTE_PUAN", istTcmbPuanPr.getKaraListePuan());
				oMap.put(tableName, row, "ESKI_BASVURU_PUAN", istTcmbPuanPr.getEskiBasvuruPuan());
				oMap.put(tableName, row, "CAPRAZSORGUGRUPKOD", istTcmbPuanPr.getCaprazSorguGrupKod());
				row++;
			}
			
			return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	@GraymoundService("BNSPR_TRN3901_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "IST_TCMB_PUAN";
			List<?> list = (List<?>)iMap.get("IST_TCMB_PUAN");
			for (int i = 0; i < list.size(); i++) {
				istTcmbPuanPrTx istTcmbPuanPrTx = new istTcmbPuanPrTx();
				istTcmbPuanPrTxId istTcmbPuanPrTxId = new istTcmbPuanPrTxId();
				
				istTcmbPuanPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				istTcmbPuanPrTxId.setKod(iMap.getString(tableName, i, "KOD"));
			
				if ( iMap.getString(tableName, i, "KOD") == null || iMap.getString(tableName, i, "KOD").length() ==0  ){
					iMap.put("HATA_NO", new BigDecimal(1453));
					iMap.put("P1", i+1);
					iMap.put("P2", "KOD");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}

				int l=0;
				
				for (int j = i+1; j < list.size(); j++) {
			
				 if ( iMap.getString(tableName, j, "KOD") == null || iMap.getString(tableName, j, "KOD").length() ==0  ){
						iMap.put("HATA_NO", new BigDecimal(1453));
						iMap.put("P1", j+1);
						iMap.put("P2", "KOD");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					
					l =iMap.getString(tableName, j, "KOD").compareTo(iMap.getString(tableName, i, "KOD") );
					if ( l==0  ){	
						iMap.put("HATA_NO", new BigDecimal(1459));
						iMap.put("P1", i+1);
						iMap.put("P2", j+1);
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	
					}

				}
				istTcmbPuanPrTx.setId(istTcmbPuanPrTxId);
				istTcmbPuanPrTx.setCaprazSorguGrupKod(iMap.getString(tableName, i, "CAPRAZSORGUGRUPKOD"));	
				istTcmbPuanPrTx.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
				istTcmbPuanPrTx.setCekPuan(iMap.getBigDecimal(tableName, i, "CEK_PUAN"));
				istTcmbPuanPrTx.setKrediPuan(iMap.getBigDecimal(tableName, i, "KREDI_PUAN"));
				istTcmbPuanPrTx.setMahkemePuan(iMap.getBigDecimal(tableName, i, "MAHKEME_PUAN"));
				istTcmbPuanPrTx.setSenetPuan(iMap.getBigDecimal(tableName, i, "SENET_PUAN"));
				istTcmbPuanPrTx.setKaraListePuan(new BigDecimal("0"));
				istTcmbPuanPrTx.setEskiBasvuruPuan(new BigDecimal("0"));
				istTcmbPuanPrTx.setTcmbKaraliste("T");
				
				session.save(istTcmbPuanPrTx);
			}
			session.flush();
			
			iMap.put("TRX_NAME", "3901");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			if(e.getCause()!=null)throw new GMRuntimeException(0,e.getCause().getMessage());
			else throw new GMRuntimeException(0,e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3901_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>)session.createCriteria(istTcmbPuanPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "IST_TCMB_PUAN";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				istTcmbPuanPrTx istTcmbPuanPrTx = (istTcmbPuanPrTx) iterator.next();
				
				oMap.put(tableName, row, "KOD", istTcmbPuanPrTx.getId().getKod());
				oMap.put(tableName, row, "ACIKLAMA", istTcmbPuanPrTx.getAciklama());
				oMap.put(tableName, row, "CEK_PUAN", istTcmbPuanPrTx.getCekPuan());
				oMap.put(tableName, row, "KREDI_PUAN", istTcmbPuanPrTx.getKrediPuan());
				oMap.put(tableName, row, "MAHKEME_PUAN", istTcmbPuanPrTx.getMahkemePuan());
				oMap.put(tableName, row, "SENET_PUAN", istTcmbPuanPrTx.getSenetPuan());
				oMap.put(tableName, row, "KARA_LISTE_PUAN", istTcmbPuanPrTx.getKaraListePuan());
				oMap.put(tableName, row, "ESKI_BASVURU_PUAN", istTcmbPuanPrTx.getEskiBasvuruPuan());
				oMap.put(tableName, row, "CAPRAZSORGUGRUPKOD", istTcmbPuanPrTx.getCaprazSorguGrupKod());
				
				row++;
			}
			
			return oMap;
		}catch (Exception e) {
			throw new GMRuntimeException(0,e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3901_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();  
			
			iMap.put("KOD", "FRAUD_SORGU_SEVIYE_KOD");
			oMap.put("FROUD_SORGU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
	
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}	
		
	}
	

}
