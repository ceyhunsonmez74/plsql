package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;

import net.sf.jasperreports.engine.JRPrintPage;
import net.sf.jasperreports.engine.JasperPrint;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirSaticiUptTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirSatici;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.ReportUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3281Services {
	@GraymoundService("BNSPR_TRN3281_SAVE")
	public static GMMap save3281(GMMap iMap){
		GMMap oMap = new GMMap();
		try {			
			Session session = DAOSession.getSession("BNSPRDal");
			BirSaticiUptTx birSaticiUptTx = (BirSaticiUptTx) session.createCriteria(BirSaticiUptTx.class).add(Restrictions.eq("txNo",iMap.getBigDecimal("TRX_NO") )).uniqueResult();
		    if(birSaticiUptTx == null) {
		    	throw new Exception("��lem Numaras� Bulunamad�");
		    }
		    birSaticiUptTx.setUptReferansNo(iMap.getString("TU_REFNUMBER"));
		    session.update(birSaticiUptTx);
		    session.flush();		
			GMMap tMap = GMServiceExecuter.call("BNSPR_EXT_BAYI_UPT_CONFIRM", iMap);
			if("0".equals(tMap.getString("RESULT_CODE"))) {
				throw new Exception(tMap.getString("ERROR_DESCRIPTION"));
			}
			iMap.put("TRX_NAME", "3281");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
			return oMap;
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
   		}
	}	
	
	@GraymoundService("BNSPR_TRN3281_CONTROL")
	public static GMMap control3281(GMMap iMap){
		GMMap oMap = new GMMap();
		try {		
			BigDecimal txNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");		
			Session session = DAOSession.getSession("BNSPRDal");
			BirSaticiUptTx birSaticiUptTx = new BirSaticiUptTx();
			birSaticiUptTx.setTxNo(txNo);
			birSaticiUptTx.setAliciHesapNo(iMap.getBigDecimal("ALICI_HESAP_NO"));
			birSaticiUptTx.setDovizCinsi("TRY");
			birSaticiUptTx.setIban(iMap.getString("IBAN"));
			birSaticiUptTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			birSaticiUptTx.setSaticiHesapNo(iMap.getBigDecimal("SATICI_HESAP_NO"));
			birSaticiUptTx.setSaticiKod(iMap.getBigDecimal("SATICI_KOD"));
			birSaticiUptTx.setTcKimlikNo(iMap.getString("TCKN"));
			birSaticiUptTx.setTutar(iMap.getBigDecimal("AMOUNT")); 
			birSaticiUptTx.setKullaniciKod(iMap.getString("KULLANICI_KOD"));
			session.save(birSaticiUptTx);
			session.flush();
			String func = "{ call pkg_trn3281.after_control(?) }";
			Object[] inputValues = {
				BnsprType.NUMBER, txNo	
			};
			Object[] outputValues = {};
			DALUtil.callOracleProcedure(func, inputValues, outputValues);
			oMap.put("TRX_NO", txNo);
			iMap.put("TRX_NO", txNo);
			if(iMap.get("NUF_SERI_NO") == null || iMap.getString("NUF_SERI_NO").isEmpty()) {
				iMap.put("NUF_SERI_NO", iMap.getString("TCKN"));
			}
			oMap.putAll(GMServiceExecuter.call("BNSPR_EXT_BAYI_UPT_SEND_REQUEST", iMap));			
		    return oMap;
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
   		}
	}
	
	@GraymoundService("BNSPR_TRN3281_DEKONT")
	public static GMMap dekont(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("TX_NO", iMap.getBigDecimal("TRX_NO"));
		    parameters.put("BAYI_MUSTERI", "B");
			JasperPrint jasperPrint = ReportUtil.generateReport("DEKONT_BAYI_UPT", parameters);
		    parameters.put("BAYI_MUSTERI", "M");
			JasperPrint tmp = ReportUtil.generateReport("DEKONT_BAYI_UPT", parameters);
			for (Object jasperPrintPage : tmp.getPages()) {
	            jasperPrint.addPage((JRPrintPage) jasperPrintPage);
	        }		
			tmp = ReportUtil.generateReport("FORM_BAYI_UPT", parameters);
			for (Object jasperPrintPage : tmp.getPages()) {
	            jasperPrint.addPage((JRPrintPage) jasperPrintPage);
	        }		
			oMap.put("REPORT", jasperPrint);
			return oMap;		 
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
   		}
	}
	
	@GraymoundService("BNSPR_TRN3281_SATICI_INFO")
	public static GMMap saticiInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirSatici birSatici = (BirSatici) session.createCriteria(BirSatici.class).add(Restrictions.eq("kod",iMap.getBigDecimal("SATICI_KOD") )).uniqueResult();
		    if(birSatici == null) {
		    	throw new Exception("Bayi Bulunamad�.");		    	
		    }
		    oMap.put("SATICI_KOD", birSatici.getKod());
		    oMap.put("SATICI_HESAP_NO", birSatici.getHesapNo());
		    
		    if(iMap.get("BAYI_LIST") != null) {
				oMap.put("BAYI_LIST", 0,"NAME",birSatici.getSaticiAdi());
		    	oMap.put("BAYI_LIST", 0,"VALUE",birSatici.getKod());
			    if("M".equals(birSatici.getSaticiTipKod())) {
			    	List<BirSatici> subeList = (List<BirSatici>) session.createCriteria(BirSatici.class).add(Restrictions.eq("bagliMerkezBayi", iMap.getBigDecimal("SATICI_KOD"))).list();
			    	int row=1;
			    	for(BirSatici satici:subeList) {
			    		oMap.put("BAYI_LIST", row,"NAME" ,satici.getSaticiAdi());
				    	oMap.put("BAYI_LIST", row,"VALUE",satici.getKod());
				    	row++;
			    	}
			    }
		    } else {
		    	String func = "{ ? = call pkg_hesap.kullanilabilir_bakiye_al(?) }";
			    Object[] inputValues = {
			    	BnsprType.NUMBER, birSatici.getHesapNo()	
			    };
			    oMap.put("LIMIT",DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues)+" TL");
		    }
			return oMap;		 
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
   		}
	}
	
	@GraymoundService("BNSPR_TRN3281_LIST")
	public static GMMap list(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			String func = "{ ? = call pkg_trn3281.rc_islem_listesi(?,?,?,?,?,?,?) }";
		    Object[] inputValues = {
		    	BnsprType.STRING, iMap.getString("TCKN"),
		    	BnsprType.STRING, iMap.getString("AD_SOYAD"),
		    	BnsprType.STRING, iMap.getString("BAS_TAR"),
		    	BnsprType.STRING, iMap.getString("BIT_TAR"),
		    	BnsprType.NUMBER, iMap.getBigDecimal("BAYI_KOD"),
		    	BnsprType.STRING, iMap.getString("STATU"),
		    	BnsprType.STRING, iMap.getString("UPT_REFERANS_NO")		    	
		    };
		    oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "ISLEM_LISTESI", inputValues));
			return oMap;		 
		} catch(Exception e) {
			throw ExceptionHandler.convertException(e);
   		}
	}
	
}
