package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Calendar;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3148Services {

	
	@GraymoundService("BNSPR_QRY3148_GET_RECORD_LIST")
	public static GMMap getRecordList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3148.GET_RECORD_LIST(?)}");
			
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);
			
			BigDecimal sumTaksitTutari = new BigDecimal(0);
			BigDecimal sumAnapara = new BigDecimal(0);
			BigDecimal sumFaiz = new BigDecimal(0);
			BigDecimal sumKKDF = new BigDecimal(0);
			BigDecimal sumBSMV = new BigDecimal(0);
			BigDecimal sumGecikmeFaizAlinan = new BigDecimal(0);
			BigDecimal sumOdemeTutari = new BigDecimal(0);
			
			BigDecimal sumTaksitTutari_gecikme = new BigDecimal(0);
			BigDecimal sumAnapara_gecikme = new BigDecimal(0);
			BigDecimal sumFaiz_gecikme = new BigDecimal(0);
			BigDecimal sumKKDF_gecikme = new BigDecimal(0);
			BigDecimal sumBSMV_gecikme = new BigDecimal(0);
			BigDecimal sumGecikmeFaizAlinan_gecikme = new BigDecimal(0);
			BigDecimal sumOdemeTutari_gecikme = new BigDecimal(0);
			BigDecimal kismiden_kalan_taksit = new BigDecimal(0);
			
			GMMap s3Map = new GMMap();
			Calendar c = Calendar.getInstance(); /** PY-11226 **/
			s3Map.put("BANKA_TARIH", c.getTime()); // (GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", s3Map ) );
			
			String tableName = "RESULTS";
			int row = 0;
			while (rSet.next()) {
				int j = 1;

				oMap.put(tableName, row, "SIRA_NO", rSet.getBigDecimal("SIRA_NO"));
				oMap.put(tableName, row, "TAKSIT_TARIH", rSet.getDate("TAKSIT_TARIHI"));
				oMap.put(tableName, row, "TAKSIT_TUT", rSet.getBigDecimal("TAKSIT_TUT"));
				oMap.put(tableName, row, "ISLEM_KOD", rSet.getBigDecimal("ISLEM_KOD"));
				oMap.put(tableName, row, "KDV", rSet.getBigDecimal("KDV"));
				oMap.put(tableName, row, "ANAPARA", rSet.getBigDecimal("ANAPARA"));
				oMap.put(tableName, row, "FAIZ", rSet.getBigDecimal("FAIZ"));
				oMap.put(tableName, row, "KKDF", rSet.getBigDecimal("KKDF"));
				oMap.put(tableName, row, "BSMV", rSet.getBigDecimal("BSMV"));
				oMap.put(tableName, row, "KALAN_ANAPARA", rSet.getBigDecimal("KALAN_ANAPARA"));
				oMap.put(tableName, row, "DURUM_KODU", rSet.getString("DURUM_KODU"));
				String durum = rSet.getString("DURUM_KODU") ;  //rSet.getString(j);
				j++;
				oMap.put(tableName, row, "ODEME_TARIH", rSet.getDate("ODEME_TARIHI"));
				String odemeTarihi = rSet.getString("ODEME_TARIHI");
				j++;
				
				if ( (durum.compareTo("ACIK") ==0) &&  odemeTarihi == null && s3Map.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName, row, "TAKSIT_TARIH") ) > 0
						&& rSet.getBigDecimal("TAKSIT_TUT").compareTo(new BigDecimal(0)) == 1 ){
					oMap.put(tableName, row, "DURUM_KODU","GECIKMEDE") ;
					
					GMMap inputDates = new GMMap();
					inputDates.put("FIRST_DATE", oMap.getDate(tableName, row, "TAKSIT_TARIH"));
					inputDates.put("SECOND_DATE", s3Map.getDate("BANKA_TARIH"));
					GMMap dayMap = GMServiceExecuter.call("BNSPR_COMMON_GUN_FARKI_HESAPLA", inputDates);
					oMap.put(tableName, row, "GECIKME_GUN_SAYISI", dayMap.getBigDecimal("DAYS"));
				}
				
				if ((durum.compareTo("ODENDI")==0) && odemeTarihi != null)  {
					GMMap inputDates = new GMMap();
					inputDates.put("FIRST_DATE", oMap.getDate(tableName, row, "TAKSIT_TARIH"));
					inputDates.put("SECOND_DATE",  oMap.getDate(tableName, row, "ODEME_TARIH"));
					GMMap dayMap = GMServiceExecuter.call("BNSPR_COMMON_GUN_FARKI_HESAPLA", inputDates);
					if (dayMap.getBigDecimal("DAYS")!= null && dayMap.getBigDecimal("DAYS").intValue()>0 ){
						oMap.put(tableName, row, "GECIKME_GUN_SAYISI", dayMap.getBigDecimal("DAYS"));
						oMap.put(tableName, row, "GECIKME_FAIZ_ALINAN", rSet.getBigDecimal("GECIKME_FAIZ_ALINAN"));
						oMap.put(tableName, row, "GECIKME_FAIZI", rSet.getBigDecimal("GECIKME_FAIZ_TUTARI")); 	
					}
				}
				
				if ( (durum.compareTo("ACIK") ==0) &&  s3Map.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName, row, "TAKSIT_TARIH") ) > -1
						&& rSet.getBigDecimal("TAKSIT_TUT").compareTo(new BigDecimal(0)) == 0 ){
					oMap.put(tableName, row, "DURUM_KODU","ODENDI") ;
				}
				
				BigDecimal odemeTxNo = rSet.getBigDecimal("ODEME_TXNO");
				if(rSet.getBigDecimal("TAKSIT_TUT").equals(BigDecimal.ZERO))
					odemeTxNo = null;
				oMap.put(tableName, row, "ODEME_TXNO", odemeTxNo);
				oMap.put(tableName, row, "ODEME_KURU", rSet.getBigDecimal("ODEME_KURU"));
				oMap.put(tableName, row, "SIGORTA_TUTARI_MASRAF", rSet.getBigDecimal("MASRAF"));
				oMap.put(tableName, row, "AYLIK_TOPLAM_ODEME_TUTARI", rSet.getBigDecimal("AYLIK_TOPLAM_ODEME_TUTARI"));
				if (  s3Map.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName, row, "TAKSIT_TARIH") ) >= 0 )  {
					if (oMap.getDate(tableName, row, "ODEME_TARIH") != null ){
						if (oMap.getString(tableName, row, "DURUM_KODU").equals("KISMI") ){
							GMMap inputDates = new GMMap();
							inputDates.put("FIRST_DATE", oMap.getDate(tableName, row, "TAKSIT_TARIH"));
							inputDates.put("SECOND_DATE", s3Map.getDate("BANKA_TARIH"));
							GMMap dayMap = GMServiceExecuter.call("BNSPR_COMMON_GUN_FARKI_HESAPLA", inputDates);
							oMap.put(tableName, row, "GECIKME_GUN_SAYISI", dayMap.getBigDecimal("DAYS"));
						}
					}
				}


				if (oMap.getString(tableName, row, "DURUM_KODU").equals("KISMI") || oMap.getString(tableName, row, "DURUM_KODU").equals("ODENDI")  ){
					oMap.put(tableName, row, "TAHSIS_EDILMIS_TAKSIT_BORCU", rSet.getBigDecimal("TAHSIS_EDILMIS_TAKSIT_BORCU"));		
				}else{
					oMap.put(tableName, row, "TAHSIS_EDILMIS_TAKSIT_BORCU", "0");
					j++;
				}
				if (oMap.getString(tableName, row, "DURUM_KODU").equals("GECIKMEDE")) {
					oMap.put(tableName, row, "GECIKME_FAIZI", rSet.getBigDecimal("GECIKME_FAIZ_TUTARI")); 	
				}

				
				if (oMap.getString(tableName, row, "DURUM_KODU").equals("KISMI")) {
					// Tahsil edilmemi� gecikme faizikalan_gecikme_faizi
					oMap.put(tableName, row, "GECIKME_FAIZI", rSet.getBigDecimal("KALAN_GECIKME_FAIZI")); 
					// Tahsil edilmi� gecikme faiz tutar�
					oMap.put(tableName, row, "GECIKME_FAIZ_ALINAN", rSet.getBigDecimal("GECIKME_FAIZ_ALINAN"));
					oMap.put("a",rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARA"));
					oMap.put(tableName, row, "KISMIDEN_KALAN_ANAPARA", rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARA"));
					oMap.put(tableName, row, "KISMIDEN_KALAN_FAIZ", rSet.getBigDecimal("KISMIDEN_KALAN_FAIZ"));
					oMap.put(tableName, row, "KISMIDEN_KALAN_KKDF", rSet.getBigDecimal("KISMIDEN_KALAN_KKDF"));
					oMap.put(tableName, row, "KISMIDEN_KALAN_BSMV", rSet.getBigDecimal("KISMIDEN_KALAN_BSMV"));
					kismiden_kalan_taksit =  rSet.getBigDecimal("TAKSIT_TUT").subtract(rSet.getBigDecimal("TAHSIS_EDILMIS_TAKSIT_BORCU")!=null?rSet.getBigDecimal("TAHSIS_EDILMIS_TAKSIT_BORCU"):new BigDecimal(0))  ; 
				    if ( kismiden_kalan_taksit.compareTo(new BigDecimal(0)) == -1 ) kismiden_kalan_taksit = new BigDecimal(0) ;
					oMap.put(tableName, row, "KISMIDEN_KALAN_TAKSIT",kismiden_kalan_taksit.add(rSet.getBigDecimal("KALAN_GECIKME_FAIZI")!=null?rSet.getBigDecimal("KALAN_GECIKME_FAIZI"):new BigDecimal(0)) );
				    	
				}
				
				oMap.put(tableName, row, "ERKEN_ODEME_FAIZ_INDIRIMI", rSet.getBigDecimal("ERKEN_ODEME_FAIZ_INDIRIMI"));

				
		        // ALT TOPLAMLAR  -- BA�LADI

				if(oMap.getString(tableName,row,"DURUM_KODU").equals("ACIK")) {
					sumGecikmeFaizAlinan = sumGecikmeFaizAlinan.add(rSet.getBigDecimal("KALAN_GECIKME_FAIZI")!=null?rSet.getBigDecimal("KALAN_GECIKME_FAIZI"):new BigDecimal(0));
					sumFaiz = sumFaiz.add(rSet.getBigDecimal("FAIZ")!=null?rSet.getBigDecimal("FAIZ"):new BigDecimal(0));
					sumBSMV = sumBSMV.add(rSet.getBigDecimal("BSMV")!=null?rSet.getBigDecimal("BSMV"):new BigDecimal(0));
				    sumKKDF = sumKKDF.add(rSet.getBigDecimal("KKDF")!=null?rSet.getBigDecimal("KKDF"):new BigDecimal(0));
				    sumTaksitTutari = sumTaksitTutari.add(rSet.getBigDecimal("TAKSIT_TUT")!=null?rSet.getBigDecimal("TAKSIT_TUT"):new BigDecimal(0));
				    sumAnapara = sumAnapara.add(rSet.getBigDecimal("ANAPARA")!=null?rSet.getBigDecimal("ANAPARA"):new BigDecimal(0));
				}
				if(oMap.getString(tableName,row,"DURUM_KODU").equals("GECIKMEDE")){
					sumGecikmeFaizAlinan_gecikme = sumGecikmeFaizAlinan_gecikme.add(rSet.getBigDecimal("GECIKME_FAIZ_TUTARI")!=null?rSet.getBigDecimal("GECIKME_FAIZ_TUTARI"):new BigDecimal(0));
					sumFaiz_gecikme = sumFaiz_gecikme.add(rSet.getBigDecimal("FAIZ")!=null?rSet.getBigDecimal("FAIZ"):new BigDecimal(0));
					sumBSMV_gecikme = sumBSMV_gecikme.add(rSet.getBigDecimal("BSMV")!=null?rSet.getBigDecimal("BSMV"):new BigDecimal(0));
				    sumKKDF_gecikme = sumKKDF_gecikme.add(rSet.getBigDecimal("KKDF")!=null?rSet.getBigDecimal("KKDF"):new BigDecimal(0));
				    sumTaksitTutari_gecikme = sumTaksitTutari_gecikme.add(rSet.getBigDecimal("TAKSIT_TUT")!=null?rSet.getBigDecimal("TAKSIT_TUT"):new BigDecimal(0));
				    sumAnapara_gecikme = sumAnapara_gecikme.add(rSet.getBigDecimal("ANAPARA")!=null?rSet.getBigDecimal("ANAPARA"):new BigDecimal(0));

					sumGecikmeFaizAlinan = sumGecikmeFaizAlinan.add(rSet.getBigDecimal("GECIKME_FAIZ_TUTARI")!=null?rSet.getBigDecimal("GECIKME_FAIZ_TUTARI"):new BigDecimal(0));
					sumFaiz = sumFaiz.add(rSet.getBigDecimal("FAIZ")!=null?rSet.getBigDecimal("FAIZ"):new BigDecimal(0));
					sumBSMV = sumBSMV.add(rSet.getBigDecimal("BSMV")!=null?rSet.getBigDecimal("BSMV"):new BigDecimal(0));
				    sumKKDF = sumKKDF.add(rSet.getBigDecimal("KKDF")!=null?rSet.getBigDecimal("KKDF"):new BigDecimal(0));
				    sumTaksitTutari = sumTaksitTutari.add(rSet.getBigDecimal("TAKSIT_TUT")!=null?rSet.getBigDecimal("TAKSIT_TUT"):new BigDecimal(0));
				    sumAnapara = sumAnapara.add(rSet.getBigDecimal("ANAPARA")!=null?rSet.getBigDecimal("ANAPARA"):new BigDecimal(0));

				}
				if (oMap.getString(tableName, row, "DURUM_KODU").equals("KISMI") ){
					if (  s3Map.getDate("BANKA_TARIH").compareTo(oMap.getDate(tableName, row, "TAKSIT_TARIH") ) >= 0 )  { // gecikmede
						sumGecikmeFaizAlinan_gecikme = sumGecikmeFaizAlinan_gecikme.add(rSet.getBigDecimal("KALAN_GECIKME_FAIZI")!=null?rSet.getBigDecimal("KALAN_GECIKME_FAIZI"):new BigDecimal(0));
					    sumFaiz_gecikme = sumFaiz_gecikme.add(rSet.getBigDecimal("KISMIDEN_KALAN_FAIZ")!=null?rSet.getBigDecimal("KISMIDEN_KALAN_FAIZ"):new BigDecimal(0));
					    sumBSMV_gecikme = sumBSMV_gecikme.add(rSet.getBigDecimal("KISMIDEN_KALAN_BSMV")!=null?rSet.getBigDecimal("KISMIDEN_KALAN_BSMV"):new BigDecimal(0));
					    sumKKDF_gecikme = sumKKDF_gecikme.add(rSet.getBigDecimal("KISMIDEN_KALAN_KKDF")!=null?rSet.getBigDecimal("KISMIDEN_KALAN_KKDF"):new BigDecimal(0));
					    sumTaksitTutari_gecikme = sumTaksitTutari_gecikme.add(kismiden_kalan_taksit);
					    sumAnapara_gecikme = sumAnapara_gecikme.add(rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARA")!=null?rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARA"):new BigDecimal(0));	
					} 
						
					sumGecikmeFaizAlinan = sumGecikmeFaizAlinan.add(rSet.getBigDecimal("KALAN_GECIKME_FAIZI")!=null?rSet.getBigDecimal("KALAN_GECIKME_FAIZI"):new BigDecimal(0));
					sumFaiz = sumFaiz.add(rSet.getBigDecimal("KISMIDEN_KALAN_FAIZ")!=null?rSet.getBigDecimal("KISMIDEN_KALAN_FAIZ"):new BigDecimal(0));
					sumBSMV = sumBSMV.add(rSet.getBigDecimal("KISMIDEN_KALAN_BSMV")!=null?rSet.getBigDecimal("KISMIDEN_KALAN_BSMV"):new BigDecimal(0));
					sumKKDF = sumKKDF.add(rSet.getBigDecimal("KISMIDEN_KALAN_KKDF")!=null?rSet.getBigDecimal("KISMIDEN_KALAN_KKDF"):new BigDecimal(0));
					sumTaksitTutari = sumTaksitTutari.add(kismiden_kalan_taksit );
					sumAnapara = sumAnapara.add(rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARA")!=null?rSet.getBigDecimal("KISMIDEN_KALAN_ANAPARA"):new BigDecimal(0));	    
				
				}
				//

				// ALT TOPLAMLAR -- B�TT� 				
				
				
				row++;
			}
			GMServerDatasource.close(rSet);		

	 		
			    oMap.put("SUM_TAKSIT_TUTAR", sumTaksitTutari);
			    oMap.put("SUM_ANAPARA", sumAnapara);
			    oMap.put("SUM_FAIZ", sumFaiz);
			    oMap.put("SUM_KKDF", sumKKDF);
			    oMap.put("SUM_BSMV", sumBSMV);
			    oMap.put("SUMGECIKMEFAIZI", sumGecikmeFaizAlinan);
			    sumOdemeTutari = sumTaksitTutari.add(sumGecikmeFaizAlinan) ; 
			    oMap.put("SUMODEMETUTARI", sumOdemeTutari);
			    
			    oMap.put("SUM_TAKSIT_TUTAR_GECIKME", sumTaksitTutari_gecikme);
			    oMap.put("SUM_ANAPARA_GECIKME", sumAnapara_gecikme);
			    oMap.put("SUM_FAIZ_GECIKME", sumFaiz_gecikme);
			    oMap.put("SUM_KKDF_GECIKME", sumKKDF_gecikme);
			    oMap.put("SUM_BSMV_GECIKME", sumBSMV_gecikme);
			    oMap.put("SUMGECIKMEFAIZI_GECIKME", sumGecikmeFaizAlinan_gecikme);
			    sumOdemeTutari_gecikme = sumTaksitTutari_gecikme.add(sumGecikmeFaizAlinan_gecikme) ; 
			    oMap.put("SUMODEMETUTARI_GECIKME", sumOdemeTutari_gecikme);
			    
		 
			oMap.put("ROW_COUNT", row);
			
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {		
			GMServerDatasource.close(rSet); 
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	
	@GraymoundService("BNSPR_QRY3148_GET_KREDI_ODEME_IST")
	public static GMMap getKrediOdemeList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC3148.GET_ODEME_LIST(?,?)}");
			
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SIRA_NO"));
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);
			
			oMap = DALUtil.rSetResults(rSet,"ISLEM_LIST");

			oMap.put("KAYIT_SAYISI", oMap.getSize("ISLEM_LIST"));
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}		
	
	 
}
