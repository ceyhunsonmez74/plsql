package tr.com.calikbank.bnspr.consumerloan.document.type;

import java.util.HashMap;

import tr.com.calikbank.bnspr.consumerloan.utils.Enums;

public class KvkForm extends WebCreditDocument {

	public KvkForm() {
		super("kvkForm", "kvkForm", Enums.CreditDocTypes.KVK_FORM.getCode() );
	}
	
	@Override
	public String generateXml(String applicationNo, HashMap<String, Object> parameters) {
		return "<AGREEMENT_INFO></AGREEMENT_INFO>";
		
	}
	
	
	
}
