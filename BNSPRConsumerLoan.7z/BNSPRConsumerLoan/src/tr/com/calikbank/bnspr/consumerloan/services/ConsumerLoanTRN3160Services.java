package tr.com.calikbank.bnspr.consumerloan.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirBayiMalTanimTx;
import tr.com.aktifbank.bnspr.dao.BirBayiMalTanimTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3160Services {

	/**
	 * to change the display data on screen
	 * TABLE2 is the whole table but the CURRENT_TABLE is the displayable table
	 * 
	 * @param iMap
	 * @param oMap
	 * @return
	 */
	private static GMMap tabloDegistir(GMMap iMap, GMMap oMap) {
		int innerRow = 0;
		int outerRow = 0;

		while (innerRow < iMap.getSize("TABLE2")) {
			outerRow = 0;
			while (outerRow < oMap.getSize("CURRENT_TABLE")) {
				if (iMap.getString("TABLE2", innerRow, "MALNO").equals(oMap.getString("CURRENT_TABLE", outerRow, "MALNO"))) {
					oMap.put("CURRENT_TABLE", outerRow, "AD", iMap.getString("TABLE2", innerRow, "AD"));
					oMap.put("CURRENT_TABLE", outerRow, "TIP", iMap.getString("TABLE2", innerRow, "TIP"));
					oMap.put("CURRENT_TABLE", outerRow, "RISKLI_URUN_ADET", iMap.getString("TABLE2", innerRow, "RISKLI_URUN_ADET"));
					oMap.put("CURRENT_TABLE", outerRow, "TESLIMAT_ZORUNLUMU", iMap.getString("TABLE2", innerRow, "TESLIMAT_ZORUNLUMU"));
					oMap.put("CURRENT_TABLE", outerRow, "ACIKLAMA", iMap.getString("TABLE2", innerRow, "ACIKLAMA"));
					break;
				}
				outerRow++;
			}
			innerRow++;

		}

		return oMap;
	}

	private static int maxSeviyeBul(Object table, String durum) {
		int maxSeviye = 0;
		List<HashMap<String, String>> list = (List<HashMap<String, String>>) table;

		Iterator<HashMap<String, String>> iterator = list.iterator();

		while (iterator.hasNext()) {

			HashMap<String, String> hashMap = iterator.next();

			if (hashMap.get("DRM").equals(durum)) {
				if (Integer.parseInt(hashMap.get("SEVIYE")) > maxSeviye)
					maxSeviye = Integer.parseInt(hashMap.get("SEVIYE"));
			}
			else if (durum.equals("T")) {
				if (Integer.parseInt(hashMap.get("SEVIYE")) > maxSeviye)
					maxSeviye = Integer.parseInt(hashMap.get("SEVIYE"));

			}
		}
		return maxSeviye;
	}

	@GraymoundService("BNSPR_TRN1360_URUN_KAPAT")
	public static GMMap urunKapat(GMMap iMap) {
		GMMap oMap = new GMMap();
		String anahtar = iMap.getString("ANAHTAR");
		tabloDegistir(iMap, iMap);

		String altUrunMu = "";
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int row = 0;
		int maxSeviye = 0;

		while (row < iMap.getSize("CURRENT_TABLE")) {
			try {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call PKG_TRN3160.alt_urun_EH(?,?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setString(2, iMap.getString("CURRENT_TABLE", row, "ANAHTAR"));
				stmt.setString(3, anahtar);
				stmt.execute();

				altUrunMu = (String) stmt.getObject(1);
				if (altUrunMu.equals("E"))
					iMap.put("CURRENT_TABLE", row, "DRM", "K");
				else if (anahtar.equals(iMap.get("CURRENT_TABLE", row, "ANAHTAR")))
					iMap.put("CURRENT_TABLE", row, "DRM", "K");
				row++;
			}

			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
			finally {
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}

		}

		oMap.put("CURRENT_TABLE", iMap.get("CURRENT_TABLE"));
		maxSeviye = maxSeviyeBul(oMap.get("CURRENT_TABLE"), "A");
		if (maxSeviye > 5)
			maxSeviye = 5;
		oMap.put("MAX_SEVIYE", maxSeviye);
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1360_URUN_AC")
	public static GMMap urunAc(GMMap iMap) {
		GMMap oMap = new GMMap();
		String anahtar = iMap.getString("ANAHTAR");
		tabloDegistir(iMap, iMap);

		String altUrunMu = "";
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int row = 0;
		int maxSeviye = 0;

		while (row < iMap.getSize("CURRENT_TABLE")) {
			try {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call PKG_TRN3160.alt_urun_EH(?,?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setString(2, iMap.getString("CURRENT_TABLE", row, "ANAHTAR"));
				stmt.setString(3, anahtar);
				stmt.execute();

				altUrunMu = (String) stmt.getObject(1);
				if (altUrunMu.equals("E"))
					iMap.put("CURRENT_TABLE", row, "DRM", "A");
				else if (anahtar.equals(iMap.get("CURRENT_TABLE", row, "ANAHTAR")))
					iMap.put("CURRENT_TABLE", row, "DRM", "A");
				row++;
			}

			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
			finally {
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}

		}

		oMap.put("CURRENT_TABLE", iMap.get("CURRENT_TABLE"));
		maxSeviye = maxSeviyeBul(oMap.get("CURRENT_TABLE"), "K");
		if (maxSeviye > 5)
			maxSeviye = 5;
		oMap.put("MAX_SEVIYE", maxSeviye);
		return oMap;

	}

	@GraymoundService("BNSPR_TRN1360_URUN_ALT_EKLE")
	public static GMMap urunAltEkle(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int row = 0;
		String tip = "";
		String drm = "";
		String malNo = "";
		while (row < iMap.getSize("TABLE")) {
			if (iMap.getString("TABLE", row, "MALNO").equals(iMap.getString("MALNO"))) {
				tip = iMap.getString("TABLE", row, "TIP");
				break;
			}
			row++;
		}
		int index = iMap.getSize("TABLE");

		while (index > row) {
			iMap.put("TABLE", index, "DRM", iMap.getString("TABLE", index - 1, "DRM"));
			iMap.put("TABLE", index, "MALNO", iMap.getString("TABLE", index - 1, "MALNO"));
			iMap.put("TABLE", index, "UST_MALNO", iMap.getString("TABLE", index - 1, "UST_MALNO"));
			iMap.put("TABLE", index, "AD", iMap.getString("TABLE", index - 1, "AD"));
			iMap.put("TABLE", index, "TIP", iMap.getString("TABLE", index - 1, "TIP"));
			iMap.put("TABLE", index, "SEVIYE", iMap.getInt("TABLE", index - 1, "SEVIYE"));
			iMap.put("TABLE", index, "USTISIM", iMap.getString("TABLE", index - 1, "USTISIM"));
			iMap.put("TABLE", index, "ANAHTAR", iMap.getString("TABLE", index - 1, "ANAHTAR"));
			iMap.put("TABLE", index, "RISKLI_URUN_ADET", iMap.getString("TABLE", index - 1, "RISKLI_URUN_ADET"));
			iMap.put("TABLE", index, "ACIKLAMA", iMap.getString("TABLE", index - 1, "ACIKLAMA"));
			iMap.put("TABLE", index, "TESLIMAT_ZORUNLUMU", iMap.getString("TABLE", index - 1, "TESLIMAT_ZORUNLUMU"));

			index--;

		}

		drm = iMap.getString("DRM");

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3160.mal_no_al}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();
			malNo = (String) stmt.getObject(1);
		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		iMap.put("TABLE", row, "MALNO", iMap.getString("TABLE", row + 1, "MALNO"));
		iMap.put("TABLE", row, "UST_MALNO", iMap.getString("TABLE", row + 1, "UST_MALNO"));
		iMap.put("TABLE", row, "DRM", iMap.getString("TABLE", row + 1, "DRM"));
		iMap.put("TABLE", row, "AD", iMap.getString("TABLE", row + 1, "AD"));
		iMap.put("TABLE", row, "TIP", iMap.getString("TABLE", row + 1, "TIP"));
		iMap.put("TABLE", row, "SEVIYE", iMap.getString("TABLE", row + 1, "SEVIYE"));
		iMap.put("TABLE", row, "USTISIM", iMap.getString("TABLE", row + 1, "USTISIM"));
		iMap.put("TABLE", row, "ANAHTAR", iMap.getString("TABLE", row + 1, "ANAHTAR"));
		iMap.put("TABLE", row, "RISKLI_URUN_ADET", iMap.getString("TABLE", row + 1, "RISKLI_URUN_ADET"));
		iMap.put("TABLE", row, "TESLIMAT_ZORUNLUMU", iMap.getString("TABLE", row + 1, "TESLIMAT_ZORUNLUMU"));
		iMap.put("TABLE", row, "ACIKLAMA", iMap.getString("TABLE", row + 1, "ACIKLAMA"));

		iMap.put("TABLE", row + 1, "MALNO", malNo);
		iMap.put("TABLE", row + 1, "UST_MALNO", iMap.getString("MALNO"));
		iMap.put("TABLE", row + 1, "DRM", drm);
		iMap.put("TABLE", row + 1, "AD", "");
		iMap.put("TABLE", row + 1, "TIP", tip);
		iMap.put("TABLE", row + 1, "SEVIYE", iMap.getInt("SEVIYE_EKLENEN") + 1);
		iMap.put("TABLE", row + 1, "USTISIM", iMap.getString("AD").trim());
		iMap.put("TABLE", row + 1, "ANAHTAR", iMap.getString("ANAHTAR") + "-" + malNo);
		iMap.put("TABLE", row + 1, "RISKLI_URUN_ADET", 0);
		iMap.put("TABLE", row + 1, "TESLIMAT_ZORUNLUMU", "E");
		iMap.put("TABLE", row + 1, "ACIKLAMA", "");

		oMap.put("NEWTAB", iMap.get("TABLE"));
		String selected = "";
		int maxSeviye = 0;
		if (iMap.getBoolean("ACIK"))
			selected = "A";
		else if (iMap.getBoolean("KAPALI"))
			selected = "K";
		else
			selected = "T";

		maxSeviye = maxSeviyeBul(oMap.get("NEWTAB"), selected);
		if (maxSeviye > 5)
			maxSeviye = 5;
		oMap.put("MAX_SEVIYE", maxSeviye);
		return oMap;

	}

	@GraymoundService("BNSPR_TRN1360_URUN_EKLE")
	public static GMMap urunEkle(GMMap iMap) {
		GMMap oMap = new GMMap();

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String malNo = "";
		String anahtar = "";
		String drm = "";
		int row = 0;
		String tip = "";
		String seviye = "";

		while (row < iMap.getSize("TABLE")) {
			if (iMap.getString("TABLE", row, "MALNO").equals(iMap.getString("MALNO"))) {
				tip = iMap.getString("TABLE", row, "TIP");
				seviye = iMap.getString("TABLE", row, "SEVIYE");
				break;
			}
			row++;
		}

		int index = iMap.getSize("TABLE");

		while (index > row) {
			iMap.put("TABLE", index, "DRM", iMap.getString("TABLE", index - 1, "DRM"));
			iMap.put("TABLE", index, "MALNO", iMap.getString("TABLE", index - 1, "MALNO"));
			iMap.put("TABLE", index, "UST_MALNO", iMap.getString("TABLE", index - 1, "UST_MALNO"));
			iMap.put("TABLE", index, "AD", iMap.getString("TABLE", index - 1, "AD"));
			iMap.put("TABLE", index, "TIP", iMap.getString("TABLE", index - 1, "TIP"));
			iMap.put("TABLE", index, "SEVIYE", iMap.getString("TABLE", index - 1, "SEVIYE"));
			iMap.put("TABLE", index, "USTISIM", iMap.getString("TABLE", index - 1, "USTISIM"));
			iMap.put("TABLE", index, "ANAHTAR", iMap.getString("TABLE", index - 1, "ANAHTAR"));
			iMap.put("TABLE", index, "RISKLI_URUN_ADET", iMap.getString("TABLE", index - 1, "RISKLI_URUN_ADET"));
			iMap.put("TABLE", index, "TESLIMAT_ZORUNLUMU", iMap.getString("TABLE", index - 1, "TESLIMAT_ZORUNLUMU"));
			iMap.put("TABLE", index, "ACIKLAMA", iMap.getString("TABLE", index - 1, "ACIKLAMA"));
			index--;

		}

		drm = iMap.getString("DRM");

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3160.mal_no_al}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();
			malNo = (String) stmt.getObject(1);

			int row1 = 0;

			stmt = conn.prepareCall("{? = call PKG_TRN3160.benzerden_mal_anahtar_belirle(?,?,?)}");
			stmt.registerOutParameter(++row1, Types.VARCHAR);
			stmt.setInt(++row1, Integer.parseInt(malNo));
			stmt.setBigDecimal(++row1, iMap.getBigDecimal("UST_MALNO"));
			stmt.setString(++row1, iMap.getString("ANAHTAR"));
			stmt.execute();
			anahtar = (String) stmt.getObject(1);
		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		iMap.put("TABLE", row, "MALNO", malNo);
		iMap.put("TABLE", row, "UST_MALNO", iMap.get("UST_MALNO"));
		iMap.put("TABLE", row, "DRM", drm);
		iMap.put("TABLE", row, "AD", "");
		iMap.put("TABLE", row, "TIP", tip);
		iMap.put("TABLE", row, "SEVIYE", iMap.getInt("SEVIYE_EKLENEN"));
		iMap.put("TABLE", row, "USTISIM", iMap.get("USTISIM"));
		iMap.put("TABLE", row, "ANAHTAR", anahtar);
		iMap.put("TABLE", row, "RISKLI_URUN_ADET", iMap.getInt("RISKLI_URUN_ADET"));
		iMap.put("TABLE", row, "TESLIMAT_ZORUNLUMU", iMap.getInt("TESLIMAT_ZORUNLUMU"));
		iMap.put("TABLE", row, "ACIKLAMA", iMap.getInt("ACIKLAMA"));

		oMap.put("NEWTAB", iMap.get("TABLE"));
		String selected = "";
		int maxSeviye = 0;
		if (iMap.getBoolean("ACIK"))
			selected = "A";
		else if (iMap.getBoolean("KAPALI"))
			selected = "K";
		else
			selected = "T";

		maxSeviye = maxSeviyeBul(oMap.get("NEWTAB"), selected);
		if (maxSeviye > 5)
			maxSeviye = 5;
		oMap.put("MAX_SEVIYE", maxSeviye);
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3160_GET_COMBO_MODELS")
	public static GMMap getCombo(GMMap iMap) {
		GMMap oMap = new GMMap();

		iMap.put("TABLE_NAME", "TIP");
		iMap.put("KOD", "BAYI_URUN_TIP");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

		iMap.put("TABLE_NAME", "EVET_HAYIR");
		iMap.put("KOD", "EVET_HAYIR");
		iMap.put("ADD_EMPTY_KEY", "H");
		oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));

		return oMap;
	}

	@GraymoundService("BNSPR_TRN1360_SEVIYE")
	public static GMMap getSeviye(GMMap iMap) {

		GMMap oMap = new GMMap();
		int index = 0;
		int row = 0;

		while (index < iMap.getSize("TABLE")) {
			if (iMap.getString("TABLE", index, "DRM").equals("A") && iMap.getBoolean("ACIK")) {
				if (iMap.getInt("SEVIYE") >= iMap.getInt("TABLE", index, "SEVIYE")) {
					oMap.put("TABLE", row, "DRM", "A");
					oMap.put("TABLE", row, "MALNO", iMap.getString("TABLE", index, "MALNO"));
					oMap.put("TABLE", row, "UST_MALNO", iMap.getString("TABLE", index, "UST_MALNO"));
					oMap.put("TABLE", row, "AD", iMap.getString("TABLE", index, "AD"));
					oMap.put("TABLE", row, "TIP", iMap.getString("TABLE", index, "TIP"));
					oMap.put("TABLE", row, "SEVIYE", iMap.getString("TABLE", index, "SEVIYE"));
					oMap.put("TABLE", row, "USTISIM", iMap.getString("TABLE", index, "USTISIM"));
					oMap.put("TABLE", row, "ANAHTAR", iMap.getString("TABLE", index, "ANAHTAR"));
					oMap.put("TABLE", row, "RISKLI_URUN_ADET", iMap.getString("TABLE", index, "RISKLI_URUN_ADET"));
					oMap.put("TABLE", row, "TESLIMAT_ZORUNLUMU", iMap.getString("TABLE", index, "TESLIMAT_ZORUNLUMU"));
					oMap.put("TABLE", row, "ACIKLAMA", iMap.getString("TABLE", index, "ACIKLAMA"));
					row++;
				}
			}

			else if (iMap.getString("TABLE", index, "DRM").equals("K") && iMap.getBoolean("KAPALI")) {
				if (iMap.getInt("SEVIYE") >= iMap.getInt("TABLE", index, "SEVIYE")) {
					oMap.put("TABLE", row, "DRM", "K");
					oMap.put("TABLE", row, "MALNO", iMap.getString("TABLE", index, "MALNO"));
					oMap.put("TABLE", row, "UST_MALNO", iMap.getString("TABLE", index, "UST_MALNO"));
					oMap.put("TABLE", row, "AD", iMap.getString("TABLE", index, "AD"));
					oMap.put("TABLE", row, "TIP", iMap.getString("TABLE", index, "TIP"));
					oMap.put("TABLE", row, "SEVIYE", iMap.getString("TABLE", index, "SEVIYE"));
					oMap.put("TABLE", row, "USTISIM", iMap.getString("TABLE", index, "USTISIM"));
					oMap.put("TABLE", row, "ANAHTAR", iMap.getString("TABLE", index, "ANAHTAR"));
					oMap.put("TABLE", row, "RISKLI_URUN_ADET", iMap.getString("TABLE", index, "RISKLI_URUN_ADET"));
					oMap.put("TABLE", row, "TESLIMAT_ZORUNLUMU", iMap.getString("TABLE", index, "TESLIMAT_ZORUNLUMU"));
					oMap.put("TABLE", row, "ACIKLAMA", iMap.getString("TABLE", index, "ACIKLAMA"));
					row++;
				}
			}
			else if (iMap.getBoolean("HEPSI")) {
				if (iMap.getInt("SEVIYE") >= iMap.getInt("TABLE", index, "SEVIYE")) {
					oMap.put("TABLE", row, "DRM", iMap.getString("TABLE", index, "DRM"));
					oMap.put("TABLE", row, "MALNO", iMap.getString("TABLE", index, "MALNO"));
					oMap.put("TABLE", row, "UST_MALNO", iMap.getString("TABLE", index, "UST_MALNO"));
					oMap.put("TABLE", row, "AD", iMap.getString("TABLE", index, "AD"));
					oMap.put("TABLE", row, "TIP", iMap.getString("TABLE", index, "TIP"));
					oMap.put("TABLE", row, "SEVIYE", iMap.getString("TABLE", index, "SEVIYE"));
					oMap.put("TABLE", row, "USTISIM", iMap.getString("TABLE", index, "USTISIM"));
					oMap.put("TABLE", row, "ANAHTAR", iMap.getString("TABLE", index, "ANAHTAR"));
					oMap.put("TABLE", row, "RISKLI_URUN_ADET", iMap.getString("TABLE", index, "RISKLI_URUN_ADET"));
					oMap.put("TABLE", row, "TESLIMAT_ZORUNLUMU", iMap.getString("TABLE", index, "TESLIMAT_ZORUNLUMU"));
					oMap.put("TABLE", row, "ACIKLAMA", iMap.getString("TABLE", index, "ACIKLAMA"));
					row++;
				}
			}

			index++;
		}

		oMap.put("CURRENT_TABLE", oMap.get("TABLE"));

		tabloDegistir(iMap, oMap);
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1360_TANIMLAR")
	public static GMMap getTanimlar(GMMap iMap) {

		GMMap oMap = new GMMap();
		int index = 0;
		int row = 0;
		int maxSeviye = 0;
		String selected = "";
		if (iMap.getBoolean("ACIK"))
			selected = "A";
		else if (iMap.getBoolean("KAPALI"))
			selected = "K";
		else
			selected = "T";

		if (iMap.getBoolean("ACIK")) {

			while (index < iMap.getSize("TABLE")) {
				if (iMap.getString("TABLE", index, "DRM").equals("A")) {
					oMap.put("TABLE", row, "DRM", iMap.getString("TABLE", index, "DRM"));
					oMap.put("TABLE", row, "MALNO", iMap.getString("TABLE", index, "MALNO"));
					oMap.put("TABLE", row, "USTISIM", iMap.getString("TABLE", index, "USTISIM"));
					oMap.put("TABLE", row, "UST_MALNO", iMap.getString("TABLE", index, "UST_MALNO"));
					oMap.put("TABLE", row, "AD", iMap.getString("TABLE", index, "AD"));
					oMap.put("TABLE", row, "TIP", iMap.getString("TABLE", index, "TIP"));
					oMap.put("TABLE", row, "SEVIYE", iMap.getString("TABLE", index, "SEVIYE"));
					oMap.put("TABLE", row, "ANAHTAR", iMap.getString("TABLE", index, "ANAHTAR"));
					oMap.put("TABLE", row, "RISKLI_URUN_ADET", iMap.getString("TABLE", index, "RISKLI_URUN_ADET"));
					oMap.put("TABLE", row, "TESLIMAT_ZORUNLUMU", iMap.getString("TABLE", index, "TESLIMAT_ZORUNLUMU"));
					oMap.put("TABLE", row, "ACIKLAMA", iMap.getString("TABLE", index, "ACIKLAMA"));
					row++;
				}

				index++;
			}

		}

		else if (iMap.getBoolean("KAPALI")) {
			while (index < iMap.getSize("TABLE")) {
				if (iMap.getString("TABLE", index, "DRM").equals("K")) {
					oMap.put("TABLE", row, "DRM", iMap.getString("TABLE", index, "DRM"));
					oMap.put("TABLE", row, "MALNO", iMap.getString("TABLE", index, "MALNO"));
					oMap.put("TABLE", row, "UST_MALNO", iMap.getString("TABLE", index, "UST_MALNO"));
					oMap.put("TABLE", row, "AD", iMap.getString("TABLE", index, "AD"));
					oMap.put("TABLE", row, "TIP", iMap.getString("TABLE", index, "TIP"));
					oMap.put("TABLE", row, "USTISIM", iMap.getString("TABLE", index, "USTISIM"));
					oMap.put("TABLE", row, "SEVIYE", iMap.getString("TABLE", index, "SEVIYE"));
					oMap.put("TABLE", row, "ANAHTAR", iMap.getString("TABLE", index, "ANAHTAR"));
					oMap.put("TABLE", row, "RISKLI_URUN_ADET", iMap.getString("TABLE", index, "RISKLI_URUN_ADET"));
					oMap.put("TABLE", row, "TESLIMAT_ZORUNLUMU", iMap.getString("TABLE", index, "TESLIMAT_ZORUNLUMU"));
					oMap.put("TABLE", row, "ACIKLAMA", iMap.getString("TABLE", index, "ACIKLAMA"));

					row++;
				}
				index++;
			}

		}

		else {

			oMap.put("TABLE", iMap.get("TABLE"));

		}

		int innerRow = 0;
		int outerRow = 0;

		while (innerRow < iMap.getSize("TABLE2")) {
			outerRow = 0;
			while (outerRow < iMap.getSize("TABLE")) {
				if (iMap.getString("TABLE2", innerRow, "MALNO").equals(iMap.getString("TABLE", outerRow, "MALNO"))) {
					iMap.put("TABLE", outerRow, "AD", iMap.getString("TABLE2", innerRow, "AD"));
					iMap.put("TABLE", outerRow, "TIP", iMap.getString("TABLE2", innerRow, "TIP"));
					break;
				}
				outerRow++;

			}
			innerRow++;

		}

		oMap.put("CURRENT_TABLE", iMap.get("TABLE"));
		oMap.put("OUTPUT_TABLE", oMap.get("TABLE"));

		innerRow = 0;
		outerRow = 0;
		while (innerRow < iMap.getSize("TABLE2")) {
			outerRow = 0;
			while (outerRow < oMap.getSize("OUTPUT_TABLE")) {
				if (iMap.getString("TABLE2", innerRow, "MALNO").equals(oMap.getString("OUTPUT_TABLE", outerRow, "MALNO"))) {
					oMap.put("OUTPUT_TABLE", outerRow, "AD", iMap.getString("TABLE2", innerRow, "AD"));
					oMap.put("OUTPUT_TABLE", outerRow, "TIP", iMap.getString("TABLE2", innerRow, "TIP"));
					break;
				}
				outerRow++;

			}
			innerRow++;

		}
		if (oMap.get("OUTPUT_TABLE") == null)
			maxSeviye = 0;
		else
			maxSeviye = maxSeviyeBul(oMap.get("OUTPUT_TABLE"), selected);
		if (maxSeviye > 5)
			maxSeviye = 5;
		oMap.put("MAX_SEVIYE", maxSeviye);
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3160_SAVE")
	public static Map<?, ?> saveTRN3160(GMMap iMap) {

		GMMap oMap = new GMMap();
		BirBayiMalTanimTxId birBayiMalTanimTxId = new BirBayiMalTanimTxId();
		BirBayiMalTanimTx birBayiMalTanimTx = null;
		Session session = DAOSession.getSession("BNSPRDal");

		birBayiMalTanimTx = (BirBayiMalTanimTx) session.createCriteria(BirBayiMalTanimTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

		if (birBayiMalTanimTx == null)
			birBayiMalTanimTx = new BirBayiMalTanimTx();

		try {
			oMap.put("CURRENT_TABLE", iMap.get("CURRENT_TABLE"));
			tabloDegistir(iMap, oMap);
			int tablerow = 0;
			while (tablerow < iMap.getSize("CURRENT_TABLE")) {
				birBayiMalTanimTx = new BirBayiMalTanimTx();
				birBayiMalTanimTxId.setAd(iMap.getString("CURRENT_TABLE", tablerow, "AD").trim());
				birBayiMalTanimTxId.setAnahtar(iMap.getString("CURRENT_TABLE", tablerow, "ANAHTAR"));
				birBayiMalTanimTxId.setDrm(iMap.getString("CURRENT_TABLE", tablerow, "DRM"));
				birBayiMalTanimTxId.setMalno(iMap.getBigDecimal("CURRENT_TABLE", tablerow, "MALNO"));
				birBayiMalTanimTxId.setSeviye(iMap.getBigDecimal("CURRENT_TABLE", tablerow, "SEVIYE"));
				birBayiMalTanimTxId.setTip(iMap.getString("CURRENT_TABLE", tablerow, "TIP"));
				birBayiMalTanimTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birBayiMalTanimTxId.setUstMalno(iMap.getBigDecimal("CURRENT_TABLE", tablerow, "UST_MALNO"));
				birBayiMalTanimTxId.setRiskliUrunAdet(iMap.getBigDecimal("CURRENT_TABLE", tablerow, "RISKLI_URUN_ADET"));
				birBayiMalTanimTxId.setTeslimatZorunlumu(iMap.getString("CURRENT_TABLE", tablerow, "TESLIMAT_ZORUNLUMU"));
				birBayiMalTanimTxId.setAciklama(iMap.getString("CURRENT_TABLE", tablerow, "ACIKLAMA"));

				tablerow++;
				birBayiMalTanimTx.setId(birBayiMalTanimTxId);
				session.saveOrUpdate(birBayiMalTanimTx);
				session.flush();

			}
			iMap.put("TRX_NAME", "3160");

			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN3160_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int maxSeviye = 0;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3160.rc_Bayi_Mal_Listesi}");
			stmt.registerOutParameter(1, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			int row = 0;
			int index = 0;
			int seviye = 0;
			String bosluk = "";

			while (rSet.next()) {

				bosluk = "";
				oMap.put("ACILIS_TABLOSU", index, "DRM", rSet.getObject("DRM"));
				oMap.put("ACILIS_TABLOSU", index, "MALNO", rSet.getObject("MALNO"));
				oMap.put("ACILIS_TABLOSU", index, "UST_MALNO", rSet.getObject("UST_MALNO"));
				oMap.put("ACILIS_TABLOSU", index, "AD", rSet.getString("AD"));
				oMap.put("ACILIS_TABLOSU", index, "TIP", rSet.getObject("TIP"));
				oMap.put("ACILIS_TABLOSU", index, "SEVIYE", rSet.getInt("SEVIYE"));
				oMap.put("ACILIS_TABLOSU", index, "ANAHTAR", rSet.getObject("ANAHTAR"));
				oMap.put("ACILIS_TABLOSU", index, "RISKLI_URUN_ADET", rSet.getObject("RISKLI_URUN_ADET"));
				oMap.put("ACILIS_TABLOSU", index, "TESLIMAT_ZORUNLUMU", rSet.getObject("TESLIMAT_ZORUNLUMU"));
				oMap.put("ACILIS_TABLOSU", index, "ACIKLAMA", rSet.getObject("ACIKLAMA"));
				index++;

				oMap.put("ANA_TABLO", row, "DRM", rSet.getObject("DRM"));
				oMap.put("ANA_TABLO", row, "MALNO", rSet.getObject("MALNO"));
				oMap.put("ANA_TABLO", row, "UST_MALNO", rSet.getObject("UST_MALNO"));

				seviye = rSet.getInt("SEVIYE");

				while (seviye > 0) {
					bosluk = bosluk + "   ";
					seviye--;

				}
				oMap.put("ANA_TABLO", row, "AD", bosluk + rSet.getString("AD"));
				oMap.put("ANA_TABLO", row, "TIP", rSet.getObject("TIP"));
				oMap.put("ANA_TABLO", row, "SEVIYE", rSet.getInt("SEVIYE"));
				oMap.put("ANA_TABLO", row, "ANAHTAR", rSet.getObject("ANAHTAR"));
				oMap.put("ANA_TABLO", row, "RISKLI_URUN_ADET", rSet.getObject("RISKLI_URUN_ADET"));
				oMap.put("ANA_TABLO", row, "TESLIMAT_ZORUNLUMU", rSet.getObject("TESLIMAT_ZORUNLUMU"));
				oMap.put("ANA_TABLO", row, "ACIKLAMA", rSet.getObject("ACIKLAMA"));

				int innerrow = 0;
				while (innerrow < oMap.getSize("ACILIS_TABLOSU")) {
					if (oMap.getString("ACILIS_TABLOSU", innerrow, "MALNO").equals(oMap.getString("ANA_TABLO", row, "UST_MALNO"))) {
						oMap.put("ANA_TABLO", row, "USTISIM", oMap.getString("ACILIS_TABLOSU", innerrow, "AD").trim());
					}
					innerrow++;
				}

				row++;
			}
			oMap.put("CURRENT_TABLE", oMap.get("ANA_TABLO"));
			if (oMap.getSize("CURRENT_TABLE") > 0)
				maxSeviye = maxSeviyeBul(oMap.get("CURRENT_TABLE"), "A");
			oMap.put("MAX", maxSeviye);

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);

		}

	}

	@GraymoundService("BNSPR_TRN3160_BOS_TABLOYA_EKLE")
	public static GMMap bosTabloyaEkle(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String malNo = "";
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3160.mal_no_al}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();
			malNo = (String) stmt.getObject(1);
			int size = iMap.getSize("CURRENT_TABLE");

			if (size > 0 /*&& iMap.getSize("TABLE")==0*/) {
				oMap.put("CURRENT_TABLE", iMap.get("CURRENT_TABLE"));
				oMap.put("CURRENT_TABLE", size, "DRM", "A");
				oMap.put("CURRENT_TABLE", size, "MALNO", malNo);
				oMap.put("CURRENT_TABLE", size, "UST_MALNO", "");
				oMap.put("CURRENT_TABLE", size, "AD", "");
				oMap.put("CURRENT_TABLE", size, "TIP", "");
				oMap.put("CURRENT_TABLE", size, "USTISIM", "");
				oMap.put("CURRENT_TABLE", size, "SEVIYE", 1);
				oMap.put("CURRENT_TABLE", size, "ANAHTAR", malNo);
				oMap.put("CURRENT_TABLE", size, "RISKLI_URUN_ADET", 0);
				oMap.put("CURRENT_TABLE", size, "TESLIMAT_ZORUNLUMU", "E");
				oMap.put("CURRENT_TABLE", size, "ACIKLAMA", "");
			}

			else {
				oMap.put("CURRENT_TABLE", 0, "DRM", "A");
				oMap.put("CURRENT_TABLE", 0, "MALNO", malNo);
				oMap.put("CURRENT_TABLE", 0, "UST_MALNO", "");
				oMap.put("CURRENT_TABLE", 0, "AD", "");
				oMap.put("CURRENT_TABLE", 0, "TIP", "");
				oMap.put("CURRENT_TABLE", 0, "USTISIM", "");
				oMap.put("CURRENT_TABLE", 0, "SEVIYE", 1);
				oMap.put("CURRENT_TABLE", 0, "ANAHTAR", malNo);
				oMap.put("CURRENT_TABLE", size, "RISKLI_URUN_ADET", 0);
				oMap.put("CURRENT_TABLE", size, "TESLIMAT_ZORUNLUMU", "E");
				oMap.put("CURRENT_TABLE", size, "ACIKLAMA", "");
			}

		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}
}