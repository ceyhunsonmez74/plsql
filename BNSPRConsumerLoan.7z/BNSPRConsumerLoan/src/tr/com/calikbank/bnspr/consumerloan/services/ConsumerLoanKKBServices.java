package tr.com.calikbank.bnspr.consumerloan.services;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.KkbGgad;
import tr.com.calikbank.bnspr.dao.KkbGgal;
import tr.com.calikbank.bnspr.dao.KkbGgap;
import tr.com.calikbank.bnspr.dao.KkbGgbd;
import tr.com.calikbank.bnspr.dao.KkbGgbs;
import tr.com.calikbank.bnspr.dao.KkbGgci;
import tr.com.calikbank.bnspr.dao.KkbGgcm;
import tr.com.calikbank.bnspr.dao.KkbGgcp;
import tr.com.calikbank.bnspr.dao.KkbGgcv;
import tr.com.calikbank.bnspr.dao.KkbGgfa;
import tr.com.calikbank.bnspr.dao.KkbGgfd;
import tr.com.calikbank.bnspr.dao.KkbGgmp;
import tr.com.calikbank.bnspr.dao.KkbGgns;
import tr.com.calikbank.bnspr.dao.KkbGgoe;
import tr.com.calikbank.bnspr.dao.KkbGgoh;
import tr.com.calikbank.bnspr.dao.KkbGgpd;
import tr.com.calikbank.bnspr.dao.KkbGgs1;
import tr.com.calikbank.bnspr.dao.KkbGgs2;
import tr.com.calikbank.bnspr.dao.KkbGgs5;
import tr.com.calikbank.bnspr.dao.KkbGgs8;
import tr.com.calikbank.bnspr.dao.KkbGgss;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class ConsumerLoanKKBServices {
	@GraymoundService("BNSPR_GET_KKB_GGAD")
	public static GMMap getKkbGgad(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgad.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGAD";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgad kkbGgad = (KkbGgad)iterator.next();
				oMap.put(tableName, row, "SIRA_NO",kkbGgad.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgad.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgad.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgad.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgad.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgad.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgad.getReserved2filler());
				oMap.put(tableName, row, "GGADINDEX", kkbGgad.getGgadindex());
				oMap.put(tableName, row, "ADDRESSTYPE", kkbGgad.getAddresstype());
				oMap.put(tableName, row, "ADDRESSCURRPREVINDICATOR", kkbGgad.getAddresscurrprevindicator());
				oMap.put(tableName, row, "ADDRESSFROMDATE", kkbGgad.getAddressfromdate());
				oMap.put(tableName, row, "ADDRESSTODATE", kkbGgad.getAddresstodate());
				oMap.put(tableName, row, "TIMEATADDRESS", kkbGgad.getTimeataddress());
				oMap.put(tableName, row, "ADDRESSLINE1", kkbGgad.getAddressline1());
				oMap.put(tableName, row, "ADDRESSLINE2", kkbGgad.getAddressline2());
				oMap.put(tableName, row, "ADDRESSLINE3", kkbGgad.getAddressline3());
				oMap.put(tableName, row, "ADDRESSLINE4", kkbGgad.getAddressline4());
				oMap.put(tableName, row, "POSTCODE", kkbGgad.getPostcode());
				oMap.put(tableName, row, "GGCP_INDEX", kkbGgad.getGgcpIndex());
				oMap.put(tableName, row, "GGCI_INDEX", kkbGgad.getGgciIndex());
				oMap.put(tableName, row, "GGFA_INDEX", kkbGgad.getGgfaIndex());
				oMap.put(tableName, row, "GGAP_INDEX", kkbGgad.getGgapIndex());
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_GET_KKB_GGAL")
	public static GMMap getKkbGgal(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgal.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGAL";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgal kkbGgal = (KkbGgal)iterator.next();
				
				oMap.put(tableName, row,"SIRA_NO",kkbGgal.getId().getSiraNo());
				oMap.put(tableName, row,"SEGMENTID",kkbGgal.getSegmentid());
				oMap.put(tableName, row,"SEGMENTLENGHT",kkbGgal.getSegmentlength());
				oMap.put(tableName, row,"SEGMENTSEQUENCE",kkbGgal.getSegmentsequence());
				oMap.put(tableName, row,"SEGMENTVERSIONNO",kkbGgal.getSegmentversionno());
				oMap.put(tableName, row,"RESERVEDFILLER",kkbGgal.getReservedfiller());
				oMap.put(tableName, row,"RESERVED2FILLER",kkbGgal.getReserved2filler());
				oMap.put(tableName, row,"INDEXOFFIRSTGGAPSEGMENT",kkbGgal.getIndexoffirstggapsegment());
				oMap.put(tableName, row,"RESERVED3FILLER",kkbGgal.getReserved3filler());
				oMap.put(tableName, row,"DATEADDRESSLINKCREATED",kkbGgal.getDateaddresslinkcreated());
				oMap.put(tableName, row,"NOOFADDRESSES",kkbGgal.getNoofaddresses());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_GET_KKB_GGAP")
	public static GMMap getKkbGgap(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgap.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGAP";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgap kkbGgap = (KkbGgap)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO",kkbGgap.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID",kkbGgap.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGHT",kkbGgap.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE",kkbGgap.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO",kkbGgap.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER",kkbGgap.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER",kkbGgap.getReserved2filler());
				oMap.put(tableName, row, "GGAPINDEX",kkbGgap.getGgapindex());
				oMap.put(tableName, row, "BESTMATCHTOINPUTAPPS",kkbGgap.getBestmatchtoinputapps());
				oMap.put(tableName, row, "REASONFORAPPRETURN", kkbGgap.getReasonforappreturn());
				oMap.put(tableName, row, "RESERVEDFORFUTUREUSE", kkbGgap.getReservedforfutureuse());
				oMap.put(tableName, row, "NOOFINDEXENTRIES", kkbGgap.getNoofindexentries());
				oMap.put(tableName, row, "GGCP_INDEX",kkbGgap.getGgcpIndex());
				oMap.put(tableName, row, "GGCI_INDEX",kkbGgap.getGgciIndex());
				oMap.put(tableName, row, "GGFA_INDEX",kkbGgap.getGgfaIndex());
				oMap.put(tableName, row, "GGAP_INDEX",kkbGgap.getGgapIndex());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_GET_KKB_GGBD")
	public static GMMap getKkbGgbd(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgbd.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGBD";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgbd kkbGgbd = (KkbGgbd)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgbd.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgbd.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgbd.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgbd.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgbd.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgbd.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgbd.getReserved2filler());
				oMap.put(tableName, row, "GGBDINDEX", kkbGgbd.getGgbdindex());
				oMap.put(tableName, row, "BANKNAME", kkbGgbd.getBankname());
				oMap.put(tableName, row, "BANKADDRLINE1", kkbGgbd.getBankaddrline1());
				oMap.put(tableName, row, "BANKADDRLINE2", kkbGgbd.getBankaddrline2());
				oMap.put(tableName, row, "BANKADDRLINE3", kkbGgbd.getBankaddrline3());
				oMap.put(tableName, row, "BANKADDRLINE4", kkbGgbd.getBankaddrline4());
				oMap.put(tableName, row, "BANKPOSTCODE", kkbGgbd.getBankpostcode());
				oMap.put(tableName, row, "TIMEATBANK", kkbGgbd.getTimeatbank());
				oMap.put(tableName, row, "BANKSORTCODE", kkbGgbd.getBanksortcode());
				oMap.put(tableName, row, "BANKACNO", kkbGgbd.getBankacno());
				oMap.put(tableName, row, "BANKACCOUNTTYPE", kkbGgbd.getBankaccounttype());
				oMap.put(tableName, row, "GGCP_INDEX", kkbGgbd.getGgcpIndex());
				oMap.put(tableName, row, "GGCI_INDEX", kkbGgbd.getGgciIndex());
				oMap.put(tableName, row, "GGFA_INDEX", kkbGgbd.getGgfaIndex());
				oMap.put(tableName, row, "GGAP_INDEX", kkbGgbd.getGgapIndex());

				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGBS")
	public static GMMap getKkbGgbs(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgbs.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGBS";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgbs kkbGgbs = (KkbGgbs)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgbs.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgbs.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgbs.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgbs.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgbs.getSegmentversionno());
				oMap.put(tableName, row, "SCORE", kkbGgbs.getScore());
				oMap.put(tableName, row, "SCOREINDICATOR", kkbGgbs.getScoreindicator());
				oMap.put(tableName, row, "REASONCODE1", kkbGgbs.getReasoncode1());
				oMap.put(tableName, row, "REASONCODE2", kkbGgbs.getReasoncode2());
				oMap.put(tableName, row, "REASONCODE3", kkbGgbs.getReasoncode3());
				oMap.put(tableName, row, "REASONCODE4", kkbGgbs.getReasoncode4());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgbs.getReservedfiller());
				oMap.put(tableName, row, "EXCLUSIONCODE", kkbGgbs.getExclusioncode());
				oMap.put(tableName, row, "MODELTYPE", kkbGgbs.getModeltype());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgbs.getReserved2filler());
				oMap.put(tableName, row, "DATATYPEFLAG", kkbGgbs.getDatatypeflag());
				oMap.put(tableName, row, "APPNO", kkbGgbs.getAppno());
				oMap.put(tableName, row, "FRAUDFLAG", kkbGgbs.getFraudflag());
				oMap.put(tableName, row, "RESERVED3FILLER", kkbGgbs.getReserved3filler());

				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_GET_KKB_GGCI")
	public static GMMap getKkbGgci(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgci.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGCI";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgci kkbGgci = (KkbGgci)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgci.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgci.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgci.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgci.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgci.getSegmentversionno());
				oMap.put(tableName, row, "OWNDATAFLAG", kkbGgci.getOwndataflag());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgci.getReservedfiller());
				oMap.put(tableName, row, "INDEXOFFIRSTGGAPSEGMENT", kkbGgci.getIndexoffirstggapsegment());
				oMap.put(tableName, row, "INDEXOFFIRSTGGCMSEGMENT", kkbGgci.getIndexoffirstggcmsegment());
				oMap.put(tableName, row, "NOOFGGCMSEGMENTS", kkbGgci.getNoofggcmsegments());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgci.getReserved2filler());
				oMap.put(tableName, row, "USERCOMPANYNAME", kkbGgci.getUsercompanyname());
				oMap.put(tableName, row, "USERCOMPANYTYPE", kkbGgci.getUsercompanytype());
				oMap.put(tableName, row, "CUSTOMERACCOUNTNO", kkbGgci.getCustomeraccountno());
				oMap.put(tableName, row, "USERCOMPANYBRANCH", kkbGgci.getUsercompanybranch());
				oMap.put(tableName, row, "USERCOMPANYDEPARTMENT", kkbGgci.getUsercompanydepartment());
				oMap.put(tableName, row, "NOOFACCOUNTHOLDERS", kkbGgci.getNoofaccountholders());
				oMap.put(tableName, row, "CURRENCYCODE", kkbGgci.getCurrencycode());
				oMap.put(tableName, row, "CURRENCYDIVISOR", kkbGgci.getCurrencydivisor());
				oMap.put(tableName, row, "STARTDATE", kkbGgci.getStartdate());
				oMap.put(tableName, row, "APPLICATIONREFERENCENO", kkbGgci.getApplicationreferenceno());
				oMap.put(tableName, row, "FINANCETYPE", kkbGgci.getFinancetype());
				oMap.put(tableName, row, "INTERESTRATEFLAG", kkbGgci.getInterestrateflag());
				oMap.put(tableName, row, "PURPOSEOFFINANCE", kkbGgci.getPurposeoffinance());
				oMap.put(tableName, row, "PURCHASEDITEMREFERENCE", kkbGgci.getPurchaseditemreference());
				oMap.put(tableName, row, "SECUREDCREDITFLAG", kkbGgci.getSecuredcreditflag());
				oMap.put(tableName, row, "AMOUNTOFFINANCE", kkbGgci.getAmountoffinance());
				oMap.put(tableName, row, "DEPOSITAMOUNT", kkbGgci.getDepositamount());
				oMap.put(tableName, row, "DURATIONOFAGREEMENT", kkbGgci.getDurationofagreement());
				oMap.put(tableName, row, "PAYMENTFREQUENCY", kkbGgci.getPaymentfrequency());
				oMap.put(tableName, row, "INSTALMENTAMOUNT", kkbGgci.getInstalmentamount());
				oMap.put(tableName, row, "FINALINSTALMENTAMOUNT", kkbGgci.getFinalinstalmentamount());
				oMap.put(tableName, row, "NOOFINSTALMENTS", kkbGgci.getNoofinstalments());
				oMap.put(tableName, row, "METHODOFPAYMENT", kkbGgci.getMethodofpayment());
				oMap.put(tableName, row, "CREDITLIMIT", kkbGgci.getCreditlimit());
				oMap.put(tableName, row, "REVISEDTERMSSTARTDATE", kkbGgci.getRevisedtermsstartdate());
				oMap.put(tableName, row, "REVISEDDURATIONOFFINANCE", kkbGgci.getReviseddurationoffinance());
				oMap.put(tableName, row, "REVISEDPAYMENTFREQUENCY", kkbGgci.getRevisedpaymentfrequency());
				oMap.put(tableName, row, "REVISEDINSTALMENTAMOUNT", kkbGgci.getRevisedinstalmentamount());
				oMap.put(tableName, row, "REVISEDNOOFINSTALMENTS", kkbGgci.getRevisednoofinstalments());
				oMap.put(tableName, row, "ACCOUNTPAYMENTSTATUS36FLAGS", kkbGgci.getAccountpaymentstatus36flags());
				oMap.put(tableName, row, "WORSTPAYMENTSTATUSEVER", kkbGgci.getWorstpaymentstatusever());
				oMap.put(tableName, row, "TOTALINSTALMENTLIMIT", kkbGgci.getTotalinstalmentlimit());
				oMap.put(tableName, row, "TOTALOUTSTANDINGINSTALMENTSBAL", kkbGgci.getTotaloutstandinginstalmentsbal());
				oMap.put(tableName, row, "REFERENCEKEYFORCONSUMERDISPUT", kkbGgci.getReferencekeyforconsumerdisput());
				oMap.put(tableName, row, "RESERVED3FILLER", kkbGgci.getReserved3filler());
				oMap.put(tableName, row, "TOTALOUTSTANDINGBALANCE", kkbGgci.getTotaloutstandingbalance());
				oMap.put(tableName, row, "TOTOUTBALINCREDITINDICATOR", kkbGgci.getTotoutbalincreditindicator());
				oMap.put(tableName, row, "CURRENTDBINTERESTBEARINGBAL", kkbGgci.getCurrentdbinterestbearingbal());
				oMap.put(tableName, row, "ARREARSBALANCE", kkbGgci.getArrearsbalance());
				oMap.put(tableName, row, "CUMULATIVENOOFMISSEDPYMNTS", kkbGgci.getCumulativenoofmissedpymnts());
				oMap.put(tableName, row, "ORIGINALDEFAULTBALANCE", kkbGgci.getOriginaldefaultbalance());
				oMap.put(tableName, row, "ORIGINALLITIGATIONBALANCE", kkbGgci.getOriginallitigationbalance());
				oMap.put(tableName, row, "AMOUNTOFLASTPAYMENT", kkbGgci.getAmountoflastpayment());
				oMap.put(tableName, row, "DATEOFLASTPAYMENT", kkbGgci.getDateoflastpayment());
				oMap.put(tableName, row, "CLOSEDATE", kkbGgci.getClosedate());
				oMap.put(tableName, row, "DEFAULTDATE", kkbGgci.getDefaultdate());
				oMap.put(tableName, row, "LITIGATIONDATE", kkbGgci.getLitigationdate());
				oMap.put(tableName, row, "WRITEOFFRECOVEREDDATE", kkbGgci.getWriteoffrecovereddate());
				oMap.put(tableName, row, "ACCOUNTSTATUS", kkbGgci.getAccountstatus());
				oMap.put(tableName, row, "REASONFORWRITEOFFORCLOSURE", kkbGgci.getReasonforwriteofforclosure());
				oMap.put(tableName, row, "ACCOUNTSPECIALSTATUSFLAG", kkbGgci.getAccountspecialstatusflag());
				oMap.put(tableName, row, "ACCOUNTSPECIALSTATUSSTARTDATE", kkbGgci.getAccountspecialstatusstartdate());
				oMap.put(tableName, row, "ACCOUNTSPECIALSTATUSENDDATE", kkbGgci.getAccountspecialstatusenddate());
				oMap.put(tableName, row, "RESERVED4FILLER", kkbGgci.getReserved4filler());
				oMap.put(tableName, row, "MONTHOFLASTUPDATE", kkbGgci.getMonthoflastupdate());
				oMap.put(tableName, row, "ACCOUNTNOFROM", kkbGgci.getAccountnofrom());
				oMap.put(tableName, row, "ACCOUNTNOTO", kkbGgci.getAccountnoto());
				oMap.put(tableName, row, "GGCI_INDEX", kkbGgci.getGgciIndex());


				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGCM")
	public static GMMap getKkbGgcm(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgcm.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGCM";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgcm kkbGgcm = (KkbGgcm)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgcm.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgcm.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgcm.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgcm.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgcm.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgcm.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgcm.getReserved2filler());
				oMap.put(tableName, row, "GGCMINDEX", kkbGgcm.getGgcmindex());
				oMap.put(tableName, row, "CURRENCYCODE", kkbGgcm.getCurrencycode());
				oMap.put(tableName, row, "CURRENCYDIVISOR", kkbGgcm.getCurrencydivisor());
				oMap.put(tableName, row, "AMOUNTFINANCED", kkbGgcm.getAmountfinanced());
				oMap.put(tableName, row, "DEPOSITAMOUNT", kkbGgcm.getDepositamount());
				oMap.put(tableName, row, "INSTALMENTAMOUNT", kkbGgcm.getInstalmentamount());
				oMap.put(tableName, row, "FINALINSTALMENTAMOUNT", kkbGgcm.getFinalinstalmentamount());
				oMap.put(tableName, row, "CREDITLIMIT", kkbGgcm.getCreditlimit());
				oMap.put(tableName, row, "TOTALOUTSTANDINGBALANCE", kkbGgcm.getTotaloutstandingbalance());
				oMap.put(tableName, row, "CREDITBALANCEINDICATOR", kkbGgcm.getCreditbalanceindicator());
				oMap.put(tableName, row, "DEBITINTERESTBEARINGBALANCE", kkbGgcm.getDebitinterestbearingbalance());
				oMap.put(tableName, row, "ARREARSBALANCE", kkbGgcm.getArrearsbalance());
				oMap.put(tableName, row, "ORIGINALDEFAULTBALANCE", kkbGgcm.getOriginaldefaultbalance());
				oMap.put(tableName, row, "ORIGINALLITIGATIONBALANCE", kkbGgcm.getOriginallitigationbalance());
				oMap.put(tableName, row, "LASTPAYMENTAMOUNT", kkbGgcm.getLastpaymentamount());
				oMap.put(tableName, row, "DATEOFLASTPAYMENT", kkbGgcm.getDateoflastpayment());

				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGCP")
	public static GMMap getKkbGgcp(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgcp.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGCP";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgcp kkbGgcp = (KkbGgcp)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgcp.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgcp.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgcp.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgcp.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgcp.getSegmentversionno());
				oMap.put(tableName, row, "OWNDATAFLAG", kkbGgcp.getOwndataflag());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgcp.getReservedfiller());
				oMap.put(tableName, row, "INDEXOFFIRSTGGAPSEGMENT", kkbGgcp.getIndexoffirstggapsegment());
				oMap.put(tableName, row, "INDEXOFGGFDSEGMENT", kkbGgcp.getIndexofggfdsegment());
				oMap.put(tableName, row, "NOOFGGFDSEGMENTS", kkbGgcp.getNoofggfdsegments());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgcp.getReserved2filler());
				oMap.put(tableName, row, "USERACCOUNTCODE", kkbGgcp.getUseraccountcode());
				oMap.put(tableName, row, "USERSOURCECODE", kkbGgcp.getUsersourcecode());
				oMap.put(tableName, row, "GENERATEDREFERENCENO", kkbGgcp.getGeneratedreferenceno());
				oMap.put(tableName, row, "USERCOMPANYBRANCH", kkbGgcp.getUsercompanybranch());
				oMap.put(tableName, row, "USERCOMPANYDEPARTMENT", kkbGgcp.getUsercompanydepartment());
				oMap.put(tableName, row, "USERCOMPANYNAME", kkbGgcp.getUsercompanyname());
				oMap.put(tableName, row, "USERCOMPANYTYPE", kkbGgcp.getUsercompanytype());
				oMap.put(tableName, row, "DATEOFSEARCH", kkbGgcp.getDateofsearch());
				oMap.put(tableName, row, "TIMEOFSEARCH", kkbGgcp.getTimeofsearch());
				oMap.put(tableName, row, "OPERATORSNAME", kkbGgcp.getOperatorsname());
				oMap.put(tableName, row, "OPERATORSTELEPHONENO", kkbGgcp.getOperatorstelephoneno());
				oMap.put(tableName, row, "NOOFAPPS", kkbGgcp.getNoofapps());
				oMap.put(tableName, row, "CURRENCYCODE", kkbGgcp.getCurrencycode());
				oMap.put(tableName, row, "CURRENCYDIVISOR", kkbGgcp.getCurrencydivisor());
				oMap.put(tableName, row, "APPLICATIONPROPOSALNO", kkbGgcp.getApplicationproposalno());
				oMap.put(tableName, row, "FINANCETYPE", kkbGgcp.getFinancetype());
				oMap.put(tableName, row, "INTERESTRATEFLAG", kkbGgcp.getInterestrateflag());
				oMap.put(tableName, row, "PURPOSEOFFINANCE", kkbGgcp.getPurposeoffinance());
				oMap.put(tableName, row, "PURCHASEDITEMREFERENCE", kkbGgcp.getPurchaseditemreference());
				oMap.put(tableName, row, "SECUREDCREDITFLAG", kkbGgcp.getSecuredcreditflag());
				oMap.put(tableName, row, "AMOUNTOFFINANCE", kkbGgcp.getAmountoffinance());
				oMap.put(tableName, row, "INITIALDEPOSITAMOUNT", kkbGgcp.getInitialdepositamount());
				oMap.put(tableName, row, "DURATIONOFAGREEMENT", kkbGgcp.getDurationofagreement());
				oMap.put(tableName, row, "PAYMENTFREQUENCY", kkbGgcp.getPaymentfrequency());
				oMap.put(tableName, row, "INSTALMENTAMOUNT", kkbGgcp.getInstalmentamount());
				oMap.put(tableName, row, "FINALINSTALMENTAMOUNT", kkbGgcp.getFinalinstalmentamount());
				oMap.put(tableName, row, "NOOFINSTALMENTS", kkbGgcp.getNoofinstalments());
				oMap.put(tableName, row, "METHODOFPAYMENT", kkbGgcp.getMethodofpayment());
				oMap.put(tableName, row, "REQUESTEDCREDITLIMIT", kkbGgcp.getRequestedcreditlimit());
				oMap.put(tableName, row, "GGCP_INDEX", kkbGgcp.getGgcpIndex());
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGCV")
	public static GMMap getKkbGgcv(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgcv.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGCV";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgcv kkbGgcv = (KkbGgcv)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgcv.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgcv.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgcv.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgcv.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgcv.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgcv.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgcv.getReserved2filler());
				oMap.put(tableName, row, "NOOFCONVERSIONENTRIES", kkbGgcv.getNoofconversionentries());

				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGFA")
	public static GMMap getKkbGgfa(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgfa.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGFA";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgfa kkbGgfa = (KkbGgfa)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgfa.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgfa.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgfa.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgfa.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgfa.getSegmentversionno());
				oMap.put(tableName, row, "OWNDATAFLAG", kkbGgfa.getOwndataflag());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgfa.getReservedfiller());
				oMap.put(tableName, row, "INDEXOFFIRSTGGAPSEGMENT", kkbGgfa.getIndexoffirstggapsegment());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgfa.getReserved2filler());
				oMap.put(tableName, row, "NOOFNAMES", kkbGgfa.getNoofnames());
				oMap.put(tableName, row, "SUPPLYINGCOMPANYACCTCODE", kkbGgfa.getSupplyingcompanyacctcode());
				oMap.put(tableName, row, "SUPPLYINGCOMPANYSOURCECODE", kkbGgfa.getSupplyingcompanysourcecode());
				oMap.put(tableName, row, "SUPPLYINGCOMPANYREFERNO", kkbGgfa.getSupplyingcompanyreferno());
				oMap.put(tableName, row, "SUPPLYINGCOMPANYBRANCH", kkbGgfa.getSupplyingcompanybranch());
				oMap.put(tableName, row, "SUPPLYINGCOMPANYDEPARTMENT", kkbGgfa.getSupplyingcompanydepartment());
				oMap.put(tableName, row, "SUPPLYINGCOMPANYNAME", kkbGgfa.getSupplyingcompanyname());
				oMap.put(tableName, row, "SUPPLYINGCOMPANYTYPE", kkbGgfa.getSupplyingcompanytype());
				oMap.put(tableName, row, "FRAUDCATEGORY", kkbGgfa.getFraudcategory());
				oMap.put(tableName, row, "DATESUPPLIED", kkbGgfa.getDatesupplied());
				oMap.put(tableName, row, "TIMESUPPLIED", kkbGgfa.getTimesupplied());
				oMap.put(tableName, row, "DATEC398OFLASTUPDATE", kkbGgfa.getDatec398oflastupdate());
				oMap.put(tableName, row, "TIMEOFLASTUPDATE", kkbGgfa.getTimeoflastupdate());
				oMap.put(tableName, row, "GGFA_INDEX", kkbGgfa.getGgfaIndex());

				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGFD")
	public static GMMap getKkbGgfd(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgfd.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGFD";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgfd kkbGgfd = (KkbGgfd)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgfd.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgfd.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgfd.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgfd.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgfd.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgfd.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgfd.getReserved2filler());
				oMap.put(tableName, row, "GGFDINDEX", kkbGgfd.getGgfdindex());
				oMap.put(tableName, row, "FILLER1", kkbGgfd.getFiller1());
				oMap.put(tableName, row, "FILLER2", kkbGgfd.getFiller2());
				oMap.put(tableName, row, "FILLER3", kkbGgfd.getFiller3());
				oMap.put(tableName, row, "FINALDECISIONCODE", kkbGgfd.getFinaldecisioncode());
				oMap.put(tableName, row, "DATEOFFINALDECISION", kkbGgfd.getDateoffinaldecision());
				oMap.put(tableName, row, "TIMEOFFINALDECISION", kkbGgfd.getTimeoffinaldecision());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGMP")
	public static GMMap getKkbGgmp(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgmp.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGMP";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgmp kkbGgmp = (KkbGgmp)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgmp.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgmp.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgmp.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgmp.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgmp.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgmp.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgmp.getReserved2filler());
				oMap.put(tableName, row, "GGMPINDEX", kkbGgmp.getGgmpindex());
				oMap.put(tableName, row, "EMPLOYERCURRPREVINDICATOR", kkbGgmp.getEmployercurrprevindicator());
				oMap.put(tableName, row, "EMPLOYMENTSTARTDATE", kkbGgmp.getEmploymentstartdate());
				oMap.put(tableName, row, "EMPLOYMENTENDDATE", kkbGgmp.getEmploymentenddate());
				oMap.put(tableName, row, "TIMEATEMPLOYERS", kkbGgmp.getTimeatemployers());
				oMap.put(tableName, row, "EMPLOYERSNAME", kkbGgmp.getEmployersname());
				oMap.put(tableName, row, "EMPLOYERSADDRLINE1", kkbGgmp.getEmployersaddrline1());
				oMap.put(tableName, row, "EMPLOYERSADDRLINE2", kkbGgmp.getEmployersaddrline2());
				oMap.put(tableName, row, "EMPLOYERSADDRLINE3", kkbGgmp.getEmployersaddrline3());
				oMap.put(tableName, row, "EMPLOYERSADDRLINE4", kkbGgmp.getEmployersaddrline4());
				oMap.put(tableName, row, "EMPLOYERSPOSTCODE", kkbGgmp.getEmployerspostcode());
				oMap.put(tableName, row, "EMPLOYERSTELNO", kkbGgmp.getEmployerstelno());
				oMap.put(tableName, row, "GGCP_INDEX", kkbGgmp.getGgcpIndex());
				oMap.put(tableName, row, "GGCI_INDEX", kkbGgmp.getGgciIndex());
				oMap.put(tableName, row, "GGFA_INDEX", kkbGgmp.getGgfaIndex());
				oMap.put(tableName, row, "GGAP_INDEX", kkbGgmp.getGgapIndex());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGNS")
	public static GMMap getKkbGgns(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgns.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGNS";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgns kkbGgns = (KkbGgns)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgns.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgns.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgns.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgns.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgns.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgns.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgns.getReserved2filler());
				oMap.put(tableName, row, "GGNSINDEX", kkbGgns.getGgnsindex());
				oMap.put(tableName, row, "APPACCOUNTHOLDERTYPE", kkbGgns.getAppaccountholdertype());
				oMap.put(tableName, row, "PRIMARYIDTYPE", kkbGgns.getPrimaryidtype());
				oMap.put(tableName, row, "PRIMARYIDNO", kkbGgns.getPrimaryidno());
				oMap.put(tableName, row, "SECONDIDTYPE", kkbGgns.getSecondidtype());
				oMap.put(tableName, row, "SECONDIDNO", kkbGgns.getSecondidno());
				oMap.put(tableName, row, "LANGUAGEGROUP", kkbGgns.getLanguagegroup());
				oMap.put(tableName, row, "NATIONALITY", kkbGgns.getNationality());
				oMap.put(tableName, row, "TITLE", kkbGgns.getTitle());
				oMap.put(tableName, row, "SURNAME", kkbGgns.getSurname());
				oMap.put(tableName, row, "SURNAMESUFFIX", kkbGgns.getSurnamesuffix());
				oMap.put(tableName, row, "FORENAME1", kkbGgns.getForename1());
				oMap.put(tableName, row, "FORENAME2", kkbGgns.getForename2());
				oMap.put(tableName, row, "ALIASSURNAME", kkbGgns.getAliassurname());
				oMap.put(tableName, row, "MOTHERSMAIDENSURNAME", kkbGgns.getMothersmaidensurname());
				oMap.put(tableName, row, "MOTHERSFORENAME", kkbGgns.getMothersforename());
				oMap.put(tableName, row, "FATHERSFORENAME", kkbGgns.getFathersforename());
				oMap.put(tableName, row, "SEXCODE", kkbGgns.getSexcode());
				oMap.put(tableName, row, "COMPANYNAME", kkbGgns.getCompanyname());
				oMap.put(tableName, row, "BIRTHDATE", kkbGgns.getBirthdate());
				oMap.put(tableName, row, "BIRTHPLACETOWN", kkbGgns.getBirthplacetown());
				oMap.put(tableName, row, "BIRTHPLACECOUNTYPROVINCE", kkbGgns.getBirthplacecountyprovince());
				oMap.put(tableName, row, "BIRTHPLACECODE", kkbGgns.getBirthplacecode());
				oMap.put(tableName, row, "CONSUMERCONSENTINDICATOR", kkbGgns.getConsumerconsentindicator());
				oMap.put(tableName, row, "GGCP_INDEX", kkbGgns.getGgcpIndex());
				oMap.put(tableName, row, "GGCI_INDEX", kkbGgns.getGgciIndex());
				oMap.put(tableName, row, "GGFA_INDEX", kkbGgns.getGgfaIndex());
				oMap.put(tableName, row, "GGAP_INDEX", kkbGgns.getGgapIndex());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGOE")
	public static GMMap getKkbGgoe(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgoe.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGOE";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgoe kkbGgoe = (KkbGgoe)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgoe.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgoe.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgoe.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgoe.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgoe.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgoe.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgoe.getReserved2filler());
				oMap.put(tableName, row, "FILLER", kkbGgoe.getFiller());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGOH")
	public static GMMap getKkbGgoh(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgoh.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGOH";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgoh kkbGgoh = (KkbGgoh)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgoh.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgoh.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgoh.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgoh.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgoh.getSegmentversionno());
				oMap.put(tableName, row, "DATAPACKEDFLAG", kkbGgoh.getDatapackedflag());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgoh.getReservedfiller());
				oMap.put(tableName, row, "DELIMITERCHARACTER", kkbGgoh.getDelimitercharacter());
				oMap.put(tableName, row, "DELIMITERSUBCHARACTER", kkbGgoh.getDelimitersubcharacter());
				oMap.put(tableName, row, "ERRORTYPE", kkbGgoh.getErrortype());
				oMap.put(tableName, row, "MESSAGECODE", kkbGgoh.getMessagecode());
				oMap.put(tableName, row, "REQUESTREFERENCENO", kkbGgoh.getRequestreferenceno());
				oMap.put(tableName, row, "RESPONSEREFERENCENO", kkbGgoh.getResponsereferenceno());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGPD")
	public static GMMap getKkbGgpd(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgpd.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGPD";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgpd kkbGgpd = (KkbGgpd)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgpd.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgpd.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgpd.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgpd.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgpd.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgpd.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgpd.getReserved2filler());
				oMap.put(tableName, row, "GGPDINDEX", kkbGgpd.getGgpdindex());
				oMap.put(tableName, row, "MARITALSTATUS", kkbGgpd.getMaritalstatus());
				oMap.put(tableName, row, "NOOFDEPENDANTS", kkbGgpd.getNoofdependants());
				oMap.put(tableName, row, "NOOFDEPENDANTSWITHINCOME", kkbGgpd.getNoofdependantswithincome());
				oMap.put(tableName, row, "INCOME", kkbGgpd.getIncome());
				oMap.put(tableName, row, "INCOMEFREQUENCY", kkbGgpd.getIncomefrequency());
				oMap.put(tableName, row, "INCOMENETGROSSFLAG", kkbGgpd.getIncomenetgrossflag());
				oMap.put(tableName, row, "CREDITCARDSHELD", kkbGgpd.getCreditcardsheld());
				oMap.put(tableName, row, "RESIDENTIALSTATUS", kkbGgpd.getResidentialstatus());
				oMap.put(tableName, row, "OCCUPATIONCODEDESCRIPTION", kkbGgpd.getOccupationcodedescription());
				oMap.put(tableName, row, "HOMETELEPHONENO", kkbGgpd.getHometelephoneno());
				oMap.put(tableName, row, "WORKTELEPHONENO", kkbGgpd.getWorktelephoneno());
				oMap.put(tableName, row, "CELLULARTELEPHONENO", kkbGgpd.getCellulartelephoneno());
				oMap.put(tableName, row, "GGCP_INDEX", kkbGgpd.getGgcpIndex());
				oMap.put(tableName, row, "GGCI_INDEX", kkbGgpd.getGgciIndex());
				oMap.put(tableName, row, "GGFA_INDEX", kkbGgpd.getGgfaIndex());
				oMap.put(tableName, row, "GGAP_INDEX", kkbGgpd.getGgapIndex());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_GET_KKB_GGS1")
	public static GMMap getKkbGgs1(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgs1.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGS1";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgs1 kkbGgs1 = (KkbGgs1)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgs1.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgs1.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgs1.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgs1.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgs1.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgs1.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgs1.getReserved2filler());
				oMap.put(tableName, row, "APPLICATIONREFERENCENO", kkbGgs1.getApplicationreferenceno());
				oMap.put(tableName, row, "REASONFORAPPDATARETURN", kkbGgs1.getReasonforappdatareturn());
				oMap.put(tableName, row, "CURRENCYCODE", kkbGgs1.getCurrencycode());
				oMap.put(tableName, row, "CURRENCYDIVISOR", kkbGgs1.getCurrencydivisor());
				oMap.put(tableName, row, "BASVURUDATEOFRECORD", kkbGgs1.getBasvurudateofrecord());
				oMap.put(tableName, row, "BASVURUFINANCETYPE", kkbGgs1.getBasvurufinancetype());
				oMap.put(tableName, row, "BASVURUAMNTFINANCECREDITLIMIT", kkbGgs1.getBasvuruamntfinancecreditlimit());
				oMap.put(tableName, row, "FINALDECISION", kkbGgs1.getFinaldecision());
				oMap.put(tableName, row, "APPTYPE", kkbGgs1.getApptype());
				oMap.put(tableName, row, "NOOFSEARCHESOWNOTHER_1", kkbGgs1.getNoofsearchesownother1());
				oMap.put(tableName, row, "NOOFOWNSEARCHES_1", kkbGgs1.getNoofownsearches1());
				oMap.put(tableName, row, "NOOFACCEPTEDAPPLICATIONS_1", kkbGgs1.getNoofacceptedapplications1());
				oMap.put(tableName, row, "NOOFREJECTEDAPPLICATIONS_1", kkbGgs1.getNoofrejectedapplications1());
				oMap.put(tableName, row, "NOAPPLICATIONSNODECISION_1", kkbGgs1.getNoapplicationsnodecision1());
				oMap.put(tableName, row, "NOOFSEARCHESASMAINJOINT_1", kkbGgs1.getNoofsearchesasmainjoint1());
				oMap.put(tableName, row, "NOSEARCHESNONMAINJOINT_1", kkbGgs1.getNosearchesnonmainjoint1());
				oMap.put(tableName, row, "FILLER_1", kkbGgs1.getFiller1());
				oMap.put(tableName, row, "NOOFSEARCHESOWNOTHER_2", kkbGgs1.getNoofsearchesownother2());
				oMap.put(tableName, row, "NOOFOWNSEARCHES_2", kkbGgs1.getNoofownsearches2());
				oMap.put(tableName, row, "NOOFACCEPTEDAPPLICATIONS_2", kkbGgs1.getNoofacceptedapplications2());
				oMap.put(tableName, row, "NOOFREJECTEDAPPLICATIONS_2", kkbGgs1.getNoofrejectedapplications2());
				oMap.put(tableName, row, "NOAPPLICATIONSNODECISION_2", kkbGgs1.getNoapplicationsnodecision2());
				oMap.put(tableName, row, "NOOFSEARCHESASMAINJOINT_2", kkbGgs1.getNoofsearchesasmainjoint2());
				oMap.put(tableName, row, "NOSEARCHESNONMAINJOINT_2", kkbGgs1.getNosearchesnonmainjoint2());
				oMap.put(tableName, row, "FILLER_2", kkbGgs1.getFiller2());
				oMap.put(tableName, row, "NOOFSEARCHESOWNOTHER_4", kkbGgs1.getNoofsearchesownother4());
				oMap.put(tableName, row, "NOOFOWNSEARCHES_4", kkbGgs1.getNoofownsearches4());
				oMap.put(tableName, row, "NOOFACCEPTEDAPPLICATIONS_4", kkbGgs1.getNoofacceptedapplications4());
				oMap.put(tableName, row, "NOOFREJECTEDAPPLICATIONS_4", kkbGgs1.getNoofrejectedapplications4());
				oMap.put(tableName, row, "NOAPPLICATIONSNODECISION_4", kkbGgs1.getNoapplicationsnodecision4());
				oMap.put(tableName, row, "NOOFSEARCHESASMAINJOINT_4", kkbGgs1.getNoofsearchesasmainjoint4());
				oMap.put(tableName, row, "NOSEARCHESNONMAINJOINT_4", kkbGgs1.getNosearchesnonmainjoint4());
				oMap.put(tableName, row, "FILLER_4", kkbGgs1.getFiller4());
				oMap.put(tableName, row, "NOOFSEARCHESOWNOTHER_6", kkbGgs1.getNoofsearchesownother6());
				oMap.put(tableName, row, "NOOFOWNSEARCHES_6", kkbGgs1.getNoofownsearches6());
				oMap.put(tableName, row, "NOOFACCEPTEDAPPLICATIONS_6", kkbGgs1.getNoofacceptedapplications6());
				oMap.put(tableName, row, "NOOFREJECTEDAPPLICATIONS_6", kkbGgs1.getNoofrejectedapplications6());
				oMap.put(tableName, row, "NOAPPLICATIONSNODECISION_6", kkbGgs1.getNoapplicationsnodecision6());
				oMap.put(tableName, row, "NOOFSEARCHESASMAINJOINT_6", kkbGgs1.getNoofsearchesasmainjoint6());
				oMap.put(tableName, row, "NOSEARCHESNONMAINJOINT_6", kkbGgs1.getNosearchesnonmainjoint6());
				oMap.put(tableName, row, "FILLER_6", kkbGgs1.getFiller6());
				oMap.put(tableName, row, "BASVURUCAPSSUMMARYFILLER", kkbGgs1.getBasvurucapssummaryfiller());
				oMap.put(tableName, row, "GGSS_INDEX", kkbGgs1.getGgssIndex());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_GET_KKB_GGS2")
	public static GMMap getKkbGgs2(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgs2.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGS2";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgs2 kkbGgs2 = (KkbGgs2)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgs2.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgs2.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgs2.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgs2.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgs2.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgs2.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgs2.getReserved2filler());
				oMap.put(tableName, row, "APPLICATIONREFERENCENO", kkbGgs2.getApplicationreferenceno());
				oMap.put(tableName, row, "REASONFORAPPDATARETURN", kkbGgs2.getReasonforappdatareturn());
				oMap.put(tableName, row, "CURRENCYCODE", kkbGgs2.getCurrencycode());
				oMap.put(tableName, row, "CURRENCYDIVISOR", kkbGgs2.getCurrencydivisor());
				oMap.put(tableName, row, "SPECIALACCOUNTSTATUSFLAG", kkbGgs2.getSpecialaccountstatusflag());
				oMap.put(tableName, row, "MONTHLYCOMMITMENTMAINJOINT", kkbGgs2.getMonthlycommitmentmainjoint());
				oMap.put(tableName, row, "TOTALNOOFRECORDSRETRIEVED", kkbGgs2.getTotalnoofrecordsretrieved());
				oMap.put(tableName, row, "WORSTCURRENTPAYMENTSTATUS", kkbGgs2.getWorstcurrentpaymentstatus());
				oMap.put(tableName, row, "WORSTEVERPAYMENTSTATUS", kkbGgs2.getWorsteverpaymentstatus());
				oMap.put(tableName, row, "TOTOUTSTBALALLRECSRETRIEVED", kkbGgs2.getTotoutstbalallrecsretrieved());
				oMap.put(tableName, row, "RESERVED3FILLER", kkbGgs2.getReserved3filler());
				oMap.put(tableName, row, "NOOFACCOUNTS104", kkbGgs2.getNoofaccounts104());
				oMap.put(tableName, row, "TOTBALANCEEXCLMORTGAGES105", kkbGgs2.getTotbalanceexclmortgages105());
				oMap.put(tableName, row, "TOTBALANCEONLYMORTGAGES106", kkbGgs2.getTotbalanceonlymortgages106());
				oMap.put(tableName, row, "WORSTPAYMENTSTATUS107", kkbGgs2.getWorstpaymentstatus107());
				oMap.put(tableName, row, "NOOFACCOUNTS108", kkbGgs2.getNoofaccounts108());
				oMap.put(tableName, row, "TOTBALANCEEXCLMORTGAGES109", kkbGgs2.getTotbalanceexclmortgages109());
				oMap.put(tableName, row, "TOTBALANCEONLYMORTGAGES110", kkbGgs2.getTotbalanceonlymortgages110());
				oMap.put(tableName, row, "WORSTPYMTSTATUS06MTHS111", kkbGgs2.getWorstpymtstatus06mths111());
				oMap.put(tableName, row, "WORSTPYMTSTATUS712MTHS112", kkbGgs2.getWorstpymtstatus712mths112());
				oMap.put(tableName, row, "NOOFACCOUNTS113", kkbGgs2.getNoofaccounts113());
				oMap.put(tableName, row, "TOTBALANCEEXCLMORTGAGES114", kkbGgs2.getTotbalanceexclmortgages114());
				oMap.put(tableName, row, "TOTBALANCEONLYMORTGAGES115", kkbGgs2.getTotbalanceonlymortgages115());
				oMap.put(tableName, row, "WORSTPYMTSTATUS06MTHS116", kkbGgs2.getWorstpymtstatus06mths116());
				oMap.put(tableName, row, "WORSTPYMTSTATUS712MTHS117", kkbGgs2.getWorstpymtstatus712mths117());
				oMap.put(tableName, row, "NOOFACCOUNTS118", kkbGgs2.getNoofaccounts118());
				oMap.put(tableName, row, "TOTBALANCEEXCLMORTGAGES119", kkbGgs2.getTotbalanceexclmortgages119());
				oMap.put(tableName, row, "TOTBALANCEONLYMORTGAGES120", kkbGgs2.getTotbalanceonlymortgages120());
				oMap.put(tableName, row, "WORSTPYMTSTATUS06MTHS121", kkbGgs2.getWorstpymtstatus06mths121());
				oMap.put(tableName, row, "WORSTPYMTSTATUS712MTHS122", kkbGgs2.getWorstpymtstatus712mths122());
				oMap.put(tableName, row, "NOOFACCOUNTS123", kkbGgs2.getNoofaccounts123());
				oMap.put(tableName, row, "TOTBALANCEINCLMORTGAGES124", kkbGgs2.getTotbalanceinclmortgages124());
				oMap.put(tableName, row, "MONTHLYCOMMITMENT125", kkbGgs2.getMonthlycommitment125());
				oMap.put(tableName, row, "NOOFACCOUNTS126", kkbGgs2.getNoofaccounts126());
				oMap.put(tableName, row, "TOTBALANCEINCLMORTGAGES127", kkbGgs2.getTotbalanceinclmortgages127());
				oMap.put(tableName, row, "MONTHLYCOMMITMENT128", kkbGgs2.getMonthlycommitment128());
				oMap.put(tableName, row, "NOOFACCOUNTS129", kkbGgs2.getNoofaccounts129());
				oMap.put(tableName, row, "TOTBALANCEINCLMORTGAGES130", kkbGgs2.getTotbalanceinclmortgages130());
				oMap.put(tableName, row, "MONTHLYCOMMITMENT131", kkbGgs2.getMonthlycommitment131());
				oMap.put(tableName, row, "NOOFACCOUNTS132", kkbGgs2.getNoofaccounts132());
				oMap.put(tableName, row, "TOTOUTSTBALANCE133", kkbGgs2.getTotoutstbalance133());
				oMap.put(tableName, row, "TIMEFROMMOSTRECENTDEFAULT134", kkbGgs2.getTimefrommostrecentdefault134());
				oMap.put(tableName, row, "NOOFOWNACCOUNTS135", kkbGgs2.getNoofownaccounts135());
				oMap.put(tableName, row, "NOOFACCOUNTS136", kkbGgs2.getNoofaccounts136());
				oMap.put(tableName, row, "TIMEFROMMOSTRECENTCLOSED137", kkbGgs2.getTimefrommostrecentclosed137());
				oMap.put(tableName, row, "NOOFOWNACCOUNTS138", kkbGgs2.getNoofownaccounts138());
				oMap.put(tableName, row, "NOOFACCOUNTS139", kkbGgs2.getNoofaccounts139());
				oMap.put(tableName, row, "TIMEFROMMOSTRECENTCLOSED140", kkbGgs2.getTimefrommostrecentclosed140());
				oMap.put(tableName, row, "NOOFOWNACCOUNTS141", kkbGgs2.getNoofownaccounts141());
				oMap.put(tableName, row, "NOOFACCOUNTS142", kkbGgs2.getNoofaccounts142());
				oMap.put(tableName, row, "TIMEFROMMOSTRECENTCLOSED143", kkbGgs2.getTimefrommostrecentclosed143());
				oMap.put(tableName, row, "NOOFOWNACCOUNTS144", kkbGgs2.getNoofownaccounts144());
				oMap.put(tableName, row, "NOOFACCOUNTS145", kkbGgs2.getNoofaccounts145());
				
				oMap.put(tableName, row, "TOTOUTSTBALANCE146", kkbGgs2.getTotoutstbalance146());
				oMap.put(tableName, row, "TIMEFROMMOSTRECENTDEFAULT147", kkbGgs2.getTimefrommostrecentdefault147());
				oMap.put(tableName, row, "NOOFOWNACCOUNTS148", kkbGgs2.getNoofownaccounts148());
				oMap.put(tableName, row, "NOOFACCOUNTS149", kkbGgs2.getNoofaccounts149());
				oMap.put(tableName, row, "TIMEFROMMOSTRECENTCLOSED150", kkbGgs2.getTimefrommostrecentclosed150());
				oMap.put(tableName, row, "NOOFOWNACCOUNTS151", kkbGgs2.getNoofownaccounts151());

				oMap.put(tableName, row, "NOOFACCOUNTS152", kkbGgs2.getNoofaccounts152());
				oMap.put(tableName, row, "TIMEFROMMOSTRECENTCLOSED153", kkbGgs2.getTimefrommostrecentclosed153());
				oMap.put(tableName, row, "NOOFOWNACCOUNTS154", kkbGgs2.getNoofownaccounts154());
				oMap.put(tableName, row, "NOOFACCOUNTS155", kkbGgs2.getNoofaccounts155());
				oMap.put(tableName, row, "TIMEFROMMOSTRECENTCLOSED156", kkbGgs2.getTimefrommostrecentclosed156());
				oMap.put(tableName, row, "NOOFOWNACCOUNTS157", kkbGgs2.getNoofownaccounts157());
				oMap.put(tableName, row, "NOOFACCOUNTS158", kkbGgs2.getNoofaccounts158());
				
				oMap.put(tableName, row, "WORSTPYMTSTATUSLAST12MTHS159", kkbGgs2.getWorstpymtstatuslast12mths159());
				oMap.put(tableName, row, "NOOFACCOUNTS160", kkbGgs2.getNoofaccounts160());
				oMap.put(tableName, row, "WORSTPYMTSTATUSLAST12MTHS161", kkbGgs2.getWorstpymtstatuslast12mths161());
				oMap.put(tableName, row, "KREDICAISSUMMARYFILLER162", kkbGgs2.getKredicaissummaryfiller162());

				oMap.put(tableName, row, "GGSS_INDEX", kkbGgs2.getGgssIndex());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGS5")
	public static GMMap getKkbGgs5(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgs5.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGS5";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgs5 kkbGgs5 = (KkbGgs5)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgs5.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgs5.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgs5.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgs5.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgs5.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgs5.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgs5.getReserved2filler());
				oMap.put(tableName, row, "APPLICATIONREFERENCENO", kkbGgs5.getApplicationreferenceno());
				oMap.put(tableName, row, "REASONFORAPPDATARETURN", kkbGgs5.getReasonforappdatareturn());
				oMap.put(tableName, row, "NOOFRECORDSFOUND", kkbGgs5.getNoofrecordsfound());
				oMap.put(tableName, row, "DATEOFTHEMOSTRECENT", kkbGgs5.getDateofthemostrecent());
				oMap.put(tableName, row, "UYARICATEGORYMOSTRECENT", kkbGgs5.getUyaricategorymostrecent());
				oMap.put(tableName, row, "GGSS_INDEX", kkbGgs5.getGgssIndex());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGS8")
	public static GMMap getKkbGgs8(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgs8.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGS8";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgs8 kkbGgs8 = (KkbGgs8)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgs8.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgs8.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgs8.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgs8.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgs8.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgs8.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgs8.getReserved2filler());
				oMap.put(tableName, row, "APPLICATIONREFERENCENO", kkbGgs8.getApplicationreferenceno());
				oMap.put(tableName, row, "REASONFORAPPDATARETURN", kkbGgs8.getReasonforappdatareturn());
				oMap.put(tableName, row, "NOOFRECORDSFOUND", kkbGgs8.getNoofrecordsfound());
				oMap.put(tableName, row, "DATEOFTHEMOSTRECENT", kkbGgs8.getDateofthemostrecent());
				oMap.put(tableName, row, "GGSS_INDEX", kkbGgs8.getGgssIndex());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_GET_KKB_GGSS")
	public static GMMap getKkbGgss(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(KkbGgss.class).add(Restrictions.eq("id.sorguNo", iMap.getBigDecimal("SORGU_NO"))).list();
			
			String tableName = "KKB_GGSS";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				KkbGgss kkbGgss = (KkbGgss)iterator.next();
				
				oMap.put(tableName, row, "SIRA_NO", kkbGgss.getId().getSiraNo());
				oMap.put(tableName, row, "SEGMENTID", kkbGgss.getSegmentid());
				oMap.put(tableName, row, "SEGMENTLENGTH", kkbGgss.getSegmentlength());
				oMap.put(tableName, row, "SEGMENTSEQUENCE", kkbGgss.getSegmentsequence());
				oMap.put(tableName, row, "SEGMENTVERSIONNO", kkbGgss.getSegmentversionno());
				oMap.put(tableName, row, "RESERVEDFILLER", kkbGgss.getReservedfiller());
				oMap.put(tableName, row, "RESERVED2FILLER", kkbGgss.getReserved2filler());
				oMap.put(tableName, row, "APPLICATIONREFERENCENO", kkbGgss.getApplicationreferenceno());
				oMap.put(tableName, row, "REASONFORAPPDATARETURN", kkbGgss.getReasonforappdatareturn());
				oMap.put(tableName, row, "BASVURUCAPS", kkbGgss.getBasvurucaps());
				oMap.put(tableName, row, "KREDICAIS", kkbGgss.getKredicais());
				oMap.put(tableName, row, "RESERVED3FILLER", kkbGgss.getReserved3filler());
				oMap.put(tableName, row, "RESERVED4FILLER", kkbGgss.getReserved4filler());
				oMap.put(tableName, row, "UYARIFAS", kkbGgss.getUyarifas());
				oMap.put(tableName, row, "RESERVED5FILLER", kkbGgss.getReserved5filler());
				oMap.put(tableName, row, "RESERVED6FILLER", kkbGgss.getReserved6filler());
				oMap.put(tableName, row, "ADDRESSLINKS", kkbGgss.getAddresslinks());
				oMap.put(tableName, row, "RESERVED7FILLER", kkbGgss.getReserved7filler());
				oMap.put(tableName, row, "DEFAULTLEGALACCOUNTS", kkbGgss.getDefaultlegalaccounts());
				oMap.put(tableName, row, "RESERVED8FILLER", kkbGgss.getReserved8filler());
				oMap.put(tableName, row, "GGSS_INDEX", kkbGgss.getGgssIndex());
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
