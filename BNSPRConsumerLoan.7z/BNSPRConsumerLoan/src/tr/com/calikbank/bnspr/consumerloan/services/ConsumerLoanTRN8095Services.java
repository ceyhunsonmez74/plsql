package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.biff.EmptyCell;

import org.apache.axis.encoding.Base64;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirGayriTakipTx;
import tr.com.aktifbank.bnspr.dao.BirGayriTakipTxId;
import tr.com.aktifbank.bnspr.dao.DcsGecikmeSmsDataTx;
import tr.com.aktifbank.bnspr.dao.DcsGecikmeSmsDataTxId;
import tr.com.calikbank.bnspr.consumerloan.document.type.WebCreditDocument;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.integration.ftp.AktifSFTPClient;
import tr.com.calikbank.integration.ftp.FtpClient;
import tr.com.calikbank.integration.ftp.FtpClientException;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN8095Services {
	
	private static Logger logger = Logger.getLogger(ConsumerLoanTRN8095Services.class);

	@GraymoundService("BNSPR_TRN8095_UPLOAD_EXCEL")
	public static GMMap uploadTakipMizanExcel(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		BigDecimal musteriNo;
		try {
			WorkbookSettings setting = new WorkbookSettings();
			setting.setEncoding("ISO-8859-9");

			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("EXCEL")), setting);
			Sheet dataSheet = workbook.getSheet(0);

			conn = DALUtil.getGMConnection();

			String tableName = "TAKIP_MIZAN_TABLO";
			int row = 0;
			
				stmt = conn.prepareCall("{call bnspr.PKG_TRN8095.takip_mizan_data(?,?,?,?)}");
				for (int i = 0; i < dataSheet.getRows(); i++) {

					if (dataSheet.getCell(0, i) instanceof EmptyCell) {
						continue;
					}
					else {
						String basvuru = dataSheet.getCell(0, i).getContents();

						if (basvuru != null && !basvuru.trim().isEmpty()) {
							BigDecimal basvuruNo = new BigDecimal(basvuru);						

							int index = 1;
							stmt.setBigDecimal(index++, basvuruNo);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.registerOutParameter(index++, Types.DECIMAL);
							stmt.execute();

							oMap.put(tableName, row, "BASVURU_NO", basvuruNo);
							index = 2;
							musteriNo = stmt.getBigDecimal(index++);
							if(musteriNo == null){
								throw new GMRuntimeException(0, "Dosyada hatal� kay�t bulunuyor.Ba�vuru No : " + basvuruNo.toString());
							}
							oMap.put(tableName, row, "MUSTERI_NO", musteriNo);
							oMap.put(tableName, row, "TAKIP_HESAP_NO", stmt.getString(index++));
							oMap.put(tableName, row, "ANAPARA_BAKIYE", stmt.getString(index++));
							row++;

							stmt.clearParameters();
						}
					}
				}
			return oMap;
		}
		catch (Exception e) {			
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN8095_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "TAKIP_MIZAN_TABLO";
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			
			for(int i=0;i< iMap.getSize(tableName);i++){
				
				BirGayriTakipTxId birGayriTakipTxId = new BirGayriTakipTxId();
				birGayriTakipTxId.setTxNo(trxNo);
				birGayriTakipTxId.setBasvuruNo(iMap.getBigDecimal(tableName, i, "BASVURU_NO"));
				
				BirGayriTakipTx birGayriTakipTx = new BirGayriTakipTx();
				birGayriTakipTx.setAnaparaBakiye(iMap.getBigDecimal(tableName, i, "ANAPARA_BAKIYE"));
				birGayriTakipTx.setMusteriNo(iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
				birGayriTakipTx.setTakipHesapNo(iMap.getBigDecimal(tableName, i, "TAKIP_HESAP_NO"));
				
				birGayriTakipTx.setId(birGayriTakipTxId);
				
				session.save(birGayriTakipTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "8095");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
