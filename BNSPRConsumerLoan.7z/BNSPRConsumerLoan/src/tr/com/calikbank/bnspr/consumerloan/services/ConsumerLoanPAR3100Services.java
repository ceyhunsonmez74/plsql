package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.httpclient.util.DateUtil;
import org.apache.commons.lang.time.DateUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirAzamiFaizOranPr;
import tr.com.aktifbank.bnspr.dao.BirAzamiFaizOranPrId;
import tr.com.aktifbank.bnspr.dao.BirAzamiFaizOranPrLog;
import tr.com.aktifbank.bnspr.dao.BirAzamiFaizOranPrLogId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanPAR3100Services {

	public enum IslemTipi {
		YENI("Y", "Yeni Kay�t"), GUNCELLEME("G", "G�ncelleme"), SILME("S", "Silme"), DEGISIKLIK_YOK("D", "De�i�iklik Yok");

		private String kod;
		private String aciklama;

		public String getKod() {
			return kod;
		}

		public String getAciklama() {
			return aciklama;
		}

		public static IslemTipi tipBul(String kod) {
			if ("Y".equalsIgnoreCase(kod)) {
				return YENI;
			}
			else if ("G".equalsIgnoreCase(kod)) {
				return GUNCELLEME;
			}
			else if ("S".equalsIgnoreCase(kod)) {
				return SILME;
			}

			return null;
		}

		private IslemTipi(String kod, String aciklama) {
			this.kod = kod;
			this.aciklama = aciklama;
		}

	}

	@GraymoundService("BNSPR_PAR3100_INITIALIZE_PARAMETERS")
	public static GMMap initializeParameters(GMMap iMap) {

		GMMap oMap = new GMMap();

		findGnlDkGrupKodList(oMap);
		findBirKrdTurKodList(oMap);

		return oMap;
	}

	public static GMMap findGnlDkGrupKodList(GMMap iMap) {

		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		String query = "select distinct kod from gnl_dk_grup_kod_pr";
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement(query);
			rSet = stmt.executeQuery();
			int i = 0;
			iMap.put("DK_GRUP_KODU", i, "VALUE", "");
			iMap.put("DK_GRUP_KODU", i, "NAME", "");
			i++;
			while (rSet.next()) {
				iMap.put("DK_GRUP_KODU", i, "VALUE", rSet.getLong("kod"));
				iMap.put("DK_GRUP_KODU", i, "NAME", rSet.getLong("kod"));
				i++;
			}
			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static GMMap findBirKrdTurKodList(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		String query = "select distinct kod from bir_krd_tur";
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement(query);
			rSet = stmt.executeQuery();
			int i = 0;
			iMap.put("KREDI_TURU", i, "VALUE", "");
			iMap.put("KREDI_TURU", i, "NAME", "");
			i++;
			while (rSet.next()) {
				iMap.put("KREDI_TURU", i, "VALUE", rSet.getLong("kod"));
				iMap.put("KREDI_TURU", i, "NAME", rSet.getLong("kod"));
				i++;
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_PAR3100_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		List<BirAzamiFaizOranPr> liste = session.createCriteria(BirAzamiFaizOranPr.class).list();
		
		String tableName = "FAIZ_ORAN_TABLO";
		
		for (int row=0; row < liste.size(); row++)
		{
			oMap.put(tableName, row, "DK_GRUP_KODU", liste.get(row).getId().getDkGrupKodu());
			oMap.put(tableName, row, "KREDI_TURU", liste.get(row).getId().getKrediTuru());
			oMap.put(tableName, row, "VADE_0_12_AY", liste.get(row).getVade012Ay());
			oMap.put(tableName, row, "VADE_12_24_AY", liste.get(row).getVade1224Ay());
			oMap.put(tableName, row, "VADE_24_AY_UZERI", liste.get(row).getVade24AyUzeri());
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR3100_TARIHCE")
	public static GMMap tarihce(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		Session session = DAOSession.getSession("BNSPRDal");
		
		List<BirAzamiFaizOranPrLog> liste = session.createCriteria(BirAzamiFaizOranPrLog.class).addOrder(Order.desc("recDate")).list();
		
		String tableName = "FAIZ_ORAN_TABLO";
		
		for (int row=0; row < liste.size(); row++)
		{
			oMap.put(tableName, row, "DK_GRUP_KODU", liste.get(row).getId().getDkGrupKodu());
			oMap.put(tableName, row, "KREDI_TURU", liste.get(row).getId().getKrediTuru());
			oMap.put(tableName, row, "VADE_0_12_AY", liste.get(row).getVade012Ay());
			oMap.put(tableName, row, "VADE_12_24_AY", liste.get(row).getVade1224Ay());
			oMap.put(tableName, row, "VADE_24_AY_UZERI", liste.get(row).getVade24AyUzeri());
			oMap.put(tableName, row, "REC_OWNER", liste.get(row).getRecOwner());
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
			oMap.put(tableName, row, "REC_DATE", dateFormat.format(liste.get(row).getRecDate()));
		}
		return oMap;
	}

	@GraymoundService("BNSPR_PAR3100_DELETE")
	public static GMMap delete(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap rowMap = iMap.getMap("ROW");

		Session session = DAOSession.getSession("BNSPRDal");

		// Yeni kay�tsa i�lem yap�lmamal�
		if (!"Y".equalsIgnoreCase(rowMap.getString("ISLEM_TIPI"))) {

			BirAzamiFaizOranPr oran = (BirAzamiFaizOranPr) session.createCriteria(BirAzamiFaizOranPr.class).add(Restrictions.eq("id.dkGrupKodu", rowMap.getBigDecimal("DK_GRUP_KODU"))).add(Restrictions.eq("id.krediTuru", rowMap.getBigDecimal("KREDI_TURU"))).uniqueResult();

			session.delete(oran);

			BirAzamiFaizOranPrLog log = new BirAzamiFaizOranPrLog();
			BirAzamiFaizOranPrLogId id = new BirAzamiFaizOranPrLogId();
			id.setDkGrupKodu(rowMap.getBigDecimal("DK_GRUP_KODU"));
			id.setLogId((BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME", "BIR_AZAMI_FAIZ_ORAN_PR_LOG")).get("ID"));
			id.setKrediTuru(rowMap.getBigDecimal("KREDI_TURU"));

			log.setId(id);
			log.setIslemTipi(IslemTipi.SILME.getKod());
			log.setVade012Ay(rowMap.getBigDecimal("VADE_0_12_AY"));
			log.setVade1224Ay(rowMap.getBigDecimal("VADE_12_24_AY"));
			log.setVade24AyUzeri(rowMap.getBigDecimal("VADE_24_AY_UZERI"));
			log.setRecOwner(ADCSession.getString("USER_NAME"));
			log.setRecDate(new Date());

			session.save(log);
			session.flush();
		}
		return oMap;
	}

	@GraymoundService("BNSPR_PAR3100_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();

		Session session = DAOSession.getSession("BNSPRDal");

		String tableName = "FAIZ_ORAN_TABLO";

		for (int row = 0; row < iMap.getSize(tableName); row++) {
			if ("Y".equalsIgnoreCase(iMap.getString(tableName, row, "ISLEM_TIPI"))) {
				BirAzamiFaizOranPr oran = new BirAzamiFaizOranPr();

				BirAzamiFaizOranPrId id = new BirAzamiFaizOranPrId();
				id.setDkGrupKodu(iMap.getBigDecimal(tableName, row, "DK_GRUP_KODU"));
				id.setKrediTuru(iMap.getBigDecimal(tableName, row, "KREDI_TURU"));

				oran.setId(id);
				oran.setVade012Ay(iMap.getBigDecimal(tableName, row, "VADE_0_12_AY"));
				oran.setVade1224Ay(iMap.getBigDecimal(tableName, row, "VADE_12_24_AY"));
				oran.setVade24AyUzeri(iMap.getBigDecimal(tableName, row, "VADE_24_AY_UZERI"));

				session.save(oran);

				BirAzamiFaizOranPrLog log = new BirAzamiFaizOranPrLog();
				BirAzamiFaizOranPrLogId logId = new BirAzamiFaizOranPrLogId();
				logId.setDkGrupKodu(iMap.getBigDecimal(tableName, row, "DK_GRUP_KODU"));
				logId.setLogId((BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME", "BIR_AZAMI_FAIZ_ORAN_PR_LOG")).get("ID"));
				logId.setKrediTuru(iMap.getBigDecimal(tableName, row, "KREDI_TURU"));

				log.setId(logId);
				log.setIslemTipi(IslemTipi.YENI.getKod());
				log.setVade012Ay(iMap.getBigDecimal(tableName, row, "VADE_0_12_AY"));
				log.setVade1224Ay(iMap.getBigDecimal(tableName, row, "VADE_12_24_AY"));
				log.setVade24AyUzeri(iMap.getBigDecimal(tableName, row, "VADE_24_AY_UZERI"));
				log.setRecOwner(ADCSession.getString("USER_NAME"));
				log.setRecDate(new Date());

				session.save(log);
				session.flush();
			}
			else {
				BirAzamiFaizOranPr oran = (BirAzamiFaizOranPr) session.createCriteria(BirAzamiFaizOranPr.class).add(Restrictions.eq("id.dkGrupKodu", iMap.getBigDecimal(tableName, row, "DK_GRUP_KODU"))).add(Restrictions.eq("id.krediTuru", iMap.getBigDecimal(tableName, row, "KREDI_TURU"))).uniqueResult();

				if (oran != null && "G".equalsIgnoreCase(iMap.getString(tableName, row, "ISLEM_TIPI"))) {
					
					oran.setVade012Ay(iMap.getBigDecimal(tableName, row, "VADE_0_12_AY"));
					oran.setVade1224Ay(iMap.getBigDecimal(tableName, row, "VADE_12_24_AY"));
					oran.setVade24AyUzeri(iMap.getBigDecimal(tableName, row, "VADE_24_AY_UZERI"));
					
					session.save(oran);

					BirAzamiFaizOranPrLog log = new BirAzamiFaizOranPrLog();
					BirAzamiFaizOranPrLogId id = new BirAzamiFaizOranPrLogId();
					id.setDkGrupKodu(iMap.getBigDecimal(tableName, row, "DK_GRUP_KODU"));
					id.setLogId((BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", new GMMap().put("TABLE_NAME", "BIR_AZAMI_FAIZ_ORAN_PR_LOG")).get("ID"));
					id.setKrediTuru(iMap.getBigDecimal(tableName, row, "KREDI_TURU"));

					log.setId(id);
					log.setIslemTipi(IslemTipi.GUNCELLEME.getKod());
					log.setVade012Ay(iMap.getBigDecimal(tableName, row, "VADE_0_12_AY"));
					log.setVade1224Ay(iMap.getBigDecimal(tableName, row, "VADE_12_24_AY"));
					log.setVade24AyUzeri(iMap.getBigDecimal(tableName, row, "VADE_24_AY_UZERI"));
					log.setRecOwner(ADCSession.getString("USER_NAME"));
					log.setRecDate(new Date());

					session.save(log);
					session.flush();
				}
			}
		}

		return oMap;
	}

}
