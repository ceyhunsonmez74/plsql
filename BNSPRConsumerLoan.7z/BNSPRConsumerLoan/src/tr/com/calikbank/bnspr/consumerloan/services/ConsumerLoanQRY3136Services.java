package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class ConsumerLoanQRY3136Services {

	@GraymoundService("BNSPR_QRY3136_GET_RECORD_FILL_LIST")
	public static GMMap getRecordQRY3136FillList(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;

		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			StringBuffer query = new StringBuffer();
			query.append("SELECT B.BASVURU_NO, B.MUSTERI_NO, B.ADI_SOYADI, PKG_BIREYSEL.KRDTUR(B.KREDI_TUR) KREDI_TUR_ADI,");
			query.append("    PKG_BIREYSEL.KRDALTTUR(B.KREDI_TUR, B.KREDI_ALT_TUR) KREDI_TIP_ADI,");
			query.append("    PKG_BIREYSEL.KRDALTTUR2(B.KREDI_TUR,B.KREDI_ALT_TUR,B.KREDI_ALT_TUR2) ALT_KREDI_TIP_ADI,");
			query.append("    PKG_GENEL_PR.KANAL_ADI(B.KANAL_KODU) KANAL_ADI,");
			query.append("    B.TUTAR, B.VADE, B.BAZ_FAIZ, T.TX_NO, B.DOVIZ_KODU, B.DURUM_KODU ");
			query.append("FROM BIR_KREDI_BASVURU B, BIR_KREDI_BASVURU_TX T ");
			query.append("WHERE B.BASVURU_NO BETWEEN  NVL(?,B.BASVURU_NO) AND NVL(?,B.BASVURU_NO) ");
			query.append("   AND B.MUSTERI_NO 		= NVL(?, B.MUSTERI_NO) ");
			query.append("   AND B.KREDI_TUR  		= NVL(?, B.KREDI_TUR) ");
			query.append("   AND B.KREDI_ALT_TUR  	= NVL(?, B.KREDI_ALT_TUR) ");
			query.append("   AND B.KREDI_ALT_TUR2 	= NVL(?, B.KREDI_ALT_TUR2) ");
			query.append("   AND B.KANAL_KODU     	= NVL(?, B.KANAL_KODU) ");
			query.append("   AND B.DOVIZ_KODU     	= NVL(?, B.DOVIZ_KODU) ");
			query.append("   AND B.DURUM_KODU       = NVL(?,B.DURUM_KODU) "); 
			query.append("   AND T.BASVURU_NO     	= B.BASVURU_NO ");
			query.append(" ORDER BY 1 ");

			stmt = conn.prepareStatement(query.toString());

			int i = 1;

			stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_BASVURU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_BASVURU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TURU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KREDI_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ALT_KREDI_TIPI"));
			stmt.setString(i++, iMap.getString("KANAL_KODU"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));

			rSet = stmt.executeQuery();
			String tableName = "RESULTS";
			int row = 0;
			while (rSet.next()) {
				int j = 1;

				oMap.put(tableName, row, "BASVURU_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "UNVAN", rSet.getString(j++));
				
				oMap.put(tableName, row, "KREDI_TUR_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KREDI_TIP_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "ALT_KREDI_TIP_ADI", rSet.getString(j++));
				oMap.put(tableName, row, "KANAL_ADI", rSet.getString(j++));
				
				oMap.put(tableName, row, "TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "VADE", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "BAZ_FAIZ", rSet.getBigDecimal(j++));	
				
				oMap.put(tableName, row, "TRX_NO", rSet.getBigDecimal(j++));	
				oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString(j++));	
				
				oMap.put(tableName, row, "DURUM", rSet.getString(j++));
				if(iMap.getString(tableName, row, "DURUM").equals("KULLANDIRIM"))oMap.put(tableName, row, "KULLANDIRIM_TARIHI",DALUtil.callOneParameterFunction("{? = call Pkg_bireysel.KullandirimTarihi(?)}", Types.DATE, iMap.getBigDecimal(tableName, row, "BASVURU_NO").toString()));
				else oMap.put(tableName, row, "KULLANDIRIM_TARIHI",(String)null);
				
				row++;
			}

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3136_GET_COMBOBOX_INITIAL_VALUES")
	public static GMMap getComboboxInitialValues(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		getDovizCinsi(oMap);
		getKanalKodu(oMap);
		return oMap;
	}
	
	public static void getDovizCinsi(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			
			BigDecimal minBasvuruNo = iMap.getBigDecimal("MIN_BASVURU_NO");
			BigDecimal maxBasvuruNo = iMap.getBigDecimal("MAX_BASVURU_NO");
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			BigDecimal krediTur = iMap.getBigDecimal("KREDI_TUR");
			BigDecimal krediTip = iMap.getBigDecimal("KREDI_TIP");
			BigDecimal altKrediTip = iMap.getBigDecimal("ALT_KREDI_TIP");
			BigDecimal kanalKodu = iMap.getBigDecimal("KANAL_KODU");
			String durumKodu = iMap.getString("DURUM_KODU");			
			
			StringBuffer query = new StringBuffer();
			query.append("SELECT DISTINCT B.DOVIZ_KODU, PKG_GENEL_PR.DOVIZ_ADI(B.DOVIZ_KODU) ACIKLAMA ");			
			query.append("FROM BIR_KREDI_BASVURU B ");
			query.append(" WHERE B.BASVURU_NO BETWEEN  NVL(?,B.BASVURU_NO) AND NVL(?,B.BASVURU_NO) ");
			query.append("AND B.MUSTERI_NO = NVL(?, B.MUSTERI_NO) ");
			query.append("AND B.KREDI_TUR  = NVL(?, B.KREDI_TUR) ");
			query.append("AND B.KREDI_ALT_TUR  = NVL(?, B.KREDI_ALT_TUR) ");
			query.append("AND B.KREDI_ALT_TUR2 = NVL(?, B.KREDI_ALT_TUR2)");
			query.append("AND B.KANAL_KODU     = NVL(?, B.KANAL_KODU) ");
			query.append("AND B.DURUM_KODU       = NVL(?,B.DURUM_KODU) "); 
			query.append("ORDER BY 1 ");
			
			stmt = conn.prepareCall(query.toString());
			
			stmt.setBigDecimal(1, minBasvuruNo);
			stmt.setBigDecimal(2, maxBasvuruNo);
			stmt.setBigDecimal(3, musteriNo);
			stmt.setBigDecimal(4, krediTur);
			stmt.setBigDecimal(5, krediTip);
			stmt.setBigDecimal(6, altKrediTip);
			stmt.setBigDecimal(7, kanalKodu);
			stmt.setString(8, durumKodu);
			
			rSet = stmt.executeQuery();
			
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("LIST_NAME", "DOVIZ_KODU");
			DALUtil.fillComboBox(iMap, rSet);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static void getKanalKodu(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;

		try {

			conn = DALUtil.getGMConnection();
			
			BigDecimal minBasvuruNo = iMap.getBigDecimal("MIN_BASVURU_NO");
			BigDecimal maxBasvuruNo = iMap.getBigDecimal("MAX_BASVURU_NO");
			BigDecimal musteriNo = iMap.getBigDecimal("MUSTERI_NO");
			BigDecimal krediTur = iMap.getBigDecimal("KREDI_TUR");
			BigDecimal krediTip = iMap.getBigDecimal("KREDI_TIP");
			BigDecimal altKrediTip = iMap.getBigDecimal("ALT_KREDI_TIP");
			String dovizKodu = iMap.getString("DOVIZ_KODU");
			String durumKodu = iMap.getString("DURUM_KODU");
			
			
			StringBuffer query = new StringBuffer();
			query.append("SELECT DISTINCT B.KANAL_KODU, PKG_GENEL_PR.KANAL_ADI(B.KANAL_KODU) ACIKLAMA ");			
			query.append("FROM BIR_KREDI_BASVURU B ");
			query.append(" WHERE B.BASVURU_NO BETWEEN  NVL(?,B.BASVURU_NO) AND NVL(?,B.BASVURU_NO) ");
			query.append("AND B.MUSTERI_NO = NVL(?, B.MUSTERI_NO) ");
			query.append("AND B.KREDI_TUR  = NVL(?, B.KREDI_TUR) ");
			query.append("AND B.KREDI_ALT_TUR  = NVL(?, B.KREDI_ALT_TUR) ");
			query.append("AND B.KREDI_ALT_TUR2 = NVL(?, B.KREDI_ALT_TUR2)");
			query.append("AND B.DOVIZ_KODU     = NVL(?, B.DOVIZ_KODU) ");
			query.append("AND B.DURUM_KODU       = NVL(?,B.DURUM_KODU) ");
			query.append("ORDER BY 1 ");
			
			stmt = conn.prepareCall(query.toString());
			
			stmt.setBigDecimal(1, minBasvuruNo);
			stmt.setBigDecimal(2, maxBasvuruNo);
			stmt.setBigDecimal(3, musteriNo);
			stmt.setBigDecimal(4, krediTur);
			stmt.setBigDecimal(5, krediTip);
			stmt.setBigDecimal(6, altKrediTip);
			stmt.setString(7, dovizKodu);
			stmt.setString(8, durumKodu);
			rSet = stmt.executeQuery();
			
			iMap.put("ADD_EMPTY_KEY", "E");
			iMap.put("LIST_NAME", "KANAL_KODU");
			DALUtil.fillComboBox(iMap, rSet);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
