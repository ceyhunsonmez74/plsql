package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirSaticiAktiflikKayitTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiAktiflikTx;
import tr.com.aktifbank.bnspr.dao.BirSaticiAktiflikTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3269Services {

    @GraymoundService("BNSPR_TRN3269_IMPORT_EXCEL")
    public static GMMap excelToTable(GMMap iMap) {
        GMMap oMap = new GMMap();
        String hataSonuc = null;
        try {
            byte[] inputFile = (byte[]) iMap.get("FILE");
            if (inputFile == null) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Dosya se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Workbook workbook;
            WorkbookSettings ws = new WorkbookSettings();

            //ws.setCharacterSet(cs);
            ws.setEncoding("ISO-8859-9");
            ws.setExcelDisplayLanguage("TR");
            ws.setExcelRegionalSettings("TR");
            ws.setLocale(new Locale("tr", "TR"));
            try {
                workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
                if(workbook.getSheet(0).getColumns() < 5){
                    throw new GMRuntimeException(0, "Yanl�� Kolon Say�s�.");
                }
            } catch (Exception e) {
                e.printStackTrace();
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Sheet sheet = workbook.getSheet(0);
            int hataliSatirSayisi = 0;
            for (int j = 0; j + 1 < sheet.getRows(); j++) {
                for (int i = 0; i < sheet.getColumns(); i++) {
                    oMap.put("TABLE", j, "COLUMN_" + (i), sheet.getCell(i, j + 1).getContents());
                }
                String func = "{? = call pkg_trn3269.kayit_hatalimi(?,?,?,?,?)}";
                Object[] inputValues = new Object[10];
                int k = 0;
                inputValues[k++] = BnsprType.STRING;
                inputValues[k++] = oMap.getString("TABLE", j, "COLUMN_0");
                inputValues[k++] = BnsprType.STRING;
                inputValues[k++] = oMap.getString("TABLE", j, "COLUMN_1");
                inputValues[k++] = BnsprType.STRING;
                inputValues[k++] = oMap.getString("TABLE", j, "COLUMN_2");
                inputValues[k++] = BnsprType.STRING;
                inputValues[k++] = oMap.getString("TABLE", j, "COLUMN_3");
                inputValues[k++] = BnsprType.STRING;
                inputValues[k++] = oMap.getString("TABLE", j, "COLUMN_4");
                hataSonuc = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);

                if (hataSonuc != null && hataSonuc.equals("E")) {
                    oMap.put("TABLE", j, "HATALI_MI", true);
                    hataliSatirSayisi++;
                } else {
                    oMap.put("TABLE", j, "HATALI_MI", false);
                    oMap.put("TABLE", j, "SATICI_ADI", LovHelper.diLov(oMap.getString("TABLE", j, "COLUMN_0"), "3269/LOV_SATICI_KODU", "SATICI_ADI"));
                }

            }
            oMap.put("SATIR_SAYISI", oMap.getSize("TABLE"));
            oMap.put("HATALI_SATIR_SAYISI", hataliSatirSayisi);
            oMap.put("KAYDEDILECEK_SATIR_SAYISI", nvl(oMap.getSize("TABLE"), 0) - hataliSatirSayisi);
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}

    }

    @GraymoundService("BNSPR_TRN3269_SAVE")
    public static Map<?, ?> saveTRN3269(GMMap iMap) {
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            @SuppressWarnings("unchecked")
            List<BirSaticiAktiflikTx> aktiflikList = (List<BirSaticiAktiflikTx>) session.createCriteria(BirSaticiAktiflikTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

            for (BirSaticiAktiflikTx kayit : aktiflikList) {
                session.delete(kayit);
                session.flush();
            }
            for (int i = 0; i < iMap.getSize("TABLE"); i++) {
                if (!iMap.getBoolean("TABLE", i, "HATALI_MI")) {
                    BirSaticiAktiflikTx birSaticiAktiflikTx = new BirSaticiAktiflikTx();
                    BirSaticiAktiflikTxId Id = new BirSaticiAktiflikTxId();
                    Id.setAktiflikBasvuruKod(iMap.getString("TABLE", i, "COLUMN_1"));
                    Id.setAktiflikKullandirimKod(iMap.getString("TABLE", i, "COLUMN_2"));
                    Id.setPolitikaKod(iMap.getString("TABLE", i, "COLUMN_4"));
                    Id.setRiskKod(iMap.getString("TABLE", i, "COLUMN_3"));
                    Id.setSaticiKod(iMap.getBigDecimal("TABLE", i, "COLUMN_0"));
                    Id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    birSaticiAktiflikTx.setId(Id);
                    session.save(birSaticiAktiflikTx);
                }
            }
            session.flush();

            BirSaticiAktiflikKayitTx birSaticiAktiflikKayitTx =
                (BirSaticiAktiflikKayitTx) session.createCriteria(BirSaticiAktiflikKayitTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

            if (birSaticiAktiflikKayitTx == null) {
                birSaticiAktiflikKayitTx = new BirSaticiAktiflikKayitTx();
            }

            birSaticiAktiflikKayitTx.setDosyaAdi(iMap.getString("FILE_NAME"));
            birSaticiAktiflikKayitTx.setHataliSatir(iMap.getBigDecimal("HATALI_SATIR_SAYISI"));
            birSaticiAktiflikKayitTx.setKaydedilecekSatir(iMap.getBigDecimal("KAYDEDILECEK_SATIR_SAYISI"));
            birSaticiAktiflikKayitTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            birSaticiAktiflikKayitTx.setYuklenenSatir(iMap.getBigDecimal("SATIR_SAYISI"));

            session.saveOrUpdate(birSaticiAktiflikKayitTx);
            session.flush();

            iMap.put("TRX_NAME", "3269");

            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}

    }

    @GraymoundService("BNSPR_TRN3269_GET_GUNCEL_LISTE")
    public static GMMap getGuncelListe(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            String func = "{? = call pkg_trn3269.get_guncel_liste()}";
            oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", new Object[0]));
            for(int i = 0; i<oMap.getSize("RESULTS"); i++){
                oMap.put("RESULTS", i, "SATICI_AD",LovHelper.diLov(oMap.getString("RESULTS", i, "SATICI_KOD"), "3269/LOV_SATICI_KODU", "SATICI_ADI"));
            }
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}

    }

    @GraymoundService("BNSPR_TRN3269_GET_TARIHCE")
    public static GMMap getTarihce(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            String func = "{? = call pkg_trn3269.get_tarihce(?,?,?)}";
            Object[] inputValues = new Object[6];
            int i = 0;
            inputValues[i++] = BnsprType.NUMBER;
            inputValues[i++] = iMap.getBigDecimal("SATICI_KOD");
            inputValues[i++] = BnsprType.DATE;
            inputValues[i++] = iMap.getDate("BAS_TARIH");
            inputValues[i++] = BnsprType.DATE;
            inputValues[i++] = iMap.getDate("BIT_TARIH");
            oMap.putAll(DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputValues));
            
            for(i = 0; i<oMap.getSize("RESULTS"); i++){
                oMap.put("RESULTS", i, "SATICI_AD",LovHelper.diLov(oMap.getString("RESULTS", i, "SATICI_KOD"), "3269/LOV_SATICI_KODU", "SATICI_ADI"));
            }
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {}

    }

    public static <T> T nvl(T a, T b) {
        if (a instanceof String) return StringUtils.isBlank((String) a) ? b : a;
        return a == null ? b : a;
    }
}
