package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBelgeMatrisPrTx;
import tr.com.calikbank.bnspr.dao.BirBelgeMatrisPrTxId;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3119Services {
	@GraymoundService("BNSPR_TRN3119_GET_DOKUMAN_LIST")
	public static GMMap getDokumanList(GMMap iMap) {	
		try {
			if(!checkFields(iMap)){
				GMMap myMap = new GMMap();
				myMap.put("HATA_NO", new BigDecimal(934));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", myMap);
			}			
			GMMap oMap = new GMMap();
			String func = "{? = call PKG_TRN3119.get_dokuman_list(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			Object[] inputValues = {
				BnsprType.NUMBER, iMap.getBigDecimal("KAMPANYA_KOD"),
				BnsprType.NUMBER, iMap.getBigDecimal("KRD_TUR_KOD"),
				BnsprType.NUMBER, iMap.getBigDecimal("KRD_TUR_ALT_KOD"),
				BnsprType.NUMBER, iMap.getBigDecimal("KRD_TUR_ALT_KOD2"),
				BnsprType.STRING, iMap.getString("KANAL_KODU"),
				BnsprType.STRING, iMap.getString("TEMINAT"),
				BnsprType.STRING, iMap.getString("MESLEK"),
				BnsprType.STRING, iMap.getString("CALISMA_SEKLI"),
				BnsprType.STRING, iMap.getString("KIMLIK_TIPI"),
				BnsprType.STRING, iMap.getString("KEFIL_TIPI"),
				BnsprType.STRING, iMap.getString("GELIR_BILGISI_KOD"),
				BnsprType.STRING, iMap.getString("BHS_VAR_YOK"),
				BnsprType.STRING, iMap.getString("BAYI_KEFALETI"),
				BnsprType.NUMBER, iMap.getBigDecimal("SATICI_KODU"),
				BnsprType.STRING, iMap.getString("KDH_TUR_KOD"),
				BnsprType.STRING, iMap.getString("MUSTERI_GRUP_KOD"),	
				BnsprType.STRING, iMap.getString("EK_PAKET_VAR_YOK"),
				BnsprType.STRING, iMap.getString("BAYI_KREDI_TIPI"),
				BnsprType.STRING, iMap.getString("FAIZSIZ_FINANSMAN"),
				BnsprType.STRING, iMap.getString("MUSTERI_TIPI"),
			};
			String tableName = "DOKUMAN_BILGI";
			oMap.putAll(DALUtil.callOracleRefCursorFunction(func, tableName, inputValues));
			int len = oMap.getSize(tableName);
		    if (len>0) {
		    	for(int i=0;i<len;i++) {
		    		oMap.put(tableName,i,"SEC", GuimlUtil.convertToCheckBoxValue(oMap.getString(tableName,i,"E_H")));
		    	}
		    }
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	@GraymoundService("BNSPR_TRN3119_GET_COMBO_DATA")
	public static GMMap getComboData(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "RESULTS");
		iMap.put("LIST_QUERY", "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr order by 1");
		DALUtil.fillComboBox(iMap);
		return iMap;
	}
	
	@GraymoundService("BNSPR_TRN3119_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "DOKUMAN_BILGI";
			List<?> list = (List<?>) iMap.get("DOKUMAN_BILGI");
			for (int i = 0; i < list.size(); i++) {
				BirBelgeMatrisPrTx birBelgeMatrisPrTx = new BirBelgeMatrisPrTx();
				BirBelgeMatrisPrTxId birBelgeMatrisPrTxId = new BirBelgeMatrisPrTxId();
				birBelgeMatrisPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birBelgeMatrisPrTxId.setDokumanKod(iMap.getString(tableName,i,"DOKUMAN_KODU"));

				birBelgeMatrisPrTx.setId(birBelgeMatrisPrTxId);
				birBelgeMatrisPrTx.setKrdTurKod(iMap.getBigDecimal("KRD_TUR_KOD"));
				birBelgeMatrisPrTx.setKrdTurAltKod(iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
				birBelgeMatrisPrTx.setKrdTurAltKod2(iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));
				birBelgeMatrisPrTx.setKanalKod(iMap.getString("KANAL_KODU"));
				birBelgeMatrisPrTx.setTeminatKod(iMap.getString("TEMINAT"));
				birBelgeMatrisPrTx.setMeslekKod(iMap.getString("MESLEK"));
				birBelgeMatrisPrTx.setCalismaSekli(iMap.getString("CALISMA_SEKLI"));
				birBelgeMatrisPrTx.setKimlikTipKod(iMap.getString("KIMLIK_TIPI"));
                birBelgeMatrisPrTx.setKefilTipKod(iMap.getString("KEFIL_TIPI"));
                birBelgeMatrisPrTx.setSaticiKod(iMap.getBigDecimal("SATICI_KODU"));
				birBelgeMatrisPrTx.setKampanyaKod(iMap.getBigDecimal("KAMPANYA_KOD"));
				birBelgeMatrisPrTx.setSec(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName,i,"SEC")));
				birBelgeMatrisPrTx.setGelirBilgisiKod(iMap.getString("GELIR_BILGISI_KOD"));
				birBelgeMatrisPrTx.setBhsVarYok(iMap.getString("BHS_VAR_YOK"));
				birBelgeMatrisPrTx.setBayiKefaleti(iMap.getString("BAYI_KEFALETI"));
				birBelgeMatrisPrTx.setKdhTurKod(iMap.getString("KDH_TUR_KOD"));
				birBelgeMatrisPrTx.setMusteriGrupKod(iMap.getString("MUSTERI_GRUP_KOD"));
				birBelgeMatrisPrTx.setEkPaketVarYok(iMap.getString("EK_PAKET_VAR_YOK"));
				birBelgeMatrisPrTx.setBayiKrediTipi(iMap.getString("BAYI_KREDI_TIPI"));
				birBelgeMatrisPrTx.setFaizsizFinansman(iMap.getString("FAIZSIZ_FINANSMAN"));
				birBelgeMatrisPrTx.setMusteriTipi(iMap.getString("MUSTERI_TIPI"));
				session.save(birBelgeMatrisPrTx);
			}
			session.flush();

			iMap.put("TRX_NAME", "3119");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN3119_GET_INFO")
	public static GMMap getInfo(GMMap iMap){	
		try{			
			GMMap oMap = new GMMap();
			String func = "{ ? = call PKG_TRN3119.get_info_kriter(?) }";   
			Object[] inputValues = {
				BnsprType.NUMBER, iMap.getBigDecimal("TRX_NO")
			};
			String tableName = "RESULTS";
		    oMap.putAll(DALUtil.callOracleRefCursorFunction(func, tableName, inputValues));
		    int len = oMap.getSize(tableName);
		    if(len>0) {		    	
		    	Set<?> keySet = oMap.getMap(tableName,0).keySet();
		    	for(Object key : keySet) {
		    		String keyName = (String) key;
		    		Object keyValue = oMap.get(tableName, 0, keyName);
		    		oMap.put(keyName,keyValue);		    		
		    	}
		    }
		    func = "{ ? = call PKG_TRN3119.get_info_belgeler(?) }";
		    tableName = "DOKUMAN_BILGI";
		    oMap.putAll(DALUtil.callOracleRefCursorFunction(func, tableName, inputValues));
		    len = oMap.getSize(tableName);
		    if (len>0) {
		    	for(int i=0;i<len;i++) {
		    		oMap.put(tableName,i,"SEC", GuimlUtil.convertToCheckBoxValue(oMap.getString(tableName,i,"E_H")));
		    	}
		    }
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static boolean checkFields(GMMap iMap){
		boolean flag = false;
		if(iMap.getBigDecimal("KRD_TUR_KOD")!=null && !iMap.getBigDecimal("KRD_TUR_KOD").equals(""))flag=true;
		else if(iMap.getBigDecimal("KRD_TUR_ALT_KOD")!=null && !iMap.getBigDecimal("KRD_TUR_ALT_KOD").equals(""))flag=true;
		else if(iMap.getBigDecimal("KRD_TUR_ALT_KOD")!=null && !iMap.getBigDecimal("KRD_TUR_ALT_KOD").equals(""))flag=true;
		else if(iMap.getBigDecimal("KRD_TUR_ALT_KOD2")!=null && !iMap.getBigDecimal("KRD_TUR_ALT_KOD2").equals(""))flag=true;
		else if(iMap.getBigDecimal("KAMPANYA_KOD")!=null && !iMap.getBigDecimal("KAMPANYA_KOD").equals(""))flag=true;
		else if(iMap.getString("KANAL_KODU")!=null && !iMap.getString("KANAL_KODU").equals("") && iMap.getBigDecimal("KRD_TUR_KOD")!=null && !iMap.getBigDecimal("KRD_TUR_KOD").equals(""))flag=true;
		else if(iMap.getString("KANAL_KODU")!=null && !iMap.getString("KANAL_KODU").equals("") && iMap.getString("TEMINAT")!=null && !iMap.getString("TEMINAT").equals(""))flag=true;
		else if(iMap.getString("KANAL_KODU")!=null && !iMap.getString("KANAL_KODU").equals("") && iMap.getString("CALISMA_SEKLI")!=null && !iMap.getString("CALISMA_SEKLI").equals(""))flag=true;
		else if(iMap.getString("KANAL_KODU")!=null && !iMap.getString("KANAL_KODU").equals("") && iMap.getString("BHS_VAR_YOK")!=null && !iMap.getString("BHS_VAR_YOK").equals(""))flag=true;
		else if(iMap.getString("MESLEK")!=null && !iMap.getString("MESLEK").equals(""))flag=true;
		else if(iMap.getString("KIMLIK_TIPI")!=null && !iMap.getString("KIMLIK_TIPI").equals(""))flag=true;
		else if(iMap.getString("KEFIL_TIPI")!=null && !iMap.getString("KEFIL_TIPI").equals("") && iMap.getBigDecimal("KRD_TUR_KOD")!=null && !iMap.getBigDecimal("KRD_TUR_KOD").equals(""))flag=true;
		else if(iMap.getString("GELIR_BILGISI_KOD")!=null && !iMap.getString("GELIR_BILGISI_KOD").equals(""))flag=true;
        else if(iMap.getString("SATICI_KODU")!=null && !iMap.getString("SATICI_KODU").equals(""))flag=true;
        else if(iMap.getString("TEMINAT")!=null && !iMap.getString("TEMINAT").equals(""))flag=true;
        else if(iMap.getString("KDH_TUR_KOD") != null && !(iMap.getString("KDH_TUR_KOD")).isEmpty()) flag = true;
        else if(iMap.getString("MUSTERI_GRUP_KOD") != null && !(iMap.getString("MUSTERI_GRUP_KOD")).isEmpty()) flag = true;		
        else if(iMap.getString("EK_PAKET_VAR_YOK") != null && !(iMap.getString("EK_PAKET_VAR_YOK")).isEmpty()) flag = true;
        else if(iMap.getString("BAYI_KREDI_TIPI") != null && !(iMap.getString("BAYI_KREDI_TIPI")).isEmpty()) flag = true;
        else if(iMap.getString("FAIZSIZ_FINANSMAN") != null && !(iMap.getString("FAIZSIZ_FINANSMAN")).isEmpty()) flag = true;
        else if(iMap.getString("MUSTERI_TIPI") != null && !(iMap.getString("MUSTERI_TIPI")).isEmpty()) flag = true;
		return flag;
	}
}
