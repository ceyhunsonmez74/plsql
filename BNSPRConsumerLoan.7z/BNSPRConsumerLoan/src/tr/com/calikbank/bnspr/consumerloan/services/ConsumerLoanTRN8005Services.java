package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirKrediYetkiLimitPr;
import tr.com.aktifbank.bnspr.dao.BirKrediYetkiLimitPrTx;
import tr.com.aktifbank.bnspr.dao.BirKrediYetkiLimitPrTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.sun.corba.se.impl.protocol.giopmsgheaders.Message;

public class ConsumerLoanTRN8005Services {

	@GraymoundService("BNSPR_TRN8005_FILL_TABLE_COMBOBOX")
	public static GMMap fillTableComboBox(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			oMap.put("ADD_EMPTY_KEY", "H");
			oMap.put("LIST_NAME", "KANAL_KODLARI");
			oMap.put("LIST_QUERY", "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr order by to_number(kod)");
			DALUtil.fillComboBox(oMap);

			String listName = "TEMINATLI";
			GuimlUtil.wrapMyCombo(oMap, listName, "E", "EVET");
			GuimlUtil.wrapMyCombo(oMap, listName, "H", "HAYIR");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN8005_GET_CODE")
	public static GMMap getCode(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('BIR_KREDI_YETKI_LIMIT_PR')}");
			stmt.registerOutParameter(1, Types.NUMERIC);

			stmt.execute();

			BigDecimal code = stmt.getBigDecimal(1);

			oMap.put("CODE", code);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN8005_SAVE")
	public static Map<?, ?> saveTRN8005(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> listBirKrediYetkiLimit = (List<?>) session.createCriteria(BirKrediYetkiLimitPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = listBirKrediYetkiLimit.iterator(); iterator.hasNext();) {
				BirKrediYetkiLimitPrTx birKrediYetkiLimit = (BirKrediYetkiLimitPrTx) iterator.next();
				session.delete(birKrediYetkiLimit);
			}
			session.flush();

			String tableName = "BIR_YETKI_LIMIT";
			ArrayList<?> list = (ArrayList<?>) iMap.get(tableName);
			if(list.size()>0){
			for (int i = 0; i < list.size(); i++) {
				BirKrediYetkiLimitPrTx birKrediYetkiLimit = new BirKrediYetkiLimitPrTx();
				BirKrediYetkiLimitPrTxId id = new BirKrediYetkiLimitPrTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setKod(iMap.getBigDecimal(tableName, i, "KOD"));
				birKrediYetkiLimit.setId(id);
				birKrediYetkiLimit.setRol(iMap.getBigDecimal("ROL"));
				birKrediYetkiLimit.setKanal(iMap.getBigDecimal(tableName, i, "KANAL"));
				birKrediYetkiLimit.setTeminatli(iMap.getString(tableName, i, "TEMINATLI"));
				birKrediYetkiLimit.setKrediTuruKod(iMap.getBigDecimal(tableName, i, "KREDI_TURU_KOD"));
				birKrediYetkiLimit.setKrediTipiKod(iMap.getBigDecimal(tableName, i, "KREDI_TIPI_KOD"));
				birKrediYetkiLimit.setKrediAltTipiKod(iMap.getBigDecimal(tableName, i, "KREDI_ALT_TIPI_KOD"));
				birKrediYetkiLimit.setYetkiLimit(iMap.getBigDecimal(tableName, i, "YETKI_LIMITI"));
				birKrediYetkiLimit.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
				birKrediYetkiLimit.setTeminatliGenelLimit(iMap.getBigDecimal("GENEL_LIMIT_TEMINATLI"));
				birKrediYetkiLimit.setTeminatsizGenelLimit(iMap.getBigDecimal("GENEL_LIMIT_TEMINATSIZ"));

				session.save(birKrediYetkiLimit);
			}
			//Tabloda b�t�n kay�tlar silindiyse, ayn� TRX_NO'da KOD s�f�r olarak at�l�r.
			}else{
				BirKrediYetkiLimitPrTx birKrediYetkiLimit = new BirKrediYetkiLimitPrTx();
				BirKrediYetkiLimitPrTxId id = new BirKrediYetkiLimitPrTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setKod(new BigDecimal(0));
				birKrediYetkiLimit.setId(id);
				birKrediYetkiLimit.setRol(iMap.getBigDecimal("ROL"));
				birKrediYetkiLimit.setKanal(new BigDecimal(0));
				birKrediYetkiLimit.setTeminatli("H");
				birKrediYetkiLimit.setKrediTuruKod(new BigDecimal(0));
				birKrediYetkiLimit.setYetkiLimit(new BigDecimal(0));
				birKrediYetkiLimit.setTeminatliGenelLimit(new BigDecimal(0));
				birKrediYetkiLimit.setTeminatsizGenelLimit(new BigDecimal(0));
				session.save(birKrediYetkiLimit);
			}
			session.flush();

			iMap.put("TRX_NAME", "8005");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN8005_GET_INFO")
	public static GMMap getInfoTRN8005(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> listBirKrediYetkiLimit = null;
			BigDecimal rol = null;
			BigDecimal genelLimitTeminatli = new BigDecimal(0);
			BigDecimal genelLimitTeminatsiz = new BigDecimal(0);
			String rolAciklama = null;
			if ((iMap.getString("ACTION").equals("MESAJ_KUTUSU_CAGIRDI")) || (iMap.getString("ACTION").equals("EDIT"))) {
				listBirKrediYetkiLimit = (List<?>) session.createCriteria(BirKrediYetkiLimitPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
				rol = ((BirKrediYetkiLimitPrTx) listBirKrediYetkiLimit.get(0)).getRol();
				genelLimitTeminatli = ((BirKrediYetkiLimitPrTx) listBirKrediYetkiLimit.get(0)).getTeminatliGenelLimit();
				genelLimitTeminatsiz = ((BirKrediYetkiLimitPrTx) listBirKrediYetkiLimit.get(0)).getTeminatsizGenelLimit();
				rolAciklama = LovHelper.diLov(rol, "8005/LOV_ROL", "TANIM");
			}
			else {
				listBirKrediYetkiLimit = (List<?>) session.createCriteria(BirKrediYetkiLimitPr.class).add(Restrictions.eq("rol", iMap.getBigDecimal("ROL"))).list();
				if (listBirKrediYetkiLimit.size() > 0){
					genelLimitTeminatli = ((BirKrediYetkiLimitPr) listBirKrediYetkiLimit.get(0)).getTeminatliGenelLimit();
				    genelLimitTeminatsiz= ((BirKrediYetkiLimitPr) listBirKrediYetkiLimit.get(0)).getTeminatsizGenelLimit();
				}
			} 
				String tableName = "BIR_YETKI_LIMIT";
				int row = 0;
				for (Iterator<?> iterator = listBirKrediYetkiLimit.iterator(); iterator.hasNext(); row++) {

					if ((iMap.getString("ACTION").equals("MESAJ_KUTUSU_CAGIRDI")) || (iMap.getString("ACTION").equals("EDIT"))) {
						BirKrediYetkiLimitPrTx birKrediYetkiLimit = (BirKrediYetkiLimitPrTx) iterator.next();
						// KOD=0 at�lan kay�tlar�n ekrana getirilmemesi i�in bu i�lem yap�lm��t�r. 
						if(birKrediYetkiLimit.getId().getKod().intValue()==0){
							row--;
						}
						else{
						oMap.put(tableName, row, "KOD", birKrediYetkiLimit.getId().getKod());
						oMap.put(tableName, row, "KANAL", birKrediYetkiLimit.getKanal());
						oMap.put(tableName, row, "TEMINATLI", birKrediYetkiLimit.getTeminatli());
						oMap.put(tableName, row, "KREDI_TURU_KOD", birKrediYetkiLimit.getKrediTuruKod());
						oMap.put(tableName, row, "KREDI_TURU", LovHelper.diLov(birKrediYetkiLimit.getKrediTuruKod(), "8005/LOV_KREDI_TURU", "ACIKLAMA"));
						oMap.put(tableName, row, "KREDI_TIPI_KOD", birKrediYetkiLimit.getKrediTipiKod());
						oMap.put(tableName, row, "KREDI_TIPI", LovHelper.diLov(birKrediYetkiLimit.getKrediTipiKod(), birKrediYetkiLimit.getKrediTuruKod(), "8005/LOV_KREDI_TIPI", "ACIKLAMA"));
						oMap.put(tableName, row, "KREDI_ALT_TIPI_KOD", birKrediYetkiLimit.getKrediAltTipiKod());
						oMap.put(tableName, row, "KREDI_ALT_TIPI", LovHelper.diLov(birKrediYetkiLimit.getKrediAltTipiKod(), birKrediYetkiLimit.getKrediTuruKod(), birKrediYetkiLimit.getKrediTipiKod(), "8005/LOV_ALT_KREDI_TIP", "ACIKLAMA"));
						oMap.put(tableName, row, "YETKI_LIMITI", birKrediYetkiLimit.getYetkiLimit());
						oMap.put(tableName, row, "ACIKLAMA", birKrediYetkiLimit.getAciklama());
						}
					}
					else {
						BirKrediYetkiLimitPr birKrediYetkiLimitPr = (BirKrediYetkiLimitPr) iterator.next();

						oMap.put(tableName, row, "KOD", birKrediYetkiLimitPr.getKod());
						oMap.put(tableName, row, "KANAL", birKrediYetkiLimitPr.getKanal());
						oMap.put(tableName, row, "TEMINATLI", birKrediYetkiLimitPr.getTeminatli());
						oMap.put(tableName, row, "KREDI_TURU_KOD", birKrediYetkiLimitPr.getKrediTuruKod());
						oMap.put(tableName, row, "KREDI_TURU", LovHelper.diLov(birKrediYetkiLimitPr.getKrediTuruKod(), "8005/LOV_KREDI_TURU", "ACIKLAMA"));
						oMap.put(tableName, row, "KREDI_TIPI_KOD", birKrediYetkiLimitPr.getKrediTipiKod());
						oMap.put(tableName, row, "KREDI_TIPI", LovHelper.diLov(birKrediYetkiLimitPr.getKrediTipiKod(), birKrediYetkiLimitPr.getKrediTuruKod(), "8005/LOV_KREDI_TIPI", "ACIKLAMA"));
						oMap.put(tableName, row, "KREDI_ALT_TIPI_KOD", birKrediYetkiLimitPr.getKrediAltTipiKod());
						oMap.put(tableName, row, "KREDI_ALT_TIPI", LovHelper.diLov(birKrediYetkiLimitPr.getKrediAltTipiKod(), birKrediYetkiLimitPr.getKrediTuruKod(), birKrediYetkiLimitPr.getKrediTipiKod(), "8005/LOV_ALT_KREDI_TIP", "ACIKLAMA"));
						oMap.put(tableName, row, "YETKI_LIMITI", birKrediYetkiLimitPr.getYetkiLimit());
						oMap.put(tableName, row, "ACIKLAMA", birKrediYetkiLimitPr.getAciklama());
					}
				}

			oMap.put("ROL", rol);
			oMap.put("GENEL_LIMIT_TEMINATLI", genelLimitTeminatli);
			oMap.put("GENEL_LIMIT_TEMINATSIZ", genelLimitTeminatsiz);
			oMap.put("ROL_ACIKLAMA", rolAciklama);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
