package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.VdmkKrediDevirGuncelleTx;
import tr.com.aktifbank.bnspr.dao.VdmkKrediDevirGuncelleTxId;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3246Services implements Constants {

	@GraymoundService("BNSPR_TRN3246_SORGULA")
	public static GMMap sorgula(GMMap iMap) {
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN3246.vdmk_kredi_devir(?,?,?,?)}");
			
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BASVURU_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("DEVIR_NO"));
						
			if (iMap.getDate("DOSYA_BAS_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("DOSYA_BAS_TARIH")
						.getTime()));
			else
				stmt.setDate(i++, null);

			if (iMap.getDate("DOSYA_BIT_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("DOSYA_BIT_TARIH")
						.getTime()));
			else
				stmt.setDate(i++, null);
			
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);
		
			String tableName = "VDMK_KREDI_DEVIR";
			int row = 0;
			
			while (rSet.next()) {
				
			  oMap.put(tableName, row, "BASVURU_NO", rSet.getBigDecimal("BASVURU_NO"));
			  oMap.put(tableName, row, "DEVIR_NO", rSet.getBigDecimal("DEVIR_NO"));
			  oMap.put(tableName, row, "TAKSIT_NO", rSet.getBigDecimal("TAKSIT_NO"));
			  oMap.put(tableName, row, "DOSYA_YUKLEME_TARIHI", rSet.getDate("DOSYA_YUKLEME_TARIHI"));

			  row++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
		
	@GraymoundService("BNSPR_TRN3246_HEPSINI_IPTAL_ET")
	public static GMMap hepsiniIptalEt(GMMap iMap){
		
		try{
			String tableName = "VDMK_KREDI_DEVIR";
			List<?> list = (List<?>)iMap.get(tableName);
			for(int i=0;i<list.size();i++)
			{
				iMap.put(tableName, i,"IPTAL",iMap.getBoolean("HEPSINI_IPTAL_ET"));
			}
        	return iMap;
        	
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3246_SAVE")
	public static Map<?, ?> save(GMMap iMap){

		try{
			Session session = DAOSession.getSession("BNSPRDal"); 
            String tableName = "VDMK_KREDI_DEVIR";
			List<?> guiList = (List<?>)iMap.get(tableName);
		
			for (int i = 0; i < guiList.size(); i++) {
									
			    VdmkKrediDevirGuncelleTx vdmkKrediDevirGuncelleTx = new VdmkKrediDevirGuncelleTx();
			    VdmkKrediDevirGuncelleTxId id = new VdmkKrediDevirGuncelleTxId();
					
			    id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			    id.setBasvuruNo(iMap.getBigDecimal(tableName, i, "BASVURU_NO"));
			    id.setDevirNo(iMap.getBigDecimal(tableName, i,"DEVIR_NO"));
			    vdmkKrediDevirGuncelleTx.setId(id);
			    
			    if(iMap.getBoolean(tableName, i, "IPTAL")){
			      vdmkKrediDevirGuncelleTx.setIptalEdilecekMiEh("E");
			    }else{
				  vdmkKrediDevirGuncelleTx.setIptalEdilecekMiEh("H");
			    }
			    
			    vdmkKrediDevirGuncelleTx.setDosyaYuklemeTarihi(iMap.getDate(tableName, i, "DOSYA_YUKLEME_TARIHI"));
			    vdmkKrediDevirGuncelleTx.setTaksitNo(iMap.getBigDecimal(tableName, i, "TAKSIT_NO"));
			    vdmkKrediDevirGuncelleTx.setYeniTaksitNo(iMap.getBigDecimal(tableName, i, "YENI_TAKSIT_NO"));
			    
                session.save(vdmkKrediDevirGuncelleTx);
			
			}
			session.flush();  	
			
			iMap.put("TRX_NAME", "3246");
			return   GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN3246_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		try{
			GMMap oMap = new GMMap();
		    Session session = DAOSession.getSession("BNSPRDal");
		    List<?> list = (List<?>)session.createCriteria(VdmkKrediDevirGuncelleTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
		
		
		String tableName = "VDMK_KREDI_DEVIR";
		int row = 0;
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			VdmkKrediDevirGuncelleTx vdmkKrediDevirGuncelleTx = (VdmkKrediDevirGuncelleTx) iterator.next();
			
			if(vdmkKrediDevirGuncelleTx.getIptalEdilecekMiEh().compareTo("E") == 0){
				oMap.put(tableName, row, "IPTAL", 1);
			}else{
				oMap.put(tableName, row, "IPTAL", 0);
			}
			oMap.put(tableName, row, "BASVURU_NO", vdmkKrediDevirGuncelleTx.getId().getBasvuruNo());
			oMap.put(tableName, row, "DEVIR_NO", vdmkKrediDevirGuncelleTx.getId().getDevirNo());
			oMap.put(tableName, row, "DOSYA_YUKLEME_TARIHI", vdmkKrediDevirGuncelleTx.getDosyaYuklemeTarihi());
			oMap.put(tableName, row, "TAKSIT_NO", vdmkKrediDevirGuncelleTx.getTaksitNo());
			oMap.put(tableName, row, "YENI_TAKSIT_NO", vdmkKrediDevirGuncelleTx.getYeniTaksitNo());

			row++;
		}
		
        	return oMap;
        	
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN3246_QUERY_FROM_FILE_XLS")
	public static GMMap queryFromFileXls(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try {
			byte[] inputFile = (byte[]) iMap.get(CONTENT);
			
			if (inputFile == null) {
				iMap.put(HATA_NO, new BigDecimal(660));
				iMap.put("P1", "Dosya se�mediniz.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			Workbook workbook;
			WorkbookSettings ws = new WorkbookSettings();

			ws.setEncoding(ISO_8859_9);
			ws.setExcelDisplayLanguage(TR);
			ws.setExcelRegionalSettings(TR);
			ws.setLocale(new Locale(TR, TR));
			
			try {
				workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
				if (workbook.getSheet(0).getColumns() != VDMK_EXCEL_COLUMN_SIZE) {
					throw new GMRuntimeException(0, "Hatal� Dosya Format�.");
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				iMap.put(HATA_NO, new BigDecimal(660));
				iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			Sheet sheet = workbook.getSheet(0);
			
			for (int row = 0; row < sheet.getRows(); row++) {
				BigDecimal basvuruNo = BigDecimal.valueOf(Long.parseLong(sheet.getCell(0, row).getContents().toString()));
				GMMap vdmkMap = new GMMap();
				vdmkMap.put(BASVURU_NO, basvuruNo);
				vdmkMap = GMServiceExecuter.call("BNSPR_TRN3246_SORGULA", vdmkMap);
				if(!vdmkMap.isEmpty()){
					oMap.put(VDMK_KREDI_DEVIR, row, vdmkMap.getMap(VDMK_KREDI_DEVIR, 0));
				}
			}
			
			oMap.put(LINE_SIZE, oMap.getSize(VDMK_KREDI_DEVIR));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
