package tr.com.calikbank.bnspr.consumerloan.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.Types;
import java.util.Date;
import java.util.List;
import java.util.Map;

import jxl.DateCell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.BirSigortaManueliptalTx;
import tr.com.aktifbank.bnspr.dao.BirSigortaManueliptalTxId;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN8040Services implements Constants {

	@GraymoundService("BNSPR_TRN8040_SIGORTA_IPTAL_SORGULA")
	public static GMMap sigortaIptalSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Date startDate = iMap.getDate("KAYIT_TARIHI_BAS");
			Date endDate = iMap.getDate("KAYIT_TARIHI_BIT");
			BigDecimal basvuruNo = iMap.getBigDecimal("BASVURU_NO");
			String policeNo = iMap.getString("POLICE_NO");
			Object[] inputs = { BnsprType.NUMBER, basvuruNo, BnsprType.STRING, policeNo, BnsprType.DATE, startDate, BnsprType.DATE, endDate };

			String func = "{ ? = call pkg_trn8040.get_insurance_list_for_trn8040(?,?,?,?) }";

			oMap = (GMMap) DALUtil.callOracleRefCursorFunction(func, "RESULTS", inputs);
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN8040_SIGORTA_IPTAL")
	public static GMMap sigortaIptal(GMMap iMap) {
		GMMap inMap = new GMMap();
		try {
			for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
				inMap = iMap.getMap("TABLE_DATA", i);
				if("1".equals(inMap.getString("SEC"))){
					inMap.put("TRX_NO", inMap.getString("TX_NO"));
					inMap.put("IPTAL_TARIHI", inMap.getString("REC_DATE"));
					GMServiceExecuter.call("BNSPR_PROCESS_LIFE_INSURANCE_CANCEL", inMap);
				}
			}
		}
		catch (Exception e) {
			ExceptionHandler.convertException(e);
		}
		return iMap;
	}
	
	@GraymoundService("BNSPR_TRN8040_SELECT_ALL")
	public static GMMap selectAll(GMMap iMap) {
		boolean checked = iMap.getBoolean("CHECKED");
		
		try {
			for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
				iMap.put("TABLE_DATA", i, "SEC", checked);
			}

			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN8040_SIGORTA_PRIM_HESAPLA")
	public static GMMap sigortaPrimHesapla(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			String listFunction = "{ ? = call pkg_trn8040.get_insurance_app_list(?,?) }";
			String formulaFunction = "{? = call  pkg_trn8040.get_insurance_premium(?)}";
			BigDecimal akustikInsPremium = BigDecimal.ZERO;
			BigDecimal formulaInsPremium = BigDecimal.ZERO;
			BigDecimal appNumber = BigDecimal.ZERO;
			Object[] inputValues = new Object[4];
			int paramCount = 0;
			
			inputValues[paramCount++] = BnsprType.DATE;
			inputValues[paramCount++] = iMap.getDate("TARIH_BASLANGIC");
			inputValues[paramCount++] = BnsprType.DATE;
			inputValues[paramCount++] = iMap.getDate("TARIH_BITIS");
			GMMap insuranceListMap = (GMMap) DALUtil.callOracleRefCursorFunction(listFunction, "LIST", inputValues);
			
			int count = 0;
			
			for (int i = 0; i < insuranceListMap.getSize("LIST"); i++) {
				appNumber = insuranceListMap.getBigDecimal("LIST", i, "BASVURU_NO");
				akustikInsPremium = insuranceListMap.getBigDecimal("LIST", i, "RETURN_PREMIUM");
				formulaInsPremium = (BigDecimal) DALUtil.callOneParameterFunction(formulaFunction, Types.NUMERIC, appNumber);
				
				BigDecimal fark = akustikInsPremium.subtract(formulaInsPremium);
				
				if ("E".equals(iMap.getString("SECENEK"))) {
					if (fark.equals(BigDecimal.ZERO)) {
						oMap.put("RESULT", count, "SIGORTA_SIRKETI", insuranceListMap.getString("LIST", i, "SIGORTA_SIRKETI"));
						oMap.put("RESULT", count, "POLICE_NO", insuranceListMap.getString("LIST", i, "POLICE_NO"));
						oMap.put("RESULT", count, "BASVURU_NO", insuranceListMap.getBigDecimal("LIST", i, "BASVURU_NO"));
						oMap.put("RESULT", count, "AKUSTIK_KOMISYON", akustikInsPremium);
						oMap.put("RESULT", count, "FORMUL_KOMISYON", formulaInsPremium);
						oMap.put("RESULT", count, "FARK", akustikInsPremium.subtract(formulaInsPremium));
						count++;
					} 
				} else if ("ED".equals(iMap.getString("SECENEK"))) {
					if (!fark.equals(BigDecimal.ZERO)) {
						oMap.put("RESULT", count, "SIGORTA_SIRKETI", insuranceListMap.getString("LIST", i, "SIGORTA_SIRKETI"));
						oMap.put("RESULT", count, "POLICE_NO", insuranceListMap.getString("LIST", i, "POLICE_NO"));
						oMap.put("RESULT", count, "BASVURU_NO", insuranceListMap.getBigDecimal("LIST", i, "BASVURU_NO"));
						oMap.put("RESULT", count, "AKUSTIK_KOMISYON", akustikInsPremium);
						oMap.put("RESULT", count, "FORMUL_KOMISYON", formulaInsPremium);
						oMap.put("RESULT", count, "FARK", akustikInsPremium.subtract(formulaInsPremium));
						count++;
					}
				} else {
					oMap.put("RESULT", count, "SIGORTA_SIRKETI", insuranceListMap.getString("LIST", i, "SIGORTA_SIRKETI"));
					oMap.put("RESULT", count, "POLICE_NO", insuranceListMap.getString("LIST", i, "POLICE_NO"));
					oMap.put("RESULT", count, "BASVURU_NO", insuranceListMap.getBigDecimal("LIST", i, "BASVURU_NO"));
					oMap.put("RESULT", count, "AKUSTIK_KOMISYON", akustikInsPremium);
					oMap.put("RESULT", count, "FORMUL_KOMISYON", formulaInsPremium);
					oMap.put("RESULT", count, "FARK", akustikInsPremium.subtract(formulaInsPremium));
					count++;
					}
				}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN4124_LOAD_EXCEL")
	public static GMMap manuelIptalDatalariList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Workbook workbook = null;
		try {			
			String tableName = "MANUEL_IPTAL_DATALARI";
			
			WorkbookSettings setting = new WorkbookSettings();
            setting.setEncoding("ISO-8859-9");
            workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("DOSYA")) , setting);
            Sheet dataSheet = workbook.getSheet(0);

            for (int i = 0; i < dataSheet.getRows() - 1; i++){
            	oMap.put(tableName , i , "BASVURU_NO" , dataSheet.getCell(0 , i + 1).getContents());
                oMap.put(tableName , i , "POLICE_NO" , dataSheet.getCell(1 , i + 1).getContents());
                oMap.put(tableName , i , "TANZIM_TARIHI" , ((DateCell)dataSheet.getCell(5 , i + 1)).getDate());
                oMap.put(tableName , i , "BRUT_PRIM" , dataSheet.getCell(6 , i + 1).getContents().replaceAll(",", "."));
                oMap.put(tableName , i , "KOMISYON" , dataSheet.getCell(7 , i + 1).getContents().replaceAll(",", "."));
            }


			return oMap;
			
			}	  catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
		
	
	@GraymoundService("BNSPR_TRN4124_SAVE")
	public static Map<?, ?> save(GMMap iMap){

		try{
			Session session = DAOSession.getSession("BNSPRDal");

            String tableName = "MANUEL_IPTAL_DATALARI";
			List<?> guiList = (List<?>)iMap.get(tableName);
			if(guiList.size()==0){
				iMap.put("HATA_NO", new BigDecimal(1064));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if(iMap.getString("DOSYA_ADI")==null || iMap.getString("DOSYA_ADI").length()==0){
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "DOSYA_ADI");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			for (int i = 0; i < guiList.size(); i++) {
				
				BirSigortaManueliptalTx birSigortaManueliptalTx = new BirSigortaManueliptalTx();
				BirSigortaManueliptalTxId id = new BirSigortaManueliptalTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setBasvuruNo(iMap.getBigDecimal(tableName, i, "BASVURU_NO"));
				id.setBrutPrim(iMap.getBigDecimal(tableName, i, "BRUT_PRIM"));
				id.setKomisyon(iMap.getBigDecimal(tableName, i, "KOMISYON"));
				id.setPoliceNo(iMap.getString(tableName, i, "POLICE_NO"));
				id.setTanzimTarihi(iMap.getDate(tableName, i, "TANZIM_TARIHI"));
				
				birSigortaManueliptalTx.setId(id);

				session.save(birSigortaManueliptalTx);
			}
			session.flush();
			iMap.put("TRX_NAME", "4124");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	
	@GraymoundService("BNSPR_TRN4124_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> list = (List<?>)session.createCriteria(BirSigortaManueliptalTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	
		String tableName = "MANUEL_IPTAL_DATALARI";
		int row = 0;
		for (Object name : list) {
			
			BirSigortaManueliptalTx birSigortaIptalTx = (BirSigortaManueliptalTx) name;
			oMap.put(tableName, row, "BASVURU_NO", birSigortaIptalTx.getId().getBasvuruNo());
			oMap.put(tableName, row, "POLICE_NO", birSigortaIptalTx.getId().getPoliceNo());
			oMap.put(tableName, row, "TANZIM_TARIHI", birSigortaIptalTx.getId().getTanzimTarihi());
			oMap.put(tableName, row, "BRUT_PRIM", birSigortaIptalTx.getId().getBrutPrim());
			oMap.put(tableName, row, "KOMISYON", birSigortaIptalTx.getId().getKomisyon());
			
			row++;
		}
        	return oMap;
        	
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
