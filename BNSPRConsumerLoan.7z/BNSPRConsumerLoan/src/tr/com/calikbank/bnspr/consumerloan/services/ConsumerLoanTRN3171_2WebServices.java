package tr.com.calikbank.bnspr.consumerloan.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.hibernate.lob.ClobImpl;

import tr.com.aktifbank.bnspr.dao.BirBasvuruBelge;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTx;
import tr.com.aktifbank.bnspr.dao.BirBasvuruBelgeTxId;
import tr.com.aktifbank.bnspr.dao.BirDijitalayakiziCihaz;
import tr.com.aktifbank.bnspr.dao.BirDijitalayakiziCihazId;
import tr.com.aktifbank.bnspr.dao.BirDijitalayakiziGirisVeri;
import tr.com.aktifbank.bnspr.dao.BirDijitalayakiziGirisVeriId;
import tr.com.aktifbank.bnspr.dao.BirDijitalayakiziHareket;
import tr.com.aktifbank.bnspr.dao.BirDijitalayakiziHareketId;
import tr.com.aktifbank.bnspr.dao.BirOtpLog;
import tr.com.aktifbank.bnspr.dao.BirRiskFiyatlamaTanim;
import tr.com.aktifbank.bnspr.dao.BirSosyalSkorData;
import tr.com.aktifbank.bnspr.dao.BirSosyalSkorDataId;
import tr.com.aktifbank.bnspr.dao.GnlMusteri;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.GnlParametre;
import tr.com.calikbank.bnspr.consumerloan.document.type.DocumentCreator;
import tr.com.calikbank.bnspr.consumerloan.document.type.WebCreditDocument;
import tr.com.calikbank.bnspr.consumerloan.models.socialscore.CustomerBehaviour;
import tr.com.calikbank.bnspr.consumerloan.models.socialscore.DeviceInformation;
import tr.com.calikbank.bnspr.consumerloan.models.socialscore.InputData;
import tr.com.calikbank.bnspr.consumerloan.models.socialscore.SocialScoreData;
import tr.com.calikbank.bnspr.consumerloan.utils.Constants;
import tr.com.calikbank.bnspr.consumerloan.utils.CreditTypes;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BirBasvuru;
import tr.com.calikbank.bnspr.dao.BirBasvuruGorusTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruGorusTxId;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlik;
import tr.com.calikbank.bnspr.dao.BirBasvuruKimlikTx;
import tr.com.calikbank.bnspr.dao.BirBasvuruTx;
import tr.com.calikbank.bnspr.dao.BirSatici;
import tr.com.calikbank.bnspr.dao.BirSaticiCalisan;
import tr.com.calikbank.bnspr.dao.BirSaticiTahsis;
import tr.com.calikbank.bnspr.dao.GnlMusteriTelefon;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

@SuppressWarnings("deprecation")
public class ConsumerLoanTRN3171_2WebServices {
	public static final int initYear = 2010;

	@GraymoundService("BNSPR_TRN3171_KPS_DEALER")
	public static Map<?, ?> kpsDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String tcKimlikNo = iMap.getString("TCKNO");
			if (tcKimlikNo.length() == 0) {
				iMap.put("HATA_NO", "993");
				iMap.put("P1", "TC Kimlik Numaran�z�");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if (tcKimlikNo.substring(0, 1).equals("9")) {
				iMap.put("HATA_NO", "1033");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			iMap.put("TC_KIMLIK_NO", tcKimlikNo);
			iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_TCKN_CHECK_DIGIT", iMap));
			if (iMap.getBigDecimal("SONUC").compareTo(new BigDecimal(0)) == 0) {
				iMap.put("HATA_NO", "456");
				iMap.put("P1", tcKimlikNo);
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			try {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", iMap));
				// oMap.putAll(GMConnection.getConnection("BANKINGSalacak").serviceCall("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", iMap));
			}
			catch (Exception e) {

			}
			if (oMap.getString("TCKNO_OUT") != null) {
				if ("5".equals(oMap.getString("DURUMU"))) {
					iMap.put("HATA_NO", "2087");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				if (oMap.getString("OLUM_TARIHI") != null) {
					iMap.put("HATA_NO", "918");
					iMap.put("P1", oMap.getString("OLUM_TARIHI").substring(6, 8) + "/" + oMap.getString("OLUM_TARIHI").substring(4, 6) + "/" + oMap.getString("OLUM_TARIHI").substring(0, 4));
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				else {
					iMap.put("DOGUM_TARIHI", oMap.getDate("DOGUM_TARIHI"));
					GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_DOGUM_TARIHI", iMap);
				}
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KIMLIK_DOGRULAMA", iMap));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KAYIP_KIMLIK_SORGULAMA", iMap));
				oMap.put("ADI", oMap.remove("AD1"));
				oMap.put("IKINCI_ADI", oMap.remove("AD2"));
				oMap.put("SOYADI", oMap.remove("SOYAD"));
				oMap.put("NUFUS_VERILIS_TARIHI", oMap.remove("VERILIS_TARIHI"));
				oMap.put("BABA_ADI", oMap.remove("BABA_AD"));
				oMap.put("ANNE_ADI", oMap.remove("ANNE_AD"));
				oMap.put("NUFUS_MAHALLE", oMap.remove("MAHALLE_KOY"));
				oMap.put("KIMLIK_SERI_NO_KPS", oMap.remove("KIMLIK_SERI_NO"));
				oMap.put("KIMLIK_SIRA_NO_KPS", oMap.remove("KIMLIK_SIRA_NO"));
				oMap.put("NUFUS_IL_KOD", oMap.remove("IL_KODU"));
				oMap.put("NUFUS_ILCE_KOD", oMap.remove("ILCE_KODU"));
				oMap.put("NUFUS_CILT_NO", oMap.remove("CILT_KODU"));
				oMap.put("NUFUS_AILE_SIRA_NO", oMap.remove("AILE_SIRA_NO"));
				oMap.put("NUFUS_SIRA_NO", oMap.remove("BIREY_SIRA_NO"));
				if (oMap.get("CINSIYET") != null) {
					oMap.put("CINSIYET", ((String) oMap.remove("CINSIYET")).substring(0, 1));
				}
				if (oMap.get("MEDENI_HALI") != null) {
					oMap.put("MEDENI_HAL", ((String) oMap.remove("MEDENI_HALI")).substring(0, 1).equals("E") ? 1 : 2);
				}
				oMap.put("KAYIP_CUZDAN_NO", oMap.remove("KAYIP_CUZDAN_NO"));
				oMap.put("KAYIP_CUZDAN_SERI", oMap.remove("KAYIP_CUZDAN_SERI"));
				oMap.put("NUF_VERILIS_NEDENI", oMap.remove("VERILIS_NEDENI"));
				oMap.put("NUF_VERILDIGI_YER", oMap.remove("VERILDIGI_ILCE_ADI"));
				if (oMap.get("KIMLIK_SERI_NO_KPS") != null && oMap.get("KIMLIK_SIRA_NO_KPS") != null && oMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && oMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
					oMap.put("NUFUS_CUZDANI_SERI_NO", oMap.getString("KIMLIK_SERI_NO_KPS").concat(oMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
				}
				oMap.put("TCKNO", tcKimlikNo);
				oMap.put("KPS_LOG", "TAMAM");
			}
			else if (oMap.getInt("HATA_KOD") == 1 && "Ki�i Bulunamad�.".equals(oMap.getString("HATA")) || oMap.getInt("HATA_KOD") == 2 && "Arad���n�z kriterlere uygun kay�t bulunamad�.".equals(oMap.getString("HATA"))) {

				iMap.put("HATA_NO", "456");
				iMap.put("P1", tcKimlikNo);
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);

			}
			else {
				oMap.put("TCKNO", tcKimlikNo);
				oMap.put("KPS_LOG", "KAPALI");
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_TEMP_SAVE_WEB")
	public static Map<?, ?> saveTempWeb(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			sMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_LC_KOD", iMap));
			iMap.put("DOVIZ_KODU", sMap.get("LC_KOD"));
			iMap.put("DOVIZ_KOD", sMap.get("LC_KOD"));
			iMap.put("KREDI_TUTARI", iMap.get("TUTAR"));
			iMap.put("KREDI_VADESI", iMap.get("VADE"));
			iMap.put("TCKN", iMap.get("TC_KIMLIK_NO"));
			iMap.put("KAMP_URUN_ADI", iMap.get("URUN_KAMP_KOD"));

			// validate start

			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KREDI_MIN_MAX_DEGER", iMap);
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_FAIZ_ORANI", iMap);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMP_KNL_KOD", iMap));
			iMap.put("KAMP_KNL_KOD", oMap.get("KAMP_KNL_KOD"));
			iMap.put("KAMP_KOD", oMap.get("KAMP_KOD"));
			GMServiceExecuter.execute("BNSPR_TRN3171_KAMPANYA_KULLANILABILIR_MI", iMap);
			String tcKimlikNo = iMap.getString("TCKN");
			if (tcKimlikNo.length() == 0) {
				sMap.put("HATA_NO", "993");
				sMap.put("P1", "TC Kimlik Numaran�z�");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
			}
			if (tcKimlikNo.substring(0, 1).equals("9")) {
				sMap.put("HATA_NO", "1033");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
			}

			sMap.put("TC_KIMLIK_NO", tcKimlikNo);
			sMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_TCKN_CHECK_DIGIT", sMap));
			if (sMap.getBigDecimal("SONUC").compareTo(new BigDecimal(0)) == 0) {
				sMap.put("HATA_NO", "456");
				sMap.put("P1", tcKimlikNo);
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
			}

			sMap.put("KOD", iMap.getString("CEP_TEL_KOD"));
			sMap.put("TEL_NO", iMap.getString("CEP_TEL_NO"));
			sMap.put("ALAN_ADI", "Cep Telefonu");
			sMap.put("GSM", "E");
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_TELEFON", sMap);

			sMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
			sMap.put("KRD_TUR_KOD", iMap.getBigDecimal("KRD_TUR_KOD"));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_CALISMA_SEKLI", sMap);

			sMap.put("IL_KOD", iMap.getString("DHF_IL"));
			sMap.put("ILCE_KOD", iMap.getString("DHF_ILCE"));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_DHF_ILCE", sMap);

			if (iMap.getString("CAPTCHA") == null || iMap.getString("CAPTCHA").length() == 0) {
				sMap.put("HATA_NO", "1165");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
			}

			if (!iMap.getBoolean("CAPTCHA_OK")) {
				sMap.put("HATA_NO", "1220");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
			}

			sMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			sMap.put("CEP_TEL_ALAN", iMap.getString("CEP_TEL_KOD"));
			sMap.put("CEP_TEL_NO", iMap.getString("CEP_TEL_NO"));
			GMServiceExecuter.execute("BNSPR_TRN3171_BASVURU_GIRIS_CAPRAZ_SORGU", sMap);

			// validate end

			// Kps start

			if (iMap.getString("TCKNO_OUT") == null) {
				sMap.put("TCKNO", iMap.get("TC_KIMLIK_NO"));
				try {
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KIMLIK_SORGULAMA", sMap));
				}
				catch (Exception e) {

				}
				if (oMap.getString("TCKNO_OUT") != null) {
					if ("5".equals(oMap.getString("DURUMU"))) {
						iMap.put("HATA_NO", "2087");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					if (oMap.getString("OLUM_TARIHI") != null) {
						iMap.put("HATA_NO", "918");
						iMap.put("P1", oMap.getString("OLUM_TARIHI").substring(6, 8) + "/" + oMap.getString("OLUM_TARIHI").substring(4, 6) + "/" + oMap.getString("OLUM_TARIHI").substring(0, 4));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					else {
						iMap.put("DOGUM_TARIHI", oMap.getDate("DOGUM_TARIHI"));
						GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_DOGUM_TARIHI", iMap);
					}
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KIMLIK_DOGRULAMA", sMap));
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KPS_KAYIP_KIMLIK_SORGULAMA", sMap));
					String adSoyad = oMap.getString("AD1");
					if (oMap.getString("AD2") != null)
						adSoyad = adSoyad + " " + oMap.getString("AD2");
					adSoyad = adSoyad + " " + oMap.getString("SOYAD");

					GregorianCalendar clndr = new GregorianCalendar();
					clndr.setTime(oMap.getDate("DOGUM_TARIHI"));
					oMap.put("DOGUM_YILI", clndr.get(Calendar.YEAR));
					oMap.put("AD_SOYAD", adSoyad);
					oMap.put("ADI", oMap.remove("AD1"));
					oMap.put("IKINCI_ADI", oMap.remove("AD2"));
					oMap.put("SOYADI", oMap.remove("SOYAD"));
					oMap.put("NUFUS_VERILIS_TARIHI", oMap.remove("VERILIS_TARIHI"));
					oMap.put("BABA_ADI", oMap.remove("BABA_AD"));
					oMap.put("ANNE_ADI", oMap.remove("ANNE_AD"));
					oMap.put("NUFUS_MAHALLE", oMap.remove("MAHALLE_KOY"));
					oMap.put("KIMLIK_SERI_NO_KPS", oMap.remove("KIMLIK_SERI_NO"));
					oMap.put("KIMLIK_SIRA_NO_KPS", oMap.remove("KIMLIK_SIRA_NO"));
					oMap.put("NUFUS_IL_KOD", oMap.remove("IL_KODU"));
					oMap.put("NUFUS_ILCE_KOD", oMap.remove("ILCE_KODU"));
					oMap.put("NUFUS_CILT_NO", oMap.remove("CILT_KODU"));
					oMap.put("NUFUS_AILE_SIRA_NO", oMap.remove("AILE_SIRA_NO"));
					oMap.put("NUFUS_SIRA_NO", oMap.remove("BIREY_SIRA_NO"));
					if (oMap.get("CINSIYET") != null) {
						oMap.put("CINSIYET", ((String) oMap.remove("CINSIYET")).substring(0, 1));
					}
					if (oMap.get("MEDENI_HALI") != null) {
						oMap.put("MEDENI_HAL", ((String) oMap.remove("MEDENI_HALI")).substring(0, 1).equals("E") ? 1 : 2);
					}
					oMap.put("KAYIP_CUZDAN_NO", oMap.remove("KAYIP_CUZDAN_NO"));
					oMap.put("KAYIP_CUZDAN_SERI", oMap.remove("KAYIP_CUZDAN_SERI"));
					oMap.put("NUF_VERILIS_NEDENI", oMap.remove("VERILIS_NEDENI"));
					oMap.put("NUF_VERILDIGI_YER", oMap.remove("VERILDIGI_ILCE_ADI"));
					if (oMap.get("KIMLIK_SERI_NO_KPS") != null && oMap.get("KIMLIK_SIRA_NO_KPS") != null && oMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && oMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
						oMap.put("NUFUS_CUZDANI_SERI_NO", oMap.getString("KIMLIK_SERI_NO_KPS").concat(oMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
					}
					iMap.putAll(oMap);

				}
				else {
					sMap.put("HATA_NO", "1009");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
				}
			}

			// Kps end
			sMap.put("KOD", iMap.get("KAMP_URUN_ADI"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KRD_TUR_KOD_BOL", sMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_ORANI"));
			iMap.put("KREDI_TURU", iMap.get("KRD_TUR_KOD"));
			iMap.put("KAMPANYA_KODU", iMap.get("KAMP_URUN_ADI"));
			iMap.put("KREDI_VADE", iMap.get("VADE"));
			iMap.put("ODEME_TIP_KOD", iMap.get("ODEME_TIPI"));
			iMap.put("KATKI_PAYI", iMap.get("MAX_KATKI_PAYI"));
			iMap.put("GECIKME_GUN_SAYISI", new BigDecimal(0));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3183_GET_ODEME_PLANI", iMap));
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_FAIZ_ORANI"));
			iMap.put("KATILIM_BEDELI", iMap.get("MAX_KATKI_PAYI"));
			iMap.put("DOSYA_MASRAFI", iMap.get("MAX_DOSYA_MASRAFI"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3183_GET_ODEME_PLANI", iMap));
			List<?> odemeList = (List<?>) iMap.get("ODEME_PLANI");
			if (odemeList != null) {
				GMMap castMap = new GMMap((HashMap<?, ?>) odemeList.get(0));
				oMap.put("TAKSIT_TUTARI", castMap.get("OP_TAKSIT_TUTAR"));
			}
			oMap.put("ODEME_PLANI", iMap.get("ODEME_PLANI"));
			oMap.put("SOZLESME_FAIZ_ORANI", iMap.get("SOZLESME_FAIZ_ORANI"));
			oMap.put("TOPLAM_TAKSIT_TUTARI", iMap.get("TOPLAM_TAKSIT_TUTARI"));
			iMap.put("EKRAN_NO", "3171");
			GMServiceExecuter.execute("BNSPR_TRN3171_SAVE_TEMP", iMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_SOLVE_ASYNCRONOUS_CAPTCHA")
	public static GMMap solveAsyncronousCaptcha(GMMap iMap) {
		GMMap oMap = new GMMap();
		String func = "{? = call pkg_nbsm_3appl.esgm_dogrulama_captcha(?) }";
		try {
			Object result = DALUtil.callOracleFunction(func, BnsprType.STRING, BnsprType.NUMBER, iMap.getBigDecimal("BASVURU_NO"));
			oMap.put("RESULT", result);
		}
		catch (Exception e) {
			oMap.put("RESULT", -99);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_TEMP_SAVE_DEALER")
	public static Map<?, ?> saveTempDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			oMap.put("DEVAM", "E");
			String cinsiyet = iMap.getString("CINSIYET");
			String medeniHal = iMap.getString("MEDENI_HAL");

			if (iMap.getString("KPS_YAPILDI") != null && iMap.getString("KPS_YAPILDI").equals("H")) {

				sMap.put("AD", iMap.getString("ADI"));
				sMap.put("ALAN_ADI", "AD");
				GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);

				if (iMap.getString("IKINCI_ADI") != null && !iMap.getString("IKINCI_ADI").equals("")) {
					sMap.put("AD", iMap.getString("IKINCI_ADI"));
					sMap.put("ALAN_ADI", "IKINCI_AD");
					GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);
				}

				sMap.put("AD", iMap.getString("SOYADI"));
				sMap.put("ALAN_ADI", "SOYAD");
				GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);

				sMap.put("AD", iMap.getString("DOGUM_YERI"));
				sMap.put("ALAN_ADI", "DOGUM_YERI");
				GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);

				sMap.put("DOGUM_TARIHI", iMap.getDate("DOGUM_TARIHI"));
				sMap.put("BANKA_TARIHI", iMap.getDate("BANKA_TARIHI"));
				GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_DOGUM_TARIHI", sMap);

				sMap.put("AD", iMap.getString("BABA_ADI"));
				sMap.put("ALAN_ADI", "BABA_ADI");
				GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);

				sMap.put("AD", iMap.getString("ANNE_ADI"));
				sMap.put("ALAN_ADI", "ANNE_ADI");
				GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);

				if (cinsiyet == null) {
					sMap.put("HATA_NO", "993");
					sMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "CINSIYET")).get("TEXT"));
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
				}

				if (medeniHal == null) {
					sMap.put("HATA_NO", "993");
					sMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "MEDENI_HAL")).get("TEXT"));
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
				}
			}

			if (iMap.get("KANAL_ALT_KOD") != null) {
				BirSaticiTahsis saticiTahsis = (BirSaticiTahsis) session.get(BirSaticiTahsis.class, iMap.getBigDecimal("KANAL_ALT_KOD"));
				if ("K".equals(saticiTahsis.getBayiStatuKod())) {
					sMap.put("HATA_NO", "1429");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
				}
				else if ("KK".equals(saticiTahsis.getBayiStatuKod()) && "3".equals(saticiTahsis.getKismiKapanmaStatuKod())) {
					sMap.put("HATA_NO", "5528");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
				}
			}

			sMap.put("SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
			sMap.put("SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
			sMap.put("CINSIYET", iMap.getString("CINSIYET"));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KIMLIK_NO", sMap);

			sMap.put("AD", iMap.getString("ANNE_KIZLIK_SOYADI"));
			sMap.put("ALAN_ADI", "AKS");
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);

			sMap.put("KOD", iMap.getString("CEP_TEL_KOD"));
			sMap.put("TEL_NO", iMap.getString("CEP_TEL_NO"));
			sMap.put("ALAN_ADI", "CEP_TELEFONU");
			sMap.put("GSM", "E");
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_TELEFON", sMap);

			GnlMusteri musteri = (GnlMusteri) session.createCriteria(GnlMusteri.class).add(Restrictions.eq("tcKimlikNo", iMap.getString("TCKN"))).add(Restrictions.or(Restrictions.ne("musteriStat1", "4"), Restrictions.isNull("musteriStat1"))).add(Restrictions.eq("durumKodu", "A")).uniqueResult();
			List<GnlMusteriTelefon> telefon = null;
			if (musteri != null) {
				telefon = (List<GnlMusteriTelefon>) session.createCriteria(GnlMusteriTelefon.class).add(Restrictions.eq("alanKod", iMap.getString("CEP_TEL_KOD"))).add(Restrictions.eq("telNo", iMap.getString("CEP_TEL_NO"))).add(Restrictions.eq("id.musteriNo", musteri.getMusteriNo())).list();

				if (telefon == null || telefon.size() == 0) {
					List<GnlMusteriTelefon> telefonList = (List<GnlMusteriTelefon>) session.createCriteria(GnlMusteriTelefon.class).add(Restrictions.eq("alanKod", iMap.getString("CEP_TEL_ALAN_KODU"))).add(Restrictions.eq("telNo", iMap.getString("CEP_TEL_NO"))).list();

					if (telefonList != null && telefonList.size() > 0) {
						throw new GMRuntimeException(0, "Giri� yap�lan cep telefonu ba�ka bir m��teri de kay�tl�d�r. Bu cep telefonundan giri� yap�lamaz.");
					}

				}
			}

			String basvuruCepTel = DALUtil.getResult("select k.cep_tel_alan_kodu || k.cep_tel_no ceptel from bnspr.bir_basvuru_tx t,bnspr.bir_basvuru_kimlik_tx k where t.basvuru_no = " + iMap.getBigDecimal("BASVURU_NO") + " and k.tx_no = t.tx_no and t.kanal_kodu = 12");
			String cepTel = iMap.getString("CEP_TEL_KOD") + iMap.getString("CEP_TEL_NO");
			
			if (!basvuruCepTel.equalsIgnoreCase(cepTel)) {
				throw new GMRuntimeException(0, "Girilen Cep Telefonu bilgisi ba�vuru ad�m�nda kullan�landan farkl�d�r.L�tfen cep telefon bilgisini g�ncelleyiniz.");
			}

			sMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
			sMap.put("KRD_TUR_KOD", iMap.getBigDecimal("KRD_TUR_KOD"));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_CALISMA_SEKLI", sMap);

			if (iMap.getBigDecimal("PERSONEL") == null) {
				sMap.put("HATA_NO", "1159");
				sMap.put("P1", "sat�� personelini");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
			}

			sMap.put("KRD_TUR_KOD", iMap.getBigDecimal("KRD_TUR_KOD"));
			sMap.put("KAMP_URUN_ADI", iMap.getString("KAMP_URUN_ADI"));
			sMap.put("DOVIZ_KODU", iMap.getString("DOVIZ_KODU"));
			sMap.put("KREDI_TUTARI", iMap.getBigDecimal("TUTAR"));
			sMap.put("KREDI_VADESI", iMap.getBigDecimal("VADE"));
			sMap.put("KANAL_KOD", iMap.getBigDecimal("KANAL_KOD"));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KREDI_MIN_MAX_DEGER", sMap);

			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_TESLIM_DURUM_DEALER", iMap));
			if (iMap.get("FATURALI_IHTIYAC_MI") != null && iMap.get("FATURALI_IHTIYAC_MI").equals("E")) {
				if (iMap.get("EVE_TESLIM_URUN") == null) {
					sMap.put("HATA_NO", "1159");
					sMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "EVE_TESLIMATLI_URUN")).get("TEXT"));
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
				}
				else if ("E".equals(iMap.getString("EVE_TESLIM_URUN"))) {
					if (iMap.getDate("TESLIMAT_TARIHI") != null && iMap.getDate("TESLIMAT_TARIHI").before(iMap.getDate("BANKA_TARIHI"))) {
						sMap.put("HATA_NO", "1867");
						SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");
						sMap.put("P1", outputFormat.format(iMap.getDate("BANKA_TARIHI")));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
					}
					else if (iMap.getDate("TESLIMAT_TARIHI") == null && iMap.getBoolean("TESLIMAT_TARIHI_BOS")) {
						sMap.put("HATA_NO", "993");
						sMap.put("P1", "teslimat tarihi");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);

					}
					else if (iMap.getDate("TESLIMAT_TARIHI") == null && !iMap.getBoolean("TESLIMAT_TARIHI_BOS")) {
						sMap.put("HATA_NO", "1866");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
					}
				}
			}

			/*if (!"0".equals(iMap.getString("GORUS_HATA_NO"))) {
				sMap.put("HATA_NO", iMap.get("GORUS_HATA_NO"));
				sMap.put("P1", iMap.get("GORUS_HATA_P1"));
				sMap.put("P2", iMap.get("GORUS_HATA_P2"));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
			}*/

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMP_KNL_KOD", iMap));
			iMap.put("KAMP_KNL_KOD", oMap.get("KAMP_KNL_KOD"));
			iMap.put("KAMP_KOD", oMap.get("KAMP_KOD"));

			sMap.put("KAMP_KOD", oMap.get("KAMP_KOD"));
			sMap.put("TCKN", iMap.getString("TC_KIMLIK_NO"));
			GMServiceExecuter.execute("BNSPR_TRN3171_KAMPANYA_KULLANILABILIR_MI", sMap);

			sMap.put("TUTAR", iMap.getBigDecimal("TUTAR"));
			sMap.put("VADE", iMap.getBigDecimal("VADE"));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_FAIZ_ORANI", sMap);

			sMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			sMap.put("CEP_TEL_ALAN", iMap.getString("CEP_TEL_KOD"));
			sMap.put("CEP_TEL_NO", iMap.getString("CEP_TEL_NO"));
			sMap.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
			sMap.put("KANAL_KODU", iMap.getString("KANAL_KOD"));
			sMap.put("KANAL_ALT_KODU", iMap.getString("KANAL_ALT_KOD"));
			sMap.put("KREDI_TURU", iMap.getString("KRD_TUR_KOD"));
			GMServiceExecuter.execute("BNSPR_TRN3171_BASVURU_GIRIS_CAPRAZ_SORGU", sMap);
			GMServiceExecuter.call("BNSPR_TRN3171_BASVURU_KAMPANYA_KONTROL", sMap);

			if (CreditTypes.TARIM.getCreditCode().equals(iMap.getBigDecimal("KRD_TUR_KOD"))) {
				GMServiceExecuter.call("BNSPR_KKB_CKS_SORGU_BASLAT", iMap);
			}

			/** Kpsden gelen asagidaki degerler aps kayd�nda ezilecegi icin kaldiriliyor. TY-1466 **/
			iMap.put("IL", "");
			iMap.put("ILCE", "");
			iMap.put("IL_KODU", "");
			iMap.put("ILCE_KODU", "");

			oMap.put("APS_YAPILDIMI", iMap.getString("APS_YAPILDIMI"));
			oMap.put("APS_TRX_YAPILDIMI", iMap.getString("APS_TRX_YAPILDIMI"));
			if ("H".equals(iMap.getString("APS_TRX_YAPILDIMI"))) {
				GMMap apsMap = new GMMap();
				// System.out.println("PerformansTest " + ADCSession.getSessionID() + " " +
				// System.currentTimeMillis()+" APS Ba�lad�");
				apsMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3171_APS_SORGULAMA", iMap));
				// System.out.println("PerformansTest " + ADCSession.getSessionID() + " " +
				// System.currentTimeMillis()+" APS Bitti");
				iMap.put("APS_YAPILDIMI", apsMap.getString("APS_YAPILDIMI"));
				oMap.put("APS_YAPILDIMI", apsMap.getString("APS_YAPILDIMI"));
				oMap.put("APS_TRX_YAPILDIMI", apsMap.getString("APS_YAPILDIMI"));
			}

			sMap.put("KOD", iMap.get("KAMP_URUN_ADI"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KRD_TUR_KOD_BOL", sMap));
			iMap.putAll(oMap);
			oMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));
			iMap.putAll(oMap);
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_ORANI"));

			if (iMap.getBoolean("ILK_GIRIS")) {
				iMap.put("KATILIM_BEDELI", iMap.get("MAX_KATKI_PAYI"));
				iMap.put("DOSYA_MASRAFI", iMap.get("MAX_DOSYA_MASRAFI"));
				oMap.put("KATKI_PAYI_DEGISTI", "E");
				oMap.put("DOSYA_MASRAFI_DEGISTI", "E");
			}
			else {
				if ((iMap.getBigDecimal("MAX_KATKI_PAYI_ILK") == null && iMap.getBigDecimal("MAX_KATKI_PAYI") != null) || (iMap.getBigDecimal("MAX_KATKI_PAYI_ILK") != null && iMap.getBigDecimal("MAX_KATKI_PAYI") == null) || !(iMap.getBigDecimal("MAX_KATKI_PAYI_ILK") != null && iMap.getBigDecimal("MAX_KATKI_PAYI_ILK").equals(iMap.getBigDecimal("MAX_KATKI_PAYI"))) || (iMap.getBigDecimal("MIN_KATKI_PAYI_ILK") == null && iMap.getBigDecimal("MAX_KATKI_PAYI") != null) || (iMap.getBigDecimal("MIN_KATKI_PAYI_ILK") != null && iMap.getBigDecimal("MIN_KATKI_PAYI") == null) || !(iMap.getBigDecimal("MIN_KATKI_PAYI_ILK") != null && iMap.getBigDecimal("MIN_KATKI_PAYI_ILK").equals(iMap.getBigDecimal("MIN_KATKI_PAYI"))) || (iMap.getString("SERBEST_KATKI_PAYI_ILK") == null && iMap.getString("SERBEST_KATKI_PAYI") != null) || (iMap.getString("SERBEST_KATKI_PAYI_ILK") != null && iMap.getString("SERBEST_KATKI_PAYI") == null) || !(iMap.getString("SERBEST_KATKI_PAYI_ILK") != null && iMap.getString("SERBEST_KATKI_PAYI_ILK").equals(iMap.getString("SERBEST_KATKI_PAYI"))) || (iMap.getString("KATKI_PAYI_KIMDEN_ILK") == null && iMap.getString("KATKI_PAYI_KIMDEN") != null) || (iMap.getString("KATKI_PAYI_KIMDEN_ILK") != null && iMap.getString("KATKI_PAYI_KIMDEN") == null) || !(iMap.getString("KATKI_PAYI_KIMDEN_ILK") != null && iMap.getString("KATKI_PAYI_KIMDEN_ILK").equals(iMap.getString("KATKI_PAYI_KIMDEN")))) {
					iMap.put("KATILIM_BEDELI", iMap.get("MAX_KATKI_PAYI"));
					oMap.put("KATKI_PAYI_DEGISTI", "E");
				}
				else {
					oMap.put("KATKI_PAYI_DEGISTI", "H");
				}
				if ((iMap.getBigDecimal("MAX_DOSYA_MASRAFI_ILK") == null && iMap.getBigDecimal("MAX_DOSYA_MASRAFI") != null) || (iMap.getBigDecimal("MAX_DOSYA_MASRAFI_ILK") != null && iMap.getBigDecimal("MAX_DOSYA_MASRAFI") == null) || !(iMap.getBigDecimal("MAX_DOSYA_MASRAFI_ILK") != null && iMap.getBigDecimal("MAX_DOSYA_MASRAFI_ILK").equals(iMap.getBigDecimal("MAX_DOSYA_MASRAFI"))) || (iMap.getBigDecimal("MIN_DOSYA_MASRAFI_ILK") == null && iMap.getBigDecimal("MAX_DOSYA_MASRAFI") != null) || (iMap.getBigDecimal("MIN_DOSYA_MASRAFI_ILK") != null && iMap.getBigDecimal("MIN_DOSYA_MASRAFI") == null) || !(iMap.getBigDecimal("MIN_DOSYA_MASRAFI_ILK") != null && iMap.getBigDecimal("MIN_DOSYA_MASRAFI_ILK").equals(iMap.getBigDecimal("MIN_DOSYA_MASRAFI"))) || (iMap.getString("DOSYA_MASRAF_TIPI_ILK") == null && iMap.getString("DOSYA_MASRAF_TIPI") != null) || (iMap.getString("DOSYA_MASRAF_TIPI_ILK") != null && iMap.getString("DOSYA_MASRAF_TIPI") == null) || !(iMap.getString("DOSYA_MASRAF_TIPI_ILK") != null && iMap.getString("DOSYA_MASRAF_TIPI_ILK").equals(iMap.getString("DOSYA_MASRAF_TIPI")))) {
					iMap.put("DOSYA_MASRAFI", iMap.get("MAX_DOSYA_MASRAFI"));
					oMap.put("DOSYA_MASRAFI_DEGISTI", "E");
				}
				else {
					oMap.put("DOSYA_MASRAFI_DEGISTI", "H");
				}
			}

			if ("C".equals(iMap.getString("CALISMA_SEKLI"))) {
				iMap.put("AYLIK_GELIR", new BigDecimal(0));
			}
			iMap.put("EKRAN_NO", "3171");

			List<?> nuLList = null;
			String nuLL = null;
			if (iMap.getString("OGRENIM_DURUMU") != null) {
				GMMap meslekMap = new GMMap();
				meslekMap.put("EGITIM_KOD", iMap.get("OGRENIM_DURUMU"));
				meslekMap.put("CALISMA_SEKLI", iMap.get("CALISMA_SEKLI"));
				meslekMap.put("BANKA_TARIHI", iMap.get("BANKA_TARIHI"));
				meslekMap.put("DOGUM_TARIHI", iMap.get("DOGUM_TARIHI"));
				meslekMap.put("BOS_ALAN", "E");
				oMap.put("MESLEK_LIST", GMServiceExecuter.call("BNSPR_TRN3171_GET_MESLEKLER", meslekMap).get("MESLEK_LIST"));
				if (iMap.getString("MESLEK") != null && oMap.get("MESLEK_LIST") != null) {
					boolean meslekVar = false;
					for (int i = 0; i < oMap.getSize("MESLEK_LIST"); i++) {
						if (iMap.getString("MESLEK").equals(oMap.getString("MESLEK_LIST", i, "VALUE"))) {
							meslekVar = true;
							break;
						}
					}
					if (meslekVar) {
						oMap.put("MESLEK", iMap.get("MESLEK"));
						GMMap unvanMap = new GMMap();
						unvanMap.put("MESLEK_KOD", iMap.get("MESLEK"));
						oMap.put("UNVAN_TURLERI_LIST", GMServiceExecuter.call("BNSPR_TRN3171_GET_UNVAN_TURLERI", unvanMap).get("UNVAN_TURLERI_LIST"));
						if (iMap.getString("UNVANI") != null && oMap.get("UNVAN_TURLERI_LIST") != null) {
							boolean unvanVar = false;
							for (int i = 0; i < oMap.getSize("UNVAN_TURLERI_LIST"); i++) {
								if (iMap.getString("UNVANI").equals(oMap.getString("UNVAN_TURLERI_LIST", i, "VALUE"))) {
									unvanVar = true;
									break;
								}
							}
							if (unvanVar) {
								oMap.put("UNVANI", iMap.get("UNVANI"));
							}
							else {
								oMap.put("UNVANI", nuLL);
							}
						}
						else {
							oMap.put("UNVANI", nuLL);
						}
					}
					else {
						oMap.put("MESLEK", nuLL);
						oMap.put("UNVANI", nuLL);
						oMap.put("UNVAN_TURLERI_LIST", nuLList);
					}
				}
				else {
					oMap.put("MESLEK", nuLL);
					oMap.put("UNVANI", nuLL);
					oMap.put("UNVAN_TURLERI_LIST", nuLList);
				}

			}
			else {
				oMap.put("MESLEK", nuLL);
				oMap.put("MESLEK_LIST", nuLList);
				oMap.put("UNVANI", nuLL);
				oMap.put("UNVAN_TURLERI_LIST", nuLList);
			}
			iMap.put("MESLEK", oMap.get("MESLEK"));
			iMap.put("UNVANI", oMap.get("UNVANI"));

			// System.out.println("PerformansTest " + ADCSession.getSessionID() + " " +
			// System.currentTimeMillis()+" TempSave Ba�lad�");
			if (!StringUtil.isEmpty(iMap.getString("SATICI_KOD"))) {
				iMap.put("KANAL_ALT_KOD", iMap.getString("SATICI_KOD"));
			}

			oMap.put("HERSEY_DAHIL_TUTAR", GMServiceExecuter.execute("BNSPR_TRN3171_HERSEY_DAHIL_TUTAR", iMap).get("HERSEY_DAHIL_TUTAR"));
			iMap.put("HERSEY_DAHIL_TUTAR", oMap.get("HERSEY_DAHIL_TUTAR"));

			GMMap outMap = new GMMap();
			outMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3171_SAVE_TEMP", iMap));
			// System.out.println("PerformansTest " + ADCSession.getSessionID() + " " +
			// System.currentTimeMillis()+" TempSave Bitti");
			iMap.put("MUSTERI_YARATMA_TX_NO", outMap.getBigDecimal("MUSTERI_YARATMA_TX_NO"));
			iMap.put("MUSTERI_NO", outMap.getBigDecimal("MUSTERI_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_UPDATE_MUSTERI_NO", iMap));

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_DEVAM_SORGULAR", iMap));

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GECERLI_TEMINATLAR", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_TEMINATLAR", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KEFIL_YAKINLIK", iMap));
			oMap.put("AYLIK_GELIR", GMServiceExecuter.execute("BNSPR_TRN3171_AYLIK_GELIR", iMap).get("AYLIK_GELIR"));

			// System.out.println("PerformansTest " + ADCSession.getSessionID() + " " +
			// System.currentTimeMillis()+" Devam Bitti");

			/** Dosya masrafi oran tipindeyse hesaplama yapilacak TY-4714 **/
			if ("O".equals(oMap.getString("DOSYA_MASRAF_TIPI"))) {
				if (oMap.get("ONAY_TUTAR") != null && oMap.getBigDecimal("ONAY_TUTAR").compareTo(BigDecimal.ZERO) > 0) {
					oMap.put("MAX_DOSYA_MASRAFI", oMap.getBigDecimal("ONAY_TUTAR").multiply(oMap.getBigDecimal("DOSYA_MASRAF_ORAN").divide(new BigDecimal(100))));
				}
				else {
					oMap.put("MAX_DOSYA_MASRAFI", iMap.getBigDecimal("TUTAR").multiply(oMap.getBigDecimal("DOSYA_MASRAF_ORAN").divide(new BigDecimal(100))));
				}
			}
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_GET_BSMV_ORANI", iMap));
			oMap.put("MAX_DOSYA_MASRAFI", oMap.getBigDecimal("MAX_DOSYA_MASRAFI").multiply(BigDecimal.ONE.add((oMap.getBigDecimal("BSMV_ORANI")))).setScale(2, RoundingMode.HALF_UP));

			// yeni portalde entry init �a�r�lm�yor, o yuzden saticiyi burda g�ncelle.

			BirBasvuruTx b = (BirBasvuruTx) session.createCriteria(BirBasvuruTx.class).add(Restrictions.eq("durumKodu", "ON_ONAY")).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			if (b != null) {
				b.setSaticiKod(iMap.getBigDecimal("KANAL_ALT_KOD"));
				session.saveOrUpdate(b);
				session.flush();
			}

			// kanal kullanicisi yarat..
			if (iMap.get("MUSTERI_NO") == null) {
				iMap.put("MUSTERI_NO", GMServiceExecuter.execute("BNSPR_TRN3171_GET_MUSTERINO", iMap).get("MUSTERI_NO"));
			}
			iMap.put("USERNAME", iMap.getString("TC_KIMLIK_NO"));
			iMap.put("CHANNELS", 0, "CODE", "DLRNG");
			iMap.put("ROLES", 0, "CODE", "GNL");
			GMServiceExecuter.call("ADK_CREATE_USER", iMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_MESLEKLER_KEFIL")
	public static Map<?, ?> getMesleklerKefil(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_DOGUM_TARIHI", iMap);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_MESLEKLER", iMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_DOVIZ_URUN_DEALER")
	public static Map<?, ?> getDovizUrun(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			sMap.put("KANAL_KODU", iMap.get("KANAL_KODU"));
			sMap.put("KRD_TUR_KOD", iMap.get("KRD_TUR_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_DOVIZ_CINSLERI", sMap));
			iMap.put("DOVIZ_KODU", oMap.get("DOVIZ_LIST", 0, "VALUE"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI_DEALER", iMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_SIGORTA_URUN")
	public static Map<?, ?> getSigorta(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_SIGORTA_URUNLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GECERLI_SIGORTA_URUNLERI", iMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI_DEALER")
	public static Map<?, ?> getUrunKampanya(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GARANTOR_MU", iMap));
			if (oMap.get("DEFAULT_URUN_KAMP") != null) {
				iMap.put("KANAL_KOD", iMap.get("KANAL_KODU"));
				iMap.put("URUN_KAMP_KOD", oMap.get("DEFAULT_URUN_KAMP"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_TESLIM_DURUM_DEALER", iMap));
			}
			else {
				oMap.put("MIN_MAX_TUTAR", "");
				oMap.put("MIN_MAX_VADE", "");
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CONTROL_WEB")
	public static Map<?, ?> controlWeb(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			sMap.put("AD", iMap.getString("ANNE_KIZLIK_SOYADI"));
			sMap.put("ALAN_ADI", "AKS");
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);
			String cinsiyet = iMap.getString("CINSIYET");
			// String medeniHal = iMap.getString("MEDENI_HAL");
			sMap.put("SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
			sMap.put("SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
			sMap.put("CINSIYET", cinsiyet);
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KIMLIK_NO", sMap);
			iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_LC_KOD", sMap));
			iMap.put("DOVIZ_KODU", iMap.get("LC_KOD"));
			iMap.put("DOVIZ_KOD", iMap.get("LC_KOD"));
			iMap.put("KREDI_TUTARI", iMap.get("TUTAR"));
			iMap.put("KREDI_VADESI", iMap.get("VADE"));
			iMap.put("KAMP_URUN_ADI", iMap.get("URUN_KAMP_KOD"));
			iMap.put("KOD", iMap.get("KAMP_URUN_ADI"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KRD_TUR_KOD_BOL", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_ORANI"));
			iMap.put("KREDI_TURU", iMap.get("KRD_TUR_KOD"));
			iMap.put("KAMPANYA_KODU", iMap.get("KAMP_URUN_ADI"));
			iMap.put("KREDI_VADE", iMap.get("VADE"));
			iMap.put("ODEME_TIP_KOD", iMap.get("ODEME_TIPI"));
			iMap.put("KATKI_PAYI", iMap.get("MAX_KATKI_PAYI"));
			iMap.put("GECIKME_GUN_SAYISI", new BigDecimal(0));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3183_GET_ODEME_PLANI", iMap));
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_FAIZ_ORANI"));
			iMap.put("KATILIM_BEDELI", iMap.get("MAX_KATKI_PAYI"));
			iMap.put("DOSYA_MASRAFI", iMap.get("MAX_DOSYA_MASRAFI"));
			GMServiceExecuter.execute("BNSPR_TRN3171_CONTROL", iMap);
			oMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			oMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_FAIZ_ORANI"));
			oMap.put("KATILIM_BEDELI", iMap.get("MAX_KATKI_PAYI"));
			oMap.put("DOSYA_MASRAFI", iMap.get("MAX_DOSYA_MASRAFI"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_SAVE_WEB")
	public static Map<?, ?> saveWeb(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			sMap.put("AD", iMap.getString("ANNE_KIZLIK_SOYADI"));
			sMap.put("ALAN_ADI", "AKS");
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);
			String cinsiyet = iMap.getString("CINSIYET");
			String medeniHal = iMap.getString("MEDENI_HAL");
			sMap.put("SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
			sMap.put("SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
			sMap.put("CINSIYET", cinsiyet);
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KIMLIK_NO", sMap);
			iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_LC_KOD", sMap));
			iMap.put("DOVIZ_KODU", iMap.get("LC_KOD"));
			iMap.put("DOVIZ_KOD", iMap.get("LC_KOD"));
			iMap.put("KREDI_TUTARI", iMap.get("TUTAR"));
			iMap.put("KREDI_VADESI", iMap.get("VADE"));
			iMap.put("KAMP_URUN_ADI", iMap.get("URUN_KAMP_KOD"));
			iMap.put("KOD", iMap.get("KAMP_URUN_ADI"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KRD_TUR_KOD_BOL", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_ORANI"));
			iMap.put("KREDI_TURU", iMap.get("KRD_TUR_KOD"));
			iMap.put("KAMPANYA_KODU", iMap.get("KAMP_URUN_ADI"));
			iMap.put("KREDI_VADE", iMap.get("VADE"));
			iMap.put("ODEME_TIP_KOD", iMap.get("ODEME_TIPI"));
			iMap.put("KATKI_PAYI", iMap.get("MAX_KATKI_PAYI"));
			iMap.put("GECIKME_GUN_SAYISI", new BigDecimal(0));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3183_GET_ODEME_PLANI", iMap));
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_FAIZ_ORANI"));
			iMap.put("KATILIM_BEDELI", iMap.get("MAX_KATKI_PAYI"));
			iMap.put("DOSYA_MASRAFI", iMap.get("MAX_DOSYA_MASRAFI"));
			GMServiceExecuter.execute("BNSPR_TRN3171_SAVE", iMap);
			sMap.putAll(iMap);
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", sMap));
			sMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TCK_NO_GET_BAYI_BILGILERI", sMap));

			sMap.put("ISIM", sMap.get("ADI"));
			sMap.put("IKINCI_ISIM", sMap.get("IKINCI_ADI"));
			sMap.put("UYRUK_KOD", sMap.get("UYRUK"));
			sMap.put("CINSIYET_KOD", sMap.get("CINSIYET"));
			sMap.put("MEDENI_HAL_KOD", sMap.get("MEDENI_HAL"));
			sMap.put("AILE_SIRA_NO", sMap.get("NUFUS_AILE_SIRA_NO"));
			sMap.put("CILT_NO", sMap.get("NUFUS_CILT_NO"));
			sMap.put("SIRA_NO", sMap.get("NUFUS_SIRA_NO"));
			sMap.put("KIZLIK_SOYADI", sMap.get("ONCEKI_SOYADI"));
			sMap.put("MESLEK_KOD", sMap.get("MESLEK"));
			sMap.put("EGITIM_KOD", sMap.get("OGRENIM_DURUMU"));
			sMap.put("VERILDIGI_YER", sMap.get("NUF_VERILDIGI_YER"));
			sMap.put("VERILDIGI_TARIH", sMap.get("NUFUS_VERILIS_TARIHI"));
			sMap.put("EV_POSTA_KOD", sMap.get("EV_POSTA_KODU"));
			sMap.put("EV_ADRES", sMap.get("EV_ADRESI"));
			sMap.put("IS_POSTA_KOD", sMap.get("IS_POSTA_KODU"));
			sMap.put("IS_ADRES", sMap.get("IS_ADRESI"));
			sMap.put("MAHALLE_KOY", sMap.get("NUFUS_MAHALLE"));
			sMap.put("IL_KOD", sMap.get("NUFUS_IL_KOD"));
			sMap.put("ILCE_KOD", sMap.get("NUFUS_ILCE_KOD"));
			if (sMap.get("KIMLIK_SERI_NO_KPS") != null && sMap.get("KIMLIK_SIRA_NO_KPS") != null && sMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && sMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO_KPS").concat(sMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
			}
			else if (sMap.get("KIMLIK_SERI_NO") != null && sMap.get("KIMLIK_SIRA_NO") != null && sMap.getString("KIMLIK_SERI_NO").length() != 0 && sMap.getString("KIMLIK_SIRA_NO").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO").concat(sMap.getString("KIMLIK_SIRA_NO").toString()));
			}

			if (sMap.get("MUSTERI_NO") == null) {
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI", sMap));
			}
			else {
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI_GUNCELLE", sMap));
			}

			GMServiceExecuter.execute("BNSPR_TRN3171_STATU_GUNCELLE", sMap);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_EKSIK_BELGE_LIST", sMap));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_SAVE_DEALER")
	public static Map<?, ?> saveDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			oMap.put("DEVAM", "E");
			GMServiceExecuter.executeNT("BNSPR_TRN3171_KEFIL_ONAY", iMap);
			sMap.put("AD", iMap.getString("ANNE_KIZLIK_SOYADI"));
			sMap.put("ALAN_ADI", "AKS");
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);
			String cinsiyet = iMap.getString("CINSIYET");
			// String medeniHal = iMap.getString("MEDENI_HAL");
			sMap.put("SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
			sMap.put("SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
			sMap.put("CINSIYET", cinsiyet);
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KIMLIK_NO", sMap);
			iMap.put("KREDI_TUTARI", iMap.get("TUTAR"));
			iMap.put("KREDI_VADESI", iMap.get("VADE"));
			iMap.put("KAMP_URUN_ADI", iMap.get("URUN_KAMP_KOD"));
			iMap.put("KOD", iMap.get("KAMP_URUN_ADI"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KRD_TUR_KOD_BOL", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_ORANI"));
			iMap.put("KREDI_TURU", iMap.get("KRD_TUR_KOD"));
			iMap.put("KAMPANYA_KODU", iMap.get("KAMP_URUN_ADI"));
			iMap.put("KREDI_VADE", iMap.get("VADE"));
			iMap.put("GECIKME_GUN_SAYISI", new BigDecimal(0));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KEFIL_SORGULAR", iMap));
			if (oMap.getString("DEVAM") != null && oMap.getString("DEVAM").equals("E")) {
				GMServiceExecuter.execute("BNSPR_TRN3171_SAVE", iMap);
			}
			sMap.putAll(iMap);
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", sMap));
			sMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TCK_NO_GET_BAYI_BILGILERI", sMap));

			sMap.put("ISIM", sMap.get("ADI"));
			sMap.put("IKINCI_ISIM", sMap.get("IKINCI_ADI"));
			sMap.put("UYRUK_KOD", sMap.get("UYRUK"));
			sMap.put("CINSIYET_KOD", sMap.get("CINSIYET"));
			sMap.put("MEDENI_HAL_KOD", sMap.get("MEDENI_HAL"));
			sMap.put("AILE_SIRA_NO", sMap.get("NUFUS_AILE_SIRA_NO"));
			sMap.put("CILT_NO", sMap.get("NUFUS_CILT_NO"));
			sMap.put("SIRA_NO", sMap.get("NUFUS_SIRA_NO"));
			sMap.put("KIZLIK_SOYADI", sMap.get("ONCEKI_SOYADI"));
			sMap.put("MESLEK_KOD", sMap.get("MESLEK"));
			sMap.put("EGITIM_KOD", sMap.get("OGRENIM_DURUMU"));
			sMap.put("VERILDIGI_YER", sMap.get("NUF_VERILDIGI_YER"));
			sMap.put("VERILDIGI_TARIH", sMap.get("NUFUS_VERILIS_TARIHI"));
			sMap.put("EV_POSTA_KOD", sMap.get("EV_POSTA_KODU"));
			sMap.put("EV_ADRES", sMap.get("EV_ADRESI"));
			sMap.put("IS_POSTA_KOD", sMap.get("IS_POSTA_KODU"));
			sMap.put("IS_ADRES", sMap.get("IS_ADRESI"));
			sMap.put("MAHALLE_KOY", sMap.get("NUFUS_MAHALLE"));
			sMap.put("IL_KOD", sMap.get("NUFUS_IL_KOD"));
			sMap.put("ILCE_KOD", sMap.get("NUFUS_ILCE_KOD"));
			if (sMap.get("KIMLIK_SERI_NO_KPS") != null && sMap.get("KIMLIK_SIRA_NO_KPS") != null && sMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && sMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO_KPS").concat(sMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
			}
			else if (sMap.get("KIMLIK_SERI_NO") != null && sMap.get("KIMLIK_SIRA_NO") != null && sMap.getString("KIMLIK_SERI_NO").length() != 0 && sMap.getString("KIMLIK_SIRA_NO").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO").concat(sMap.getString("KIMLIK_SIRA_NO").toString()));
			}

			if (sMap.get("MUSTERI_NO") == null) {
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI", sMap));
			}
			else {
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI_GUNCELLE", sMap));
			}
			GMServiceExecuter.execute("BNSPR_TRN3171_STATU_GUNCELLE", sMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_SAVE_DEALER")
	public static Map<?, ?> saveUpdateDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			oMap.put("DEVAM", "E");
			GMServiceExecuter.executeNT("BNSPR_TRN3171_KEFIL_ONAY", iMap);
			sMap.put("AD", iMap.getString("ANNE_KIZLIK_SOYADI"));
			sMap.put("ALAN_ADI", "AKS");
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);
			String cinsiyet = iMap.getString("CINSIYET");
			sMap.put("SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
			sMap.put("SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
			sMap.put("CINSIYET", cinsiyet);
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KIMLIK_NO", sMap);
			iMap.put("KREDI_TUTARI", iMap.get("TUTAR"));
			iMap.put("KREDI_VADESI", iMap.get("VADE"));
			iMap.put("KAMP_URUN_ADI", iMap.get("URUN_KAMP_KOD"));
			iMap.put("KOD", iMap.get("KAMP_URUN_ADI"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KRD_TUR_KOD_BOL", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_ORANI"));
			iMap.put("KREDI_TURU", iMap.get("KRD_TUR_KOD"));
			iMap.put("KAMPANYA_KODU", iMap.get("KAMP_URUN_ADI"));
			iMap.put("KREDI_VADE", iMap.get("VADE"));
			iMap.put("GECIKME_GUN_SAYISI", new BigDecimal(0));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KEFIL_SORGULAR", iMap));
			if (oMap.getString("DEVAM") != null && oMap.getString("DEVAM").equals("E")) {
				GMServiceExecuter.execute("BNSPR_TRN3172_SAVE", iMap);
			}
			sMap.putAll(iMap);
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", sMap));
			sMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TCK_NO_GET_BAYI_BILGILERI", sMap));

			sMap.put("ISIM", sMap.get("ADI"));
			sMap.put("IKINCI_ISIM", sMap.get("IKINCI_ADI"));
			sMap.put("UYRUK_KOD", sMap.get("UYRUK"));
			sMap.put("CINSIYET_KOD", sMap.get("CINSIYET"));
			sMap.put("MEDENI_HAL_KOD", sMap.get("MEDENI_HAL"));
			sMap.put("AILE_SIRA_NO", sMap.get("NUFUS_AILE_SIRA_NO"));
			sMap.put("CILT_NO", sMap.get("NUFUS_CILT_NO"));
			sMap.put("SIRA_NO", sMap.get("NUFUS_SIRA_NO"));
			sMap.put("KIZLIK_SOYADI", sMap.get("ONCEKI_SOYADI"));
			sMap.put("MESLEK_KOD", sMap.get("MESLEK"));
			sMap.put("EGITIM_KOD", sMap.get("OGRENIM_DURUMU"));
			sMap.put("VERILDIGI_YER", sMap.get("NUF_VERILDIGI_YER"));
			sMap.put("VERILDIGI_TARIH", sMap.get("NUFUS_VERILIS_TARIHI"));
			sMap.put("EV_POSTA_KOD", sMap.get("EV_POSTA_KODU"));
			sMap.put("EV_ADRES", sMap.get("EV_ADRESI"));
			sMap.put("IS_POSTA_KOD", sMap.get("IS_POSTA_KODU"));
			sMap.put("IS_ADRES", sMap.get("IS_ADRESI"));
			sMap.put("MAHALLE_KOY", sMap.get("NUFUS_MAHALLE"));
			sMap.put("IL_KOD", sMap.get("NUFUS_IL_KOD"));
			sMap.put("ILCE_KOD", sMap.get("NUFUS_ILCE_KOD"));
			if (sMap.get("KIMLIK_SERI_NO_KPS") != null && sMap.get("KIMLIK_SIRA_NO_KPS") != null && sMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && sMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO_KPS").concat(sMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
			}
			else if (sMap.get("KIMLIK_SERI_NO") != null && sMap.get("KIMLIK_SIRA_NO") != null && sMap.getString("KIMLIK_SERI_NO").length() != 0 && sMap.getString("KIMLIK_SIRA_NO").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO").concat(sMap.getString("KIMLIK_SIRA_NO").toString()));
			}

			if (sMap.get("MUSTERI_NO") == null) {
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI", sMap));
			}
			else {
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI_GUNCELLE", sMap));
			}
			GMServiceExecuter.execute("BNSPR_TRN3171_STATU_GUNCELLE", sMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CONTROL_DEALER")
	public static Map<?, ?> controlDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			oMap.put("DEVAM", "E");
			sMap.put("AD", iMap.getString("ANNE_KIZLIK_SOYADI"));
			sMap.put("ALAN_ADI", "AKS");
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);
			String cinsiyet = iMap.getString("CINSIYET");
			sMap.put("SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
			sMap.put("SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
			sMap.put("CINSIYET", cinsiyet);
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KIMLIK_NO", sMap);
			iMap.put("KREDI_TUTARI", iMap.get("TUTAR"));
			iMap.put("KREDI_VADESI", iMap.get("VADE"));
			iMap.put("KAMP_URUN_ADI", iMap.get("URUN_KAMP_KOD"));
			iMap.put("KOD", iMap.get("KAMP_URUN_ADI"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KRD_TUR_KOD_BOL", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_ORANI"));
			iMap.put("KREDI_TURU", iMap.get("KRD_TUR_KOD"));
			iMap.put("KAMPANYA_KODU", iMap.get("KAMP_URUN_ADI"));
			iMap.put("KREDI_VADE", iMap.get("VADE"));
			iMap.put("GECIKME_GUN_SAYISI", new BigDecimal(0));
			String evAdresi = iMap.getString("EV_ADRESI");
			if (evAdresi != null && !evAdresi.isEmpty()) {
				sMap.put("AD", evAdresi);
				sMap.put("ALAN_ADI", "EV_ADRES");
				GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);
			}
			String isAdresi = iMap.getString("IS_ADRESI");
			if (isAdresi != null && !isAdresi.isEmpty()) {
				sMap.put("AD", isAdresi);
				sMap.put("ALAN_ADI", "IS_ADRES");
				GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);
			}

			// BAYI_KONTROL KAYITLI_MAIL_KONTROL

			String kontrolEh = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap.put("KOD", "BAYI_KONTROL").put("KEY", "KAYITLI_MAIL_KONTROL")).getString("TEXT");

			if ("E".equalsIgnoreCase(kontrolEh)) {

				String email = iMap.getString("EMAIL1") + "@" + iMap.getString("EMAIL2");
				Date birAyOnce = DateUtils.add(new Date(), Calendar.MONTH, -1);

				@SuppressWarnings("unchecked")
				List<Object> kimlikListe = session.createQuery("from BirBasvuruKimlik k,BirBasvuru b where k.basvuruNo = b.basvuruNo and  k.EMail = :email and b.basvuruTarihi > :tar").setParameter("email", email).setParameter("tar", birAyOnce).list();

				if (kimlikListe.size() > 3) {
					iMap.put("HATA_NO", new BigDecimal(5789));
					return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}

			oMap.put("HERSEY_DAHIL_TUTAR", GMServiceExecuter.execute("BNSPR_TRN3171_HERSEY_DAHIL_TUTAR", iMap).get("HERSEY_DAHIL_TUTAR"));
			iMap.put("HERSEY_DAHIL_TUTAR", oMap.get("HERSEY_DAHIL_TUTAR"));

			GMServiceExecuter.executeNT("BNSPR_TRN3171_CONTROL", iMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CONTROL_DEALER_NBSM")
	public static Map<?, ?> controlDealerNbsm(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			oMap.put("HERSEY_DAHIL_TUTAR", GMServiceExecuter.execute("BNSPR_TRN3171_HERSEY_DAHIL_TUTAR", iMap).get("HERSEY_DAHIL_TUTAR"));
			iMap.put("HERSEY_DAHIL_TUTAR", oMap.get("HERSEY_DAHIL_TUTAR"));
			// System.out.println("PerformansTest " + ADCSession.getSessionID() + " " +
			// System.currentTimeMillis()+" G�nderControl Bitti");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GONDER_SORGULAR", iMap));
			oMap.put("CALISMA_SEKLI_KOD", GMServiceExecuter.call("BNSPR_TRN3171_GET_CALISMA_SEKLI_KOD", iMap).get("CALISMA_SEKLI_KOD"));
			if (oMap.get("KEFIL_GEREKLI") != null && oMap.get("KEFIL_GEREKLI").equals("Y")) {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3171_GET_KEFIL_LIST", iMap));
				oMap.put("MAX_KEFIL_SAYISI", "2");
				return oMap;
			}
			if (oMap.getString("DEVAM") != null && oMap.getString("DEVAM").equals("E")) {
				BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				String mesaj = "";
				String cepTel = "";
				BirBasvuruKimlik kimlik = (BirBasvuruKimlik) session.createCriteria(BirBasvuruKimlik.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				cepTel = kimlik.getCepTelAlanKodu().concat(kimlik.getCepTelNo());
				if ("SOZLESME".equalsIgnoreCase(oMap.getString("DURUM")) && birBasvuru.getKrediTur().compareTo(CreditTypes.TASIT.getCreditCode()) == 0) {
					iMap.put("P1", kimlik.getAd());
					iMap.put("P2", birBasvuru.getBasvuruNo());
					iMap.put("P3", birBasvuru.getDosyaMasrafi());
					iMap.put("MESSAGE_NO", new java.math.BigDecimal(5717));
					mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
					if (!"".equals(cepTel) && !"".equals(mesaj)) {
						GMMap smsMap = new GMMap();
						smsMap.put("MSISDN", cepTel);
						smsMap.put("CONTENT", mesaj);
						smsMap.put("HEADER", ".NKOLAY");
						GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsMap).get("RESULT");
					}
				}

				// TY-11999 Yim Pending'e D��en Ba�vurulara Onay SMS'inin D�zenlenmesi
				if (oMap.getString("DURUM").equalsIgnoreCase("SOZLESME") && oMap.getString("SOZLESME_BEKLEME_EH").equals("Y")) {
					GMMap smsMap = new GMMap();
					GMMap getSmsMap = new GMMap();
					getSmsMap.put("P1", kimlik.getSoyad());
					getSmsMap.put("MESSAGE_NO", new java.math.BigDecimal(5931));
					mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", getSmsMap).get("ERROR_MESSAGE");
					smsMap.put("MSISDN", cepTel);
					smsMap.put("CONTENT", mesaj);
					smsMap.put("HEADER", "AktifBank");
					GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsMap).get("RESULT");
				}
				// TY-11999

				// TY-12429
				if ("Y".equalsIgnoreCase(oMap.getString("SGK_BELGE_GEREKLI"))) {
					GMMap smsMap = new GMMap();
					GMMap getSmsMap = new GMMap();
					getSmsMap.put("P1", kimlik.getAd() + " " + kimlik.getSoyad());
					getSmsMap.put("P2", birBasvuru.getBasvuruNo());
					getSmsMap.put("MESSAGE_NO", new java.math.BigDecimal(5941));
					mesaj = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", getSmsMap).get("ERROR_MESSAGE");

					smsMap.put("MSISDN", cepTel);
					smsMap.put("CONTENT", mesaj);
					smsMap.put("HEADER", "AktifBank");
					GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", smsMap).get("RESULT");
				}

				// System.out.println("PerformansTest " + ADCSession.getSessionID() + " " +
				// System.currentTimeMillis()+" G�nderSave Ba�lad�");
				iMap.put("KAMP_URUN_ADI", iMap.get("URUN_KAMP_KOD"));
				oMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", iMap));
				oMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));
				iMap.putAll(oMap);
				iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
				iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_ORANI"));
				GMServiceExecuter.execute("BNSPR_TRN3171_SAVE", iMap);

				/** Upsell Bilgileri **/
				if (iMap.get("UPSELL_LIMIT") != null && iMap.getBigDecimal("UPSELL_LIMIT").compareTo(BigDecimal.ZERO) > 0) {
					if ("U".equals(birBasvuru.getBasvuruTeklifTur())) {
						if (birBasvuru.getSerbestKatkiPayi() != null && birBasvuru.getSerbestKatkiPayi().compareTo(BigDecimal.ZERO) > 0) {
							if (birBasvuru.getIliskiliBasvuruNo() != null) {
								BirBasvuru iliskiliBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", birBasvuru.getIliskiliBasvuruNo())).uniqueResult();
								if (iliskiliBasvuru != null && "IPTAL".equals(iliskiliBasvuru.getDurumKodu())) {
									oMap.put("UPSELL_TIPI", "2");
									oMap.put("UPSELL_LIMIT", birBasvuru.getBasvuruTeklifTutar().subtract(birBasvuru.getTutar()));
									birBasvuru.setBasvuruTeklifTutar(oMap.getBigDecimal("UPSELL_LIMIT"));
									session.saveOrUpdate(birBasvuru);
									session.flush();
								}
							}
							else {
								oMap.put("UPSELL_TIPI", "2");
								oMap.put("UPSELL_LIMIT", birBasvuru.getBasvuruTeklifTutar().subtract(birBasvuru.getTutar()));
								birBasvuru.setBasvuruTeklifTutar(oMap.getBigDecimal("UPSELL_LIMIT"));
								session.saveOrUpdate(birBasvuru);
								session.flush();
							}
						}
						else {
							oMap.put("UPSELL_TIPI", "1");
							oMap.put("UPSELL_LIMIT", birBasvuru.getBasvuruTeklifTutar());
							oMap.put("FAIZSIZ_FINANSMAN", birBasvuru.getFaizsizFinansman());
						}
						GMMap pMap = ConsumerLoanCommonServices.getParamTextLists("BAYI_UPSELL_PARAMETRE", "PARAM_TABLE");
						for (int i = 0; i < pMap.getSize("PARAM_TABLE"); i++) {
							if ("VADE".equals(pMap.getString("PARAM_TABLE", i, "CODE"))) {
								oMap.put("UPSELL_VADE", pMap.getString("PARAM_TABLE", i, "DESCRIPTION"));
							}
							else if ("KAMPANYA_KODU".equals(pMap.getString("PARAM_TABLE", i, "CODE"))) {
								oMap.put("UPSELL_KAMP_KOD", pMap.getString("PARAM_TABLE", i, "DESCRIPTION"));
							}
							else if ("MIN_TUTAR".equals(pMap.getString("PARAM_TABLE", i, "CODE"))) {
								oMap.put("UPSELL_MIN_TUTAR", pMap.getString("PARAM_TABLE", i, "DESCRIPTION"));
							}
						}
					}
				}
				// System.out.println("PerformansTest " + ADCSession.getSessionID() + " " +
				// System.currentTimeMillis()+" G�nderSave Bitti");
			}
			sMap.putAll(iMap);
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", sMap));
			sMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TCK_NO_GET_BAYI_BILGILERI", sMap));

			sMap.put("KANAL_KODU", iMap.getString("KANAL_KOD"));
			sMap.put("KANAL_ALT_KODU", iMap.getString("KANAL_ALT_KOD"));
			sMap.put("ISIM", sMap.get("ADI"));
			sMap.put("IKINCI_ISIM", sMap.get("IKINCI_ADI"));
			sMap.put("UYRUK_KOD", sMap.get("UYRUK"));
			sMap.put("CINSIYET_KOD", sMap.get("CINSIYET"));
			sMap.put("MEDENI_HAL_KOD", sMap.get("MEDENI_HAL"));
			sMap.put("AILE_SIRA_NO", sMap.get("NUFUS_AILE_SIRA_NO"));
			sMap.put("CILT_NO", sMap.get("NUFUS_CILT_NO"));
			sMap.put("SIRA_NO", sMap.get("NUFUS_SIRA_NO"));
			sMap.put("KIZLIK_SOYADI", sMap.get("ONCEKI_SOYADI"));
			sMap.put("MESLEK_KOD", sMap.get("MESLEK"));
			sMap.put("EGITIM_KOD", sMap.get("OGRENIM_DURUMU"));
			sMap.put("VERILDIGI_YER", sMap.get("NUF_VERILDIGI_YER"));
			sMap.put("VERILDIGI_TARIH", sMap.get("NUFUS_VERILIS_TARIHI"));
			sMap.put("EV_POSTA_KOD", sMap.get("EV_POSTA_KODU"));
			sMap.put("EV_ADRES", sMap.get("EV_ADRESI"));
			sMap.put("IS_POSTA_KOD", sMap.get("IS_POSTA_KODU"));
			sMap.put("IS_ADRES", sMap.get("IS_ADRESI"));
			sMap.put("MAHALLE_KOY", sMap.get("NUFUS_MAHALLE"));
			sMap.put("IL_KOD", sMap.get("NUFUS_IL_KOD"));
			sMap.put("ILCE_KOD", sMap.get("NUFUS_ILCE_KOD"));
			if (sMap.get("KIMLIK_SERI_NO_KPS") != null && sMap.get("KIMLIK_SIRA_NO_KPS") != null && sMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && sMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO_KPS").concat(sMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
			}
			else if (sMap.get("KIMLIK_SERI_NO") != null && sMap.get("KIMLIK_SIRA_NO") != null && sMap.getString("KIMLIK_SERI_NO").length() != 0 && sMap.getString("KIMLIK_SIRA_NO").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO").concat(sMap.getString("KIMLIK_SIRA_NO").toString()));
			}

			if (sMap.get("MUSTERI_NO") == null) {
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI", sMap));
			}
			else {
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI_GUNCELLE", sMap));
			}
			GMServiceExecuter.execute("BNSPR_TRN3171_STATU_GUNCELLE", sMap);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GARANTOR_ONAYI_SOR", iMap));

			if (oMap.getString("GARANTOR_ONAYI_SOR") != null && oMap.getString("GARANTOR_ONAYI_SOR").equals("O")) {
				BirBasvuruGorusTx birBasvuruGorusTx = (BirBasvuruGorusTx) session.createCriteria(BirBasvuruGorusTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.gorusKod", "10")).uniqueResult();
				if (birBasvuruGorusTx == null) {
					birBasvuruGorusTx = new BirBasvuruGorusTx();
				}
				BirBasvuruGorusTxId Id = new BirBasvuruGorusTxId();
				Id.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
				Id.setGorusKod("10");
				Id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				birBasvuruGorusTx.setEH("E");
				birBasvuruGorusTx.setId(Id);
				session.saveOrUpdate(birBasvuruGorusTx);
				session.flush();
			}

			if (StringUtils.isEmpty(oMap.getString("UPSELL_TIPI"))) {
				try {
					/** SOBF Mail ile gonderilmesi **/
					GMMap tMap = new GMMap();
					tMap.put("EPOSTA", iMap.getString("EMAIL1") + "@" + iMap.getString("EMAIL2"));
					tMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
					tMap.put("MUSTERI_NO", sMap.get("MUSTERI_NO"));
					tMap.put("BELGE_TURU", "SOBF");
					tMap.put("GONDERIM_TIPI", "E");
					tMap.put("DYS_TRANSFER", true);
					GMServiceExecuter.execute("BNSPR_QRY3956_SAVE", tMap);
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
			else {
				/** Upsell teklif sms **/
				GMMap tMap = new GMMap();
				tMap.put("MSISDN", iMap.getString("CEP_TEL_KOD") + iMap.getString("CEP_TEL_NO"));
				if ("1".equals(oMap.getString("UPSELL_TIPI"))) {
					if ("E".equals(oMap.getString("FAIZSIZ_FINANSMAN"))) {
						tMap.put("MESSAGE_NO", 5628);
					}
					else {
						tMap.put("MESSAGE_NO", 5352);
					}
					tMap.put("P1", iMap.getBigDecimal("TUTAR"));
					tMap.put("P2", oMap.getBigDecimal("UPSELL_VADE"));
					tMap.put("P3", oMap.getBigDecimal("UPSELL_LIMIT"));
				}
				else {
					tMap.put("MESSAGE_NO", 5358);
					tMap.put("P1", oMap.getBigDecimal("UPSELL_LIMIT"));
					tMap.put("P2", oMap.getBigDecimal("UPSELL_VADE"));
				}
				tMap.put("CONTENT", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", tMap).get("ERROR_MESSAGE"));
				GMServiceExecuter.execute("BNSPR_SMS_SEND_SMS", tMap).get("RESULT");
			}

			// System.out.println("PerformansTest " + ADCSession.getSessionID() + " " +
			// System.currentTimeMillis()+" G�nder Bitti");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_CONTROL_DEALER")
	public static Map<?, ?> controlUpdateDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			oMap.put("DEVAM", "E");
			sMap.put("AD", iMap.getString("ANNE_KIZLIK_SOYADI"));
			sMap.put("ALAN_ADI", "AKS");
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);
			String cinsiyet = iMap.getString("CINSIYET");
			// String medeniHal = iMap.getString("MEDENI_HAL");
			sMap.put("SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
			sMap.put("SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
			sMap.put("CINSIYET", cinsiyet);
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KIMLIK_NO", sMap);
			iMap.put("KREDI_TUTARI", iMap.get("TUTAR"));
			iMap.put("KREDI_VADESI", iMap.get("VADE"));
			iMap.put("KAMP_URUN_ADI", iMap.get("URUN_KAMP_KOD"));
			iMap.put("KOD", iMap.get("KAMP_URUN_ADI"));
			// oMap.put("HERSEY_DAHIL_TUTAR" , GMServiceExecuter.execute("BNSPR_TRN3171_HERSEY_DAHIL_TUTAR" , iMap).get("HERSEY_DAHIL_TUTAR"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KRD_TUR_KOD_BOL", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_ORANI"));
			iMap.put("KREDI_TURU", iMap.get("KRD_TUR_KOD"));
			iMap.put("KAMPANYA_KODU", iMap.get("KAMP_URUN_ADI"));
			iMap.put("KREDI_VADE", iMap.get("VADE"));
			iMap.put("GECIKME_GUN_SAYISI", new BigDecimal(0));
			String evAdresi = iMap.getString("EV_ADRESI");
			if (evAdresi != null && !evAdresi.isEmpty()) {
				sMap.put("AD", evAdresi);
				sMap.put("ALAN_ADI", "EV_ADRES");
				GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);
			}
			String isAdresi = iMap.getString("IS_ADRESI");
			if (isAdresi != null && !isAdresi.isEmpty()) {
				sMap.put("AD", isAdresi);
				sMap.put("ALAN_ADI", "IS_ADRES");
				GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);
			}
			GMServiceExecuter.executeNT("BNSPR_TRN3171_CONTROL", iMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_CONTROL_DEALER_NBSM")
	public static Map<?, ?> updateControlDealerNbsm(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			oMap.put("HERSEY_DAHIL_TUTAR", GMServiceExecuter.execute("BNSPR_TRN3171_HERSEY_DAHIL_TUTAR", iMap).get("HERSEY_DAHIL_TUTAR"));
			iMap.put("HERSEY_DAHIL_TUTAR", oMap.get("HERSEY_DAHIL_TUTAR"));
			iMap.put("NBSMSIZ_KEFIL", iMap.get("KEFIL_GEREKLI_MI"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GONDER_SORGULAR", iMap));
			oMap.put("CALISMA_SEKLI_KOD", GMServiceExecuter.call("BNSPR_TRN3171_GET_CALISMA_SEKLI_KOD", iMap).get("CALISMA_SEKLI_KOD"));
			if ("E".equals(iMap.getString("KEFIL_GEREKLI_MI"))) {
				oMap.put("KEFIL_GEREKLI", "Y");
			}
			if (oMap.get("KEFIL_GEREKLI") != null && oMap.get("KEFIL_GEREKLI").equals("Y")) {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3171_GET_KEFIL_LIST", iMap));
				oMap.put("MAX_KEFIL_SAYISI", "2");
				return oMap;
			}
			if (oMap.getString("DEVAM") != null && oMap.getString("DEVAM").equals("E")) {
				iMap.put("KAMP_URUN_ADI", iMap.get("URUN_KAMP_KOD"));
				oMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", iMap));
				oMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));
				iMap.putAll(oMap);
				iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
				iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_ORANI"));
				GMServiceExecuter.execute("BNSPR_TRN3172_SAVE", iMap);
			}
			sMap.putAll(iMap);
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", sMap));
			sMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TCK_NO_GET_BAYI_BILGILERI", sMap));

			sMap.put("ISIM", sMap.get("ADI"));
			sMap.put("IKINCI_ISIM", sMap.get("IKINCI_ADI"));
			sMap.put("UYRUK_KOD", sMap.get("UYRUK"));
			sMap.put("CINSIYET_KOD", sMap.get("CINSIYET"));
			sMap.put("MEDENI_HAL_KOD", sMap.get("MEDENI_HAL"));
			sMap.put("AILE_SIRA_NO", sMap.get("NUFUS_AILE_SIRA_NO"));
			sMap.put("CILT_NO", sMap.get("NUFUS_CILT_NO"));
			sMap.put("SIRA_NO", sMap.get("NUFUS_SIRA_NO"));
			sMap.put("KIZLIK_SOYADI", sMap.get("ONCEKI_SOYADI"));
			sMap.put("MESLEK_KOD", sMap.get("MESLEK"));
			sMap.put("EGITIM_KOD", sMap.get("OGRENIM_DURUMU"));
			sMap.put("VERILDIGI_YER", sMap.get("NUF_VERILDIGI_YER"));
			sMap.put("VERILDIGI_TARIH", sMap.get("NUFUS_VERILIS_TARIHI"));
			sMap.put("EV_POSTA_KOD", sMap.get("EV_POSTA_KODU"));
			sMap.put("EV_ADRES", sMap.get("EV_ADRESI"));
			sMap.put("IS_POSTA_KOD", sMap.get("IS_POSTA_KODU"));
			sMap.put("IS_ADRES", sMap.get("IS_ADRESI"));
			sMap.put("MAHALLE_KOY", sMap.get("NUFUS_MAHALLE"));
			sMap.put("IL_KOD", sMap.get("NUFUS_IL_KOD"));
			sMap.put("ILCE_KOD", sMap.get("NUFUS_ILCE_KOD"));
			if (sMap.get("KIMLIK_SERI_NO_KPS") != null && sMap.get("KIMLIK_SIRA_NO_KPS") != null && sMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && sMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO_KPS").concat(sMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
			}
			else if (sMap.get("KIMLIK_SERI_NO") != null && sMap.get("KIMLIK_SIRA_NO") != null && sMap.getString("KIMLIK_SERI_NO").length() != 0 && sMap.getString("KIMLIK_SIRA_NO").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO").concat(sMap.getString("KIMLIK_SIRA_NO").toString()));
			}

			if (sMap.get("MUSTERI_NO") == null) {
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI", sMap));
			}
			else {
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI_GUNCELLE", sMap));
			}
			GMServiceExecuter.execute("BNSPR_TRN3171_STATU_GUNCELLE", sMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_CONTROL_KEFIL_DEALER")
	public static Map<?, ?> conrolKefil(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			sMap.put("TABLE_NAME", "BIR_BASVURU_KEFIL");
			sMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", sMap));
			iMap.put("KEFIL_NO", sMap.get("ID"));
			oMap.put("KEFIL_NO", sMap.get("ID"));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KEFIL_TCKN", iMap);
			GMServiceExecuter.execute("BNSPR_TRN3171_CONTROL_KEFIL", iMap);
			sMap.putAll(iMap);
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", sMap));
			sMap.put("TCK_NO", iMap.get("TC_KIMLIK_NO"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TCK_NO_GET_BAYI_BILGILERI", sMap));

			sMap.put("ISIM", sMap.get("ADI"));
			sMap.put("IKINCI_ISIM", sMap.get("IKINCI_ADI"));
			sMap.put("UYRUK_KOD", sMap.get("UYRUK"));
			sMap.put("CINSIYET_KOD", sMap.get("CINSIYET"));
			sMap.put("MEDENI_HAL_KOD", sMap.get("MEDENI_HAL"));
			sMap.put("AILE_SIRA_NO", sMap.get("NUFUS_AILE_SIRA_NO"));
			sMap.put("CILT_NO", sMap.get("NUFUS_CILT_NO"));
			sMap.put("SIRA_NO", sMap.get("NUFUS_SIRA_NO"));
			sMap.put("KIZLIK_SOYADI", sMap.get("ONCEKI_SOYADI"));
			sMap.put("MESLEK_KOD", sMap.get("MESLEK"));
			sMap.put("EGITIM_KOD", sMap.get("OGRENIM_DURUMU"));
			sMap.put("VERILDIGI_YER", sMap.get("NUF_VERILDIGI_YER"));
			sMap.put("VERILDIGI_TARIH", sMap.get("NUFUS_VERILIS_TARIHI"));
			sMap.put("EV_POSTA_KOD", sMap.get("EV_POSTA_KODU"));
			sMap.put("EV_ADRES", sMap.get("EV_ADRESI"));
			sMap.put("IS_POSTA_KOD", sMap.get("IS_POSTA_KODU"));
			sMap.put("IS_ADRES", sMap.get("IS_ADRESI"));
			sMap.put("MAHALLE_KOY", sMap.get("NUFUS_MAHALLE"));
			sMap.put("IL_KOD", sMap.get("NUFUS_IL_KOD"));
			sMap.put("ILCE_KOD", sMap.get("NUFUS_ILCE_KOD"));
			if (sMap.get("KIMLIK_SERI_NO_KPS") != null && sMap.get("KIMLIK_SIRA_NO_KPS") != null && sMap.getString("KIMLIK_SERI_NO_KPS").length() != 0 && sMap.getString("KIMLIK_SIRA_NO_KPS").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO_KPS").concat(sMap.getString("KIMLIK_SIRA_NO_KPS").toString()));
			}
			else if (sMap.get("KIMLIK_SERI_NO") != null && sMap.get("KIMLIK_SIRA_NO") != null && sMap.getString("KIMLIK_SERI_NO").length() != 0 && sMap.getString("KIMLIK_SIRA_NO").length() != 0) {
				sMap.put("NUFUS_CUZDANI_SERI_NO", sMap.getString("KIMLIK_SERI_NO").concat(sMap.getString("KIMLIK_SIRA_NO").toString()));
			}

			if (sMap.get("MUSTERI_NO") == null) {
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI", sMap));
			}
			else {
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KONTAKT_MUSTERI_GUNCELLE", sMap));
			}

			GMServiceExecuter.execute("BNSPR_TRN3171_STATU_GUNCELLE_KEFIL", sMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_ODEME_PLANI_WEB")
	public static Map<?, ?> getOdemePlaniWeb(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KRD_TUR_KOD_BOL", iMap));
			iMap.put("KAMP_URUN_ADI", iMap.get("KOD"));
			iMap.put("KAMPANYA_KODU", iMap.get("KOD"));
			iMap.put("KREDI_TURU", iMap.get("KRD_TUR_KOD"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_LC_KOD", iMap));
			iMap.put("DOVIZ_KOD", iMap.get("LC_KOD"));
			iMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));
			iMap.put("KREDI_TUTARI", iMap.get("TUTAR"));
			iMap.put("KREDI_VADE", iMap.get("VADE"));
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			iMap.put("KATKI_PAYI", iMap.get("MAX_KATKI_PAYI"));
			iMap.put("GECIKME_GUN_SAYISI", new BigDecimal(0));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3183_GET_ODEME_PLANI", iMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_ODEME_PLANI_DEALER")
	public static Map<?, ?> getOdemePlaniDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KRD_TUR_KOD_BOL", iMap));
			iMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			
			/** risk bazli fiyatlama **/
			if("E".equals(iMap.getString("RISK_BAZLI_FIYATLAMA")) && StringUtils.isNotEmpty(iMap.getString("SEGMENT"))){
				Session session = DAOSession.getSession("BNSPRDal");
				BirRiskFiyatlamaTanim birRiskFiyatlamaTanim = (BirRiskFiyatlamaTanim) session.createCriteria(BirRiskFiyatlamaTanim.class).add(Restrictions.eq("id.kampKod", iMap.getBigDecimal("KAMP_URUN_ADI"))).add(Restrictions.eq("id.segment", iMap.getString("SEGMENT"))).uniqueResult();
				
				if(birRiskFiyatlamaTanim != null) {
					iMap.put("FAIZ_ORAN", iMap.getBigDecimal("FAIZ_ORAN").add(((birRiskFiyatlamaTanim.getBps().divide(new BigDecimal(100)))).setScale(2, RoundingMode.HALF_DOWN)));
				}
			}
			
			iMap.put("DOSYA_MASRAFI", iMap.get("MAX_DOSYA_MASRAFI"));
			if (iMap.get("FAIZ_ORAN") != null) {
				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3199_GECIKME_FAIZ_ORAN", iMap));
			}

			if (!iMap.containsKey("KATKI_PAYI") || iMap.get("KATKI_PAYI") == null) {
				GMMap otMap = new GMMap();
				otMap.putAll(iMap);
				otMap.put("KOD", iMap.get("KAMPANYA_KODU"));
				otMap.put("VADE", iMap.get("KREDI_VADE"));
				otMap.put("TUTAR", iMap.get("KREDI_TUTARI"));
				otMap.put("KRD_TUR_KOD", iMap.get("KREDI_TURU"));
				otMap.put("DOVIZ_KODU", iMap.get("DOVIZ_KOD"));
				otMap.put("IS_FOR_CALC_RATIO", "true");
				otMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_TIPI_DEALER", otMap));
				iMap.put("KATKI_PAYI", otMap.get("MAX_KATKI_PAYI"));
			}

			/** oteleme gun sayisi bilgilerini hesapla (suanda web kanalinda kullaniliyor olacak) **/
			if (iMap.containsKey("TAKSIT_GUNU") && iMap.get("TAKSIT_GUNU") != null) {
				iMap.putAll(GMServiceExecuter.execute("BNSPR_CL_WEB_GET_SIMULATION_INFO", iMap));
			}

			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3183_GET_ODEME_PLANI", iMap));
			iMap.put("MAX_DOSYA_MASRAFI", oMap.get("MAX_DOSYA_MASRAFI"));
			iMap.put("DOSYA_MASRAFI", iMap.get("MAX_DOSYA_MASRAFI"));
			oMap.putAll(iMap);
			if (oMap.get("MAX_DOSYA_MASRAFI") != null) {
				oMap.put("HESABA_YATACAK_TUTAR", iMap.getBigDecimal("TUTAR").subtract(oMap.getBigDecimal("MAX_DOSYA_MASRAFI")));
			}
			if (iMap.get("FARK_FAIZI") != null) {
				oMap.put("HESABA_YATACAK_TUTAR", oMap.getBigDecimal("HESABA_YATACAK_TUTAR").subtract(iMap.getBigDecimal("FARK_FAIZI")));
			}
			if (oMap.getSize("ODEME_PLANI") > 0) {
				oMap.put("AYLIK_TAKSIT", oMap.get("ODEME_PLANI", 0, "OP_TAKSIT_TUTAR"));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_ODEME_TIPI_DEALER")
	public static Map<?, ?> getOdemeTipiDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KRD_TUR_KOD_BOL", iMap));

			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMP_KNL_KOD", iMap));
			oMap.put("KAMP_KNL_KOD", iMap.get("KAMP_KNL_KOD"));

			oMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", iMap));

			iMap.put("DOVIZ_KODU", iMap.get("DOVIZ_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", iMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_INITIALIZE_WEB")
	public static Map<?, ?> initializeWeb(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_LC_KOD", iMap));
			iMap.put("DOVIZ_KODU", oMap.get("LC_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_BASVURU_NO", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ILLER", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_DHF_ILLER", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_CALISMA_SEKILLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_OGRENIM_DURUMLARI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_FAALIYET_ALANLARI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ISYERI_MULKIYET_TURLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_VERGI_DAIRESI_ILLERI", iMap));
			oMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_VERGI_DAIRESI_ILLERI", iMap));
			iMap.put("TABLE_NAME", "BANKA_LIST");
			iMap.put("LOV", "3181/LOV_BANKA");
			iMap.put("VALUE", "BANKA_TCMB_KODU");
			iMap.put("NAME", "BANKA_ADI");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_LOV", iMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_INITIALIZE_CREDIT_DEALER")
	public static Map<?, ?> initializeCreditDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap));
			oMap.put("KANAL_ALT_KOD", iMap.get("KANAL_ALT_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_BASVURU_NO", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_CINSIYET_TURLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_MEDENI_HAL_TURLERI", iMap));
			iMap.put("KANAL_KODU", oMap.get("KANAL_KOD"));
			iMap.put("KANAL_ALT_KODU", oMap.get("KANAL_ALT_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_BAGLI_SATICI_ADI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KREDI_TURLERI", iMap));
			iMap.put("KRD_TUR_KOD", oMap.getString("KREDI_TUR_LIST", 0, "VALUE"));
			iMap.put("KANAL_KODU", oMap.getString("KANAL_KOD"));
			iMap.put("KANAL_ALT_KODU", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("SATICI_KOD", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("SATICI_KODU", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("DOVIZ_KODU", "TRY");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_DOVIZ_CINSLERI", iMap));
			iMap.put("BOS_ALAN", "E");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_DEALER_GET_BAYI_PERSONEL_LIST", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GARANTOR_MU", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI", iMap));
			if (oMap.getString("DEFAULT_URUN_KAMP") != null) {
				sMap.put("URUN_KAMP_KOD", oMap.get("DEFAULT_URUN_KAMP"));
				sMap.put("KRD_TUR_KOD", iMap.get("KRD_TUR_KOD"));
				sMap.put("DOVIZ_KODU", iMap.get("DOVIZ_KODU"));
				sMap.put("KANAL_KOD", iMap.get("KANAL_KODU"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_TESLIM_DURUM_DEALER", sMap));
			}
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_CALISMA_SEKILLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ILLER", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_OGRENIM_DURUMLARI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_FAALIYET_ALANLARI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ISYERI_MULKIYET_TURLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_VERGI_DAIRESI_ILLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_IKAMET_TURLERI", iMap));
			oMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_BAYI_IL_ILCE_KOD", iMap));
			iMap.put("IL_KODU", oMap.getString("BAYI_IL_KOD"));
			iMap.put("IL_KOD", oMap.getString("BAYI_IL_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ILCELER", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_TELEFON_KOD", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_OLUMLU_GORUS", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_OLUMSUZ_GORUS", iMap));
			int olumlu_size = oMap.getSize("OLUMLU_GORUS");
			int olumsuz_size = oMap.getSize("OLUMSUZ_GORUS");
			if (olumsuz_size > 0) {
				Set<?> keySet = oMap.getMap("OLUMSUZ_GORUS", 0).keySet();
				for (int i = 0; i < olumsuz_size; i++) {
					for (Object key : keySet) {
						String keyName = (String) key;
						Object keyValue = oMap.get("OLUMSUZ_GORUS", i, keyName);
						oMap.put("OLUMLU_GORUS", olumlu_size + i, keyName, keyValue);
					}
				}
			}
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_YENI_GORUS", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KEFIL_GORUS", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GORUS", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GEC_TESLIM_NEDENLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_TESLIM_KIME", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_BAYI_URUN", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KIMLIK2", iMap));
			// oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GEC_TESLIM_NEDEN_SOR", iMap));
			// oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_BASKA_KIMLIK_SOR", iMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_INITIALIZE_UPDATE_DEALER")
	public static Map<?, ?> initializeUpdateDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap));
			oMap.put("KANAL_ALT_KOD", iMap.get("KANAL_ALT_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_CINSIYET_TURLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_MEDENI_HAL_TURLERI", iMap));
			iMap.put("KANAL_KODU", oMap.get("KANAL_KOD"));
			iMap.put("KANAL_ALT_KODU", oMap.get("KANAL_ALT_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KREDI_TURLERI", iMap));
			iMap.put("KRD_TUR_KOD", oMap.getString("KREDI_TUR_LIST", 0, "VALUE"));
			iMap.put("KANAL_KODU", oMap.getString("KANAL_KOD"));
			iMap.put("KANAL_ALT_KODU", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("SATICI_KOD", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("SATICI_KODU", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("DOVIZ_KODU", "TRY");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_DOVIZ_CINSLERI", iMap));
			iMap.put("BOS_ALAN", "E");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_DEALER_GET_BAYI_PERSONEL_LIST", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_CALISMA_SEKILLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ILLER", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_OGRENIM_DURUMLARI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_FAALIYET_ALANLARI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ISYERI_MULKIYET_TURLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_VERGI_DAIRESI_ILLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_IKAMET_TURLERI", iMap));
			oMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_BAYI_IL_ILCE_KOD", iMap));
			iMap.put("IL_KODU", oMap.getString("BAYI_IL_KOD"));
			iMap.put("IL_KOD", oMap.getString("BAYI_IL_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ILCELER", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_TELEFON_KOD", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_GET_ONAY_STATU_LIST", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_BAGLI_SATICI_ADI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_TESLIM_KIME", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_BAYI_URUN", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GEC_TESLIM_NEDENLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KIMLIK2", iMap));
			// oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GEC_TESLIM_NEDEN_SOR", iMap));
			// oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_BASKA_KIMLIK_SOR", iMap));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3173_INITIALIZE_VIEW_DEALER")
	public static Map<?, ?> initializeViewDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap));
			oMap.put("KANAL_ALT_KOD", iMap.get("KANAL_ALT_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_CINSIYET_TURLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_MEDENI_HAL_TURLERI", iMap));
			iMap.put("KANAL_KODU", oMap.get("KANAL_KOD"));
			iMap.put("KANAL_ALT_KODU", oMap.get("KANAL_ALT_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KREDI_TURLERI", iMap));
			iMap.put("KRD_TUR_KOD", oMap.getString("KREDI_TUR_LIST", 0, "VALUE"));
			iMap.put("KANAL_KODU", oMap.getString("KANAL_KOD"));
			iMap.put("KANAL_ALT_KODU", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("SATICI_KOD", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("SATICI_KODU", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("DOVIZ_KODU", "TRY");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_DOVIZ_CINSLERI", iMap));
			iMap.put("BOS_ALAN", "E");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_DEALER_GET_BAYI_PERSONEL_LIST", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_CALISMA_SEKILLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ILLER", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_OGRENIM_DURUMLARI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_FAALIYET_ALANLARI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ISYERI_MULKIYET_TURLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_VERGI_DAIRESI_ILLERI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_IKAMET_TURLERI", iMap));
			oMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KEFIL_YAKINLIK_ALL", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3173_ONAY_STATU_LIST", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_BAGLI_SATICI_ADI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3173_ALINACAK_AKSIYON_LIST", iMap));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_INITIALIZE_PAYMENT_DEALER")
	public static Map<?, ?> initializePaymentDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap));
			oMap.put("KANAL_ALT_KOD", iMap.get("KANAL_ALT_KOD"));
			iMap.put("KANAL_KODU", oMap.get("KANAL_KOD"));
			iMap.put("KANAL_ALT_KODU", oMap.get("KANAL_ALT_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KREDI_TURLERI", iMap));
			iMap.put("KRD_TUR_KOD", oMap.getString("KREDI_TUR_LIST", 0, "VALUE"));
			iMap.put("KANAL_KODU", oMap.getString("KANAL_KOD"));
			iMap.put("KANAL_ALT_KODU", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("SATICI_KOD", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("SATICI_KODU", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("DOVIZ_KODU", "TRY");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_DOVIZ_CINSLERI", iMap));
			iMap.put("BOS_ALAN", "E");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI", iMap));
			oMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
			iMap.put("KOD", "BIR_FARK_FAIZ_SEKLI_KOD");
			iMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));
			oMap.put("FAIZ_ODEME_LIST", iMap.get("RESULTS"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_INITIALIZE_CONTRACT_DEALER")
	public static Map<?, ?> initializeContractDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_KANAL_KOD", iMap));
			oMap.put("KANAL_ALT_KOD", iMap.get("KANAL_ALT_KOD"));
			iMap.put("KANAL_KODU", oMap.get("KANAL_KOD"));
			iMap.put("KANAL_ALT_KODU", oMap.get("KANAL_ALT_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KREDI_TURLERI", iMap));
			iMap.put("KRD_TUR_KOD", oMap.getString("KREDI_TUR_LIST", 0, "VALUE"));
			iMap.put("KANAL_KODU", oMap.getString("KANAL_KOD"));
			iMap.put("KANAL_ALT_KODU", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("SATICI_KOD", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("SATICI_KODU", oMap.getString("KANAL_ALT_KOD"));
			iMap.put("DOVIZ_KODU", "TRY");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_DOVIZ_CINSLERI", iMap));
			iMap.put("BOS_ALAN", "E");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI", iMap));
			oMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
			iMap.put("LOV", "3181/LOV_BANKA");
			iMap.put("VALUE", "BANKA_TCMB_KODU");
			iMap.put("NAME", "BANKA_ADI");
			iMap.put("TABLE_NAME", "BANKA_LIST");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_LOV", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_ALINACAK_AKSIYON_LIST", iMap));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_UPDATE_LIST_DEALER")
	public static Map<?, ?> getUpdateList(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			String tcKimlikNo = iMap.getString("TC_KIMLIK_NO");
			String basvuruNo = iMap.getString("BASVURU_NO", "");
			BigDecimal valid = new BigDecimal(1);

			if (tcKimlikNo != null && !tcKimlikNo.equals("")) {
				sMap.put("TCKN", tcKimlikNo);
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_CHECK_TCKN", sMap));
				if (sMap.getBigDecimal("SONUC").compareTo(new BigDecimal(0)) == 0) {
					sMap.clear();
					sMap.put("HATA_NO", "1049");
					sMap.put("P1", tcKimlikNo);
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
				}
			}

			if (!basvuruNo.equals("")) {
				sMap.clear();
				sMap.put("BASVURU_NO", basvuruNo);
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_CHECK_BASVURU_NO", sMap));
				valid = sMap.getBigDecimal("SONUC");
			}

			if (valid.compareTo(new BigDecimal(0)) == 0) {
				sMap.clear();
				sMap.put("HATA_NO", "1050");
				sMap.put("P1", basvuruNo);
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
			}
			else {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_BASVURU_GUNCELLE_LIST", iMap));
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY3173_VIEW_LIST_DEALER")
	public static Map<?, ?> getViewList(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			String tcKimlikNo = iMap.getString("TC_KIMLIK_NO", "");

			if (!tcKimlikNo.equals("")) {
				sMap.put("TCKN", tcKimlikNo);
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_CHECK_TCKN", sMap));
				if (sMap.getBigDecimal("SONUC").compareTo(new BigDecimal(0)) == 0) {
					sMap.clear();
					sMap.put("HATA_NO", "1049");
					sMap.put("P1", tcKimlikNo);
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
				}
			}

			iMap.put("IPTAL", true);

			oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3173_BASVURU_IZLEME_LIST", iMap));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3181_BASVURU_GUNCELLE_LIST_DAELER")
	public static Map<?, ?> getContractList(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			String tcKimlikNo = iMap.getString("TC_KIMLIK_NO");

			if (!tcKimlikNo.equals("")) {
				sMap.put("TCKN", tcKimlikNo);
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_CHECK_TCKN", sMap));
				if (sMap.getBigDecimal("SONUC").compareTo(new BigDecimal(0)) == 0) {
					sMap.clear();
					sMap.put("HATA_NO", "1049");
					sMap.put("P1", tcKimlikNo);
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
				}
			}
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_BASVURU_GUNCELLE_LIST", iMap));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_KEFIL_BILGILERI_DEALER")
	public static Map<?, ?> getKefilBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KEFIL_BILGILERI", iMap));
			if (!(oMap.getString("K_EV_IL") == null || oMap.getString("K_EV_IL").equals("") || oMap.getString("K_EV_IL").equals(" ") || oMap.getString("K_EV_IL").equals("X"))) {
				iMap.put("IL_KODU", oMap.get("K_EV_IL"));
				iMap.put("BOS_ALAN", "E");
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ILCELER", iMap));
				oMap.put("EV_ILCELER_LIST", oMap.get("ILCELER_LIST"));
			}
			if (!(oMap.getString("K_IS_IL") == null || oMap.getString("K_IS_IL").equals("") || oMap.getString("K_IS_IL").equals(" ") || oMap.getString("K_IS_IL").equals("X"))) {
				iMap.put("IL_KODU", oMap.get("K_IS_IL"));
				iMap.put("BOS_ALAN", "E");
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ILCELER", iMap));
				oMap.put("IS_ILCELER_LIST", oMap.get("ILCELER_LIST"));
			}
			if (!(oMap.getString("K_ISYERI_VERGI_DAIRESI_IL") == null || oMap.getString("K_ISYERI_VERGI_DAIRESI_IL").equals("") || oMap.getString("K_ISYERI_VERGI_DAIRESI_IL").equals(" ") || oMap.getString("K_ISYERI_VERGI_DAIRESI_IL").equals("X"))) {
				iMap.put("VERGI_DAIRESI_IL", oMap.get("K_ISYERI_VERGI_DAIRESI_IL"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_VERGI_DAIRESI_ADLARI", iMap));
			}
			if (!(oMap.getString("K_OGRENIM_DURUMU") == null || oMap.getString("K_OGRENIM_DURUMU").equals("") || oMap.getString("K_OGRENIM_DURUMU").equals(" ") || oMap.getString("K_OGRENIM_DURUMU").equals("X") || oMap.getString("K_CALISMA_SEKLI") == null || oMap.getString("K_CALISMA_SEKLI").equals("") || oMap.getString("K_CALISMA_SEKLI").equals(" ") || oMap.getString("K_CALISMA_SEKLI").equals("X")) || oMap.getString("K_DOGUM_TARIHI") == null || oMap.getString("K_DOGUM_TARIHI").equals("") || oMap.getString("K_DOGUM_TARIHI").equals(" ") || oMap.getString("K_DOGUM_TARIHI").equals("X")) {
				iMap.put("EGITIM_KOD", oMap.get("K_OGRENIM_DURUMU"));
				iMap.put("CALISMA_SEKLI", oMap.get("K_CALISMA_SEKLI"));
				iMap.put("DOGUM_TARIHI", oMap.get("K_DOGUM_TARIHI"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_MESLEKLER", iMap));
			}
			if (!(oMap.getString("K_MESLEK") == null || oMap.getString("K_MESLEK").equals("") || oMap.getString("K_MESLEK").equals(" ") || oMap.getString("K_MESLEK").equals("X"))) {
				iMap.put("MESLEK_KOD", oMap.get("K_MESLEK"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_UNVAN_TURLERI", iMap));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_GET_BASVURU_DEALER")
	public static Map<?, ?> getUpdateBasvuruBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.putAll(iMap);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_GET_BASVURU", iMap));
			oMap.put("CHANGE_KATKI_PAYI", "KANALIADE".equals(oMap.getString("DURUM_KODU")));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_GET_BASVURU_DETAY", iMap));
			if (oMap.get("TRX_NO") == null) {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
				iMap.put("TRX_NO", oMap.get("TRX_NO"));
				oMap.put("NEW_TRANSACTION", "E");
			}
			if (oMap.get("EVE_TESLIM_URUN") != null && oMap.get("EVE_TESLIM_URUN").equals("E")) {
				oMap.put("TESLIM_E", true);
				oMap.put("TESLIM_H", false);
				oMap.put("FATURALI_IHTIYAC_MI", "E");
			}
			else if (oMap.get("EVE_TESLIM_URUN") != null && oMap.get("EVE_TESLIM_URUN").equals("H")) {
				oMap.put("TESLIM_E", false);
				oMap.put("TESLIM_H", true);
				oMap.put("FATURALI_IHTIYAC_MI", "E");
			}
			else {
				oMap.put("TESLIM_E", false);
				oMap.put("TESLIM_H", false);
				oMap.put("FATURALI_IHTIYAC_MI", "H");
			}
			if (!(oMap.getString("EV_IL") == null || oMap.getString("EV_IL").equals("") || oMap.getString("EV_IL").equals(" ") || oMap.getString("EV_IL").equals("X"))) {
				iMap.put("IL_KODU", oMap.get("EV_IL"));
				iMap.put("BOS_ALAN", "E");
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ILCELER", iMap));
				oMap.put("EV_ILCELER_LIST", oMap.get("ILCELER_LIST"));
			}
			if (!(oMap.getString("IS_IL") == null || oMap.getString("IS_IL").equals("") || oMap.getString("IS_IL").equals(" ") || oMap.getString("IS_IL").equals("X"))) {
				iMap.put("IL_KODU", oMap.get("IS_IL"));
				iMap.put("BOS_ALAN", "E");
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ILCELER", iMap));
				oMap.put("IS_ILCELER_LIST", oMap.get("ILCELER_LIST"));
			}
			if (!(oMap.getString("ISYERI_VERGI_DAIRESI_IL") == null || oMap.getString("ISYERI_VERGI_DAIRESI_IL").equals("") || oMap.getString("ISYERI_VERGI_DAIRESI_IL").equals(" ") || oMap.getString("ISYERI_VERGI_DAIRESI_IL").equals("X"))) {
				iMap.put("VERGI_DAIRESI_IL", oMap.get("ISYERI_VERGI_DAIRESI_IL"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_VERGI_DAIRESI_ADLARI", iMap));
			}
			if (!(oMap.getString("OGRENIM_DURUMU") == null || oMap.getString("OGRENIM_DURUMU").equals("") || oMap.getString("OGRENIM_DURUMU").equals(" ") || oMap.getString("OGRENIM_DURUMU").equals("X") || oMap.getString("CALISMA_SEKLI") == null || oMap.getString("CALISMA_SEKLI").equals("") || oMap.getString("CALISMA_SEKLI").equals(" ") || oMap.getString("CALISMA_SEKLI").equals("X") || oMap.getString("DOGUM_TARIHI") == null || oMap.getString("DOGUM_TARIHI").equals("") || oMap.getString("DOGUM_TARIHI").equals(" ") || oMap.getString("DOGUM_TARIHI").equals("X"))) {
				iMap.put("EGITIM_KOD", oMap.get("OGRENIM_DURUMU"));
				iMap.put("CALISMA_SEKLI", oMap.get("CALISMA_SEKLI"));
				iMap.put("DOGUM_TARIHI", oMap.get("DOGUM_TARIHI"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_MESLEKLER", iMap));
			}
			if (!(oMap.getString("MESLEK") == null || oMap.getString("MESLEK").equals("") || oMap.getString("MESLEK").equals(" ") || oMap.getString("MESLEK").equals("X"))) {
				iMap.put("MESLEK_KOD", oMap.get("MESLEK"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_UNVAN_TURLERI", iMap));
			}
			iMap.put("KANAL_KODU", oMap.get("KANAL_KODU"));
			iMap.put("KRD_TUR_KOD", oMap.get("KRD_TUR_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_DOVIZ_CINSLERI", iMap));
			oMap.put("DOVIZ_KODU", oMap.get("DOVIZ_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GARANTOR_MU", oMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_URUN_KAMPANYA_TURLERI", oMap));
			oMap.put("KAMP_URUN_ADI", oMap.get("URUN_KAMP_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", oMap));
			if (!(!(oMap.getString("ODEME_TIPI") == null || oMap.getString("ODEME_TIPI").equals("") || oMap.getString("ODEME_TIPI").equals(" ") || oMap.getString("ODEME_TIPI").equals("X")))) {
				oMap.put("ODEME_TIPI", oMap.get("DEFAULT_ODEME_TIP"));
			}
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_GET_GORUS", oMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_GET_OLUMLU_GORUS", oMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_GET_OLUMSUZ_GORUS", oMap));
			int olumlu_size = oMap.getSize("OLUMLU_GORUS");
			int olumsuz_size = oMap.getSize("OLUMSUZ_GORUS");
			if (olumsuz_size > 0) {
				Set<?> keySet = oMap.getMap("OLUMSUZ_GORUS", 0).keySet();
				for (int i = 0; i < olumsuz_size; i++) {
					for (Object key : keySet) {
						String keyName = (String) key;
						Object keyValue = oMap.get("OLUMSUZ_GORUS", i, keyName);
						oMap.put("OLUMLU_GORUS", olumlu_size + i, keyName, keyValue);
					}
				}
			}
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_GET_YENI_GORUS", oMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3172_GET_KEFIL_GORUS", oMap));
			oMap.put("OLUMLU_GORUS_SAYISI", oMap.getInt("OLUMLU_GORUS_SAYISI") + oMap.getInt("KEFIL_GORUS_SAYISI"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GECERLI_TEMINATLAR", oMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_TEMINATLAR", oMap));
			oMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", oMap));
			oMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", oMap));
			iMap.put("ACTION", "VIEW");
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY3171_GET_KEFIL_LIST", iMap));
			oMap.put("KEFIL_LIST", iMap.get("RESULTS"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_TESLIM_DURUM_DEALER", oMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GECERLI_SIGORTA_URUNLERI", oMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3181_GET_INFO_BY_BASVURU_NO_DEALER")
	public static Map<?, ?> getContractBasvuruBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_GET_INFO_BY_BASVURU_NO", iMap));

			String func = "{? = call PKG_TRN3181.F_ERKEN_BELGE_BILGI_DEGISTI_EH(?)}";
			Object[] inputValues = new Object[2];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			oMap.put("BELGE_BILGI_DEGISTI_EH", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_GET_DIST_AKTARIM_BILGI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_GET_DEFAULT_FAIZ_ODEME_SEKLI", iMap));
			oMap.put("ILK_TAKSIT_TARIHI_ESKI", oMap.get("ILK_TAKSIT_TARIHI"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_KIMLIK_TEYIT_GEREKLI_MI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_MUSTERI_PERSONEL_MI", oMap));
			iMap.put("KRD_TUR_KOD", oMap.get("KREDI_TUR"));
			// oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_GET_KKDF_ORANI" , iMap));
			// oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_GET_BSMV_ORANI" , iMap));
			if (!(oMap.getString("BANKA") == null || oMap.getString("BANKA").equals("") || oMap.getString("BANKA").equals(" ") || oMap.getString("BANKA").equals("X"))) {
				iMap.put("LOV", "3181/LOV_SEHIR");
				iMap.put("VALUE", "IL_KODU");
				iMap.put("NAME", "IL_ADI");
				iMap.put("TABLE_NAME", "BANKA_IL_MODEL");
				iMap.put("P1", oMap.getString("BANKA"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_LOV", iMap));
			}
			if (!(oMap.getString("IL") == null || oMap.getString("IL").equals("") || oMap.getString("IL").equals(" ") || oMap.getString("IL").equals("X"))) {
				iMap.put("LOV", "3181/LOV_SUBE");
				iMap.put("VALUE", "SUBE_KODU");
				iMap.put("NAME", "SUBE_ADI");
				iMap.put("TABLE_NAME", "BANKA_SUBE_MODEL");
				iMap.put("P1", oMap.getString("BANKA"));
				iMap.put("P2", oMap.getString("IL"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_LOV", iMap));
			}
			sMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			sMap.put("SOZLESME_TARIHI", iMap.get("BANKA_TARIHI"));
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_GET_ILK_TAKSIT_TARIHI", sMap));
			oMap.put("ILK_TAKSIT_TARIHI", sMap.get("ILK_TAKSIT_TARIHI"));
			oMap.put("TATIL_FARKI", sMap.get("TATIL_FARKI"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_PTT_EMEKLISI_MI", sMap));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3172_TEMP_SAVE_DEALER")
	public static Map<?, ?> saveTempUpdateDealer(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		try {
			oMap.put("DEVAM", "E");

			sMap.put("SERI_NO", iMap.getString("KIMLIK_SERI_NO"));
			sMap.put("SIRA_NO", iMap.getString("KIMLIK_SIRA_NO"));
			sMap.put("CINSIYET", iMap.getString("CINSIYET"));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KIMLIK_NO", sMap);

			sMap.put("AD", iMap.getString("ANNE_KIZLIK_SOYADI"));
			sMap.put("ALAN_ADI", "AKS");
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_AD", sMap);

			sMap.put("KOD", iMap.getString("CEP_TEL_KOD"));
			sMap.put("TEL_NO", iMap.getString("CEP_TEL_NO"));
			sMap.put("ALAN_ADI", "CEP_TELEFONU");
			sMap.put("GSM", "E");
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_TELEFON", sMap);

			sMap.put("CALISMA_SEKLI", iMap.getString("CALISMA_SEKLI"));
			sMap.put("KRD_TUR_KOD", iMap.getBigDecimal("KRD_TUR_KOD"));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_CALISMA_SEKLI", sMap);

			sMap.put("KAMP_URUN_ADI", iMap.getString("KAMP_URUN_ADI"));
			sMap.put("DOVIZ_KODU", iMap.getString("DOVIZ_KODU"));
			sMap.put("KREDI_TUTARI", iMap.getBigDecimal("TUTAR"));
			sMap.put("KREDI_VADESI", iMap.getBigDecimal("VADE"));
			sMap.put("KANAL_KOD", iMap.getBigDecimal("KANAL_KOD"));
			GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KREDI_MIN_MAX_DEGER", sMap);

			if (iMap.getBigDecimal("PERSONEL") == null) {
				sMap.put("HATA_NO", "1159");
				sMap.put("P1", "sat�� personelini");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
			}

			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_TESLIM_DURUM_DEALER", iMap));
			if (iMap.get("FATURALI_IHTIYAC_MI") != null && iMap.get("FATURALI_IHTIYAC_MI").equals("E")) {
				if (iMap.get("EVE_TESLIM_URUN") == null) {
					sMap.put("HATA_NO", "1159");
					sMap.put("P1", (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", new GMMap().put("KOD", "3171").put("KEY", "EVE_TESLIMATLI_URUN")).get("TEXT"));
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
				}
				else if ("E".equals(iMap.getString("EVE_TESLIM_URUN"))) {
					if (iMap.getDate("TESLIMAT_TARIHI") != null && iMap.getDate("TESLIMAT_TARIHI").before(iMap.getDate("BANKA_TARIHI"))) {
						sMap.put("HATA_NO", "1867");
						SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");
						sMap.put("P1", outputFormat.format(iMap.getDate("BANKA_TARIHI")));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
					}
					else if (iMap.getDate("TESLIMAT_TARIHI") == null && iMap.getBoolean("TESLIMAT_TARIHI_BOS")) {
						sMap.put("HATA_NO", "993");
						sMap.put("P1", "teslimat tarihi");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);

					}
					else if (iMap.getDate("TESLIMAT_TARIHI") == null && !iMap.getBoolean("TESLIMAT_TARIHI_BOS")) {
						sMap.put("HATA_NO", "1866");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
					}
				}
			}
			// TY-1792 ao
			/*if (!"0".equals(iMap.getString("GORUS_HATA_NO"))) {
				sMap.put("HATA_NO", iMap.get("GORUS_HATA_NO"));
				sMap.put("P1", iMap.get("GORUS_HATA_P1"));
				sMap.put("P2", iMap.get("GORUS_HATA_P2"));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", sMap);
			}*/

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMP_KNL_KOD", iMap));
			iMap.put("KAMP_KNL_KOD", oMap.get("KAMP_KNL_KOD"));
			iMap.put("KAMP_KOD", oMap.get("KAMP_KOD"));

			sMap.put("KAMP_KOD", oMap.get("KAMP_KOD"));
			sMap.put("TCKN", iMap.getString("TC_KIMLIK_NO"));
			GMServiceExecuter.execute("BNSPR_TRN3171_KAMPANYA_KULLANILABILIR_MI", sMap);

			sMap.put("TUTAR", iMap.getBigDecimal("TUTAR"));
			sMap.put("VADE", iMap.getBigDecimal("VADE"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_FAIZ_ORANI", sMap));
			iMap.put("FAIZ_ORANI", oMap.get("FAIZ_ORANI"));

			sMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			sMap.put("CEP_TEL_ALAN", iMap.getString("CEP_TEL_KOD"));
			sMap.put("CEP_TEL_NO", iMap.getString("CEP_TEL_NO"));
			sMap.put("TC_KIMLIK_NO", iMap.getString("TC_KIMLIK_NO"));
			sMap.put("KANAL_KODU", iMap.getString("KANAL_KODU"));
			sMap.put("KANAL_ALT_KODU", iMap.getString("KANAL_ALT_KOD"));
			sMap.put("KREDI_TURU", iMap.getString("KRD_TUR_KOD"));
			GMServiceExecuter.execute("BNSPR_TRN3171_BASVURU_GIRIS_CAPRAZ_SORGU", sMap);

			oMap.put("APS_YAPILDIMI", iMap.getString("APS_YAPILDIMI"));
			oMap.put("APS_TRX_YAPILDIMI", iMap.getString("APS_TRX_YAPILDIMI"));
			if ("H".equals(iMap.getString("APS_TRX_YAPILDIMI")) && "E".equals(iMap.getString("NEW_TRANSACTION"))) {
				GMMap apsMap = new GMMap();
				apsMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3171_APS_SORGULAMA", iMap));
				iMap.put("APS_YAPILDIMI", apsMap.getString("APS_YAPILDIMI"));
				oMap.put("APS_YAPILDIMI", apsMap.getString("APS_YAPILDIMI"));
				oMap.put("APS_TRX_YAPILDIMI", apsMap.getString("APS_YAPILDIMI"));
			}

			sMap.put("KOD", iMap.get("KAMP_URUN_ADI"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KRD_TUR_KOD_BOL", sMap));
			iMap.putAll(oMap);
			oMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", iMap));
			oMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap));
			iMap.putAll(oMap);
			iMap.put("FAIZ_ORANI", iMap.get("FAIZ_ORAN"));
			iMap.put("SOZLESME_FAIZI", iMap.get("SOZLESME_ORANI"));
			if (iMap.getBoolean("CHANGE_KATKI_PAYI") || (iMap.getBigDecimal("MAX_KATKI_PAYI_ILK") == null && iMap.getBigDecimal("MAX_KATKI_PAYI") != null) || (iMap.getBigDecimal("MAX_KATKI_PAYI_ILK") != null && iMap.getBigDecimal("MAX_KATKI_PAYI") == null) || !(iMap.getBigDecimal("MAX_KATKI_PAYI_ILK") != null && iMap.getBigDecimal("MAX_KATKI_PAYI_ILK").equals(iMap.getBigDecimal("MAX_KATKI_PAYI"))) || (iMap.getBigDecimal("MIN_KATKI_PAYI_ILK") == null && iMap.getBigDecimal("MAX_KATKI_PAYI") != null) || (iMap.getBigDecimal("MIN_KATKI_PAYI_ILK") != null && iMap.getBigDecimal("MIN_KATKI_PAYI") == null) || !(iMap.getBigDecimal("MIN_KATKI_PAYI_ILK") != null && iMap.getBigDecimal("MIN_KATKI_PAYI_ILK").equals(iMap.getBigDecimal("MIN_KATKI_PAYI"))) || (iMap.getString("SERBEST_KATKI_PAYI_ILK") == null && iMap.getString("SERBEST_KATKI_PAYI") != null) || (iMap.getString("SERBEST_KATKI_PAYI_ILK") != null && iMap.getString("SERBEST_KATKI_PAYI") == null) || !(iMap.getString("SERBEST_KATKI_PAYI_ILK") != null && iMap.getString("SERBEST_KATKI_PAYI_ILK").equals(iMap.getString("SERBEST_KATKI_PAYI"))) || (iMap.getString("KATKI_PAYI_KIMDEN_ILK") == null && iMap.getString("KATKI_PAYI_KIMDEN") != null) || (iMap.getString("KATKI_PAYI_KIMDEN_ILK") != null && iMap.getString("KATKI_PAYI_KIMDEN") == null) || !(iMap.getString("KATKI_PAYI_KIMDEN_ILK") != null && iMap.getString("KATKI_PAYI_KIMDEN_ILK").equals(iMap.getString("KATKI_PAYI_KIMDEN")))) {
				iMap.put("KATILIM_BEDELI", iMap.get("MAX_KATKI_PAYI"));
				oMap.put("KATKI_PAYI_DEGISTI", "E");
			}
			else {
				oMap.put("KATKI_PAYI_DEGISTI", "H");
			}
			oMap.put("CHANGE_KATKI_PAYI", false);
			if ((iMap.getBigDecimal("MAX_DOSYA_MASRAFI_ILK") == null && iMap.getBigDecimal("MAX_DOSYA_MASRAFI") != null) || (iMap.getBigDecimal("MAX_DOSYA_MASRAFI_ILK") != null && iMap.getBigDecimal("MAX_DOSYA_MASRAFI") == null) || !(iMap.getBigDecimal("MAX_DOSYA_MASRAFI_ILK") != null && iMap.getBigDecimal("MAX_DOSYA_MASRAFI_ILK").equals(iMap.getBigDecimal("MAX_DOSYA_MASRAFI"))) || (iMap.getBigDecimal("MIN_DOSYA_MASRAFI_ILK") == null && iMap.getBigDecimal("MAX_DOSYA_MASRAFI") != null) || (iMap.getBigDecimal("MIN_DOSYA_MASRAFI_ILK") != null && iMap.getBigDecimal("MIN_DOSYA_MASRAFI") == null) || !(iMap.getBigDecimal("MIN_DOSYA_MASRAFI_ILK") != null && iMap.getBigDecimal("MIN_DOSYA_MASRAFI_ILK").equals(iMap.getBigDecimal("MIN_DOSYA_MASRAFI"))) || (iMap.getString("DOSYA_MASRAF_TIPI_ILK") == null && iMap.getString("DOSYA_MASRAF_TIPI") != null) || (iMap.getString("DOSYA_MASRAF_TIPI_ILK") != null && iMap.getString("DOSYA_MASRAF_TIPI") == null) || !(iMap.getString("DOSYA_MASRAF_TIPI_ILK") != null && iMap.getString("DOSYA_MASRAF_TIPI_ILK").equals(iMap.getString("DOSYA_MASRAF_TIPI")))) {
				iMap.put("DOSYA_MASRAFI", iMap.get("MAX_DOSYA_MASRAFI"));
				oMap.put("DOSYA_MASRAFI_DEGISTI", "E");
			}
			else {
				oMap.put("DOSYA_MASRAFI_DEGISTI", "H");
			}
			if ("C".equals(iMap.getString("CALISMA_SEKLI"))) {
				iMap.put("AYLIK_GELIR", new BigDecimal(0));
			}
			iMap.put("EKRAN_NO", "3172");

			List<?> nuLList = null;
			String nuLL = null;
			if (iMap.getString("OGRENIM_DURUMU") != null) {
				GMMap meslekMap = new GMMap();
				meslekMap.put("EGITIM_KOD", iMap.get("OGRENIM_DURUMU"));
				meslekMap.put("CALISMA_SEKLI", iMap.get("CALISMA_SEKLI"));
				meslekMap.put("BANKA_TARIHI", iMap.get("BANKA_TARIHI"));
				meslekMap.put("DOGUM_TARIHI", iMap.get("DOGUM_TARIHI"));
				meslekMap.put("BOS_ALAN", "E");
				oMap.put("MESLEK_LIST", GMServiceExecuter.call("BNSPR_TRN3171_GET_MESLEKLER", meslekMap).get("MESLEK_LIST"));
				if (iMap.getString("MESLEK") != null && oMap.get("MESLEK_LIST") != null) {
					boolean meslekVar = false;
					for (int i = 0; i < oMap.getSize("MESLEK_LIST"); i++) {
						if (iMap.getString("MESLEK").equals(oMap.getString("MESLEK_LIST", i, "VALUE"))) {
							meslekVar = true;
							break;
						}
					}
					if (meslekVar) {
						oMap.put("MESLEK", iMap.get("MESLEK"));
						GMMap unvanMap = new GMMap();
						unvanMap.put("MESLEK_KOD", iMap.get("MESLEK"));
						oMap.put("UNVAN_TURLERI_LIST", GMServiceExecuter.call("BNSPR_TRN3171_GET_UNVAN_TURLERI", unvanMap).get("UNVAN_TURLERI_LIST"));
						if (iMap.getString("UNVANI") != null && oMap.get("UNVAN_TURLERI_LIST") != null) {
							boolean unvanVar = false;
							for (int i = 0; i < oMap.getSize("UNVAN_TURLERI_LIST"); i++) {
								if (iMap.getString("UNVANI").equals(oMap.getString("UNVAN_TURLERI_LIST", i, "VALUE"))) {
									unvanVar = true;
									break;
								}
							}
							if (unvanVar) {
								oMap.put("UNVANI", iMap.get("UNVANI"));
							}
							else {
								oMap.put("UNVANI", nuLL);
							}
						}
						else {
							oMap.put("UNVANI", nuLL);
						}
					}
					else {
						oMap.put("MESLEK", nuLL);
						oMap.put("UNVANI", nuLL);
						oMap.put("UNVAN_TURLERI_LIST", nuLList);
					}
				}
				else {
					oMap.put("MESLEK", nuLL);
					oMap.put("UNVANI", nuLL);
					oMap.put("UNVAN_TURLERI_LIST", nuLList);
				}

			}
			else {
				oMap.put("MESLEK", nuLL);
				oMap.put("MESLEK_LIST", nuLList);
				oMap.put("UNVANI", nuLL);
				oMap.put("UNVAN_TURLERI_LIST", nuLList);
			}
			iMap.put("MESLEK", oMap.get("MESLEK"));
			iMap.put("UNVANI", oMap.get("UNVANI"));

			GMServiceExecuter.executeNT("BNSPR_TRN3171_SAVE_TEMP", iMap);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_DEVAM_SORGULAR", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_ODEME_GRUPLAR_URUN", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GECERLI_TEMINATLAR", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_TEMINATLAR", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KEFIL_YAKINLIK", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GECERLI_SIGORTA_URUNLERI", oMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_SIGORTA_URUNLERI", oMap));
			oMap.put("HERSEY_DAHIL_TUTAR", GMServiceExecuter.execute("BNSPR_TRN3171_HERSEY_DAHIL_TUTAR", iMap).get("HERSEY_DAHIL_TUTAR"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_DEALER_GET_DELAER_INFO")
	public static GMMap getDealerInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");

			BirSatici satici = (BirSatici) session.get(BirSatici.class, iMap.getBigDecimal("SATICI_KOD"));

			if (satici != null) {
				oMap.put("BAYI_KOD", satici.getKod());
				oMap.put("BAYI_ADI", satici.getSaticiAdi());
				oMap.put("BAYI_TEL_ALANKOD", satici.getAlanKodTel());
				oMap.put("BAYI_TEL", satici.getTelNo());
				oMap.put("BAYI_ADRES", satici.getAdres());

				oMap.put("SATICI_TIPI", satici.getSaticiTipKod());

				oMap.put("MUSTERI_NO", satici.getMusteriNo());
				oMap.put("SUBE_MUSTERI_NO", satici.getSubeMusteriNo());
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_DEALER_GET_DEALER_EMPLOYEE_INFO")
	public static GMMap getDealerEmployeeInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("select c.kod, c.adi, c.soyadi, c.cep_alan_kod, c.cep_tel_no, c.dogum_tarihi from bir_satici_calisan c where c.kod = ?");
			stmt.setBigDecimal(1, iMap.getBigDecimal("CALISAN_KOD"));

			rSet = stmt.executeQuery();
			if (rSet.next()) {
				oMap.put("CALISAN_KOD", rSet.getLong(1));
				oMap.put("CALISAN_ADI", rSet.getString(2));
				oMap.put("CALISAN_SOYADI", rSet.getString(3));
				oMap.put("CALISAN_CEP_TEL_ALANKOD", rSet.getString(4));
				oMap.put("CALISAN_CEP_TEL", rSet.getString(5));
				oMap.put("CALISAN_DOGUM_TARIHI", rSet.getDate(6));
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	@GraymoundService("BNSPR_DEALER_GET_BAYI_BILGILERI")
	public static GMMap getBayiAdi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("select s.musteri_no, s.satici_tip_kod, s.sube_musteri_no, s.satici_adi, s.alan_kod_tel, s.tel_no,c.cep_alan_kod, c.cep_tel_no, c.satici_kod, c.dogum_tarihi, s.yetki_seviye_kod from bir_satici s, bir_satici_calisan c where s.kod=c.satici_kod and c.kod = ?");
			// stmt.setBigDecimal(1 , iMap.getBigDecimal("SATICI_KOD"));
			stmt.setBigDecimal(1, iMap.getBigDecimal("CALISAN_KOD"));
			rSet = stmt.executeQuery();
			if (rSet.next()) {
				oMap.put("MUSTERI_NO", rSet.getString("MUSTERI_NO"));
				oMap.put("SATICI_TIP_KOD", rSet.getString("SATICI_TIP_KOD"));
				oMap.put("SUBE_MUSTERI_NO", rSet.getString("SUBE_MUSTERI_NO"));
				oMap.put("BAYI_ADI", rSet.getString("SATICI_ADI"));
				oMap.put("BAYI_TEL_ALANKOD", rSet.getString("ALAN_KOD_TEL"));
				oMap.put("BAYI_TEL", rSet.getString("TEL_NO"));
				oMap.put("CALISAN_TEL_ALANKOD", rSet.getString("CEP_ALAN_KOD"));
				oMap.put("CALISAN_TEL", rSet.getString("CEP_TEL_NO"));
				oMap.put("BAYI_KOD", rSet.getString("SATICI_KOD"));
				oMap.put("CALISAN_DOGUM_TARIHI", rSet.getDate("DOGUM_TARIHI"));
				oMap.put("BAYI_YETKI_KOD", rSet.getString("YETKI_SEVIYE_KOD"));
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	@GraymoundService("BNSPR_DEALER_GET_ALL_BAYI_BILGILERI")
	public static GMMap getAllBayiAdi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("select * from bnspr.bir_satici s where s.satici_tip_kod <> 'D' and s.drm='G' ");
			rSet = stmt.executeQuery();

			return DALUtil.rSetResults(rSet, "BAYI_LIST");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	@GraymoundService("BNSPR_DEALER_GET_BAYI_PERSONEL_LIST")
	public static GMMap getBayiPersonelList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select c.kod,c.adi ||' ' ||c.soyadi from bir_satici_calisan c where c.durum='ONAY' and c.cal_statu_kod<>'K'  and (c.satici_kod in " + "(select satici_kod from bir_satici_calisan c where c.durum='ONAY' and c.cal_statu_kod<>'K'  and c.kod=?)or c.satici_kod=?)");
			// stmt =
			// conn.prepareStatement("select c.kod,c.adi ||' ' ||c.soyadi from bir_satici_calisan c where c.durum='ONAY' and c.cal_statu_kod<>'K'  and c.satici_kod=? ");
			stmt.setBigDecimal(1, iMap.getBigDecimal("SATICI_KOD"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KOD"));
			rSet = stmt.executeQuery();

			DALUtil.fillComboBox(oMap, "PERSONEL_LIST", iMap.getString("BOS_ALAN") != null && iMap.getString("BOS_ALAN").equals("E"), rSet);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_TESLIM_DURUM_DEALER")
	public static GMMap getTeslimDurum(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			iMap.put("KOD", iMap.get("URUN_KAMP_KOD"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_KRD_TUR_KOD_BOL", iMap));
			if (iMap.getString("URUN_KAMP_KOD") != null) {
				stmt = conn.prepareCall("{? = call pkg_bireysel.FaturaliIhtiyacKredisiMi(?,?,?,?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setBigDecimal(2, iMap.getString("URUN_KAMP_KOD").contains("-") ? null : iMap.getBigDecimal("URUN_KAMP_KOD"));
				stmt.setBigDecimal(3, iMap.getBigDecimal("KRD_TUR_KOD"));
				stmt.setBigDecimal(4, iMap.getBigDecimal("KRD_TUR_ALT_KOD"));
				stmt.setBigDecimal(5, iMap.getBigDecimal("KRD_TUR_ALT_KOD2"));

				stmt.execute();
				oMap.put("FATURALI_IHTIYAC_MI", stmt.getString(1));
			}
			iMap.put("KAMP_URUN_ADI", iMap.get("URUN_KAMP_KOD"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KREDI_MIN_MAX_DEGER", iMap));

			// oMap.put("FATURALI_IHTIYAC_MI","E");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_BAYI_STATU_KONTROL")
	public static GMMap bayiKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_BASVURU.BayiStatuKontrol(?)}");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KODU"));

			stmt.execute();
			oMap.put("HATA_NO", stmt.getBigDecimal(1));
			stmt.close();
			if (oMap.getBigDecimal("HATA_NO").compareTo(new BigDecimal(0)) == 0) {
				stmt = conn.prepareCall("{? = call PKG_BASVURU.BayiCalisanStatuKontrol(?,?)}");
				stmt.registerOutParameter(1, Types.DECIMAL);
				stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KODU"));
				stmt.setString(3, iMap.getString("KULLANICI_KODU"));
				stmt.execute();
				oMap.put("HATA_NO", stmt.getBigDecimal(1));
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_BAYI_ANA_EKRAN_BILGI")
	public static GMMap getBuAyKrediAdet(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_basvuru.Bayi_Ana_Ekran_Bilgi(?) }");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("SATICI_KOD"));

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			GMMap oMap = DALUtil.rSetMap(rSet);

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3173_GET_BELGE_DEALER")
	public static GMMap getBelgeDealer(GMMap iMap) {
		String asilBelgeGerekliEh = "";
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			iMap.put("KOD", "BIR_BELGE_HATA");

			List<?> belge = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.or(Restrictions.ne("belgeAlinmaAdim", "KS"), Restrictions.isNull("belgeAlinmaAdim"))).addOrder(Order.asc("id.kimden")).addOrder(Order.asc("belgeAdi")).list();
			String tableName = "TBL_BELGE";
			for (int row = 0; row < belge.size(); row++) {
				BirBasvuruBelge birBasvuruBelge = (BirBasvuruBelge) belge.get(row);
				String dokumanKod = birBasvuruBelge.getId().getDokumanKod();
				oMap.put(tableName, row, "BELGE_KODU", dokumanKod);
				oMap.put(tableName, row, "BELGE_KIMDEN", LovHelper.diLov(birBasvuruBelge.getId().getKimden(), "3181/LOV_BASVURU_KISI", "ACIKLAMA"));
				oMap.put(tableName, row, "BELGE_ADI", LovHelper.diLov(dokumanKod, "3181/LOV_BELGE", "ACIKLAMA"));
				oMap.put(tableName, row, "ALINDI", GuimlUtil.convertToCheckBoxSelected(birBasvuruBelge.getAlindi()));
				oMap.put(tableName, row, "BELGE_KONTROL", birBasvuruBelge.getBelgeKontrol());
				oMap.put(tableName, row, "BELGE_GELIS_TARIHI", birBasvuruBelge.getBelgeGelisTarihi());
				oMap.put(tableName, row, "KONTROL_NEDENI", birBasvuruBelge.getKontrolNedeni());
				iMap.put("KEY", birBasvuruBelge.getBelgeHata());
				oMap.put(tableName, row, "BELGE_HATA", iMap.getString("KEY") != null ? GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT", iMap).getString("TEXT") : "");
				oMap.put(tableName, row, "BELGE_ALINMA_ADIM", birBasvuruBelge.getBelgeAlinmaAdim());
				asilBelgeGerekliEh = LovHelper.diLov(dokumanKod, "3182/LOV_BELGE_EKLE_KOD", "ASIL_BELGE_GEREKLI_EH");
				oMap.put(tableName, row, "ELEKTRONIK_BELGE_ALINABILIR", "H".equals(asilBelgeGerekliEh) ? "E" : "H");

				BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
				Object[] inputValues = new Object[4];
				int inputParams = 0;
				inputValues[inputParams++] = BnsprType.NUMBER;
				inputValues[inputParams++] = birBasvuru.getSaticiKod();
				inputValues[inputParams++] = BnsprType.STRING;
				inputValues[inputParams++] = birBasvuru.getKanalKodu();

				BigDecimal orjEvrakGonSuresi = (BigDecimal) DALUtil.callOracleFunction("{? = call PKG_BIREYSEL.SaticiOrjinalEvrakGonSure(?, ?)}", BnsprType.NUMBER, inputValues);
				Date belgeTamamlamaTarihi = null;
				if (birBasvuru.getSozlesmeTarihi() != null) {
					GMMap tempMap = new GMMap();
					tempMap.put("TARIH", birBasvuru.getSozlesmeTarihi());
					tempMap.put("GUN", orjEvrakGonSuresi == null ? BigDecimal.ZERO : orjEvrakGonSuresi);
					belgeTamamlamaTarihi = (GMServiceExecuter.call("BNSPR_COMMON_SONRAKI_GUN", tempMap).getDate("TARIH"));
				}
				oMap.put(tableName, row, "BELGE_TAMAMLAMA_TARIHI", belgeTamamlamaTarihi);
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3181_CHECK_ILK_TAKSIT_TARIHI_DEALER")
	public static GMMap checkIlkTaksitTarihi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN3181.kontrol_ilk_taksit_tarihi(?,?)}");
			stmt.setDate(1, new java.sql.Date(iMap.getDate("ILK_TAKSIT_TARIHI_KUL").getTime()));
			stmt.setDate(2, new java.sql.Date(iMap.getDate("ILK_TAKSIT_TARIHI").getTime()));
			stmt.execute();
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3181_SOZLESME_BELGELERINI_AL_DEALER")
	public static GMMap sozlesmeBelgeleriniAl(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();

			if ("H".equals(iMap.getString("DIST_AKTARIM_EH"))) {
				iMap.put("HATA_NO", "2160");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_SOZLESME_BELGELERINI_AL", iMap));
			if ((oMap.getString("MESSAGE") == null || "".equals(oMap.getString("MESSAGE"))) && oMap.getString("OTOMATIK_KULLANDIRIM") == null) {
				if (!"E".equals(oMap.getString("BAYI_ERKEN_BELGE_ALIMI"))) {
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_UPDATE_DURUM", iMap));
					oMap.put("MESSAGE", "");
				}
			}
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_CALISMA_SEKLI_KOD")
	public static GMMap getCalismaSekliKod(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			oMap.put("CALISMA_SEKLI_KOD", birBasvuru.getCalismaSekliKod());
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_DEALER_LIST")
	public static GMMap getDealerList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rs = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_BASVURU.BAYI_BILGI_AL(?)}");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("KANAL_ALT_KOD"));

			stmt.execute();
			rs = (ResultSet) stmt.getObject(1);

			oMap.putAll(DALUtil.fillComboBox(iMap, "DEALER_LIST", false, rs));
			if (oMap.getSize("DEALER_LIST") == 1) {
				iMap.put("BAYI_KOD", oMap.get("DEALER_LIST", 0, "VALUE"));
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_DEALER_KAMPANYA_LIST", iMap));
			}
			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rs);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_DEALER_KAMPANYA_LIST")
	public static GMMap getKampanyaList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rs = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_BASVURU.KAMPANYA_BILGI_AL(?,?)}");

			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("KANAL_ALT_KOD"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("BAYI_KOD"));

			stmt.execute();
			rs = (ResultSet) stmt.getObject(1);

			return DALUtil.fillComboBox(iMap, "KAMPANYA_LIST", false, rs);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rs);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN3171_GET_PERFORMANCE")
	public static GMMap getPerformance(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_BASVURU.PERFORMANS_BASVURU_SORGULA(?,?,?,?,?,?,?,?)}");

			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("KANAL_ALT_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BAYI_KOD"));
			stmt.setBigDecimal(i++, iMap.get("KAMPANYA_KOD") != null ? iMap.getBigDecimal("KAMPANYA_KOD") : null);
			if (iMap.getDate("BASLANGIC_TARIHI") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TARIHI").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			if (iMap.getDate("BITIS_TARIHI") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TARIHI").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("BASVURU_SORGU", "E"));
			i--;
			
			stmt.execute();
			if("E".equals(iMap.getString("BASVURU_SORGU", "E"))){
				rs2 = (ResultSet) stmt.getObject(--i);
			}else{
				i--;
			}
			rs1 = (ResultSet) stmt.getObject(--i);

			String[] tableNames = { "PERFORMANS_BILGILERI", "BASVURU_BILGILERI" };

			oMap.putAll(DALUtil.rSetResults(rs1, tableNames[0]));
			if("E".equals(iMap.getString("BASVURU_SORGU", "E"))){
				oMap.putAll(DALUtil.rSetResults(rs2, tableNames[1]));
			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rs1);
			GMServerDatasource.close(rs2);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * @param iMap
	 *            = ( BASVURU_NO,
	 *            BELGELER = {BELGE_KOD, KIMDEN_KOD, BELGE_KONTROL, DOKUMAN_TIP_KOD, ORJINAL_EVRAK_MI, DOSYA_ADI, GELIS_TARIHI, BELGE_HATA, ONAYLI_MI,
	 *            UYUMSUZ_ACIKLAMA, DOSYA_YOL, CONTENT} )
	 * 
	 * @return MESSAGE
	 */
	@GraymoundService("BNSPR_TRN3182_SAVE_DEALER")
	public static GMMap belgeDurumGuncelleme(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			iMap.put("IPTAL_GOSTER", "H");

			iMap.putAll(GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
			iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3182_GET_BASVURU_INFO", iMap)); // 3182 simule edildi.
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3182_SAVE", iMap));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_LOG_NBSM_DEALER")
	public static GMMap logNbsmDealer(GMMap iMap) {
		try {
			BigDecimal LogtxNo = iMap.getBigDecimal("LOG_TX_NO");

			if (LogtxNo == null) {
				LogtxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");
				iMap.put("LOG_TX_NO", LogtxNo);
			}

			Session session = DAOSession.getSession("BNSPRDal");
			BirOtpLog birOtpLog = (BirOtpLog) session.createCriteria(BirOtpLog.class).add(Restrictions.eq("islemTxNo", iMap.getBigDecimal("TX_NO"))).add(Restrictions.eq("txNo", LogtxNo)).uniqueResult();
			if (birOtpLog == null) {
				birOtpLog = new BirOtpLog();
			}
			birOtpLog.setTxNo(LogtxNo);
			birOtpLog.setIslemTxNo(iMap.getBigDecimal("TX_NO"));
			birOtpLog.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			birOtpLog.setCepTelNo(iMap.getString("PHONE_NUMBER").substring(3));
			birOtpLog.setKanalKodu(iMap.getString("KANAL_KODU"));
			birOtpLog.setSifreDogrulandi(iMap.getString("OTP_OK"));
			birOtpLog.setYeniSifreIstendi(iMap.getBoolean("RETRY") ? "E" : "H");
			session.flush();
			session.saveOrUpdate(birOtpLog);
			return iMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN3171_CHECK_OTP_NEEDED")
	public static GMMap OtpCheck(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirSaticiTahsis birSaticiTahsis = (BirSaticiTahsis) session.createCriteria(BirSaticiTahsis.class).add(Restrictions.eq("kod", iMap.getBigDecimal("KANAL_ALT_KOD"))).uniqueResult();
			if (birSaticiTahsis != null && StringUtils.isNotBlank(birSaticiTahsis.getOtpKontrolEh())) {
				if (birSaticiTahsis.getOtpKontrolEh().equals("E"))
					oMap.put("BAYI_OTP", true);
				else
					oMap.put("BAYI_OTP", false);
			}
			else
				oMap.put("BAYI_OTP", false);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN3171_CHECK_OTP_UPDATE")
	public static GMMap updateOtpCheck(GMMap iMap) {
		GMMap oMap = new GMMap();
		Boolean otpResend;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			otpResend = true;
			List<?> otpList = session.createCriteria(BirOtpLog.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).list();
			// if(otpList.size()==0) otpResend=true;
			for (Object name : otpList) {
				BirOtpLog birOtpLog = (BirOtpLog) name;
				if (birOtpLog.getSifreDogrulandi().equals("E")) {
					otpResend = false;
					break;
				}
			}
			oMap.put("OTP_RESEND", otpResend);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN3171_GET_TESVIK_GIDER_COMBO_DATA")
	public static GMMap getTesvikGiderComboData(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.putAll(GMServiceExecuter.call("BNSPR_DEALER_GET_BAYI_PERSONEL_LIST", iMap));
		int currentYear = Calendar.getInstance().get(Calendar.YEAR);
		for (int year = initYear; year <= currentYear; year++) {
			GuimlUtil.wrapMyCombo(oMap, "YIL_LIST", String.valueOf(year), String.valueOf(year));
		}
		for (int ay = 1; ay <= 12; ay++) {
			GuimlUtil.wrapMyCombo(oMap, "AY_LIST", String.valueOf(ay), String.valueOf(ay));
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_GET_TESVIK_GIDER_PUSULA")
	public static GMMap getTesvikGiderPusula(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			String procStr = "{ call tesvik_gider_pusula.tesvik_ekrani_hesaplama(?,?,?,?,?)}";
			Object[] inputValues = new Object[6];
			Object[] outputValues = new Object[4];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("KANAL_ALT_KOD");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("CALISAN_KOD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("YIL_AY");

			i = 0;
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "TX_NO";
			outputValues[i++] = BnsprType.NUMBER;
			outputValues[i++] = "RESPONSE";

			oMap.putAll((GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues));

			oMap.put("TESVIK_VAR_MI", !"0".equals(oMap.getString("RESPONSE")));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;

	}

	@GraymoundService("BNSPR_TRN3171_GET_TESVIK_GIDER_PUSULA_REPORT")
	public static GMMap getTesvikGiderPusulaReport(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call pkg_genel_pr.bankamiz_adres}";
			iMap.put("BANKA_ADRES", DALUtil.callOracleFunction(func, BnsprType.STRING, new Object[] {}));

			Object[] inputValues = new Object[2];

			String func2 = "{? = call tesvik_gider_pusula.RETURN_REPORT_FNC(?)}";
			int i = 0;
			inputValues = new Object[2];
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TX_NO");

			iMap.putAll(DALUtil.callOracleRefCursorFunction(func2, "RESULTS", inputValues));

			oMap.putAll(GMServiceExecuter.call("INTERNET_REPORT_INCENTIVE_EXPENSE_BILL", iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;

	}

	@GraymoundService("BNSPR_TRN3171_GET_GARANTOR_ONAYI_SOR")
	public static GMMap getGarantorOnayi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call pkg_trn3171.garantor_onayi_sor(?)}";
			Object[] inputValues = new Object[2];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			oMap.put("GARANTOR_ONAYI_SOR", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_GET_GARANTORLU_MU")
	public static GMMap getGarantorluMu(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call pkg_trn3195.garantorlu_mu(?)}";
			Object[] inputValues = new Object[2];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			oMap.put("GARANTORLU_MU", DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_GET_BELGE_YAZDIR_ONAY")
	public static GMMap getBelgeYazdirOnay(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call tesvik_gider_pusula.Check_Belge_Yazdir(?)}";
			Object[] inputValues = new Object[2];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			oMap.put("GARANTOR_ONAYI_SOR", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_PTT_EMEKLI_SORGUSU_YAPILSIN_MI")
	public static GMMap getPttEmekliSorgusuYapilsinMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_TRN3171.PTT_EMEKLI_SORGUSU_YAPILSIN_MI(?)}";
			Object[] inputValues = new Object[2];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			oMap.put("PTT_EMEKLI_SORGUSU_YAP", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_PTT_EMEKLI_SORGULA")
	public static GMMap getPttEmekliSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if ("E".equals(GMServiceExecuter.execute("BNSPR_TRN3171_PTT_EMEKLI_SORGUSU_YAPILSIN_MI", iMap).get("PTT_EMEKLI_SORGUSU_YAP"))) {
				if (iMap.getString("TCKN") == null || iMap.getString("TCKN") == "")
					iMap.put("TCKN", iMap.getString("TC_KIMLIK_NO"));

				iMap.put("PARAM_REF_TUR", "BIR_BASVURU");
				iMap.put("PARAM_REF_ID", iMap.getString("BASVURU_NO"));
				oMap.putAll(GMServiceExecuter.executeNT("BNSPR_EXT_PTT_EMEKLI_ODEME_SORGULA", iMap));

				if ("0".equals(oMap.getString("RESPONSE"))) {
					Session session = DAOSession.getSession("BNSPRDal");
					GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", "BAYI_PTT_EMEKLI_SGK_SORGU")).uniqueResult();
					if ("A".equals(parametre.getDeger())) {
						oMap.putAll(GMServiceExecuter.executeNT("BNSPR_SGK_EMEKLI_GET_EMEKLI_AYLIK_BILGILERI", iMap));
					}
				}
			}
		}
		catch (Exception e) {
			// throw ExceptionHandler.convertException(e);
			e.printStackTrace();
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_PTT_EMEKLI_BLOKE_KOYMA")
	public static GMMap getPttEmekliBlokeKoyma(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		GnlParametre parametre = (GnlParametre) session.createCriteria(GnlParametre.class).add(Restrictions.eq("kod", "BAYI_PTT_EMEKLI_SGK_SORGU")).uniqueResult();
		if ("A".equals(parametre.getDeger())) {
			iMap.put("PARAM_REF_TUR", "BIR_BASVURU");
			iMap.put("PARAM_REF_ID", iMap.getString("BASVURU_NO"));
			if (iMap.getString("TCKN") == null || iMap.getString("TCKN") == "")
				iMap.put("TCKN", iMap.getString("TC_KIMLIK_NO"));

			try {
				// Bayi PTT emeklisi ise
				if ("E".equals(GMServiceExecuter.execute("BNSPR_TRN3171_PTT_EMEKLISI_MI", iMap).get("PTT_EMEKLISI_MI"))) {
					// Maas bloke oncesinde mutlaka aylik bilgisi tekrar sorgulanmali
					oMap.putAll(GMServiceExecuter.executeNT("BNSPR_SGK_EMEKLI_GET_EMEKLI_AYLIK_BILGILERI", iMap));
					if ("2".equals(oMap.getString("RESPONSE"))) {
						// Basvuru emekli maasina bloke konmasi
						iMap.put("HATA_VER", "E");
						GMServiceExecuter.execute("BNSPR_TRN3171_PTT_EMEKLI_MAAS_BLOKE_KOYMA", iMap);
						//
						String procStr = "{ call pkg_trn3171.ptt_emekli_maas_blokesi_koy(?)}";
						Object[] inputValues = new Object[2];
						Object[] outputValues = new Object[0];
						int i = 0;
						inputValues[i++] = BnsprType.NUMBER;
						inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
						DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
						//
						// Basvuru emekli maasi disindaki maaslarina bloke konmasi
						iMap.put("HATA_VER", "H");
						GMServiceExecuter.execute("BNSPR_TRN3171_PTT_EMEKLI_MAAS_BLOKE_KOYMA", iMap);
					}
					else {
						// Maasini PTT'den almiyor hatasi
						if (!oMap.getString("RESPONSE_DATA").isEmpty() && oMap.getString("RESPONSE_DATA").contains("-13")) {
							iMap.put("HATA_NO", "4456");
							GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						}
						// Diger hatalar
						else {
							throw new Exception(oMap.getString("RESPONSE_DATA"));
						}
					}
				}
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_PTT_EMEKLI_MAAS_BLOKE_KOYMA")
	public static GMMap getPttEmekliMaasBlokeKoyma(GMMap iMap) {

		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_TRN3171.ptt_emekli_maas_liste(?, ?) }";
			Object[] inputValues = new Object[4];
			int n = 0;
			inputValues[n++] = BnsprType.NUMBER;
			inputValues[n++] = iMap.getBigDecimal("BASVURU_NO");
			inputValues[n++] = BnsprType.STRING;
			inputValues[n++] = iMap.getString("HATA_VER");
			GMMap resultMap = (GMMap) (DALUtil.callOracleRefCursorFunction(func, "MAAS_LISTE", inputValues));

			if (resultMap.getSize("MAAS_LISTE") == 0 && "E".equals(iMap.getString("HATA_VER"))) {
				iMap.put("HATA_NO", "4454");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			for (int i = 0; i < resultMap.getSize("MAAS_LISTE"); i++) {
				GMMap sMap = new GMMap();
				sMap.put("PARAM_REF_TUR", iMap.getString("PARAM_REF_TUR"));
				sMap.put("PARAM_REF_ID", iMap.getString("PARAM_REF_ID"));
				sMap.put("TCKN", resultMap.getString("MAAS_LISTE", i, "TCKN"));
				sMap.put("AYLIK_ID", resultMap.getString("MAAS_LISTE", i, "AYLIK_ID"));
				sMap.put("EMEKLI_GSM_NO", resultMap.getString("MAAS_LISTE", i, "EMEKLI_GSM_NO"));
				sMap.put("SIGORTA_KOLU", resultMap.getString("MAAS_LISTE", i, "SIGORTA_KOLU"));

				oMap = new GMMap();
				oMap.putAll(GMServiceExecuter.executeNT("BNSPR_SGK_EMEKLI_UPDATE_KREDI_BILGISI_BLOKE_KOY", sMap));
				if (!"2".equals(oMap.getString("RESPONSE")) && "E".equals(iMap.getString("HATA_VER"))) {
					// Maasini PTT'den almiyor hatasi
					if (!oMap.getString("RESPONSE_DATA").isEmpty() && (oMap.getString("RESPONSE_DATA").contains("-13") || oMap.getString("RESPONSE_DATA").contains("-6"))) {
						iMap.put("HATA_NO", "4456");
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					// Diger hatalar
					else {
						throw new Exception(oMap.getString("RESPONSE_DATA"));
					}
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_PTT_EMEKLI_TOPLU_BLOKE_KOYMA")
	public static GMMap getPttEmekliTopluBlokeKoyma(GMMap iMap) {
		GMMap oMap = new GMMap();
		String basariliListesi = "\n";
		String basarisizListesi = "\n";
		try {
			String func = "{? = call PKG_PTT_DOSYA.bayi_ptt_emekli_blksiz_listesi }";
			Object[] inputValues = new Object[0];
			GMMap resultMap = (GMMap) (DALUtil.callOracleRefCursorFunction(func, "BASVURU_LISTE", inputValues));

			for (int i = 0; i < resultMap.getSize("BASVURU_LISTE"); i++) {
				try {
					GMMap sMap = new GMMap();
					sMap.put("BASVURU_NO", resultMap.getString("BASVURU_LISTE", i, "BASVURU_NO"));
					sMap.put("TC_KIMLIK_NO", resultMap.getString("BASVURU_LISTE", i, "TC_KIMLIK_NO"));
					GMServiceExecuter.executeNT("BNSPR_TRN3171_PTT_EMEKLI_BLOKE_KOYMA", sMap);
					basariliListesi = basariliListesi + "\n" + resultMap.getString("BASVURU_LISTE", i, "BASVURU_NO") + " : Basarili";
				}
				catch (Exception e) {
					basarisizListesi = basarisizListesi + "\n" + resultMap.getString("BASVURU_LISTE", i, "BASVURU_NO") + " : HATALI";
				}

			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		sendMail("Bayi PTT Emekli Toplu Maas Bloke Koyma", "Bayi ptt emekli basvurulari icin maas bloke koyma islemi asagidaki basvurular icin gerceklesti. Hata alanlarin durumlari kontrol edilmeli. \n" + basariliListesi + basarisizListesi);

		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_AYLIK_GELIR")
	public static GMMap getAylikGelir(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{? = call PKG_TRN3171.BASVURU_AYLIK_GELIR(?,?)}";
			Object[] inputValues = new Object[4];
			int i = 0;
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("BASVURU_NO");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TRX_NO");
			oMap.put("AYLIK_GELIR", DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	private static void sendMail(String subject, String mailBody) {
		GMMap servisMap = new GMMap();
		servisMap.put("MAIL_FROM", "system@aktifbank.com.tr");
		GMMap xMap = new GMMap();
		// KKB bildiriminde mail giden kisilerle bu is icin mail giden kisiler ayni.
		xMap.put("KOD", "PTT_HATALI_KAYIT_MAIL_GONDER");
		xMap.put("KEY", "err_mail_to");
		servisMap.put("MAIL_TO", GMServiceExecuter.execute("BNSPR_COMMON_GET_PARAM_TEXT", xMap).get("TEXT"));
		servisMap.put("MAIL_SUBJECT", subject);
		servisMap.put("MAIL_BODY", mailBody);
		servisMap.put("IS_BODY_HTML", "H");
		GMServiceExecuter.executeNT("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);
	}

	@GraymoundService("BNSPR_TRN3171_ONONAY_BASVURU_SMS")
	public static GMMap onOnayBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (StringUtil.isEmpty(iMap.getString("TCKN")) || StringUtil.isEmpty(iMap.getString("MOBILE_NUMBER"))) {
				throw new GMRuntimeException(0, "TCKN ve MOBILE_NUMBER dolu olmal�d�r.");
			}
			Session session = DAOSession.getSession("BNSPRDal");

			@SuppressWarnings("unchecked")
			List<Object> list = session.createQuery("from BirBasvuruTx b, BirBasvuruKimlikTx k where b.txNo = k.txNo and b.tcKimlikNo='" + iMap.getString("TCKN") + "' and b.durumKodu = 'ON_ONAY' and b.kanalKodu = '12' and b.saticiKod is null and k.cepTelAlanKodu='" + iMap.getString("MOBILE_AREA_CODE") + "' and k.cepTelNo='" + iMap.getString("MOBILE_NUMBER") + "'").list();

			if (list.size() > 0) {
				Object[] obj = (Object[]) list.get(0);
				oMap.put("APPLICATION_NO", ((BirBasvuruTx) obj[0]).getBasvuruNo());
				oMap.put("SURNAME", ((BirBasvuruKimlikTx) obj[1]).getSoyad());
				oMap.put("STATUS", "S");
			}
			else {
				iMap.put("CEP_TEL_NO", iMap.get("MOBILE_NUMBER"));
				iMap.put("CEP_TEL_ALAN_KODU", iMap.get("MOBILE_AREA_CODE"));
				iMap.put("KANAL_KOD", "12"); // Sms
				iMap.put("ONONAY_BASVURU", "1");

				if ("E".equals(iMap.getString("CALL_NBSM"))) {
					iMap.put("PARAMETRE", "BAYI_SMS_KAMP_KOD");
					iMap.put("KAMP_URUN_ADI", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).getString("DEGER"));
					oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMP_KNL_KOD", iMap));
					iMap.put("KAMP_KNL_KOD", oMap.get("KAMP_KNL_KOD"));
					iMap.put("KAMP_KOD", oMap.get("KAMP_KOD"));
				}

				iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_SAVE_ONONAY_BASVURU", iMap));
				oMap.put("APPLICATION_NO", iMap.get("BASVURU_NO"));

				if (iMap.get("HATA_NO") != null && iMap.get("BASVURU_NO") != null) {
					oMap.put("STATUS", "R");
					oMap.put("SURNAME", iMap.get("SOYADI"));
					oMap.put("ERROR_EXP", iMap.get("HATA"));
				}
				else {
					if ("E".equals(iMap.getString("KPS_YAPILDI"))) {
						oMap.put("SURNAME", iMap.get("SOYADI"));
						oMap.put("STATUS", "S");

						if ("E".equals(iMap.getString("CALL_NBSM"))) {
							oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_DEVAM_SORGULAR", iMap));
						}

					}
					else {
						oMap.put("STATUS", "E");
						oMap.put("ERROR_EXP", iMap.get("HATA"));
						if ("99".equals(iMap.getString("HATA_NO"))) {
							throw new GMRuntimeException(0, iMap.getString("HATA"));
						}
					}
				}
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_GET_ENTRY_LIST")
	public static GMMap getEntryList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			if (StringUtil.isEmpty(iMap.getString("BASVURU_NO")) || StringUtil.isEmpty(iMap.getString("TC_KIMLIK_NO"))) {
				iMap.put("HATA_NO", "5081");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			Session session = DAOSession.getSession("BNSPRDal");
			SimpleDateFormat outputFormat = new SimpleDateFormat("dd/MM/yyyy");
			@SuppressWarnings("unchecked")
			List<Object> list = session.createQuery("from BirBasvuruTx b, BirBasvuruKimlikTx k where b.txNo = k.txNo and b.tcKimlikNo='" + iMap.getString("TC_KIMLIK_NO") + "' and b.durumKodu = 'ON_ONAY" + "' and b.basvuruNo=" + iMap.getString("BASVURU_NO")).list();

			if (list.size() > 0) {
				Object[] obj = (Object[]) list.get(0);
				BirBasvuruTx basvuruTx = (BirBasvuruTx) obj[0];
				BirBasvuruKimlikTx kimlikTx = (BirBasvuruKimlikTx) obj[1];

				if (basvuruTx.getSaticiKod() == null || basvuruTx.getSaticiKod().equals(iMap.getBigDecimal("SATICI_KOD"))) {
					BirBasvuru b = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", basvuruTx.getBasvuruNo())).uniqueResult();
					// eger isleme alinmamissa
					if (b == null) {
						oMap.put("BASVURU_BILGILERI", 0, "BASVURU_NO", basvuruTx.getBasvuruNo());
						oMap.put("BASVURU_BILGILERI", 0, "TC_KIMLIK_NO", basvuruTx.getTcKimlikNo());
						if (kimlikTx.getAd() != null && !"".equals(kimlikTx.getAd())) {
							oMap.put("BASVURU_BILGILERI", 0, "AD_SOYAD", kimlikTx.getAd().concat(kimlikTx.getIkinciAd() == null ? " " : kimlikTx.getIkinciAd().concat(" ")).concat(kimlikTx.getSoyad()));
						}
						oMap.put("BASVURU_BILGILERI", 0, "BASVURU_TAR", basvuruTx.getBasvuruTarihi() != null ? outputFormat.format(basvuruTx.getBasvuruTarihi()) : null);
						oMap.put("BASVURU_BILGILERI", 0, "DURUM", basvuruTx.getDurumKodu());
						oMap.put("BASVURU_BILGILERI", 0, "TX_NO", basvuruTx.getTxNo());
						oMap.put("BASVURU_BILGILERI", 0, "CEP_TEL_ALAN_KODU", kimlikTx.getCepTelAlanKodu());
						oMap.put("BASVURU_BILGILERI", 0, "CEP_TEL_NO", kimlikTx.getCepTelNo());
					}
				}
				else {
					iMap.put("HATA_NO", "5082");
					GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}
			else {
				iMap.put("HATA_NO", "5081");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3171_GET_ENTRY_INIT")
	public static Map<?, ?> getEntryInit(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			oMap.putAll(iMap);

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
			iMap.put("TRX_NO", oMap.get("TRX_NO"));
			oMap.put("NEW_TRANSACTION", "E");

			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_OLUMLU_GORUS", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_OLUMSUZ_GORUS", iMap));
			int olumlu_size = oMap.getSize("OLUMLU_GORUS");
			int olumsuz_size = oMap.getSize("OLUMSUZ_GORUS");
			if (olumsuz_size > 0) {
				Set<?> keySet = oMap.getMap("OLUMSUZ_GORUS", 0).keySet();
				for (int i = 0; i < olumsuz_size; i++) {
					for (Object key : keySet) {
						String keyName = (String) key;
						Object keyValue = oMap.get("OLUMSUZ_GORUS", i, keyName);
						oMap.put("OLUMLU_GORUS", olumlu_size + i, keyName, keyValue);
					}
				}
			}
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_YENI_GORUS", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KEFIL_GORUS", iMap));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_GORUS", iMap));

			BirBasvuruTx b = (BirBasvuruTx) session.createCriteria(BirBasvuruTx.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();

			if (b != null) {
				b.setSaticiKod(iMap.getBigDecimal("KANAL_ALT_KOD"));
				session.saveOrUpdate(b);
				session.flush();
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/***
	 * Upsell guncelleme ve yeni basvuru yaratma servisi
	 * Upsell_tipi = 1 guncelleme, 2 yeni basvuru
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_TRN3171_SAVE_UPSELL_BASVURU")
	public static GMMap saveUpsellBasvuru(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap sMap = new GMMap();
		GMMap sorguMap = new GMMap();
		BigDecimal bayiUrunTutari = null;

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			if (StringUtil.isEmpty(iMap.getString("UPSELL_TIPI")) || StringUtil.isEmpty(iMap.getString("BASVURU_NO"))) {
				throw new GMRuntimeException(0, "UPSELL_TIPI ve BASVURU_NO dolu olmal�d�r.");
			}

			GMMap appMap = GMServiceExecuter.call("BNSPR_TRN3172_GET_BASVURU", iMap);
			appMap.putAll(GMServiceExecuter.call("BNSPR_TRN3172_GET_BASVURU_DETAY", iMap));

			if (!"0".equals(iMap.getString("UPSELL_TIPI"))) {
				if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
					iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
				}
				bayiUrunTutari = appMap.getBigDecimal("TUTAR");

				appMap.put("TUTAR", iMap.get("UPSELL_LIMIT"));
				appMap.put("VADE", iMap.get("UPSELL_VADE"));
				appMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
				appMap.put("SATICI_KOD", appMap.get("KANAL_ALT_KOD"));

				if ("2".equals(iMap.getString("UPSELL_TIPI"))) {
					appMap.put("KAMP_KOD", iMap.get("UPSELL_KAMP_KOD"));
					appMap.put("URUN_KAMP_KOD", iMap.get("UPSELL_KAMP_KOD"));
					appMap.put("BASVURU_NO", GMServiceExecuter.call("BNSPR_TRN3171_GET_BASVURU_NO", iMap).getBigDecimal("ID"));
					appMap.remove("URUN_TABLE");
					appMap.remove("EVE_TESLIM_URUN");
					appMap.remove("TESLIMAT_TARIHI");
					appMap.put("DURUM_KODU", "");
					appMap.put("ODEME_TIPI", "2");
					appMap.put("ODEME_ORANI", "");
					appMap.put("ODEME_PERIYODU", "");
					appMap.put("ODEME_TUTARI", "");
					appMap.put("ODEME_VADESI", "");
					appMap.put("EK_IHTIYAC", "H");
				}

				sMap.put("KRD_TUR_KOD", appMap.getBigDecimal("KRD_TUR_KOD", new BigDecimal(1)));
				sMap.put("KAMP_URUN_ADI", appMap.getString("KAMP_KOD"));
				sMap.put("DOVIZ_KODU", appMap.getString("DOVIZ_KODU", "TRY"));
				sMap.put("KREDI_TUTARI", iMap.get("UPSELL_LIMIT"));
				sMap.put("KREDI_VADESI", appMap.getBigDecimal("VADE"));
				sMap.put("KANAL_KOD", appMap.getBigDecimal("KANAL_KOD", new BigDecimal(8)));
				GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_KREDI_MIN_MAX_DEGER", sMap);

				sMap.put("TUTAR", iMap.get("UPSELL_LIMIT"));
				sMap.put("VADE", appMap.getBigDecimal("VADE"));
				sMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GET_KAMP_KNL_KOD", sMap));
				appMap.put("KAMP_KNL_KOD", sMap.get("KAMP_KNL_KOD"));

				GMServiceExecuter.execute("BNSPR_TRN3171_CHECK_FAIZ_ORANI", sMap);

				sMap.put("DOVIZ_KOD", sMap.getString("DOVIZ_KODU"));
				sMap.putAll(GMServiceExecuter.execute("BPM_GET_KATKIPAYI", sMap));
				sMap.putAll(GMServiceExecuter.execute("BPM_DOSYA_MASRAF_FAIZ_TANIMI", sMap));
				appMap.put("FAIZ_ORANI", sMap.get("FAIZ_ORAN"));
				appMap.put("SOZLESME_FAIZI", sMap.get("SOZLESME_ORANI"));
				appMap.put("KATILIM_BEDELI", sMap.get("MAX_KATKI_PAYI"));
				appMap.put("DOSYA_MASRAFI", sMap.get("MAX_DOSYA_MASRAFI"));

				appMap.put("TRX_NO", iMap.get("TRX_NO"));

				if ("2".equals(iMap.getString("UPSELL_TIPI"))) {
					oMap.put("YENI_BASVURU_NO", appMap.get("BASVURU_NO"));

					iMap.put("ILISKILI_BASVURU_NO", oMap.getBigDecimal("YENI_BASVURU_NO"));
					GMServiceExecuter.executeNT("BNSPR_TRN3171_SAVE_ILISKILI_BASVURU_NO", iMap);

					GMMap apsMap = new GMMap();
					apsMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3171_APS_SORGULAMA", appMap));
					appMap.put("APS_YAPILDIMI", apsMap.getString("APS_YAPILDIMI"));

					appMap.put("EKRAN_NO", "3171");
					GMServiceExecuter.executeNT("BNSPR_TRN3171_SAVE_TEMP", appMap);
					GMServiceExecuter.executeNT("BNSPR_TRN3171_STATU_GUNCELLE", appMap);
					sorguMap.put("BASVURU_NO", appMap.get("BASVURU_NO"));
					sorguMap.put("TRX_NO", appMap.get("TRX_NO"));
					oMap.putAll(GMServiceExecuter.executeNT("BNSPR_TRN3171_DEVAM_SORGULAR", sorguMap));
					if ("E".equals(oMap.getString("DEVAM"))) {
						appMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
						GMServiceExecuter.executeNT("BNSPR_TRN3171_CONTROL", appMap);
						sorguMap.put("TRX_NO", appMap.get("TRX_NO"));
						oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3171_GONDER_SORGULAR", sorguMap));
					}

					BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, oMap.getBigDecimal("YENI_BASVURU_NO"));
					session.refresh(birBasvuru);
					birBasvuru.setIliskiliBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
					session.saveOrUpdate(birBasvuru);

					session.flush();
				}
				else if ("1".equals(iMap.getString("UPSELL_TIPI"))) {
					// onay tutar guncelle
					BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
					session.refresh(birBasvuru);
					birBasvuru.setOnayTutar(iMap.getBigDecimal("UPSELL_LIMIT"));
					birBasvuru.setBasvuruTeklifOnay("E");
					birBasvuru.setBayiUrunTutari(bayiUrunTutari);
					session.saveOrUpdate(birBasvuru);
					session.flush();

					GMServiceExecuter.execute("BNSPR_TRN3171_CONTROL", appMap);
				}
			}

			/** SOBF Mail ile gonderilmesi **/
			GMMap tMap = new GMMap();
			tMap.put("EPOSTA", appMap.getString("EMAIL1") + "@" + appMap.getString("EMAIL2"));
			tMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
			tMap.put("MUSTERI_NO", appMap.get("MUSTERI_NO"));
			tMap.put("BELGE_TURU", "SOBF");
			tMap.put("GONDERIM_TIPI", "E");
			GMServiceExecuter.executeAsync("BNSPR_QRY3956_SAVE", tMap);

			if ("2".equals(iMap.getString("UPSELL_TIPI"))) {
				tMap.put("BASVURU_NO", appMap.get("BASVURU_NO"));
				GMServiceExecuter.executeAsync("BNSPR_QRY3956_SAVE", tMap);
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN3171_SAVE_ILISKILI_BASVURU_NO")
	public static GMMap saveIliskiliBasvuruNo(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			session.refresh(birBasvuru);
			birBasvuru.setIliskiliBasvuruNo(iMap.getBigDecimal("ILISKILI_BASVURU_NO"));
			birBasvuru.setBasvuruTeklifOnay("E");
			session.saveOrUpdate(birBasvuru);
			session.flush();
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN371_GET_ELECTRONIC_APPLICATION_INFO")
	public static GMMap getElectronicApplicationInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			@SuppressWarnings("unchecked")
			List<Object> list = session.createQuery("from BirBasvuru b, BirBasvuruKimlik k where b.basvuruNo = k.basvuruNo and b.tcKimlikNo='" + iMap.getString("TC_KIMLIK_NO") + "' and k.cepTelNo = '" + iMap.getString("CEP_TEL_NO") + "' and k.cepTelAlanKodu = '" + iMap.getString("CEP_TEL_KOD") + "' and k.kimlikSeriNoKps = '" + iMap.getString("KIMLIK_SERI_NO") + "' and k.kimlikSiraNoKps = '" + iMap.getString("KIMLIK_SIRA_NO") + "' and b.durumKodu = 'SOZLESME" + "' order By b.basvuruNo desc").list();

			if (list.size() > 0) {
				for (int i = 0; i < list.size(); i++) {
					Object[] obj = (Object[]) list.get(i);
					BirBasvuru birBasvuru = (BirBasvuru) obj[0];
					oMap.put("TBL_BASVURU", i, "BASVURU_NO", birBasvuru.getBasvuruNo());
					oMap.put("TBL_BASVURU", i, "MUSTERI_NO", birBasvuru.getMusteriNo());
				}

				oMap.put("BASVURU_NO", oMap.get("TBL_BASVURU", 0, "BASVURU_NO"));
			}
			else {
				iMap.put("HATA_NO", "1053");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3181_GET_ELECTRONIC_DOCUMENT_CODE_AND_PATHS")
	public static GMMap getElectronicDocumentCodes(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = null;
		try {
			session = DAOSession.getSession("BNSPRDal");
			Criteria criteria = session.createCriteria(GnlParamText.class).add(Restrictions.eq("kod", "BIR_ELEKTRONIK_BELGE_TIP")).add(Restrictions.eq("key2", "E"));

			List<?> paramTextList = criteria.list();
			for (int row = 0; row < paramTextList.size(); row++) {
				GnlParamText gnlParamText = (GnlParamText) paramTextList.get(row);

				oMap.put("TBL_BELGE", row, "KOD", gnlParamText.getKey1());
				oMap.put("TBL_BELGE", row, "DIZIN_ADI", "bayiPortal");
				oMap.put("TBL_BELGE", row, "TEMPLATE_ADI", gnlParamText.getKey3());
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3181_GET_ELECTRONIC_DOCUMENTS")
	public static GMMap getElectronicDocuments(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN3181_GET_INFO_BY_BASVURU_NO", iMap));

			int i = 0;
			for (int index = 0; index < iMap.getSize("TBL_BELGE"); index++) {
				if ("2".equals(iMap.getString("TBL_BELGE", index, "BELGE_ALIM_SEKLI"))) {
					int documentCode = iMap.getInt("TBL_BELGE", index, "BELGE_KODU");
					WebCreditDocument creditDocument = DocumentCreator.createDealerDocument(documentCode);
					oMap.put("TBL_BELGE", i, "KOD", documentCode);
					oMap.put("TBL_BELGE", i, "BELGE_ADI", ConsumerLoanWebServices.getDocumentName(documentCode));
					oMap.put("TBL_BELGE", i, "XML", creditDocument.generateXml(iMap.getString("BASVURU_NO"), null));
					i++;
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN3181_SAVE_ELECTRONIC_DOCUMENTS")
	public static GMMap saveElectronicDocuments(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap bMap = new GMMap();
		boolean otoKul = true;

		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}

			bMap.put("BASVURU_NO", iMap.getBigDecimal("BASVURU_NO"));
			bMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			bMap.put("KIM_ICIN", "M");

			for (int index = 0; index < iMap.getSize("TBL_BELGE"); index++) {
				bMap.put("DOKUMAN_KOD", iMap.getString("TBL_BELGE", index, "KOD"));
				bMap.put("DOSYA_ICERIK", iMap.getString("TBL_BELGE", index, "DOSYA_ICERIK"));
				GMServiceExecuter.execute("BNSPR_CL_BELGE_YUKLE", bMap);

				BirBasvuruBelgeTxId id = new BirBasvuruBelgeTxId(bMap.getBigDecimal("TRX_NO"), bMap.getString("DOKUMAN_KOD"), bMap.getString("KIM_ICIN"), bMap.getBigDecimal("BASVURU_NO"));

				BirBasvuruBelgeTx birBasvuruBelgeTx = (BirBasvuruBelgeTx) session.get(BirBasvuruBelgeTx.class, id);
				birBasvuruBelgeTx.setBelgeKontrol("1");
				birBasvuruBelgeTx.setOrjinalEvrakMi("E");
				birBasvuruBelgeTx.setBelgeGelisTarihi(new Date());
				session.save(birBasvuruBelgeTx);
			}
			session.flush();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_trn3181.elektronik_belge_al(?, ?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("BASVURU_NO"));

			stmt.execute();

			/** Eger kiosk basvuru ise otomatik kullandirim akisina girecek **/
			BirBasvuru birBasvuru = (BirBasvuru) session.get(BirBasvuru.class, iMap.getBigDecimal("BASVURU_NO"));
			if (birBasvuru.getAdcOwner() != null) {
				List<?> calList = null;
				try {
					calList = session.createCriteria(BirSaticiCalisan.class).add(Restrictions.eq("kod", new BigDecimal(birBasvuru.getAdcOwner()))).list();
				}
				catch (Exception e) {
					calList = Collections.EMPTY_LIST;
				}
				;

				for (int row = 0; row < calList.size(); row++) {
					BirSaticiCalisan cal = (BirSaticiCalisan) calList.get(row);
					if ("E".equals(cal.getCihazKullanicisi())) {
						List<?> belgeList = session.createCriteria(BirBasvuruBelge.class).add(Restrictions.eq("id.basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).add(Restrictions.or(Restrictions.eq("belgeAlinmaAdim", "S"), Restrictions.isNull("belgeAlinmaAdim"))).list();

						bMap.clear();

						BirBasvuruBelge birBasvuruBelge = null;
						int j = 0;
						for (int i = 0; i < belgeList.size(); i++) {
							birBasvuruBelge = (BirBasvuruBelge) belgeList.get(i);
							session.refresh(birBasvuruBelge);
							if ("E".equals(birBasvuruBelge.getAlindi())) {
								bMap.put("BELGELER", j, "BELGE_KOD", birBasvuruBelge.getId().getDokumanKod());
								bMap.put("BELGELER", j, "BASVURU_NO", iMap.getString("BASVURU_NO"));
								bMap.put("BELGELER", j, "BELGE_ADI", birBasvuruBelge.getBelgeAdi());
								bMap.put("BELGELER", j, "ALINDI", birBasvuruBelge.getAlindi());
								bMap.put("BELGELER", j, "KIMDEN_KOD", birBasvuruBelge.getId().getKimden());
								bMap.put("BELGELER", j, "BELGE_KONTROL", birBasvuruBelge.getBelgeKontrol());
								bMap.put("BELGELER", j, "GELIS_TARIHI", birBasvuruBelge.getBelgeGelisTarihi());
								bMap.put("BELGELER", j, "ORJINAL_EVRAK_MI", GuimlUtil.convertToCheckBoxValue(birBasvuruBelge.getOrjinalEvrakMi()));
								bMap.put("BELGELER", j, "ISLEM_TARIHI", new Date());
								j++;
							}
							else {
								otoKul = false;
							}
						}

						if (otoKul) {
							birBasvuru.setDurumKodu("KUL");
							session.save(birBasvuru);
							session.flush();

							bMap.put("BASVURU_NO", iMap.get("BASVURU_NO"));
							bMap.put("MUSTERI_NO", birBasvuru.getMusteriNo());
							bMap.put("CALISMA_TIPI", birBasvuru.getCalismaSekliKod());
							bMap.put("DURUM_KODU", "KUL");
							bMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
							bMap.put("MUSTERI_ESLESTIRME", "false");
							bMap.put("OTOMATIK_KULLANDIRIM", "true");
							bMap.put("OTOMATIK_AKIS", "E");
							GMServiceExecuter.execute("BNSPR_TRN3182_SAVE", bMap);
							oMap.put("OTOMATIK_KULLANDIRIM", "true");
						}
					}
				}
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_DEALER_GET_CIHAZ_BAYI_BILGILERI")
	public static GMMap getCihazBayiBilgileri(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("select s.musteri_no, s.satici_tip_kod, s.sube_musteri_no, s.satici_adi, s.alan_kod_tel, s.tel_no, c.kod, c.cep_alan_kod, c.cep_tel_no, c.satici_kod, c.dogum_tarihi, s.yetki_seviye_kod from bir_satici s, bir_satici_calisan c where s.kod=c.satici_kod and c.bayi_cihaz_kodu = ?");
			stmt.setString(1, iMap.getString("BAYI_CIHAZ_KODU"));
			rSet = stmt.executeQuery();
			if (rSet.next()) {
				oMap.put("SATICI_KOD", rSet.getString("SATICI_KOD"));
				oMap.put("CALISAN_KOD", rSet.getString("KOD"));
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	@GraymoundService("BNSPR_DEALER_BASVURU_KANALIADE")
	public static GMMap dealerBasvuruKanaliade(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);
			BirBasvuru birBasvuru = (BirBasvuru) session.createCriteria(BirBasvuru.class).add(Restrictions.eq("basvuruNo", iMap.getBigDecimal("BASVURU_NO"))).uniqueResult();
			
			if("CEPTE".equals(birBasvuru.getDurumKodu()) || "EVRAKSIZ".equals(birBasvuru.getDurumKodu())) {
				iMap.put("HATA_NO", new BigDecimal(1751));
				iMap.put("P1", iMap.getString("BASVURU_NO"));
				iMap.put("P2", "KANALIADE");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			if (iMap.getString("TRX_NO") == null || iMap.getString("TRX_NO").isEmpty()) {
				iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			}
			iMap.putAll(GMServiceExecuter.call("BNSPR_TRN3174_GET_DETAY", iMap));

			iMap.put("AKSIYON_KOD", "I");
			iMap.put("IADE_KOD", "KANALIADE");
			iMap.put("EKRAN_NO", "3174");
			iMap.put("TALEP_TUTAR", iMap.get("ONAY_TUTAR"));
			GMServiceExecuter.execute("BNSPR_TRN3174_SAVE", iMap);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}

	@GraymoundService("BNSPR_DEALER_SAVE_SOSYAL_SKOR_DATA")
	public static GMMap saveSosyalSkorData(GMMap iMap) {
		GMMap oMap = new GMMap();
		String jSon = null;
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy HH:mm:ss");
		boolean isParsed = true;

		try {
			Session session = DAOSession.getSession(Constants.BNSPR_SESSION_NAME);

			if (StringUtil.isEmpty(iMap.getString("BASVURU_NO"))) {
				iMap.put("HATA_NO", new BigDecimal(993));
				iMap.put("P1", "Ba�vuru No");
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			try {
				Gson gson = new GsonBuilder().disableHtmlEscaping().create();
				jSon = iMap.getString("DATA");
				jSon = jSon.replace("ISP/Address", "ISPAddress");
				SocialScoreData[] socialScoreDataList = gson.fromJson(jSon, SocialScoreData[].class);

				for (SocialScoreData socialScoreData : socialScoreDataList) {
					if (socialScoreData.getDeviceInformation() != null) {
						DeviceInformation di = socialScoreData.getDeviceInformation();

						BirDijitalayakiziCihazId cId = new BirDijitalayakiziCihazId(iMap.getBigDecimal("BASVURU_NO"));
						if (di.getBrowser() != null) {
							cId.setBrowserName(di.getBrowser().getName());
							cId.setBrowserVersion(di.getBrowser().getVersion());
						}
						cId.setDevice(di.getDevice());
						if (di.getISPAddress() != null) {
							cId.setIspAddress(di.getISPAddress().getISP());
						}
						if (di.getPlatform() != null) {
							cId.setPlatformBits(di.getPlatform().getBits());
							cId.setPlatformBrand(di.getPlatform().getBrand());
							cId.setPlatformVersion(di.getPlatform().getVersion());
						}
						BirDijitalayakiziCihaz c = new BirDijitalayakiziCihaz(cId);
						session.save(c);
					}
					else if (socialScoreData.getCustomerBehaviour() != null) {
						for (CustomerBehaviour customerBehaviour : socialScoreData.getCustomerBehaviour()) {
							BirDijitalayakiziHareketId hId = new BirDijitalayakiziHareketId(iMap.getBigDecimal("BASVURU_NO"));

							hId.setBackspaceCount(new BigDecimal(customerBehaviour.getBackspaceCount()));
							hId.setCopyPasteCount(new BigDecimal(customerBehaviour.getCopyPasteCount()));
							hId.setDeleteCount(new BigDecimal(customerBehaviour.getDeleteCount()));
							hId.setEntryTime(dateFormat.parse(customerBehaviour.getEntryTime()));
							hId.setExitTime(dateFormat.parse(customerBehaviour.getExitTime()));
							hId.setFieldChangeCount(new BigDecimal(customerBehaviour.getFieldChangeCount()));
							hId.setPageName(customerBehaviour.getPageName());
							BirDijitalayakiziHareket h = new BirDijitalayakiziHareket(hId);

							for (InputData inputData : customerBehaviour.getInputData()) {
								BirDijitalayakiziGirisVeriId vId = new BirDijitalayakiziGirisVeriId(iMap.getBigDecimal("BASVURU_NO"));
								vId.setPageName(customerBehaviour.getPageName());
								vId.setName(inputData.getName());
								vId.setTimeElapsed(new BigDecimal(inputData.getTimeElapsed()));

								BirDijitalayakiziGirisVeri v = new BirDijitalayakiziGirisVeri(vId);
								session.save(v);
							}
							session.save(h);
						}
					}
				}
			}
			catch (Exception e) {
				e.printStackTrace();
				isParsed = false;
			}

			BirSosyalSkorDataId dataId = new BirSosyalSkorDataId();
			dataId.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			dataId.setTur(iMap.getString("TUR"));
			dataId.setData(new ClobImpl(iMap.getString("DATA")));
			if (isParsed) {
				dataId.setDurum("P");
			}
			else {
				dataId.setDurum("A");
			}

			BirSosyalSkorData data = new BirSosyalSkorData();
			data.setId(dataId);

			session.save(data);
			session.flush();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
		}
	}
}
