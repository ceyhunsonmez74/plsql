package tr.com.calikbank.bnspr.consumerloan.tests;

import java.util.Calendar;

import com.graymound.util.GMMap;

import junit.framework.Assert;
import junit.framework.TestCase;

import tr.com.calikbank.bnspr.consumerloan.services.ConsumerLoanTRN3180Services;

public class ConsumerLoanTRN3180Test extends TestCase{
	
	public void testaddTimeToDate () {
		//Assert.assertEquals(Calendar.getInstance().getTime().getTime() + 3600000 + 120000 + 3000, 
				//ConsumerLoanTRN3180Services.addTimeToDate(Calendar.getInstance().getTime(), "010203").getTime());
		
	}
	
	public void testBankaTarihiControl () {
		try {
			GMMap xMap = new GMMap();		
			xMap.put("TARIH", "20091221");
			xMap.put("SAAT", "153000");
			//ConsumerLoanTRN3180Services.controlBankaTarihi(
					//ConsumerLoanTRN3180Services.addTimeToDate(xMap.getDate("TARIH"), xMap.getString("SAAT")));
		}
		catch (Exception e) {
			System.out.println("Hata");
		}
		
	}
	
}
