package tr.com.calikbank.bnspr.consumerloan.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;
import com.graymound.util.GMMap;

public class ConsumerLoanKKBTest extends TestCase {
	public void testCanGetKKBGgadList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(314));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGAD", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGAD");
		
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGAD",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgalList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(314));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGAL", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGAL");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGAL",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgapList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(323));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGAP", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGAP");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGAP",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgbgList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(327));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGBD", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGBD");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGBD",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgbsList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(327));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGBS", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGBS");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGBS",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgciList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(327));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGCI", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGCI");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGCI",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgcmList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(327));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGCM", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGCM");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGCM",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgcpList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(327));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGCP", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGCP");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGCP",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgcvList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(327));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGCV", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGCV");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGCV",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgfaList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(277));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGFA", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGFA");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGFA",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgfdList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(327));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGFD", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGFD");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGFD",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgmpList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(370));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGMP", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGMP");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGMP",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgnsList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(370));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGNS", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGNS");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGNS",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgoeList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(134));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGOE", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGOE");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGOE",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgohList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(370));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGOH", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGOH");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGOH",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgpdList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(370));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGPD", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGPD");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGPD",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgs1List(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(370));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGS1", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGS1");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGS1",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgs2List(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(370));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGS2", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGS2");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGS2",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgs5List(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(210));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGS5", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGS5");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGS5",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgs8List(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(370));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGS8", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGS8");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGS8",rowData.get("SEGMENTID").toString()); 
		}
	}
	public void testCanGetKKBGgssList(){
		GMMap iMap = new GMMap();
		iMap.put("SORGU_NO", new BigDecimal(370));
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KKB_GGSS", iMap);
		List<?> list = (List<?>)oMap.get("KKB_GGSS");
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			HashMap<?,?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("GGSS",rowData.get("SEGMENTID").toString()); 
		}
	}
}
