package tr.com.calikbank.bnspr.consumerloan.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3171Test extends TestCase {

	public void testGetSaticiKrdTurList() {

		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("SATICI_KOD", new BigDecimal(1));

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BPM_GET_SATICI_KRD_TUR_LIST", iMap);

		System.out.println(oMap);

	}

	public void testGetSaticiUrunList() {

		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("KRD_TUR_KOD", new BigDecimal(1));
		iMap.put("SATICI_KOD", new BigDecimal(1));
		iMap.put("DOVIZ_KOD", "TRY");

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BPM_GET_SATICI_URUN_LIST", iMap);

		System.out.println(oMap);

	}

	public void testGetKanalBazindaMinMaxDeger() {

		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("KRD_TUR_KOD", new BigDecimal(1));
		iMap.put("KRD_TUR_ALT_KOD", new BigDecimal(80));
		iMap.put("DOVIZ_KODU", "TRY");
		iMap.put("KANAL_KODU", new BigDecimal(1));

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BPM_GET_KANAL_BAZINDA_MIN_MAX_DEGER", iMap);

		System.out.println(oMap);

	}

	public void testGetUrunOdmGrubaBagliOdmTipleri() {

		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("KRD_TUR_KOD", new BigDecimal(1));
		iMap.put("KRD_TUR_ALT_KOD", new BigDecimal(80));
		iMap.put("KRD_TUR_ALT_KOD2", new BigDecimal(233));
		iMap.put("KANAL_KOD", "2");
		iMap.put("DOVIZ_KOD", "TRY");

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BPM_GET_URUN_ODM_GRUBA_BAGLI_ODM_TIPLERI", iMap);

		System.out.println(oMap);

	}

	public void testGetOdemeGrupBilgileri() {

		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("ODEME_GRUP_KOD", new BigDecimal(23));
		iMap.put("ODEME_TIP_KOD", new BigDecimal(3));

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BPM_GET_ODEME_GRUP_BILGILERI", iMap);

		System.out.println("BPM_GET_ODEME_GRUP_BILGILERI =>" + oMap);
	}

	public void testGetKatkiPayiUrunden() {

		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("KRD_TUR_KOD", new BigDecimal(1));
		iMap.put("KRD_TUR_ALT_KOD", new BigDecimal(80));
		iMap.put("KRD_TUR_ALT_KOD2", new BigDecimal(233));
		iMap.put("KANAL_KOD", "2");
		iMap.put("DOVIZ_KOD", "TRY");

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BPM_GET_KATKIPAYI_URUNDEN", iMap);

		System.out.println("BPM_GET_KATKIPAYI_URUNDEN =>" + oMap);

	}

	public void testGetDosyaMasrafFaizTanimi() {

		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("KRD_TUR_KOD", new BigDecimal(1));
		iMap.put("KRD_TUR_ALT_KOD", new BigDecimal(80));
		iMap.put("KRD_TUR_ALT_KOD2", new BigDecimal(293));
		iMap.put("KANAL_KOD", "2");
		iMap.put("DOVIZ_KOD", "TRY");
		iMap.put("TUTAR", "500");
		iMap.put("VADE", "12");		

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BPM_DOSYA_MASRAF_FAIZ_TANIMI", iMap);

		System.out.println("BPM_DOSYA_MASRAF_FAIZ_TANIMI =>" + oMap);

	}
	
	public void testGetTaksitTutari() {

		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("KRD_TUR_KOD", new BigDecimal(1));
		iMap.put("KRD_TUR_ALT_KOD", new BigDecimal(81));
		iMap.put("KRD_TUR_ALT_KOD2", new BigDecimal(234));
		iMap.put("TUTAR", new BigDecimal(5000));
		iMap.put("VADE", new BigDecimal(10));		
		iMap.put("KANAL_KOD", new BigDecimal(2));
		iMap.put("DOVIZ_KOD", "TRY");

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BPM_GET_TAKSIT_TUTARI", iMap);

		System.out.println("BPM_GET_TAKSIT_TUTARI =>" + oMap);

	}


	public void testGetCalisanBayiList() {

		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TC_KIMLIK_NO", "18499930722");
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BPM_CALISAN_BAYI_LIST", iMap);

		System.out.println("BPM_CALISAN_BAYI_LIST =>" + oMap);

	}
	
	public void testGetIadeBasvList() {
		GMMap iMap = new GMMap();
		iMap.put("SATICI_KOD", "2");

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN3171_GET_IADE_BASV_LIST", iMap);

		System.out.println("IADE_BASV_LIST =>" + oMap);

	}

	public void testGetEksikBelgBasvList() {
		GMMap iMap = new GMMap();
		iMap.put("SATICI_KOD", "2");
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN3171_GET_EKSIK_BELG_BASV_LIST", iMap);
		
		System.out.println("EKSIK_BELG_BASV_LIST =>" + oMap);
		
	}
	
	public void testGetEksikBelgeList() {
		GMMap iMap = new GMMap();
		iMap.put("BASVURU_NO", "1");
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN3171_GET_EKSIK_BELGE_LIST", iMap);
		
		System.out.println("EKSIK_BELGE_LIST =>" + oMap);
		
	}
	
	


}
