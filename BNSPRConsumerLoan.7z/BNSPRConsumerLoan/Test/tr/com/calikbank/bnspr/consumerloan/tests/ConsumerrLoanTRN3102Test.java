package tr.com.calikbank.bnspr.consumerloan.tests;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class ConsumerrLoanTRN3102Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		ArrayList<HashMap<?, ?>> list = new ArrayList<HashMap<?,?>>();
		HashMap<String, Object> rowData = new HashMap<String, Object>();
		rowData.put("KOD", new BigDecimal(1));
		rowData.put("DRM", "G");
		rowData.put("ACIKLAMA", "osman");
		list.add(rowData);
		
		iMap.put("KRD_ALT_TUR", rowData);
		iMap.put("TRX_NO", getTransactionNo());
		iMap.put("TUR_KOD", new BigDecimal(1));
		return iMap;
	}
	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	public void testCanGetCorrectKrediTipiTanimlamaList() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("KRD_TUR_KOD", new BigDecimal(1));

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN3102_GET_KRD_ALT_TUR", iMap);
		List<?> list = (List<?>) oMap.get("KRD_ALT_TUR");
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()) {
			HashMap<?, ?> rowdata = (HashMap<?, ?>) iterator.next();
			assertEquals(new BigDecimal(1), rowdata.get("KOD"));
			assertEquals("Fatural� �htiya�", rowdata.get("ACIKLAMA"));
			assertEquals("G", rowdata.get("DRM"));		
		}
	}
	public void testKodNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("KOD", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN3102_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
}
