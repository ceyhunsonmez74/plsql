package tr.com.calikbank.bnspr.consumerloan.tests;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;
import com.graymound.util.GMRuntimeException;

import junit.framework.TestCase;

public class ConsumerLoanQRY3301Test extends TestCase{
	public void testCanGetKkbSorguNo(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("FINANCE_TYPE", new BigDecimal(50));
		iMap.put("NUMBEROFAPPLICANTS", new BigDecimal(1));
		iMap.put("FORENAME1","HASAN");
		iMap.put("SURNAME","KOPTU");
		iMap.put("SEXCODE", new BigDecimal(1));
		iMap.put("PRIMARY_ID_TYPE", new BigDecimal(3));
		iMap.put("PRIMARY_ID_NO", "V01155686");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		try {
			iMap.put("BIRTHDATE", dateFormat.parse("12.01.1972"));
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		iMap.put("BIRTHTOWN","TRABZON");
		iMap.put("ADRESTYPE", new BigDecimal(1));
		iMap.put("ADDRES1", "as");
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY3301_ONLINE_KKB_SORGULA", iMap);
		assertNotNull(oMap.get("SORGU_NO"));
	}
}
