package tr.com.calikbank.bnspr.consumerloan.tests;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class ConsumerLoanTRN3163Test extends TestCase{
	public void testTRN3163Save(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", getTransactionNo());
		
		ArrayList<HashMap<String, Object>> saticiLimitList = new ArrayList<HashMap<String,Object>>();
		HashMap<String, Object> saticiLimit = new HashMap<String, Object>();
		//saticiLimit.put("FAALIYET_KODU", "11");
		saticiLimit.put("SATICI_KOD", new BigDecimal(1));
		saticiLimit.put("DOVIZ_CINS", "TRY");
		saticiLimit.put("ORJ_LIMIT", new BigDecimal(12));
		saticiLimit.put("IADE", "1");
		saticiLimit.put("BELGE_TAAH_MAX_ORAN", new BigDecimal(2));
		saticiLimit.put("GARANTOR_BELGE_TIP", "1");
		saticiLimit.put("GARANTOR_MAX_ORAN", new BigDecimal(5));
		saticiLimit.put("GARANTI_TAAH_BELGE_TIP", "2");
		saticiLimit.put("GARANTI_TAAH_MAX_ORAN", new BigDecimal(3));
		saticiLimitList.add(saticiLimit);
		iMap.put("BIR_SATICI_LIMIT", saticiLimitList);
	
		iMap.put("USERNAME", "BNSPR");
		iMap.put("PASSWORD", "cd02588a9436a3a448f6e1b0743d7971e2c6ef23");
		iMap.put("LANGUAGE", "TR");
				
		GMResourceFactory.getInstance().service("BNSPR_USER_AUTHENTICATE", iMap);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN3163_SAVE", iMap);
		assertNotNull(oMap.get("MESSAGE"));
		System.out.println(oMap.get("MESSAGE"));
		
	}
	
	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}

}
