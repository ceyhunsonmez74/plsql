package tr.com.calikbank.bnspr.consumerloan.tests;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class ConsumerLoanTRN3162Test extends TestCase{
	public void testTRN3262Save(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", getTransactionNo());
		iMap.put("KOD", new BigDecimal(1));
		iMap.put("BAYI_SSK_ISYERI_KOD", 122);
		iMap.put("TICARET_SICIL_NO", "22");
		iMap.put("TOP_CALISAN_SAYI", new BigDecimal(13));
		iMap.put("SATIS_PERSONEL_SAYI",new BigDecimal(2));
		iMap.put("ISYERI_MULKIYET_KOD", "44");
		iMap.put("KIRA_BEDELI", new BigDecimal(54));
		iMap.put("BLOKE_SURESI", new BigDecimal(10));
		iMap.put("ISYERI_KONUM_KOD", "32");
		iMap.put("ISYERI_YUZOLCUMU", new BigDecimal(11));
		iMap.put("EK_ISYERI_VAR", "H");
		iMap.put("EK_ISYERI_ADI", "otel");
		iMap.put("ACIKLAMA", "bla bla");
		iMap.put("HESAP_NO", new BigDecimal(111));
		iMap.put("BAYI_STATU_KOD","12");
		iMap.put("CALISMA_SEKLI_KOD", "1");
		iMap.put("BAYI_RISK_KOD", "2");
		iMap.put("BAYI", new BigDecimal(4));
		iMap.put("BAYI_GUNLUK_LIMIT", new BigDecimal(2));
		iMap.put("KISMI_KAPANMA_NEDEN_KOD", "1");
		iMap.put("ORJ_EVRAK_GON_SURE", new BigDecimal(44));
		iMap.put("MALI_YILI", new BigDecimal(2000));
		iMap.put("MUSTERI_PORTFOY_KOD", "D");
		iMap.put("SERMAYE_TUTAR", new BigDecimal(2));
		iMap.put("VERGI_MATRAH", new BigDecimal(3));
		iMap.put("AYLIK_SATIS_ADET", new BigDecimal(23));
		iMap.put("AYLIK_SATIS_TUTAR", new BigDecimal(12));
		iMap.put("TASIT_SAYI", new BigDecimal(44));
		iMap.put("CAL_FINANS1_EH","X");
		iMap.put("CAL_FINANS2_EH","Y");
		iMap.put("CAL_FINANS3_EH","Z");
		iMap.put("CAL_FINANS_DIGER","E" );
		iMap.put("DAGITICI_FIRMA_TEMINAT_KOD","T" );
		iMap.put("TEMINAT_TUTAR", new BigDecimal(1));
		iMap.put("YATIRIM_PLANI", "VAR");
		iMap.put("ORTAK_SEKTOR_TECRUBESI", new BigDecimal(4));
		iMap.put("BEKLENEN_KREDI_HACMI", new BigDecimal(66) );
		iMap.put("DURUM", "K");
		iMap.put("GAYRIMENKUL_ADET_ARSA", new BigDecimal(1));
		iMap.put("GAYRIMENKUL_ADET_DUKKAN", new BigDecimal(1));
		iMap.put("GAYRIMENKUL_ADET_EV", new BigDecimal(1));
		iMap.put("AYNI_ADRESTE_FAALIYET_SURESI", new BigDecimal(1));
		iMap.put("SUBE_SAYISI", new BigDecimal(1));
		iMap.put("YATIRIM_PLANI_ACIKLAMA", "sadasd");
		
		ArrayList<HashMap<String, Object>> saticiTahsisFaaliyetList = new ArrayList<HashMap<String,Object>>();
		HashMap<String, Object> saticiTahsisFaaliyet = new HashMap<String, Object>();
		saticiTahsisFaaliyet.put("FAALIYET_KODU", "11");
		saticiTahsisFaaliyet.put("SATICI_KOD", new BigDecimal(1));
		saticiTahsisFaaliyet.put("TUR", "EK");
		saticiTahsisFaaliyetList.add(saticiTahsisFaaliyet);
		iMap.put("BIR_SATICI_TAHSIS_FAALIYET", saticiTahsisFaaliyetList);
		
		ArrayList<HashMap<String, Object>> saticiTahsisAraclarList = new ArrayList<HashMap<String,Object>>();
		HashMap<String, Object> saticiTahsisAraclar = new HashMap<String, Object>();
		saticiTahsisAraclar.put("MARKA", "XYZ");
		saticiTahsisAraclar.put("MODEL", "ABC");
		saticiTahsisAraclar.put("PLAKA", "33");
		saticiTahsisAraclar.put("SATICI_KOD", new BigDecimal(1));
		saticiTahsisAraclar.put("YIL", "1997");
		saticiTahsisAraclarList.add(saticiTahsisAraclar);
		iMap.put("BIR_SATICI_TAHSIS_ARACLAR", saticiTahsisAraclarList);
		
		ArrayList<HashMap<String, Object>> saticiTahsisMarkalarList = new ArrayList<HashMap<String,Object>>();
		HashMap<String, Object> saticiTahsisMarkalar = new HashMap<String, Object>();
		saticiTahsisMarkalar.put("MARKA", new BigDecimal(123));
		saticiTahsisMarkalar.put("SATICI_KOD", new BigDecimal(1));
		saticiTahsisMarkalar.put("BAYILIK_SURESI", new BigDecimal(6));
		saticiTahsisMarkalar.put("KART", new BigDecimal(444));
		saticiTahsisMarkalar.put("ORT_AYLIK_SATIS_ADET", new BigDecimal(200));
		saticiTahsisMarkalar.put("PESIN", new BigDecimal(100));
		saticiTahsisMarkalar.put("SENET", new BigDecimal(4));
		saticiTahsisMarkalar.put("YETKILI_BAYI", new BigDecimal(2));
		saticiTahsisMarkalar.put("YOGUN_SEZON_BASLANGIC", new BigDecimal(2));
		saticiTahsisMarkalar.put("YOGUN_SEZON_BITIS", new BigDecimal(3));
		
		saticiTahsisMarkalarList.add(saticiTahsisMarkalar);
		iMap.put("BIR_SATICI_TAHSIS_MARKALAR", saticiTahsisMarkalarList);
		iMap.put("USERNAME", "BNSPR");
		iMap.put("PASSWORD", "cd02588a9436a3a448f6e1b0743d7971e2c6ef23");
		iMap.put("LANGUAGE", "TR");
				
		GMResourceFactory.getInstance().service("BNSPR_USER_AUTHENTICATE", iMap);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN3162_SAVE", iMap);
		//GMServiceExecuter.execute("BNSPR_TRN3162_SAVE", iMap);
		assertNotNull(oMap.get("MESSAGE"));
		System.out.println(oMap.get("MESSAGE"));
		
	}
	
	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
}
