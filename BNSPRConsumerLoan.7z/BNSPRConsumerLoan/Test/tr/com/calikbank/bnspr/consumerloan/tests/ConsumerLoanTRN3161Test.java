package tr.com.calikbank.bnspr.consumerloan.tests;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;
import com.graymound.util.GMMap;

public class ConsumerLoanTRN3161Test extends TestCase {

	public void testGetMUsteriBayiBilgileri() {

		GMMap iMap = new GMMap();

		iMap.put("MUSTERI_NO", 1000006);

		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN3161_GET_MUSTERI_BAYI_BILGILERI", iMap);

		assertEquals(oMap.get("ISYERI_UNVANI")		, "Hakan Elektronik Genel M�d�rl�k");
		assertEquals(oMap.get("ADRES")				, "Tekfen TOWER");
		assertEquals(oMap.get("WEB_ADRES")			, "www.hakanelektronik.com.tr");
		assertEquals(oMap.get("VERGI_DAIRE_KODU")	, "20101");

	}
	public void testFillComboBox() {

		GMMap iMap = new GMMap();

		iMap.put("KOD", "SATICI_TIP_KOD");

		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_FILL_COMBOBOX", iMap);

		System.out.println(oMap);

	}
	
	public void testTCKNoGetBayiBilgileri() {

		GMMap iMap = new GMMap();

		iMap.put("TCK_NO", "12253946530");

		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TCK_NO_GET_BAYI_BILGILERI", iMap);

		System.out.println(oMap);

	}
	
	public void testVergiNoGetBayiBilgileri() {

		GMMap iMap = new GMMap();

		iMap.put("VERGI_NO", "123456789");

		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_VERGI_NO_GET_BAYI_BILGILERI", iMap);

		System.out.println(oMap);

	}
	
	public void testDalGetLovService() {

		GMMap iMap = new GMMap();

		iMap.put("LOV_NAME", "3161/LOV_BANKA_SUBE");
		iMap.put("KEY", "%");

		ArrayList<String> list = new ArrayList<String>();

		list.add("1");
		list.add("006");		
		
		iMap.put("INPUT_PARAMETERS", list);

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_DAL_GET_LOV", iMap);

		System.out.println("BNSPR_DAL_GET_LOV -> " + oMap);
	}
	
	public void testTRN3161Save(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		Random rand = new Random();
		BigDecimal trxNo = new BigDecimal(919926 + rand.nextInt(100000));

		iMap.put("TRX_NO", trxNo);
		iMap.put("KOD", new BigDecimal(992599 + rand.nextInt(100000)));
		iMap.put("SATICI_ADI", "Sat�c� Ad�");
		iMap.put("MUSTERI_NO", new BigDecimal(1000006));
		iMap.put("TANIMLAMA_TAR", new Date());
		iMap.put("SATICI_TIP_KOD", "D");
		iMap.put("BAGLI_MERKEZ_BAYI", null);
		iMap.put("KURULUS_TAR", new Date());
		iMap.put("KRD_TUR_KODLARI", "1");
		iMap.put("YETKI_SEVIYE_KOD", "K");
		iMap.put("ONEM_DERECE_KOD", "A");
		iMap.put("TESVIK_UYGULAMA_EH", "E");
		iMap.put("TESVIK_FARKLI_EH", "E");
		iMap.put("BELGE_GON_FAKS_EH", "E");
		iMap.put("BELGE_GON_EMAIL_EH", "E");
		iMap.put("ADRES", "Adres");
		iMap.put("ALAN_KOD_TEL", "212");
		iMap.put("TEL_NO", "9912535");
		iMap.put("ALAN_KOD_FAKS", "212");
		iMap.put("FAKS_NO", "9987456");
		iMap.put("EMAIL", "email");
		iMap.put("WEB_ADRES", "web adresi");
		iMap.put("BANKA_KOD", "255");
		iMap.put("BANKA_SUBE", "300");
		iMap.put("BANKA_HESAP", "0212121");
		iMap.put("PARA_CIKIS_OTO_EH", "E");
		iMap.put("SATIS_GORUS_KOD", "1");
		iMap.put("DRM", "G");
		iMap.put("BAGLI_OLD_BOLGE_KOD", "B");
		iMap.put("ISYERI_FAAL_KONU_KOD", "1");
		iMap.put("DOK_YOLLAMA_KOD", "1");
		
		ArrayList<HashMap<String, Object>> calisanList = new ArrayList<HashMap<String,Object>>();
		iMap.put("SATICI_CALISAN", calisanList);
		HashMap<String, Object> calisanMap = new HashMap<String, Object>();
		calisanMap.put("TRX_NO", trxNo);
		calisanMap.put("KOD", new BigDecimal(12313213));
		calisanMap.put("SATICI_KOD", new BigDecimal(1));
		calisanMap.put("TC_KIMLIK_NO", "12131321");
		calisanMap.put("ADI", "Ad�");
		calisanMap.put("SOYADI", "soyad�");
		calisanMap.put("UYRUK_KOD", "TR");
		calisanMap.put("DOGUM_TARIHI", new Date());
		calisanMap.put("DOGUM_YERI", "dogum yeri");
		calisanMap.put("BABA_ADI", "baba ad�");
		calisanMap.put("YETKI_GIRIS_KOD", "1");
		calisanMap.put("CEP_ALAN_KOD", "535");
		calisanMap.put("CEP_TEL_NO", "9998822");
		calisanMap.put("EPOSTA", "E-posta");
		calisanMap.put("ISE_BASLAMA_TAR", new Date());
		calisanMap.put("POZISYON_KOD", "1");
		calisanMap.put("TUTTUGU_TAKIM_KOD", "1");
		calisanMap.put("HOBI_KOD", "1");
		calisanMap.put("MUSTERI_NO", new BigDecimal(1000004));
		calisanMap.put("HESAP_NO", new BigDecimal(11111111));
		calisanMap.put("DIGER_BANKA_KOD", "211");
		calisanMap.put("DIGER_SUBE_KOD", "200");
		calisanMap.put("DIGER_HESAP_NO", "212");
		calisanMap.put("ARMAGAN_KART_NO", "1");
		calisanMap.put("CAL_STATU_KOD", "1");
		calisanMap.put("CAL_KISMI_KAPANMA_NEDEN_KOD", "1");		
		calisanList.add(calisanMap);
		
		ArrayList<HashMap<String, Object>> teminatlarGuiList = new ArrayList<HashMap<String,Object>>();
		HashMap<String, Object> iliskiMap = new HashMap<String, Object>();
		iliskiMap.put("TRX_NO", trxNo);
		iliskiMap.put("KOD", new BigDecimal(994545));
		iliskiMap.put("SATICI_KOD", new BigDecimal(1));
		iliskiMap.put("BAGLI_OLD_SAT_KOD", new BigDecimal(2));
		teminatlarGuiList.add(iliskiMap);
		
		iMap.put("SATICI_ILISKI", teminatlarGuiList);
		
		iMap.put("USERNAME", "BNSPR");
		iMap.put("PASSWORD", "cd02588a9436a3a448f6e1b0743d7971e2c6ef23");
		iMap.put("LANGUAGE", "TR");
				
		GMResourceFactory.getInstance().service("BNSPR_USER_AUTHENTICATE", iMap);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN3161_SAVE", iMap);
		assertNotNull(oMap.get("MESSAGE"));
		System.out.println(oMap.get("MESSAGE"));
	}
	
}
