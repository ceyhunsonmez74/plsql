package tr.com.calikbank.bnspr.consumerloan.tests;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class ConsumerLoanTRN3164Test extends TestCase{
	public void testTRN3164Get(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("SATICI_KOD", new BigDecimal(1));
		
		iMap.put("USERNAME", "BNSPR");
		iMap.put("PASSWORD", "cd02588a9436a3a448f6e1b0743d7971e2c6ef23");
		iMap.put("LANGUAGE", "TR");
				
		GMResourceFactory.getInstance().service("BNSPR_USER_AUTHENTICATE", iMap);
		
		GMResourceFactory.getInstance().service("BNSPR_TRN3164_GET_BIR_SATICI_TESVIK_TANIM", iMap);

	}
	
	public void testTRN3164Save() {

		ArrayList<HashMap<String, Object>> saticiTanimList = new ArrayList<HashMap<String,Object>>();
		HashMap<String, Object> rowData = new HashMap<String, Object>();
		
		rowData.put("TRX_NO", new BigDecimal(15211));
		rowData.put("ID", new BigDecimal(180));
		rowData.put("SATICI_KOD", new BigDecimal(1));
		rowData.put("KRD_TUR_KOD", new BigDecimal(1));
		rowData.put("KRD_TUR_ALT_KOD", new BigDecimal(80));
		rowData.put("KRD_TUR_ALT_KOD2", new BigDecimal(189));
		rowData.put("TESVIK_KOD", new BigDecimal(1));
		rowData.put("BAYI_ORAN", new BigDecimal(6));
		rowData.put("BAYI_TUT", new BigDecimal(7));
		rowData.put("CAL_ORAN", new BigDecimal(8));
		rowData.put("CAL_TUT",new BigDecimal(9));
		
		saticiTanimList.add(rowData);
		
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("BIR_SATICI_TESVIK_TANIM", saticiTanimList);

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN3164_SAVE", iMap);
		assertNotNull(oMap.get("MESSAGE"));
		System.out.println(oMap.get("MESSAGE"));
	}
}
