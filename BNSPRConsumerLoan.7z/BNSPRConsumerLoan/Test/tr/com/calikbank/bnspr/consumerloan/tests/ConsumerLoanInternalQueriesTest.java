package tr.com.calikbank.bnspr.consumerloan.tests;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.HashMap;

import junit.framework.TestCase;

import com.graymound.connection.GMConnection;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class ConsumerLoanInternalQueriesTest extends TestCase {
	public void testDevamSorgular() throws IOException{
		GMMap gmInMap = new GMMap();
		GMConnection connection = GMConnection.getConnection("BANKING", gmInMap);	
		
		System.out.println((String)GMServiceExecuter.execute("BNSPR_COMMON_GET_BIREYSEL_SUBE_KODU", new GMMap()).get("SUBE_KODU"));
		//BigDecimal dosyaMasrafi = new BigDecimal(5555).multiply(new BigDecimal(1.99)).divide(new BigDecimal(100)).setScale(2, RoundingMode.CEILING);
		//System.out.println(new BigDecimal(13.4445).setScale(2, RoundingMode.CEILING));
		//System.out.println(new BigDecimal(13.4465).setScale(2, RoundingMode.CEILING));
		System.out.println(new BigDecimal(13.4445).setScale(2, RoundingMode.FLOOR));
		System.out.println(new BigDecimal(13.4465).setScale(2, RoundingMode.FLOOR));
		System.out.println(new BigDecimal(13.4445).setScale(2, RoundingMode.HALF_DOWN));
		System.out.println(new BigDecimal(13.4465).setScale(2, RoundingMode.HALF_DOWN));
		//System.out.println(new BigDecimal(13.4445).setScale(2, RoundingMode.UP));
		//System.out.println(new BigDecimal(13.4465).setScale(2, RoundingMode.UP));
//		GMMap gmInMap = new GMMap();
//		GMConnection connection = GMConnection.getConnection("BANKING", gmInMap);		
//
//		GMMap iMap = new GMMap();
//		iMap.put("BASVURU_NO", new BigDecimal(995));
//		iMap.put("BARKOD_NO", "44444");
//		
//		HashMap<?, ?> oMap =  (HashMap<?, ?>) connection.serviceCall("BNSPR_TRN3182_GET_BELGE_LIST_FOR_HOBIM", iMap);
//		
//		System.out.println("oMap : " + oMap);
//		
//		iMap.putAll(oMap);
//
//		HashMap<?, ?> oMap2 = (HashMap<?, ?>) connection.serviceCall("BNSPR_TRN3182_SAVE_FOR_HOBIM", iMap);
//		
//		System.out.println("oMap2 : " + oMap2);
	}
}
