package tr.com.calikbank.bnspr.consumerloan.tests;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;
import com.graymound.util.GMRuntimeException;

public class ConsumerLoanTRN3165Test extends TestCase {

	public String getTransactionNo() {
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String) oMap.get("TRX_NO");
	}

	public void testsaveTRN3165() {

		HashMap<String, Object> iMap = new HashMap<String, Object>();

		// ----------------------------------------------------------------------------------------

		iMap.put("TRX_NO", getTransactionNo());

		iMap.put("SATICI_KOD", new BigDecimal(1));
		iMap.put("KAZANDIRAN_KANAL", "1");
		iMap.put("TAKYIDAT_EH", "E");
		iMap.put("KEFALET_YETKI_EH", "E");
		iMap.put("ISYERI_ADRES_AYNI_EH", "H");
		iMap.put("TELEFON_NO_AYNI_EH", "H");
		iMap.put("BEYAN_BILGI_SORGULAMA_AYNI_EH", "E");
		iMap.put("TCMB_SORGU_SONUCU", "Emircan");
		iMap.put("TCMB_SORGU_SONUCU_ACK", "Kalyoncu");
		iMap.put("FAAL_KONUSU_ACK", "QWERTY");

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		try {
			iMap.put("IPTAL_TAR", dateFormat.parse("04.11.2008"));
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}

		// ----------------------------------------------------------------------------------------------------

		ArrayList<HashMap<String, Object>> birSaticiTahsisOrtaklar = new ArrayList<HashMap<String, Object>>();
		HashMap<String, Object> ortakData = new HashMap<String, Object>();
		ortakData.put("SATICI_KOD", new BigDecimal(1));
		ortakData.put("ORTAK_ADI", "Asl�");
		ortakData.put("ORTAKLIK_PAY", new BigDecimal(90));
		ortakData.put("TCMB_KKB_SONUCU", "Temiz");
		ortakData.put("ACIKLAMA", "Her�ey dahil..");
		birSaticiTahsisOrtaklar.add(ortakData);
		iMap.put("BIR_SATICI_TAHSIS_ORTAKLAR", birSaticiTahsisOrtaklar);

		// ----------------------------------------------------------------------------------------

		ArrayList<HashMap<String, Object>> birSaticiTahsisFinans = new ArrayList<HashMap<String, Object>>();
		HashMap<String, Object> finansData = new HashMap<String, Object>();
		finansData.put("SATICI_KOD", new BigDecimal(1));
		finansData.put("GELIR_NET_SATIS", new BigDecimal(10));
		finansData.put("GELIR_KAR_ZARAR", new BigDecimal(20));
		finansData.put("GELIR_VERGI_MATRAH", new BigDecimal(3));
		finansData.put("BIL_AKTIF_TOP", new BigDecimal(4));
		finansData.put("BIL_DONEN_VARLIK_TOP", new BigDecimal(5));
		finansData.put("BIL_TICARI_ALACAK", new BigDecimal(6));
		finansData.put("BIL_STOK", new BigDecimal(7));
		finansData.put("BIL_ORTAK_ALACAK", new BigDecimal(8));
		finansData.put("BIL_DURAN_VAR_TOP", new BigDecimal(9));
		finansData.put("BIL_MALI_DURAN_VARLIK", new BigDecimal(22));
		finansData.put("MALI_KISA_VADE_BORC", new BigDecimal(11));
		finansData.put("MALI_BANKA_KREDI", new BigDecimal(44));
		finansData.put("MALI_TICARI_BORC", new BigDecimal(33));
		finansData.put("MALI_ORTAKLARA_BORC", new BigDecimal(55));
		finansData.put("MALI_UZUN_VADELI_BORC", new BigDecimal(66));
		finansData.put("MALI_OZKAYNAK", new BigDecimal(77));
		finansData.put("MALI_ODENMIS_SERMAYE", new BigDecimal(88));
		finansData.put("MALI_GEC_VERGI_BORC", new BigDecimal(99));
		finansData.put("MALI_GEC_SSK_BORC", new BigDecimal(100));
		finansData.put("ACIKLAMA", "A��klama girmek istemiyor..");

		try {
			finansData.put("DONEM", dateFormat.parse("04.02.2008"));
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}

		birSaticiTahsisFinans.add(finansData);
		iMap.put("BIR_SATICI_TAHSIS_FINANS", birSaticiTahsisFinans);

		// ----------------------------------------------------------------------------------------

		iMap.put("USERNAME", "BNSPR");
		iMap.put("PASSWORD", "cd02588a9436a3a448f6e1b0743d7971e2c6ef23");
		iMap.put("LANGUAGE", "TR");

		GMResourceFactory.getInstance().service("BNSPR_USER_AUTHENTICATE", iMap);

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN3165_SAVE", iMap);
		assertNotNull(oMap.get("MESSAGE"));
		System.out.println(oMap.get("MESSAGE"));

	}

	public void testGetSaticiTahsisBilgi() {

		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("KOD", new BigDecimal(1));

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN3165_GET_SATICI_TAHSIS_BILGI", iMap);

		System.out.println(oMap.get("KURULUS_TARIHI").getClass());
		System.out.println(oMap);

	}

}
