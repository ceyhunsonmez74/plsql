package tr.com.calikbank.bnspr.consumerloan.tests;

import java.util.HashMap;
import java.util.Map;
import com.graymound.resource.GMResourceFactory;
import junit.framework.TestCase;

public class ConsumerLoanTRN3103Test extends TestCase{
	public void testCanGetcomboBoxValue(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN3103_GET_COMBOBOX_INITIAL_VALUES", new HashMap<String, Object>());
		assertNotNull(oMap.get("GECERLI_MI"));
		assertNotNull(oMap.get("MUSTERI_TIPI"));
		assertNotNull(oMap.get("INT_GORNTUMELENME"));
	}
	public void testCanGetKanalKodu(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN3103_GET_KANAL_KODU", new HashMap<String, Object>());
		assertNotNull(oMap.get("KANAL_KODU"));
	}
	

}
