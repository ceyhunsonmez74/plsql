package tr.com.calikbank.bnspr.accounting.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class AccountingChargesTest extends TestCase{
	
	
	public HashMap<String, Object> setUpIMap(){
		
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO",4508);
		iMap.put("SIRA", 1);
		iMap.put("MASRAF_KODU", "ARBITRAJ");
		iMap.put("ALINAN", 1);
		
		return iMap;
	}
	
	public void testGetBSMVServiceitsTrue(){
		HashMap<String, Object> iMap=setUpIMap();
				
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_CHARGES_GET_BSMV", iMap);		
		assertTrue(oMap.get("BSMV") instanceof BigDecimal);
		
	}
	public void testGetBSMVServiceValueBSMV(){
		HashMap<String, Object> iMap=setUpIMap();
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_CHARGES_GET_BSMV", iMap);		
		assertEquals("",new Double(0.05),(Double.parseDouble(oMap.get("BSMV").toString())) ,new Double(0.2));
	
	}
	
	public void testGetInfoServiceValueAdi(){
		HashMap<String, Object> iMap=setUpIMap();		
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_CHARGES_GET_INFO", iMap);		
		List<?> list=(List<?>) oMap.get("LIST");
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()){
			
			HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("Arbitraj Masraf�", rowData.get("ADI"));
		}		
	}
	
	public void testGetInfoServiceValueHesaplanan(){
		HashMap<String, Object> iMap=setUpIMap();		
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_CHARGES_GET_INFO", iMap);		
		List<?> list=(List<?>) oMap.get("LIST");
		
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()){
			
			HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("",new Double(1.00),(Double.parseDouble(rowData.get("HESAPLANAN").toString())),new Double(0.2));
		}	
		
	}
	
	public void testGetInfoServiceValueAlinan(){
		HashMap<String, Object> iMap=setUpIMap();		
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_CHARGES_GET_INFO", iMap);		
		List<?> list=(List<?>) oMap.get("LIST");
		
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()){
			
			HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
			assertEquals("",new Double(1.00),(Double.parseDouble(rowData.get("ALINAN").toString())),new Double(0.2));
		}	
		
	}
	
	public void testGetInfoServiceValueBsmv(){
		HashMap<String, Object> iMap=setUpIMap();		
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_CHARGES_GET_INFO", iMap);		
		List<?> list=(List<?>) oMap.get("LIST");
		
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()){
			
		HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
		assertEquals("",new Double(0.05),(Double.parseDouble(rowData.get("BSMV").toString())),new Double(0.2));
		}	
		
	}
	
	public void testGetInfoServiceValueDoviz(){
		HashMap<String, Object> iMap=setUpIMap();		
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_CHARGES_GET_INFO", iMap);		
		List<?> list=(List<?>) oMap.get("LIST");
		
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()){
			
		HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
		assertEquals("USD",rowData.get("DOVIZ"));
		}	
		
	}
	public void testGetInfoServiceValueOdeyecek(){
		HashMap<String, Object> iMap=setUpIMap();		
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_CHARGES_GET_INFO", iMap);		
		List<?> list=(List<?>) oMap.get("LIST");
		
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()){
			
		HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
		assertEquals("M��teri",rowData.get("ODEYECEK"));
		}	
		
	}
	public void testGetInfoServiceTypeitsTrue(){
		HashMap<String, Object> iMap=setUpIMap();		
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_CHARGES_GET_INFO", iMap);		
		List<?> list=(List<?>) oMap.get("LIST");
		
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()){
			
		HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
		assertTrue(rowData.get("ADI") instanceof String);
		assertTrue(rowData.get("HESAPLANAN") instanceof BigDecimal);
		assertTrue(rowData.get("ALINAN") instanceof String);
		assertTrue(rowData.get("BSMV") instanceof String);
		assertTrue(rowData.get("DOVIZ") instanceof String);
		assertTrue(rowData.get("ODEYECEK") instanceof String);
		
		}	
		
	}
	
}
