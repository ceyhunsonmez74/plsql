package tr.com.calikbank.bnspr.accounting.tests;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class AccountingQRY1105Test extends TestCase {
	public HashMap<String, Object> setUpIMap() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try {
			iMap.put("BAS_TARIH", (java.util.Date) dateFormat
					.parse("11-11-2005"));
			iMap.put("SON_TARIH", (java.util.Date) dateFormat
					.parse("27-12-2008"));
		} catch (Exception e) {
		}

		iMap.put("ISLEM_NO", 2013);
		iMap.put("NUMARA", 324);

		return iMap;
	}

	public void testCanGetCorrectValueMuhFisRecord() {
		HashMap<String, Object> iMap = setUpIMap();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_QRY1105_GET_MUH_FIS_RECORD", iMap);
		List<?> list = (List<?>) oMap.get("SATIR_BILGILERI");
		Iterator<?> iter = list.iterator();
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("324", rowData.get("NUMARA"));
			assertEquals("G", rowData.get("TUR"));
			assertEquals("200", rowData.get("BOLUM"));
			assertEquals("39099100", rowData.get("HESAP_NUMARA"));
			assertEquals("2007-10-17", ((Date) rowData.get("VALOR_TARIHI"))
					.toString());
			assertEquals("-2.89", rowData.get("NDB_LC_TUTAR"));
			assertEquals("-2.89", rowData.get("NDB_FC_TUTAR"));
			// assertEquals("", rowData.get("BANKA_ACIKLAMA"));
			// assertEquals("", rowData.get("MUSTERI_ACIKLAMA"));
			assertEquals(null, rowData.get("REFERANS"));
			assertEquals("VS", rowData.get("MUSTERI_HESAP_TUR"));
			assertEquals("243", rowData.get("MUSTERI_HESAP_NUMARA"));
			assertEquals("8443", rowData.get("ISTATISTIK_KODU"));
			assertEquals("2007-10-17", ((Date) rowData
					.get("MUHASEBELESTIGI_TARIH")).toString());
			assertEquals("BNSPR", rowData.get("YARATAN_KULLANICI_KODU"));
			// assertEquals("", rowData.get("ACIKLAMA"));
			assertEquals("1.22", rowData.get("KUR"));
			assertEquals("B", rowData.get("BORC_ALACAK"));

		}
		// assertEquals("",new Double(-1.66),(Double.parseDouble(oMap.get("ALACAK").toString())),new Double(0.2));
		// assertEquals("-6.10",oMap.get("BORC"));
		// assertEquals("4.44",oMap.get("BALANS"));
	}

	public void testCanGetCorrectValueFcToplam() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("NUMARA", 324);

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_QRY1105_GET_MUH_FC_TOTAL", iMap);
		List<?> list = (List<?>) oMap.get("FC_TOPLAM");
		Iterator<?> iter = list.iterator();
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>)iter.next();
			assertEquals("TRY",rowData.get("DOVIZ_KOD"));
			assertEquals("2.89", rowData.get("NDB_DV_TUTAR_ALACAK"));
			assertEquals("2.89", rowData.get("NDB_DV_TUTAR_BORC"));
		}
	}
	public void testCanConvertUtilDateToSqldateWithBaslangicTarih() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try {
			iMap.put("BAS_TARIH", (java.util.Date) dateFormat
					.parse("11-11-2005"));		
		} catch (Exception e) {}	

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_QRY1105_GET_SQL_BAS_DATE", iMap);
		assertEquals("11.11.2005", (oMap.get("BAS_TARIH")).toString());
	}
	public void testCanConvertUtilDateToSqldateWithBitisTarih() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try {
			iMap.put("SON_TARIH", (java.util.Date) dateFormat
					.parse("27-12-2008"));
		} catch (Exception e) {}	

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_QRY1105_GET_SQL_BIT_DATE", iMap);
		assertEquals("27.12.2008", (oMap.get("SON_TARIH")).toString());
	}
}
