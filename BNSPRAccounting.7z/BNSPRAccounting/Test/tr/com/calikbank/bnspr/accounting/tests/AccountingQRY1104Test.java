package tr.com.calikbank.bnspr.accounting.tests;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class AccountingQRY1104Test extends TestCase {

	public void testCanGetCoorectCbsDetayListValue() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try {
			iMap.put("TARIH", dateFormat.parse("01-01-2007"));
		} catch (Exception e) {
		}
		iMap.put("SUBE_KODU", "200");

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_QRY1104_GET_MIZAN_HAREKET_INFO", iMap);
		List<?> list = (List<?>) oMap.get("CBS_DETAY");
		Iterator<?> iter = list.iterator();
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("02000400", rowData.get("DK_NUMARA"));
			assertEquals("TRL", rowData.get("DOVIZ_KOD"));
			assertEquals("EFT HESABI", rowData.get("ACIKLAMA"));
			assertEquals(new BigDecimal(65625000), rowData.get("ALACAK_FC"));
			assertEquals(new BigDecimal(65625000), rowData.get("ALACAK_LC"));
			assertEquals(new BigDecimal(65625000), rowData.get("BORC_FC"));
			assertEquals(new BigDecimal(65625000), rowData.get("BORC_LC"));
			assertEquals(new BigDecimal(0), rowData.get("BAKIYE_FC"));
			assertEquals(new BigDecimal(0), rowData.get("BAKIYE_LC"));
		}
	}

	public void testCBSDetayNotNull() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try {
			iMap.put("TARIH", dateFormat.parse("01-01-2007"));
		} catch (Exception e) {
		}
		iMap.put("SUBE_KODU", "200");

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_QRY1104_GET_MIZAN_HAREKET_INFO", iMap);
		List<?> list = (List<?>) oMap.get("CBS_DETAY");
		Iterator<?> iter = list.iterator();
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			assertNotNull(rowData.get("DK_NUMARA"));
			assertNotNull(rowData.get("DOVIZ_KOD"));
			assertNotNull(rowData.get("ACIKLAMA"));
			assertNotNull(rowData.get("ALACAK_FC"));
			assertNotNull(rowData.get("ALACAK_LC"));
			assertNotNull(rowData.get("BORC_FC"));
			assertNotNull(rowData.get("BORC_LC"));
			assertNotNull(rowData.get("BAKIYE_FC"));
			assertNotNull(rowData.get("BAKIYE_LC"));
		}
	}

	public void testCanGetCoorectCbsToplamListValue() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try {
			iMap.put("TARIH", dateFormat.parse("01-01-2007"));
		} catch (Exception e) {
		}
		iMap.put("SUBE_KODU", "200");

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_QRY1104_GET_MIZAN_HAREKET_INFO", iMap);
		List<?> list = (List<?>) oMap.get("CBS_DETAY_TOPLAM");
		Iterator<?> iter = list.iterator();
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("699717.88", rowData.get("ALACAK_FC"));
			assertEquals("1195432323797", rowData.get("ALACAK_LC"));
			assertEquals("0", rowData.get("BAKIYE_FC"));
			assertEquals("0", rowData.get("BAKIYE_LC"));
			assertEquals("699717.88", rowData.get("BORC_FC"));
			assertEquals("1195432323797", rowData.get("BORC_LC"));
			assertEquals("EUR", rowData.get("SUM_DOVIZ_KOD"));
		}
	}

	public void testCanGetCoorectCbsNazimListValue() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try {
			iMap.put("TARIH", dateFormat.parse("01-01-2007"));
		} catch (Exception e) {
		}
		iMap.put("SUBE_KODU", "200");

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_QRY1104_GET_MIZAN_HAREKET_INFO", iMap);
		List<?> list = (List<?>) oMap.get("CBS_NAZIM");
		Iterator<?> iter = list.iterator();
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("TRL", rowData.get("SUM_NAZIM_DOVIZ_KOD"));
			assertEquals("156335957226", rowData.get("SUM_NAZIM_BORC_LC_GENEL"));
			assertEquals("156335957226", rowData.get("SUM_NAZIM_BORC_FC_GENEL"));
			assertEquals("156335957226", rowData
					.get("SUM_NAZIM_ALACAK_LC_GENEL"));
			assertEquals("156335957226", rowData
					.get("SUM_NAZIM_ALACAK_FC_GENEL"));
			assertEquals("0", rowData.get("SUM_NAZIM_BAKIYE_LC_GENEL"));
			assertEquals("0", rowData.get("SUM_NAZIM_BAKIYE_FC_GENEL"));
		}
	}

	public void testCanGetCoorectGeneralValue() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try {
			iMap.put("TARIH", dateFormat.parse("01-01-2007"));
		} catch (Exception e) {
		}
		iMap.put("SUBE_KODU", "200");

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_QRY1104_GET_MIZAN_HAREKET_INFO", iMap);
		
		assertEquals("116873692297086", oMap.get("SUM_BORC_LC_GENEL"));
		assertEquals("116873692151419", oMap.get("SUM_ALACAK_LC_GENEL"));
		assertEquals("98266110514723.34", oMap.get("SUM_BORC_FC_GENEL"));
		assertEquals("98266111514722.56", oMap.get("SUM_ALACAK_FC_GENEL"));
		assertEquals("-145667", oMap.get("SUM_BAKIYE_LC_GENEL"));
		assertEquals("999999.22", oMap.get("SUM_BAKIYE_FC_GENEL"));
		assertEquals(null, oMap.get("SUM_FAIZ_GELIR"));
		assertEquals("999999.22", oMap.get("SUM_BAKIYE_FC_GENEL"));
		assertEquals(null, oMap.get("SUM_FAIZ_GIDER"));
		assertEquals("750395124", oMap.get("SUM_FAIZ_DISI_GELIR"));
		assertEquals("-2734539686419", oMap.get("SUM_FAIZ_DISI_GIDER"));
		
	}

}
