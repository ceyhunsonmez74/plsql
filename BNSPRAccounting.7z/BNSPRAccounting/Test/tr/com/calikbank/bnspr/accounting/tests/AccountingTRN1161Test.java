package tr.com.calikbank.bnspr.accounting.tests;

import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;
import com.graymound.util.GMMap;

public class AccountingTRN1161Test extends TestCase{
	public void testCanGetTxNo(){
		GMMap iMap = new GMMap();
		iMap.put("KANAL", (String)null);
		iMap.put("MK_TURU", (String)null);
		iMap.put("MODUL", (String)null);
		iMap.put("KAYIT_TURU", (String)null);
		iMap.put("DURUM", (String)null);
		iMap.put("BAS_TARIH", (String)null);
		iMap.put("SON_TARIH", (String)null);
		iMap.put("MUSTERI_TIP", (String)null);
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN1161_GET_TRX_NO", iMap);
		System.out.println(oMap.get("TRX_NO"));
		assertNotNull(oMap.get("TRX_NO"));
	}
}
