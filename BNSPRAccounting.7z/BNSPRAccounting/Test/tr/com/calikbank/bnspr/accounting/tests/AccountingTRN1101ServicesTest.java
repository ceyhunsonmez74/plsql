package tr.com.calikbank.bnspr.accounting.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class AccountingTRN1101ServicesTest extends TestCase {
	private static final BigDecimal sampleHesapNo = new BigDecimal(114);
	private static final BigDecimal sampleBalance = new BigDecimal(21889);
	private static final BigDecimal samplePersonelMi = new BigDecimal(0);
	
	public void testCanBalanceInfo() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("HESAP_NO", sampleHesapNo);
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN1101_GET_ACCOUNT_BALANCE", iMap);
		BigDecimal balance = (BigDecimal)oMap.get("BALANCE");
		BigDecimal personelMi = (BigDecimal)oMap.get("PERSONELMI");
		assertEquals(sampleBalance, balance);
		System.out.println("Bakiye: " + balance);
		assertEquals(samplePersonelMi, personelMi);
		System.out.println("Personel mi: " + personelMi);
	}
	
	public void testLCTutar() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("BA_TUR", "B");
		iMap.put("HESAP_TUR_KODU", "VS");
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("HESAP_NO", new BigDecimal(114));
		iMap.put("DV_TUTAR", new BigDecimal(1000));
		iMap.put("KUR", new BigDecimal(1.22));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN1101_GET_LC_TUTAR", iMap);
		BigDecimal tutar = (BigDecimal)oMap.get("LC_TUTAR");
		assertEquals(new BigDecimal(1220), tutar);
		System.out.println("Tutar: " + tutar);
	}
	
	public void testCanGetKur() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "USD");
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN1101_GET_KUR", iMap);
		BigDecimal kur = (BigDecimal)oMap.get("KUR");
		assertEquals(1.33, kur.doubleValue(), 0.009);
		System.out.println(kur);
	}
}
