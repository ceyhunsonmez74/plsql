package tr.com.calikbank.bnspr.accounting.tests;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;
import com.graymound.util.GMMap;

public class AccountingQRY1161Test extends TestCase{
	public void testCanGetMasrafKomisyonList(){
		GMMap iMap = new GMMap();
		iMap.put("MUSTERI_NO", (BigDecimal)null);
		iMap.put("KANAL_NUMARA",(String)null );
		iMap.put("BAS_TARIH", (Date)null);
		iMap.put("SON_TARIH", (Date)null);
		iMap.put("KAYIT_TURU",(String)null);
		iMap.put("MASKOM_TURU", (String)null);
		iMap.put("ILK_TUTAR", new BigDecimal(0));
		iMap.put("SON_TUTAR", new BigDecimal(999999));
		iMap.put("DURUM", (String)null);
		iMap.put("TAHSILAT_DURUM", (String)null);
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY1161_GET_MASRAF_KOMISYON_LIST", iMap);
		List<?> list = (List<?>)oMap.get("MASRAF_KOMISYON_TAHSILAT");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?, ?> rowData = (HashMap<?, ?>)iter.next();
			assertNotNull(rowData.get("KANAL_NUMARA"));
			assertNotNull(rowData.get("AMIR_SUBE_KOD"));
		}
		System.out.println(list);
	}
}
