package tr.com.calikbank.bnspr.accounting.tests;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class AccountingQRY1101Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("DOVIZ_KODU", "EUR");
		iMap.put("SUBE_KODU",new BigDecimal(200));
		iMap.put("HAREKET_TURU","T");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-mm-yyyy");
		try{
			iMap.put("BAS_TARIH",(java.util.Date)dateFormat.parse("11-11-2005"));
			iMap.put("BIT_TARIH",(java.util.Date)dateFormat.parse("27-12-2008"));
		}catch (Exception e) {
		}
		iMap.put("BAS_TUTAR",new BigDecimal(0));
		iMap.put("BIT_TUTAR",new BigDecimal(10000000));
		iMap.put("BAS_DK",new BigDecimal(0));
		iMap.put("BIT_DK",new BigDecimal(100000000));
		
		return iMap;
	}
	public void testCanGetCorrectValueDkList(){
		HashMap<String, Object> iMap = setUpIMap();
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY1101_GET_DK_INFO", iMap);
		List<?> list = (List<?>)oMap.get("DK_HAREKET");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();		
			assertEquals("39099100",rowData.get("SATIR_HESAP_NUMARA"));
			assertEquals("EUR", rowData.get("SATIR_DOVIZ_KOD"));
			assertEquals(new BigDecimal(200), rowData.get("SATIR_HESAP_BOLUM_KODU"));
			assertEquals("123123123", rowData.get("SATIR_BANKA_ACIKLAMA"));

			try{
				assertEquals("2007-10-17", ((Date)rowData.get("FIS_YARATILDIGI_BANKA_TARIH")).toString());
			}catch (Exception e) {}
			assertEquals(new BigDecimal(254), rowData.get("FIS_NUMARA"));
			assertEquals(new BigDecimal(0), rowData.get("ALACAK_DI"));
			assertEquals(new BigDecimal(0), rowData.get("BORC_DI"));		
	
		}
	}
	public void testCanGetCorrectDkFormat() {	
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DK", "12");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY1101_CHECK_BAS_DK",iMap);
		assertEquals(0, oMap.get("FLAG"));
	}
}
