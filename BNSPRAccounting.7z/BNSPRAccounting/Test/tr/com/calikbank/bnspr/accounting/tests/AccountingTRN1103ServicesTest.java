package tr.com.calikbank.bnspr.accounting.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class AccountingTRN1103ServicesTest extends TestCase {
	public void testCanExecuteFunction() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TX_NO", new BigDecimal(9999999));
		iMap.put("DK_HESAP_BASLANGIC", "11111111");
		iMap.put("DK_HESAP_BITIS", "11222222");
		GMResourceFactory.getInstance().service("BNSPR_TRN1101_GET_DK_LIST", iMap);
		assertTrue(true);
	}
}
