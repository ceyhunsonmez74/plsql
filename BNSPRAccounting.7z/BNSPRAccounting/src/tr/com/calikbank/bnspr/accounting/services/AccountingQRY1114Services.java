package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingQRY1114Services {

	@GraymoundService("BNSPR_QRY1114_GET_RECORDS")
	public static GMMap getRecords(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc1114.rc1114_get_atlanan_fisler(?,?)}"); //PROSEDUR
			
			int i = 0;
			stmt.registerOutParameter(++i, -10);
			if(iMap.get("TARIH_BAS")!=null)
				stmt.setDate(++i, new Date(iMap.getDate("TARIH_BAS").getTime()));
			else 
				stmt.setDate(++i, null);

			if(iMap.get("TARIH_SON")!=null)
				stmt.setDate(++i, new Date(iMap.getDate("TARIH_SON").getTime()));
			else 
				stmt.setDate(++i, null);
			
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetResults(rSet, "FIS_LIST");
			
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
