package tr.com.calikbank.bnspr.accounting.services;

import java.awt.Color;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.Types;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMasrafKomKriterTx;
import tr.com.calikbank.bnspr.dao.GnlMasrafKomTanimPrTx;
import tr.com.calikbank.bnspr.dao.GnlMasrafKomTanimPrTxId;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1161Services {
	@GraymoundService("BNSPR_TRN1161_GET_TRX_NO")
	public static GMMap getTrxNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn
					.prepareCall("{? = call PKG_TRN1161.get_parameters(?,?,?,?,?,?,?,?,?)}");
			
			stmt.registerOutParameter(1, Types.DECIMAL);
			
			stmt.setString(2, iMap.getString("KANAL"));
			stmt.setString(3, iMap.getString("MK_TURU"));
			stmt.setString(4, iMap.getString("MUSTERI_TIP"));
			stmt.setString(5, iMap.getString("MODUL"));
			stmt.setString(6, iMap.getString("KAYIT_TURU"));
			stmt.setString(7, iMap.getString("DURUM"));
			if(iMap.getDate("BAS_TARIH")!=null)stmt.setDate(8, new Date(iMap.getDate("BAS_TARIH").getTime()));
			else stmt.setDate(8,null);
			if(iMap.getDate("SON_TARIH")!=null)stmt.setDate(9, new Date(iMap.getDate("SON_TARIH").getTime()));
			else stmt.setDate(9,null);
			stmt.setBigDecimal(10, iMap.getBigDecimal("ISLEM_KOD"));
						
			stmt.execute();

			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			
			return oMap;
		}catch (ParseException e) {
			throw ExceptionHandler.convertException(e);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN1161_GET_MASRAF_KOM_TANIM_LIST")
	public static GMMap getMasrafKomTanimList(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			List<?> list = session.createCriteria(GnlMasrafKomTanimPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			String tableName = "MASRAF_KOM_TANIM_PR";
			Integer row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlMasrafKomTanimPrTx gnlMasrafKomTanimPrTx = (GnlMasrafKomTanimPrTx)iterator.next();
				oMap.put(tableName, row,"MASKOM_ID",gnlMasrafKomTanimPrTx.getId().getMaskomId());
				oMap.put(tableName, row,"KANAL_KOD",gnlMasrafKomTanimPrTx.getKanalKod());
				oMap.put(tableName, row,"MUSTERI_TIPI",gnlMasrafKomTanimPrTx.getMusteriTipi());
				oMap.put(tableName, row,"KAYIT_TURU",gnlMasrafKomTanimPrTx.getMK());
				oMap.put(tableName, row,"MODUL_KOD",gnlMasrafKomTanimPrTx.getModulKod());
				oMap.put(tableName, row,"ISLEM_KODU",gnlMasrafKomTanimPrTx.getIslemKod());
				oMap.put(tableName, row,"DEGISTIRILEBILIR",GuimlUtil.convertToCheckBoxValue(gnlMasrafKomTanimPrTx.getDegistirilebilir()));
				oMap.put(tableName, row,"DOVIZ_KODU",gnlMasrafKomTanimPrTx.getDovizKod());
				oMap.put(tableName, row,"END_DATE",gnlMasrafKomTanimPrTx.getEndDate());
				oMap.put(tableName, row,"MASKOM_ORAN",gnlMasrafKomTanimPrTx.getMaskomOran());
				oMap.put(tableName, row,"MASKOM_TURU",gnlMasrafKomTanimPrTx.getMaskomKod());
				oMap.put(tableName, row,"MASKOM_TUTAR",gnlMasrafKomTanimPrTx.getMaskomTutar());
				oMap.put(tableName, row,"MAX_ISLEM_TUTAR",gnlMasrafKomTanimPrTx.getMaxIslemTutar());
				oMap.put(tableName, row,"MAX_MASKOM_TUTAR",gnlMasrafKomTanimPrTx.getMaxMaskomTutar());
				oMap.put(tableName, row,"MIN_ISLEM_TUTAR",gnlMasrafKomTanimPrTx.getMinIslemTutar());
				oMap.put(tableName, row,"MIN_MASKOM_TUTAR",gnlMasrafKomTanimPrTx.getMinMaskomTutar());
				oMap.put(tableName, row,"START_DATE",gnlMasrafKomTanimPrTx.getStartDate());
				oMap.put(tableName, row,"TAHSILAT_DK",gnlMasrafKomTanimPrTx.getTahsilatDk());
				oMap.put(tableName, row,"ESKI_KAYIT" ,"ESKI");

				if (gnlMasrafKomTanimPrTx.getDrm().equals("I"))
				   oMap.put(tableName, row,"DRM","1");
				else
					oMap.put(tableName, row,"DRM","0");
				
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1161_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "MASRAF_KOM_TANIM_PR";
			List<?> list = (List<?>)iMap.get("MASRAF_KOM_TANIM_PR");
			for (int i = 0; i < list.size(); i++) {
				
				GnlMasrafKomTanimPrTxId gnlMasrafKomTanimPrTxId = new GnlMasrafKomTanimPrTxId();
				gnlMasrafKomTanimPrTxId.setMaskomId(iMap.getBigDecimal(tableName,i,"MASKOM_ID"));
				gnlMasrafKomTanimPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlMasrafKomTanimPrTxId.setEskiYeni("Y");
				
				GnlMasrafKomTanimPrTx gnlMasrafKomTanimPrTx = (GnlMasrafKomTanimPrTx)session.get(GnlMasrafKomTanimPrTx.class,gnlMasrafKomTanimPrTxId);
				
				if(gnlMasrafKomTanimPrTx == null)gnlMasrafKomTanimPrTx = new GnlMasrafKomTanimPrTx();
				
				gnlMasrafKomTanimPrTx.setId(gnlMasrafKomTanimPrTxId);
				gnlMasrafKomTanimPrTx.setDegistirilebilir(GuimlUtil.convertFromCheckBoxValue(iMap.getString(tableName,i,"DEGISTIRILEBILIR")));
				gnlMasrafKomTanimPrTx.setDovizKod(iMap.getString(tableName,i,"DOVIZ_KODU"));
				
				if (iMap.getString(tableName,i,"DRM").equals("1"))
					gnlMasrafKomTanimPrTx.setDrm("I");
				else
					gnlMasrafKomTanimPrTx.setDrm("A");

				gnlMasrafKomTanimPrTx.setEndDate(iMap.getDate(tableName, i, "END_DATE"));
				gnlMasrafKomTanimPrTx.setIslemKod(iMap.getBigDecimal(tableName,i,"ISLEM_KODU"));
				gnlMasrafKomTanimPrTx.setKanalKod(iMap.getString(tableName, i, "KANAL_KOD"));
				gnlMasrafKomTanimPrTx.setMK(iMap.getString(tableName, i, "KAYIT_TURU"));
				gnlMasrafKomTanimPrTx.setMaskomOran(iMap.getBigDecimal(tableName,i,"MASKOM_ORAN"));
				gnlMasrafKomTanimPrTx.setMaskomKod(iMap.getString(tableName, i, "MASKOM_TURU"));
				gnlMasrafKomTanimPrTx.setMaskomTutar(iMap.getBigDecimal(tableName, i, "MASKOM_TUTAR"));
				gnlMasrafKomTanimPrTx.setMaxIslemTutar(iMap.getBigDecimal(tableName,i,"MAX_ISLEM_TUTAR"));
				gnlMasrafKomTanimPrTx.setMaxMaskomTutar(iMap.getBigDecimal(tableName,i,"MAX_MASKOM_TUTAR"));
				gnlMasrafKomTanimPrTx.setMinIslemTutar(iMap.getBigDecimal(tableName,i,"MIN_ISLEM_TUTAR"));
				gnlMasrafKomTanimPrTx.setMinMaskomTutar(iMap.getBigDecimal(tableName,i,"MIN_MASKOM_TUTAR"));
				gnlMasrafKomTanimPrTx.setModulKod(iMap.getString(tableName,i,"MODUL_KOD"));
				gnlMasrafKomTanimPrTx.setMusteriTipi(iMap.getString(tableName,i,"MUSTERI_TIPI"));
				gnlMasrafKomTanimPrTx.setStartDate(iMap.getDate(tableName, i, "START_DATE"));
				gnlMasrafKomTanimPrTx.setTahsilatDk(iMap.getString(tableName,i,"TAHSILAT_DK"));
				
				session.saveOrUpdate(gnlMasrafKomTanimPrTx);
			}

			session.flush();
			
			GnlMasrafKomKriterTx gnlMasrafKomKriterTx = new GnlMasrafKomKriterTx();
			
			gnlMasrafKomKriterTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			gnlMasrafKomKriterTx.setKanalKod(iMap.getString("KANAL_KOD"));
			gnlMasrafKomKriterTx.setMusteriTipi(iMap.getString("MUSTERI_TIPI"));
			gnlMasrafKomKriterTx.setKayitTuru(iMap.getString("KAYIT_TURU"));
			gnlMasrafKomKriterTx.setStartDate(iMap.getDate("START_DATE"));
			gnlMasrafKomKriterTx.setEndDate(iMap.getDate("END_DATE"));
			gnlMasrafKomKriterTx.setMaskomKod(iMap.getString("MASKOM_TURU"));
			gnlMasrafKomKriterTx.setModulKod(iMap.getString("MODUL"));
			gnlMasrafKomKriterTx.setDrm(iMap.getString("STATU"));
			gnlMasrafKomKriterTx.setIslemKod(iMap.getBigDecimal("ISLEM_KOD"));
			
			session.save(gnlMasrafKomKriterTx);
			session.flush();
			
			iMap.put("TRX_NAME", "1161");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		}catch (Exception e) {
			System.out.println(e.getMessage());
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1161_GET_MASRAF_KOM_TANIM_INFO")
	public static GMMap getMasrafKomTanimInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> list = (List<?>)session.createCriteria(GnlMasrafKomTanimPrTx.class)
										.add(Restrictions.eq("id.txNo"		, iMap.getBigDecimal("TRX_NO")))
										.add(Restrictions.eq("id.eskiYeni"	, "Y"))
										.list();			
			String tableName = "MASRAF_KOM_TANIM_PR";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlMasrafKomTanimPrTx gnlMasrafKomTanimPrTx = (GnlMasrafKomTanimPrTx)iterator.next();
				oMap.put(tableName, row,"MASKOM_ID",gnlMasrafKomTanimPrTx.getId().getMaskomId());				
				oMap.put(tableName, row,"KANAL_KOD",gnlMasrafKomTanimPrTx.getKanalKod());
				oMap.put(tableName, row,"MUSTERI_TIPI",gnlMasrafKomTanimPrTx.getMusteriTipi());
				oMap.put(tableName, row,"KAYIT_TURU",gnlMasrafKomTanimPrTx.getMK());
				oMap.put(tableName, row,"MODUL_KOD",gnlMasrafKomTanimPrTx.getModulKod());
				oMap.put(tableName, row,"ISLEM_KODU",gnlMasrafKomTanimPrTx.getIslemKod());
				oMap.put(tableName, row,"DEGISTIRILEBILIR",GuimlUtil.convertToCheckBoxValue(gnlMasrafKomTanimPrTx.getDegistirilebilir()));
				oMap.put(tableName, row,"DOVIZ_KODU",gnlMasrafKomTanimPrTx.getDovizKod());
				oMap.put(tableName, row,"END_DATE",gnlMasrafKomTanimPrTx.getEndDate());
				oMap.put(tableName, row,"MASKOM_ORAN",gnlMasrafKomTanimPrTx.getMaskomOran());
				oMap.put(tableName, row,"MASKOM_TURU",gnlMasrafKomTanimPrTx.getMaskomKod());
				oMap.put(tableName, row,"MASKOM_TUTAR",gnlMasrafKomTanimPrTx.getMaskomTutar());
				oMap.put(tableName, row,"MAX_ISLEM_TUTAR",gnlMasrafKomTanimPrTx.getMaxIslemTutar());
				oMap.put(tableName, row,"MAX_MASKOM_TUTAR",gnlMasrafKomTanimPrTx.getMaxMaskomTutar());
				oMap.put(tableName, row,"MIN_ISLEM_TUTAR",gnlMasrafKomTanimPrTx.getMinIslemTutar());
				oMap.put(tableName, row,"MIN_MASKOM_TUTAR",gnlMasrafKomTanimPrTx.getMinMaskomTutar());
				oMap.put(tableName, row,"START_DATE",gnlMasrafKomTanimPrTx.getStartDate());
				oMap.put(tableName, row,"TAHSILAT_DK",gnlMasrafKomTanimPrTx.getTahsilatDk());
				if (gnlMasrafKomTanimPrTx.getDrm().equals("I")) oMap.put(tableName, row,"DRM","1");
				else oMap.put(tableName, row,"DRM","0");

				row++;
			}

			GnlMasrafKomKriterTx gnlMasrafKomKriterTx = (GnlMasrafKomKriterTx)session.get(GnlMasrafKomKriterTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", gnlMasrafKomKriterTx.getTxNo());
			oMap.put("KANAL_Q", gnlMasrafKomKriterTx.getKanalKod());
			oMap.put("DI_KANAL", LovHelper.diLov(gnlMasrafKomKriterTx.getKanalKod(), "1161/LOV_KANAL", "ACIKLAMA"));
			oMap.put("MUSTERI_TIPI_Q", gnlMasrafKomKriterTx.getMusteriTipi());
			oMap.put("KAYIT_TURU_Q", gnlMasrafKomKriterTx.getKayitTuru());
			oMap.put("MASKOM_TURU_Q", gnlMasrafKomKriterTx.getMaskomKod());
			oMap.put("DI_MASKOM_TURU_Q", LovHelper.diLov(gnlMasrafKomKriterTx.getMaskomKod(),gnlMasrafKomKriterTx.getKayitTuru(),"1161/LOV_MASKOM", "ACIKLAMA"));
			oMap.put("START_DATE_Q", gnlMasrafKomKriterTx.getStartDate());
			oMap.put("END_DATE_Q", gnlMasrafKomKriterTx.getEndDate());
			oMap.put("MODUL_Q", gnlMasrafKomKriterTx.getModulKod());
			oMap.put("STATU_Q", gnlMasrafKomKriterTx.getDrm());
			oMap.put("ISLEM_KOD", gnlMasrafKomKriterTx.getIslemKod());
			
			
			// Renklendirme

			List<?> oldList = (List<?>)session.createCriteria(GnlMasrafKomTanimPrTx.class)
												.add(Restrictions.eq("id.txNo"		, iMap.getBigDecimal("TRX_NO")))
												.add(Restrictions.eq("id.eskiYeni"	, "E"))
												.list();
			String oldTableName = "OLD_MASRAF_KOM_TANIM_PR";
			int _row = 0;
			for (Iterator<?> iterator = oldList.iterator(); iterator.hasNext();) {
				GnlMasrafKomTanimPrTx gnlMasrafKomTanimPrTx = (GnlMasrafKomTanimPrTx)iterator.next();
				oMap.put(oldTableName, _row, "MASKOM_ID"		, gnlMasrafKomTanimPrTx.getId().getMaskomId());				
				oMap.put(oldTableName, _row, "KANAL_KOD"		, gnlMasrafKomTanimPrTx.getKanalKod());
				oMap.put(oldTableName, _row, "MUSTERI_TIPI"		, gnlMasrafKomTanimPrTx.getMusteriTipi());
				oMap.put(oldTableName, _row, "KAYIT_TURU"		, gnlMasrafKomTanimPrTx.getMK());
				oMap.put(oldTableName, _row, "MODUL_KOD"		, gnlMasrafKomTanimPrTx.getModulKod());
				oMap.put(oldTableName, _row, "ISLEM_KODU"		, gnlMasrafKomTanimPrTx.getIslemKod());
				oMap.put(oldTableName, _row, "DEGISTIRILEBILIR"	,GuimlUtil.convertToCheckBoxValue(
															gnlMasrafKomTanimPrTx.getDegistirilebilir()));
				oMap.put(oldTableName, _row, "DOVIZ_KODU"		,gnlMasrafKomTanimPrTx.getDovizKod());
				oMap.put(oldTableName, _row, "END_DATE"			,gnlMasrafKomTanimPrTx.getEndDate());
				oMap.put(oldTableName, _row, "MASKOM_ORAN"		,gnlMasrafKomTanimPrTx.getMaskomOran());
				oMap.put(oldTableName, _row, "MASKOM_TURU"		,gnlMasrafKomTanimPrTx.getMaskomKod());
				oMap.put(oldTableName, _row, "MASKOM_TUTAR"		,gnlMasrafKomTanimPrTx.getMaskomTutar());
				oMap.put(oldTableName, _row, "MAX_ISLEM_TUTAR"	,gnlMasrafKomTanimPrTx.getMaxIslemTutar());
				oMap.put(oldTableName, _row, "MAX_MASKOM_TUTAR"	,gnlMasrafKomTanimPrTx.getMaxMaskomTutar());
				oMap.put(oldTableName, _row, "MIN_ISLEM_TUTAR"	,gnlMasrafKomTanimPrTx.getMinIslemTutar());
				oMap.put(oldTableName, _row, "MIN_MASKOM_TUTAR"	,gnlMasrafKomTanimPrTx.getMinMaskomTutar());
				oMap.put(oldTableName, _row, "START_DATE"		,gnlMasrafKomTanimPrTx.getStartDate());
				oMap.put(oldTableName, _row,"TAHSILAT_DK"		,gnlMasrafKomTanimPrTx.getTahsilatDk());
				if (gnlMasrafKomTanimPrTx.getDrm().equals("I")) oMap.put(oldTableName, _row,"DRM","1");
				else oMap.put(oldTableName, _row,"DRM","0");
				
				_row++;
			}
			
			oMap.putAll(BeanSetProperties.tableDifferenceWithCustomColumnColored((ArrayList<?>)oMap.get(oldTableName), (ArrayList<?>)oMap.get(tableName), "MASKOM_ID", "KANAL_KOD", Color.RED));
			// Renklendirme biti�
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1161_GET_PROPERTIES")
	public static GMMap get1161Properties(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			
			GnlMasrafKomTanimPrTx newGnlMasrafKomTanimPrTx = (GnlMasrafKomTanimPrTx)session.createCriteria(GnlMasrafKomTanimPrTx.class)
										.add(Restrictions.eq("id.txNo"		, iMap.getBigDecimal("TRX_NO")))
										.add(Restrictions.eq("id.maskomId"	, iMap.getBigDecimal("MASKOM_ID")))
										.add(Restrictions.eq("id.eskiYeni"	, "Y"))
										.uniqueResult();
			GnlMasrafKomTanimPrTx oldGnlMasrafKomTanimPrTx = (GnlMasrafKomTanimPrTx)session.createCriteria(GnlMasrafKomTanimPrTx.class)
										.add(Restrictions.eq("id.txNo"		, iMap.getBigDecimal("TRX_NO")))
										.add(Restrictions.eq("id.maskomId"	, iMap.getBigDecimal("MASKOM_ID")))
										.add(Restrictions.eq("id.eskiYeni"	, "E"))
										.uniqueResult();
			
			if(oldGnlMasrafKomTanimPrTx == null) {
				oldGnlMasrafKomTanimPrTx = new GnlMasrafKomTanimPrTx();
				GnlMasrafKomTanimPrTxId id = new GnlMasrafKomTanimPrTxId();
				oldGnlMasrafKomTanimPrTx.setId(id);
			}
			
			oMap.putAll(BeanSetProperties.reflectDifference(oldGnlMasrafKomTanimPrTx, newGnlMasrafKomTanimPrTx, oldGnlMasrafKomTanimPrTx.getId(), newGnlMasrafKomTanimPrTx.getId()));				
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
