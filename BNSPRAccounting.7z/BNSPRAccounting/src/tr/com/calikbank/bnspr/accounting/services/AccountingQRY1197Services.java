package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class AccountingQRY1197Services {
	
	@GraymoundService("BNSPR_QRY1197_SORGULA")
	public static GMMap sorgula(GMMap iMap){
		Connection 			conn	= null;
		CallableStatement 	stmt	= null;
		ResultSet 			rSet	= null;
		try{
	        GMMap oMap = new GMMap();
	        conn = DALUtil.getGMConnection();
	        
	        String musteriNo = iMap.getString("MUSTERI_NO");
	        String urunGrupKodu = iMap.getString("URUN_GRUP_KODU");
	        Date baslangicTarihi =  iMap.getDate("BAS_TARIH");
			Date bitisTarihi =  iMap.getDate("BIT_TARIH");
            // GUNCEL DURUM
            {
                stmt = conn.prepareCall("{? = call PKG_RC_ACCOUNTING.RC_QRY1197_GET_GUNCEL_DURUM(?,?)}");
                stmt.registerOutParameter(1, -10);
                stmt.setBigDecimal(2, new BigDecimal(musteriNo));
                stmt.setBigDecimal(3, new BigDecimal(urunGrupKodu));
                stmt.execute();
                rSet = (ResultSet) stmt.getObject(1);
                
                for(int i = 0; rSet.next(); i++){
                	if(i == 0){
                		oMap.put("BLNCO_KARDAMI_ZARARDAMI", rSet.getString("kardami_zarardami"));
                		oMap.put("BLNCO_DONEM_ICI_KAR", rSet.getString("donem_ici_kar"));
                		oMap.put("BLNCO_DONEM_ICI_ZARAR", rSet.getString("donem_ici_zarar"));
                		oMap.put("BLNCO_DONEM_DEVREDEN_ZARAR", rSet.getString("donem_devreden_zarar"));
                		oMap.put("BLNCO_MAHSUP_SONRASI_KAR", rSet.getString("mahsup_sonrasi_kar"));
                		oMap.put("BLNCO_MAHSUP_SONRASI_ZARAR", rSet.getString("mahsup_sonrasi_zarar"));
                		oMap.put("BLNCO_MAHSUP_DEVREDEN_ZARAR", rSet.getString("mahsup_devreden_zarar"));
                		oMap.put("BLNCO_IADEYE_KONU_VERGI", rSet.getString("iadeye_konu_vergi"));
                		oMap.put("BLNCO_SON_MAHSUPLASMA_TX", rSet.getString("son_mahsuplasma_tx"));
                		oMap.put("BLNCO_DONEM_ICI_ALINAN_VERGI", rSet.getString("donem_ici_alinan_vergi"));
                		oMap.put("BLNCO_DONEM_ICI_ODENMIS_VERGI", rSet.getString("donem_ici_odenmis_vergi"));
                		oMap.put("BLNCO_SON_MAHSUPLASMA_ODENEN", rSet.getString("son_mahsuplasma_odenen"));
                	}else{
                		oMap.put("DNMSL_KARDAMI_ZARARDAMI", rSet.getString("kardami_zarardami"));
                		oMap.put("DNMSL_DONEM_ICI_KAR", rSet.getString("donem_ici_kar"));
                		oMap.put("DNMSL_DONEM_ICI_ZARAR", rSet.getString("donem_ici_zarar"));
                		oMap.put("DNMSL_DONEM_DEVREDEN_ZARAR", rSet.getString("donem_devreden_zarar"));
                		oMap.put("DNMSL_DONEM_ICI_ODENMIS_IADE", rSet.getString("donem_ici_odenmis_iade"));
                	}
                }
            }
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            // ISLEM LISTESI
            {
                stmt = conn.prepareCall("{? = call PKG_RC_ACCOUNTING.RC_QRY1197_GET_ISLEM_LISTESI(?,?,?,?)}");
                stmt.registerOutParameter(1, -10);
                stmt.setBigDecimal(2, new BigDecimal(musteriNo));
                stmt.setBigDecimal(3, new BigDecimal(urunGrupKodu));
                stmt.setDate(4, baslangicTarihi != null ? new java.sql.Date(baslangicTarihi.getTime()) : null);
                stmt.setDate(5, bitisTarihi != null ? new java.sql.Date(bitisTarihi.getTime()) : null);
                stmt.execute();
                rSet = (ResultSet) stmt.getObject(1);
                oMap.putAll(DALUtil.rSetResults(rSet, "ISLEM_LISTESI"));
            }
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            // MAHSUPLASMA GECMISI
            {
                stmt = conn.prepareCall("{? = call PKG_RC_ACCOUNTING.RC_QRY1197_GET_MAHSUP_GECMISI(?,?,?,?)}");
                stmt.registerOutParameter(1, -10);
                stmt.setBigDecimal(2, new BigDecimal(musteriNo));
                stmt.setBigDecimal(3, new BigDecimal(urunGrupKodu));
                stmt.setDate(4, baslangicTarihi != null ? new java.sql.Date(baslangicTarihi.getTime()) : null);
                stmt.setDate(5, bitisTarihi != null ? new java.sql.Date(bitisTarihi.getTime()) : null);
                stmt.execute();
                rSet = (ResultSet) stmt.getObject(1);
                oMap.putAll(DALUtil.rSetResults(rSet, "MAHSUPLASMA_GECMISI"));
            }
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY1197_SET_TX_NO_LIST")
	public static GMMap createList(GMMap iMap){
		 GMMap oMap = new GMMap();

		try
		{
			List<BigDecimal>	list = new ArrayList<BigDecimal>();
			
			list.add(iMap.getBigDecimal("TX_NO"));
			
			oMap.put("TX_NO_LIST",list);
			
		return oMap;
	} catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	}
	}
}
