package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
 
import tr.com.aktifbank.bnspr.dao.MuhVergiiadeHesapTx;
import tr.com.aktifbank.bnspr.dao.MuhVergiiadeHesapTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1196Services {
    
	
	@GraymoundService("BNSPR_TRN1196_FILL_COMBO")
	public static GMMap fillCombo(GMMap iMap) {
		GMMap oMap = new GMMap();
		int i = 0;
 
		i=0;    
		oMap.put("MAHSUP", i, "NAME", "");
	    oMap.put("MAHSUP", i++, "VALUE", "");

	    oMap.put("MAHSUP", i, "NAME", "EVET");
	    oMap.put("MAHSUP", i++, "VALUE", "E");
	    
	    oMap.put("MAHSUP", i, "NAME", "HAYIR");
	    oMap.put("MAHSUP", i++, "VALUE", "H");

		return oMap;
	}
	
    @GraymoundService("BNSPR_TRN1196_GET_LIST")
    public static GMMap getList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        
        try{
        	conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN1196.GET_DATA(?)}");
            int i = 1;            
            stmt.registerOutParameter(i++ , -10);
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("MUSTERI_NO"));
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            GMMap oMap = new GMMap();
            oMap.putAll(DALUtil.rSetResults(rSet , "LIST"));
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @SuppressWarnings("unchecked")
    @GraymoundService("BNSPR_TRN1196_SAVE")
    public static GMMap saveList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        int i = 0;
        String table = "TBL_STOPAJ";
        Session session = DAOSession.getSession("BNSPRDal");

            
            try{
                while (i < iMap.getSize(table)){
                	MuhVergiiadeHesapTx muhVergiiadeHesapTx = new MuhVergiiadeHesapTx();
                	MuhVergiiadeHesapTxId muhVergiiadeHesapTxId = new MuhVergiiadeHesapTxId();
                	muhVergiiadeHesapTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                	muhVergiiadeHesapTxId.setMusteriNo(iMap.getBigDecimal("TBL_STOPAJ",i,"MUSTERI_NO"));
                    
                	muhVergiiadeHesapTx.setId(muhVergiiadeHesapTxId);
                	muhVergiiadeHesapTx.setHesapNo(iMap.getBigDecimal("TBL_STOPAJ",i,"HESAP_NO"));
                	muhVergiiadeHesapTx.setMahsupDisi(iMap.getString("TBL_STOPAJ",i,"MAHSUP_DISI"));
                    session.save(muhVergiiadeHesapTx);
                    i++;
                }
                session.flush();
                
                iMap.put("TRX_NAME" , "1196");
                GMMap oMap = new GMMap();
                oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap));
                return oMap;
            } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } finally{
                GMServerDatasource.close(rSet);
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
            }
        
    }
    
    @GraymoundService("BNSPR_TRN1196_VIEW_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<MuhVergiiadeHesapTx> bbtTMP = session
					.createCriteria(MuhVergiiadeHesapTx.class)
					.add(Restrictions.eq("id.txNo",
							iMap.getBigDecimal("TRX_NO"))).list();

			int i = 0;
			String tn = "TBL_STOPAJ";
			
			for (MuhVergiiadeHesapTx bb : bbtTMP) {
			

				oMap.put(tn, i, "HESAP_NO", bb.getHesapNo());
				oMap.put(tn, i, "MAHSUP_DISI", bb.getMahsupDisi());
				oMap.put(tn, i, "MUSTERI_NO", bb.getId().getMusteriNo());
				 
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
    }
    
}