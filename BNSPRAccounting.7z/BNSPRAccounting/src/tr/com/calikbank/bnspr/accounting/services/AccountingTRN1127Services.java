package tr.com.calikbank.bnspr.accounting.services;


import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Map;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import tr.com.aktifbank.bnspr.dao.MuhGeciciHesapTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1127Services {

	@GraymoundService("BNSPR_TRN1127_GET_LIST")
	public static GMMap getList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN1127.GET_LIST(?) }");

			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("REFERANS"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			GMMap oMap = new GMMap();
			while (rSet.next()) {
				oMap.put("BORC_MUSTERI_DK", rSet.getString("BORC_MUSTERI_DK"));
				oMap.put("BORC_MUSTERI_NO", rSet.getBigDecimal("BORC_MUSTERI_NO"));
				oMap.put("BORC_MUSTERI_ADI", rSet.getString("BORC_MUSTERI_ADI"));
				oMap.put("BORC_HESAP_NO", rSet.getString("BORC_HESAP_NO"));
				oMap.put("DOVIZ_KODU", rSet.getString("DOVIZ_KODU"));
				oMap.put("ALACAK_MUSTERI_DK", rSet.getString("ALACAK_MUSTERI_DK"));
				oMap.put("ALACAK_MUSTERI_NO", rSet.getBigDecimal("ALACAK_MUSTERI_NO"));
				oMap.put("ALACAK_MUSTERI_ADI", rSet.getString("ALACAK_MUSTERI_ADI"));
				oMap.put("ALACAK_HESAP_NO", rSet.getString("ALACAK_HESAP_NO"));
				oMap.put("TUTAR", rSet.getBigDecimal("TUTAR"));
				oMap.put("KUR", rSet.getBigDecimal("KUR"));
				oMap.put("ACIKLAMA", rSet.getString("ACIKLAMA"));
				oMap.put("KALAN_TUTAR", rSet.getBigDecimal("KALAN_TUTAR"));

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1127_SAVE")
	public static Map<?, ?> saveParameters(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			valiteRequest(iMap);
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");

			MuhGeciciHesapTx muhGeciciHesapTx = (MuhGeciciHesapTx) session.get(MuhGeciciHesapTx.class, iMap.getBigDecimal("TRX_NO"));

			if (muhGeciciHesapTx == null) {
				muhGeciciHesapTx = new MuhGeciciHesapTx();
			}

			muhGeciciHesapTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			muhGeciciHesapTx.setReferansNo(iMap.getString("REFERANS"));
			muhGeciciHesapTx.setBorcMusteriDk(iMap.getString("BORC_MUSTERI_DK"));
			muhGeciciHesapTx.setBorcMusteriNo(iMap.getBigDecimal("BORC_MUSTERI_NO"));
			muhGeciciHesapTx.setBorcHesapNo(iMap.getString("BORC_HESAP_NO"));
			muhGeciciHesapTx.setAlacakMusteriDk(iMap.getString("ALACAK_MUSTERI_DK"));
			muhGeciciHesapTx.setAlacakMusteriNo(iMap.getBigDecimal("ALACAK_MUSTERI_NO"));
			muhGeciciHesapTx.setAlacakHesapNo(iMap.getString("ALACAK_HESAP_NO"));
			muhGeciciHesapTx.setTutar(iMap.getBigDecimal("TUTAR"));
			muhGeciciHesapTx.setKur(iMap.getBigDecimal("KUR"));
			muhGeciciHesapTx.setAciklama(iMap.getString("ACIKLAMA"));
			muhGeciciHesapTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			muhGeciciHesapTx.setKapamaTutari(iMap.getBigDecimal("KAPAMA_TUTARI"));
			muhGeciciHesapTx.setKalanTutar(iMap.getBigDecimal("KALAN_TUTAR"));

			if (iMap.getBigDecimal("TUTAR").subtract(iMap.getBigDecimal("KAPAMA_TUTARI")).equals(new BigDecimal(0).setScale(2)) || (iMap.getBigDecimal("KALAN_TUTAR") != null) && (iMap.getBigDecimal("KALAN_TUTAR").subtract(iMap.getBigDecimal("KAPAMA_TUTARI")).equals(new BigDecimal(0)))) {
				muhGeciciHesapTx.setDurum("K");
			}
			else {
				muhGeciciHesapTx.setDurum("P");
			}

			session.saveOrUpdate(muhGeciciHesapTx);

			session.flush();

			iMap.put("TRX_NAME", "1127");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1127_GET_INFO")
	public static Map<?, ?> trn1127GetInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			MuhGeciciHesapTx muhGeciciHesapTx = (MuhGeciciHesapTx) session.createCriteria(MuhGeciciHesapTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (muhGeciciHesapTx == null) {
				muhGeciciHesapTx = new MuhGeciciHesapTx();
			}

			oMap.put("TRX_NO", muhGeciciHesapTx.getTxNo());
			oMap.put("REFERANS", muhGeciciHesapTx.getReferansNo());
			oMap.put("BORC_MUSTERI_DK", muhGeciciHesapTx.getBorcMusteriDk());
			oMap.put("BORC_MUSTERI_NO", muhGeciciHesapTx.getBorcMusteriNo());
			oMap.put("BORC_MUSTERI_ADI", DALUtil.getResult("select unvan from v_gnl_musteri_aktif where musteri_no = " + muhGeciciHesapTx.getBorcMusteriNo() + ""));
			oMap.put("BORC_HESAP_NO", muhGeciciHesapTx.getBorcHesapNo());
			oMap.put("ALACAK_MUSTERI_DK", muhGeciciHesapTx.getAlacakMusteriDk());
			oMap.put("ALACAK_MUSTERI_NO", muhGeciciHesapTx.getAlacakMusteriNo());
			oMap.put("ALACAK_MUSTERI_ADI", DALUtil.getResult("select unvan from v_gnl_musteri_aktif where musteri_no = " + muhGeciciHesapTx.getAlacakMusteriNo() + ""));
			oMap.put("ALACAK_HESAP_NO", muhGeciciHesapTx.getAlacakHesapNo());
			oMap.put("TUTAR", muhGeciciHesapTx.getTutar());
			oMap.put("KUR", muhGeciciHesapTx.getKur());
			oMap.put("ACIKLAMA", muhGeciciHesapTx.getAciklama());
			oMap.put("DOVIZ_KODU", muhGeciciHesapTx.getDovizKodu());
			oMap.put("KAPAMA_TUTARI", muhGeciciHesapTx.getKapamaTutari());
			oMap.put("KALAN_TUTAR", muhGeciciHesapTx.getKalanTutar());

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	public static void valiteRequest(GMMap iMap) {
		if (!isNotExistAndNull(iMap, "KAPAMA_TUTARI")) {
			throw new GMRuntimeException(10561, "KAPAMA_TUTARI Bo� ge�ilemez!");

		}
		if (!isNotExistAndNull(iMap, "TUTAR")) {
			throw new GMRuntimeException(10561, "TUTAR alan� bo� ge�elimez!");

		}
		if ((iMap.getBigDecimal("KAPAMA_TUTARI") instanceof BigDecimal) && (iMap.getBigDecimal("TUTAR") instanceof BigDecimal)) {
			int comprRslt = iMap.getBigDecimal("KAPAMA_TUTARI").compareTo(iMap.getBigDecimal("TUTAR"));
			if (comprRslt == 1)
				throw new GMRuntimeException(10561, "Kapama Tutar� ,Tutar de�erinden b�y�k olamaz!");
		}
		
		
		if ((iMap.getBigDecimal("KAPAMA_TUTARI") instanceof BigDecimal) && (iMap.getBigDecimal("KALAN_TUTAR") instanceof BigDecimal)) {
			int comprRslt = iMap.getBigDecimal("KAPAMA_TUTARI").compareTo(iMap.getBigDecimal("KALAN_TUTAR"));
			if (comprRslt == 1)
				throw new GMRuntimeException(10561, "Kapama Tutar� ,Kalan Tutar de�erinden b�y�k olamaz!");
		}
		
	}

	public static boolean isNotExistAndNull(GMMap iMap, String key) {

		if (iMap.containsKey(key) && iMap.get(key) != null && iMap.get(key).toString().length() > 0) {
			return true;
		}
		else {
			return false;
		}

	}

}
