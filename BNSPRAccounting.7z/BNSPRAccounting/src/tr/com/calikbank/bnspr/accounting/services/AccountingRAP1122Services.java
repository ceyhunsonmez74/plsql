package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.util.Date;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class AccountingRAP1122Services {
	
	@GraymoundService("BNSPR_RAP1122_KAYIT_OLUSTUR")
	public static GMMap kayitYarat(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_resmi_defter.Resmi_Defter_Kayitlari_Olustur(?,?,?,?,?,?)}");
			stmt.setString(1, iMap.getString("SUBE_KODU"));
			Date baslangicTarihi =  iMap.getDate("BAS_TARIH");
			Date bitisTarihi =  iMap.getDate("BIT_TARIH");
			if (baslangicTarihi != null)
				stmt.setDate(2, new java.sql.Date(baslangicTarihi.getTime()));
			else
				stmt.setDate(2, null);

			if (bitisTarihi != null)
				stmt.setDate(3, new java.sql.Date(bitisTarihi.getTime()));
			else
				stmt.setDate(3, null);
			
			stmt.setString(4, iMap.getString("BAS_HESAP"));
			stmt.setString(5, iMap.getString("BIT_HESAP"));
			stmt.setString(6, iMap.getString("RAPOR_TIPI"));
			stmt.execute();
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} catch (ParseException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_RAP1122_DEVIR_OLUSTUR")
	public static GMMap devirYarat(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_resmi_defter.Resmi_Defter_Devir_Olustur(?,?,?)}");
			stmt.setString(1, iMap.getString("SUBE_KODU"));
			Date baslangicTarihi =  iMap.getDate("BAS_TARIHI");
			Date bitisTarihi =  iMap.getDate("BIT_TARIHI");
			if (baslangicTarihi != null)
				stmt.setDate(2, new java.sql.Date(baslangicTarihi.getTime()));
			else
				stmt.setDate(2, null);

			if (bitisTarihi != null)
				stmt.setDate(3, new java.sql.Date(bitisTarihi.getTime()));
			else
				stmt.setDate(3, null);

			stmt.execute();
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} catch (ParseException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_RAP1122_SON_DK_TARIHI")
	public static GMMap getLastDKDate(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call pkg_resmi_defter.Max_Devir_Tarih (?,?) }");
			int i = 1;
			stmt.registerOutParameter(i++, Types.DATE);	
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SUBE_KODU"));
			if ( iMap.getDate("BAS_TARIH") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			} else {
				stmt.setDate(i++, null);
			}

			stmt.execute();
			
			oMap.put("SON_DK_TARIHI",stmt.getDate(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_RAP1122_TOPLAM_DEVREDEN_BORC")
	public static GMMap getToplamDevredenBorc(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call pkg_resmi_defter.Devir_Tutar_Bul (?,?,?,?) }");
			int i = 1;
			stmt.registerOutParameter(i++, Types.INTEGER);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SUBE_KOD"));
			if ( iMap.getDate("BAS_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			else
				stmt.setDate(i++, null);
			stmt.setBigDecimal(i++, null);			
			stmt.setString(i++, "B");

			stmt.execute();
			
			oMap.put("DEVREDEN_B",stmt.getBigDecimal(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_RAP1122_TOPLAM_DEVREDEN_ALACAK")
	public static GMMap getToplamDevredenAlacak( GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call pkg_resmi_defter.Devir_Tutar_Bul (?,?,?,?) }");
			int i = 1;
			stmt.registerOutParameter(i++, Types.INTEGER);	
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SUBE_KOD"));
			if ( iMap.getDate("BAS_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			else
				stmt.setDate(i++, null);
			stmt.setBigDecimal(i++, null);
			stmt.setString(i++, "A");

			stmt.execute();
			
			oMap.put("DEVREDEN_A",stmt.getBigDecimal(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_RAP1122_DEVIR_TARIH_KONTROL")
	public static GMMap devirTarihKontrol( GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_RESMI_DEFTER.Devir_Tarih_Kontrol(?,?) }");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SUBE_KOD"));
			if ( iMap.getDate("BAS_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			else
				stmt.setDate(i++, null);

			stmt.execute();
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
