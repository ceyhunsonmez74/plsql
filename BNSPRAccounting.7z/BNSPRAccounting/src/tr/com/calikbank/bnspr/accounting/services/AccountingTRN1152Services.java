package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.aktifbank.bnspr.dao.OtomatikVergiOdemesi;
import tr.com.aktifbank.bnspr.dao.SbaTakastaniadeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlKarsiMusMaskomTnmPrTx;
import tr.com.calikbank.bnspr.dao.GnlKarsiMusMaskomTnmPrTxId;
import tr.com.calikbank.bnspr.dao.GnlMasrafKomKriterTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1152Services {
	
	@GraymoundService("BNSPR_TRN1152_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		ResultSet rSet1 = null;
		
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.MONTH, -1);
			Date tarih = cal.getTime();
			int ay = cal.get(Calendar.MONTH)+1  ;
			int yil = cal.get(Calendar.YEAR);
			String aciklama = "";
			
			if (iMap.getString("ISLEM_KODU").equals("MUH_DK")){
				aciklama = ay +"/"+yil+" muhtasar beyanname tahakkuku";
			}else if (iMap.getString("ISLEM_KODU").equals("BSMV_DK")){
				aciklama = ay +"/"+yil+" BSMV tahakkuku �demesi";
			}else if (iMap.getString("ISLEM_KODU").equals("KKDF_DK")){
				aciklama = ay +"/"+yil+" KKDF beyanname tahakkuk �demesi";
			}else if (iMap.getString("ISLEM_KODU").equals("SGK_DK")){
				aciklama = ay +"/"+yil+" SGK tahakkuku �demesi";
			}else if (iMap.getString("ISLEM_KODU").equals("KDV_DK")){
				aciklama = ay +"/"+yil+" KDV �demesi";
			}else if (iMap.getString("ISLEM_KODU").equals("DEGER_DK")){
				aciklama = ay +"/"+yil+" De�erli Ka��t �demesi";
			}else if (iMap.getString("ISLEM_KODU").equals("DAMGA_DK")){
				aciklama = ay +"/"+yil+" Damga Vergisi �demesi";
			}else if (iMap.getString("ISLEM_KODU").equals("MUH3_DK")){
				aciklama = "3 Ayl�k Muhtasar �demesi";
			}else{
				aciklama = ay +"/"+yil+" tahakkuk �demesi";
			}
			
			GMMap dMap = new GMMap();
			dMap.put("BANKA_TARIHI", tarih);
			tarih = GMServiceExecuter.call("BNSPR_COMMON_GET_AYIN_SON_ISGUNU", dMap).getDate("SON_GUN");
			conn = DALUtil.getGMConnection();
			StringBuilder query = new StringBuilder();
			query.append("select text from gnl_param_text where kod ='OTOMATIK_VERGI_TAHSILATI_DK' and key1=?");
			String dk ="";
			//query.append("select sube_kodu, bakiye_fc from bnspr.muh_rpt_mizan where tur='E' and bakiye_fc>0 and dk_numara=?");
			stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, iMap.getString("ISLEM_KODU"));
			rSet = stmt.executeQuery();
			while (rSet.next()) {
				StringBuilder query1 = new StringBuilder();
				query1.append("select sube_kodu, bakiye_fc from bnspr.muh_rpt_mizan where tur='E' and bakiye_fc>0 and dk_numara=? and tarih=?");
				stmt = conn.prepareStatement(query1.toString());
				dk=rSet.getString(1);
				stmt.setString(1, dk);
				stmt.setDate(2, (java.sql.Date) tarih);
				rSet1 = stmt.executeQuery();
				while (rSet1.next()) {
					OtomatikVergiOdemesi otomatikVergiOdemesi = new OtomatikVergiOdemesi();
					otomatikVergiOdemesi.setAciklama(aciklama);
					otomatikVergiOdemesi.setAlckHesapNo(getGlobalParam("1152_ALACAKLI_HESAP"));
					otomatikVergiOdemesi.setAlckSubeKodu("777");
					otomatikVergiOdemesi.setBorcHesapNo(dk);
					otomatikVergiOdemesi.setBorcSubeKodu(rSet1.getString(1));
					otomatikVergiOdemesi.setTutar(rSet1.getBigDecimal(2));
					otomatikVergiOdemesi.setTxNo(iMap.getBigDecimal("TRX_NO"));
					otomatikVergiOdemesi.setIslemTuru(iMap.getString("ISLEM_KODU"));
					session.saveOrUpdate(otomatikVergiOdemesi);
				}
			}
			session.flush();
			iMap.put("TRX_NAME", "1152");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (ConstraintViolationException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(716));
			return AccountingChargesServices.throwGMBusssinessException((String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE",myMap).get("ERROR_MESSAGE"));
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSet1);
		}
		
	}
	@GraymoundService("BNSPR_TRN1152_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			OtomatikVergiOdemesi otomatikVergiOdemesi = (OtomatikVergiOdemesi) session.createCriteria(OtomatikVergiOdemesi.class).add(Restrictions.eq("txNo",iMap.getBigDecimal("TRX_NO") )).setMaxResults(1).uniqueResult();
			oMap.put("ISLEM_KODU", otomatikVergiOdemesi.getIslemTuru());
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	public static String getGlobalParam(String batchParamCode) {
        GMMap iMapG = new GMMap();
        iMapG.put("KOD" , batchParamCode);
        iMapG.put("TRIM_QUOTES" , true);
        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , iMapG).getString("DEGER");
        return batchNo;
    }
}