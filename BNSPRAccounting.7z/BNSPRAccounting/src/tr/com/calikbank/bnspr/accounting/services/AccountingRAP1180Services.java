package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingRAP1180Services {
	
	@GraymoundService("BNSPR_RAP1180_REPORT_DATA_SOURCE")
	public static GMMap reportDataSource(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_TRN1180.DK_Musteri_Hesap_Kont_Rapor(?) }");
			stmt.registerOutParameter(1, -10);
			if(iMap.getDate("V_TARIH") != null) {
				stmt.setDate(2, new java.sql.Date(iMap.getDate("V_TARIH").getTime()));	
			}
			else {
				stmt.setDate(2, null);
			}
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet, "REPORT_DATA");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
