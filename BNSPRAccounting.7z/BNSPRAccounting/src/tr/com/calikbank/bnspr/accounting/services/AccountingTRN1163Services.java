package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMasrafKomKriterTx;
import tr.com.calikbank.bnspr.dao.GnlMusGrupMaskomMuafTx;
import tr.com.calikbank.bnspr.dao.GnlMusGrupMaskomMuafTxId;
import tr.com.calikbank.bnspr.dao.GnlMusGrupMaskomTnmPrTx;
import tr.com.calikbank.bnspr.dao.GnlMusGrupMaskomTnmPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1163Services {
	@GraymoundService("BNSPR_TRN1163_GET_TRX_NO")
	public static GMMap getTrxNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn
					.prepareCall("{? = call PKG_TRN1163.get_parameters(?,?,?,?)}");
			
			stmt.registerOutParameter(1, Types.DECIMAL);
			
			stmt.setString(2, iMap.getString("MUSTERI_GRUP_KOD"));
			stmt.setString(3, iMap.getString("KANAL_Q"));
			stmt.setString(4, iMap.getString("STATU_Q"));
			stmt.setString(5, iMap.getString("MASKOM_TURU_Q"));
						
			stmt.execute();

			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN1163_GET_MUS_GRUP_MASKOM_MUAF_LIST")
	public static GMMap getMusGrupMaskomMuafList(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(GnlMusGrupMaskomMuafTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "MUS_GRUP_MASKOM_MUAF";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlMusGrupMaskomMuafTx gnlMusGrupMaskomMuafTx = (GnlMusGrupMaskomMuafTx)iterator.next();

				if (gnlMusGrupMaskomMuafTx.getDrm().equals("I"))
					oMap.put(tableName, row,"DRM","1");
				else
					oMap.put(tableName, row,"DRM","0");
				
				oMap.put(tableName, row,"END_DATE",gnlMusGrupMaskomMuafTx.getEndDate());
				oMap.put(tableName, row,"KANAL_KOD",gnlMusGrupMaskomMuafTx.getKanalKod());
				oMap.put(tableName, row,"MUS_GRUP_MUAF_ID",gnlMusGrupMaskomMuafTx.getId().getMusGrupMuafId());
				oMap.put(tableName, row,"MUSTERI_GRUP_KOD",gnlMusGrupMaskomMuafTx.getMusteriGrupKod());
				oMap.put(tableName, row,"START_DATE",gnlMusGrupMaskomMuafTx.getStartDate());
				
				oMap.put(tableName, row,"ESKI_KAYIT" ,"ESKI");
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1163_GET_MUS_GRUP_MASKOM_TNM_PR_LIST")
	public static GMMap getMusGrupMaskomTnmPrList(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(GnlMusGrupMaskomTnmPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "MUS_GRUP_MASKOM_TNM_PR";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlMusGrupMaskomTnmPrTx gnlMusGrupMaskomTnmPrTx = (GnlMusGrupMaskomTnmPrTx)iterator.next();

				if (gnlMusGrupMaskomTnmPrTx.getDrm().equals("I"))
					oMap.put(tableName, row,"DRM","1");
				else
					oMap.put(tableName, row,"DRM","0");
				
				oMap.put(tableName, row,"END_DATE",gnlMusGrupMaskomTnmPrTx.getEndDate());
				oMap.put(tableName, row,"ISLEM_KOD",gnlMusGrupMaskomTnmPrTx.getIslemKod());
				oMap.put(tableName, row,"DI_ISLEM_KOD",LovHelper.diLov(gnlMusGrupMaskomTnmPrTx.getIslemKod(),"1163/LOV_ISLEM","ISLEM_ADI"));
				oMap.put(tableName, row,"KANAL_KOD",gnlMusGrupMaskomTnmPrTx.getKanalKod());
				oMap.put(tableName, row,"MASKOM_KATSAYI",gnlMusGrupMaskomTnmPrTx.getMaskomKatsayi());
				oMap.put(tableName, row,"MASKOM_KOD",gnlMusGrupMaskomTnmPrTx.getMaskomKod());
				oMap.put(tableName, row,"MASKOM_ORAN",gnlMusGrupMaskomTnmPrTx.getMaskomOran());
				oMap.put(tableName, row,"MASKOM_TUTAR",gnlMusGrupMaskomTnmPrTx.getMaskomTutar());
				oMap.put(tableName, row,"MUS_GRUP_MASKOM_ID",gnlMusGrupMaskomTnmPrTx.getId().getMusGrupMaskomId());
				oMap.put(tableName, row, "START_DATE",gnlMusGrupMaskomTnmPrTx.getStartDate());
				
				oMap.put(tableName, row,"ESKI_KAYIT" ,"ESKI");
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1163_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "MUS_GRUP_MASKOM_MUAF";
			List<?> list = (List<?>)iMap.get("MUS_GRUP_MASKOM_MUAF");
			for (int i = 0; i < list.size(); i++) {
				GnlMusGrupMaskomMuafTxId gnlMusGrupMaskomMuafTxId = new GnlMusGrupMaskomMuafTxId();
				gnlMusGrupMaskomMuafTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlMusGrupMaskomMuafTxId.setMusGrupMuafId(iMap.getBigDecimal(tableName, i , "MUS_GRUP_MUAF_ID"));
				
				GnlMusGrupMaskomMuafTx gnlMusGrupMaskomMuafTx = (GnlMusGrupMaskomMuafTx)session.get(GnlMusGrupMaskomMuafTx.class, gnlMusGrupMaskomMuafTxId);
				
				if(gnlMusGrupMaskomMuafTx == null)gnlMusGrupMaskomMuafTx = new GnlMusGrupMaskomMuafTx();
				
				gnlMusGrupMaskomMuafTx.setId(gnlMusGrupMaskomMuafTxId);
				if (iMap.getString(tableName,i,"DRM").equals("1")) gnlMusGrupMaskomMuafTx.setDrm("I");
				else gnlMusGrupMaskomMuafTx.setDrm("A");
				gnlMusGrupMaskomMuafTx.setEndDate(iMap.getDate(tableName, i, "END_DATE"));
				gnlMusGrupMaskomMuafTx.setKanalKod(iMap.getString(tableName, i, "KANAL_KOD"));
				gnlMusGrupMaskomMuafTx.setMusteriGrupKod(iMap.getString(tableName, i , "MUSTERI_GRUP_KOD"));
				gnlMusGrupMaskomMuafTx.setStartDate(iMap.getDate(tableName, i, "START_DATE"));
				
				session.saveOrUpdate(gnlMusGrupMaskomMuafTx);
			}
			session.flush();
			
			tableName = "MUS_GRUP_MASKOM_TNM_PR";
			List<?> list1 = (List<?>)iMap.get("MUS_GRUP_MASKOM_TNM_PR");
			for (int i = 0; i < list1.size(); i++) {
				GnlMusGrupMaskomTnmPrTxId gnlMusGrupMaskomTnmPrTxId = new GnlMusGrupMaskomTnmPrTxId();
				gnlMusGrupMaskomTnmPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlMusGrupMaskomTnmPrTxId.setMusGrupMaskomId(iMap.getBigDecimal(tableName, i , "MUS_GRUP_MASKOM_ID"));
				
				GnlMusGrupMaskomTnmPrTx gnlMusGrupMaskomTnmPrTx = (GnlMusGrupMaskomTnmPrTx)session.get(GnlMusGrupMaskomTnmPrTx.class, gnlMusGrupMaskomTnmPrTxId);
				
				if(gnlMusGrupMaskomTnmPrTx == null)gnlMusGrupMaskomTnmPrTx = new GnlMusGrupMaskomTnmPrTx();
				
				gnlMusGrupMaskomTnmPrTx.setId(gnlMusGrupMaskomTnmPrTxId);
				if (iMap.getString(tableName,i,"DRM").equals("1")) gnlMusGrupMaskomTnmPrTx.setDrm("I");
				else gnlMusGrupMaskomTnmPrTx.setDrm("A");
				gnlMusGrupMaskomTnmPrTx.setEndDate(iMap.getDate(tableName, i, "END_DATE"));
				gnlMusGrupMaskomTnmPrTx.setIslemKod(iMap.getBigDecimal(tableName, i, "ISLEM_KOD"));
				gnlMusGrupMaskomTnmPrTx.setKanalKod(iMap.getString(tableName, i, "KANAL_KOD"));
				//gnlMusGrupMaskomTnmPrTx.setMaskomKatsayi(iMap.getBigDecimal(tableName, i, "MASKOM_KATSAYI"));
				gnlMusGrupMaskomTnmPrTx.setMaskomKod(iMap.getString(tableName, i, "MASKOM_KOD"));
				gnlMusGrupMaskomTnmPrTx.setMaskomOran(iMap.getBigDecimal(tableName, i, "MASKOM_ORAN"));
				gnlMusGrupMaskomTnmPrTx.setMaskomTutar(iMap.getBigDecimal(tableName, i, "MASKOM_TUTAR"));
				gnlMusGrupMaskomTnmPrTx.setMusteriGrupKod(iMap.getString("MUSTERI_GRUP_KOD"));
				gnlMusGrupMaskomTnmPrTx.setStartDate(iMap.getDate(tableName, i, "START_DATE"));
				
				session.saveOrUpdate(gnlMusGrupMaskomTnmPrTx);
			}
			session.flush();
			
			GnlMasrafKomKriterTx gnlMasrafKomKriterTx = new GnlMasrafKomKriterTx();
			
			gnlMasrafKomKriterTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			gnlMasrafKomKriterTx.setMusteriGrupKod(iMap.getString("MUSTERI_GRUP_KOD"));
			gnlMasrafKomKriterTx.setDrm(iMap.getString("STATU"));
			gnlMasrafKomKriterTx.setKanalKod(iMap.getString("KANAL_KOD"));
			gnlMasrafKomKriterTx.setMaskomKod(iMap.getString("MASKOM_TURU"));
			
			session.save(gnlMasrafKomKriterTx);
			session.flush();
			
			iMap.put("TRX_NAME", "1163");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (ConstraintViolationException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(716));
			return AccountingChargesServices.throwGMBusssinessException((String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE",myMap).get("ERROR_MESSAGE"));
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1163_GET_MUS_GRUP_MUAF_MASKOM_TNM_INFO")
	public static GMMap getMusGrupMuafMaskomTnmInfo(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> muafList = session.createCriteria(GnlMusGrupMaskomMuafTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "MUS_GRUP_MASKOM_MUAF";
			int row = 0;
			for (Iterator<?> iterator = muafList.iterator(); iterator.hasNext();) {
				GnlMusGrupMaskomMuafTx gnlMusGrupMaskomMuafTx = (GnlMusGrupMaskomMuafTx)iterator.next();
				
				if (gnlMusGrupMaskomMuafTx.getDrm().equals("I"))
					oMap.put(tableName, row,"DRM","1");
				else
					oMap.put(tableName, row,"DRM","0");
				oMap.put(tableName, row, "END_DATE",gnlMusGrupMaskomMuafTx.getEndDate());
				oMap.put(tableName, row, "KANAL_KOD",gnlMusGrupMaskomMuafTx.getKanalKod());
				oMap.put(tableName, row, "MUSTERI_GRUP_KOD",gnlMusGrupMaskomMuafTx.getMusteriGrupKod());
				oMap.put(tableName, row, "START_DATE",gnlMusGrupMaskomMuafTx.getStartDate());
				
				row++;
			}
			
			List<?> tnmList = session.createCriteria(GnlMusGrupMaskomTnmPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			tableName = "MUS_GRUP_MASKOM_TNM_PR";
			row = 0;
			for (Iterator<?> iterator = tnmList.iterator(); iterator.hasNext();) {
				GnlMusGrupMaskomTnmPrTx gnlMusGrupMaskomTnmPrTx = (GnlMusGrupMaskomTnmPrTx)iterator.next();
				
				if (gnlMusGrupMaskomTnmPrTx.getDrm().equals("I"))
					oMap.put(tableName, row,"DRM","1");
				else
					oMap.put(tableName, row,"DRM","0");
				oMap.put(tableName, row, "END_DATE",gnlMusGrupMaskomTnmPrTx.getEndDate());
				oMap.put(tableName, row, "ISLEM_KOD",gnlMusGrupMaskomTnmPrTx.getIslemKod());
				oMap.put(tableName, row,  "DI_ISLEM_KOD",LovHelper.diLov(gnlMusGrupMaskomTnmPrTx.getIslemKod(),"1163/LOV_ISLEM","ISLEM_ADI"));
				oMap.put(tableName, row, "KANAL_KOD",gnlMusGrupMaskomTnmPrTx.getKanalKod());
				//oMap.put(tableName, row, "MASKOM_KATSAYI",gnlMusGrupMaskomTnmPrTx.getMaskomKatsayi());
				oMap.put(tableName, row, "MASKOM_KOD",gnlMusGrupMaskomTnmPrTx.getMaskomKod());
				oMap.put(tableName, row, "MASKOM_ORAN",gnlMusGrupMaskomTnmPrTx.getMaskomOran());
				oMap.put(tableName, row, "MASKOM_TUTAR",gnlMusGrupMaskomTnmPrTx.getMaskomTutar());
				oMap.put(tableName, row, "MUSTERI_GRUP_KOD",gnlMusGrupMaskomTnmPrTx.getMusteriGrupKod());
				oMap.put(tableName, row, "START_DATE",gnlMusGrupMaskomTnmPrTx.getStartDate());
				
				row++;
			}
			
			GnlMasrafKomKriterTx gnlMasrafKomKriterTx = (GnlMasrafKomKriterTx)session.get(GnlMasrafKomKriterTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", gnlMasrafKomKriterTx.getTxNo());
			oMap.put("MUSTERI_GRUP_KOD", gnlMasrafKomKriterTx.getMusteriGrupKod());
			oMap.put("DI_MUSTERI_GRUP_KOD", LovHelper.diLov(gnlMasrafKomKriterTx.getMusteriGrupKod(), "1163/LOV_MUSTERI_GRUP_BILGI", "ACIKLAMA"));
			oMap.put("KANAL_KOD", gnlMasrafKomKriterTx.getKanalKod());
			oMap.put("DI_KANAL_KOD", LovHelper.diLov(gnlMasrafKomKriterTx.getKanalKod(), "1163/LOV_KANAL", "ACIKLAMA"));
			oMap.put("STATU", gnlMasrafKomKriterTx.getDrm());
			oMap.put("MASKOM_TURU", gnlMasrafKomKriterTx.getMaskomKod());
			oMap.put("DI_MASKOM_TURU", LovHelper.diLov(gnlMasrafKomKriterTx.getMaskomKod(), "1163/LOV_MASKOM_Q", "ACIKLAMA"));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
