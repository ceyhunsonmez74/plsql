package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.MuhDkOzelKarsilikTanim;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingPAR1199Services {
	@GraymoundService("BNSPR_PAR1199_GETRECORDS")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> recordList = (List<?>) session.createCriteria(MuhDkOzelKarsilikTanim.class).list();

			String tableName = "TBL_DK";

			for (int row = 0; row < recordList.size(); row++) {
				MuhDkOzelKarsilikTanim muhDkOzelKarsilikTanim = (MuhDkOzelKarsilikTanim) recordList.get(row);
				oMap.put(tableName, row, "DK_HESAP_NO", muhDkOzelKarsilikTanim.getDkAna());
				oMap.put(tableName, row, "DK_ACIKLAMA", LovHelper.diLov(muhDkOzelKarsilikTanim.getDkAna(), "1199P/LOV_DK_HESAP", "DK_ACIKLAMA"));
				oMap.put(tableName, row, "OZEL_KARSILIK_DK", muhDkOzelKarsilikTanim.getDkOzelKarsilik());
				oMap.put(tableName, row, "OZEL_DK_ACIKLAMA", LovHelper.diLov(muhDkOzelKarsilikTanim.getDkOzelKarsilik(), "1199P/LOV_OZEL_KARS_DK", "OZEL_KARSILIK_DK"));
				oMap.put(tableName, row, "GIDER_DK", muhDkOzelKarsilikTanim.getDkGider());
				oMap.put(tableName, row, "GIDER_DK_ACIKLAMA", LovHelper.diLov(muhDkOzelKarsilikTanim.getDkGider(), "1199P/LOV_GIDER_DK", "GIDER_DK"));
				oMap.put(tableName, row, "KARSILIK_ORANI", muhDkOzelKarsilikTanim.getKarsilikOrani());
				oMap.put(tableName, row, "TEMINAT_ORANI", muhDkOzelKarsilikTanim.getTeminatOrani());
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_PAR1199_SAVE")
	public static GMMap saveParameters(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		String tableName = null;
		int rowCount = 0;

		try {

			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");

			tableName = "TBL_DK";
			rowCount = iMap.getSize(tableName);

			for (int i = 0; i < rowCount; i++) {
				if (iMap.getString(tableName, i, "DK_HESAP_NO") == null) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "DK Hesap No");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				if (iMap.getString(tableName, i, "OZEL_KARSILIK_DK") == null) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Ozel Karsilik DK");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				if (iMap.getString(tableName, i, "GIDER_DK") == null) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Gider DK");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				if (iMap.getBigDecimal(tableName, i, "KARSILIK_ORANI") == null) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Karsilik Orani");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				if (iMap.getBigDecimal(tableName, i, "TEMINAT_ORANI") == null) {
					iMap.put("HATA_NO", new BigDecimal(330));
					iMap.put("P1", "Teminat Orani");
					return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
				}
			}

			ArrayList<?> muhDkOzelKarsilikTanimList = (ArrayList<?>) session.createCriteria(MuhDkOzelKarsilikTanim.class).list();
			for (Iterator<?> iterator = muhDkOzelKarsilikTanimList.iterator(); iterator.hasNext();) {
				MuhDkOzelKarsilikTanim muhDkOzelKarsilikTanim = (MuhDkOzelKarsilikTanim) iterator.next();
				session.delete(muhDkOzelKarsilikTanim);
			}
			session.flush();

			for (int i = 0; i < rowCount; i++) {
				MuhDkOzelKarsilikTanim muhDkOzelKarsilikTanim = (MuhDkOzelKarsilikTanim) session.get(MuhDkOzelKarsilikTanim.class, iMap.getString(tableName, i, "DK_HESAP_NO"));
				if (muhDkOzelKarsilikTanim == null)
					muhDkOzelKarsilikTanim = new MuhDkOzelKarsilikTanim();

				muhDkOzelKarsilikTanim.setDkAna(iMap.getString(tableName, i, "DK_HESAP_NO"));
				muhDkOzelKarsilikTanim.setDkOzelKarsilik(iMap.getString(tableName, i, "OZEL_KARSILIK_DK"));
				muhDkOzelKarsilikTanim.setDkGider(iMap.getString(tableName, i, "GIDER_DK"));
				muhDkOzelKarsilikTanim.setKarsilikOrani(iMap.getBigDecimal(tableName, i, "KARSILIK_ORANI"));
				muhDkOzelKarsilikTanim.setTeminatOrani(iMap.getBigDecimal(tableName, i, "TEMINAT_ORANI"));

				session.saveOrUpdate(muhDkOzelKarsilikTanim);
			}
			session.flush();

			oMap.put("MESSAGE", "��leminiz Tamamlanm��t�r.");
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
