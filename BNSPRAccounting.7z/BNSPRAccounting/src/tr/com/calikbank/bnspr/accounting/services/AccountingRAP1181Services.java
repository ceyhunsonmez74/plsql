package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingRAP1181Services {
	
	@GraymoundService("BNSPR_RAP1181_REPORT_DATA_SOURCE")
	public static GMMap reportDataSourceRAP1181(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement	stmt = null;
		ResultSet 			rSet = null;
		GMMap				oMap = new GMMap();
		try { 
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC1181.Gunluk_Fisler_Raporu(?,?,?,?)}");
			stmt.registerOutParameter(1, -10);
			if(iMap.getDate("V_TARIH") != null) {
				stmt.setDate(2, new java.sql.Date(iMap.getDate("V_TARIH").getTime()));	
			}
			else {
				stmt.setDate(2, null);
			}
			stmt.setString(3, iMap.getString("KANAL"));
			stmt.setString(4, iMap.getString("SUBE_KODU"));
			stmt.setString(5, iMap.getString("KULLANICI_KOD"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "REPORT_DATA";
			DALUtil.rSetResults(rSet, tableName, oMap);
			
			for(int row=0; row<oMap.getSize(tableName); row++){
				oMap.put(tableName, row, "SUB_REPORT_DATA_1", get1181SubReportData1(oMap.getBigDecimal(tableName, row, "NUMARA")));
				oMap.put(tableName, row, "SUB_REPORT_DATA_2", get1181SubReportData2(oMap.getBigDecimal(tableName, row, "NUMARA"), oMap.getString(tableName, row, "KANAL")) );
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static List<?> get1181SubReportData1(BigDecimal numara) {
		Connection 			conn = null;
		CallableStatement	stmt = null;
		ResultSet 			rSet = null;
		List<Object>	 	list = new ArrayList<Object>();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC1181.Gunluk_Fisler_Sub_Rapor_1(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, numara);
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			
			while (rSet.next()) {
				HashMap<Object, Object> rowData = new HashMap<Object, Object>();
				ResultSetMetaData rs = rSet.getMetaData();
				for (int c = 1; c <= rs.getColumnCount(); c++){
					rowData.put(rs.getColumnName(c), rSet.getObject(c));
				}
				list.add(rowData);
			}
			
			return list;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static List<?> get1181SubReportData2(BigDecimal numara, String kanal) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		List<Object>	 	list = new ArrayList<Object>();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC1181.Gunluk_Fisler_Sub_Rapor_2(?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setBigDecimal(2, numara);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			while (rSet.next()) {
				HashMap<Object, Object> rowData = new HashMap<Object, Object>();
				ResultSetMetaData rs = rSet.getMetaData();
				for (int c = 1; c <= rs.getColumnCount(); c++){
					rowData.put(rs.getColumnName(c), rSet.getObject(c));
				}
				rowData.put("KANAL", kanal);
				list.add(rowData);
			}
			
			return list;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	
	@GraymoundService("BNSPR_RAP1181_GM_SUBE_KULLANICISI_MI")
	public static GMMap gmKullanicisimi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			GMMap oMap = new GMMap();
			stmt = conn.prepareCall("{? = call PKG_PERSONEL.GM_Kullanicisimi(?)}");
			stmt.registerOutParameter(1,Types.VARCHAR);
			stmt.setString(2, iMap.getString("KULLANICI_KOD"));
			stmt.execute();

			oMap.put("GM_KULLANICISI_MI", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}
	
	
	
	@GraymoundService("BNSPR_RAP_KRITER_LOGLA")
	public static GMMap kriterLogla(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_IZLEME_KRITER.KRITER_LOGLA(?,?)}");
			stmt.setString(1, iMap.getString("KRITER"));
			stmt.setString(2, iMap.getString("PROGRAM"));

			stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}	
	 
	
	
}
