package tr.com.calikbank.bnspr.accounting.services;

import java.text.ParseException;
import java.util.Map;

import org.hibernate.Session;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlNazimGirisCikisTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1201Services {

	@GraymoundService("BNSPR_TRN1201_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap oMap = new GMMap();

		try {
			validateRequest(iMap);
			GnlNazimGirisCikisTx gnlNazimGirisCikisTx = (GnlNazimGirisCikisTx) session.get(GnlNazimGirisCikisTx.class, iMap.getBigDecimal("TRX_NO"));
			if (gnlNazimGirisCikisTx == null)
				gnlNazimGirisCikisTx = new GnlNazimGirisCikisTx();

			gnlNazimGirisCikisTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			gnlNazimGirisCikisTx.setIslemTipi(iMap.getString("ISLEM_TIPI"));
			gnlNazimGirisCikisTx.setIslemTuru(iMap.getString("ISLEM_TURU"));
			gnlNazimGirisCikisTx.setIslemAdet(iMap.getBigDecimal("ADET"));
			gnlNazimGirisCikisTx.setDovKod(iMap.getString("DOV_KOD"));
			gnlNazimGirisCikisTx.setAciklama(iMap.getString("ACIKLAMA"));

			try {
				oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN1201_GET_ISLEM_TURU_DETAIL", iMap));

				gnlNazimGirisCikisTx.setDkNoBorc(oMap.getString("DK_NO_BORC"));
				gnlNazimGirisCikisTx.setDkNoAlacak(oMap.getString("DK_NO_ALACAK"));
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}

			session.saveOrUpdate(gnlNazimGirisCikisTx);
			session.flush();
			iMap.put("TRX_NAME", "1201");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (ParseException e) {

			throw ExceptionHandler.convertException(e);
		}

	}

	public static boolean isNotExistAndNull(GMMap iMap, String key) {

		if (iMap.containsKey(key) && iMap.get(key) != null && iMap.get(key).toString().length() > 0) {
			return true;
		}
		else {
			return false;
		}

	}

	private static void validateRequest(GMMap iMap) throws ParseException {

		if (!isNotExistAndNull(iMap, "ACIKLAMA")) {
			throw new GMRuntimeException(10561, "ACIKLAMA  bilgisi girilmelidir!");
		}

		if (!isNotExistAndNull(iMap, "ISLEM_TIPI")) {
			throw new GMRuntimeException(10561, "ISLEM_TIPI  bilgisi girilmelidir!");
		}

		if (!isNotExistAndNull(iMap, "ISLEM_TURU")) {
			throw new GMRuntimeException(10561, "ISLEM_TURU  bilgisi girilmelidir!");
		}

		if (!isNotExistAndNull(iMap, "ADET")) {
			throw new GMRuntimeException(10561, "ADET  bilgisi girilmelidir!");
		}
		
		if (!isNotExistAndNull(iMap, "DOV_KOD")) {
			throw new GMRuntimeException(10561, "Doviz Kodu  bilgisi girilmelidir!");
		}
	}
	
	


	@GraymoundService("BNSPR_TRN1201_GET_ISLEM_TURU_DETAIL")
	public static GMMap getIslemTuruById(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			String func = "{? = call PKG_TRN1201.GET_ISLEM_TURU_BY_ID(?)}";
			Object[] inputValues = new Object[2];
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEM_TURU");

			String tableName = "RESULTS";
			oMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);

			i = 0;
			while (i < oMap.getSize(tableName)) {
				oMap.put("KOD", oMap.getString(tableName, i, "KOD"));
				oMap.put("ACIKLAMA", oMap.getString(tableName, i, "ACIKLAMA"));
				oMap.put("DK_NO_BORC", oMap.getString(tableName, i, "DK_NO_BORC"));
				oMap.put("DK_NO_ALACAK", oMap.getString(tableName, i, "DK_NO_ALACAK"));

				i++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	public static GMMap getDKByIslemTipi(String islemTipi) {

		GMMap oMap = new GMMap();
		GMMap iMap = new GMMap();
		String table = "ISLEM_TIPI";
		try {
			iMap.put("KOD", "NAZIM_GIRIS_CIKIS_ISLEM_TIPI");
			oMap.put(table, GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN1201_INITIALIZE")
	public static GMMap initiazlize(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			iMap.put("KOD", "NAZIM_GIRIS_CIKIS_ISLEM_TIPI");
			oMap.put("ISLEM_TIPI", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN1201_GET_INFO")
	public static GMMap getNazimGirisCikisInfo(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlNazimGirisCikisTx gnlNazimGirisCikisTx = (GnlNazimGirisCikisTx) session.load(GnlNazimGirisCikisTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			oMap.put("ISLEM_TIPI", gnlNazimGirisCikisTx.getIslemTipi());
			oMap.put("ISLEM_TURU", gnlNazimGirisCikisTx.getIslemTuru());
			oMap.put("ISLEM_TUR_ACIKLAMA", LovHelper.diLov(gnlNazimGirisCikisTx.getIslemTuru(), "1201/LOV_ISLEM_TURU", "ACIKLAMA"));
			oMap.put("ADET", gnlNazimGirisCikisTx.getIslemAdet());
			oMap.put("DOV_KOD", gnlNazimGirisCikisTx.getDovKod());
			oMap.put("ACIKLAMA", gnlNazimGirisCikisTx.getAciklama());

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	
	@GraymoundService("BNSPR_TRN1201_GET_DOV_KOD_STATE")
	public static GMMap getDovStatu(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			String func = "{? = call PKG_TRN1201.GET_ISLEM_TURU_BY_ID(?)}";
			Object[] inputValues = new Object[2];
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEM_TUR");

			String tableName = "RESULTS";
			oMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);

			i = 0;
			while (i < oMap.getSize(tableName)) {
				if((oMap.getString(tableName, i, "DK_NO_BORC").startsWith("997")) || (oMap.getString(tableName, i, "DK_NO_ALACAK").startsWith("997")))
						oMap.put("DOV_KOD_MESSAGE","T");
				
				else
					oMap.put("DOV_KOD_MESSAGE","F");
			

				i++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
}
