package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MuhDkGiderTanimRol;
import tr.com.aktifbank.bnspr.dao.MuhDkGiderTanimRolTx;
import tr.com.aktifbank.bnspr.dao.MuhDkGiderTanimRolTxId;
import tr.com.aktifbank.bnspr.dao.MuhDkGiderTanimTx;
import tr.com.aktifbank.bnspr.dao.MuhDkGiderTanimTxId;
import tr.com.aktifbank.bnspr.dao.MuhDkUrunTanimTx;
import tr.com.aktifbank.bnspr.dao.MuhGiderTx;
import tr.com.aktifbank.bnspr.dao.MuhHesapKrediTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1187Services {
    
    @GraymoundService("BNSPR_TRN1187_GET_LIST")
    public static GMMap getList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        Session session = DAOSession.getSession("BNSPRDal");
        try{
        	conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN1187.TRN1187_sorgula}");
            int i = 1;
            stmt.registerOutParameter(i++ , -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            GMMap oMap = new GMMap();
            oMap.putAll(DALUtil.rSetResults(rSet , "LIST"));
            i = 0;
            while (i < oMap.getSize("LIST")){
                oMap.put("LIST" , i , "HESABA_BAGLIMI" , oMap.getString("LIST" , i , "HESABA_BAGLIMI").equals("E") ? true : false);
                ArrayList<HashMap<String, Object>> rolesOutList = new ArrayList<HashMap<String, Object>>();
        		ArrayList<?> roles = (ArrayList<?>) session.createCriteria(MuhDkGiderTanimRol.class).add(Restrictions.eq("id.kod", oMap.getString("LIST" , i ,"KOD"))).list();
        		for (Iterator<?> iterator = roles.iterator(); iterator.hasNext();) {
        			MuhDkGiderTanimRol giderTanimRol = (MuhDkGiderTanimRol) iterator.next();
        			HashMap<String, Object> rowData = new HashMap<String, Object>();
        			rowData.put("KOD", giderTanimRol.getId().getKod());
        			rowData.put("ROL", giderTanimRol.getId().getRol().toString());
        			rowData.put("TANIM", giderTanimRol.getRolAciklama());
        			rolesOutList.add(rowData);
        			GMContext.getCurrentContext().getSession().put(oMap.getString("LIST" , i ,"KOD"), rolesOutList);
        		}
                i++;
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @SuppressWarnings("unchecked")
    @GraymoundService("BNSPR_TRN1187_SAVE")
    public static GMMap saveList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        int i = 0;
        String table = "TABLE";
        Session session = DAOSession.getSession("BNSPRDal");
        try{
            List<MuhDkGiderTanimTx> list = (List<MuhDkGiderTanimTx>) session.createCriteria(MuhDkGiderTanimTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            for (MuhDkGiderTanimTx rec : list){
                session.delete(rec);
            }
            session.flush();
            
            try{
                while (i < iMap.getSize(table)){
                    MuhDkGiderTanimTx muhDkGiderTanimTx = new MuhDkGiderTanimTx();
                    MuhDkGiderTanimTxId muhDkGiderTanimTxId = new MuhDkGiderTanimTxId();
                    muhDkGiderTanimTxId.setKod(iMap.getString(table , i , "KOD"));
                    muhDkGiderTanimTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    muhDkGiderTanimTx.setId(muhDkGiderTanimTxId);
                    muhDkGiderTanimTx.setAciklama(iMap.getString(table , i , "ACIKLAMA"));
                    muhDkGiderTanimTx.setDkHesapTl(iMap.getString(table , i , "DK_HESAP_TL"));
                    muhDkGiderTanimTx.setDkHesapYp(iMap.getString(table , i , "DK_HESAP_YP"));
                    muhDkGiderTanimTx.setHesabaBaglimi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(table, i, "HESABA_BAGLIMI")));
                    muhDkGiderTanimTx.setModulTurKod(iMap.getString(table , i , "MODUL_TUR_KOD"));
                    muhDkGiderTanimTx.setUrunSinifKod(iMap.getString(table , i , "URUN_SINIF_KOD"));
                    muhDkGiderTanimTx.setUrunTurKod(iMap.getString(table , i , "URUN_TUR_KOD"));
                    // muhDkGiderTanimTx.set
                    session.saveOrUpdate(muhDkGiderTanimTx);
                    
                    ArrayList<?> roller = (ArrayList<?>)  GMContext.getCurrentContext().getSession().get(iMap.getString(table, i, "KOD"));
                    Object o = GMContext.getCurrentContext().getSession().get(iMap.getString(table, i, "KOD"));
                    if(o!=null){
                    	boolean flag = true;
    					for (Iterator<?> iterator2 = roller.iterator(); iterator2.hasNext();) {
    						HashMap<?, ?> rowData2 = (HashMap<?, ?>) iterator2.next();
    					MuhDkGiderTanimRolTx giderTanimRolTx = new MuhDkGiderTanimRolTx();
    					MuhDkGiderTanimRolTxId giderTanimRolTxId = new MuhDkGiderTanimRolTxId();
    					giderTanimRolTxId.setKod((String) rowData2.get("KOD"));
    					giderTanimRolTxId.setRol(BigDecimal.valueOf(Long.valueOf((String) rowData2.get("ROL"))));
    					giderTanimRolTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
    					giderTanimRolTx.setId(giderTanimRolTxId);
    					giderTanimRolTx.setRolAciklama((String) rowData2.get("TANIM"));
    					session.saveOrUpdate(giderTanimRolTx);
    					
    					if(flag){
							GMContext.getCurrentContext().getSession().remove((String)rowData2.get("KOD"));
							flag=false;
						}
    					}
                    }
                    
                    i++;
                }
                
                 
                session.flush();
                
                iMap.put("TRX_NAME" , "1187");
                GMMap oMap = new GMMap();
                oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap));
                return oMap;
            } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } finally{
                GMServerDatasource.close(rSet);
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
            }
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN1187_GIDER_GIRIS_SAVE")
    public static GMMap saveGiderGirisList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        Session session = DAOSession.getSession("BNSPRDal");
        
        try{
            MuhGiderTx muhGiderTx = new MuhGiderTx();
            muhGiderTx.setAciklama(iMap.getString("ACIKLAMA"));
            muhGiderTx.setAlacakDkHesapNo(iMap.getString("ALACAK_DK_HESAP_NO"));
            muhGiderTx.setAlacakHesapNo(iMap.getBigDecimal("ALACAK_HESAP_NO"));
            muhGiderTx.setAlacakMusteriNo(iMap.getBigDecimal("ALACAK_MUSTERI_NO"));
            muhGiderTx.setAlacakSube(iMap.getString("ALACAK_SUBE"));
            muhGiderTx.setMasrafBolumKodu(iMap.getString("MASRAF_BOLUM_KOD"));
            muhGiderTx.setKarBolumKodu(iMap.getString("KAR_BOLUM_KOD"));            
            muhGiderTx.setBorcluDkHesapNo(iMap.getString("BORCLU_DK_HESAP_NO"));
            muhGiderTx.setGiderHesapNo(iMap.getBigDecimal("GIDER_HESAP_NO"));
            muhGiderTx.setGiderMusteriNo(iMap.getBigDecimal("GIDER_MUSTERI_NO"));
            muhGiderTx.setGiderSube(iMap.getString("GIDER_SUBE"));
            muhGiderTx.setDovizKodu(iMap.getString("DOVIZ_KOD"));
            muhGiderTx.setGiderKod(iMap.getString("GIDER_KOD"));
            muhGiderTx.setIslemTipi(iMap.getString("ISLEM_TIPI"));
            muhGiderTx.setModulTurKod(iMap.getString("MODUL_TUR_KOD"));
            muhGiderTx.setTutar(iMap.getBigDecimal("TUTAR"));
            muhGiderTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            muhGiderTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
            muhGiderTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
            
            session.save(muhGiderTx);
            session.flush();
            
            iMap.put("TRX_NAME" , "1188");
            GMMap oMap = new GMMap();
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap));
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    @GraymoundService("BNSPR_TRN1188_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			MuhGiderTx tanim = (MuhGiderTx)session.get(MuhGiderTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", tanim.getTxNo());
			oMap.put("GIDER_KOD", tanim.getGiderKod());
			oMap.put("GIDER_ACIKLAMA", LovHelper.diLov(tanim.getGiderKod(),GMContext.getCurrentContext().getSession().get("ROLE_ID").toString(), "1188/GIDER_TIPI", "ACIKLAMA"));
			oMap.put("HESABA_BAGLIMI", LovHelper.diLov(tanim.getGiderKod(),GMContext.getCurrentContext().getSession().get("ROLE_ID").toString(), "1188/GIDER_TIPI", "HESABA_BAGLIMI"));
			oMap.put("MODUL_TUR_KOD", tanim.getModulTurKod());
			oMap.put("URUN_TUR_KOD", tanim.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", tanim.getUrunSinifKod());
			oMap.put("ACIKLAMA", tanim.getAciklama());
			oMap.put("ALACAK_DK_HESAP_NO", tanim.getAlacakDkHesapNo());
			oMap.put("ALACAK_HESAP_NO", tanim.getAlacakHesapNo());
			oMap.put("ALACAK_MUSTERI_NO", tanim.getAlacakMusteriNo());
			oMap.put("ALACAK_MUSTERI_ADI", LovHelper.diLov(tanim.getAlacakMusteriNo(), "1188/ALACAKLI_MUSTERI_NO", "ISIM"));
			oMap.put("ALACAK_SUBE", tanim.getAlacakSube());
			oMap.put("ALACAK_SUBE_ACK", LovHelper.diLov(tanim.getAlacakSube(), "1188/LOV_SUBE_KOD", "SUBE_ADI"));
			oMap.put("MASRAF_BOLUM_KOD", tanim.getMasrafBolumKodu());
			oMap.put("MASRAF_BOLUM_ACK", LovHelper.diLov(tanim.getMasrafBolumKodu(), "1188/BOLUM_KOD", "ACIKLAMA"));
			oMap.put("KAR_BOLUM_KOD", tanim.getKarBolumKodu());
			oMap.put("KAR_BOLUM_ACK", LovHelper.diLov(tanim.getKarBolumKodu(), "1188/BOLUM_KOD", "ACIKLAMA"));
			oMap.put("BORCLU_DK_HESAP_NO", tanim.getBorcluDkHesapNo());
			oMap.put("GIDER_HESAP_NO", tanim.getGiderHesapNo());
			oMap.put("GIDER_MUSTERI_NO", tanim.getGiderMusteriNo());
			oMap.put("GIDER_MUSTERI_ADI", LovHelper.diLov(tanim.getGiderMusteriNo(), "1188/ALACAKLI_MUSTERI_NO", "ISIM"));
			oMap.put("GIDER_SUBE", tanim.getGiderSube());
			oMap.put("GIDER_SUBE_ACK", LovHelper.diLov(tanim.getGiderSube(), "1188/LOV_SUBE_KOD", "SUBE_ADI"));
			oMap.put("DOVIZ_KOD", tanim.getDovizKodu());
			oMap.put("DOVIZ_ACIKLAMA", LovHelper.diLov(tanim.getDovizKodu(), "1188/LOV_DOVIZ_KOD", "ACIKLAMA"));
			oMap.put("ISLEM_TIPI", tanim.getIslemTipi());
			oMap.put("TUTAR", tanim.getTutar());
			oMap.put("TRX_NO", tanim.getTxNo());
            
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
    @GraymoundService("BNSPR_TRN1187_PUT_ROLES_TO_CONTEXT")
    public static Map<?, ?> putRolesToContext(GMMap iMap) {
    		GMContext.getCurrentContext().getSession().put(iMap.getString("KOD"), iMap.get("ROLES"));
    		return new GMMap();
    	
    }
    @GraymoundService("BNSPR_TRN1187_GET_ROLES_BY_TX_NO")
    public static GMMap getRolesByTxNo(GMMap iMap){
    	Session session = DAOSession.getSession("BNSPRDal");
    	GMMap oMap = new GMMap();
    	try {
			
		
    		ArrayList<?> roles =(ArrayList<?>) session.createCriteria(MuhDkGiderTanimRolTx.class).add(Restrictions.and(Restrictions.eq("id.kod", iMap.getBigDecimal("KOD")),Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))).list();
    	String tableName="ROLES";
    	int i = 0;
    	for (Iterator<?> iterator= roles.iterator();  iterator.hasNext(); i++) {
			MuhDkGiderTanimRolTx giderTanimRolTx = (MuhDkGiderTanimRolTx) iterator.next();
			oMap.put(tableName, i,"KOD", giderTanimRolTx.getId().getKod());
			oMap.put(tableName, i,"ROL", giderTanimRolTx.getId().getRol());
			oMap.put(tableName,i , "TANIM", giderTanimRolTx.getRolAciklama());
		}
    	}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}		
    	return oMap;
    }
    @GraymoundService("BNSPR_TRN1187_GET_ROLES")
    public static Map<?, ?>  getRoles(GMMap iMap){
    	Session session = DAOSession.getSession("BNSPRDal");
    	
    	HashMap<String, Object> oMap = new HashMap<String, Object>();
    	ArrayList<?> roller = (ArrayList<?>)  GMContext.getCurrentContext().getSession().get(iMap.getString("KOD"));
            Object o = GMContext.getCurrentContext().getSession().get(iMap.getString("KOD"));
            if(o!=null){
            	try {
            	ArrayList<HashMap<?, Object>> rolesOutList = new ArrayList<HashMap<?, Object>>();
				for (Iterator<?> iterator2 = roller.iterator(); iterator2.hasNext();) {
					HashMap<?, Object> rowData2 = (HashMap<?, Object>) iterator2.next();
					rolesOutList.add(rowData2);
				}
				oMap.put("ROLES", rolesOutList);
            }
		
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
    	}else {
    		oMap.put("ROLES", GMContext.getCurrentContext().getSession().get(iMap.getString("KOD")));
    	}
    	
    	return oMap;
    }
    @GraymoundService("BNSPR_TRN1188_GET_ROLE")
    public static GMMap getRole(GMMap iMap){
    	GMMap oMap = new GMMap();
    	BigDecimal roleID = new BigDecimal(GMContext.getCurrentContext().getSession().get("ROLE_ID").toString());
    	oMap.put("ROLE", roleID);
    	return oMap;
    }

    @GraymoundService("BNSPR_TRN1187_GET_INFO")
    public static GMMap getInfoTrn1187(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        try{
        	
        	Object[] inputValues = new Object[2];
        	inputValues[0] = BnsprType.NUMBER;
        	inputValues[1] = iMap.getBigDecimal("TRX_NO");
        	String func = "{? = call PKG_TRN1187.TRN1187_GET_INFO(?)}";
        	oMap = DALUtil.callOracleRefCursorFunction(func, "LIST", inputValues);
        	
            int i = 0;
            while (i < oMap.getSize("LIST")){
                oMap.put("LIST" , i , "HESABA_BAGLIMI" , oMap.getString("LIST" , i , "HESABA_BAGLIMI").equals("E") ? true : false);
                ArrayList<HashMap<String, Object>> rolesOutList = new ArrayList<HashMap<String, Object>>();
        		ArrayList<?> roles = (ArrayList<?>) session.createCriteria(MuhDkGiderTanimRolTx.class).add(Restrictions.eq("id.kod", oMap.getString("LIST" , i ,"KOD"))).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
        		for (Iterator<?> iterator = roles.iterator(); iterator.hasNext();) {
        			MuhDkGiderTanimRolTx giderTanimRolTx = (MuhDkGiderTanimRolTx) iterator.next();
        			HashMap<String, Object> rowData = new HashMap<String, Object>();
        			rowData.put("KOD", giderTanimRolTx.getId().getKod());
        			rowData.put("ROL", giderTanimRolTx.getId().getRol().toString());
        			rowData.put("TANIM", giderTanimRolTx.getRolAciklama());
        			rolesOutList.add(rowData);
        			GMContext.getCurrentContext().getSession().put(oMap.getString("LIST" , i ,"KOD"), rolesOutList);
        		}
                i++;
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
}