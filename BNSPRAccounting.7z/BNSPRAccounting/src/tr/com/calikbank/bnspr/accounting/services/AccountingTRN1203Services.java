package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlNazimKodlariTx;
import tr.com.calikbank.bnspr.dao.GnlNazimKodlariTxId;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1203Services {

	@GraymoundService("BNSPR_TRN1203_SAVE")
	public static GMMap save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
			int i = 0;
			String table = "TBL";

			while (i < iMap.getSize(table)) {
				GnlNazimKodlariTx gnlNazimKodlariTx = new GnlNazimKodlariTx();
				GnlNazimKodlariTxId gnlNazimKodlariTxId = new GnlNazimKodlariTxId();
				gnlNazimKodlariTxId.setTxNo(trxNo);
				gnlNazimKodlariTxId.setKod(iMap.getString(table, i, "KOD"));
				gnlNazimKodlariTx.setId(gnlNazimKodlariTxId);
				gnlNazimKodlariTx.setAciklama(iMap.getString(table, i, "ACIKLAMA"));
				gnlNazimKodlariTx.setDkNoBorc(iMap.getString(table, i, "DK_NO_BORC"));
				gnlNazimKodlariTx.setDkNoAlacak(iMap.getString(table, i, "DK_NO_ALACAK"));
				gnlNazimKodlariTx.setId(gnlNazimKodlariTxId);
				session.saveOrUpdate(gnlNazimKodlariTx);
				i++;

			}

			session.flush();

			iMap.put("TRX_NAME", "1203");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1203_GET_DATA")
	public static GMMap getIslemTuruById(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			String func = "{? = call PKG_TRN1203.get_rec_query(?)}";
			Object[] inputValues = new Object[2];
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KOD");

			String tableName = "TBL";
			oMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN1203_CHECK_DOUBLE_DATA")
	public static GMMap existData(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			int i = 0;
			int j = 0;
			String table = "TBL";
			while (i < iMap.getSize(table)) {
				j = i + 1;
				String kod = iMap.getString(table, i, "KOD");
				while (j < iMap.getSize(table)) {
					String kodAna = iMap.getString(table, j, "KOD");
					if (kod.equalsIgnoreCase(kodAna))
						oMap.put("MESSAGE", "Bu KOD daha �nce kullan�lm�� -> " + iMap.getString(table, j, "KOD"));
					j++;
				}
				i++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN1203_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			List<GnlNazimKodlariTx> gnlNazimKodlariTx = (List<GnlNazimKodlariTx>) session.createCriteria(GnlNazimKodlariTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			int i = 0;
			String table = "TBL";
			for (GnlNazimKodlariTx recItem : gnlNazimKodlariTx) {

				oMap.put(table, i, "ACIKLAMA", recItem.getAciklama());
				oMap.put(table, i, "DK_NO_BORC", recItem.getDkNoBorc());
				oMap.put(table, i, "DK_NO_ALACAK", recItem.getDkNoAlacak());
				oMap.put(table, i, "KOD", recItem.getId().getKod());
				oMap.put(table, i, "TRX_NO", recItem.getId().getTxNo());
				i++;

			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;

	}

}
