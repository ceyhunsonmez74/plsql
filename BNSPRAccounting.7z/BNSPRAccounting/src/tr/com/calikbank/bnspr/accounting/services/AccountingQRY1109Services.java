package tr.com.calikbank.bnspr.accounting.services;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingQRY1109Services {
	@GraymoundService("BNSPR_QRY1109_GET_TEKDUZEN_HESAP_PLAN_LIST")
	public static GMMap getTekduzenHesapPlanList(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_rc_accounting.RC_QRY1109_GET_TD_HSP_PLN_LST(?,?)}");

			int i = 1;	

			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("BAS_HESAP_NO"));
			stmt.setString(i++, iMap.getString("SON_HESAP_NO"));

			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);

			String tableName = "TEKDUZEN_HESAP_PLAN";

			GMMap oMap = new GMMap();


			int j = 0;
			while (rSet.next()) {
				oMap.put(tableName, j, "HESAP_NO", rSet.getString("hesap_no"));
				oMap.put(tableName, j, "DK_KOD", rSet.getString("dk_kod"));
				oMap.put(tableName, j, "BA_KOD", rSet.getString("ba_kod"));
				oMap.put(tableName, j, "ACIKLAMA", rSet.getString("aciklama"));
				oMap.put(tableName, j, "HESAP_TERSE_DONSUN_MU", rSet.getString("hesap_terse_donsun_mu"));
				oMap.put(tableName, j, "ALTHESAP_MI", rSet.getString("althesap_mi"));
				oMap.put(tableName, j, "HESAP_TIPI", rSet.getString("hesap_tipi"));
				j++;
			}

			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
}