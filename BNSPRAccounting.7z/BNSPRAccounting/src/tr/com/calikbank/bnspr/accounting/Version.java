package tr.com.calikbank.bnspr.accounting;

public class Version {

}
