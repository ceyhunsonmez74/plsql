package tr.com.calikbank.bnspr.accounting.services;

import java.io.File;
import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;
import jxl.write.WriteException;
import jxl.write.biff.RowsExceededException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class AccountingQRY1112Services {
	private static String ROOT = GMServer.getProperty("graymound.home",null)+
	File.separator 	+
	"Server"		+
	File.separator 	+
	"Content"		+
	File.separator	+
	"Root"			;
	
	@GraymoundService("BNSPR_QRY1112_GET_RECORDS")
	public static GMMap getRecords(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_RC1112.PKG_RC1112_Get_Records(?,?)}"); //PROSEDUR
			
			int i = 0;
			stmt.registerOutParameter(++i, -10);
			if(iMap.get("TARIH")!=null)
				stmt.setDate(++i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(++i, null);

			stmt.setString(++i,iMap.getString("SUBE_KODU"));
			
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetResults(rSet, "TBL_1");

			
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY1112_HEPSINI_GOSTER")
	public static GMMap getHepsiniGoster(GMMap iMap) throws ParseException, RowsExceededException, WriteException, IOException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_RC1112.PKG_RC1112_Detay_Goster(?,?,?,?,?,?,?,?)}"); //PROSEDUR
			
			int i = 0;
			stmt.registerOutParameter(++i, -10);
			if(iMap.get("TARIH")!=null)
				stmt.setDate(++i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(++i, null);
			
			stmt.setString	(++i, iMap.getString("SUBE_KODU"));
			stmt.setString(++i, null);
			stmt.setString(++i, null);
			stmt.setString(++i, null);
			stmt.setString(++i, null);
			stmt.setString(++i, null);
			stmt.setString(++i, null);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			int fileNum = 1;
			File f = new File(ROOT+File.separator+"files"+File.separator + "reeskont_"+fileNum+".csv");
			WritableWorkbook workbook = Workbook.createWorkbook(f); 
			int sheetNum = 0;
			WritableSheet sheet = workbook.createSheet("Reeskont izleme_"+fileNum+"_"+(sheetNum+1), sheetNum);
			//Baslik satiri.
			int row = 0;
			int col = 0;
			sheet.addCell(new Label(col++, row, "TARIH"));
			sheet.addCell(new Label(col++, row, "SUBE"));
			sheet.addCell(new Label(col++, row, "DOVIZ KODU"));
			sheet.addCell(new Label(col++, row, "HESAP NO"));
			sheet.addCell(new Label(col++, row, "REESKONT TUTARI"));
			sheet.addCell(new Label(col++, row, "REESKONT TUTARI TL"));
			sheet.addCell(new Label(col++, row, "MUSTERI NO"));
			sheet.addCell(new Label(col++, row, "UNVAN"));
			sheet.addCell(new Label(col++, row, "DK"));
			sheet.addCell(new Label(col++, row, "REESKONT HESAP"));
			sheet.addCell(new Label(col++, row, "GELIR HESAP"));
			sheet.addCell(new Label(col++, row, "FIS NO"));
			sheet.addCell(new Label(col++, row, "TUR"));
			sheet.addCell(new Label(col++, row, "MODUL TUR KOD"));
			sheet.addCell(new Label(col++, row, "URUN TUR KOD"));
			sheet.addCell(new Label(col++, row, "URUN SINIF KOD"));
			sheet.addCell(new Label(col++, row, "ANA HESAP"));
			sheet.addCell(new Label(col++, row, "BAKIYE"));
			sheet.addCell(new Label(col++, row, "VALORLU BAKIYE"));
			sheet.addCell(new Label(col++, row, "BIRIKMIS FAIZ TUTARI"));
			sheet.addCell(new Label(col++, row, "BIRIKMIS FAIZ KOMISYON"));
			sheet.addCell(new Label(col++, row, "IRR FAIZ REESKONT"));
			sheet.addCell(new Label(col++, row, "IRR KOMISYON REESKONT"));
			
			row++;
			
			DateFormat df = new SimpleDateFormat("dd.MM.yyyy");
			while(rSet.next()) {
				col = 0;
				sheet.addCell(new Label(col++, row, rSet.getString("tarih") == null ? "" : df.format((Date)rSet.getDate("tarih"))));
				sheet.addCell(new Label(col++, row, rSet.getString("sube")));
				sheet.addCell(new Label(col++, row, rSet.getString("doviz_kodu")));
				sheet.addCell(new Label(col++, row, rSet.getString("hesap_no") == null ? "" : rSet.getBigDecimal("hesap_no").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("rees_tut") == null ? "" : rSet.getBigDecimal("rees_tut").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("REES_TUT_TL") == null ? "" : rSet.getBigDecimal("REES_TUT_TL").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("musterino") == null ? "" : rSet.getBigDecimal("musterino").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("unvan")));
				sheet.addCell(new Label(col++, row, rSet.getString("dk")));
				sheet.addCell(new Label(col++, row, rSet.getString("reeskont_hesap")));
				sheet.addCell(new Label(col++, row, rSet.getString("gelir_hesap")));
				sheet.addCell(new Label(col++, row, rSet.getString("Fis_No") == null ? "" : rSet.getBigDecimal("Fis_No").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("Tur")));
				sheet.addCell(new Label(col++, row, rSet.getString("modul_tur_kod")));
				sheet.addCell(new Label(col++, row, rSet.getString("urun_tur_kod")));
				sheet.addCell(new Label(col++, row, rSet.getString("urun_sinif_kod")));
				sheet.addCell(new Label(col++, row, rSet.getString("ana_hesap")));
				sheet.addCell(new Label(col++, row, rSet.getString("bakiye") == null ? "" : rSet.getBigDecimal("bakiye").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("valorlu_bakiye") == null ? "" : rSet.getBigDecimal("valorlu_bakiye").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("birikmis_faiz_tutari") == null ? "" : rSet.getBigDecimal("birikmis_faiz_tutari").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("birikmis_faiz_kom") == null ? "" : rSet.getBigDecimal("birikmis_faiz_kom").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("FAIZ_REES_IRR") == null ? "" : rSet.getBigDecimal("FAIZ_REES_IRR").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("KOM_REES_IRR") == null ? "" : rSet.getBigDecimal("KOM_REES_IRR").toString()));
				
				row++;
				//Sorgu bazen maximum excel satirini geciyor. Bu sebeple satir kontrolu eklenip diger scheet'e gecicek.
				if(row>65000){
					if(sheetNum == 2){
						fileNum++;
						workbook.write();
						workbook.close();
						f = new File(ROOT+File.separator+"files"+File.separator + "reeskont_"+fileNum+".csv");
						workbook = Workbook.createWorkbook(f);
						sheetNum = 0;
					}else
						sheetNum++;
					row = 0;
					sheet = workbook.createSheet("Reeskont izleme_"+fileNum+"_"+(sheetNum+1), sheetNum);
					//yeni sheet e baslik ekleyelim.
					col = 0;
					sheet.addCell(new Label(col++, row, "TARIH"));
					sheet.addCell(new Label(col++, row, "SUBE"));
					sheet.addCell(new Label(col++, row, "DOVIZ KODU"));
					sheet.addCell(new Label(col++, row, "HESAP NO"));
					sheet.addCell(new Label(col++, row, "REESKONT TUTARI"));
					sheet.addCell(new Label(col++, row, "REESKONT TUTARI TL"));
					sheet.addCell(new Label(col++, row, "MUSTERI NO"));
					sheet.addCell(new Label(col++, row, "UNVAN"));
					sheet.addCell(new Label(col++, row, "DK"));
					sheet.addCell(new Label(col++, row, "REESKONT HESAP"));
					sheet.addCell(new Label(col++, row, "GELIR HESAP"));
					sheet.addCell(new Label(col++, row, "FIS NO"));
					sheet.addCell(new Label(col++, row, "TUR"));
					sheet.addCell(new Label(col++, row, "MODUL TUR KOD"));
					sheet.addCell(new Label(col++, row, "URUN TUR KOD"));
					sheet.addCell(new Label(col++, row, "URUN SINIF KOD"));
					sheet.addCell(new Label(col++, row, "ANA HESAP"));
					sheet.addCell(new Label(col++, row, "BAKIYE"));
					sheet.addCell(new Label(col++, row, "VALORLU BAKIYE"));
					sheet.addCell(new Label(col++, row, "BIRIKMIS FAIZ TUTARI"));
					sheet.addCell(new Label(col++, row, "BIRIKMIS FAIZ KOMISYON"));
					sheet.addCell(new Label(col++, row, "IRR FAIZ REESKONT"));
					sheet.addCell(new Label(col++, row, "IRR KOMISYON REESKONT"));					
					row++;
				}
			}
			workbook.write();
			workbook.close();
			iMap.put("DOSYA_SAYISI", fileNum);
			return iMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY1112_DELETE_TMP_FILE")
	public static GMMap deleteTmpFile(GMMap iMap){ 
		try {
			for (int i = 1; i <= iMap.getInt("DOSYA_SAYISI"); i++) {
				File f = new File(ROOT+File.separator+"files"+File.separator + "reeskont_"+i+".csv");
				f.delete();
			}
			return iMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("BNSPR_QRY1112_GET_DETAY")
	public static GMMap getDetay(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC1112.PKG_RC1112_Detay_Goster(?,?,?,?,?,?,?,?)}"); //PROSEDUR
			
			int i = 0;
			stmt.registerOutParameter(++i, -10);
			if(iMap.get("TARIH")!=null)
				stmt.setDate(++i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(++i, null);
			stmt.setString	(++i, iMap.getString("SUBE_KODU"));
			stmt.setString(++i, iMap.getString("REES_TUR"));
			stmt.setString(++i, iMap.getString("MODUL_TUR_KOD"));
			stmt.setString(++i, iMap.getString("URUN_TUR_KOD"));
			stmt.setString(++i, iMap.getString("URUN_SINIF_KOD"));
			stmt.setString(++i, iMap.getString("DOVIZ_KOD"));
			stmt.setString(++i, iMap.getString("GRUP_KOD"));
			
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetResults(rSet, "TBL_2");
			
		} catch (SQLException e) {
			//throw new GMRuntimeException(1, e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
