package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhHpHesapGuncelleAnaTX;
import tr.com.calikbank.bnspr.dao.MuhHpHesapGuncelleTx;
import tr.com.calikbank.bnspr.dao.MuhHpHesapGuncelleTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1103Services {
	@GraymoundService("BNSPR_TRN1103_GET_COMBO_ITEMS")
	public static GMMap getBAKods(GMMap iMap) {
		GMMap oMap = new GMMap();
		createComboItems(oMap, "COMBO_EH");
		createBAComboItems(oMap, "COMBO_BA");
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1103_GET_DK_LIST")
	public static GMMap getDKList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN1103.BilgiAktar(?, ?, ?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TX_NO"));
			stmt.setString(2, iMap.getString("DK_HESAP_BASLANGIC"));
			stmt.setString(3, iMap.getString("DK_HESAP_BITIS"));
			stmt.execute();
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		GMMap oMap = new GMMap();
		try{
			Session session	= DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(MuhHpHesapGuncelleTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TX_NO"))).addOrder(Order.asc("id.numara")).list();
			String tableName = "RESULTS";
			int i = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				MuhHpHesapGuncelleTx muhHpHesapGuncelleTx = (MuhHpHesapGuncelleTx) iterator.next();
				oMap.put(tableName, i, "NUMARA", muhHpHesapGuncelleTx.getId().getNumara());
				oMap.put(tableName, i, "DK_KISA_ISIM", muhHpHesapGuncelleTx.getDkKisaIsim());
				oMap.put(tableName, i, "ACIKLAMA", muhHpHesapGuncelleTx.getAciklama());
				oMap.put(tableName, i, "BA_KOD", muhHpHesapGuncelleTx.getBaKod());
				oMap.put(tableName, i, "KARSI_SUBEYE_KAPALI_MI", muhHpHesapGuncelleTx.getKarsiSubeyeKapaliMi());
				oMap.put(tableName, i, "HESAP_TERSE_DONSUN_MU", muhHpHesapGuncelleTx.getHesapTerseDonsunMu());
				oMap.put(tableName, i, "ALTHESAP_MI", muhHpHesapGuncelleTx.getAlthesapMi());
				oMap.put(tableName, i, "SUBEYE_KAPALI_MI", muhHpHesapGuncelleTx.getSubeyeKapaliMi());
				oMap.put(tableName, i, "GENEL_MD_KAPALI_MI", muhHpHesapGuncelleTx.getGenelMdKapaliMi());
				oMap.put(tableName, i, "MUSTERILI_HESAP_MI", muhHpHesapGuncelleTx.getMusteriliHesapMi());
				oMap.put(tableName, i, "FAIZ_HESAPLANACAK_MI", muhHpHesapGuncelleTx.getFaizHesaplanacakMi());
				oMap.put(tableName, i, "PERSONELE_BAGLI_MI", muhHpHesapGuncelleTx.getPersoneleBagliMi());
				oMap.put(tableName, i, "SBA_KAPALI_MI", muhHpHesapGuncelleTx.getSbaKapaliMi());
				oMap.put(tableName, i, "KAR_ZARAR_GL", muhHpHesapGuncelleTx.getKarZararGl());
				i++;
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1103_GET_RECORD")
	public static GMMap getRecord(GMMap iMap) {
		try{
			Session session	= DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			MuhHpHesapGuncelleAnaTX muhHpHesapGuncelleAnaTX = (MuhHpHesapGuncelleAnaTX)session.get(MuhHpHesapGuncelleAnaTX.class, iMap.getBigDecimal("TRX_NO"));
			oMap.put("DK_HESAP_BASLANGIC", muhHpHesapGuncelleAnaTX.getBas_DK());
			oMap.put("DK_HESAP_BITIS", muhHpHesapGuncelleAnaTX.getSon_DK());

			List<?> list = session.createCriteria(MuhHpHesapGuncelleTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).addOrder(Order.asc("id.numara")).list();
			String tableName = "RESULTS";
			int i = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				MuhHpHesapGuncelleTx muhHpHesapGuncelleTx = (MuhHpHesapGuncelleTx) iterator.next();
				oMap.put(tableName, i, "NUMARA", muhHpHesapGuncelleTx.getId().getNumara());
				oMap.put(tableName, i, "DK_KISA_ISIM", muhHpHesapGuncelleTx.getDkKisaIsim());
				oMap.put(tableName, i, "ACIKLAMA", muhHpHesapGuncelleTx.getAciklama());
				oMap.put(tableName, i, "BA_KOD", muhHpHesapGuncelleTx.getBaKod());
				oMap.put(tableName, i, "KARSI_SUBEYE_KAPALI_MI", muhHpHesapGuncelleTx.getKarsiSubeyeKapaliMi());
				oMap.put(tableName, i, "HESAP_TERSE_DONSUN_MU", muhHpHesapGuncelleTx.getHesapTerseDonsunMu());
				oMap.put(tableName, i, "ALTHESAP_MI", muhHpHesapGuncelleTx.getAlthesapMi());
				oMap.put(tableName, i, "SUBEYE_KAPALI_MI", muhHpHesapGuncelleTx.getSubeyeKapaliMi());
				oMap.put(tableName, i, "GENEL_MD_KAPALI_MI", muhHpHesapGuncelleTx.getGenelMdKapaliMi());
				oMap.put(tableName, i, "MUSTERILI_HESAP_MI", muhHpHesapGuncelleTx.getMusteriliHesapMi());
				oMap.put(tableName, i, "FAIZ_HESAPLANACAK_MI", muhHpHesapGuncelleTx.getFaizHesaplanacakMi());
				oMap.put(tableName, i, "PERSONELE_BAGLI_MI", muhHpHesapGuncelleTx.getPersoneleBagliMi());
				oMap.put(tableName, i, "SBA_KAPALI_MI", muhHpHesapGuncelleTx.getSbaKapaliMi());
				oMap.put(tableName, i, "KAR_ZARAR_GL", muhHpHesapGuncelleTx.getKarZararGl());
				i++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1103_UPDATE_DK")
	public static Map<?, ?> updateDKList(GMMap iMap) {
		try{
			Session session	= DAOSession.getSession("BNSPRDal");
			MuhHpHesapGuncelleAnaTX muhHpHesapGuncelleAnaTX = (MuhHpHesapGuncelleAnaTX )session.get(MuhHpHesapGuncelleAnaTX.class, iMap.getBigDecimal("TRX_NO"));
			if(muhHpHesapGuncelleAnaTX == null){
				muhHpHesapGuncelleAnaTX = new MuhHpHesapGuncelleAnaTX();
				muhHpHesapGuncelleAnaTX.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}
			muhHpHesapGuncelleAnaTX.setBas_DK(iMap.getString("DK_HESAP_BASLANGIC"));
			muhHpHesapGuncelleAnaTX.setSon_DK(iMap.getString("DK_HESAP_BITIS"));
			session.saveOrUpdate(muhHpHesapGuncelleAnaTX);
			session.flush();
			
			List<?> dkPersistenceList = session.createCriteria(MuhHpHesapGuncelleTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = dkPersistenceList.iterator(); iterator
					.hasNext();) {
				MuhHpHesapGuncelleTx muhHpHesapGuncelleTx = (MuhHpHesapGuncelleTx) iterator.next();
				session.delete(muhHpHesapGuncelleTx);
			}
			session.flush();
			
			String tableName = "DK_LIST";
			for (int row = 0; row < iMap.getSize(tableName); row++) {
				MuhHpHesapGuncelleTx muhHpHesapGuncelleTx = new MuhHpHesapGuncelleTx();
				muhHpHesapGuncelleTx.setDkKisaIsim(iMap.getString(tableName, row, "DK_KISA_ISIM"));
				muhHpHesapGuncelleTx.setAciklama(iMap.getString(tableName, row, "ACIKLAMA"));
				muhHpHesapGuncelleTx.setBaKod(iMap.getString(tableName, row, "BA_KOD"));
				muhHpHesapGuncelleTx.setKarsiSubeyeKapaliMi(iMap.getString(tableName, row, "KARSI_SUBEYE_KAPALI_MI"));
				muhHpHesapGuncelleTx.setHesapTerseDonsunMu(iMap.getString(tableName, row, "HESAP_TERSE_DONSUN_MU"));
				muhHpHesapGuncelleTx.setAlthesapMi(iMap.getString(tableName, row, "ALTHESAP_MI"));
				muhHpHesapGuncelleTx.setSubeyeKapaliMi(iMap.getString(tableName, row, "SUBEYE_KAPALI_MI"));
				muhHpHesapGuncelleTx.setGenelMdKapaliMi(iMap.getString(tableName, row, "GENEL_MD_KAPALI_MI"));
				muhHpHesapGuncelleTx.setMusteriliHesapMi(iMap.getString(tableName, row, "MUSTERILI_HESAP_MI"));
				muhHpHesapGuncelleTx.setFaizHesaplanacakMi(iMap.getString(tableName, row, "FAIZ_HESAPLANACAK_MI"));
				muhHpHesapGuncelleTx.setPersoneleBagliMi(iMap.getString(tableName, row, "PERSONELE_BAGLI_MI"));
				muhHpHesapGuncelleTx.setSbaKapaliMi(iMap.getString(tableName, row, "SBA_KAPALI_MI"));
				muhHpHesapGuncelleTx.setKarZararGl(iMap.getString(tableName, row, "KAR_ZARAR_GL"));
				MuhHpHesapGuncelleTxId id = new MuhHpHesapGuncelleTxId();
				id.setNumara(iMap.getString(tableName, row, "NUMARA"));
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				muhHpHesapGuncelleTx.setId(id);
				session.save(muhHpHesapGuncelleTx);
			}
			session.flush();
			
			iMap.put("TRX_NAME", "1103");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
		}
	}
	
	private static GMMap createComboItems(GMMap oMap, String listName) {
		GuimlUtil.wrapMyCombo(oMap, listName, "E", "E");
		GuimlUtil.wrapMyCombo(oMap, listName, "H", "H");
		return oMap;
	}
	
	private static GMMap createBAComboItems(GMMap oMap, String listName) {
		GuimlUtil.wrapMyCombo(oMap, listName, "B", "B");
		GuimlUtil.wrapMyCombo(oMap, listName, "A", "A");
		GuimlUtil.wrapMyCombo(oMap, listName, "X", "X");
		return oMap;
	}
	
//	@GraymoundService("BNSPR_TRN1103_GET_COMBO_ITEMS")
//	public static GMMap getList(GMMap iMap) {
//		GMMap oMap = new GMMap();
//		return createComboItems(oMap, "COMBO");
//	}
}
