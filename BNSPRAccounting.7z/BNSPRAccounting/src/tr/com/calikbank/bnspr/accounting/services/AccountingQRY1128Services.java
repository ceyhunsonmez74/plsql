package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.text.ParseException;


import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class AccountingQRY1128Services {

	
    
    @GraymoundService("BNSPR_TRN1128_FILL_COMBOBOX_INITIAL_VALUE")
    public static GMMap fillComboBox(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            iMap.put("ADD_EMPTY_KEY", "H");
            iMap.put("KEY2", "A");
            iMap.put("KOD", "GECICI_HESAP_AC_KAPA_ISLEM_DURUM");
            oMap.put(   "GECICI_ISLEM_DURUM",
                    GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
                            iMap).get("RESULTS"));
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    

	@GraymoundService("BNSPR_QRY1128_GET_DETAY")
	public static GMMap getDetay(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc1128.RC_QRY1128(?,?,?,?,?,?)}");	
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("REFERANS"));
			if (!(iMap.get("BAS_TARIH") == null)) {
				stmt.setDate(i++, new Date(iMap.getDate("BAS_TARIH").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			
		     if (!(iMap.get("BIT_TARIH") == null)) {
	                stmt.setDate(i++, new Date(iMap.getDate("BIT_TARIH").getTime()));
	            } else {
	                stmt.setDate(i++, null);
	            }
			stmt.setString(i++, iMap.getString("BAS_HESAP"));
			stmt.setString(i++, iMap.getString("BIT_HESAP"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			
			stmt.execute();
			String tableName = "GECICI_HESAP_DETAY";
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			int j = 0;
			while (rSet.next()) {		
				oMap.put(tableName, j, "REFERANS", rSet.getString("REFERANS"));
				oMap.put(tableName, j, "BORC_HESAP_NO", rSet.getString("BORC_HESAP_NO"));
				oMap.put(tableName, j, "ALACAK_HESAP_NO", rSet.getString("ALACAK_HESAP_NO"));
				oMap.put(tableName, j, "BORC_MUSTERI_NO", rSet.getBigDecimal("BORC_MUSTERI_NO"));
				oMap.put(tableName, j, "ALACAK_MUSTERI_NO", rSet.getBigDecimal("ALACAK_MUSTERI_NO"));
				oMap.put(tableName, j, "TUTAR", rSet.getBigDecimal("TUTAR"));
				oMap.put(tableName, j, "DOVIZ_KODU", rSet.getString("DOVIZ_KODU"));
				oMap.put(tableName, j, "ACIKLAMA", rSet.getString("ACIKLAMA"));
				oMap.put(tableName, j, "ISLEM_TARIHI", rSet.getDate("ISLEM_TARIHI"));
				oMap.put(tableName, j, "TARIHCE_MODEL", GMServiceExecuter.call("BNSPR_RC1128_GET_ISLEM_LIST", new GMMap().put("REFERANS", rSet.getString("REFERANS"))).get("ISLEM_DETAY"));
				oMap.put(tableName, j, "DURUM", rSet.getString("DURUM"));
				j++ ;
			}

			return oMap;
		} catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
	  
    @GraymoundService("BNSPR_RC1128_GET_ISLEM_LIST")
    public static GMMap getListAlt(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
        	conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call PKG_RC1128.RC_QRY1128_GET_ISLEM(?) }");

            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setString(i++, iMap.getString("REFERANS"));
            
            
            stmt.execute();
            String tableName = "ISLEM_DETAY";
            
            rSet = (ResultSet) stmt.getObject(1);
            GMMap oMap = new GMMap();
        
            int j=0;
            while (rSet.next()) {
                oMap.put(tableName, j, "ISLEM_TARIHI", rSet.getDate("ISLEM_TARIHI"));
                oMap.put(tableName, j, "ISLEM_NO", rSet.getBigDecimal("ISLEM_NO"));
                oMap.put(tableName, j, "TUTAR", rSet.getBigDecimal("TUTAR"));
                oMap.put(tableName, j, "DURUM", rSet.getString("DURUM"));
                oMap.put(tableName, j, "DURUM_KOD", rSet.getString("DURUM_KOD"));
                oMap.put(tableName, j, "ISLEM_TURU", rSet.getString("ISLEM_TURU"));
                 
                j++;
            }
            GMServerDatasource.close(rSet);
            
        
            

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
}				 
