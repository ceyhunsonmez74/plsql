package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MuhTersFisTx;
import tr.com.aktifbank.bnspr.dao.MuhTersFisTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1118Services {

	@GraymoundService("BNSPR_TRN1118_LIST")
	public static GMMap getList(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{      
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_Trn1118.Get_Fis_Data(?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			
			if(iMap.getDate("BAS_TARIHI") != null)
				stmt.setDate(i++,  new java.sql.Date(iMap.getDate("BAS_TARIHI").getTime()));
			else
				stmt.setDate(i++, null);
			if(iMap.getDate("BIT_TARIHI") != null)
				stmt.setDate(i++,  new java.sql.Date(iMap.getDate("BIT_TARIHI").getTime()));
			else
				stmt.setDate(i++, null);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIS_NO"));
			if(iMap.getBigDecimal("ISLEM_KODU")!=null)
				stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_KODU"));
			else
				stmt.setBigDecimal(i++, null);
			stmt.setString(i++, iMap.getString("BOLUM_KODU"));
			stmt.setString(i++, iMap.getString("GET_INFO"));
			
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			return DALUtil.rSetResults(rSet, "FIS_LIST");
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN1118_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "FIS_LIST";
			List<?> list = (List<?>)iMap.get("FIS_LIST");
			for (int i = 0; i < list.size(); i++) {
				if(iMap.getBoolean(tableName, i, "SEC")){
				MuhTersFisTxId id = new MuhTersFisTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setFisNo(iMap.getBigDecimal(tableName,i,"NUMARA"));
				MuhTersFisTx muhTersFisTx = new MuhTersFisTx();
				muhTersFisTx.setKriBasTarih(iMap.getDate("BAS_TARIHI"));
				muhTersFisTx.setKriBitTarih(iMap.getDate("BIT_TARIHI"));
				muhTersFisTx.setKriFisNo(iMap.getBigDecimal("FIS_NO"));
				muhTersFisTx.setCbTers("E");
				muhTersFisTx.setBolumKodu(iMap.getString("BOLUM_KODU"));
				muhTersFisTx.setIslemKodu(iMap.getBigDecimal("ISLEM_KODU"));
				muhTersFisTx.setId(id);
				
				session.saveOrUpdate(muhTersFisTx);
				}
			}
			session.flush();
			iMap.put("TRX_NAME", "1118");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1118_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(MuhTersFisTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			GMMap oMap = new GMMap();
			String tableName = "FIS_LIST";
			int row = 0;
			GMMap temp = new GMMap();
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				MuhTersFisTx muhTersFisTx = (MuhTersFisTx)iterator.next();
				if(row==0)
				{
					temp.put("BAS_TARIHI", muhTersFisTx.getKriBasTarih());
					temp.put("BIT_TARIHI", muhTersFisTx.getKriBitTarih());
					temp.put("FIS_NO", muhTersFisTx.getKriFisNo());
					temp.put("ISLEM_KODU", muhTersFisTx.getIslemKodu());
					temp.put("BOLUM_KODU", muhTersFisTx.getBolumKodu());
					temp.put("GET_INFO", "E");
					oMap = getList(temp);
					oMap.put("BAS_TARIHI", muhTersFisTx.getKriBasTarih());
					oMap.put("BIT_TARIHI", muhTersFisTx.getKriBitTarih());
					oMap.put("FIS_NO", muhTersFisTx.getKriFisNo());
					oMap.put("ISLEM_KODU", muhTersFisTx.getIslemKodu());
					oMap.put("BOLUM_KODU", muhTersFisTx.getBolumKodu());
				}
				List<?> oMaplist = (List<?>)oMap.get("FIS_LIST");
				for(int i = 0; i < oMaplist.size(); i++ )
				{
					if(muhTersFisTx.getId().getFisNo().compareTo(oMap.getBigDecimal(tableName,i,"NUMARA"))==0)
						if("E".equals(muhTersFisTx.getCbTers()))
						{
							oMap.put(tableName, i, "SEC", true);
							break;
						}
						else
							break;
				}
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
