package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Date;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class AccountingQRY1103Services {
	
	@GraymoundService("BNSPR_TRN_1103Q_LISTELE_GENEL")
	public static GMMap getListeGenel(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{      
			
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC1103.QRY1103_Get_Genel_B_A_Izleme(?,?,?,?,?,?,?,?,?)}"); //PROSEDUR
			
			int i = 0;
			stmt.setString	(++i, iMap.getString("BOLUMKODUBAS"));
			stmt.setString	(++i, iMap.getString("BOLUMKODUSON"));
			stmt.setString	(++i, iMap.getString("SUBEKODUBAS"));
			stmt.setString	(++i, iMap.getString("SUBEKODUSON"));
			
			
			stmt.setString(++i, iMap.getString("DKHESAPNOBAS"));
			stmt.setString(++i, iMap.getString("DKHESAPNOSON"));
			
			if(iMap.get("TARIHBAS")!=null)
				stmt.setDate(++i, new Date(iMap.getDate("TARIHBAS").getTime()));
			else 
				stmt.setDate(++i, null);
			if(iMap.get("TARIHSON")!=null)
				stmt.setDate(++i, new Date(iMap.getDate("TARIHSON").getTime()));
			else 
				stmt.setDate(++i, null);
			
			stmt.registerOutParameter(++i, -10);
			stmt.execute();
			//stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(i);
			return DALUtil.rSetResults(rSet, "GENELTABLO");
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN_1103Q_LISTELE_DETAY")
	public static GMMap getlisteDetay(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try{      
			
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC1103.QRY1103_Get_Detay_B_A_Izleme(?,?,?,?,?,?)}"); //PROSEDUR
			
			int i = 0;
			stmt.setString	(++i, iMap.getString("BOLUMKODU"));
			stmt.setBigDecimal	(++i, iMap.getBigDecimal("SUBE"));
			stmt.setBigDecimal	(++i, iMap.getBigDecimal("DKHESABI"));

			if(iMap.get("TARIHBAS")!=null)
				stmt.setDate(++i, new Date(iMap.getDate("TARIHBAS").getTime()));
			else 
				stmt.setDate(++i, null);
			
			if(iMap.get("TARIHSON")!=null)
				stmt.setDate(++i, new Date(iMap.getDate("TARIHSON").getTime()));
			else 
				stmt.setDate(++i, null);
			
			stmt.registerOutParameter(++i, -10);
			stmt.execute();
			//stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(i);
			oMap =  DALUtil.rSetResults(rSet, "DETAYTABLO");
			return oMap;
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	

}
