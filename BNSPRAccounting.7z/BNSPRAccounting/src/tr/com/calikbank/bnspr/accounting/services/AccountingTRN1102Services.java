package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MuhMasrafKomTahsilTx;
import tr.com.aktifbank.bnspr.dao.MuhMasrafKomTahsilTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1102Services {
	@GraymoundService("BNSPR_TRN1102_GET_BSMV_KKDF")
	public static GMMap getBsmvKkdf(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			
			conn = DALUtil.getGMConnection();
		
			stmt = conn.prepareCall("{call pkg_trn1102.bsmv_kkdf_hesapla(?,?,?,?,?,?,?,?,?,?,?)}");

			stmt.setString(1, iMap.getString("DOVIZ_KODU"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("TAHSIL_TUTARI"));
			stmt.setString(3, iMap.getString("BSMV"));
			stmt.setString(4, iMap.getString("KKDF"));
			stmt.setBigDecimal(5, iMap.getBigDecimal("TESVIK_ORAN"));
			stmt.setBigDecimal(6, iMap.getBigDecimal("KUR"));
			stmt.setString(7, iMap.getString("BSMV_ICINDEN_MI"));
			stmt.registerOutParameter(8, Types.DECIMAL);
			stmt.registerOutParameter(9, Types.DECIMAL);
			stmt.registerOutParameter(10, Types.DECIMAL);
			stmt.registerOutParameter(11, Types.DECIMAL);

			stmt.execute();
			
			GMMap oMap = new GMMap();
			oMap.put("BSMV_ORAN", getBigDecimal(stmt.getObject(8)));
			oMap.put("BSMV_TUTAR", getBigDecimal(stmt.getBigDecimal(9)));
			oMap.put("KKDF_ORAN", getBigDecimal(stmt.getBigDecimal(10)));
			oMap.put("KKDF_TUTAR", getBigDecimal(stmt.getBigDecimal(11)));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	public static BigDecimal getBigDecimal(Object obj){
		if(obj == null) return new BigDecimal(0);
		else return new BigDecimal(obj.toString());
	}
	
	@GraymoundService("BNSPR_TRN1102_FILL_COMBOBOX")
	public static GMMap fillComboBox(GMMap iMap)
	{
		GMMap oMap=new GMMap();
		iMap.put("ADD_EMPTY_KEY", "H");
        iMap.put("KOD", "MAS_KOM_BOLUM_KOD");
        oMap.put("BOLUM_KOD",GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", 
                   iMap).get("RESULTS"));  
        return oMap;
       

	}
	
	@GraymoundService("BNSPR_TRN1102_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			MuhMasrafKomTahsilTxId muhMasrafKomTahsilTxId = new MuhMasrafKomTahsilTxId() ;
			MuhMasrafKomTahsilTx muhMasrafKomTahsilTx = (MuhMasrafKomTahsilTx)session.createCriteria(MuhMasrafKomTahsilTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			
			if(muhMasrafKomTahsilTx == null){
				muhMasrafKomTahsilTx = new MuhMasrafKomTahsilTx();
				muhMasrafKomTahsilTxId = new MuhMasrafKomTahsilTxId();
			}
			else 
			muhMasrafKomTahsilTxId = muhMasrafKomTahsilTx.getId();
			
			muhMasrafKomTahsilTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
			muhMasrafKomTahsilTxId.setGelirTipi(iMap.getString("GELIR_TIPI"));
			muhMasrafKomTahsilTx.setId(muhMasrafKomTahsilTxId);
			
			muhMasrafKomTahsilTx.setGelirAciklama(iMap.getString("GELIR_ACIKLAMA"));
			muhMasrafKomTahsilTx.setDvz(iMap.getString("DVZ"));
			muhMasrafKomTahsilTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			muhMasrafKomTahsilTx.setIliskiliHesapNo(iMap.getBigDecimal("ILISKILI_HESAP_NO"));
			muhMasrafKomTahsilTx.setIliskiliReferans(iMap.getString("ILISKILI_REFERANS"));
			muhMasrafKomTahsilTx.setReferansDovizKodu(iMap.getString("REFERANS_DOVIZ_KODU"));
			muhMasrafKomTahsilTx.setTahsilTutari(iMap.getBigDecimal("TAHSIL_TUTARI"));

			muhMasrafKomTahsilTx.setKkdfVar(iMap.getString("KKDF_VAR"));
			muhMasrafKomTahsilTx.setKkdfOran(iMap.getBigDecimal("KKDF_ORAN"));
			muhMasrafKomTahsilTx.setKkdfTutari(iMap.getBigDecimal("KKDF_TUTARI"));
			muhMasrafKomTahsilTx.setIstisnaVarMi(iMap.getString("ISTISNA_VAR_MI"));
			muhMasrafKomTahsilTx.setIstisnaOrani(iMap.getBigDecimal("ISTISNA_ORANI"));
			muhMasrafKomTahsilTx.setBsmvVar(iMap.getString("BSMV_VAR"));
			muhMasrafKomTahsilTx.setBsmvOran(iMap.getBigDecimal("BSMV_ORAN"));
			muhMasrafKomTahsilTx.setBsmvTutari(iMap.getBigDecimal("BSMV_TUTARI"));
			muhMasrafKomTahsilTx.setTesvikliOran(iMap.getBigDecimal("TESVIKLI_ORAN"));
			muhMasrafKomTahsilTx.setTahsilToplamTutar(iMap.getBigDecimal("TAHSIL_TOPLAM_TUTAR"));
			
			muhMasrafKomTahsilTx.setBelgeNo(iMap.getString("BELGE_NO"));
			muhMasrafKomTahsilTx.setBelgeKodu(iMap.getString("BELGE_KODU"));
			muhMasrafKomTahsilTx.setBelgeTarihi(iMap.getDate("BELGE_TARIHI"));
			muhMasrafKomTahsilTx.setTahsilDvzKod(iMap.getString("TAHSIL_DVZ_KOD"));
			muhMasrafKomTahsilTx.setRezervasyonNo(iMap.getBigDecimal("REZERVASYON_NO"));
			muhMasrafKomTahsilTx.setKur(iMap.getBigDecimal("KUR"));
			muhMasrafKomTahsilTx.setTahsilHesapNo(iMap.getBigDecimal("TAHSIL_HESAP_NO"));
			muhMasrafKomTahsilTx.setAciklama(iMap.getString("ACIKLAMA"));
			muhMasrafKomTahsilTx.setIslemSekli(iMap.getString("MASRAF_TAHSIL_SEKLI"));
			muhMasrafKomTahsilTx.setKasaKimlikTipi(iMap.getBigDecimal("KIMLIK_TIPI"));
			muhMasrafKomTahsilTx.setMasrafBolumKod(iMap.getString("BOLUM_KOD"));
			muhMasrafKomTahsilTx.setBsmvIcindenMi(iMap.getString("BSMV_ICINDEN_MI"));
			muhMasrafKomTahsilTx.setDkHesapNo(iMap.getString("DK_HESAP_NO"));
			muhMasrafKomTahsilTx.setBsmvBunyedenMi(iMap.getString("BSMV_BUNYEDEN_MI"));
			muhMasrafKomTahsilTx.setMasrafGelirSube(iMap.getString("MASRAF_GELIR_SUBE"));
			muhMasrafKomTahsilTx.setKgvTutari(iMap.getBigDecimal("KGV_TUTARI"));
			muhMasrafKomTahsilTx.setEftTarih(iMap.getDate("EFT_TARIH"));
			muhMasrafKomTahsilTx.setSorguNo(iMap.getBigDecimal("SORGU_NO"));
			
			session.saveOrUpdate(muhMasrafKomTahsilTx);
			
			session.flush();
			iMap.put("TRX_NAME", "1102");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1102_GET_INFO")
	public static GMMap getMasrafBilgi(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			MuhMasrafKomTahsilTx muhMasrafKomTahsilTx = (MuhMasrafKomTahsilTx)session.createCriteria(MuhMasrafKomTahsilTx.class).add(Restrictions.eq("id.txNo",iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			GMMap oMap = new GMMap();
			
			oMap.put("TRX_NO", muhMasrafKomTahsilTx.getId().getTxNo());
			oMap.put("GELIR_TIPI",muhMasrafKomTahsilTx.getId().getGelirTipi());
			oMap.put("GELIR_ACIKLAMA",LovHelper.diLov(muhMasrafKomTahsilTx.getId().getGelirTipi(),muhMasrafKomTahsilTx.getMasrafBolumKod(), "1102/LOV_GELIR_TIP", "GELIR_ACIKLAMA") );
			oMap.put("DVZ" , muhMasrafKomTahsilTx.getDvz());
			oMap.put("MUSTERI_NO", muhMasrafKomTahsilTx.getMusteriNo());
			oMap.put("DI_MUSTERI_ADI", LovHelper.diLov(muhMasrafKomTahsilTx.getMusteriNo(), "1102/LOV_MUSTERI", "ISIM"));
			oMap.put("ILISKILI_HESAP_NO", muhMasrafKomTahsilTx.getIliskiliHesapNo());
			oMap.put("ILISKILI_REFERANS", muhMasrafKomTahsilTx.getIliskiliReferans());
			oMap.put("TAHSIL_TUTARI", muhMasrafKomTahsilTx.getTahsilTutari());
			oMap.put("KKDF_VAR", muhMasrafKomTahsilTx.getKkdfVar());
			oMap.put("KKDF_ORAN", muhMasrafKomTahsilTx.getKkdfOran());
			oMap.put("KKDF_TUTARI", muhMasrafKomTahsilTx.getKkdfTutari());
			oMap.put("ISTISNA_VAR_MI", muhMasrafKomTahsilTx.getIstisnaVarMi());
			oMap.put("ISTISNA_ORANI", muhMasrafKomTahsilTx.getIstisnaOrani());
			oMap.put("BSMV_VAR", muhMasrafKomTahsilTx.getBsmvVar());
			oMap.put("BSMV_ORAN", muhMasrafKomTahsilTx.getBsmvOran());
			oMap.put("BSMV_TUTARI", muhMasrafKomTahsilTx.getBsmvTutari());
			oMap.put("TESVIKLI_ORAN", muhMasrafKomTahsilTx.getTesvikliOran());
			oMap.put("TAHSIL_TOPLAM_TUTAR", muhMasrafKomTahsilTx.getTahsilToplamTutar());
			oMap.put("BELGE_NO", muhMasrafKomTahsilTx.getBelgeNo());
			oMap.put("BELGE_KODU", muhMasrafKomTahsilTx.getBelgeKodu());			
			oMap.put("BELGE_TARIHI", muhMasrafKomTahsilTx.getBelgeTarihi());
            oMap.put("TAHSIL_DVZ_KOD", muhMasrafKomTahsilTx.getTahsilDvzKod());
            oMap.put("REZERVASYON_NO", muhMasrafKomTahsilTx.getRezervasyonNo());
            oMap.put("KUR", muhMasrafKomTahsilTx.getKur());
            oMap.put("TAHSIL_HESAP_NO", muhMasrafKomTahsilTx.getTahsilHesapNo());
            oMap.put("ACIKLAMA", muhMasrafKomTahsilTx.getAciklama());
            oMap.put("MASRAF_TAHSIL_SEKLI", muhMasrafKomTahsilTx.getIslemSekli());
            oMap.put("KIMLIK_TIPI", muhMasrafKomTahsilTx.getKasaKimlikTipi());
            oMap.put("BSMV_ICINDEN_MI", muhMasrafKomTahsilTx.getBsmvIcindenMi());
            oMap.put("BOLUM_KOD", muhMasrafKomTahsilTx.getMasrafBolumKod());
            oMap.put("DK_HESAP_NO", muhMasrafKomTahsilTx.getDkHesapNo());
            oMap.put("REFERANS_DOVIZ_KODU", muhMasrafKomTahsilTx.getReferansDovizKodu());
            oMap.put("BSMV_BUNYEDEN_MI", muhMasrafKomTahsilTx.getBsmvBunyedenMi());
            oMap.put("MASRAF_GELIR_SUBE", muhMasrafKomTahsilTx.getMasrafGelirSube());
            oMap.put("KGV_TUTARI", muhMasrafKomTahsilTx.getKgvTutari());
            oMap.put("EFT_TARIH", muhMasrafKomTahsilTx.getEftTarih());
            oMap.put("SORGU_NO", muhMasrafKomTahsilTx.getSorguNo());
            
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

    @GraymoundService("BNSPR_TRN1102_AFTER_APPROVAL")
    public static GMMap afterApproval(GMMap iMap) {
        Connection conn = null;
        ResultSet rSet = null;
        String tokenid = null;
        CallableStatement stmt = null;
        
        try {
            Session session = DAOSession.getSession("BNSPRDal");
			MuhMasrafKomTahsilTx muhMasrafKomTahsilTx = (MuhMasrafKomTahsilTx)session.createCriteria(MuhMasrafKomTahsilTx.class).add(Restrictions.eq("id.txNo",iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();

            tokenid = muhMasrafKomTahsilTx.getIliskiliReferans();
   
            GMMap sMap = new GMMap();
           if ("TOKENMAS".equals(muhMasrafKomTahsilTx.getId().getGelirTipi()))
           {
	            sMap.put("TOKEN_ID", tokenid);
	            sMap.put("UCRET_DURUM", "ALINDI");
                        
              sMap = GMServiceExecuter.call("AKTIF_SIFRE_UCRET_UPDATE", sMap);
              session.flush();
           }   
 
            return new GMMap();
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN1102_AFTER_CANCELATION")
    public static GMMap afterCancellation(GMMap iMap) {
        ResultSet rSet = null;
        String tokenid = null;
        try {
            Session session = DAOSession.getSession("BNSPRDal");
			MuhMasrafKomTahsilTx muhMasrafKomTahsilTx = (MuhMasrafKomTahsilTx)session.createCriteria(MuhMasrafKomTahsilTx.class).add(Restrictions.eq("id.txNo",iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();

            tokenid = muhMasrafKomTahsilTx.getIliskiliReferans();
   
            GMMap sMap = new GMMap();
            if ("TOKENMAS".equals(muhMasrafKomTahsilTx.getId().getGelirTipi()))
            {
               sMap.put("TOKEN_ID", tokenid);
               sMap.put("UCRET_DURUM", "ALINMADI");
                        
               sMap = GMServiceExecuter.call("AKTIF_SIFRE_UCRET_UPDATE", sMap);
              session.flush();
            }  

            return new GMMap();
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
        }

    }   

	public static Date getBankDate() {
		Connection conn = null;
		Date bankaTarihi = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_MUHASEBE.BANKA_TARIHI_BUL()}");
			stmt.registerOutParameter(1, Types.DATE);
			stmt.execute();
			bankaTarihi = stmt.getDate(1);
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return bankaTarihi;

	}
	
	@GraymoundService("BNSPR_TRN1102_GET_KGV_TUTAR")
	public static GMMap getKgvTutar(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			
			conn = DALUtil.getGMConnection();
		
			stmt = conn.prepareCall("{? = call pkg_trn2013.Vergi_Hesapla(?,?,?,?)}");

            stmt.registerOutParameter(1, Types.DECIMAL);
            stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("REZERVASYON_NO"));
			stmt.setDate(5, new java.sql.Date(getBankDate().getTime()));

			stmt.execute();
			
			GMMap oMap = new GMMap();
			oMap.put("KGV_TUTAR", stmt.getBigDecimal(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
    
    
}
