package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Calendar;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class AccountingQRY1198Services {
	
	@GraymoundService("BNSPR_QRY1198_SORGULA")
	public static GMMap sorgula(GMMap iMap){
		Connection 			conn	= null;
		CallableStatement 	stmt	= null;
		ResultSet 			rSet	= null;
		try{
	        GMMap oMap = new GMMap();
	        conn = DALUtil.getGMConnection();
	        
	        String musteriNo = iMap.getString("MUSTERI_NO");
	        String urunGrupKodu = iMap.getString("URUN_GRUP_KODU");
	        String donemYili =  iMap.getString("DONEM_YILI");
			String donemKodu =  iMap.getString("DONEM_KODU");

            // MAHSUPLASMA GECMISI
            {
                stmt = conn.prepareCall("{? = call PKG_RC_ACCOUNTING.RC_QRY1198_GET_DONEMSEL_DURUM(?,?,?,?)}");
                stmt.registerOutParameter(1, -10);
                stmt.setBigDecimal(2, musteriNo != null && !"".equals(musteriNo) ?  new BigDecimal(musteriNo) : null);
                stmt.setBigDecimal(3, urunGrupKodu != null && !"".equals(urunGrupKodu) ?  new BigDecimal(urunGrupKodu) : null);
                stmt.setBigDecimal(4, donemYili != null && !"".equals(donemYili) ?  new BigDecimal(donemYili) : null);
                stmt.setBigDecimal(5, donemKodu != null && !"".equals(donemKodu) ?  new BigDecimal(donemKodu) : null);
                stmt.execute();
                rSet = (ResultSet) stmt.getObject(1);
                oMap.putAll(DALUtil.rSetResults(rSet, "DONEMSEL_DURUM"));
            }
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY1198_GET_YEARS")
	public static GMMap getYears(GMMap iMap){
		try{
	        GMMap oMap = new GMMap();
	        int firstYear = iMap.getInt("FIRST_YEAR");
	        int lastYear = iMap.getInt("FIRST_YEAR");
	        
	        if(firstYear < 1900)
	        	firstYear = 2014;
	        
	        if(lastYear < 1900)
	        	lastYear = 2050;
	        
	        for(;firstYear <= lastYear; firstYear++){
	        	GuimlUtil.wrapMyCombo(oMap, "YEARS", String.valueOf(firstYear), String.valueOf(firstYear));
	        }	        
	        oMap.put("CURRENT_YEAR", String.valueOf(Calendar.getInstance().get(Calendar.YEAR)));
	        
	        return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		}
	}
}
