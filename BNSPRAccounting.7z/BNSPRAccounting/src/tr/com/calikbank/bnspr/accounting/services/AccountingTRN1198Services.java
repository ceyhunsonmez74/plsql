package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MuhStopajOranlari;
import tr.com.aktifbank.bnspr.dao.MuhStopajOranlariTx;
import tr.com.aktifbank.bnspr.dao.MuhStopajOranlariTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

@SuppressWarnings({ "unchecked" })
public class AccountingTRN1198Services {
    
    @GraymoundService("BNSPR_TRN1198_FILL_COMBOBOX")
    public static GMMap fillCombobox(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            
            /* ** Islem Kanali ** */
            DALUtil.fillComboBox(oMap , "ISLEM_KANALI" , false , "select '-1' kod,'Hepsi' aciklama from dual union select KOD, ACIKLAMA from v_ml_gnl_kanal_grup_kod_pr where KOD in (1,4,5,6,7,10)");
            
           
            
            iMap.put("KOD", "STOPAJ_URUN_GRUPLARI");
			iMap.put("ADD_EMPTY_KEY", "E");
			oMap.put("URUN",GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
                   
            
            /* ** anon�m ** */
            oMap.put("ANONIM" , 0 , "NAME" , "HEPSI");
            oMap.put("ANONIM" , 0 , "VALUE" , "H");
            
            oMap.put("ANONIM" , 1 , "NAME" , "Evet");
            oMap.put("ANONIM" , 1 , "VALUE" , "E");
            
            /* ** Yurti�iD��� ** */
            oMap.put("YURTICI_DISI" , 0 , "NAME" , "HEPSI");
            oMap.put("YURTICI_DISI" , 0 , "VALUE" , "H");
            
            oMap.put("YURTICI_DISI" , 1 , "NAME" , "Yurt ��i (I)");
            oMap.put("YURTICI_DISI" , 1 , "VALUE" , "I");
            
            oMap.put("YURTICI_DISI" , 2 , "NAME" , "Yurt D��� (D)");
            oMap.put("YURTICI_DISI" , 2 , "VALUE" , "D");
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN1198_INITIALIZE")
    public static GMMap initiazlize(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call Pkg_TRN1198.Stopaj_Oran_Listesi_1198(?,?)}");
            
            int parameterIndex = 1;
            stmt.registerOutParameter(parameterIndex++ , -10);
            stmt.setString(parameterIndex++ , iMap.getString(""));
            stmt.setString(parameterIndex++ , iMap.getString(""));
 
            
            stmt.execute();
            String tn = "STOPAJ_ORAN_LIST";
            
            rSet = (ResultSet) stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet , tn);
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN1198_FAIZ_ORAN_SORGULA")
    public static GMMap faizOranSorgula(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call Pkg_TRN1198.Stopaj_Oran_Listesi_1198(?,?)}");
            
            int parameterIndex = 1;
            
            
            stmt.registerOutParameter(parameterIndex++ , -10);
            stmt.setString(parameterIndex++ , iMap.getString("MUSTERI_TUR"));
            stmt.setString(parameterIndex++ , iMap.getString("URUN"));
            
            stmt.execute();
            String tn = "STOPAJ_ORAN";
            
            rSet = (ResultSet) stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet , tn);
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN1198_SAVE")
    public static GMMap save(GMMap iMap) {
        try{
            
            Session session = DAOSession.getSession("BNSPRDal");
            
            BigDecimal trxNo = iMap.getBigDecimal("TRX_NO");
            
            int i = 0;
            String tn = "STOPAJ_ORAN";
            
            while (i < iMap.getSize(tn)){
                
            	MuhStopajOranlariTx muhStopajOranlariTx = new MuhStopajOranlariTx();
                
                MuhStopajOranlariTxId muhStopajOranlariTxId = new MuhStopajOranlariTxId();
                
                
                muhStopajOranlariTxId.setTxNo(trxNo);
                muhStopajOranlariTxId.setAnonim(iMap.getString(tn , i , "ANONIM"));
               
                
                muhStopajOranlariTxId.setMusteriStat1(iMap.getString(tn , i , "MUSTERI_STAT1"));
               
                muhStopajOranlariTxId.setMusteriStat2(iMap.getString(tn , i , "MUSTERI_STAT2"));
                muhStopajOranlariTxId.setMusteriStat3(iMap.getString(tn , i , "MUSTERI_STAT3"));
                muhStopajOranlariTxId.setMusteriTurKod(iMap.getString(tn , i , "MUSTERI_TUR_KOD"));
                muhStopajOranlariTxId.setUrun(iMap.getString(tn , i , "URUN"));
                muhStopajOranlariTxId.setYurtIciDisi(iMap.getString(tn , i , "YURT_ICI_DISI"));
                muhStopajOranlariTx.setAciklama(iMap.getString(tn , i , "ACIKLAMA"));
                muhStopajOranlariTx.setOran(iMap.getBigDecimal(tn , i , "ORAN"));
             
                muhStopajOranlariTx.setSilindi(iMap.getBoolean(tn , i , "SIL") == false ? "H" : "E");
                
                muhStopajOranlariTx.setId(muhStopajOranlariTxId);
                muhStopajOranlariTx.setVergiOranId(iMap.getBigDecimal(tn,i,"VERGI_ORAN_ID"));
                
                session.saveOrUpdate(muhStopajOranlariTx);
                
                i++;
                
            }
            session.flush();
            
            iMap.put("TRX_NAME" , iMap.getString("EKRAN_NO"));
            return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN1198_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            
            List<MuhStopajOranlariTx> bbtTMP =(List<MuhStopajOranlariTx>)
                    session.createCriteria(MuhStopajOranlariTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
           
            int i = 0;
            String tableName = "BONO_FAIZ_ORAN";
            for (MuhStopajOranlariTx bb : bbtTMP){
                
                oMap.put(tableName , i , "ANONIM" , bb.getId().getAnonim());
                oMap.put(tableName , i , "MUSTERI_STAT1" , bb.getId().getMusteriStat1());
                oMap.put(tableName , i , "MUSTERI_STAT2" , bb.getId().getMusteriStat2());
                oMap.put(tableName , i , "MUSTERI_STAT3" , bb.getId().getMusteriStat3());
                oMap.put(tableName , i , "MUSTERI_TUR_KOD" , bb.getId().getMusteriTurKod());
                oMap.put(tableName , i , "ORAN" , bb.getOran());
                oMap.put(tableName , i , "URUN" , bb.getId().getUrun());
                oMap.put(tableName , i , "VERGI_ORAN_ID" , bb.getVergiOranId());
                oMap.put(tableName , i , "YURT_ICI_DISI" , bb.getId().getYurtIciDisi());
                oMap.put(tableName , i , "ACIKLAMA" , bb.getAciklama());
 
                oMap.put(tableName , i , "SIL" , bb.getSilindi());
                if (bb.getSilindi().equals("E")){
                    oMap.put(tableName , i , "SIL" , true);
                }
                i++;
            }
            
            List<MuhStopajOranlari> bbtTMPOld = session.createCriteria(MuhStopajOranlari.class).list();
            
            String oldTableName = "BONO_FAIZ_ORAN_OLD";
            
            // for (MenAlimSatimFaizleri bb : bbtTMPOld) {
            for (i = 0; i < bbtTMPOld.size(); i++){
            	
            	MuhStopajOranlari bb = bbtTMPOld.get(i);
            	
                oMap.put(oldTableName , i , "ANONIM" , bb.getId().getAnonim());
                oMap.put(oldTableName , i , "MUSTERI_STAT1" , bb.getId().getMusteriStat1());
                oMap.put(oldTableName , i , "MUSTERI_STAT2" , bb.getId().getMusteriStat2());
                oMap.put(oldTableName , i , "MUSTERI_STAT3" , bb.getId().getMusteriStat3());
                oMap.put(oldTableName , i , "MUSTERI_TUR_KOD" , bb.getId().getMusteriTurKod());
                oMap.put(oldTableName , i , "ORAN" , bb.getId().getOran());
                oMap.put(oldTableName , i , "URUN" , bb.getId().getUrun());
                oMap.put(oldTableName , i , "VERGI_ORAN_ID" , bb.getId().getVergiOranId());
                oMap.put(oldTableName , i , "YURT_ICI_DISI" , bb.getId().getYurtIciDisi());
                oMap.put(oldTableName , i , "ACIKLAMA" , bb.getId().getAciklama());
                oMap.put(oldTableName , i , "SIL" , bb.getId().getSilindi());
            }
            
            ArrayList<String> str = new ArrayList<String>();
            
            str.add("ANONIM");
            str.add("MUSTERI_STAT1");
            str.add("MUSTERI_STAT2");
            str.add("MUSTERI_STAT3");
            str.add("MUSTERI_TUR_KOD");
            str.add("ORAN");
            str.add("URUN");
            str.add("VERGI_ORAN_ID");
            str.add("YURT_ICI_DISI");
            str.add("SIL");
            str.add("ACIKLAMA");
            
            oMap.putAll(BeanSetProperties.tableDifferenceWithPropertiesColumn((ArrayList<?>) oMap.get(oldTableName) , (ArrayList<?>) oMap.get(tableName) , str));
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
}
