package tr.com.calikbank.bnspr.accounting.services;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class AccountingQRY1161Services {
	@GraymoundService("BNSPR_QRY1161_GET_MASRAF_KOMISYON_LIST")
	public static GMMap getMasrafKomisyonList(GMMap iMap) throws ParseException{
		
		try{
						/*pc_kanalnumara varchar2,pd_bastarih date,pd_sontarih date,pn_musterino number,
            pc_maskomturu varchar2,pc_kayitturu varchar2, pn_ilktutar number, pn_sontutar number,
            pc_durum varchar2, pc_tahsilatdurum varchar2,pc_hesaplanan0 varchar2*/
			
			Object[] objArray = new Object[22];
			objArray[0]=BnsprType.STRING;
			objArray[1]=iMap.getString("KANAL_NUMARA");
			objArray[2]=BnsprType.DATE;
			if(iMap.get("BAS_TARIH")!=null)
				objArray[3]=new Date(iMap.getDate("BAS_TARIH").getTime());
			else 
				objArray[3]=null;
			
			objArray[4]=BnsprType.DATE;
			if(iMap.get("SON_TARIH")!=null)
				objArray[5]=new Date(iMap.getDate("SON_TARIH").getTime());
			else 
				objArray[5]=null;
			
			objArray[6]=BnsprType.NUMBER;
			objArray[7]=iMap.getBigDecimal("MUSTERI_NO");
			
			objArray[8]=BnsprType.STRING;
			objArray[9]=iMap.getString("MASKOM_TURU");
			objArray[10]=BnsprType.STRING;
			objArray[11]=iMap.getString("KAYIT_TURU");
			
			objArray[12]=BnsprType.NUMBER;
			objArray[13]=iMap.getBigDecimal("ILK_TUTAR");
			objArray[14]=BnsprType.NUMBER;
			objArray[15]= iMap.getBigDecimal("SON_TUTAR");
			
			objArray[16]=BnsprType.STRING;
			objArray[17]=iMap.getString("DURUM");
			objArray[18]=BnsprType.STRING;
			objArray[19]=iMap.getString("TAHSILAT_DURUM");
			
			objArray[20]=BnsprType.STRING;
			objArray[21]=new Boolean(iMap.getBoolean("HESAPLANAN_0")).toString();
			String func="{? = call pkg_rc_accounting.RC_QRY1161_GET_MSRF_KMSYN_LST(?,?,?,?,?,?,?,?,?,?,?) }";
			GMMap oMap2 = new GMMap();
			oMap2= DALUtil.callOracleRefCursorFunction(func, "TABLO", objArray);
			
			String tableName = "MASRAF_KOMISYON_TAHSILAT";

			GMMap oMap = new GMMap();

			int row = 0;
			for (int i = 0; i < oMap2.getSize("TABLO"); i++) {
			
				oMap.put(tableName, row, "KANAL_NUMARA",oMap2.getString("TABLO",i,"KANAL_NUMARA"));
				oMap.put(tableName, row, "AMIR_SUBE_KOD",oMap2.getString("TABLO",i,"AMIR_SUBE_KOD"));
				oMap.put(tableName, row, "KAYIT_TARIHI",oMap2.getDate("TABLO",i,"KAYIT_TARIH"));
				oMap.put(tableName, row, "ISLEM_KOD",oMap2.getString("TABLO",i,"ISLEM_KOD"));
				oMap.put(tableName, row, "ACIKLAMA",oMap2.getString("TABLO",i,"ACIKLAMA"));
				oMap.put(tableName, row, "MUSTERI_NO",oMap2.getString("TABLO",i,"MUSTERI_NO"));
				oMap.put(tableName, row, "HESAP_NO",oMap2.getString("TABLO",i,"HESAP_NO"));
				oMap.put(tableName, row, "UNVAN",oMap2.getString("TABLO",i,"UNVAN"));
				oMap.put(tableName, row, "ISLEM_TUTARI",oMap2.getString("TABLO",i,"ISLEM_TUTARI"));
				oMap.put(tableName, row, "ISLEM_DOVIZ",oMap2.getString("TABLO",i,"DOVIZ_KOD"));
				oMap.put(tableName, row, "MASRAF_KODU",oMap2.getString("TABLO",i,"MASRAF_KODU"));
				oMap.put(tableName, row, "MK_ACIKLAMA",oMap2.getString("TABLO",i,"M_K_ACIKLAMA"));
				oMap.put(tableName, row, "HESAPLANAN",oMap2.getString("TABLO",i,"HESAPLANAN"));
				oMap.put(tableName, row, "ALINAN",oMap2.getString("TABLO",i,"ALINAN"));
				oMap.put(tableName, row, "H_A_DOVIZ",oMap2.getString("TABLO",i,"DVZ"));
				oMap.put(tableName, row, "DURUM",oMap2.getString("TABLO",i,"DURUM"));
				oMap.put(tableName, row, "FIS_NUMARA",oMap2.getString("TABLO",i,"FIS_NUMARA"));

				row++;
			}


			return oMap;

		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY1161_GET_MASRAF_TOPLAM")
	public static GMMap GetMasrafToplam(GMMap iMap)throws ParseException{
		try{
			Object[] objArray = new Object[22];
			objArray[0]=BnsprType.STRING;
			objArray[1]=iMap.getString("KANAL_NUMARA");
			objArray[2]=BnsprType.DATE;
			if(iMap.get("BAS_TARIH")!=null)
				objArray[3]=new Date(iMap.getDate("BAS_TARIH").getTime());
			else 
				objArray[3]=null;
			
			objArray[4]=BnsprType.DATE;
			if(iMap.get("SON_TARIH")!=null)
				objArray[5]=new Date(iMap.getDate("SON_TARIH").getTime());
			else 
				objArray[5]=null;
			
			objArray[6]=BnsprType.NUMBER;
			objArray[7]=iMap.getBigDecimal("MUSTERI_NO");
			
			objArray[8]=BnsprType.STRING;
			objArray[9]=iMap.getString("MASKOM_TURU");
			objArray[10]=BnsprType.STRING;
			objArray[11]=iMap.getString("KAYIT_TURU");
			
			objArray[12]=BnsprType.NUMBER;
			objArray[13]=iMap.getBigDecimal("ILK_TUTAR");
			objArray[14]=BnsprType.NUMBER;
			objArray[15]= iMap.getBigDecimal("SON_TUTAR");
			
			objArray[16]=BnsprType.STRING;
			objArray[17]=iMap.getString("DURUM");
			objArray[18]=BnsprType.STRING;
			objArray[19]=iMap.getString("TAHSILAT_DURUM");
			
			objArray[20]=BnsprType.STRING;
			objArray[21]=new Boolean(iMap.getBoolean("HESAPLANAN_0")).toString();
			String func="{? = call pkg_rc_accounting.RC_QRY1161_GET_MASRAF_TOPLAM(?,?,?,?,?,?,?,?,?,?,?)}";
			GMMap oMap2 = new GMMap();
			oMap2= DALUtil.callOracleRefCursorFunction(func, "TABLO", objArray);
			
			String tableName = "RESULTS";
			GMMap oMap = new GMMap();

			int row = 0;
			for (int i = 0; i < oMap2.getSize("TABLO"); i++) {
			
				oMap.put(tableName, row, "KAYIT_SAYISI",oMap2.getBigDecimal("TABLO",i,"KAYIT_SAYISI"));
				oMap.put(tableName, row, "HESAPLANAN",oMap2.getBigDecimal("TABLO",i,"HESAPLANAN"));
				oMap.put(tableName, row, "ALINAN",oMap2.getBigDecimal("TABLO",i,"ALINAN"));
				oMap.put(tableName, row, "DVZ",oMap2.getString("TABLO",i,"DVZ"));
				row++;
			}
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);			
		}
	}
}


