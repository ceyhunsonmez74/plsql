package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class AccountingQRY1129Services {


	@GraymoundService("BNSPR_QRY1129_GET_OZEL_KARSILIK_FIS")
	public static GMMap getDetay(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc1129.OzelKarsilikFis(?,?,?,?,?)}");	
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("TAKIP_HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			
			if (iMap.getBoolean("TERS_FIS_EH") == false) {
				stmt.setString(i++, "H");
			}
			else {
				stmt.setString(i++, "E");
			}

			stmt.setDate(i++, new Date(iMap.getDate("TARIH_BAS").getTime()));
			stmt.setDate(i++, new Date(iMap.getDate("TARIH_SON").getTime()));
			
			stmt.execute();
			String tableName = "OZEL_KARSILIK_FIS";
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			
			int j = 0;
			while (rSet.next()) {		
				oMap.put(tableName, j, "TAKIP_HESAP_NO", rSet.getString("TAKIP_HESAP_NO"));
                oMap.put(tableName, j, "TAKIP_HESAP_DK", rSet.getString("TAKIP_HESAP_DK"));
                oMap.put(tableName, j, "TAKIP_BAKIYE", rSet.getBigDecimal("TAKIP_BAKIYE"));
                oMap.put(tableName, j, "TEMINAT_TUTAR", rSet.getBigDecimal("TEMINAT_TUTAR"));
                oMap.put(tableName, j, "ATANMIS_MASRAF_TUTAR", rSet.getBigDecimal("ATANMIS_MASRAF_TUTAR"));
                oMap.put(tableName, j, "OZEL_KARSILIK_TUTAR", rSet.getBigDecimal("OZEL_KARSILIK_TUTAR"));
                oMap.put(tableName, j, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
                oMap.put(tableName, j, "TX_NO", rSet.getString("TX_NO"));
                oMap.put(tableName, j, "UNVAN", DALUtil.callOneParameterFunction(
                								"{? = call pkg_musteri.unvan(?)}", Types.VARCHAR, rSet.getBigDecimal("MUSTERI_NO")));
				j++ ;
			}

			return oMap;
		} catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
	  
    @GraymoundService("BNSPR_QRY1129_GET_OZEL_KARSILIK_FIS_DETAY")
    public static GMMap getListAlt(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
        	conn = DALUtil.getGMConnection();
        	stmt = conn.prepareCall("{? = call pkg_rc1129.OzelKarsilikFisDetay(?)}");

            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setBigDecimal(i++, iMap.getBigDecimal("TX_NO"));
            
            stmt.execute();
            String tableName = "OZEL_KARSILIK_FIS_DETAY";
            
            rSet = (ResultSet) stmt.getObject(1);
            GMMap oMap = new GMMap();
        
            int j=0;
            while (rSet.next()) {
                oMap.put(tableName, j, "TAKIP_HESAP_NO", rSet.getString("TAKIP_HESAP_NO"));
                oMap.put(tableName, j, "TAKIP_HESAP_DK", rSet.getString("TAKIP_HESAP_DK"));
                oMap.put(tableName, j, "TAKIP_BAKIYE", rSet.getBigDecimal("TAKIP_BAKIYE"));
                oMap.put(tableName, j, "TEMINAT_TUTAR", rSet.getBigDecimal("TEMINAT_TUTAR"));
                oMap.put(tableName, j, "ATANMIS_MASRAF_TUTAR", rSet.getBigDecimal("ATANMIS_MASRAF_TUTAR"));
                oMap.put(tableName, j, "OZEL_KARSILIK_TUTAR", rSet.getBigDecimal("OZEL_KARSILIK_TUTAR"));
                oMap.put(tableName, j, "MUSTERI_NO", rSet.getString("MUSTERI_NO"));
                j++;
            }

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
}				 
