package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Date;
import java.text.DateFormat;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingQRY1116Services {
	
	@GraymoundService("BNSPR_QRY1116_GET_INITIAL_VALUES")
	public static GMMap initialize(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			iMap.put("KOD", "MALI_DONEM");
			iMap.put("TABLE_NAME", "AY");
			oMap.putAll(GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap));
			
			Calendar today = Calendar.getInstance();
			today.setTime(new Date());
			
			oMap.put("SU_ANKI_AY", today.get(Calendar.MONTH)+1);
			oMap.put("SU_ANKI_YIL", today.get(Calendar.YEAR));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}
	
	@GraymoundService("BNSPR_QRY1116_ORTALAMA_MIZAN_LIST")
	public static GMMap getList(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		try {
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_ACCOUNTING.RC_QRY1116_ORTALAMA_MIZAN(?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("SUBE_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("AY"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("YIL"));
			if(iMap.get("TAR1")!=null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("TAR1").getTime()));
			else 
				stmt.setDate(i++, null);
			
			if(iMap.get("TAR2")!=null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("TAR2").getTime()));
			else 
				stmt.setDate(i++, null);
			
			stmt.setString(i++, iMap.getString("RAPOR_TIPI"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, "ORTALAMA_MIZAN_LIST"));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}		
	}
	
}
