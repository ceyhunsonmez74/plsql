package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class AccountingQRY1119Services {

	@GraymoundService("BNSPR_QRY1119_GET")
	public static GMMap getFisNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String tableName;

		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			int i=1;
			int var;
			stmt = conn.prepareCall("{? = call PKG_TRN1119.RC_QRY1119_GET_ISLEM_LIST(?,?,?,?,?)}");

			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("SUBE_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIS_NO"));
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("SON_TARIH").getTime()));
			stmt.setBigDecimal(i++ , iMap.getBigDecimal("GUNC_ISTEYEN_BOLM"));
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);
			tableName = "tblISLEM" ; 
			var = 0 ;

			while(rSet.next()){
				oMap.put(tableName,var,"ISLEM_NUMARA"				, rSet.getString("islem_no"));
				oMap.put(tableName,var,"FIS_NO"						, rSet.getString("fis_No"));
				oMap.put(tableName,var,"MUSTRIACIKLAMA"				, rSet.getString("aciklama_musteri"));
				oMap.put(tableName,var,"BANKACIKLAMA"				, rSet.getString("aciklama_banka"));
				oMap.put(tableName,var,"MUSTERI_NO" 				, rSet.getString("MUSTERI_NO"));
				oMap.put(tableName,var,"UNVAN"						, rSet.getString("UNVAN"));
				oMap.put(tableName,var,"GUNCELLEMETARIH"			, rSet.getDate("guncelleme_tarihi"));
				oMap.put(tableName,var,"ISLEMTARIH"					, rSet.getDate("satir_yaratildigi_tarih"));
				oMap.put(tableName,var,"TUTAR"						, rSet.getString("satir_lc_tutar"));				
				oMap.put(tableName,var,"DOVIZKODU"					, rSet.getString("satir_doviz_kod"));
				oMap.put(tableName,var,"SUBE_KOD"					, rSet.getString("sube_kodu"));
				oMap.put(tableName,var,"KANAL"						, rSet.getString("kanal_numara"));
				oMap.put(tableName,var,"MUSTERI_ACIKLAMA"	 		, rSet.getString("aciklama_musteri_eski"));
				oMap.put(tableName,var,"BANKA_ACIKLAMA"				, rSet.getString("aciklama_banka_eski"));
				oMap.put(tableName,var,"GUNCELLEME_KULL"			, rSet.getString("guncellemeyi_yapan_kull") +", "+ rSet.getShort("guncelleyen_ad_soyad"));
				oMap.put(tableName,var,"GUNCELLEME_ONAY"			, rSet.getString("guncellemeyi_onaylayan_kull"));
				oMap.put(tableName,var,"GUNC_ISTEYEN_BOLM"          , rSet.getString("guncelleyen_bolum"));
				var++;
			}
			if(oMap.isEmpty())
			{
				oMap.put("RESPONSE", "2");
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}		
}
