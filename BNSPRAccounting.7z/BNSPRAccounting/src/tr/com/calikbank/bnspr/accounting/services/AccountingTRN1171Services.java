package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.DetachedCriteria;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.criterion.Subqueries;

import tr.com.aktifbank.bnspr.dao.VostroMasrafKomisyonPr;
import tr.com.aktifbank.bnspr.dao.VostroMasrafKomisyonPrTx;
import tr.com.aktifbank.bnspr.dao.VostroMasrafKomisyonPrTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1171Services {
    
    @GraymoundService("BNSPR_TRN1171_VIEW")
    public static GMMap viewIslem(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap oMapOld = new GMMap();
        List<BigDecimal> idList = new ArrayList<BigDecimal>();
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            Criteria criteria = session.createCriteria(VostroMasrafKomisyonPrTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO")));
            criteria.addOrder(Order.desc("id.id"));

            List<?> list = criteria.list();
            String tableName = "MASKOM_LIST";
            int row = 0;
            for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
                VostroMasrafKomisyonPrTx maskom = (VostroMasrafKomisyonPrTx)iterator.next();
                oMap.put(tableName , row , "ID" , maskom.getId().getId());
                oMap.put(tableName , row , "ISLEM_TIPI" , maskom.getIslemTipi());
                oMap.put(tableName , row , "MUSTERI_NO" , maskom.getMusteriNo());
                oMap.put(tableName , row , "UNVAN" , (String)DALUtil.callOneParameterFunction("{? = call PKG_MUSTERI.unvan(?)}", Types.VARCHAR, maskom.getMusteriNo()));
                oMap.put(tableName , row , "HESAP_NO" , maskom.getHesapNo());
                oMap.put(tableName , row , "DOVIZ_KODU" , maskom.getDovizKodu());
                oMap.put(tableName , row , "BASLANGIC_TUTAR" , maskom.getBaslangicTutar());
                oMap.put(tableName , row , "BITIS_TUTAR" , maskom.getBitisTutar());
                oMap.put(tableName , row , "MASRAF" , maskom.getMasraf());
                oMap.put(tableName , row , "KOMISYON" , maskom.getKomisyon());
                oMap.put(tableName , row , "MIN_TUTAR" , maskom.getMinTutar());
                oMap.put(tableName , row , "MAX_TUTAR" , maskom.getMaxTutar());
                oMap.put(tableName , row , "PERIYOT" , maskom.getPeriyot());
                oMap.put(tableName , row , "MASRAF_KRITER" , maskom.getMasrafKriter());
                oMap.put(tableName , row , "DEL" , maskom.getGds().equals("S") ? true : false);
                idList.add(maskom.getId().getId());
                row++;
            }
            
            
            DetachedCriteria subCriteria = DetachedCriteria
                    .forClass(VostroMasrafKomisyonPrTx.class);
            subCriteria.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")));
            subCriteria.setProjection(Projections.property("id.id"));

            criteria = session.createCriteria(VostroMasrafKomisyonPr.class);
            
            criteria.add(Subqueries.propertyIn("id", subCriteria));
 
            List<?> listOld = criteria.list();
            ArrayList<String> columnList = new ArrayList<String>();
            columnList.add("ID");columnList.add("ISLEM_TIPI");columnList.add("MUSTERI_NO");columnList.add("UNVAN");
            columnList.add("HESAP_NO");columnList.add("DOVIZ_KODU");columnList.add("BASLANGIC_TUTAR");columnList.add("BITIS_TUTAR");
            columnList.add("MASRAF");columnList.add("KOMISYON");columnList.add("MIN_TUTAR");columnList.add("MAX_TUTAR");
            columnList.add("PERIYOT");columnList.add("MASRAF_KRITER");columnList.add("DEL");
            String tableNameOld = "MASKOM_LIST_OLD";
            row = 0;
            for (Iterator<?> iterator = listOld.iterator(); iterator.hasNext();){
                VostroMasrafKomisyonPr maskom = (VostroMasrafKomisyonPr)iterator.next();
                oMapOld.put(tableNameOld , row , "ID" , maskom.getId());
                oMapOld.put(tableNameOld , row , "ISLEM_TIPI" , maskom.getIslemTipi());
                oMapOld.put(tableNameOld , row , "MUSTERI_NO" , maskom.getMusteriNo());
                oMapOld.put(tableNameOld , row , "UNVAN" , (String)DALUtil.callOneParameterFunction("{? = call PKG_MUSTERI.unvan(?)}", Types.VARCHAR, maskom.getMusteriNo()));
                oMapOld.put(tableNameOld , row , "HESAP_NO" , maskom.getHesapNo());
                oMapOld.put(tableNameOld , row , "DOVIZ_KODU" , maskom.getDovizKodu());
                oMapOld.put(tableNameOld , row , "BASLANGIC_TUTAR" , maskom.getBaslangicTutar());
                oMapOld.put(tableNameOld , row , "BITIS_TUTAR" , maskom.getBitisTutar());
                oMapOld.put(tableNameOld , row , "MASRAF" , maskom.getMasraf());
                oMapOld.put(tableNameOld , row , "KOMISYON" , maskom.getKomisyon());
                oMapOld.put(tableNameOld , row , "MIN_TUTAR" , maskom.getMinTutar());
                oMapOld.put(tableNameOld , row , "MAX_TUTAR" , maskom.getMaxTutar());
                oMapOld.put(tableNameOld , row , "PERIYOT" , maskom.getPeriyot());
                oMapOld.put(tableNameOld , row , "MASRAF_KRITER" , maskom.getMasrafKriter());
                oMapOld.put(tableNameOld , row , "DEL" , false);
                row++;
            }
            
            oMap.put("COLOR" , BeanSetProperties.tableDifference((ArrayList<?>) oMapOld.get(tableNameOld),(ArrayList<?>) oMap.get(tableName), columnList).get("COLOR_DATA"));
            
            return oMap;
        } 
        catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }        
    }
    
    @GraymoundService("BNSPR_TRN1171_LIST")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            Criteria criteria = session.createCriteria(VostroMasrafKomisyonPr.class);
            if (iMap.getBigDecimal("MUSTERI_NO") != null){
                criteria = criteria.add(Restrictions.eq("musteriNo" , iMap.getBigDecimal("MUSTERI_NO")));
            }
            if (iMap.getBigDecimal("HESAP_NO") != null){
                criteria = criteria.add(Restrictions.eq("hesapNo" , iMap.getBigDecimal("HESAP_NO")));
            }
            if (!isNullOrEmpty(iMap.getString("DVZ"))){
                criteria = criteria.add(Restrictions.eq("dovizKodu" , iMap.getString("DVZ")));
            }
            if (!isNullOrEmpty(iMap.getString("ISLEM_TIPI"))){
                criteria = criteria.add(Restrictions.eq("islemTipi" , iMap.getString("ISLEM_TIPI")));
            }
            if (!isNullOrEmpty(iMap.getString("MASRAF_PERIYOT"))){
                criteria = criteria.add(Restrictions.eq("periyot" , iMap.getString("MASRAF_PERIYOT")));
            }
            criteria.addOrder(Order.desc("id"));

            List<?> list = criteria.list();
            String tableName = "MASKOM_LIST";
            int row = 0;
            for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
                VostroMasrafKomisyonPr maskom = (VostroMasrafKomisyonPr)iterator.next();
                oMap.put(tableName , row , "ID" , maskom.getId());
                oMap.put(tableName , row , "ISLEM_TIPI" , maskom.getIslemTipi());
                oMap.put(tableName , row , "MUSTERI_NO" , maskom.getMusteriNo());
                oMap.put(tableName , row , "UNVAN" , (String)DALUtil.callOneParameterFunction("{? = call PKG_MUSTERI.unvan(?)}", Types.VARCHAR, maskom.getMusteriNo()));
                oMap.put(tableName , row , "HESAP_NO" , maskom.getHesapNo());
                oMap.put(tableName , row , "DOVIZ_KODU" , maskom.getDovizKodu());
                oMap.put(tableName , row , "BASLANGIC_TUTAR" , maskom.getBaslangicTutar());
                oMap.put(tableName , row , "BITIS_TUTAR" , maskom.getBitisTutar());
                oMap.put(tableName , row , "MASRAF" , maskom.getMasraf());
                oMap.put(tableName , row , "KOMISYON" , maskom.getKomisyon());
                oMap.put(tableName , row , "MIN_TUTAR" , maskom.getMinTutar());
                oMap.put(tableName , row , "MAX_TUTAR" , maskom.getMaxTutar());
                oMap.put(tableName , row , "PERIYOT" , maskom.getPeriyot());
                oMap.put(tableName , row , "MASRAF_KRITER" , maskom.getMasrafKriter());
                row++;
            }
            return oMap;
        } 
        catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }        
    }
    
    @GraymoundService("BNSPR_TRN1171_SAVE")
    public static Map<?, ?> save(GMMap iMap) {
        try{
            validateFields(iMap);
            
            Session session = DAOSession.getSession("BNSPRDal");
            String tableName = "MASKOM_LIST";
            List<?> list = (List<?>) iMap.get(tableName);
            for (int i = 0; i < list.size(); i++){
                VostroMasrafKomisyonPrTxId id = new VostroMasrafKomisyonPrTxId();
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                id.setId(iMap.getBigDecimal(tableName , i , "ID"));
                VostroMasrafKomisyonPrTx komisyonPrTx = new VostroMasrafKomisyonPrTx();
                komisyonPrTx.setId(id);
                komisyonPrTx.setIslemTipi(iMap.getString(tableName , i , "ISLEM_TIPI"));
                komisyonPrTx.setMusteriNo(iMap.getBigDecimal(tableName , i , "MUSTERI_NO"));
                komisyonPrTx.setHesapNo(iMap.getBigDecimal(tableName , i , "HESAP_NO"));
                komisyonPrTx.setDovizKodu(iMap.getString(tableName , i , "DOVIZ_KODU"));
                komisyonPrTx.setBaslangicTutar(iMap.getBigDecimal(tableName , i , "BASLANGIC_TUTAR"));
                komisyonPrTx.setBitisTutar(iMap.getBigDecimal(tableName , i , "BITIS_TUTAR"));
                komisyonPrTx.setMasraf(iMap.getBigDecimal(tableName , i , "MASRAF"));
                komisyonPrTx.setKomisyon(iMap.getBigDecimal(tableName , i , "KOMISYON"));
                komisyonPrTx.setMinTutar(iMap.getBigDecimal(tableName , i , "MIN_TUTAR"));
                komisyonPrTx.setMaxTutar(iMap.getBigDecimal(tableName , i , "MAX_TUTAR"));
                komisyonPrTx.setPeriyot(iMap.getString(tableName , i , "PERIYOT"));
                komisyonPrTx.setMasrafKriter(iMap.getBigDecimal(tableName , i , "MASRAF_KRITER"));
                if (isNullOrEmpty(iMap.getString(tableName , i , "G_D_S"))){
                    komisyonPrTx.setGds("D");
                }
                else{
                    komisyonPrTx.setGds(iMap.getString(tableName , i , "G_D_S"));
                }
                
                session.saveOrUpdate(komisyonPrTx);
            }
            session.flush();
            iMap.put("TRX_NAME" , "1171");
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    private static void validateFields(GMMap iMap){
        Session session = null;
        String tableName = "MASKOM_LIST";
        if (iMap == null || iMap.get(tableName) == null){
            return;
        }
        if (iMap.getBigDecimal("TRX_NO") == null){
            AccountingChargesServices.throwGMBusssinessException("��lem No bo� olamaz.");
        }

        session = DAOSession.getSession("BNSPRDal");
        List<?> list = (List<?>) iMap.get(tableName);
        Map<String, List<VostroMasrafKomisyonPr>> keyMap = new HashMap<String, List<VostroMasrafKomisyonPr>>();
        Map<BigDecimal, VostroMasrafKomisyonPr> ekleMap = new HashMap<BigDecimal, VostroMasrafKomisyonPr>();
        Map<BigDecimal, VostroMasrafKomisyonPr> silMap = new HashMap<BigDecimal, VostroMasrafKomisyonPr>();
        Map<BigDecimal, VostroMasrafKomisyonPr> guncelleMap = new HashMap<BigDecimal, VostroMasrafKomisyonPr>();
        
        for (int i = 0; i < list.size(); i++){
            String sGDS = iMap.getString(tableName , i , "G_D_S");
            if (isNullOrEmpty(sGDS)){
                sGDS = "D";
            }
            if (!sGDS.equals("S")){  //G�R�� veya D�ZELTME ise
                if (iMap.getBigDecimal(tableName , i , "ID") == null){
                    AccountingChargesServices.throwGMBusssinessException((i + 1) + " nolu sat�rda hata: ID bilgisi bo� olamaz.");
                }
                if (isNullOrEmpty(iMap.getString(tableName , i , "ISLEM_TIPI"))){
                    AccountingChargesServices.throwGMBusssinessException( (i + 1) + " nolu sat�rda hata: ��LEM T�P� bilgisi bo� olamaz.");
                }
                if (isNullOrZero(iMap.getBigDecimal(tableName , i , "MUSTERI_NO"))){
                    AccountingChargesServices.throwGMBusssinessException((i + 1) + " nolu sat�rda hata: M��TER� NO bilgisi bo� olamaz.");
                }
                if (isNullOrZero(iMap.getBigDecimal(tableName , i , "HESAP_NO"))){
                    AccountingChargesServices.throwGMBusssinessException((i + 1) + " nolu sat�rda hata: HESAP NO bilgisi bo� olamaz");
                }
                if (isNullOrEmpty(iMap.getString(tableName , i , "DOVIZ_KODU"))){
                    AccountingChargesServices.throwGMBusssinessException( (i + 1) + " nolu sat�rda hata: D�V�Z KODU bilgisi bo� olamaz.");
                }
                if (iMap.getBigDecimal(tableName , i , "BASLANGIC_TUTAR") == null){
                    AccountingChargesServices.throwGMBusssinessException((i + 1) + " nolu sat�rda hata: BA�LANGI� TUTAR bilgisi bo� olamaz.");
                }
                if (iMap.getBigDecimal(tableName , i , "BITIS_TUTAR") == null){
                    AccountingChargesServices.throwGMBusssinessException((i + 1) + " nolu sat�rda hata: B�T�� TUTAR bilgisi bo� olamaz.");
                }
                if (iMap.getBigDecimal(tableName , i , "BASLANGIC_TUTAR").compareTo(iMap.getBigDecimal(tableName , i , "BITIS_TUTAR")) > 0){
                    AccountingChargesServices.throwGMBusssinessException((i + 1) + " nolu sat�rda hata: BA�LANGI� TUTAR, B�T�� TUTAR'dan b�y�k olamaz.");
                }
                if (iMap.getBigDecimal(tableName , i , "MASRAF") == null && iMap.getBigDecimal(tableName , i , "KOMISYON") == null){
                    AccountingChargesServices.throwGMBusssinessException((i + 1) + " nolu sat�rda hata:  MASRAF/KOM�SYON bilgilerinden birini giriniz.");
                }
                if (iMap.getBigDecimal(tableName , i , "MASRAF") != null && iMap.getBigDecimal(tableName , i , "KOMISYON") != null){
                    if (iMap.getBigDecimal(tableName , i , "MASRAF").doubleValue() == 0 && iMap.getBigDecimal(tableName , i , "KOMISYON").doubleValue() != 0){
                        Object objNull = null;
                        iMap.put(tableName , i , "MASRAF", (BigDecimal)objNull);
                    }
                    else if ( (iMap.getBigDecimal(tableName , i , "MASRAF").doubleValue() != 0 && iMap.getBigDecimal(tableName , i , "KOMISYON").doubleValue() == 0)
                            ||(iMap.getBigDecimal(tableName , i , "MASRAF").doubleValue() == 0 && iMap.getBigDecimal(tableName , i , "KOMISYON").doubleValue() == 0)){
                        Object objNull = null;
                        iMap.put(tableName , i , "KOMISYON", (BigDecimal)objNull);
                    }
                    else{
                        AccountingChargesServices.throwGMBusssinessException((i + 1) + " nolu sat�rda hata:  MASRAF/KOM�SYON bilgilerinden sadece birini girebilirsiniz");
                    }
                }
                if (isNullOrEmpty(iMap.getString(tableName , i , "PERIYOT"))){
                    AccountingChargesServices.throwGMBusssinessException((i + 1) + " nolu sat�rda hata: PER�YOT bilgisi bo� olamaz");
                }
                if (iMap.getBigDecimal(tableName , i , "MIN_TUTAR") != null && iMap.getBigDecimal(tableName , i , "MAX_TUTAR") != null){
                    if (iMap.getBigDecimal(tableName , i , "MIN_TUTAR").compareTo(iMap.getBigDecimal(tableName , i , "MAX_TUTAR")) > 0){
                        AccountingChargesServices.throwGMBusssinessException((i + 1) + " nolu sat�rda hata: MIN TUTAR, MAX TUTAR'dan b�y�k olamaz");
                    }
                }
                
                VostroMasrafKomisyonPr mk = new VostroMasrafKomisyonPr();
                mk.setId(iMap.getBigDecimal(tableName , i , "ID"));
                mk.setIslemTipi(iMap.getString(tableName , i , "ISLEM_TIPI"));
                mk.setMusteriNo(iMap.getBigDecimal(tableName , i , "MUSTERI_NO"));
                mk.setHesapNo(iMap.getBigDecimal(tableName , i , "HESAP_NO"));
                mk.setBaslangicTutar(iMap.getBigDecimal(tableName , i , "BASLANGIC_TUTAR"));
                mk.setBitisTutar(iMap.getBigDecimal(tableName , i , "BITIS_TUTAR"));
                
                if (sGDS.equals("G")){
                    ekleMap.put(mk.getId() , mk);
                }
                else{
                    guncelleMap.put(mk.getId() , mk);
                }
                
            }
            else{ //S�LME ise
                VostroMasrafKomisyonPr old = (VostroMasrafKomisyonPr)session.get(VostroMasrafKomisyonPr.class , iMap.getBigDecimal(tableName , i , "ID"));
                if (old == null){
                    AccountingChargesServices.throwGMBusssinessException( (i + 1) + " nolu sat�rda hata: Silinecek kay�t bulunamad�");
                }
                VostroMasrafKomisyonPr mk = new VostroMasrafKomisyonPr();
                mk.setId(old.getId());
                mk.setIslemTipi(old.getIslemTipi());
                mk.setMusteriNo(old.getMusteriNo());
                mk.setHesapNo(old.getHesapNo());
                silMap.put(mk.getId() , mk);
                
            }
        }

        for (BigDecimal bdId : ekleMap.keySet()){
            VostroMasrafKomisyonPr mk = ekleMap.get(bdId);
            String sPK = getPK(mk);
            if (keyMap.containsKey(sPK)){
                keyMap.get(sPK).add(mk);
            }
            else{
                List<VostroMasrafKomisyonPr> lID = new ArrayList<VostroMasrafKomisyonPr>();
                lID.add(mk);
                keyMap.put(sPK , lID);
            }
        }

        for (BigDecimal bdId : guncelleMap.keySet()){
            VostroMasrafKomisyonPr mk = guncelleMap.get(bdId);
            String sPK = getPK(mk);
            if (keyMap.containsKey(sPK)){
                keyMap.get(sPK).add(mk);
            }
            else{
                List<VostroMasrafKomisyonPr> lID = new ArrayList<VostroMasrafKomisyonPr>();
                lID.add(mk);
                keyMap.put(sPK , lID);
            }
        }
        
        for (String sPK : keyMap.keySet()){
            Criteria criteria = session.createCriteria(VostroMasrafKomisyonPr.class).
                    add(Restrictions.eq("islemTipi" , getFieldFromPK(sPK , 1))).
                    add(Restrictions.eq("musteriNo" , new BigDecimal(getFieldFromPK(sPK , 2)))).
                    add(Restrictions.eq("hesapNo" , new BigDecimal(getFieldFromPK(sPK , 3))));
            List<?> dbList = criteria.list();
            if (dbList != null){
                for (Iterator<?> iterator = dbList.iterator(); iterator.hasNext();){
                    VostroMasrafKomisyonPr dbMK = (VostroMasrafKomisyonPr)iterator.next();
                    if (!guncelleMap.containsKey(dbMK.getId())){
                        keyMap.get(sPK).add(dbMK);
                    }
                }
            }
            

        }
        
        for (BigDecimal bdId : silMap.keySet()){
            VostroMasrafKomisyonPr mk = silMap.get(bdId);
            String sPK = getPK(mk);
            if (keyMap.containsKey(sPK)){
                List<VostroMasrafKomisyonPr> tempList = keyMap.get(sPK);
                Iterator<VostroMasrafKomisyonPr> itrTemp = tempList.iterator();
                while (itrTemp.hasNext()){
                    VostroMasrafKomisyonPr tempMK = itrTemp.next();
                    if (bdId.setScale(0).compareTo(tempMK.getId().setScale(0)) == 0){
                        itrTemp.remove();
                    }
                }
            }
        }

        
        /*********************** Ekrandan gelen data gridde ayn� aral�kta masraf tan�m� var m� kontrol� **************************/
        if (keyMap.size()>0){
            for (String sKey : keyMap.keySet()){
                List<VostroMasrafKomisyonPr> masrafList = keyMap.get(sKey);
                if (masrafList != null && masrafList.size()>1){
                    Iterator<VostroMasrafKomisyonPr> itr1 = masrafList.iterator();
                    while (itr1.hasNext()){
                        VostroMasrafKomisyonPr masraf = itr1.next();
                        itr1.remove();
                        for (VostroMasrafKomisyonPr masraf2 : masrafList){
                            if (isOverlapping(masraf , masraf2)){
                                AccountingChargesServices.throwGMBusssinessException("Ba�lang�� - biti� tutar aral�klar� kesi�en kay�tlar var." + masraf2.getId().setScale(0)+ " ve " + masraf.getId().setScale(0)+ " ID'li kay�tlar� kontrol edip tekrar deneyiniz");
                            }
                        }
                    }
                }
            }
        }
        /**************************************************************************************************************************/
        
    }
    
    @GraymoundService("BNSPR_TRN1171_MASRAF_KOMISYON_GETIR")
    public static GMMap getMasrafKomisyon(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_TRN1171.MasrafKomisyonHesapla(?,?,?,?,?,?,?,?)}");
            
            stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setBigDecimal(2, iMap.getBigDecimal("HESAP_NO"));
            stmt.setString(3, iMap.getString("ISLEM_TIPI"));
            stmt.setBigDecimal(4, iMap.getBigDecimal("ISLEM_TUTARI"));
            stmt.setString(5, iMap.getString("ISLEM_DOVIZ"));
            stmt.registerOutParameter(6, Types.NUMERIC);
            if (!isNullOrEmpty(iMap.getString("MASRAF_DOVIZ"))){
                stmt.setString(7 , iMap.getString("MASRAF_DOVIZ"));
            }
            stmt.registerOutParameter(7, Types.VARCHAR);
            stmt.registerOutParameter(8, Types.VARCHAR);
            stmt.execute();
            
            oMap.put("MASRAF_TUTAR" , stmt.getBigDecimal(6));
            oMap.put("MASRAF_DOVIZ" , stmt.getString(7));
            oMap.put("MASRAF_PERIYOT" , stmt.getString(8));
            
            return oMap;
        } 
        catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    private static boolean isNullOrEmpty(String str){
        return str == null || str.equals("");
    }

    private static boolean isNullOrZero(BigDecimal bd){
        return bd == null || bd.doubleValue() == 0;
    }
    
    private static String getPK(VostroMasrafKomisyonPr mk){
        return mk.getIslemTipi() + ":" + mk.getMusteriNo().setScale(0).toString() + ":" + mk.getHesapNo().setScale(0).toString();
    }
    
    private static String getFieldFromPK(String sPk, int field){ //field: 1:i�lem tipi, 2:m��teri no, 3:hesap no
        if (field < 1 || field >3){
            return "";
        }
        String[] fields = sPk.split(":");
        if (fields != null && fields.length >= field){
            return fields[field - 1];                    
        }
        return "";
    }
    
    private static boolean isOverlapping(VostroMasrafKomisyonPr masraf1, VostroMasrafKomisyonPr masraf2){
        if (masraf1 == null || masraf2 == null){ 
            return false;
        }
        return (((masraf1.getBitisTutar() == null) || (masraf2.getBaslangicTutar() == null) || (masraf1.getBitisTutar().setScale(2).doubleValue() >= masraf2.getBaslangicTutar().setScale(2).doubleValue())) &&
                ((masraf1.getBaslangicTutar() == null) || (masraf2.getBitisTutar() == null) || (masraf1.getBaslangicTutar().setScale(2).doubleValue() <= masraf2.getBitisTutar().setScale(2).doubleValue())));
    }
}
