package tr.com.calikbank.bnspr.accounting.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types; //import java.sql.Types;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MuhFisSatirAckGuncTx;
import tr.com.aktifbank.bnspr.dao.MuhFisSatirAckGuncTxId;
import tr.com.aktifbank.bnspr.dao.MuhTersFisTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1119Services {
    
    @GraymoundService("BNSPR_TRN1119_GET_MUH_FIS_RECORD")
    public static GMMap getMuhFisRecord(GMMap iMap) throws ParseException {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try{
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call Pkg_genel_pr.islem_ekran_adi(?)}");
            stmt.registerOutParameter(1 , Types.VARCHAR); // ref cursor
            stmt.setBigDecimal(2 , iMap.getBigDecimal("ISLEM_NO"));
            stmt.execute();
            oMap.put("EKRAN_ADI" , stmt.getString(1));
            
            stmt = conn.prepareCall("{? = call pkg_trn1119.RC_QRY1119_GET_MUH_FIS_RECORD(?,?,?,?)}");
            int i = 1;
            stmt.registerOutParameter(i++ , -10); // ref cursor
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("NUMARA"));// fi� no giriliyog
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("ISLEM_NO"));
            
            if (!(iMap.get("BAS_TARIH") == null)){
                stmt.setDate(i++ , new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
            } else{
                stmt.setDate(i++ , null);
            }
            
            if (!(iMap.get("SON_TARIH") == null)){
                stmt.setDate(i++ , new java.sql.Date(iMap.getDate("SON_TARIH").getTime()));
            } else{
                stmt.setDate(i++ , null);
            }
            
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(1);
            
            String tableName = "SATIR_BILGILERI";
            
            BigDecimal alacak = new BigDecimal(0);
            BigDecimal borc = new BigDecimal(0);
            
            int j = 0;
            while (rSet.next()){
                oMap.put(tableName , j , "NUMARA" , rSet.getString("fis_numara"));
                GMMap aMap = new GMMap();
                aMap.put("KOD" , "MUHFIS_TUR_KOD");
                aMap.put("KEY" , rSet.getString("fis_tur"));
                oMap.put(tableName , j , "TUR" , GMServiceExecuter.execute("BNSPR_COMMON_GET_PARAM_TEXT" , aMap).get("TEXT"));
                
                oMap.put(tableName , j , "BOLUM" , rSet.getString("satir_hesap_bolum_kodu"));
                oMap.put(tableName , j , "HESAP_NUMARA" , rSet.getString("satir_hesap_numara"));
                oMap.put(tableName , j , "VALOR_TARIHI" , rSet.getDate("satir_valor_tarihi"));
                
                oMap.put(tableName , j , "NDB_LC_TUTAR" , rSet.getString("satir_lc_tutar"));
                oMap.put(tableName , j , "NDB_FC_TUTAR" , rSet.getString("satir_dv_tutar"));
                
                if (rSet.getString("b_a").equals("A"))
                    alacak = alacak.add(rSet.getBigDecimal("satir_lc_tutar"));
                else borc = borc.add(rSet.getBigDecimal("satir_lc_tutar"));
                
                oMap.put(tableName , j , "DOVIZ" , rSet.getString("satir_doviz_kod"));
                oMap.put(tableName , j , "BANKA_ACIKLAMA" , rSet.getString("satir_banka_aciklama"));
                oMap.put(tableName , j , "BANKA_ACIKLAMA_ESKI" , rSet.getString("satir_banka_aciklama"));
                oMap.put(tableName , j , "FIS_ACIKLAMA" , rSet.getString("fis_aciklama"));
                oMap.put(tableName , j , "MUSTERI_ACIKLAMA" , rSet.getString("satir_musteri_aciklama"));
                oMap.put(tableName , j , "MUSTERI_ACIKLAMA_ESKI" , rSet.getString("satir_musteri_aciklama"));
                oMap.put(tableName , j , "REFERANS" , rSet.getString("satir_referans"));
                oMap.put(tableName , j , "MUSTERI_HESAP_TUR" , rSet.getString("satir_musteri_hesap_tur"));
                oMap.put(tableName , j , "MUSTERI_HESAP_NUMARA" , rSet.getString("satir_musteri_hesap_numara"));
                oMap.put(tableName , j , "ISTATISTIK_KODU" , rSet.getString("satir_istatistik_kodu"));
                oMap.put(tableName , j , "MUHASEBELESTIGI_TARIH" , rSet.getDate("fis_muhasebelestigi_tarih"));
                oMap.put(tableName , j , "YARATAN_KULLANICI_KODU" , rSet.getString("yaratan_kullanici_kodu"));
                oMap.put(tableName , j , "ACIKLAMA" , rSet.getString("fis_aciklama"));
                oMap.put(tableName , j , "KUR" , rSet.getString("kur"));
                oMap.put(tableName , j , "BORC_ALACAK" , rSet.getString("b_a"));
                oMap.put(tableName , j , "MUSTERI_NO" , rSet.getBigDecimal("MUSTERI_NO"));
                oMap.put(tableName , j , "UNVAN" , rSet.getString("UNVAN"));
                oMap.put(tableName , j , "DK_HESAP_ADI" , rSet.getString("DK_HESAP_ADI"));
                oMap.put(tableName , j , "KAYIT_KULLANICI_KODU" , rSet.getString("kayit_kullanici_kodu"));
                oMap.put(tableName , j , "SATIR_NUMARA" , rSet.getString("satir_numara"));
                if ("MESAJ_KUTUSU_CAGIRDI".equals(iMap.getString("ACTION"))){
                    GMMap tempMap = new GMMap();
                    tempMap.put("TRX_NO" , iMap.get("TRX_NO"));
                    tempMap.put("FIS_NO" , iMap.get("NUMARA"));
                    tempMap.put("SATIR_NO" , rSet.getString("satir_numara"));
                    tempMap = GMServiceExecuter.call("BNSPR_TRN1119_GET_ACK_YENI" , tempMap);
                    oMap.put(tableName , j , "MUSTERI_ACIKLAMA" , tempMap.getString("MUSTERI_ACIKLAMA"));
                    oMap.put(tableName , j , "MUSTERI_ACIKLAMA_ESKI" , tempMap.getString("MUSTERI_ACIKLAMA_ESKI"));
                    oMap.put(tableName , j , "BANKA_ACIKLAMA" , tempMap.getString("BANKA_ACIKLAMA"));
                    oMap.put(tableName , j , "BANKA_ACIKLAMA_ESKI" , tempMap.getString("BANKA_ACIKLAMA_ESKI"));
                    oMap.put(tableName , j , "GUNC_ISTEYEN_BOL" , tempMap.getString("GUNCELLEME_TALEP_BOLUM"));
                }
                j++;
            }
            
            oMap.put("ALACAK" , alacak);
            oMap.put("BORC" , borc);
            oMap.put("BALANS" , alacak.add(borc));
            
            return oMap;
            
        } catch (SQLException e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN1119_SAVE")
    public static Map<?, ?> save(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            String tableName = "CBS_SATIR";
            List<?> list = (List<?>) iMap.get("CBS_SATIR");
            for (int i = 0, index = 0; i < list.size(); i++){
                
                if ((iMap.getString(tableName , i , "BANKA_ACIKLAMA") != iMap.getString(tableName , i , "BANKA_ACIKLAMA_ESKI"))
                        || (iMap.getString(tableName , i , "MUSTERI_ACIKLAMA") != iMap.getString(tableName , i , "MUSTERI_ACIKLAMA_ESKI"))){
                    MuhFisSatirAckGuncTxId id = new MuhFisSatirAckGuncTxId();
                    id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    id.setFisNumara(iMap.getBigDecimal(tableName , index , "NUMARA"));
                    id.setSatir(iMap.getBigDecimal(tableName , index , "SATIR_NUMARA"));
                    
                    MuhFisSatirAckGuncTx FisSatirGnc = new MuhFisSatirAckGuncTx();
                    FisSatirGnc.setAciklamaBanka(iMap.getString(tableName , index , "BANKA_ACIKLAMA"));
                    FisSatirGnc.setAciklamaBankaEski(iMap.getString(tableName , index , "BANKA_ACIKLAMA_ESKI"));
                    FisSatirGnc.setAciklamaMusteri(iMap.getString(tableName , index , "MUSTERI_ACIKLAMA"));
                    FisSatirGnc.setAciklamaMusteriEski(iMap.getString(tableName , index , "MUSTERI_ACIKLAMA_ESKI"));
                    FisSatirGnc.setBolumKod(iMap.getString(tableName , index , "GUNC_ISTEYEN_BOLM"));
                    FisSatirGnc.setHesapTurKodu(iMap.getString(tableName , index , "HESAP_TUR_KODU"));
                    FisSatirGnc.setMusteriHesapNumara(iMap.getString(tableName , index , "MUSTERI_HESAP_NUMARA"));
                    
                    
                    FisSatirGnc.setId(id);
                    index++;
                    session.saveOrUpdate(FisSatirGnc);
                    session.flush();
                    
                }
            }
            session.flush();
            iMap.put("TRX_NAME" , "1119");
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN1119_ISLEM_KONTROL")
    public static Map<?, ?> IslemKontrol(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call pkg_trn1119.Islem_Kontrol(?)}");
            
            stmt.registerOutParameter(1 , Types.VARCHAR);
            
            stmt.setBigDecimal(2 , iMap.getBigDecimal("FIS_NO"));
            
            stmt.execute();
            
            oMap.put("ISLEM_MESSAGE" , stmt.getString(1));
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN1119_GET_FIS_NO")
    public static GMMap getFisNo(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call pkg_trn1119.get_fis_no(?)}");
            
            stmt.registerOutParameter(1 , Types.INTEGER);
            
            stmt.setBigDecimal(2 , iMap.getBigDecimal("TRX_NO"));
            
            stmt.execute();
            
            oMap.put("FIS_NO" , stmt.getBigDecimal(1));
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN1119_CHANGE_COLOR")
    public static GMMap changeColor(GMMap iMap) {
        try{
            GMMap oMap = new GMMap();
            ArrayList<String> bank = new ArrayList<String>();
            bank.add("BANKA_ACIKLAMA");
            bank.add("BANKA_ACIKLAMA_ESKI");
            ArrayList<String> musteri = new ArrayList<String>();
            musteri.add("MUSTERI_ACIKLAMA");
            musteri.add("MUSTERI_ACIKLAMA_ESKI");
            ArrayList<ArrayList<String>> toBeComparedColumns = new ArrayList<ArrayList<String>>();
            toBeComparedColumns.add(bank);
            toBeComparedColumns.add(musteri);
            oMap.putAll(BeanSetProperties.tablePaintRow((ArrayList<?>) iMap.get("MODEL_DATA") , toBeComparedColumns , "setBackground" , Color.RED));
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN1119_GET_ACK_YENI")
    public static GMMap getAckYeni(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{call pkg_trn1119.get_Aciklama_yeni(?,?,?,?,?,?,?,?)}");
            
            stmt.registerOutParameter(4 , Types.VARCHAR);
            stmt.registerOutParameter(5 , Types.VARCHAR);
            stmt.registerOutParameter(6 , Types.VARCHAR);
            stmt.registerOutParameter(7 , Types.VARCHAR);
            stmt.registerOutParameter(8 , Types.VARCHAR);
            
            stmt.setBigDecimal(1 , iMap.getBigDecimal("TRX_NO"));
            stmt.setBigDecimal(2 , iMap.getBigDecimal("FIS_NO"));
            stmt.setBigDecimal(3 , iMap.getBigDecimal("SATIR_NO"));
            
            stmt.execute();
            
            oMap.put("MUSTERI_ACIKLAMA"      , stmt.getString(4));
            oMap.put("BANKA_ACIKLAMA"        , stmt.getString(5));
            oMap.put("MUSTERI_ACIKLAMA_ESKI" , stmt.getString(6));
            oMap.put("BANKA_ACIKLAMA_ESKI"   , stmt.getString(7));
            oMap.put("GUNC_ISTEYEN_BOLM"     , stmt.getString(8));
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN1119_GET_SON_GNC_INFO")
    public static GMMap getSonGnc_Info(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{call pkg_trn1119.get_SonGncBlg(?,?,?,?,?)}");
            
            stmt.registerOutParameter(2 , Types.DATE);
            stmt.registerOutParameter(3 , Types.VARCHAR);
            stmt.registerOutParameter(4 , Types.DATE);
            
            stmt.setBigDecimal(5 , iMap.getBigDecimal("TRX_NO"));
            stmt.setBigDecimal(1 , iMap.getBigDecimal("FIS_NO"));
            
            stmt.execute();
            
            oMap.put("BAS_TARIH" , stmt.getDate(2));
            oMap.put("SON_TARIH" , stmt.getDate(2));
            oMap.put("GNC_TARIH" , stmt.getDate(4));
            oMap.put("GNC_KULLANICI_KODU" , stmt.getString(3));
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN1119_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            List<?> list = session.createCriteria(MuhTersFisTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            GMMap oMap = new GMMap();
            String tableName = "CBS_SATIR";
            int row = 0;
            GMMap temp = new GMMap();
            for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
                MuhTersFisTx muhTersFisTx = (MuhTersFisTx) iterator.next();
                if (row == 0){
                    temp.put("BAS_TARIHI" , muhTersFisTx.getKriBasTarih());
                    temp.put("BIT_TARIHI" , muhTersFisTx.getKriBitTarih());
                    temp.put("FIS_NO" , muhTersFisTx.getKriFisNo());
                    temp.put("GET_INFO" , "E");
                    //oMap = getList(temp);
                    oMap.put("BAS_TARIHI" , muhTersFisTx.getKriBasTarih());
                    oMap.put("BIT_TARIHI" , muhTersFisTx.getKriBitTarih());
                    oMap.put("FIS_NO" , muhTersFisTx.getKriFisNo());
                }
                List<?> oMaplist = (List<?>) oMap.get("FIS_LIST");
                for (int i = 0; i < oMaplist.size(); i++){
                    if (muhTersFisTx.getId().getFisNo().compareTo(oMap.getBigDecimal(tableName , i , "NUMARA")) == 0)
                        if ("E".equals(muhTersFisTx.getCbTers())){
                            oMap.put(tableName , i , "SEC" , true);
                            break;
                        } else break;
                }
                row++;
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
}
