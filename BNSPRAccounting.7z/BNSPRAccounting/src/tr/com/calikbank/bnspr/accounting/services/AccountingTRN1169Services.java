package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhBsmvDevirTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1169Services {
	@GraymoundService("BNSPR_TRN1169_GET_DEVREDILEN_AY_BILGISI")
	public static GMMap getDevredilenAyBilgisi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_trn1169.Get_devir_tutars(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));

			stmt.execute();

			oMap.put("DEVREDILEN_AY", stmt.getBigDecimal(1));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}
	@GraymoundService("BNSPR_TRN1169_GET_MUH_BSMV_DEVIR_LIST")
	public static GMMap getMuhBsmvDevirList(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(MuhBsmvDevirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
					.list();

			GMMap oMap = new GMMap();
			String tableName = "MUH_BSMV_DEVIR";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				MuhBsmvDevirTx muhBsmvDevirTx = (MuhBsmvDevirTx) iterator.next();

				oMap.put(tableName, row, "DEVIR_SUBE", muhBsmvDevirTx.getId().getDevirSube());
				oMap.put(tableName, row, "DEVRALAN_SUBE", muhBsmvDevirTx.getDevralanSube());
				oMap.put(tableName, row, "DEVIR_TUTAR", muhBsmvDevirTx.getDevirTutar());
				
				row++;
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1169_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			iMap.put("TRX_NAME", "1169");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1169_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(MuhBsmvDevirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
					.list();

			GMMap oMap = new GMMap();
			String tableName = "MUH_BSMV_DEVIR";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				MuhBsmvDevirTx muhBsmvDevirTx = (MuhBsmvDevirTx) iterator.next();

				oMap.put("DEVREDILEN_AY", muhBsmvDevirTx.getDevirAy());
				oMap.put(tableName, row, "DEVIR_SUBE", muhBsmvDevirTx.getId().getDevirSube());
				oMap.put(tableName, row, "DEVRALAN_SUBE", muhBsmvDevirTx.getDevralanSube());
				oMap.put(tableName, row, "DEVIR_TUTAR", muhBsmvDevirTx.getDevirTutar());
				
				row++;
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
