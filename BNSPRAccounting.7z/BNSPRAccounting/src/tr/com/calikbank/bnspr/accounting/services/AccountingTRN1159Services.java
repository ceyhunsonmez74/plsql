package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MustakrizKdBorcislemTx;
import tr.com.aktifbank.bnspr.dao.MustakrizKdBorcislemTxId;
import tr.com.aktifbank.bnspr.dao.MustakrizParametreTx;
import tr.com.aktifbank.bnspr.dao.MustakrizistisnaMusteriTx;
import tr.com.aktifbank.bnspr.dao.MustakrizistisnaMusteriTxId;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1159Services {
    
    @GraymoundService("BNSPR_TRN1159_SAVE")
    public static GMMap save(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        
        MustakrizParametreTx parametreTxDeleteObj =
                (MustakrizParametreTx) session.createCriteria(MustakrizParametreTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
        session.delete(parametreTxDeleteObj);
        session.flush();
        
        MustakrizParametreTx parametreTx = new MustakrizParametreTx();
        parametreTx.setBryAltLimit(iMap.getBigDecimal("BIREYSEL_ASGARI_TUTAR"));
        parametreTx.setBryBkyDegO(iMap.getBigDecimal("BIREYSEL_BAKIYE_DEGISIM"));
        parametreTx.setBryGunSayi(iMap.getBigDecimal("BIREYSEL_KONTROL_GUN"));
        parametreTx.setKrmAltLimit(iMap.getBigDecimal("KURUMSAL_ASGARI_TUTAR"));
        parametreTx.setKrmBkyDegO(iMap.getBigDecimal("KURUMSAL_BAKIYE_DEGISIM"));
        parametreTx.setKrmGunSayi(iMap.getBigDecimal("KURUMSAL_KONTROL_GUN"));
        parametreTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
        
        session.saveOrUpdate(parametreTx);
        session.flush();
        
        @SuppressWarnings("unchecked")
        List<MustakrizKdBorcislemTx> islemDeletObjList = session.createCriteria(MustakrizKdBorcislemTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
        
        for (MustakrizKdBorcislemTx islemDeletObj : islemDeletObjList){
            session.delete(islemDeletObj);
        }
        
        session.flush();
        
        for (int i = 0; i < iMap.getSize("ISLEM_LIST"); i++){
            MustakrizKdBorcislemTxId kdBorcIslemId = new MustakrizKdBorcislemTxId();
            kdBorcIslemId.setIslemKod(iMap.getBigDecimal("ISLEM_LIST" , i , "ISLEM_KODU"));
            kdBorcIslemId.setTxNo(iMap.getBigDecimal("TRX_NO"));
            MustakrizKdBorcislemTx islemObj = new MustakrizKdBorcislemTx();
            islemObj.setId(kdBorcIslemId);
            session.saveOrUpdate(islemObj);
        }
        session.flush();
        
        @SuppressWarnings("unchecked")
        List<MustakrizistisnaMusteriTx> istisnaDeleteObjList = session.createCriteria(MustakrizistisnaMusteriTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
        
        for (MustakrizistisnaMusteriTx istisnaDeleteObj : istisnaDeleteObjList){
            session.delete(istisnaDeleteObj);
        }
        session.flush();
        
        for (int i = 0; i < iMap.getSize("MUSTERI_LIST"); i++){
            MustakrizistisnaMusteriTxId id = new MustakrizistisnaMusteriTxId();
            id.setMusteriNo(iMap.getBigDecimal("MUSTERI_LIST" , i , "MUSTERI_NO"));
            id.setTxNo(iMap.getBigDecimal("TRX_NO"));
            MustakrizistisnaMusteriTx istisnaObj = new MustakrizistisnaMusteriTx();
            istisnaObj.setId(id);
            session.saveOrUpdate(istisnaObj);
            
        }
        session.flush();
        
        iMap.put("TRX_NAME" , "1159");
        oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN1159_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        
        MustakrizParametreTx parametreObj = (MustakrizParametreTx) session.createCriteria(MustakrizParametreTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
        oMap.put("BIREYSEL_ASGARI_TUTAR" , parametreObj.getBryAltLimit());
        oMap.put("BIREYSEL_BAKIYE_DEGISIM" , parametreObj.getBryBkyDegO());
        oMap.put("BIREYSEL_KONTROL_GUN" , parametreObj.getBryGunSayi());
        oMap.put("KURUMSAL_ASGARI_TUTAR" , parametreObj.getKrmAltLimit());
        oMap.put("KURUMSAL_KONTROL_GUN" , parametreObj.getKrmGunSayi());
        oMap.put("KURUMSAL_BAKIYE_DEGISIM" , parametreObj.getKrmBkyDegO());
        
        List<MustakrizKdBorcislemTx> listOfIslem = session.createCriteria(MustakrizKdBorcislemTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
        
        int islemCounter = 0;
        for (MustakrizKdBorcislemTx islemObj : listOfIslem){
            
            oMap.put("ISLEM_LIST" , islemCounter , "ISLEM_KODU" , islemObj.getId().getIslemKod());
            oMap.put("ISLEM_LIST" , islemCounter , "ACIKLAMA" , LovHelper.diLov(islemObj.getId().getIslemKod() , "1159/LOV_ISLEM_NO" , "ACIKLAMA"));
            
            islemCounter++;
        }
        
        List<MustakrizistisnaMusteriTx> listOfMusteri = session.createCriteria(MustakrizistisnaMusteriTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
        
        int musteriCounter = 0;
        for (MustakrizistisnaMusteriTx musteriObj : listOfMusteri){
            
            oMap.put("MUSTERI_LIST" , musteriCounter , "MUSTERI_NO" , musteriObj.getId().getMusteriNo());
            oMap.put("MUSTERI_LIST" , musteriCounter , "ISIM_UNVAN" , LovHelper.diLov(musteriObj.getId().getMusteriNo() , "1159/LOV_MUSTERI_NO" , "ISIM_UNVAN"));
            
            musteriCounter++;
        }
        
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN1159_GET_INITAL_VALUES")
    public static GMMap getInitalValues(GMMap iMap) throws SQLException {
        GMMap oMap = new GMMap();
        Object[] inputValues = new Object[] {};
        String funcStr = "{ ? = call  PKG_TRN1159.ParametreDegerAktar()}";
        
        oMap.put("TRX_NO" , (BigDecimal) DALUtil.callOracleFunction(funcStr , BnsprType.NUMBER , inputValues));
        iMap.put("TRX_NO" , oMap.getBigDecimal("TRX_NO"));
        
        Session session = DAOSession.getSession("BNSPRDal");
        
        MustakrizParametreTx parametreObj = (MustakrizParametreTx) session.createCriteria(MustakrizParametreTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
        oMap.put("BIREYSEL_ASGARI_TUTAR" , parametreObj.getBryAltLimit());
        oMap.put("BIREYSEL_BAKIYE_DEGISIM" , parametreObj.getBryBkyDegO());
        oMap.put("BIREYSEL_KONTROL_GUN" , parametreObj.getBryGunSayi());
        oMap.put("KURUMSAL_ASGARI_TUTAR" , parametreObj.getKrmAltLimit());
        oMap.put("KURUMSAL_KONTROL_GUN" , parametreObj.getKrmGunSayi());
        oMap.put("KURUMSAL_BAKIYE_DEGISIM" , parametreObj.getKrmBkyDegO());
        
        List<MustakrizKdBorcislemTx> listOfIslem = session.createCriteria(MustakrizKdBorcislemTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
        
        int islemCounter = 0;
        for (MustakrizKdBorcislemTx islemObj : listOfIslem){
            
            oMap.put("ISLEM_LIST" , islemCounter , "ISLEM_KODU" , islemObj.getId().getIslemKod());
            oMap.put("ISLEM_LIST" , islemCounter , "ACIKLAMA" , LovHelper.diLov(islemObj.getId().getIslemKod() , "1159/LOV_ISLEM_NO" , "ACIKLAMA"));
            
            islemCounter++;
        }
        
        List<MustakrizistisnaMusteriTx> listOfMusteri = session.createCriteria(MustakrizistisnaMusteriTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
        
        int musteriCounter = 0;
        for (MustakrizistisnaMusteriTx musteriObj : listOfMusteri){
            
            oMap.put("MUSTERI_LIST" , musteriCounter , "MUSTERI_NO" , musteriObj.getId().getMusteriNo());
            oMap.put("MUSTERI_LIST" , musteriCounter , "ISIM_UNVAN" , LovHelper.diLov(musteriObj.getId().getMusteriNo() , "1159/LOV_MUSTERI_NO" , "ISIM_UNVAN"));
            
            musteriCounter++;
        }
        
        return oMap;
    }
    
}
