package tr.com.calikbank.bnspr.accounting.services;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingPAR1195Services {
	
	@GraymoundService("BNSPR_PAR1195_FILL_COMBOBOX")
	public static GMMap fillComboBox(GMMap iMap)
	{
		GMMap oMap=new GMMap();
		iMap.put("ADD_EMPTY_KEY", "H");
        iMap.put("KOD", "MAS_KOM_BOLUM_KOD");
        oMap.put("MASRAF_BOLUMU",GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", 
                   iMap).get("RESULTS"));  
        return oMap;

	}
	@GraymoundService("BNSPR_PAR1195_SAVE")
	public static GMMap save(GMMap iMap)
	{
		Connection conn=null;
		PreparedStatement stmt=null;
		
		try {
			conn = DALUtil.getGMConnection();
			stmt= conn.prepareStatement("insert into GNL_BOLUM_MAS_KOM_FAIZ_GEL_TIP (BOLUM_KOD, MASRAF_KOD) values (?,?)");
			stmt.setString(1, iMap.getString("BOLUM_KOD"));
			stmt.setString(2, iMap.getString("MASRAF_KOD"));
			stmt.execute();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}		
        return iMap;

	}
	

}
