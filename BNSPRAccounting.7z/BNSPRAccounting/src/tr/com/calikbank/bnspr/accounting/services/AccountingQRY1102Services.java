package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.Locale;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingQRY1102Services {

	@GraymoundService("BNSPR_QRY1102_GET_DK_INFO")
	public static GMMap getDkHesapHareketIzlemeInfo(GMMap iMap) throws ParseException {
	    Connection conn = null;
	    CallableStatement stmt = null;
	    ResultSet rSet = null;
		
		try {
			/*Object[] objArray = new Object[16];
			objArray[0]=BnsprType.STRING;
			objArray[1]=iMap.getString("DK_NO");
			objArray[2]=BnsprType.STRING;
			objArray[3]=iMap.getString("DOVIZ_KODU");
			objArray[4]=BnsprType.STRING;
			objArray[5]=iMap.getString("SUBE_KODU");
			
			objArray[6]=BnsprType.DATE;
			if (!(iMap.get("BAS_TARIH") == null)) {
				objArray[7]=new Date(iMap.getDate("BAS_TARIH").getTime());
			} else {
				objArray[7]= null;
			}
			objArray[8]=BnsprType.DATE;
			if (!(iMap.get("BIT_TARIH") == null)) {
				objArray[9]=new Date(iMap.getDate("BIT_TARIH").getTime());
			} else {
				objArray[9]= null;
			}
		
			objArray[10]=BnsprType.NUMBER;
			objArray[11]=iMap.getBigDecimal("DEVREDEN_BAKIYE");
			
			objArray[12]=BnsprType.NUMBER;
			if (iMap.getBigDecimal("MIN_TUTAR").compareTo(BigDecimal.ZERO)==0) objArray[13]=null;
			else objArray[13] = iMap.getBigDecimal("MIN_TUTAR");
			
			objArray[14]=BnsprType.NUMBER;
			if (iMap.getBigDecimal("MAX_TUTAR").compareTo(BigDecimal.ZERO)==0) objArray[15]= null;
			else objArray[15]= iMap.getBigDecimal("MAX_TUTAR");	
		
			String func="{? = call pkg_rc_accounting.RC_QRY1102_GET_DK_INFO(?,?,?,?,?,?,?,?)}";
			GMMap oMap2 = new GMMap();
			oMap2= DALUtil.callOracleRefCursorFunction(func, "TABLO", objArray); */

			conn = DALUtil.getGMConnection();
		      stmt = conn.prepareCall("{ ? = call pkg_rc_accounting.RC_QRY1102_GET_DK_INFO(?,?,?,?,?,?,?,?)}");
		      int i=1;
		      
		      stmt.registerOutParameter(i++, -10);
		      
		      stmt.setString(i++,iMap.getString("DK_NO"));
		      stmt.setString(i++,iMap.getString("DOVIZ_KODU"));
		     if(iMap.getString("SUBE_KODU")==null)
			        stmt.setString(i++, null);
			 else
			  stmt.setString(i++, iMap.getString("SUBE_KODU"));

     		 if (!(iMap.get("BAS_TARIH") == null)) 
   			  stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
  		     else
			        stmt.setString(i++, null);

     		 if (!(iMap.get("BIT_TARIH") == null)) 
      			  stmt.setDate(i++, new java.sql.Date(iMap.getDate("BIT_TARIH").getTime()));
     		     else
   			        stmt.setString(i++, null);

 			stmt.setBigDecimal(i++, iMap.getBigDecimal("DEVREDEN_BAKIYE"));
            if (iMap.getBigDecimal("MIN_TUTAR").compareTo(BigDecimal.ZERO)==0)
                    stmt.setString(i++, null);
            else
 			stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_TUTAR"));

            if (iMap.getBigDecimal("MAX_TUTAR").compareTo(BigDecimal.ZERO)==0)
                stmt.setString(i++, null);
            else
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_TUTAR"));
			
	      stmt.execute();
	      
	      GMMap oMap = new GMMap();
	      rSet = (ResultSet)stmt.getObject(1);
			
						
			String tableName = "DK_HAREKET";
			int j = 0;

			while(rSet.next()) {
			    DateFormat formatter = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.DEFAULT, Locale.getDefault());
				
				oMap.put(tableName, j, "SATIR_DV_TUTAR",rSet.getBigDecimal("SATIR_DV_TUTAR"));
				oMap.put(tableName, j, "SATIR_TUR",rSet.getString("SATIR_TUR"));
				oMap.put(tableName, j, "FIS_NUMARA", rSet.getBigDecimal("FIS_NUMARA"));
				oMap.put(tableName, j, "FIS_YARATILDIGI_BANKA_TARIH", rSet.getDate("FIS_YARATILDIGI_BANKA_TARIH"));
				oMap.put(tableName, j, "SATIR_BANKA_ACIKLAMA", rSet.getString("SATIR_BANKA_ACIKLAMA"));
				oMap.put(tableName, j, "SATIR_DOVIZ_KOD", rSet.getString("SATIR_DOVIZ_KOD"));
				oMap.put(tableName, j, "SATIR_HESAP_BOLUM_KODU", rSet.getBigDecimal("SATIR_HESAP_BOLUM_KODU"));
				oMap.put(tableName, j, "SATIR_HESAP_NUMARA", rSet.getString("SATIR_HESAP_NUMARA"));
				oMap.put(tableName, j, "BAKIYE", rSet.getBigDecimal("CUMTUTAR"));
				oMap.put(tableName, j, "REFERANS", rSet.getString("SATIR_REFERANS"));
				oMap.put(tableName, j, "GIRISCI", rSet.getString("GIRISCI"));
				oMap.put(tableName, j, "ONAYCI", rSet.getString("ONAYCI"));
				oMap.put(tableName, j, "SATIR_TARIH", formatter.format(rSet.getTimestamp("satir_tarih")));

				j++;
			}
			return oMap;
		} catch (SQLException e) {
			//throw new GMRuntimeException(1, e);
			throw ExceptionHandler.convertException(e);
		}finally {
		      GMServerDatasource.close(rSet);
		      GMServerDatasource.close(stmt);
		      GMServerDatasource.close(conn);
		}      
	}
	

	
	@GraymoundService("BNSPR_QRY1102_GET_DEVREDEN_BAKIYE")
	public static GMMap getDevredenBakiye(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		java.util.Date Date = iMap.getDate("BAS_TARIH");
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_hp.DevirBakiye(?,?,?,?)}");
			stmt.registerOutParameter(1, Types.DECIMAL);
				stmt.setString(2, iMap.getString("DK_NO"));
				stmt.setString(3, iMap.getString("SUBE_KODU"));
				if (!(iMap.get("BAS_TARIH") == null)) {
			//		stmt.setDate(4, new Date(iMap.getDate("BAS_TARIH").getTime()));
					Date = getGeriIsGunu(Date);
					stmt.setDate(4, new Date(Date.getTime()));
					} else {
						stmt.setDate(4, null);
					}		
				stmt.setString(5, iMap.getString("DOVIZ_KOD"));
				stmt.execute();
				if (!("").equals(stmt.getObject(1)) && stmt.getObject(1) != null ) {
					oMap.put("DEVREDEN_BAKIYE", stmt.getObject(1));
				}else{
					oMap.put("DEVREDEN_BAKIYE", new BigDecimal(0));
				}
				return oMap;
			} catch (SQLException e) {
				throw ExceptionHandler.convertException(e);

			} finally {
				GMServerDatasource.close(conn);
				GMServerDatasource.close(stmt);
			}
		}

	public static Date getGeriIsGunu(java.util.Date aDate){
		GMMap oMap = new GMMap();
		oMap.put("TARIH", aDate);
		return (Date)GMServiceExecuter.execute("BNSPR_TRN2301_GET_GERI_ISGUNU", oMap).get("SONUC");
	}
}
