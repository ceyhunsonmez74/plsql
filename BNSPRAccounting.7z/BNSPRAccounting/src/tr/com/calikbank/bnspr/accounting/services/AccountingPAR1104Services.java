package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhHpTanim;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class AccountingPAR1104Services {
	@GraymoundService("BNSPR_PAR1104_SAVE")
	public static GMMap save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			MuhHpTanim muhHpTanim = new MuhHpTanim();

			muhHpTanim.setKarsiSubeyeKapaliMi(iMap
					.getString("KARSI_SUBEYE_KAPALI_MI"));
			muhHpTanim.setHesapTerseDonsunMu(iMap
					.getString("HESAP_TERSE_DONSUN_MU"));
			muhHpTanim.setAlthesapMi(iMap.getString("ALTHESAP_MI"));
			muhHpTanim.setSubeyeKapaliMi(iMap.getString("SUBEYE_KAPALI_MI"));
			muhHpTanim.setGenelMdKapaliMi(iMap.getString("GENEL_MD_KAPALI_MI"));
			muhHpTanim.setFaizHesaplanacakMi(iMap
					.getString("FAIZ_HESAPLANACAK_MI"));
			muhHpTanim
					.setPersoneleBagliMi(iMap.getString("PERSONELE_BAGLI_MI"));
			muhHpTanim.setSbaKapaliMi(iMap.getString("SBA_KAPALI_MI"));
			muhHpTanim.setBaKod(iMap.getString("BA_KOD"));
			muhHpTanim.setHesapNo(iMap.getString("NUMARA"));
			muhHpTanim.setDkSinif(iMap.getString("DK_SINIF"));
			muhHpTanim.setDkKisaIsim(iMap.getString("DK_KISA_ISIM"));
			muhHpTanim.setAciklama(iMap.getString("ACIKLAMA"));
			muhHpTanim.setMusteriliHesapMi(iMap.getString("MUSTERILI_HESAP_MI"));
			session.save(muhHpTanim);
			session.flush();
			

			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_PAR1104_HESAP_YARAT")
	public static GMMap hesapYarat(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_hp.hesap_yarat(?,?,?)}");
			stmt.setString(1, iMap.getString("HESAP_NO"));
			Date baslangicTarihi =  iMap.getDate("BASLANGIC_TARIHI");
			Date bitisTarihi =  iMap.getDate("BITIS_TARIHI");
			if (baslangicTarihi != null)
				stmt.setDate(2, new java.sql.Date(baslangicTarihi.getTime()));
			else
				stmt.setDate(2, null);

			if (bitisTarihi != null)
				stmt.setDate(3, new java.sql.Date(bitisTarihi.getTime()));
			else
				stmt.setDate(3, null);

			stmt.execute();
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} catch (ParseException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
}
