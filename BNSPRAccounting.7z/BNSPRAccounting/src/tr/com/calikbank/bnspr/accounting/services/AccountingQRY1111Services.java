package tr.com.calikbank.bnspr.accounting.services;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import jxl.Workbook;
import jxl.write.DateFormat;
import jxl.write.Label;
import jxl.write.WritableCell;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;

@SuppressWarnings("rawtypes")
public class AccountingQRY1111Services {
	public static String charset = "iso-8859-9";

	public static final SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
	public static WritableCellFormat cellDateFormat = new WritableCellFormat(new DateFormat("dd.MM.yyyy"));

    @GraymoundService("BNSPR_QRY1111_INITIALIZE")
    public static GMMap initialize(GMMap iMap) {
        try {
			Map<String, String[]> headers = new LinkedHashMap<String, String[]>();
			headers.put("DK_NUMARA", 	new String[] { "DK No", 			"getString" });
			headers.put("MUSTERI_NO", 	new String[] { "M��teri No", 		"getString" });
			headers.put("HESAP_NO", 	new String[] { "Hesap No", 			"getString" });
			headers.put("DOVIZ_KOD", 	new String[] { "D�viz Kodu", 		"getString" });
			headers.put("ACIKLAMA", 	new String[] { "A��klama", 			"getString" });
			headers.put("BORC_FC", 		new String[] { "Bor� Toplam Dvz", 	"getBigDecimal" });
			headers.put("ALACAK_FC", 	new String[] { "Alacak Toplam Dvz", "getBigDecimal" });
			headers.put("BAKIYE_FC", 	new String[] { "Bakiye", 			"getBigDecimal" });
			headers.put("TARIH", 		new String[] { "Tarih", 			"getDate" });
			headers.put("DK_GRUP_KODU",         new String[] { "DK Grup Kodu",             "getString" });

        	iMap.put("HEADERS", headers);

            return iMap; 
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

	@GraymoundService("BNSPR_QRY1111_MUSTERI_DETAYLI_MIZAN")
	public static GMMap getDkInfo(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_rc1111.RC_QRY1111(?,?,?,?,?,?,?)}");
			if (!(iMap.get("TARIH") == null)) {
				stmt.setDate(1, new Date(iMap.getDate("TARIH").getTime()));
			}
			else {
				stmt.setDate(1, null);
			}
			stmt.setString(2, iMap.getString("SUBE_KODU"));
			stmt.setString(3, iMap.getString("DOVIZ_KOD"));
			stmt.setString(4, iMap.getString("TUR"));
			stmt.setString(5, iMap.getString("DK_NO"));
			stmt.setString(6, iMap.getBoolean("F_VDMK_HARIC") ? "E" : "H");
			stmt.registerOutParameter(7, -10); // ref cursor
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(7);

			oMap = DALUtil.rSetResults(rSet, "CBS_DETAY");

			String tableName = "CBS_DETAY";

			String OmapUzunluk;

			OmapUzunluk = oMap.toString();

			int lenght = 0;
			float TOPLAM_ALACAK_FC = 0;
			float TOPLAM_BORC_FC = 0;
			float TOPLAM_BAKIYE_FC = 0;
			if (OmapUzunluk.length() > 2) {
				List<?> list = (List<?>) oMap.get(tableName);

				for (int i = 0; i < list.size(); i++) {
					lenght = oMap.getString(tableName, i, "DK_NUMARA").length();

					if (lenght == 9 && (oMap.getString(tableName, i, "MUSTERI_NO") == null || oMap.getString(tableName, i, "MUSTERI_NO").isEmpty())) {
						TOPLAM_ALACAK_FC = TOPLAM_ALACAK_FC + Float.parseFloat(oMap.getString(tableName, i, "ALACAK_FC"));
						TOPLAM_BORC_FC = TOPLAM_BORC_FC + Float.parseFloat(oMap.getString(tableName, i, "BORC_FC"));
					}
				}
				TOPLAM_BAKIYE_FC = TOPLAM_ALACAK_FC - TOPLAM_BORC_FC;
			}

			DecimalFormat df = new DecimalFormat("##################.##"); // 18,2

			oMap.put("TOPLAM_BAKIYE_FC", df.format(TOPLAM_BAKIYE_FC));
			oMap.put("TOPLAM_ALACAK_FC", df.format(TOPLAM_ALACAK_FC));
			oMap.put("TOPLAM_BORC_FC", df.format(TOPLAM_BORC_FC));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);

		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	/**
	 * 
	 * - Bu servis BNSPR_EXPORT_TO_EXCEL.guiml'den �a�r�l�r <br/>
	 * 
	 * @param iMap
	 * 			-FILE_NAME
	 * 			-TABLE_DATA
	 * 			-HEADERS (opsiyonel)
	 * @return
	 * 		oMap
	 * 			-FILE_NAME
	 * 			-DOSYA_SAYISI
	 * @throws
	 * 			GMRuntimeException
	 */
	@SuppressWarnings({ "unchecked", "null" })
	@GraymoundService("BNSPR_TABLE_TO_EXCEL")
    public static GMMap exportToExcel(GMMap iMap) {
        String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";
        GMMap oMap = new GMMap();

        try {
       
            String tablename = "TABLE_DATA";
            String fileName = iMap.getString("FILE_NAME");

            String sheetName = iMap.getString("FILE_NAME");

            int fileNum = 1;
            File f = new File(ROOT + File.separator + "files" + File.separator + fileName + fileNum + ".xls");
            WritableWorkbook workbook = Workbook.createWorkbook(f);
            int sheetNum = 0;

            WritableSheet sheet = workbook.createSheet(sheetName + fileNum + "_" + (sheetNum + 1), sheetNum);

            Class columnTypeClass;
            Class[] argsClasses;
            Constructor constructor;
            
            int row = 0;
            int col = 0;

            String className;
            String columnID;
            
            int size = iMap.getSize(tablename);
            if (size>0) {
    			ArrayList<Map<String, Object>> tabloFIRST =(ArrayList<Map<String, Object>>) iMap.get(tablename);

    			Map<String, String[]> headers = null;
    			boolean hasHeaders = iMap.containsKey("HEADERS") && iMap.get("HEADERS") != null;
    			
    			if (hasHeaders) {
    				headers = (LinkedHashMap<String, String[]>) iMap.get("HEADERS");
    			}
    			else {
    				Map<String, Object> satir = tabloFIRST.get(0);
    				for (String key : satir.keySet()) {
    					headers.put(key, (String[]) null);
    				}
    			}
    			
    			String[] columnIDs = new String[headers.keySet().size()];
    			headers.keySet().toArray(columnIDs);

            	iMap = GMServiceExecuter.call("BNSPR_TABLE_PREPARE_FOR_EXPORTING", iMap);

            	ArrayList<Map<String, Object>> tablo =(ArrayList<Map<String, Object>>) iMap.get(tablename);
    			GMMap rowData = new GMMap(tablo.get(0)); // Ba�l�k datas�
    			GMMap rowDataFirst;

    			int columnSize = rowData.size();

                for (int column=0; column < columnSize;column++) { // Baslik
                    sheet.addCell(new Label(col++, row, (String) rowData.get(column+"")));
                }

                row++;

                for (int dataRow = 1; dataRow < size+1; dataRow++) { // Sat�rlar
                	rowData = new GMMap(tablo.get(dataRow));
                	rowDataFirst = new GMMap(tabloFIRST.get(dataRow-1));

                	col=0;
	                for (int column=0; column < columnSize;column++) { // Kolonlar
	                	columnID = columnIDs[column];
	                	if (hasHeaders && headers.get(columnID).length>1) {
	                		className = etractExcellCellClass(headers.get(columnID)[1]);

	                		if (className != null && rowDataFirst.getString(columnID)!=null) {
			                    columnTypeClass = Class.forName("jxl.write."+className);
			                    argsClasses = getCellParameterClasses(className);
		
			                    constructor = columnTypeClass.getConstructor(argsClasses);
			                    Object cell = constructor.newInstance(getCellParameters(col++, row, formatExcellCellArgument(className, rowDataFirst.getString(columnID)), className));
		
			                    sheet.addCell((WritableCell) cell);
	                		} else {
		                        sheet.addCell(new Label(col++, row, (String) rowData.get(column+"")));
		                	}
	                	} else {
	                        sheet.addCell(new Label(col++, row, (String) rowData.get(column+"")));
	                	}
					}
	
	                row++;

	                // Sorgu bazen maximum excel satirini geciyor. Bu sebeple satir
	                // kontrolu eklenip diger scheet'e gecicek.
	                if (row > 65000) {
	                    if (sheetNum == 2) {
	                        fileNum++;
	                        workbook.write();
	                        workbook.close();
	                        f = new File(ROOT + File.separator + "files" + File.separator + fileName + fileNum + ".xls");
	                        workbook = Workbook.createWorkbook(f);
	                        sheetNum = 0;
	                    } else
	                        sheetNum++;
	                    row = 0;
	                    sheet = workbook.createSheet(sheetName + fileNum + "_" + (sheetNum + 1), sheetNum);
	                    // yeni sheet e baslik ekleyelim.
	
	                    rowData = new GMMap(tablo.get(0)); // Header
	                    for (int column=0; column < columnSize;column++) {
	                        sheet.addCell(new Label(col++, row, (String) rowData.get(column+"")));
	                    }
	
	                    row++;
	                }
	            }
            }

            workbook.write();
            workbook.close();

            oMap.put("FILE_NAME_PTT", f.getName());
            oMap.put("FILE_NAME", fileName);
            oMap.put("DOSYA_SAYISI", fileNum);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }

        return oMap;
    }

	/**
     * 
     * @param
     * 		iMap
	 * 			-FILE_NAME (.pdf uzant�s�z haliyle),
	 * 			-TABLE_DATA,
	 * 			-HEADERS (opsiyonel)
	 * 			-CHANGE_PAGE_DIRECTION (Boolean: true-> yatay, false(varsay�lan)->dikey) (opsiyonel)
	 * 			-FONT_SIZE (float (varsay�lan: 6f)) (opsiyonel)
	 * @return
	 * 		oMap
	 * 			-PDF_FILE
	 * @throws
	 * 			GMRuntimeException
     */
    @SuppressWarnings({ "unchecked"})
	@GraymoundService("BNSPR_TABLE_TO_PDF")
    public static GMMap exportToPdfService(GMMap iMap) {
    	GMMap oMap = new GMMap();
        try {
            String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";
            String fileName = iMap.getString("FILE_NAME");
            String tablename = "TABLE_DATA";

            File f = new File(ROOT + File.separator + "files" + File.separator + fileName + ".pdf");
            if (f.exists()) {
            	f.delete();
            }

            boolean changePageDirection = iMap.getBoolean("CHANGE_PAGE_DIRECTION");
            float fontSize = iMap.containsKey("FONT_SIZE") ? Float.valueOf(iMap.getString("FONT_SIZE")) : 6f;

			Document pdfDocument = new Document();
			pdfDocument.setPageSize(changePageDirection ? PageSize.A4.rotate() : PageSize.A4);

		    Font headerFont = FontFactory.getFont(BaseFont.HELVETICA_BOLD, charset, fontSize);
		    Font cellFont = FontFactory.getFont(BaseFont.HELVETICA, charset, fontSize);	

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			
			PdfWriter.getInstance(pdfDocument, baos);

            int size = iMap.getSize(tablename);
            if (size>0) {
    			pdfDocument.open();

            	iMap = GMServiceExecuter.call("BNSPR_TABLE_PREPARE_FOR_EXPORTING", iMap);
            	
    			ArrayList<Map<String, Object>> tablo =(ArrayList<Map<String, Object>>) iMap.get(tablename);
    			Map<String, Object> rowData = tablo.get(0); // Ba�l�k datas�

    			int columnSize = rowData.size();

    			PdfPTable pdfTable = new PdfPTable(columnSize);

				pdfTable.setTotalWidth((changePageDirection ? PageSize.A4.rotate().width() : PageSize.A4.width())-40f);
		        pdfTable.setLockedWidth(true); 

		        pdfTable.setSpacingAfter(0); 
		        pdfTable.setSpacingBefore(0);
    			
                for (int column=0; column < columnSize;column++) { // Ba�l�k
                    pdfTable.addCell(getPdfCell((String) rowData.get(column+""), headerFont, true));
                }

                for (int dataRow = 1; dataRow < size+1; dataRow++) { // Sat�rlar
                	rowData = tablo.get(dataRow);

	                for (int column=0; column < columnSize;column++) { // Kolonlar
	                    pdfTable.addCell(getPdfCell((String) rowData.get(column+""), cellFont, false));
					}
	            }
				pdfDocument.add(pdfTable);
				pdfDocument.close();
            }

			byte[] bs = baos.toByteArray();
			FileOutputStream out = new FileOutputStream(f);
			out.write(bs);
			out.close();
			
			oMap.put("PDF_FILE", f);
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

	/**
	 * 
	 * <br/>
	 * "HEADERS", parametresi g�nderilmezse, ba��klar s�tun adlar�ndan olu�turulur, e�er paremetre g�nderilirse �u  �ekilde kullan�labilir:<br/>
	 * <br/>
	 *		Map<String, String[]> headers = new LinkedHashMap<String, String[]>();<br/>
	 *		headers.put("DK_NUMARA", 	new String[] { "DK No", 			"getString" });<br/>
	 *		headers.put("MUSTERI_NO", 	new String[] { "M��teri No", 		"getString" });<br/>
	 *		headers.put("HESAP_NO", 	new String[] { "Hesap No", 			"getString" });<br/>
	 *		headers.put("DOVIZ_KOD", 	new String[] { "D�viz Kodu"						}); // Varsay�landa "getString"<br/>
	 *		headers.put("ACIKLAMA", 	new String[] { "A��klama", 			"getString" });<br/>
	 *		headers.put("No", 			new String[] { "No", 				"getString;DateTime" });// Excel veya ba�ka bir ��kt� bi�iminde farkl� bir i�lem uygulanacaksa noktal� virg�lle ekleme yap�labilir<br/>
	 *		headers.put("ACIKLAMA", 	new String[] { "A��klama", 			"getString;Number" });// Excel veya ba�ka bir ��kt� bi�iminde farkl� bir i�lem uygulanacaksa noktal� virg�lle ekleme yap�labilir<br/>
	 *		headers.put("BORC_FC", 		new String[] { "Bor� Toplam Dvz", 	"getBigDecimal" });<br/>
	 *		headers.put("BAKIYE_FC", 	new String[] { "Bakiye", 			"getBigDecimal", "3" }); // E�er virg�lden sonraki k�sm�n min. uzunlu�u k�s�tlanmak istiyorsa ���nc� bir parametre g�nderilmeli.<br/>
	 *		headers.put("BAKIYE_FC", 	new String[] { "Bakiye", 			"getBigDecimal", "3", "5" }); // E�er virg�lden sonraki k�sm�n max. uzunlu�u k�s�tlanmak istiyorsa d�rd�nc� bir parametre g�nderilmeli.<br/>
	 *		headers.put("No", 			new String[] { "No", 				"getInt" }); //�kinci olarak g�nderilen parametreler GMMap'in herhangi bir methodu olabilir<br/>
	 * <br />
     *   	iMap.put("HEADERS", headers);<br/>
     * <br />
     * <br />
     * <br />
     * <br />
     * 	Servisten ��kan ��kt� tablo yap�s�:<br />
     * <br />
     * 					Sutun1	Sutun2	Sutun3	Sutun4 	Sutun5	Sutun6 	...									<br />
     * 				______________________________________________________									<br />
     *  	Sat�r1	|	Ba�l�k1	Ba�l�k2 Ba�l�k3	Ba�l�k4 Ba�l�k5	Ba�l�k6	...	-> ��lenmi� ba�l�klar			<br />
     *  	Sat�r2	|	data11	data12 	data13 	data14 	data15 	data16 	...	-> ��lenmi� veriler (1.sat�r)	<br />
     *  	Sat�r3	|	data21	data22 	data23 	data24 	data25 	data26 	...	-> ��lenmi� veriler (2.sat�r)	<br />
     *  	Sat�r4	|	data31	data32 	data33 	data34 	data35 	data36 	...	-> ��lenmi� veriler (3.sat�r)	<br />
     *  	...<br />
	 * <br />
	 * @param iMap
	 * 			-TABLE_DATA
	 * 			-HEADERS (opsiyonel)
	 * @return
	 * 		oMap
	 * 			-TABLE_DATA
	 * @throws
	 * 			GMRuntimeException
	 */
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TABLE_PREPARE_FOR_EXPORTING")
    public static GMMap prepareForExporting(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
			String tablename = "TABLE_DATA";

			Map<String, String[]> cols = new LinkedHashMap<String, String[]>();

			int row = 0;
			int col = 0;

			boolean hasHeaders = iMap.containsKey("HEADERS") && iMap.get("HEADERS") != null;
			int size = iMap.getSize(tablename);
			if (size > 0) {
				ArrayList<Map<String, Object>> tablo = (ArrayList<Map<String, Object>>) iMap.get(tablename);

				if (hasHeaders) {
					cols = (LinkedHashMap<String, String[]>) iMap.get("HEADERS");
				}
				else {
					Map<String, Object> satir = tablo.get(0);
					for (String key : satir.keySet()) {
						cols.put(key, (String[]) null);
					}
				}

				for (String columnName : cols.keySet()) {
					oMap.put(tablename, row, col++ + "", hasHeaders ? cols.get(columnName)[0] : columnName.replace('_', ' '));
				}

				row++;

				Object datum;
				Method method;
				String finalColumnDatum = null, methodName = null;
				SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");

				for (int k = 0; k < size; k++) {
					col = 0;
					for (String columnName : cols.keySet()) {
						finalColumnDatum = "";

						if (hasHeaders && cols.get(columnName).length > 1 && cols.get(columnName)[1].startsWith("get")){ // E�er istenilen �ekilde formatlanmas� istenirse
							methodName = cols.get(columnName)[1].split(";")[0];

							method = GMMap.class.getMethod(methodName, String.class, int.class, String.class);
							datum = method.invoke(iMap, tablename, row - 1, columnName);

							if (datum == null) {
								finalColumnDatum = "";
							}
							else if (methodName.contains("getDate")) {
								finalColumnDatum = sdf.format((java.util.Date) datum);
							}
							else if (methodName.contains("getBigDecimal")) {
								NumberFormat trCostFormat = NumberFormat.getInstance();
								trCostFormat.setMinimumFractionDigits(cols.get(columnName).length > 2 ? Integer.parseInt(cols.get(columnName)[2]) : 0);
								trCostFormat.setMaximumFractionDigits(cols.get(columnName).length > 3 ? Integer.parseInt(cols.get(columnName)[3]) : 100);
								finalColumnDatum = trCostFormat.format(((BigDecimal) datum).doubleValue());
							}
							else {
								finalColumnDatum = datum.toString();
							}

							oMap.put(tablename, row, col++ + "", finalColumnDatum);
						}
						else {
							oMap.put(tablename, row, col++ + "", iMap.getString(tablename, k, columnName));
						}
					}

					row++;
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

        return oMap;
    }

    @GraymoundService("BNSPR_DELETE_EXCEL_TMP_FILES")
    public static GMMap deleteTmpFile(GMMap iMap) {
        try {
            if (iMap.containsKey("FILE_NAME") && iMap.containsKey("DOSYA_SAYISI")) {
                String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";
                String fileName = iMap.getString("FILE_NAME");

                File f;
                for (int i = 1; i <= iMap.getInt("DOSYA_SAYISI"); i++) {
                    f = new File(ROOT + File.separator + "files" + File.separator + fileName + i + ".xls");
                    if (f.exists()) {
                    	f.delete();
                    }
                }            	
            }
            return iMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
	

    @GraymoundService("BNSPR_QRY1111_SORGULA_VE_EXCELE_AKTAR")
    public static GMMap sorgulaVeExceleAktar(GMMap iMap) {
        Object tableData=GMServiceExecuter.call("BNSPR_QRY1111_MUSTERI_DETAYLI_MIZAN", iMap).get("CBS_DETAY");
        GMMap oMap=new GMMap();
        oMap.putAll(iMap);
        oMap.put("TABLE_DATA", tableData);
    	return GMServiceExecuter.call("BNSPR_TABLE_TO_EXCEL", oMap);
    }

    /**
     * 
     * @param in
     * @return out
     */
    public static String changeCharsToUnicode(String in) {
        in=in.replaceAll("�", "\u00fc");
        in=in.replaceAll("�", "\u00dc");

        in=in.replaceAll("�", "\u00d6");
        in=in.replaceAll("�", "\u00f6");

        in=in.replaceAll("�", "\u00c7");
        in=in.replaceAll("�", "\u00e7");

        in=in.replaceAll("�", "\u0130");
    	in=in.replaceAll("�", "\u0131");

        in=in.replaceAll("�", "\u011f");
        in=in.replaceAll("�", "\u011e");

        in=in.replaceAll("�", "\u015e");
        in=in.replaceAll("�", "\u015f");

        return in;
    }
    
    public static PdfPCell getPdfCell(String value,Font font, boolean middle) {
    	if (StringUtils.isBlank(value)) {
    		value = "";
    	}

		PdfPCell cell = new PdfPCell();
		Paragraph cellValue = new Paragraph(changeCharsToUnicode(value),font);
		cell.addElement(cellValue);

		if (middle) {
			cell.setVerticalAlignment(Element.ALIGN_CENTER);
			cell.setHorizontalAlignment(Element.ALIGN_MIDDLE);
		}

		return cell;
	}

	public static Class getExcelCellArgumentType(String className) {
	    try {
	    	if (className.equalsIgnoreCase("DateTime")) {
	    		return Class.forName("java.util.Date");
	     	} else if (className.equalsIgnoreCase("Number")) {
				return (Class) Class.forName("java.lang.Double").getField("TYPE").get(null); // primitive istedi�i i�in
			}
		    return Class.forName("java.lang.String");
	    } catch (Exception e) {
	    	e.printStackTrace();
	    }
		return null;
	}

	public static Object formatExcellCellArgument(String className, String str) {
	    try {
	    	if (className.equalsIgnoreCase("DateTime")) {
	    		return new java.sql.Date(dateFormat.parse(str).getTime());
	     	} else if (className.equalsIgnoreCase("Number")) {
				return StringUtils.isBlank(str) ? 0D : new BigDecimal(str).doubleValue(); 
			}
	    } catch (Exception e) {
	    	e.printStackTrace();
	    }
		return str;
	}

	public static String etractExcellCellClass(String string) {
		if (string==null) {
			return null;
		}
		for (String str : string.split(";")) {
			if (str.equals("DateTime")){
				return "DateTime";	
			} else if (str.equals("Number")){
				return "Number";	
			} else if (str.equals("Label")){
				return "Label";	
			}
		}
		
		return null;
	}
	
	public static Class[] getCellParameterClasses(String className) {
        Class[] results = null;
        try {
	        Class intClass = (Class) Class.forName("java.lang.Integer").getField("TYPE").get(null);
	
			if (className.equals("DateTime")) {
				results = new Class[4];
				results[3] = Class.forName("jxl.format.CellFormat");
			} else {
				results = new Class[3];
			}
			results[0]=intClass;
			results[1]=intClass;
			results[2]=getExcelCellArgumentType(className);

        } catch (Exception e) {
        	e.printStackTrace();
        }
		
		return results;
	}
	
	public static Object[] getCellParameters(int col, int row, Object value, String className) {
		Object[] results = null;
		if (className.equals("DateTime")) {
			results = new Object[4];
			results[3] = cellDateFormat;
		} else {
			results = new Object[3];
		}
		results[0]=col;
		results[1]=row;
		results[2]=value;
		
		return results;
	}
}
