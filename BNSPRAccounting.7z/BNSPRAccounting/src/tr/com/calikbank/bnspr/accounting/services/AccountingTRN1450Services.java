package tr.com.calikbank.bnspr.accounting.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.text.ParseException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import jxl.DateCell;
import jxl.NumberCell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.biff.EmptyCell;
import tr.com.aktifbank.bnspr.dao.GnlGmBankSumSourceDetTx;
import tr.com.aktifbank.bnspr.dao.GnlGmBankSumSourceDetTxId;
import tr.com.aktifbank.bnspr.dao.GnlGmBankSummaryMainTx;
import tr.com.aktifbank.bnspr.dao.GnlGmBankSummarySourceTx;
import tr.com.aktifbank.bnspr.dao.GnlGmBankSummarySourceTxId;
import tr.com.aktifbank.bnspr.dao.GnlGmBankSummaryTx;
import tr.com.aktifbank.bnspr.dao.GnlGmBankSummaryTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1450Services {
	
	@GraymoundService("BNSPR_TRN1450_UPLOAD_EXCEL")
	public static GMMap uploadExcel(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			
			WorkbookSettings setting = new WorkbookSettings();
			setting.setEncoding("ISO-8859-9");
			
			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("EXCEL")), setting);
			Sheet dataSheet1 = workbook.getSheet(0);

			int row = 0;
			String tableName = "DATA_TABLE1";
			for(int i=1; i<dataSheet1.getRows(); i++){
				
				if(dataSheet1.getCell(1, i) instanceof EmptyCell)
					continue;
				
				oMap.put(tableName, row, "DATE",	dateControl(dataSheet1, 0, i));
				oMap.put(tableName, row, "CODE",	dataSheet1.getCell(1, i).getContents());
				oMap.put(tableName, row, "NAME",	nameControl(dataSheet1, 2, i));
				oMap.put(tableName, row, "VALUE",	valueControl(dataSheet1, 3, i));
				oMap.put(tableName, row, "GROUP",	dataSheet1.getCell(4, i).getContents());
				oMap.put(tableName, row, "LEVEL1",	dataSheet1.getCell(5, i).getContents());
				oMap.put(tableName, row, "LEVEL2",	dataSheet1.getCell(6, i).getContents());
				oMap.put(tableName, row, "LEVEL3",	dataSheet1.getCell(7, i).getContents());
				oMap.put(tableName, row, "LEVEL4",	dataSheet1.getCell(8, i).getContents());
				row++;
			}
			
			Sheet dataSheet2 = workbook.getSheet(1);
			
			row = 0;
			tableName = "DATA_TABLE2";
			for(int i=1; i<dataSheet2.getRows(); i++){
				
				if(dataSheet2.getCell(1, i) instanceof EmptyCell)
					continue;
				
				oMap.put(tableName, row, "DATE",	dateControl(dataSheet2, 0, i));
				oMap.put(tableName, row, "CODE",	dataSheet2.getCell(1, i).getContents());
				oMap.put(tableName, row, "NAME",	nameControl(dataSheet2, 2, i));
				oMap.put(tableName, row, "VALUE_TL",valueControl(dataSheet2, 3, i));
				oMap.put(tableName, row, "VALUE_FC",valueControl(dataSheet2, 4, i));
				oMap.put(tableName, row, "TOTAL",	valueControl(dataSheet2, 5, i));
				oMap.put(tableName, row, "GROUP",	dataSheet2.getCell(6, i).getContents());
				oMap.put(tableName, row, "LEVEL1",	dataSheet2.getCell(7, i).getContents());
				oMap.put(tableName, row, "LEVEL2",	dataSheet2.getCell(8, i).getContents());
				oMap.put(tableName, row, "LEVEL3",	dataSheet2.getCell(9, i).getContents());
				oMap.put(tableName, row, "LEVEL4",	dataSheet2.getCell(10, i).getContents());
				row++;
			}
			
			Sheet dataSheet3 = workbook.getSheet(2);
			
			row = 0;
			tableName = "DATA_TABLE3";
			for(int i=1; i<dataSheet3.getRows(); i++){
				
				if(dataSheet3.getCell(1, i) instanceof EmptyCell)
					continue;
				
				oMap.put(tableName, row, "DATE",		dateControl(dataSheet3, 0, i));
				oMap.put(tableName, row, "CODE",		dataSheet3.getCell(1, i).getContents());
				oMap.put(tableName, row, "NAME",		nameControl(dataSheet3, 2, i));
				oMap.put(tableName, row, "VALUE_TL",	valueControl(dataSheet3, 3, i));
				oMap.put(tableName, row, "VALUE_USD",	valueControl(dataSheet3, 4, i));
				oMap.put(tableName, row, "VALUE_EUR",	valueControl(dataSheet3, 5, i));
				oMap.put(tableName, row, "VALUE_OTH",	valueControl(dataSheet3, 6, i));
				oMap.put(tableName, row, "GROUP",		dataSheet3.getCell(7, i).getContents());
				oMap.put(tableName, row, "LEVEL1",		dataSheet3.getCell(8, i).getContents());
				oMap.put(tableName, row, "LEVEL2",		dataSheet3.getCell(9, i).getContents());
				oMap.put(tableName, row, "LEVEL3",		dataSheet3.getCell(10, i).getContents());
				oMap.put(tableName, row, "LEVEL4",		dataSheet3.getCell(11, i).getContents());
				row++;
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN1450_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {	
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			GnlGmBankSummaryMainTx mainTx = (GnlGmBankSummaryMainTx) session.get(GnlGmBankSummaryMainTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(mainTx == null){
				mainTx = new GnlGmBankSummaryMainTx();
			}
			
			mainTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			mainTx.setTarih(new Date());
			mainTx.setDosyaAdi(iMap.getString("FILE_NAME"));
			
			session.saveOrUpdate(mainTx);
			session.flush();
			
			List<GnlGmBankSummaryTx> removalList1 = session.createCriteria(GnlGmBankSummaryTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			for(GnlGmBankSummaryTx delRecord : removalList1){
				session.delete(delRecord);
			}
			session.flush();
			
			String tableName = "DATA_TABLE1";
			for(int i=0; i<iMap.getSize(tableName); i++){
				
				if(iMap.getBigDecimal(tableName, i, "CODE") == null)
					continue;
				
				GnlGmBankSummaryTxId recordId = new GnlGmBankSummaryTxId();
				recordId.setKalem(iMap.getBigDecimal(tableName, i, "CODE"));
				recordId.setTarih(iMap.getDate(tableName, i, "DATE"));
				recordId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				
				GnlGmBankSummaryTx record = new GnlGmBankSummaryTx();
				record.setId(recordId);
				record.setKalemAdi(iMap.getString(tableName, i, "NAME"));
				record.setDeger(iMap.getBigDecimal(tableName, i, "VALUE"));
				record.setGrup(iMap.getString(tableName, i, "GROUP"));
				record.setSeviye1(iMap.getBigDecimal(tableName, i, "LEVEL1"));
				record.setSeviye2(iMap.getBigDecimal(tableName, i, "LEVEL2"));
				record.setSeviye3(iMap.getBigDecimal(tableName, i, "LEVEL3"));
				record.setSeviye4(iMap.getBigDecimal(tableName, i, "LEVEL4"));
				session.save(record);
				
			}
			session.flush();
			
			
			List<GnlGmBankSummarySourceTx> removalList2 = session.createCriteria(GnlGmBankSummarySourceTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			for(GnlGmBankSummarySourceTx delRecord : removalList2){
				session.delete(delRecord);
			}
			session.flush();
			
			
			tableName = "DATA_TABLE2";
			for(int i=0; i<iMap.getSize(tableName); i++){
				
				if(iMap.getBigDecimal(tableName, i, "CODE") == null)
					continue;
				
				GnlGmBankSummarySourceTxId recordId = new GnlGmBankSummarySourceTxId();
				recordId.setKalem(iMap.getBigDecimal(tableName, i, "CODE"));
				recordId.setTarih(iMap.getDate(tableName, i, "DATE"));
				recordId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				
				GnlGmBankSummarySourceTx record = new GnlGmBankSummarySourceTx();
				record.setId(recordId);
				record.setKalemAdi(iMap.getString(tableName, i, "NAME"));
				record.setDegerTl(iMap.getBigDecimal(tableName, i, "VALUE_TL"));
				record.setDegerYp(iMap.getBigDecimal(tableName, i, "VALUE_FC"));
				record.setToplam(iMap.getBigDecimal(tableName, i, "TOTAL"));
				record.setGrup(iMap.getString(tableName, i, "GROUP"));
				record.setSeviye1(iMap.getBigDecimal(tableName, i, "LEVEL1"));
				record.setSeviye2(iMap.getBigDecimal(tableName, i, "LEVEL2"));
				record.setSeviye3(iMap.getBigDecimal(tableName, i, "LEVEL3"));
				record.setSeviye4(iMap.getBigDecimal(tableName, i, "LEVEL4"));
				session.save(record);
				
			}
			session.flush();
			
			
			List<GnlGmBankSumSourceDetTx> removalList3 = session.createCriteria(GnlGmBankSumSourceDetTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			for(GnlGmBankSumSourceDetTx delRecord : removalList3){
				session.delete(delRecord);
			}
			session.flush();
			
			tableName = "DATA_TABLE3";
			for(int i=0; i<iMap.getSize(tableName); i++){
				
				if(iMap.getBigDecimal(tableName, i, "CODE") == null)
					continue;
				
				GnlGmBankSumSourceDetTxId recordId = new GnlGmBankSumSourceDetTxId();
				recordId.setKalem(iMap.getBigDecimal(tableName, i, "CODE"));
				recordId.setTarih(iMap.getDate(tableName, i, "DATE"));
				recordId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				
				GnlGmBankSumSourceDetTx record = new GnlGmBankSumSourceDetTx();
				record.setId(recordId);
				record.setKalemAdi(iMap.getString(tableName, i, "NAME"));
				record.setDegerTl(iMap.getBigDecimal(tableName, i, "VALUE_TL"));
				record.setDegerUsd(iMap.getBigDecimal(tableName, i, "VALUE_USD"));
				record.setDegerEur(iMap.getBigDecimal(tableName, i, "VALUE_EUR"));
				record.setDegerDiger(iMap.getBigDecimal(tableName, i, "VALUE_OTH"));
				record.setGrup(iMap.getString(tableName, i, "GROUP"));
				record.setSeviye1(iMap.getBigDecimal(tableName, i, "LEVEL1"));
				record.setSeviye2(iMap.getBigDecimal(tableName, i, "LEVEL2"));
				record.setSeviye3(iMap.getBigDecimal(tableName, i, "LEVEL3"));
				record.setSeviye4(iMap.getBigDecimal(tableName, i, "LEVEL4"));
				session.save(record);
				
			}
			session.flush();
			
			iMap.put("TRX_NAME", "1450");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN1450_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<GnlGmBankSummaryTx> summaryList = session.createCriteria(GnlGmBankSummaryTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			String tableName = "DATA_TABLE1";
			int row = 0;
			for(GnlGmBankSummaryTx record : summaryList){
				oMap.put(tableName, row, "DATE", record.getId().getTarih());
				oMap.put(tableName, row, "CODE", record.getId().getKalem());
				oMap.put(tableName, row, "NAME", record.getKalemAdi());
				oMap.put(tableName, row, "VALUE", record.getDeger());
				oMap.put(tableName, row, "GROUP", record.getGrup());
				oMap.put(tableName, row, "LEVEL1", record.getSeviye1());
				oMap.put(tableName, row, "LEVEL2", record.getSeviye2());
				oMap.put(tableName, row, "LEVEL3", record.getSeviye3());
				oMap.put(tableName, row, "LEVEL4", record.getSeviye4());
				row++;
			}
			
			List<GnlGmBankSummarySourceTx> summaryList2 = session.createCriteria(GnlGmBankSummarySourceTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			tableName = "DATA_TABLE2";
			row = 0;
			for(GnlGmBankSummarySourceTx record : summaryList2){
				oMap.put(tableName, row, "DATE", record.getId().getTarih());
				oMap.put(tableName, row, "CODE", record.getId().getKalem());
				oMap.put(tableName, row, "NAME", record.getKalemAdi());
				oMap.put(tableName, row, "VALUE_TL", record.getDegerTl());
				oMap.put(tableName, row, "VALUE_FC", record.getDegerYp());
				oMap.put(tableName, row, "TOTAL", record.getToplam());
				oMap.put(tableName, row, "GROUP", record.getGrup());
				oMap.put(tableName, row, "LEVEL1", record.getSeviye1());
				oMap.put(tableName, row, "LEVEL2", record.getSeviye2());
				oMap.put(tableName, row, "LEVEL3", record.getSeviye3());
				oMap.put(tableName, row, "LEVEL4", record.getSeviye4());
				row++;
			}
			
			List<GnlGmBankSumSourceDetTx> summaryList3 = session.createCriteria(GnlGmBankSumSourceDetTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			tableName = "DATA_TABLE3";
			row = 0;
			for(GnlGmBankSumSourceDetTx record : summaryList3){
				oMap.put(tableName, row, "DATE", record.getId().getTarih());
				oMap.put(tableName, row, "CODE", record.getId().getKalem());
				oMap.put(tableName, row, "NAME", record.getKalemAdi());
				oMap.put(tableName, row, "VALUE_TL", record.getDegerTl());
				oMap.put(tableName, row, "VALUE_USD", record.getDegerUsd());
				oMap.put(tableName, row, "VALUE_EUR", record.getDegerEur());
				oMap.put(tableName, row, "VALUE_OTH", record.getDegerDiger());
				oMap.put(tableName, row, "GROUP", record.getGrup());
				oMap.put(tableName, row, "LEVEL1", record.getSeviye1());
				oMap.put(tableName, row, "LEVEL2", record.getSeviye2());
				oMap.put(tableName, row, "LEVEL3", record.getSeviye3());
				oMap.put(tableName, row, "LEVEL4", record.getSeviye4());
				row++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static BigDecimal valueControl(Sheet dataSheet, int column, int row) throws ParseException{
		
		if(dataSheet.getCell(column, row) instanceof NumberCell){
			
			if(dataSheet.getCell(column, row).getContents().contains("%")){
				return new BigDecimal(dataSheet.getCell(column, row).getContents().replace('%', ' ').replace(',', '.').trim());
			}else{
				return new BigDecimal(((NumberCell)dataSheet.getCell(column, row)).getValue());				
			}
			
		}else{
			return null;
		}
		
	}
	
	public static Date dateControl(Sheet dataSheet, int column, int row) throws ParseException{
		
		if(dataSheet.getCell(column, row) instanceof DateCell){
			return ((DateCell)dataSheet.getCell(column, row)).getDate();
		}
		else{
			return null;
		}

	}
	
	public static String nameControl(Sheet dataSheet, int column, int row){
		
		if(dataSheet.getCell(column, row) instanceof EmptyCell){

			return null;

		}else{

			int indent = dataSheet.getCell(column, row).getCellFormat().getIndentation();

			StringBuilder build = new StringBuilder();

			for(int i=0; i<indent; i++){
				build.append(" ");
			}

			return build.append(dataSheet.getCell(column, row).getContents()).toString();
		}
		
	}
	
	@GraymoundService("BNSPR_TRN1450_SAVE_TO_BI_ASYNC")
	public static GMMap saveBI(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		try{
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call BIAPP.PKG_DWH_INTG.P_GM_GET_DATA}");
			stmt.execute();

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
