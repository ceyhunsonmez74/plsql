package tr.com.calikbank.bnspr.accounting.services;

import java.sql.Types;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EdefterislemPrTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1130Services {
    
    @GraymoundService("BNSPR_TRN1130_INITIALIZE")
    public static GMMap initalize(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        try{
            
            oMap.put("TRX_NO" , DALUtil.callNoParameterFunction("{{? = call PKG_TRN1130.get_initial}" , Types.NUMERIC));
            
            EdefterislemPrTx eDefter = (EdefterislemPrTx) session.createCriteria(EdefterislemPrTx.class).add(Restrictions.eq("id.txNo" , oMap.getBigDecimal("TRX_NO"))).uniqueResult();
            
            oMap.put("AY" , eDefter.getId().getAy());
            oMap.put("YIL" , eDefter.getId().getYil());
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN1130_SAVE")
    public static GMMap save(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            
            iMap.put("TRX_NAME" , "1130");
            oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN1130_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            
            Session session = DAOSession.getSession("BNSPRDal");
            try{
                EdefterislemPrTx eDefterTx = (EdefterislemPrTx) session.createCriteria(EdefterislemPrTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
                oMap.put("AY" , eDefterTx.getId().getAy());
                oMap.put("YIL" , eDefterTx.getId().getYil());
                
            } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
}
