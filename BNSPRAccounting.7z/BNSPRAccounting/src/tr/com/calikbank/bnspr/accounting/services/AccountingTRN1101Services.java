package tr.com.calikbank.bnspr.accounting.services;
 


import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhSbaFisTx;
import tr.com.calikbank.bnspr.dao.MuhSbaSatirTx;
import tr.com.calikbank.bnspr.dao.MuhSbaSatirTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1101Services {

	@GraymoundService("BNSPR_TRN1101_GET_BA_TUR_KODS")
	public static GMMap getBAKods(GMMap iMap) {
		GMMap oMap = new GMMap();
		String listName = "BA_KODS";
		GuimlUtil.wrapMyCombo(oMap, listName, "A", "Alacak");
		GuimlUtil.wrapMyCombo(oMap, listName, "B", "Borc");
		
		listName = "TUR_KODS";
		GuimlUtil.wrapMyCombo(oMap, listName, "VS", "VS");
		GuimlUtil.wrapMyCombo(oMap, listName, "VD", "VD");
		GuimlUtil.wrapMyCombo(oMap, listName, "KR", "KR");
		GuimlUtil.wrapMyCombo(oMap, listName, "DK", "DK");
		
		oMap.put("PARAM_DEGER", DALUtil.getResult("select pkg_parametre.Deger_Al_K('TRN1100_MUSTERILI_ISLEME_ACIK') from dual"));
		return oMap;
	}

	/*
	 * bu servis HESAP_NO parametresi ile istenen hesab�n bakiyesini ve Hesab�n
	 * personele ait olup olmad���n� d�nd�r�r.
	 */
	@GraymoundService("BNSPR_TRN1101_GET_ACCOUNT_BALANCE")
	public static GMMap getAccountBalance(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		BigDecimal hesapNo = iMap.getBigDecimal("HESAP_NO");
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_hesap.HesapBakiyeAl(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, hesapNo);
			stmt.execute();
			Object obj = stmt.getObject(1);
			oMap.put("BALANCE", obj);
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_hesap.Kullanilabilir_Bakiye_Al(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, hesapNo);
			stmt.execute();
			Object obj = stmt.getObject(1);
			oMap.put("USABLE_BALANCE", obj);
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call pkg_hesap.Personel_Bakiye_Gosterilsin(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, hesapNo);
			stmt.execute();
			Object obj = stmt.getObject(1);
			oMap.put("PERSONELMI", obj);
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	/*
	 * bu servis Banka Tarihini ve Kullan�c� Kodunu d�nd�r�r
	 */
	@GraymoundService("BNSPR_TRN1101_GET_TARIH_AND_KULLANICI")
	public static GMMap getTarihKullanici(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_muhasebe.Banka_Tarihi_Bul}");
			stmt.registerOutParameter(1, Types.DATE);
			stmt.execute();
			oMap.put("BANKA_TARIH", stmt.getDate(1));
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_muhasebe.Sonraki_Banka_Tarihi_Bul}");
			stmt.registerOutParameter(1, Types.DATE);
			stmt.execute();
			oMap.put("SONRAKI_BANKA_TARIHI", stmt.getDate(1));
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_global.GET_KULLANICIKOD}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();
			Object obj = stmt.getObject(1);
			oMap.put("KULLANICI_KOD", obj);
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	/*
	 * bu servis Yerli Para birimi cinsinden tutar� d�nd�r�r
	 */
	@GraymoundService("BNSPR_TRN1101_GET_LC_TUTAR")
	public static GMMap getLCTutar(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		String baTur = iMap.getString("BA_TUR");
		String hesapTurKod = iMap.getString("HESAP_TUR_KODU");
		String dovizKodu = iMap.getString("DOVIZ_KODU");
		BigDecimal hesapNo = iMap.getBigDecimal("HESAP_NO");
		BigDecimal dvTutar = iMap.getBigDecimal("DV_TUTAR");
		BigDecimal kur = iMap.getBigDecimal("KUR");
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call pkg_trn1101.LC_TUTAR_HESAPLA (?, ?, ?, ?, ?, ?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, baTur);
			stmt.setString(3, hesapTurKod);
			stmt.setString(4, dovizKodu);
			stmt.setBigDecimal(5, hesapNo);
			stmt.setBigDecimal(6, dvTutar);
			stmt.setBigDecimal(7, kur);
			stmt.execute();
			Object obj = stmt.getObject(1);
			oMap.put("LC_TUTAR", obj);
		} catch (SQLException e) {
			//throw new GMRuntimeException(0, e);
		    throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	
	/*
	 * bu verilen para birimi i�in kuru d�nd�r�r
	 */
	@GraymoundService("BNSPR_TRN1101_GET_KUR")
	public static GMMap getKur(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_kur.DOVIZ_CEVIR (?,pkg_genel_pr.lc_al, ?, 1,1, null, null, 'N', 'A')}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			String dovizKodu = iMap.getString("DOVIZ_KODU");
			stmt.setString(2, dovizKodu);
			//if (!(iMap.get("TARIH") == null)) {
				
			//}else{
				//stmt.setDate(3, null);
			//}
			stmt.setDate(3, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			stmt.execute();
			//Object obj = stmt.getBigDecimal(1);
			oMap.put("KUR", stmt.getBigDecimal(1));
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} catch (ParseException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	/*
	 * 
	 */
@GraymoundService("BNSPR_TRN1101_SAVE_SBA")
public static Map<?, ?> saveSBA(GMMap iMap) {
	try {
			Session session = DAOSession.getSession("BNSPRDal");
	
			MuhSbaFisTx muhSbaFisTx = (MuhSbaFisTx)session.get(MuhSbaFisTx.class, iMap.getBigDecimal("TRX_NO"));
			if(muhSbaFisTx == null){
				muhSbaFisTx = new MuhSbaFisTx();
			}
			muhSbaFisTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			muhSbaFisTx.setUrunSinif(iMap.getString("URUN_SINIF"));
			muhSbaFisTx.setAciklama(iMap.getString("ACIKLAMA"));
			muhSbaFisTx.setRecOwner(iMap.getString("YARATAN_KULLANICI_KODU"));
			muhSbaFisTx.setGecerliOlduguTarih(iMap.getDate("GECERLI_OLDUGU_TARIH"));
			muhSbaFisTx.setRecDate(iMap.getDate("YARATILDIGI_TARIH"));
			muhSbaFisTx.setAmountLcDb(iMap.getBigDecimal("K_AMOUNT_LC_DB"));
			muhSbaFisTx.setAmountLcCr(iMap.getBigDecimal("K_AMOUNT_LC_CR"));
			
			
			session.saveOrUpdate(muhSbaFisTx);
			
			List<?> satirPersistenceList = session.createCriteria(MuhSbaSatirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = satirPersistenceList.iterator(); iterator.hasNext();) {  //id.txNo // id.muhSbaFisTx.txNo txNo
				MuhSbaSatirTx muhSbaSatirTx = (MuhSbaSatirTx) iterator.next();
				session.delete(muhSbaSatirTx);
			}
            
			session.flush();
			
			String tableName = "SATIR_BILGILERI";
			int j = 1;
			List<?> satirBilgileri = (List<?>) iMap.get(tableName);
			for (int i = 0; i < satirBilgileri.size(); i++) {
				MuhSbaSatirTx muhSbaSatirTx = new MuhSbaSatirTx();
				muhSbaSatirTx.setTur(iMap.getString(tableName, i, "TUR"));
				muhSbaSatirTx.setHesapSubeKodu(iMap.getString(tableName,i, "HESAP_BOLUM_KODU"));
				muhSbaSatirTx.setHesapTurKodu(iMap.getString(tableName,i, "HESAP_TUR_KODU"));
				muhSbaSatirTx.setHesapNumara(iMap.getString(tableName, i, "HESAP_NUMARA"));
				muhSbaSatirTx.setMusteriNo(iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
				muhSbaSatirTx.setDovizKod(iMap.getString(tableName, i, "DOVIZ_KOD"));
				muhSbaSatirTx.setKur(iMap.getBigDecimal(tableName, i, "KUR"));
				muhSbaSatirTx.setDvTutar(iMap.getBigDecimal(tableName,i, "DV_TUTAR"));
				muhSbaSatirTx.setLcTutar(iMap.getBigDecimal(tableName,i, "LC_TUTAR"));
				muhSbaSatirTx.setValorTarihi(iMap.getDate(tableName, i, "VALOR_TARIHI"));
				muhSbaSatirTx.setBankaAciklama(iMap.getString(tableName, i, "BA"));
				muhSbaSatirTx.setMusteriAciklama(iMap.getString(tableName, i, "MA"));
				muhSbaSatirTx.setReferans(iMap.getString(tableName, i, "RF"));
				muhSbaSatirTx.setIstatistikKodu(iMap.getString(tableName, i, "SK"));
				muhSbaSatirTx.setBolumKodu(iMap.getString(tableName, i, "BOLUMKODU"));
				MuhSbaSatirTxId id = new MuhSbaSatirTxId();
				id.setNumara(new BigDecimal(j++)); //s�ra numaras� servis taraf�ndan veriliyor
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				//id.setMuhSbaFisTx(muhSbaFisTx);
				//id.TxNo   (txNo)  setMuhSbaFisTx(muhSbaFisTx);   
				muhSbaSatirTx.setId(id);
				muhSbaFisTx.getMuhSbaSatirTxes().add(muhSbaSatirTx);
				
				session.save(muhSbaSatirTx);
			}
			
			session.flush();
			
		    if(iMap.getBoolean("TEMP_SAVE")){
		    	iMap.put("TRX_NAME", iMap.getString("EKRAN_NO"));
		    	return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION_TEMP", iMap);
		    }else{
		    	iMap.put("TRX_NAME", iMap.getString("EKRAN_NO"));
				return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		    }
	} catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	}
}
	
	/*
	 * 
	 */
	@GraymoundService("BNSPR_TRN1101_GET_SBA")
	public static GMMap getSBA(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		Connection conn = null;
		CallableStatement stmt = null;
		MuhSbaFisTx muhSbaFisTx = (MuhSbaFisTx)session.get(MuhSbaFisTx.class, iMap.getBigDecimal("TRX_NO"));
		oMap.put("URUN_SINIF", muhSbaFisTx.getUrunSinif());
		oMap.put("ACIKLAMA", muhSbaFisTx.getAciklama());
		oMap.put("YARATAN_KULLANICI_KODU", muhSbaFisTx.getRecOwner());
		oMap.put("GECERLI_OLDUGU_TARIH", muhSbaFisTx.getGecerliOlduguTarih());
		oMap.put("YARATILDIGI_TARIH", muhSbaFisTx.getRecDate());
		oMap.put("K_AMOUNT_LC_DB", muhSbaFisTx.getAmountLcDb());
		oMap.put("K_AMOUNT_LC_CR", muhSbaFisTx.getAmountLcCr());
		
		try{
			conn = DALUtil.getGMConnection();

			List<?> satirPersistenceList = session.createCriteria(MuhSbaSatirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "MUH_SBA_SATIR";   //id.muhSbaFisTx.txNo
			for (int i = 0; i < satirPersistenceList.size(); i++) {
				MuhSbaSatirTx muhSbaSatirTx = (MuhSbaSatirTx) satirPersistenceList.get(i);
				oMap.put(tableName, i, "TUR", muhSbaSatirTx.getTur());
				oMap.put(tableName, i, "HESAP_BOLUM_KODU", muhSbaSatirTx.getHesapSubeKodu());
				oMap.put(tableName, i, "HESAP_TUR_KODU", muhSbaSatirTx.getHesapTurKodu());
				oMap.put(tableName, i, "HESAP_NUMARA", muhSbaSatirTx.getHesapNumara());
				
				ArrayList<Object> lovInputList = new ArrayList<Object>();
				lovInputList.add(muhSbaSatirTx.getHesapTurKodu());
				lovInputList.add(muhSbaSatirTx.getHesapSubeKodu());
				lovInputList.add(muhSbaSatirTx.getMusteriNo());
				lovInputList.add(muhSbaSatirTx.getHesapTurKodu());
				lovInputList.add(muhSbaSatirTx.getHesapSubeKodu());
				lovInputList.add(muhSbaSatirTx.getMusteriNo());
				lovInputList.add(muhSbaSatirTx.getHesapTurKodu());
				lovInputList.add(muhSbaSatirTx.getHesapSubeKodu());
				lovInputList.add(muhSbaSatirTx.getMusteriNo());
				lovInputList.add(muhSbaSatirTx.getHesapTurKodu());
				lovInputList.add(muhSbaSatirTx.getHesapSubeKodu());
				//lovInputList.add(muhSbaSatirTx.getBolumKodu());
				oMap.put(tableName, i, "HA", LovHelper.diLov(muhSbaSatirTx.getHesapNumara(), "1101/LOV_HESAPLAR","KISA_ISIM",lovInputList));
				oMap.put(tableName, i, "UT", LovHelper.diLov(muhSbaSatirTx.getHesapNumara(), "1101/LOV_HESAPLAR","URUN_TUR_KOD",lovInputList));
				oMap.put(tableName, i, "US", LovHelper.diLov(muhSbaSatirTx.getHesapNumara(), "1101/LOV_HESAPLAR","URUN_SINIF_KOD",lovInputList));
				oMap.put(tableName, i, "MUSTERI_ADI", LovHelper.diLov(muhSbaSatirTx.getHesapNumara(), "1101/LOV_HESAPLAR","ISIM",lovInputList));
				oMap.put(tableName, i, "HESAP_ADI", LovHelper.diLov(muhSbaSatirTx.getHesapNumara(), "1101/LOV_HESAPLAR","KISA_ISIM",lovInputList));
				oMap.put(tableName, i, "MUSTERI_NO", muhSbaSatirTx.getMusteriNo());
				oMap.put(tableName, i, "DOVIZ_KOD", muhSbaSatirTx.getDovizKod());
				oMap.put(tableName, i, "KUR", muhSbaSatirTx.getKur());
				oMap.put(tableName, i, "DV_TUTAR", muhSbaSatirTx.getDvTutar());
				oMap.put(tableName, i, "LC_TUTAR", muhSbaSatirTx.getLcTutar());
				oMap.put(tableName, i, "VALOR_TARIHI", muhSbaSatirTx.getValorTarihi());
				oMap.put(tableName, i, "BA", muhSbaSatirTx.getBankaAciklama());
				oMap.put(tableName, i, "MA", muhSbaSatirTx.getMusteriAciklama());
				oMap.put(tableName, i, "RF", muhSbaSatirTx.getReferans());
				oMap.put(tableName, i, "SK", muhSbaSatirTx.getIstatistikKodu());
				oMap.put(tableName, i, "NUMARA", muhSbaSatirTx.getId().getNumara());
				
				
				oMap.put(tableName, i, "BOLUMKODU", muhSbaSatirTx.getBolumKodu());
			//	oMap.put(tableName, i, "BOLUMADI", LovHelper.diLov(muhSbaSatirTx.getBolumKodu(), "1101/LOV_BOLUM_KODU", "ADI"));
			
				if(muhSbaSatirTx.getBolumKodu()==(null))
					oMap.put(null,muhSbaSatirTx.getBolumKodu());
				else{
					stmt = conn.prepareCall("{?=call pkg_genel_pr.bolum_adi(?)}");
					stmt.registerOutParameter(1, Types.VARCHAR);
					stmt.setString(2, muhSbaSatirTx.getBolumKodu());
					stmt.execute();
					oMap.put(tableName, i,"BOLUMADI", stmt.getString(1));
				}
				
			}
			
			return oMap;
		
		} 
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	


	@GraymoundService("BNSPR_TRN1101_GET_DI_URUN_SINIF")
	public static GMMap getDiUrunSinif(GMMap iMap){
		GMMap oMap = new GMMap();
		oMap.put("DI_URUN_SINIF", LovHelper.diLov("SBA", "1101/LOV_URUN_SINIF", "ACIKLAMA"));
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1101_IMPORT_EXCEL")
	public static GMMap importExcel (GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			byte[] inputFile = (byte[]) iMap.get("FILE");
            if (inputFile == null) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Dosya se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Workbook workbook;
            WorkbookSettings ws = new WorkbookSettings();

            //ws.setCharacterSet(cs);
            ws.setEncoding("ISO-8859-9");
            ws.setExcelDisplayLanguage("TR");
            ws.setExcelRegionalSettings("TR");
            ws.setLocale(new Locale("tr", "TR"));
            try {
                workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
            } catch (Exception e) {
                iMap.put("HATA_NO", new BigDecimal(660));
                iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
            }
            Sheet sheet = workbook.getSheet(0);
            String tableName = "MUH_SBA_SATIR";   //id.muhSbaFisTx.txNo
            for (int j = 0; j < sheet.getRows(); j++) {
            	if(!StringUtils.isEmpty(sheet.getCell(0, j).getContents())){
	                	
	                	oMap.put(tableName, j, "TUR", sheet.getCell(0, j).getContents());
	                	oMap.put(tableName, j, "HESAP_BOLUM_KODU", sheet.getCell(1, j).getContents());
	                	oMap.put(tableName, j, "HESAP_TUR_KODU", sheet.getCell(2, j).getContents());
	                	oMap.put(tableName, j, "HESAP_NUMARA",sheet.getCell(3, j).getContents());
	    				
	    				ArrayList<Object> lovInputList = new ArrayList<Object>();
	    				lovInputList.add(sheet.getCell(2, j).getContents());
	    				lovInputList.add(sheet.getCell(1, j).getContents());
	    				lovInputList.add("");
	    				lovInputList.add(sheet.getCell(2, j).getContents());
	    				lovInputList.add(sheet.getCell(1, j).getContents());
	    				lovInputList.add("");
	    				lovInputList.add(sheet.getCell(2, j).getContents());
	    				lovInputList.add(sheet.getCell(1, j).getContents());
	    				lovInputList.add("");
	    				lovInputList.add(sheet.getCell(2, j).getContents());
	    				lovInputList.add(sheet.getCell(1, j).getContents());
	    				//lovInputList.add(muhSbaSatirTx.getBolumKodu());
	    				oMap.put(tableName, j, "HA", LovHelper.diLov(sheet.getCell(3, j).getContents(), "1101/LOV_HESAPLAR","KISA_ISIM",lovInputList));
	    				oMap.put(tableName, j, "UT", LovHelper.diLov(sheet.getCell(3, j).getContents(), "1101/LOV_HESAPLAR","URUN_TUR_KOD",lovInputList));
	    				oMap.put(tableName, j, "US", LovHelper.diLov(sheet.getCell(3, j).getContents(), "1101/LOV_HESAPLAR","URUN_SINIF_KOD",lovInputList));
	    				oMap.put(tableName, j, "MUSTERI_ADI", LovHelper.diLov(sheet.getCell(3, j).getContents(), "1101/LOV_HESAPLAR","ISIM",lovInputList));
	    				oMap.put(tableName, j, "HESAP_ADI", LovHelper.diLov(sheet.getCell(3, j).getContents(), "1101/LOV_HESAPLAR","KISA_ISIM",lovInputList));
	    				oMap.put(tableName, j, "MUSTERI_NO", LovHelper.diLov(sheet.getCell(3, j).getContents(), "1101/LOV_HESAPLAR","MUSTERI_NO",lovInputList));
	    				oMap.put(tableName, j, "DOVIZ_KOD", sheet.getCell(4, j).getContents());
	    				oMap.put(tableName, j, "KUR", sheet.getCell(5, j).getContents().replace(",","."));
	    				oMap.put(tableName, j, "DV_TUTAR", sheet.getCell(6, j).getContents().replace(",","."));
	    				oMap.put(tableName, j, "LC_TUTAR", BigDecimal.valueOf(Double.valueOf(sheet.getCell(6, j).getContents().replace(",","."))).multiply(BigDecimal.valueOf(Double.valueOf(sheet.getCell(5, j).getContents().replace(",",".")))).setScale(2,RoundingMode.HALF_UP));
	    				
	    				oMap.put(tableName, j, "VALOR_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
	    				oMap.put(tableName, j, "BA", sheet.getCell(7, j).getContents());
	    				oMap.put(tableName, j, "MA", sheet.getCell(8, j).getContents());
	    				//oMap.put(tableName, i, "RF", muhSbaSatirTx.getReferans());
	    				//oMap.put(tableName, i, "SK", muhSbaSatirTx.getIstatistikKodu());
	    				oMap.put(tableName, j, "NUMARA", j+1);
	    				
	    				
	    				oMap.put(tableName, j, "BOLUMKODU", sheet.getCell(9, j).getContents());
	    				if(!StringUtil.isEmpty(sheet.getCell(9, j).getContents()))
	    				oMap.put(tableName, j, "BOLUMADI", LovHelper.diLov(sheet.getCell(9, j).getContents(), "1101/LOV_BOLUM_KODU","ADI"));
	    				
            	}
            }
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
}

