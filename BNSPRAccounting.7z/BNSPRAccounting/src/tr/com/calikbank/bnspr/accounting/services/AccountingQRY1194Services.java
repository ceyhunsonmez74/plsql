package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class AccountingQRY1194Services {
	
	@GraymoundService("BNSPR_QRY1194_SORGULA")
	public static GMMap sorgula(GMMap iMap){
		Connection 			conn	= null;
		CallableStatement 	stmt	= null;
		ResultSet 			rSet	= null;
		try{
	        GMMap oMap = new GMMap();
	        int i;
	        Date firstDate = iMap.getDate("TARIH")!= null ? new java.sql.Date(iMap.getDate("TARIH").getTime()) : null;

	        conn = DALUtil.getGMConnection();

            // M��teri Limit-Risk
            {
                stmt = conn.prepareCall("{? = call PKG_RC_ACCOUNTING.RC_QRY1194_GET_LIMIT_RISK(?)}");
                i = 1;
                stmt.registerOutParameter(i++, -10);
                stmt.setDate(i++, firstDate);
                stmt.execute();
    
                rSet = (ResultSet) stmt.getObject(1);
                
                oMap.putAll(DALUtil.rSetResults(rSet, "MUSTERI_LIMIT_RISK"));
            }

            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            
            // Grup Limitleri
            {
                stmt = conn.prepareCall("{? = call PKG_RC_ACCOUNTING.RC_QRY1194_GET_GRUP_LIMITLERI(?)}");
                i = 1;
                stmt.registerOutParameter(i++, -10);
                stmt.setDate(i++, firstDate);
                stmt.execute();
    
                rSet = (ResultSet) stmt.getObject(1);
                
                oMap.putAll(DALUtil.rSetResults(rSet, "GRUP_LIMITLERI"));
            }

            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            
            // S�zle�meler
            {
                stmt = conn.prepareCall("{? = call PKG_RC_ACCOUNTING.RC_QRY1194_GET_SOZLESMELER(?)}");
                i = 1;
                stmt.registerOutParameter(i++, -10);
                stmt.setDate(i++, firstDate);
                stmt.execute();
    
                rSet = (ResultSet) stmt.getObject(1);
                
                oMap.putAll(DALUtil.rSetResults(rSet, "SOZLESMELER"));
            }
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
