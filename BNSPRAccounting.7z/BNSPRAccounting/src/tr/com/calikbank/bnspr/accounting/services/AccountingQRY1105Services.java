package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingQRY1105Services {

	@GraymoundService("BNSPR_QRY1105_GET_MUH_FIS_RECORD")
	public static GMMap getMuhFisRecord(GMMap iMap)throws ParseException  {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call Pkg_genel_pr.islem_ekran_adi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR); //ref cursor
			stmt.setBigDecimal(2,iMap.getBigDecimal("ISLEM_NO"));
			stmt.execute();
			oMap.put("EKRAN_ADI", stmt.getString(1));
			
			stmt = conn.prepareCall("{? = call pkg_rc_accounting.RC_QRY1105_GET_MUH_FIS_RECORD(?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++,iMap.getBigDecimal("NUMARA"));//fi� no giriliyog
			stmt.setBigDecimal(i++,iMap.getBigDecimal("ISLEM_NO"));

			if (!(iMap.get("BAS_TARIH") == null)) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			}else{
				stmt.setDate(i++, null);
			}

			if (!(iMap.get("SON_TARIH") == null)) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("SON_TARIH").getTime()));
			}else{
				stmt.setDate(i++, null);
			}

			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);

			String tableName = "SATIR_BILGILERI";

			BigDecimal alacak = new BigDecimal(0);
			BigDecimal borc = new BigDecimal(0);

			int j = 0;
			while (rSet.next()) {
				oMap.put(tableName, j, "NUMARA", rSet.getString("fis_numara"));
				GMMap aMap = new GMMap();
				/*aMap.put("KOD", "MUHFIS_TUR_KOD");
				aMap.put("KEY", rSet.getString("fis_tur"));
				oMap.put(tableName, j, "TUR", GMServiceExecuter.execute("BNSPR_COMMON_GET_PARAM_TEXT", aMap).get("TEXT"));
                 */
				oMap.put(tableName, j, "TUR", rSet.getString("tur"));
				oMap.put(tableName, j, "BOLUM", rSet.getString("satir_hesap_bolum_kodu"));
				oMap.put(tableName, j, "HESAP_NUMARA", rSet.getString("satir_hesap_numara"));
				oMap.put(tableName, j, "VALOR_TARIHI", rSet.getDate("satir_valor_tarihi"));

				oMap.put(tableName, j, "NDB_LC_TUTAR", rSet.getString("satir_lc_tutar"));			
				oMap.put(tableName, j, "NDB_FC_TUTAR", rSet.getString("satir_dv_tutar"));

				if (rSet.getString("b_a").equals("A"))
					alacak = alacak.add(rSet.getBigDecimal("satir_lc_tutar"));
				else
					borc = borc.add(rSet.getBigDecimal("satir_lc_tutar"));

				oMap.put(tableName, j, "DOVIZ", rSet.getString("satir_doviz_kod"));
				oMap.put(tableName, j, "BANKA_ACIKLAMA", rSet.getString("satir_banka_aciklama"));
				oMap.put(tableName, j, "FIS_ACIKLAMA", rSet.getString("fis_aciklama"));
				oMap.put(tableName, j, "MUSTERI_ACIKLAMA", rSet.getString("satir_musteri_aciklama"));
				oMap.put(tableName, j, "REFERANS", rSet.getString("satir_referans"));
				oMap.put(tableName, j, "MUSTERI_HESAP_TUR", rSet.getString("satir_musteri_hesap_tur"));
				oMap.put(tableName, j, "MUSTERI_HESAP_NUMARA", rSet.getString("satir_musteri_hesap_numara"));
				oMap.put(tableName, j, "ISTATISTIK_KODU", rSet.getString("satir_istatistik_kodu"));
				oMap.put(tableName, j, "MUHASEBELESTIGI_TARIH", rSet.getDate("fis_muhasebelestigi_tarih"));
				oMap.put(tableName, j, "YARATAN_KULLANICI_KODU", rSet.getString("yaratan_kullanici_kodu"));
				oMap.put(tableName, j, "DOGRULAYAN_KULLANICI_KODU", rSet.getString("dogrulayan_kullanici"));
				
				oMap.put(tableName, j, "ACIKLAMA", rSet.getString("fis_aciklama"));
				oMap.put(tableName, j, "KUR", rSet.getString("kur"));
				oMap.put(tableName, j, "BORC_ALACAK",rSet.getString("b_a"));
				oMap.put(tableName, j, "MUSTERI_NO", rSet.getBigDecimal("MUSTERI_NO"));
				oMap.put(tableName, j, "UNVAN", rSet.getString("UNVAN"));
				oMap.put(tableName, j, "DK_HESAP_ADI", rSet.getString("DK_HESAP_ADI"));
				oMap.put(tableName, j, "KAYIT_KULLANICI_KODU", rSet.getString("kayit_kullanici_kodu"));
				j++;
			}

			oMap.put("ALACAK", alacak);
			oMap.put("BORC", borc);
			oMap.put("BALANS", alacak.add(borc));

			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY1105_GET_MUH_FC_TOTAL")
	public static GMMap getMuhFcTotal(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_accounting.RC_QRY1105_GET_MUH_FC_TOTAL(?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor 
			stmt.setBigDecimal(i++, iMap.getBigDecimal("NUMARA"));


			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);

			String tableName = "FC_TOPLAM";
			GMMap oMap = new GMMap();
			int j = 0;
			while (rSet.next()) {

				oMap.put(tableName,j, "DOVIZ_KOD", rSet.getString(1));
				oMap.put(tableName,j, "NDB_DV_TUTAR_ALACAK", rSet.getString(2));
				oMap.put(tableName,j, "NDB_DV_TUTAR_BORC", rSet.getString(3));
				j++;
			}

			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/*Son Onaylama Saati olmadigi i�in Fis saatten cekiliyor. */
	@GraymoundService("BNSPR_QRY1105_GET_SON_ONAYLAMA_SAATI")
	public static GMMap getSonOnaylamaSaati(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_rc_accounting.RC_QRY1105_fis_saat(?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);

			stmt.setBigDecimal(2, iMap.getBigDecimal("FIS_NUMARA"));

			stmt.execute();

			oMap.put("SAAT", stmt.getString(1));

			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}

