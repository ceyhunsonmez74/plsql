package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MuhHesapUrunDegisiklikTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1116Services {
	
    
    @GraymoundService("BNSPR_TRN1116_COMMON_GET_COMBO_PARAMETERS")
    public static GMMap getComboParameter(GMMap iMap) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rSet = null;
        try {
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareStatement("SELECT distinct KEY1, TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = ? ORDER BY KEY1");
            stmt.setString(1, iMap.getString("KOD"));
            rSet = stmt.executeQuery();

            String listName = "RESULTS";
           
            while (rSet.next()) {
                GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString(1), rSet.getString(2));
            }

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
	@GraymoundService("BNSPR_TRN1116_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			MuhHesapUrunDegisiklikTx muhHesapUrunDegisiklikTx = (MuhHesapUrunDegisiklikTx) session.createCriteria(MuhHesapUrunDegisiklikTx.class)
																							.add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
																							.uniqueResult();
			if(muhHesapUrunDegisiklikTx == null){
				muhHesapUrunDegisiklikTx = new MuhHesapUrunDegisiklikTx();
			}
			
			muhHesapUrunDegisiklikTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			iMap.put("TABLE_NAME","MUH_HESAP_URUN_DEGISIKLIK");
			muhHesapUrunDegisiklikTx.setId((BigDecimal)GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", iMap).get("ID"));
			muhHesapUrunDegisiklikTx.setIslemTuru(iMap.getBigDecimal("ISLEM_TURU"));
			muhHesapUrunDegisiklikTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			muhHesapUrunDegisiklikTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			muhHesapUrunDegisiklikTx.setTeklifUrunGrupKod(iMap.getBigDecimal("URUN_GRUP_NO"));
			muhHesapUrunDegisiklikTx.setYeniUrunTur(iMap.getString("URUN_TUR_KOD"));
			muhHesapUrunDegisiklikTx.setModulTurKod(iMap.getString("MODUL_TUR_KOD"));
			muhHesapUrunDegisiklikTx.setUrunTur(iMap.getString("OLD_URUN_TUR_KOD"));
			muhHesapUrunDegisiklikTx.setYeniUrunSinif(iMap.getString("URUN_SINIF_KOD"));
			muhHesapUrunDegisiklikTx.setUrunSinif(iMap.getString("OLD_URUN_SINIF_KOD"));
			muhHesapUrunDegisiklikTx.setYeniDkHesapNo(iMap.getString("DK_HESAP_NO"));
			muhHesapUrunDegisiklikTx.setDkHesapNo(iMap.getString("OLD_DK_HESAP_NO"));
			
			session.saveOrUpdate(muhHesapUrunDegisiklikTx);
			session.flush();
			
			iMap.put("TRX_NAME", "1116");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1116_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		
		GMMap oMap = new GMMap();
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			MuhHesapUrunDegisiklikTx muhHesapUrunDegisiklikTx = (MuhHesapUrunDegisiklikTx) session.createCriteria(MuhHesapUrunDegisiklikTx.class)
																							.add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
																							.uniqueResult();
			
			oMap.put("ISLEM_TURU", muhHesapUrunDegisiklikTx.getIslemTuru());
			oMap.put("HESAP_NO", muhHesapUrunDegisiklikTx.getHesapNo());
			oMap.put("DK_KOD", LovHelper.diLov(muhHesapUrunDegisiklikTx.getHesapNo(), muhHesapUrunDegisiklikTx.getIslemTuru(),muhHesapUrunDegisiklikTx.getMusteriNo(), getLov(oMap), "DK_GRUP_KOD"));
			oMap.put("MUSTERI_NO", muhHesapUrunDegisiklikTx.getMusteriNo());
			oMap.put("UNVAN", LovHelper.diLov(muhHesapUrunDegisiklikTx.getHesapNo(), muhHesapUrunDegisiklikTx.getIslemTuru(),muhHesapUrunDegisiklikTx.getMusteriNo(), getLov(oMap), "UNVAN"));
			oMap.put("URUN_GRUP_NO", LovHelper.diLov(muhHesapUrunDegisiklikTx.getHesapNo(), muhHesapUrunDegisiklikTx.getIslemTuru(),muhHesapUrunDegisiklikTx.getMusteriNo(), getLov(oMap), "URUN_GRUP_NO"));
			oMap.put("ACIKLAMA", LovHelper.diLov(muhHesapUrunDegisiklikTx.getHesapNo(), muhHesapUrunDegisiklikTx.getIslemTuru(),muhHesapUrunDegisiklikTx.getMusteriNo(),  getLov(oMap), "ACIKLAMA"));
			oMap.put("MODUL_TUR_KOD", muhHesapUrunDegisiklikTx.getModulTurKod());
			oMap.put("URUN_TUR_KOD", muhHesapUrunDegisiklikTx.getYeniUrunTur());
			oMap.put("URUN_SINIF_KOD", muhHesapUrunDegisiklikTx.getYeniUrunSinif());
			oMap.put("DK_HESAP_NO", muhHesapUrunDegisiklikTx.getYeniDkHesapNo());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	public static String getLov(GMMap oMap){
		
		String islemTuru = oMap.getString("ISLEM_TURU");
		String lovName = "1116/LOV_HESAP_NO1";
		return lovName;
	}
	
}
