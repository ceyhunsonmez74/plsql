package tr.com.calikbank.bnspr.accounting.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.text.DateFormat;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MuhGeciciHesapTanimTx;
import tr.com.aktifbank.bnspr.dao.MuhGeciciHesapTanimTxId;
import tr.com.aktifbank.bnspr.dao.SwftMt940HesapTanimTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1125Services {
	
    @GraymoundService("BNSPR_TRN1125_SAVE")
    public static Map<?, ?>  saveParameters(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        
        try {
        	conn = DALUtil.getGMConnection();
            Session session = DAOSession.getSession("BNSPRDal");

        
            ArrayList<?> list = (ArrayList<?>) session.createCriteria(MuhGeciciHesapTanimTx.class).add(Restrictions.eq("id.txNo",iMap.getBigDecimal("TRX_NO"))).list();
            for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
                MuhGeciciHesapTanimTx muhGeciciHesapTanimTx = (MuhGeciciHesapTanimTx) iterator.next();
                session.delete(muhGeciciHesapTanimTx);
            }
            session.flush();
            
            
            String tableName = "TBL_GECICI_HESAP_TANIMLAMA";
            int rowCount = iMap.getSize(tableName);
            for (int i = 0; i < rowCount; i++) {

                MuhGeciciHesapTanimTx muhGeciciHesapTanimTx = new MuhGeciciHesapTanimTx();
                MuhGeciciHesapTanimTxId muhGeciciHesapTanimTxId = new MuhGeciciHesapTanimTxId();
            
                
                muhGeciciHesapTanimTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                muhGeciciHesapTanimTxId.setHesapNo(iMap.getString(tableName, i, "HESAP_NO"));
                
                muhGeciciHesapTanimTx.setId(muhGeciciHesapTanimTxId);
                
                if(("S").equals(iMap.getString(tableName,i,"G_S")))
                    muhGeciciHesapTanimTx.setGS("S");
                else if(("G").equals(iMap.getString(tableName,i,"G_S")))
                    muhGeciciHesapTanimTx.setGS("G");
                else
                    muhGeciciHesapTanimTx.setGS("");
                
                
                session.saveOrUpdate(muhGeciciHesapTanimTx);
            }
            session.flush();
            
            iMap.put("TRX_NAME","1125");
            return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);  
            
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN1125_GET_LIST")
    public static Map<?, ?> getHesapList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try {
        	conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_TRN1125.GET_GECICI_HESAP_LIST(?)}");
            int i = 1;
    
            stmt.registerOutParameter(i++, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            String tableName1 = "TBL_GECICI_HESAP_TANIMLAMA";
            for (int row = 0; rSet.next(); row++) {
                
                oMap.put(tableName1, row, "HESAP_NO", rSet.getString("HESAP_NO"));
                oMap.put(tableName1, row, "ACIKLAMA", rSet.getString("ACIKLAMA"));
                oMap.put(tableName1, row, "G_S", rSet.getString("G_S"));
                oMap.put(tableName1, row, "SIL", rSet.getString("SIL"));
                
            }
                
            return oMap;
        }
            catch (Exception e) {
                
                throw ExceptionHandler.convertException(e);
            
            } finally {
                
                GMServerDatasource.close(rSet);
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
            
            }
        }
 
    
    @GraymoundService("BNSPR_TRN1125_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {

       
        try{
            
        GMMap oMap = new GMMap();
        String tableName    = "TBL_GECICI_HESAP_TANIMLAMA";
        

          Session     session     = DAOSession.getSession("BNSPRDal");
          Criteria criteria = session.createCriteria(MuhGeciciHesapTanimTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO")));
          
          List<?> recordList = (List<?>) criteria.list();                            
          
          for (int row=0; row<recordList.size(); row++) {
              MuhGeciciHesapTanimTx muhGeciciHesapTanimTx = (MuhGeciciHesapTanimTx) recordList.get(row);

    
            oMap.put("TX_NO",iMap.getBigDecimal("TX_NO"));
            oMap.put(tableName, row, "HESAP_NO", muhGeciciHesapTanimTx.getId().getHesapNo());
            oMap.put(tableName, row, "ACIKLAMA", DALUtil.getResult("select aciklama from muh_hp_tanim where hesap_no = "+muhGeciciHesapTanimTx.getId().getHesapNo()+""));  
            oMap.put(tableName, row, "G_S", muhGeciciHesapTanimTx.getGS());
            oMap.put(tableName, row, "SIL", ("S").equals(muhGeciciHesapTanimTx.getGS()) ? true : false);

          }
                
        return oMap;
        }
        
        catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }   
    }



  
    @GraymoundService("BNSPR_TRN1125_IS_RECORDS_UNIQUE")
    public static GMMap isRecordsUnique(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        
        String tableName = "TBL_GECICI_HESAP_TANIMLAMA";
        int rowCount = iMap.getSize(tableName);
        
        for (int i = 0; i < rowCount; i++){
            for (int j = 0; j < rowCount; j++){
                if (iMap.getString(tableName , i , "HESAP_NO") == (null) || iMap.getString(tableName , i , "HESAP_NO").equals("")){
                    iMap.put("HATA_NO" , new BigDecimal(330));
                    iMap.put("P1" , "HESAP_NO");
                    GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                }
               
                if (i != j){
                    if (iMap.getString(tableName , i , "HESAP_NO").equals(iMap.getString(tableName , j , "HESAP_NO"))){
                        iMap.put("HATA_NO" , new BigDecimal(932));
                        GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
                    }
                }
            }
        }
        return oMap;
    }
    

   @GraymoundService("BNSPR_TRN1125_RENKLENDIRME")
    public static GMMap Renklendir(GMMap iMap) {    
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            List<?> list = (List<?>) iMap.get("TBL_GECICI_HESAP_TANIMLAMA"); 
            if(list != null)
            {
                for (int i = 0; i < list.size(); i++) {

                    if( "G".equals(iMap.getString("TBL_GECICI_HESAP_TANIMLAMA", i, "G_S")))
                    {       
                      
                      oMap.put("TBL_GECICI_HESAP_TANIMLAMA", i, "HESAP_NO", getUnchangedTableCellColorData(Color.GREEN));
                      oMap.put("TBL_GECICI_HESAP_TANIMLAMA", i, "ACIKLAMA", getUnchangedTableCellColorData(Color.GREEN));
                  
                    }
                    else if ("S".equals(iMap.getString("TBL_GECICI_HESAP_TANIMLAMA", i, "G_S")))
                    {
                      oMap.put("TBL_GECICI_HESAP_TANIMLAMA", i, "HESAP_NO", getUnchangedTableCellColorData(Color.RED));  
                      oMap.put("TBL_GECICI_HESAP_TANIMLAMA", i, "ACIKLAMA", getUnchangedTableCellColorData(Color.RED));
                     
                    }
                    else
                    {
                      oMap.put("TBL_GECICI_HESAP_TANIMLAMA", i, "HESAP_NO", iMap.getString("TBL_GECICI_HESAP_TANIMLAMA", i, "HESAP_NO"));
                      oMap.put("TBL_GECICI_HESAP_TANIMLAMA", i, "ACIKLAMA", iMap.getString("TBL_GECICI_HESAP_TANIMLAMA", i, "ACIKLAMA"));
                    }
                }
            }  
        return oMap;            
        }catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }   
    }
    private static GMMap getUnchangedTableCellColorData(Color ColorData){
        GMMap oMap = new GMMap();
        oMap.put("setBackground", ColorData);
        return oMap;
    }   
	
}
