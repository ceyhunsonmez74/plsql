package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
//import java.sql.Types;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;



import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;


public class AccountingQRY1115Services {

	@GraymoundService("BNSPR_QRY1115_GET_MUH_FIS_SATIR")
	public static GMMap getMuhFisSatir(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_RC_ACCOUNTING.RC_QRY1115_GET_SERBEST_BA(?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("SUBE_KODU"));
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("SON_TARIH").getTime()));
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "FIS_SATIR";
			GMMap oMap = DALUtil.rSetResults(rSet, tableName);
			
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}


