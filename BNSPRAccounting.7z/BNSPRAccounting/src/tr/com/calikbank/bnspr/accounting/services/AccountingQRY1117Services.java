package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingQRY1117Services {

	@GraymoundService("BNSPR_QRY1117_GET_MIZAN_HAREKET_INFO")
	public static GMMap getMizanHareketInfo(GMMap iMap) throws ParseException{
		try
		{ 
			GMMap oMap = new GMMap();
			oMap.putAll(getCbsDetay(iMap));
			oMap.putAll(getCbsDetayToplam(iMap));
			oMap.putAll(getSumAlcakBorc(iMap));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY1104_GET_CBSDETAY")
	public static GMMap getCbsDetay(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_accounting.RC_QRY1117_GET_CBSDETAY(?,?,?,?,?)}");	
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("SUBE_KODU"));
			if (!(iMap.get("TARIH") == null)) {
				stmt.setDate(i++, new Date(iMap.getDate("TARIH").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			stmt.setString(i++, iMap.getString("TUR"));
			stmt.setString(i++, iMap.getString("DK_BAS"));
			stmt.setString(i++, iMap.getString("DK_BIT"));
			stmt.execute();
			String tableName = "CBS_DETAY";
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			int j = 0;
			while (rSet.next()) {		
				oMap.put(tableName, j, "SUBE_KODU", rSet.getString("sube_kodu"));
				oMap.put(tableName, j, "TARIH", new SimpleDateFormat("dd/MM/yyyy").format(rSet.getDate("tarih")));
				oMap.put(tableName, j, "TUR", rSet.getString("tur"));
				oMap.put(tableName, j, "ACIKLAMA", rSet.getString("aciklama"));
				oMap.put(tableName, j, "ALACAK_FC", rSet.getBigDecimal("alacak_fc"));
				oMap.put(tableName, j, "ALACAK_LC", rSet.getBigDecimal("alacak_lc"));
				oMap.put(tableName, j, "BAKIYE_FC", rSet.getBigDecimal("bakiye_fc"));
				oMap.put(tableName, j, "BAKIYE_LC", rSet.getBigDecimal("bakiye_lc"));
				oMap.put(tableName, j, "BORC_FC", rSet.getBigDecimal("borc_fc") );
				oMap.put(tableName, j, "BORC_LC", rSet.getBigDecimal("borc_lc"));
				oMap.put(tableName, j, "DK_NUMARA", rSet.getString("dk_numara"));
				oMap.put(tableName, j, "DOVIZ_KOD", rSet.getString("doviz_kod"));
				j++ ;
			}

			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY1104_GET_CBSDETAY_TOPLAM")
	public static GMMap getCbsDetayToplam(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_accounting.RC_QRY1117_GET_CBSDETAY_TOPLAM(?,?,?,?,?)}");	
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("SUBE_KODU"));
			if (!(iMap.get("TARIH") == null)) {
				stmt.setDate(i++, new Date(iMap.getDate("TARIH").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			stmt.setString(i++, iMap.getString("TUR"));
			stmt.setString(i++, iMap.getString("DK_BAS"));
			stmt.setString(i++, iMap.getString("DK_BIT"));
			stmt.execute();
			String tablename="CBS_DETAY_TOPLAM";
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			int j = 0;
			while (rSet.next()) {		

				oMap.put(tablename,j,"ALACAK_FC", rSet.getBigDecimal("sum_alacak_fc"));
				oMap.put(tablename,j,"ALACAK_LC", rSet.getBigDecimal("sum_alacak_lc"));
				oMap.put(tablename,j,"BAKIYE_FC", rSet.getBigDecimal("sum_bakiye_fc"));
				oMap.put(tablename,j,"BAKIYE_LC", rSet.getBigDecimal("sum_bakiye_lc"));
				oMap.put(tablename,j,"BORC_FC", rSet.getBigDecimal("sum_borc_fc") );
				oMap.put(tablename,j,"BORC_LC", rSet.getBigDecimal("sum_borc_lc"));
				oMap.put(tablename,j,"SUM_DOVIZ_KOD", rSet.getString("sum_doviz_kod"));
				j++;
			}

			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY1104_GET_SUM_ALCAK_BORC")
	public static GMMap getSumAlcakBorc(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_accounting.RC_QRY1117_GET_SUM_ALCAK_BORC(?,?,?,?,?)}");	
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("SUBE_KODU"));
			if (!(iMap.get("TARIH") == null)) {
				stmt.setDate(i++, new Date(iMap.getDate("TARIH").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			stmt.setString(i++, iMap.getString("TUR"));
			stmt.setString(i++, iMap.getString("DK_BAS"));
			stmt.setString(i++, iMap.getString("DK_BIT"));
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			int j = 0;
			while (rSet.next()) {		

				oMap.put("SUM_BORC_LC_GENEL", rSet.getString("sum_borc_lc_genel"));
				oMap.put("SUM_ALACAK_LC_GENEL", rSet.getBigDecimal("sum_alacak_lc_genel"));
				oMap.put("SUM_BORC_FC_GENEL", rSet.getBigDecimal("sum_borc_fc_genel"));
				oMap.put("SUM_ALACAK_FC_GENEL", rSet.getBigDecimal("sum_alacak_fc_genel"));
				oMap.put("SUM_BAKIYE_LC_GENEL", rSet.getBigDecimal("sum_bakiye_lc_genel"));
				oMap.put("SUM_BAKIYE_FC_GENEL", rSet.getBigDecimal("sum_bakiye_fc_genel"));
				j++;
			}

			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
		}
	}						


								


}						 
