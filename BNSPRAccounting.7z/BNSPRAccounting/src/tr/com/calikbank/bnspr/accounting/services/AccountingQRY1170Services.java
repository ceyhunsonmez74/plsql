package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Types;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMasrafKomKriterTx;
import tr.com.calikbank.bnspr.dao.GnlMasrafKomTanimPrTx;
import tr.com.calikbank.bnspr.dao.GnlMasrafKomTanimPrTxId;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingQRY1170Services {


@GraymoundService("BNSPR_QRY1170_GET_LIST")
public static GMMap qry1170GetList(GMMap iMap) {
	Connection conn = null;
	CallableStatement stmt = null;
	ResultSet rSet = null;
	try {
		conn = DALUtil.getGMConnection();
		stmt = conn.prepareCall("{? = call PKG_RC1170.RC_QRY1170_GET_LIST(?,?,?,?,?,?,?,?)}");	
		int i = 1;	
		stmt.registerOutParameter(i++, -10); //ref cursor
		/*if (!"X".equals(iMap.getString("M_K")))
			stmt.setString(i++, iMap.getString("M_K"));
		else
			stmt.setString(i++, null);*/
		stmt.setString(i++, iMap.getString("KANAL_Q"));
		stmt.setString(i++, iMap.getString("MASKOM_TURU_Q"));
		stmt.setString(i++, iMap.getString("MUSTERI_TIPI_Q"));
		stmt.setString(i++, iMap.getString("MODUL_Q"));
		stmt.setString(i++,iMap.getString("KAYIT_TURU_Q"));
		stmt.setString(i++,iMap.getString("STATU_Q"));
	
		
		
		if (iMap.getDate("START_DATE_Q") != null)
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("START_DATE_Q").getTime()));
		else
			stmt.setDate(i++, null);
		
		if (iMap.getDate("END_DATE_Q") != null)
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("END_DATE_Q").getTime()));
		else
			stmt.setDate(i++, null);
	
		stmt.execute();
		String tableName = "MASRAF_KOM_TANIM_PR";
	    rSet = (ResultSet)stmt.getObject(1);
		GMMap oMap = new GMMap();
		int row = 0;
		while (rSet.next()) {
			
			oMap.put(tableName, row, "KANAL_KOD", rSet.getString("KANAL_KOD"));
			oMap.put(tableName, row, "MUSTERI_TIPI", rSet.getString("MUSTERI_TIPI"));
			oMap.put(tableName, row, "M_K", rSet.getString("M_K"));
			oMap.put(tableName, row, "MODUL_KOD", rSet.getString("MODUL_KOD"));
			oMap.put(tableName, row, "ISLEM_KOD", rSet.getBigDecimal("ISLEM_KOD"));
			oMap.put(tableName, row, "MASKOM_KOD", rSet.getString("MASKOM_KOD"));
			oMap.put(tableName, row, "MIN_ISLEM_TUTAR", rSet.getBigDecimal("MIN_ISLEM_TUTAR"));
			oMap.put(tableName, row, "MAX_ISLEM_TUTAR", rSet.getBigDecimal("MAX_ISLEM_TUTAR"));
			oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString("DOVIZ_KOD"));
			oMap.put(tableName, row, "DEGISTIRILEBILIR", GuimlUtil.convertToCheckBoxValue(rSet.getString("DEGISTIRILEBILIR")));
			oMap.put(tableName, row, "DRM", GuimlUtil.convertToCheckBoxValue(rSet.getString("DRM")));
			oMap.put(tableName, row, "MASKOM_TUTAR", rSet.getBigDecimal("MASKOM_TUTAR"));
			oMap.put(tableName, row, "MASKOM_ORAN", rSet.getBigDecimal("MASKOM_ORAN"));
			oMap.put(tableName, row, "MIN_MASKOM_TUTAR", rSet.getBigDecimal("MIN_MASKOM_TUTAR"));
			oMap.put(tableName, row, "MAX_MASKOM_TUTAR", rSet.getBigDecimal("MAX_MASKOM_TUTAR"));
			oMap.put(tableName, row, "START_DATE", rSet.getDate("START_DATE"));
			oMap.put(tableName, row, "END_DATE", rSet.getDate("END_DATE"));
			row++;
		}
		return oMap;
	} catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	} finally {
		GMServerDatasource.close(rSet);
		GMServerDatasource.close(stmt);
		GMServerDatasource.close(conn);
	}
}

}