package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.classic.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMasraf;
import tr.com.calikbank.bnspr.dao.GnlMasrafId;
import tr.com.calikbank.bnspr.dao.GnlMasrafTaksitTx;
import tr.com.calikbank.bnspr.dao.GnlMasrafTaksitTxId;
import tr.com.calikbank.bnspr.dao.GnlMasrafDonemselTx;
import tr.com.calikbank.bnspr.dao.GnlMasrafDonemselTxId;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import com.graymound.server.dao.DAOSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingChargesServices {
	
	@GraymoundService("BNSPR_CHARGES_GET_INFO")
	public static GMMap getChargesInfo(GMMap iMap) {
		
		GMMap oMap= new GMMap();
		Session session = (Session) DAOSession.getSession("BNSPRDal");
		
		BigDecimal hesaplananToplam=BigDecimal.ZERO;
		BigDecimal alinanToplam=BigDecimal.ZERO;
		BigDecimal bsmvToplam = BigDecimal.ZERO;
		List<?> list =session.createCriteria(GnlMasraf.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
															.add(Restrictions.isNull("donemsel"))
															.list();
		int i = 0;
		String tableName = "LIST";
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			GnlMasraf listBilgi = (GnlMasraf) iterator.next();
			oMap.put(tableName,i, "TX_NO", listBilgi.getId().getTxNo());
			oMap.put(tableName,i, "SIRA", listBilgi.getId().getSira());
			oMap.put(tableName,i, "MASRAF_KODU", listBilgi.getId().getMasrafKodu());
			oMap.put(tableName,i, "ADI", listBilgi.getAdi());
			oMap.put(tableName,i, "HESAPLANAN", listBilgi.getHesaplanan());
			oMap.put(tableName,i, "ALINAN", listBilgi.getAlinan().toString());
			oMap.put(tableName,i, "BSMV", listBilgi.getBsmv().toString());
			try{
				hesaplananToplam=listBilgi.getHesaplanan().add(hesaplananToplam);
			}catch (Exception e) {				
			}
			try{
				alinanToplam=listBilgi.getAlinan().add(alinanToplam);
			}catch (Exception e) {				
			}
			try{
				bsmvToplam = listBilgi.getBsmv().add(bsmvToplam);
			}catch (Exception e) {
			}
			
			oMap.put(tableName,i, "DOVIZ", listBilgi.getDvz());
			oMap.put(tableName,i, "ODEYECEK", listBilgi.getOdeyecek());
			oMap.put(tableName,i, "DEGISTIRILEBILIR", listBilgi.getDegistirilebilir());
			i++;
		}

		oMap.put("HESAPLANAN_TOPLAM", hesaplananToplam);
		oMap.put("ALINAN_TOPLAM", alinanToplam);
		oMap.put("BSMV_TOPLAM", bsmvToplam);
		return oMap;
	}
	
	@GraymoundService("BNSPR_CHARGES_GET_BSMV")
	public static GMMap getChargesBSMV(GMMap iMap) {
		
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			
			conn = DALUtil.getGMConnection();

			GMMap oMap=new GMMap();
			stmt = conn	.prepareCall("{? = call PKG_MASRAF_YENI.ALINAN_MASRAF_BSMV(?,?,?,?)}");
			
			stmt.registerOutParameter(1, Types.DECIMAL);
			
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("SIRA"));
			stmt.setString(4, iMap.getString("MASRAF_KODU"));
			stmt.setBigDecimal(5, iMap.getBigDecimal("ALINAN"));
						
			stmt.execute();
			
			BigDecimal bsmv=stmt.getBigDecimal(1);
			
			oMap.put("BSMV", bsmv);
			
			return oMap;
			

		} catch (SQLException e) {
			throw  ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_CHARGES_SAVE")
	    public static GMMap saveAccCharges(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		GMMap oMap = new GMMap();

		try{
			Session session = (Session) DAOSession.getSession("BNSPRDal");
			
			List<?> listML = (List<?>) iMap.get("MASRAF_LIST");
			String tableName = "MASRAF_LIST";
			
			for (int i=0;i<listML.size();i++) {
				
				GnlMasrafId id = new GnlMasrafId();
				iMap.put("TRX_NO", iMap.getBigDecimal(tableName,i,"TX_NO"));
				id.setTxNo(iMap.getBigDecimal(tableName,i,"TX_NO"));
				id.setSira(iMap.getBigDecimal(tableName,i,"SIRA"));
				id.setMasrafKodu(iMap.getString(tableName,i,"MASRAF_KODU"));
				
				List<?> list = session.createCriteria(GnlMasraf.class).add(Restrictions.eq("id", id)).list();
				
				for (Iterator<?> iterator2 = list.iterator(); iterator2.hasNext();) {
					GnlMasraf gnlMasraf = (GnlMasraf) iterator2.next();

					gnlMasraf.setAlinan(iMap.getBigDecimal(tableName,i,"ALINAN"));
					gnlMasraf.setBsmv(iMap.getBigDecimal(tableName,i,"BSMV"));
					gnlMasraf.setOdeyecek(iMap.getString(tableName,i,"ODEYECEK"));
					
					session.save(gnlMasraf);						
				}				
				session.flush();
			}
			
//			iMap.put("TRX_NAME", "CHARGES");
//
//			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION",iMap);
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("call PKG_TRNCHARGES.after_control(?)");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();	
			
			return oMap;
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);		
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	} 

	@GraymoundService("BNSPR_CHARGES_GET_ODEYECEK_TIPI")
	public static GMMap getodeyecekTipi(GMMap iMap){
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("SELECT ODEYECEK, MASRAF_KODU FROM GNL_MASRAF_ODEYEN WHERE MASRAF_KODU = ?");
			stmt.setString(1, iMap.getString("MASRAF_KODU"));
			rSet = stmt.executeQuery();
			
			iMap.put("LIST_NAME", "ODEYECEK_LIST");
			iMap.put("ADD_EMPTY_KEY", "H");
			DALUtil.fillComboBox(iMap, rSet);
			return iMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_CHARGES_DNM_GET_MASRAF_KODU")
	public static GMMap getMasraf_kodu(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("call PKG_DONEMSEL_MASRAF.masraf_kodu_al(?,?,?)");
			stmt.setString(1, iMap.getString("TRX_NAME"));
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.execute();
			oMap.put("MASRAF_KODU", stmt.getString(2));
			oMap.put("MASRAF_ADI", stmt.getString(3));
			
			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_CHARGES_DNM_BILGI_AKTAR")
	public static GMMap getBilgiAktar(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("call PKG_DONEMSEL_MASRAF.bilgi_aktar(?,?,?)");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(2, iMap.getString("REFERANS"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("VESAIK_NO"));
			stmt.execute();
			
			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_CHARGES_DNM_TUTAR_HESAPLA")
	public static GMMap tutarHesapla(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(" call PKG_DONEMSEL_MASRAF.tutar_hesapla(?,?,?,?,?,?,?,?,?)");
			stmt.setBigDecimal(1, iMap.getBigDecimal("MATRAH_TUTAR"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("ORAN"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TUTAR"));
			stmt.setString(4, iMap.getString("DOVIZ_KODU"));
			
			stmt.registerOutParameter(5, Types.NUMERIC);
			stmt.registerOutParameter(6, Types.NUMERIC);
			stmt.setString(7, iMap.getString("BSMV_ALINDI_MI"));
            stmt.setBigDecimal(8, iMap.getBigDecimal("DONEM_YILLIK_ORAN"));
            stmt.setBigDecimal(9, iMap.getBigDecimal("DEVRE_AY_SAYISI"));
			
			stmt.execute();
			oMap.put("HESAPLANAN_TUTAR", stmt.getBigDecimal(5));
			oMap.put("BSMV", stmt.getBigDecimal(6));
			
			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_CHARGES_DNM_ODEME_PLANI_OLUSTUR")
	public static GMMap odemePlaniOlustur(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("call PKG_DONEMSEL_MASRAF.odeme_plani_olustur(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(i++, iMap.getString("REFERANS"));
			stmt.setString(i++, iMap.getString("MASRAF_KODU"));
			stmt.setString(i++, iMap.getString("KOMISYON_TIP"));
			if(iMap.getBigDecimal("TAKSIT_TUTAR")!=null)
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TAKSIT_TUTAR"));
			else
				stmt.setBigDecimal(i++, new BigDecimal("0"));
			if(iMap.getDate("VADE_TARIHI")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("VADE_TARIHI").getTime()));
			
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("DEVRE_GUN_SAYISI"));
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("DEVRE_AY_SAYISI"));
			stmt.setString(i++, iMap.getString("DONEM_BASSON"));
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.DATE);
			stmt.registerOutParameter(i++, Types.DATE);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setString(i++, iMap.getString("BSMV_ALINDI_MI"));
			stmt.setString(i++, iMap.getString("VADE_SONRASI"));
			if(iMap.getString("HEMEN_TAKSIT_YARAT").equals("true"))
				stmt.setString(i++,"E");
			else 	
				stmt.setString(i++,"H");
			if(iMap.getDate("BAS_TARIH")==null)
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			i--;
			i--;
			i--;
			i--;
			stmt.execute();
			oMap.put("TAHSIL_EDILMEYEN", stmt.getBigDecimal(--i));
			oMap.put("TAHSIL_TOPLAM", stmt.getBigDecimal(--i));
			oMap.put("TAKSIT_SONTAR", stmt.getDate(--i));
			oMap.put("TAKSIT_BASTAR", stmt.getDate(--i));
			oMap.put("TAKSIT_SAYISI", stmt.getBigDecimal(--i));
			
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_CHARGES_DNM_INITIALIZE")
	public static GMMap dnmInitialize(GMMap iMap){
			
		GMMap oMap = new GMMap();
		iMap.put("KOD", "MASRAF_DONEM_KOMISYON_TIP");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("MASRAF_DONEM_KOMISYON_TIP",GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

		iMap.put("KOD", "MASRAF_DONEM_ODEYECEK");
		iMap.put("ADD_EMPTY_KEY", "H");
		oMap.put("MASRAF_DONEM_ODEYECEK",GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "MASRAF_DONEM_BASSON");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("MASRAF_DONEM_BASSON",GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "EVET_HAYIR");
		iMap.put("ADD_EMPTY_KEY", "H");
		oMap.put("BSMV_ALINSIN_MI",GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "MASRAF_DONEM_DKMUS");
		iMap.put("ADD_EMPTY_KEY", "H");
		oMap.put("HESAP_TIPI",GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "MASRAF_DEVRE_AY_SAYISI");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("MASRAF_DEVRE_AY_SAYISI",GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "MASRAF_DEVRE_GUN_SAYISI");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("MASRAF_DEVRE_GUN_SAYISI",GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "MASRAF_DONEM_KUR_TIPI");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("MASRAF_DONEM_KUR_TIPI",GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_CHARGES_DNM_GET_MASRAF_TAKSIT")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn 		= null;
		
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			
			Session session = (Session)DAOSession.getSession("BNSPRDal");
			
			String tableName = "MASRAF_TAKSIT_ISLEM";
			List<?> recordList = (List<?>)session.createCriteria(GnlMasrafTaksitTx.class)
												.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
												.list();
			for (int row = 0; row < recordList.size(); row++) {
				GnlMasrafTaksitTx gnlMasrafTaksitTx = (GnlMasrafTaksitTx) recordList.get(row);
				oMap.put(tableName,row,"BSMV", gnlMasrafTaksitTx.getBsmv());
				oMap.put(tableName,row,"ODENEN_TUTAR", gnlMasrafTaksitTx.getOdenenTutar());
				oMap.put(tableName,row,"TAKSIT_NO", gnlMasrafTaksitTx.getId().getTaksitNo());
				oMap.put(tableName,row,"TAKSIT_ODEME_TARIH", gnlMasrafTaksitTx.getTaksitOdemeTarih());
				oMap.put(tableName,row,"TAKSIT_TARIHI", gnlMasrafTaksitTx.getTaksitTarihi());
				oMap.put(tableName,row,"TAKSIT_TUTARI", gnlMasrafTaksitTx.getTaksitTutari());
				oMap.put(tableName,row,"F_ODEME_YAPILACAK", gnlMasrafTaksitTx.getFOdemeYapilacak());
				oMap.put(tableName,row,"ODENMEME_NEDENI", gnlMasrafTaksitTx.getOdenmemeNedeni());
				oMap.put(tableName,row,"DURUM", gnlMasrafTaksitTx.getDurum());
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_CHARGES_DNM_SAVE_MASRAF_DONEMSEL")
	public static GMMap saveDonemselMasraf(GMMap iMap) {
		Connection conn 		= null;
		PreparedStatement stmt = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();
			Session session = (Session)DAOSession.getSession("BNSPRDal");
			
			if(iMap.getString("DONEMSEL_MASRAF_VARMI").equals("E"))
			{
				GnlMasrafDonemselTx gnlMasrafDonemselTx = (GnlMasrafDonemselTx)session.createCriteria(GnlMasrafDonemselTx.class).
				add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
				
				if(gnlMasrafDonemselTx == null){
					gnlMasrafDonemselTx = new GnlMasrafDonemselTx();
				
					GnlMasrafDonemselTxId gnlMasrafDonemselTxId = new GnlMasrafDonemselTxId();
					gnlMasrafDonemselTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					gnlMasrafDonemselTxId.setSiraNo(new BigDecimal("1"));
					gnlMasrafDonemselTx.setId(gnlMasrafDonemselTxId);
				}
				
				gnlMasrafDonemselTx.setAdi(iMap.getString("ADI"));
				gnlMasrafDonemselTx.setBsmv(iMap.getBigDecimal("BSMV"));
				gnlMasrafDonemselTx.setBsmvEh(iMap.getString("BSMV_EH"));
				gnlMasrafDonemselTx.setDevreGunSayisi(iMap.getBigDecimal("DEVREGUNSAYISI"));
				gnlMasrafDonemselTx.setDonemBasSon(iMap.getString("DONEMBASSON"));
				gnlMasrafDonemselTx.setDvz(iMap.getString("DOVIZ_KODU"));
				gnlMasrafDonemselTx.setIslemDoviz(iMap.getString("DVZ"));
				gnlMasrafDonemselTx.setHesaplanan(iMap.getBigDecimal("HESAPLANAN"));
				gnlMasrafDonemselTx.setKomisyonTipi(iMap.getString("KOMISYONTIPI"));
				gnlMasrafDonemselTx.setMasrafHesapNo(iMap.getBigDecimal("MASRAFHESAPNO"));
				gnlMasrafDonemselTx.setMasrafKodu(iMap.getString("MASRAFKODU"));
				gnlMasrafDonemselTx.setOdeyecek(iMap.getString("ODEYECEK"));
				gnlMasrafDonemselTx.setOran(iMap.getBigDecimal("ORAN"));
				gnlMasrafDonemselTx.setReferans(iMap.getString("REFERANS"));
				gnlMasrafDonemselTx.setTahsilEdilemeyen(iMap.getBigDecimal("TAHSILEDILEMEYEN"));
				gnlMasrafDonemselTx.setTahsilToplam(iMap.getBigDecimal("TAHSILTOPLAM"));
				gnlMasrafDonemselTx.setTaksitBasTarih(iMap.getDate("TAKSITBASTARIH"));
				gnlMasrafDonemselTx.setTaksitBitisTarih(iMap.getDate("TAKSITBITISTARIH"));
				gnlMasrafDonemselTx.setTaksitSayisi(iMap.getBigDecimal("TAKSITSAYISI"));
				gnlMasrafDonemselTx.setTutar(iMap.getBigDecimal("TUTAR"));
				gnlMasrafDonemselTx.setYilDonemSayisi(iMap.getBigDecimal("YILDONEMSAYISI"));
				gnlMasrafDonemselTx.setYillikOran(iMap.getBigDecimal("YILLIKORAN"));
				gnlMasrafDonemselTx.setMatrahTutar(iMap.getBigDecimal("MATRAHTUTAR"));
				gnlMasrafDonemselTx.setIslemKod(iMap.getBigDecimal("ISLEMKOD"));
				gnlMasrafDonemselTx.setMasrafHesapTurKod(iMap.getString("MASRAF_HESAP_TUR_KOD"));
				
				gnlMasrafDonemselTx.setKur(iMap.getBigDecimal("KUR"));
				gnlMasrafDonemselTx.setKurTipi(iMap.getString("KUR_TIPI"));
				
				session.saveOrUpdate(gnlMasrafDonemselTx);
				session.flush();
				String tableName = "MASRAF_TAKSIT_ISLEM";
				List<?> list = (List<?>) iMap.get(tableName);
				for (int i=0;i<list.size();i++){
					
					GnlMasrafTaksitTxId id = new GnlMasrafTaksitTxId();
					id.setTaksitNo(iMap.getBigDecimal(tableName, i, "TAKSIT_NO"));
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					id.setMasrafKodu(iMap.getString("MASRAFKODU"));
					
					GnlMasrafTaksitTx gnlMasrafTaksitTx = (GnlMasrafTaksitTx)session.createCriteria(GnlMasrafTaksitTx.class).
					add(Restrictions.eq("id.txNo", id.getTxNo())).
					add(Restrictions.eq("id.taksitNo", id.getTaksitNo())).
					add(Restrictions.eq("id.masrafKodu", id.getMasrafKodu())).uniqueResult();
					
					if(gnlMasrafTaksitTx==null)
						gnlMasrafTaksitTx = new GnlMasrafTaksitTx();
					gnlMasrafTaksitTx.setBsmv(iMap.getBigDecimal(tableName, i, "BSMV"));
					gnlMasrafTaksitTx.setOdenenTutar(iMap.getBigDecimal(tableName, i, "ODENEN_TUTAR"));
					gnlMasrafTaksitTx.setTaksitOdemeTarih(iMap.getDate(tableName, i, "TAKSIT_ODEME_TARIH"));
					gnlMasrafTaksitTx.setTaksitTarihi(iMap.getDate(tableName, i, "TAKSIT_TARIHI"));
					gnlMasrafTaksitTx.setTaksitTutari(iMap.getBigDecimal(tableName, i, "TAKSIT_TUTARI"));
					gnlMasrafTaksitTx.setFOdemeYapilacak(iMap.getString(tableName, i, "F_ODEME_YAPILACAK"));
					gnlMasrafTaksitTx.setOdenmemeNedeni(iMap.getString(tableName, i, "ODENMEME_NEDENI"));
					gnlMasrafTaksitTx.setDurum(iMap.getString(tableName,i,"DURUM"));
					gnlMasrafTaksitTx.setId(id);
					
					session.saveOrUpdate(gnlMasrafTaksitTx);
					session.flush();
				}
			}
			
			List<?> listML = (List<?>) iMap.get("MASRAF_LIST");
			String tableName = "MASRAF_LIST";
			
			GnlMasrafId id = new GnlMasrafId();
			iMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			
			for (int i=0;i<listML.size();i++) {
				
				id.setSira(iMap.getBigDecimal(tableName,i,"SIRA"));
				id.setMasrafKodu(iMap.getString(tableName,i,"MASRAF_KODU"));
				
				List<?> list = session.createCriteria(GnlMasraf.class).add(Restrictions.eq("id", id)).list();
				
				for (Iterator<?> iterator2 = list.iterator(); iterator2.hasNext();) {
					GnlMasraf gnlMasraf = (GnlMasraf) iterator2.next();

					gnlMasraf.setAlinan(iMap.getBigDecimal(tableName,i,"ALINAN"));
					gnlMasraf.setBsmv(iMap.getBigDecimal(tableName,i,"BSMV"));
					gnlMasraf.setOdeyecek(iMap.getString(tableName,i,"ODEYECEK"));
					gnlMasraf.setHesapNo(iMap.getBigDecimal("MASRAFHESAPNO"));
					gnlMasraf.setMasrafHesapTurKod(iMap.getString("MASRAF_HESAP_TUR_KOD"));
					
					session.save(gnlMasraf);						
				}				
				session.flush();
			}
			
//			iMap.put("TRX_NAME", "CHARGES");

//			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION",iMap);
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("call PKG_TRNCHARGES.after_control(?)");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();	

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);	
		} finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}
	
	@GraymoundService("BNSPR_CHARGES_DNM_DONEMSEL_MASRAF_VARMI")
	public static GMMap donemselMasrafVarmi(GMMap iMap) {
		Connection conn 		= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			Session session = (Session)DAOSession.getSession("BNSPRDal");
			
			GnlMasrafDonemselTx gnlMasrafDonemselTx = (GnlMasrafDonemselTx)(session.createCriteria(GnlMasrafDonemselTx.class)
					.add(Restrictions.eq("id.txNo",iMap.getBigDecimal("TRX_NO"))).uniqueResult() );
			
			if(gnlMasrafDonemselTx != null)
			{
				oMap.put("CALL_GET_INFO", "E");
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_CHARGES_DNM_GET_MASRAF_DONEMSEL")
	public static GMMap getDonemselMasraf(GMMap iMap) {
		Connection conn 		= null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			Session session = (Session)DAOSession.getSession("BNSPRDal");
			
			GnlMasrafDonemselTx gnlMasrafDonemselTx = (GnlMasrafDonemselTx)(session.createCriteria(GnlMasrafDonemselTx.class)
					.add(Restrictions.eq("id.txNo",iMap.getBigDecimal("TRX_NO"))).uniqueResult() );
			
			if(gnlMasrafDonemselTx != null)
			{
				oMap.put("ADI", gnlMasrafDonemselTx.getAdi());
				oMap.put("BSMV", gnlMasrafDonemselTx.getBsmv());
				oMap.put("BSMV_EH", gnlMasrafDonemselTx.getBsmvEh());
				oMap.put("DEVREGUNSAYISI", gnlMasrafDonemselTx.getDevreGunSayisi());
				oMap.put("DONEMBASSON", gnlMasrafDonemselTx.getDonemBasSon());
				oMap.put("DVZ", gnlMasrafDonemselTx.getDvz());
				oMap.put("HESAPLANAN", gnlMasrafDonemselTx.getHesaplanan());
				oMap.put("KOMISYONTIPI", gnlMasrafDonemselTx.getKomisyonTipi());
				oMap.put("MASRAFHESAPNO", gnlMasrafDonemselTx.getMasrafHesapNo());
				oMap.put("MASRAFKODU", gnlMasrafDonemselTx.getMasrafKodu());
				oMap.put("ODEYECEK", gnlMasrafDonemselTx.getOdeyecek());
				oMap.put("ORAN", gnlMasrafDonemselTx.getOran());
				oMap.put("REFERANS", gnlMasrafDonemselTx.getReferans());
				oMap.put("TAHSILEDILEMEYEN", gnlMasrafDonemselTx.getTahsilEdilemeyen());
				oMap.put("TAHSILTOPLAM", gnlMasrafDonemselTx.getTahsilToplam());
				oMap.put("TAKSITBASTARIH", gnlMasrafDonemselTx.getTaksitBasTarih());
				oMap.put("TAKSITBITISTARIH", gnlMasrafDonemselTx.getTaksitBitisTarih());
				oMap.put("TAKSITSAYISI", gnlMasrafDonemselTx.getTaksitSayisi());
				oMap.put("TUTAR", gnlMasrafDonemselTx.getTutar());
				oMap.put("YILDONEMSAYISI", gnlMasrafDonemselTx.getYilDonemSayisi());
				oMap.put("YILLIKORAN", gnlMasrafDonemselTx.getYillikOran());
				oMap.put("MASRAF_HESAP_TUR_KOD", gnlMasrafDonemselTx.getMasrafHesapTurKod());
				oMap.put("KUR", gnlMasrafDonemselTx.getKur());
				oMap.put("KUR_TIPI", gnlMasrafDonemselTx.getKurTipi());
				
				String tableName = "MASRAF_TAKSIT_ISLEM";
				List<?> recordList = (List<?>)session.createCriteria(GnlMasrafTaksitTx.class)
													.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
													.list();
				for (int row = 0; row < recordList.size(); row++) {
					GnlMasrafTaksitTx gnlMasrafTaksitTx = (GnlMasrafTaksitTx) recordList.get(row);
					oMap.put(tableName,row,"BSMV", gnlMasrafTaksitTx.getBsmv());
					oMap.put(tableName,row,"ODENEN_TUTAR", gnlMasrafTaksitTx.getOdenenTutar());
					oMap.put(tableName,row,"TAKSIT_NO", gnlMasrafTaksitTx.getId().getTaksitNo());
					oMap.put(tableName,row,"TAKSIT_ODEME_TARIH", gnlMasrafTaksitTx.getTaksitOdemeTarih());
					oMap.put(tableName,row,"TAKSIT_TARIHI", gnlMasrafTaksitTx.getTaksitTarihi());
					oMap.put(tableName,row,"TAKSIT_TUTARI", gnlMasrafTaksitTx.getTaksitTutari());
					oMap.put(tableName,row,"F_ODEME_YAPILACAK", gnlMasrafTaksitTx.getFOdemeYapilacak());
					oMap.put(tableName,row,"ODENMEME_NEDENI", gnlMasrafTaksitTx.getOdenmemeNedeni());
					oMap.put(tableName,row,"DURUM", gnlMasrafTaksitTx.getDurum());
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
		}
	}
	 
	@GraymoundService("BNSPR_STATIC_SAVE_MASRAF")
	public static HashMap<String, Object> saveStaticMasraf(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			int i = 1;
			conn = DALUtil.getGMConnection();
    		stmt = conn	.prepareCall("{call PKG_MASRAF_YENI.MASRAF_YARAT(?,?,?,?,?,?,?)}");
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			String hesapNo = iMap.getString("HESAP_NO");
			if(hesapNo == null || hesapNo.equals("")) {
				if(iMap.getBigDecimal("MUSTERI_NO")== null || iMap.getBigDecimal("MUSTERI_NO").toString().equals(""))
					stmt.setBigDecimal(i++, null);
				else
					stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
				
				stmt.setString(i++, null);
			}
			else {
				if(iMap.getBigDecimal("MUSTERI_NO")== null || iMap.getBigDecimal("MUSTERI_NO").toString().equals(""))
					stmt.setBigDecimal(i++, (BigDecimal)GMServiceExecuter.execute("BNSPR_COMMON_GET_MUSTERI_NO",iMap).get("MUSTERI_NO"));
				else
					stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
				
				stmt.setString(i++, iMap.getString("HESAP_NO"));
			}
			stmt.setString(i++, iMap.getString("ALICI_HESAP"));
			stmt.execute();
			return new HashMap<String, Object>();
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_ACCOUNTIING_CHECK_MASKOM_EXEMPTION")
	public static GMMap checkMASKOMExemption(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {	
			String func = "{? = call BNSPR.PKG_MASRAF_YENI.MUAFIYET_VARMI(?,?,?)}";
			Object[] inputValues = new Object[3];
			int i = 0;
			inputValues[i++] = iMap.getInt("CUSTOMER_NO");
			inputValues[i++] = iMap.getInt("ACCOUNT_NO");
			inputValues[i++] = iMap.getInt("PROCESS_DEF_ID");
			
			String doesExemptionExist = (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);
			
			oMap.put("EXEMPTION", doesExemptionExist); //E or H
			
			return oMap;
			
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static GMMap throwGMBusssinessException(String string) {				
		GMMap exMap = new GMMap();
		exMap.put("P1", string);
		exMap.put("HATA_NO", "660");
		return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", exMap);
	}
}
	
	
