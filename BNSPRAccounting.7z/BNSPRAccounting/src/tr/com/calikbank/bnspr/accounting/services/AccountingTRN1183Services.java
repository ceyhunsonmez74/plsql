package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MuhDkUrunTanimTx;
import tr.com.aktifbank.bnspr.dao.MuhDkUrunTanimTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1183Services {
	
	@GraymoundService("BNSPR_TRN1183_GET_LIST")
	public static GMMap getList(GMMap iMap){
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		
		try{
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1183.TRN1183_SORGULA}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);

			return DALUtil.rSetResults(rSet, "TBL_DK_URUN_TANIM");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN1183_SAVE")
	public static Map<?, ?> save(GMMap iMap){

		try{

			String tableName = "TBL_DK_URUN_TANIM";
			Session session = DAOSession.getSession("BNSPRDal");

			List<MuhDkUrunTanimTx> removalList = (List<MuhDkUrunTanimTx>) session.createCriteria(MuhDkUrunTanimTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			for(MuhDkUrunTanimTx record : removalList){
				session.delete(record);
			}
			session.flush();

			try
			{

				for(int row =0; row<iMap.getSize(tableName); row++){

					if(iMap.getString(tableName, row, "DK_HESAP_NO") != null && !iMap.getString(tableName, row, "DK_HESAP_NO").trim().isEmpty() &&
							iMap.getString(tableName, row, "MODUL_TUR_KOD") != null && !iMap.getString(tableName, row, "MODUL_TUR_KOD").trim().isEmpty()){

						MuhDkUrunTanimTxId id = new MuhDkUrunTanimTxId(iMap.getBigDecimal("TRX_NO"), iMap.getString(tableName, row, "DK_HESAP_NO"));
						MuhDkUrunTanimTx tanim = new MuhDkUrunTanimTx();

						tanim.setId(id);
						tanim.setModulTurKod(iMap.getString(tableName, row, "MODUL_TUR_KOD"));
						tanim.setUrunTurKod(iMap.getString(tableName, row, "URUN_TUR_KOD"));
						tanim.setUrunSinifKod(iMap.getString(tableName, row, "URUN_SINIF_KOD"));
						session.save(tanim);

					}

				}
				session.flush();

			}catch(NonUniqueObjectException e){
				iMap.put("HATA_NO", "2240");
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
			}

			iMap.put("TRX_NAME", "1183");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN1183_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			
			String tableName = "TBL_DK_URUN_TANIM";
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<MuhDkUrunTanimTx> tanimList = (List<MuhDkUrunTanimTx>) session.createCriteria(MuhDkUrunTanimTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			int row = 0;
			for(MuhDkUrunTanimTx tanim : tanimList){
				
				oMap.put(tableName, row, "DK_HESAP_NO", tanim.getId().getDkHesapNo());
				oMap.put(tableName, row, "MODUL_TUR_KOD", tanim.getModulTurKod());
				oMap.put(tableName, row, "URUN_TUR_KOD", tanim.getUrunTurKod());
				oMap.put(tableName, row, "URUN_SINIF_KOD", tanim.getUrunSinifKod());
				row++;
				
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
