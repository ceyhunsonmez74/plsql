package tr.com.calikbank.bnspr.accounting.services;

import java.sql.Types;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EdefterislemPrTx;
import tr.com.aktifbank.bnspr.dao.SbaKurMarjTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhHesapBasvuruGunTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1141Services {
    
    @GraymoundService("BNSPR_TRN1141_INITIALIZE")
    public static GMMap initalize(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        try{
            
            oMap.put("TRX_NO" , DALUtil.callNoParameterFunction("{{? = call PKG_TRN1141.get_initial}" , Types.NUMERIC));
            
            // SbaKurMarjTx sba = (SbaKurMarjTx) session.createCriteria(SbaKurMarjTx.class).add(Restrictions.eq("txNo" , oMap.getBigDecimal("TRX_NO"))).uniqueResult();
			SbaKurMarjTx sba = (SbaKurMarjTx) session.get(SbaKurMarjTx.class, oMap.getBigDecimal("TRX_NO"));
            
            oMap.put("MARJ" , sba.getMarj());
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN1141_SAVE")
    public static GMMap save(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
			Session session = DAOSession.getSession("BNSPRDal");

			SbaKurMarjTx sbaKurMarjTx = (SbaKurMarjTx) session.get(SbaKurMarjTx.class, iMap.getBigDecimal("TRX_NO"));

			if (sbaKurMarjTx == null)
				sbaKurMarjTx = new SbaKurMarjTx();

             sbaKurMarjTx.setMarj(iMap.getBigDecimal("MARJ"));

             session.saveOrUpdate(sbaKurMarjTx);
 		   	 session.flush();
        	
            iMap.put("TRX_NAME" , "1141");
            oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN1141_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            
            Session session = DAOSession.getSession("BNSPRDal");
            try{
            //	SbaKurMarjTx marj = (SbaKurMarjTx) session.createCriteria(SbaKurMarjTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
    			SbaKurMarjTx marj = (SbaKurMarjTx) session.get(SbaKurMarjTx.class, iMap.getBigDecimal("TRX_NO"));
            	oMap.put("MARJ" , marj.getMarj());
                
            } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
}
