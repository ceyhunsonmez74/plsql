package tr.com.calikbank.bnspr.accounting.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import jxl.Cell;
import jxl.DateCell;
import jxl.NumberCell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MuhSubeKarZararAnaTx;
import tr.com.aktifbank.bnspr.dao.MuhSubeKarZararAnaTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1110Services {
    
    @GraymoundService("BNSPR_TRN1110_LOAD_EXCEL")
    public static GMMap loadExcel(GMMap iMap) {
        GMMap oMap = new GMMap();
        Workbook workbook = null;
        try{
            String tableName = "TBL_EXCEL_LIST";
            WorkbookSettings setting = new WorkbookSettings();
            setting.setEncoding("ISO-8859-9");
            workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("DOSYA")) , setting);
            Sheet dataSheet = workbook.getSheet(0);
            validateFile(dataSheet);
            for (int i = 0; i < dataSheet.getRows()-1; i++){
                oMap.put(tableName , i , "SIRA_NO" , dataSheet.getCell(0 , i + 1).getContents());
                oMap.put(tableName , i , "ACIKLAMA" , dataSheet.getCell(1 , i + 1).getContents());
                oMap.put(tableName , i , "FAIZ_KOM" , dataSheet.getCell(2 , i + 1).getContents());
                oMap.put(tableName , i , "DK_HESAP" , dataSheet.getCell(3 , i + 1).getContents());
                oMap.put(tableName , i , "DVZ" , dataSheet.getCell(4 , i + 1).getContents());
                oMap.put(tableName , i , "SUBE_KODU" , dataSheet.getCell(5 , i + 1).getContents());
                oMap.put(tableName , i , "B_A" , dataSheet.getCell(6 , i + 1).getContents());
                oMap.put(tableName , i , "TUTAR" , parseBigDecimal(dataSheet.getCell(7 , i + 1)));
                oMap.put(tableName , i , "MUHASEBE_TARIH" , ((DateCell)dataSheet.getCell(8, i + 1)).getDate());
                oMap.put(tableName , i , "TUR" , dataSheet.getCell(9 , i + 1).getContents());
            }
            return oMap;
        } 
        catch (IllegalArgumentException e){
            GMMap myMap = new GMMap();
            myMap.put("MESSAGE_NO" , new BigDecimal(1183));
            return AccountingChargesServices.throwGMBusssinessException((String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE" , myMap).get("ERROR_MESSAGE"));
        } 
        catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }        
        finally{
            if (workbook != null){
                workbook.close();
            }
        }
    }
    
    @GraymoundService("BNSPR_TRN1110_VIEW")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            List<?> list = session.createCriteria(MuhSubeKarZararAnaTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            String tableName = "FIS_LIST";
            int row = 0;
            for (Iterator<?> iterator = list.iterator(); iterator.hasNext();){
                MuhSubeKarZararAnaTx anaTx = (MuhSubeKarZararAnaTx)iterator.next();
                oMap.put(tableName , row , "SIRA_NO" , anaTx.getId().getSiraNo());
                oMap.put(tableName , row , "ACIKLAMA" , anaTx.getAciklama());
                oMap.put(tableName , row , "FAIZ_KOM" , anaTx.getFaizKomisyon());
                oMap.put(tableName , row , "DK_HESAP" , anaTx.getDkHesapNo());
                oMap.put(tableName , row , "DVZ" , anaTx.getDovizKodu());
                oMap.put(tableName , row , "SUBE_KODU" , anaTx.getSubeKodu());
                oMap.put(tableName , row , "B_A" , anaTx.getBorcAlacak());
                oMap.put(tableName , row , "TUTAR" , anaTx.getTutar());
                oMap.put(tableName , row , "MUHASEBE_TARIH" , anaTx.getMuhasebeTarih());
                oMap.put(tableName , row , "TUR" , anaTx.getTur());
                row++;
            }
            return oMap;
        } 
        catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }        
    }
    
    @GraymoundService("BNSPR_TRN1110_SAVE")
    public static Map<?, ?> save(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            String tableName = "FIS_LIST";
            List<?> list = (List<?>) iMap.get(tableName);
            for (int i = 0; i < list.size(); i++){
                MuhSubeKarZararAnaTxId id = new MuhSubeKarZararAnaTxId();
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                id.setSiraNo(iMap.getBigDecimal(tableName , i , "SIRA_NO"));
                MuhSubeKarZararAnaTx muhSubeKarZararAna = new MuhSubeKarZararAnaTx();
                muhSubeKarZararAna.setId(id);
                muhSubeKarZararAna.setAciklama(iMap.getString(tableName , i , "ACIKLAMA"));
                muhSubeKarZararAna.setFaizKomisyon(iMap.getString(tableName , i , "FAIZ_KOM"));
                muhSubeKarZararAna.setDkHesapNo(iMap.getString(tableName , i , "DK_HESAP"));
                muhSubeKarZararAna.setDovizKodu(iMap.getString(tableName , i , "DVZ"));
                muhSubeKarZararAna.setSubeKodu(iMap.getString(tableName , i , "SUBE_KODU"));
                muhSubeKarZararAna.setBorcAlacak(iMap.getString(tableName , i , "B_A"));
                muhSubeKarZararAna.setTutar(iMap.getBigDecimal(tableName , i , "TUTAR"));
                muhSubeKarZararAna.setMuhasebeTarih(iMap.getDate(tableName , i , "MUHASEBE_TARIH"));
                muhSubeKarZararAna.setTur(iMap.getString(tableName , i , "TUR"));
                muhSubeKarZararAna.setDrm("GIRIS");
                
                session.saveOrUpdate(muhSubeKarZararAna);
            }
            session.flush();
            iMap.put("TRX_NAME" , "1110");
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    private static void validateFile(Sheet dataSheet){
        for (int i = 0; i < dataSheet.getRows()-1; i++){
            String value = dataSheet.getCell(0 , i + 1).getContents(); //SIRA NO
            try{
                Double.parseDouble(value);
            }
            catch(NumberFormatException nfe){
                throwEx(i+2, "SIRA NO");
            }
            value = dataSheet.getCell(3 , i + 1).getContents(); //KEB�R
            if (value == null || value.equals("")){
                throwEx(i+2 , "KEB�R");
            }
            value = dataSheet.getCell(4 , i + 1).getContents(); //DVZ
            if (value == null || value.equals("")){
                throwEx(i+2 , "DVZ");
            }
            value = dataSheet.getCell(5 , i + 1).getContents(); //SUBE KODU
            if (value == null || value.equals("")){
                throwEx(i+2 , "�UBE KODU");
            }
            value = dataSheet.getCell(6 , i + 1).getContents(); // B/A
            if (value == null || value.equals("") || (!value.equals("B") && !value.equals("A"))){
                throwEx(i+2 , "B/A");
            }
            try{
                if(!(dataSheet.getCell(7 , i + 1) instanceof NumberCell)){ // TUTAR
                    throwEx(i+2, "TUTAR");
                }
                parseBigDecimal(dataSheet.getCell(7 , i + 1));
            }
            catch(Exception e){
                throwEx(i+2, "TUTAR");
            }
            try{
                if(!(dataSheet.getCell(8, i + 1) instanceof DateCell)){ // MUHASEBE TARIH
                    throwEx(i+2, "MUHASEBE TARIH");
                }
                ((DateCell)dataSheet.getCell(8, i + 1)).getDate();
            }
            catch(Exception e){
                throwEx(i+2, "MUHASEBE TARIH");
            }
        }
    }
    
    private static void throwEx(int satir, String kolon){
        GMMap myMap = new GMMap ();
        myMap.put("P1" , satir);
        myMap.put("P2" , kolon);
        myMap.put("MESSAGE_NO", new BigDecimal(1019));
        AccountingChargesServices.throwGMBusssinessException((String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE",myMap).get("ERROR_MESSAGE"));
    }
    
    private static BigDecimal parseBigDecimal(Cell cell){
        if(cell instanceof NumberCell){
            if(cell.getContents().contains("%")){
                return new BigDecimal(cell.getContents().replace('%', ' ').replace(',', '.').trim());
            }
            else{
                return new BigDecimal(((NumberCell)cell).getValue());             
            }
        }
        return null;
    }
}
