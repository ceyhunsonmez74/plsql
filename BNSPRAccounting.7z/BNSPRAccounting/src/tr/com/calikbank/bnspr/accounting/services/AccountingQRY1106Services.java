package tr.com.calikbank.bnspr.accounting.services;

import java.util.Calendar;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingQRY1106Services {
	
	@GraymoundService("BNSPR_QRY1106_DATE_CONTROL")
	public static GMMap dateControl(GMMap iMap){
		GMMap oMap = new GMMap();
		
		try{
			
			if(iMap.getDate("BAS_TARIH") != null && iMap.getDate("BIT_TARIH") != null){
				
				Calendar basTarih = Calendar.getInstance();
				basTarih.setTime(iMap.getDate("BAS_TARIH"));

				Calendar bitTarih = Calendar.getInstance();
				bitTarih.setTime(iMap.getDate("BIT_TARIH"));
				
				GMMap inputDates = new GMMap();
				inputDates.put("FIRST_DATE", basTarih.getTime());
				inputDates.put("SECOND_DATE", bitTarih.getTime());
				GMMap dayMap = GMServiceExecuter.call("BNSPR_COMMON_GUN_FARKI_HESAPLA", inputDates);
				
				if(bitTarih.getTimeInMillis() < basTarih.getTimeInMillis() || dayMap.getInt("DAYS") > 31)
				{
					iMap.put("HATA_NO", "2178");
					iMap.put("P1", "30");
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				
			}else{
				
				iMap.put("HATA_NO", "2178");
				iMap.put("P1", "30");
				GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
}
