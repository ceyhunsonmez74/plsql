package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.aktifbank.bnspr.dao.ClkPaScreenDescription;
import tr.com.aktifbank.bnspr.dao.ClkPaScreenDescriptionId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;

public class AccountingPAR1145Services {
	
	@GraymoundService("BNSPR_PAR1145_FILL_COMBOBOX")
	public static GMMap fillComboBox(GMMap iMap)
	{
		GMMap oMap = new GMMap();
		iMap.put("KOD", "PARMUH_GRUP_TIP");
		oMap.put("BOOK_TYPE_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "PARMUH_KAYNAK_TIPI");
		oMap.put("DESC_TYPE_LIST", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		return oMap;

	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_PAR1145_GET_PARMUH_DATA")
	public static GMMap getParMuhData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		ResultSet rSet2 = null;
		GMMap oMap = new GMMap();
		GMMap tempMap = new GMMap();
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PAR_BOOK_DESCRIPTION.RC_1145_MAIN(?,?,?)}");
			int i = 1;
			stmt.setString(i++, iMap.getString("EKRAN_NO"));
			stmt.registerOutParameter(i++, -10);
			stmt.registerOutParameter(i++, -10);
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(2);
			rSet2 = (ResultSet)stmt.getObject(3);

			String tableName = "TBL_PARBOOK";
			String tableName2 = "TBL_PARBOOK_DETAIL";
		
			int row = 0;
			int controlRow = 0;
			int detailRow = 0;
			
			while(rSet2.next()){
				oMap.put(tableName2, row, "SCREEN", rSet2.getString("SCREEN"));
				oMap.put(tableName2, row, "GROUP_", rSet2.getString("GROUP_"));
				oMap.put(tableName2, row, "BOOK_ID", rSet2.getBigDecimal("BOOK_ID"));
				oMap.put(tableName2, row, "LANGUAGE_CODE", rSet2.getString("LANGUAGE_CODE"));
				oMap.put(tableName2, row, "CUST_DESC_TYPE", rSet2.getString("CUST_DESC_TYPE"));
				oMap.put(tableName2, row, "CUST_DESCRIPTION", rSet2.getString("CUST_DESCRIPTION"));
				oMap.put(tableName2, row, "BANK_DESC_TYPE", rSet2.getString("BANK_DESC_TYPE"));
				oMap.put(tableName2, row, "BANK_DESCRIPTION", rSet2.getString("BANK_DESCRIPTION"));
				
				//Clear Context
				if(GMContext.getCurrentContext().getSession().get("GN_" + rSet2.getString("SCREEN") + "_" + rSet2.getString("GROUP_") + "_" +  rSet2.getBigDecimal("BOOK_ID").toPlainString()) != null){
					GMContext.getCurrentContext().getSession().put("GN_" + rSet2.getString("SCREEN") + "_" + rSet2.getString("GROUP_") + "_" +  rSet2.getBigDecimal("BOOK_ID").toPlainString(), null);
				}
				
				row++;
			}
			
			row = 0;
			while(rSet.next()){
				oMap.put(tableName, row, "SCREEN", rSet.getString("SCREEN"));
				oMap.put(tableName, row, "GROUP_", rSet.getString("GROUP_"));
				oMap.put(tableName, row, "BOOK_ID", rSet.getBigDecimal("BOOK_ID"));
				oMap.put(tableName, row, "BOOK_TYPE", rSet.getString("BOOK_TYPE"));
				oMap.put(tableName, row, "BOOK_NAME", rSet.getString("BOOK_NAME"));
				oMap.put(tableName, row, "EXP", rSet.getString("EXP"));
				oMap.put(tableName, row, "ROW_GROUP", rSet.getString("ROW_GROUP"));
				
				
				for(controlRow=0 ; controlRow < oMap.getSize(tableName2) ; controlRow++ ){
				    
				    if(rSet.getString("GROUP_").equals(oMap.get(tableName2, controlRow, "GROUP_")) && rSet.getBigDecimal("BOOK_ID").toPlainString().equals(oMap.get(tableName2, controlRow, "BOOK_ID"))){
				        
        					if(GMContext.getCurrentContext().getSession().get("GN_" + rSet.getString("SCREEN") + "_" + rSet.getString("GROUP_") + "_" +  rSet.getBigDecimal("BOOK_ID").toPlainString()) != null){
        						List<GMMap> tempList = (List<GMMap>) GMContext.getCurrentContext().getSession().get("GN_" + rSet.getString("SCREEN") + "_" + rSet.getString("GROUP_") + "_" +  rSet.getBigDecimal("BOOK_ID").toPlainString());
        						tempList.add(detailRow,oMap.getMap(tableName2, controlRow));
        						tempMap.put("TEMP",tempList);
        					}else{
        						tempMap.put("TEMP", detailRow, oMap.getMap(tableName2, controlRow));
        					}
        					
        					GMContext.getCurrentContext().getSession().put("GN_" + rSet.getString("SCREEN") + "_" + rSet.getString("GROUP_") +"_" + rSet.getBigDecimal("BOOK_ID").toPlainString(), tempMap.get("TEMP"));
        					detailRow++;
        					tempMap.clear();
				    }
				}
				
				detailRow = 0;
				row++;
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet2);
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_PAR1145_GET_DETAIL_DATA")
	public static GMMap getDetailData(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			oMap.put("PARBOOK_DETAIL", (List<GMMap>) GMContext.getCurrentContext().getSession().get("GN_" + iMap.getString("SCREEN") + "_" + iMap.getString("GROUP_") + "_" +  iMap.getBigDecimal("BOOK_ID").toPlainString()));
			return oMap;
		}catch(Exception ex){
			throw ExceptionHandler.convertException(ex);
		}
	}
	
	@GraymoundService("BNSPR_PAR1145_PUT_TO_CONTEXT")
	public static GMMap putToContext(GMMap iMap) {
		GMMap oMap = new GMMap();
		try{
			GMContext.getCurrentContext().getSession().put("GN_" + iMap.getString("SCREEN") + "_" + iMap.getString("GROUP_") +"_" + iMap.getBigDecimal("BOOK_ID"), iMap.get("PARBOOK_DETAIL"));
			return oMap;
		}catch(Exception ex){
			throw ExceptionHandler.convertException(ex);
		}
	}
	
	@GraymoundService("BNSPR_PAR1145_GET_PARAMETER")
	public static GMMap getParameter(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_PAR_BOOK_DESCRIPTION.RC_1145_params(?)}");
			int i = 1;	
			
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("EKRAN_NO"));
			stmt.execute();		

			String tableName = "TBL_PARAMETER";
			rSet = (ResultSet)stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet, tableName));
			
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_PAR1145_CONFIRM")
	public static GMMap confirm(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			
			if(iMap.getString("EKRAN") != null && iMap.getString("EKRAN").trim().length() > 0){
				
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call PKG_PAR_BOOK_DESCRIPTION.Onayla(?)}");
				stmt.setString(1, iMap.getString("EKRAN"));
				stmt.execute();
				
			}
			
			oMap.put("MESSAGE","��lem Tamamlanm��t�r.");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_PAR1145_SAVE")
	public static GMMap save(GMMap iMap)
	{
		GMMap oMap = new GMMap();
		try {
			
			GMMap tempMap = new GMMap();
			String tableName = "PARBOOK";
			String tableName2 = "TEMP";
			
			if(iMap.get(tableName) != null && iMap.getSize(tableName) > 0){
				
				Session session = DAOSession.getSession("BNSPRDal");
				
				for(int i =0; i<iMap.getSize(tableName); i++){
					
					List<ClkPaScreenDescription> descList = (List<ClkPaScreenDescription>) session.createCriteria(ClkPaScreenDescription.class)
																								.add(Restrictions.eq("id.screen", iMap.getString(tableName, i, "SCREEN")))
																								.add(Restrictions.eq("id.group", iMap.getString(tableName, i, "GROUP_")))
																								.add(Restrictions.eq("id.bookId", iMap.getBigDecimal(tableName, i, "BOOK_ID")))
																								.list();
					
					for(ClkPaScreenDescription clearDesc : descList){
						session.delete(clearDesc);
						session.flush();
					}
					
					tempMap.put(tableName2 ,GMContext.getCurrentContext().getSession().get("GN_" + iMap.getString(tableName, i, "SCREEN") + "_" + iMap.getString(tableName, i, "GROUP_") + "_" +  iMap.getBigDecimal(tableName, i, "BOOK_ID")));

					if(tempMap.get(tableName2) != null && tempMap.getSize(tableName2) > 0){

						for(int k=0; k<tempMap.getSize(tableName2); k++){

							ClkPaScreenDescriptionId newId = new ClkPaScreenDescriptionId();
							newId.setScreen(tempMap.getString(tableName2,k,"SCREEN"));
							newId.setGroup(tempMap.getString(tableName2,k,"GROUP_"));
							newId.setBookId(tempMap.getBigDecimal(tableName2,k,"BOOK_ID"));
							newId.setLanguageCode(tempMap.getString(tableName2,k,"LANGUAGE_CODE"));

							ClkPaScreenDescription newRecord = new ClkPaScreenDescription();
							newRecord.setId(newId);
							newRecord.setCustDescType(tempMap.getString(tableName2,k,"CUST_DESC_TYPE"));
							newRecord.setCustDescription(tempMap.getString(tableName2,k,"CUST_DESCRIPTION"));
							newRecord.setBankDescType(tempMap.getString(tableName2,k,"BANK_DESC_TYPE"));
							newRecord.setBankDescription(tempMap.getString(tableName2,k,"BANK_DESCRIPTION"));

							session.save(newRecord);
							session.flush();
						}

					}
					
					tempMap.clear();
					
				}
			
			}

			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
