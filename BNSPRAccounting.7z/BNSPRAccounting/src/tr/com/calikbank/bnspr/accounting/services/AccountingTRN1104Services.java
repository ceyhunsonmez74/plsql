package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.aktifbank.bnspr.dao.MuhHpTanimTx;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1104Services {
	
	@GraymoundService("BNSPR_TRN1104_SAVE")
	public static GMMap save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			MuhHpTanimTx muhHpTanim = (MuhHpTanimTx)session.get(MuhHpTanimTx.class, iMap.getBigDecimal("TRX_NO"));

			if(muhHpTanim == null)
				muhHpTanim = new MuhHpTanimTx();
			
			muhHpTanim.setTxNo(iMap.getBigDecimal("TRX_NO"));
			muhHpTanim.setKarsiSubeyeKapaliMi(iMap
					.getString("KARSI_SUBEYE_KAPALI_MI"));
			muhHpTanim.setHesapTerseDonsunMu(iMap
					.getString("HESAP_TERSE_DONSUN_MU"));
			muhHpTanim.setAlthesapMi(iMap.getString("ALTHESAP_MI"));
			muhHpTanim.setSubeyeKapaliMi(iMap.getString("SUBEYE_KAPALI_MI"));
			muhHpTanim.setGenelMdKapaliMi(iMap.getString("GENEL_MD_KAPALI_MI"));
			muhHpTanim.setFaizHesaplanacakMi(iMap
					.getString("FAIZ_HESAPLANACAK_MI"));
			muhHpTanim
					.setPersoneleBagliMi(iMap.getString("PERSONELE_BAGLI_MI"));
			muhHpTanim.setSbaKapaliMi(iMap.getString("SBA_KAPALI_MI"));
			muhHpTanim.setBaKod(iMap.getString("BA_KOD"));
			muhHpTanim.setHesapNo(iMap.getString("NUMARA"));
			muhHpTanim.setDkSinif(iMap.getString("DK_SINIF"));
			muhHpTanim.setDkKisaIsim(iMap.getString("DK_KISA_ISIM"));
			muhHpTanim.setAciklama(iMap.getString("ACIKLAMA"));
			muhHpTanim.setMusteriliHesapMi(iMap.getString("MUSTERILI_HESAP_MI"));
			
			muhHpTanim.setHesapNo(iMap.getString("HESAP_NO"));
			muhHpTanim.setBaslangicTarihi(iMap.getDate("BASLANGIC_TARIHI"));
			muhHpTanim.setBitisTarihi(iMap.getDate("BITIS_TARIHI"));
			muhHpTanim.setTumDovizSubelerAcilacakMi(iMap.getString("AUTO_DOVIZ"));
			
			session.saveOrUpdate(muhHpTanim);
			session.flush();
			
			iMap.put("TRX_NAME", "1104");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1104_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			MuhHpTanimTx muhHpTanim = (MuhHpTanimTx)session.get(MuhHpTanimTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", muhHpTanim.getTxNo());
			if("E".equals(muhHpTanim.getKarsiSubeyeKapaliMi()))
				oMap.put("KARSI_SUBEYE_KAPALI_MI", true);
			else
				oMap.put("KARSI_SUBEYE_KAPALI_MI", false);
			
			if("E".equals(muhHpTanim.getHesapTerseDonsunMu()))
				oMap.put("HESAP_TERSE_DONSUN_MU", true);
			else
				oMap.put("HESAP_TERSE_DONSUN_MU", false);
			
			if("E".equals(muhHpTanim.getAlthesapMi()))
				oMap.put("ALTHESAP_MI", true);
			else
				oMap.put("ALTHESAP_MI", false);
			
			if("E".equals(muhHpTanim.getSubeyeKapaliMi()))
				oMap.put("SUBEYE_KAPALI_MI", true);
			else
				oMap.put("SUBEYE_KAPALI_MI", false);
			
			if("E".equals(muhHpTanim.getGenelMdKapaliMi()))
				oMap.put("GENEL_MD_KAPALI_MI", true);
			else
				oMap.put("GENEL_MD_KAPALI_MI", false);
			
			if("E".equals(muhHpTanim.getFaizHesaplanacakMi()))
				oMap.put("FAIZ_HESAPLANACAK_MI", true);
			else
				oMap.put("FAIZ_HESAPLANACAK_MI", false);
			
			if("E".equals(muhHpTanim.getPersoneleBagliMi()))
				oMap.put("PERSONELE_BAGLI_MI", true);
			else
				oMap.put("PERSONELE_BAGLI_MI", false);
			
			if("E".equals(muhHpTanim.getSbaKapaliMi()))
				oMap.put("SBA_KAPALI_MI", true);
			else
				oMap.put("SBA_KAPALI_MI", false);
			
			if("E".equals(muhHpTanim.getMusteriliHesapMi()))
				oMap.put("MUSTERILI_HESAP_MI", true);
			else
				oMap.put("MUSTERILI_HESAP_MI", false);
			
			if("E".equals(muhHpTanim.getTumDovizSubelerAcilacakMi()))
				oMap.put("AUTO_DOVIZ", true);
			else
				oMap.put("AUTO_DOVIZ", false);
			
			oMap.put("BA_KOD", muhHpTanim.getBaKod());
			oMap.put("NUMARA", muhHpTanim.getHesapNo());
			oMap.put("DK_SINIF", muhHpTanim.getDkSinif());
			oMap.put("DK_KISA_ISIM", muhHpTanim.getDkKisaIsim());
			oMap.put("ACIKLAMA", muhHpTanim.getAciklama());
			
			oMap.put("HESAP_NO", muhHpTanim.getHesapNo());
			oMap.put("BASLANGIC_TARIHI", muhHpTanim.getBaslangicTarihi());
			oMap.put("BITIS_TARIHI", muhHpTanim.getBitisTarihi());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1104_HESAP_YARAT")
	public static GMMap hesapYarat(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_hp.hesap_yarat(?,?,?)}");
			stmt.setString(1, iMap.getString("HESAP_NO"));
			Date baslangicTarihi =  iMap.getDate("BASLANGIC_TARIHI");
			Date bitisTarihi =  iMap.getDate("BITIS_TARIHI");
			if (baslangicTarihi != null)
				stmt.setDate(2, new java.sql.Date(baslangicTarihi.getTime()));
			else
				stmt.setDate(2, null);

			if (bitisTarihi != null)
				stmt.setDate(3, new java.sql.Date(bitisTarihi.getTime()));
			else
				stmt.setDate(3, null);

			stmt.execute();
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} catch (ParseException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
}
