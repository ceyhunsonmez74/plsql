package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMasrafKomKriterTx;
import tr.com.calikbank.bnspr.dao.GnlMusteriMaskomMuafTx;
import tr.com.calikbank.bnspr.dao.GnlMusteriMaskomMuafTxId;
import tr.com.calikbank.bnspr.dao.GnlMusteriMaskomTanimPrTx;
import tr.com.calikbank.bnspr.dao.GnlMusteriMaskomTanimPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1162Services {
	@GraymoundService("BNSPR_TRN1162_GET_TRX_NO")
	public static GMMap getTrxNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn
					.prepareCall("{? = call PKG_TRN1162.get_parameters(?,?,?)}");
			
			stmt.registerOutParameter(1, Types.DECIMAL);
			
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(3, iMap.getString("KANAL_Q"));
			stmt.setString(4, iMap.getString("STATU_Q"));
						
			stmt.execute();

			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN1162_GET_MUSTERI_MASKOM_MUAF_LIST")
	public static GMMap getMusteriMaskomMuafList(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(GnlMusteriMaskomMuafTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "MUSTERI_MASKOM_MUAF";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlMusteriMaskomMuafTx gnlMusteriMaskomMuafTx = (GnlMusteriMaskomMuafTx)iterator.next();

				if (gnlMusteriMaskomMuafTx.getDrm().equals("I"))
					oMap.put(tableName, row,"DRM","1");
				else
					oMap.put(tableName, row,"DRM","0");
				
				oMap.put(tableName, row,"END_DATE",gnlMusteriMaskomMuafTx.getEndDate());
				oMap.put(tableName, row,"KANAL_KOD",gnlMusteriMaskomMuafTx.getKanalKod());
				oMap.put(tableName, row,"MUSTERI_MUAF_ID",gnlMusteriMaskomMuafTx.getId().getMusteriMuafId());
				oMap.put(tableName, row,"MUSTERI_NO",gnlMusteriMaskomMuafTx.getMusteriNo());
				oMap.put(tableName, row,"START_DATE",gnlMusteriMaskomMuafTx.getStartDate());
				
				oMap.put(tableName, row,"ESKI_KAYIT" ,"ESKI");
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1162_GET_MUSTERI_MASKOM_TANIM_PR_LIST")
	public static GMMap getMusteriMaskomTanimPrList(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(GnlMusteriMaskomTanimPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "MUSTERI_MASKOM_TANIM_PR";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlMusteriMaskomTanimPrTx gnlMusteriMaskomTanimPrTx = (GnlMusteriMaskomTanimPrTx)iterator.next();

				if (gnlMusteriMaskomTanimPrTx.getDrm().equals("I"))
					oMap.put(tableName, row,"DRM","1");
				else
					oMap.put(tableName, row,"DRM","0");
				
				oMap.put(tableName, row,"END_DATE",gnlMusteriMaskomTanimPrTx.getEndDate());
				oMap.put(tableName, row,"ISLEM_KOD",gnlMusteriMaskomTanimPrTx.getIslemKod());
				oMap.put(tableName, row,"DI_ISLEM_KOD",LovHelper.diLov(gnlMusteriMaskomTanimPrTx.getIslemKod(),"1162/LOV_ISLEM","ISLEM_ADI"));
				oMap.put(tableName, row,"KANAL_KOD",gnlMusteriMaskomTanimPrTx.getKanalKod());
				oMap.put(tableName, row,"MASKOM_KATSAYI",gnlMusteriMaskomTanimPrTx.getMaskomKatsayi());
				oMap.put(tableName, row,"MASKOM_KOD",gnlMusteriMaskomTanimPrTx.getMaskomKod());
				oMap.put(tableName, row,"MASKOM_ORAN",gnlMusteriMaskomTanimPrTx.getMaskomOran());
				oMap.put(tableName, row,"MASKOM_TUTAR",gnlMusteriMaskomTanimPrTx.getMaskomTutar());
				oMap.put(tableName, row,"MUSTERI_MASKOM_ID",gnlMusteriMaskomTanimPrTx.getId().getMusteriMaskomId());
				oMap.put(tableName, row, "START_DATE",gnlMusteriMaskomTanimPrTx.getStartDate());
				
				oMap.put(tableName, row,"ESKI_KAYIT" ,"ESKI");
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1162_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "MUSTERI_MASKOM_MUAF";
			List<?> list = (List<?>)iMap.get("MUSTERI_MASKOM_MUAF");
			for (int i = 0; i < list.size(); i++) {
				GnlMusteriMaskomMuafTxId gnlMusteriMaskomMuafTxId = new GnlMusteriMaskomMuafTxId();
				gnlMusteriMaskomMuafTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlMusteriMaskomMuafTxId.setMusteriMuafId(iMap.getBigDecimal(tableName, i , "MUSTERI_MUAF_ID"));
				
				GnlMusteriMaskomMuafTx gnlMusteriMaskomMuafTx = (GnlMusteriMaskomMuafTx)session.get(GnlMusteriMaskomMuafTx.class, gnlMusteriMaskomMuafTxId);
				
				if(gnlMusteriMaskomMuafTx == null)gnlMusteriMaskomMuafTx = new GnlMusteriMaskomMuafTx();
				
				gnlMusteriMaskomMuafTx.setId(gnlMusteriMaskomMuafTxId);
				if (iMap.getString(tableName,i,"DRM").equals("1")) gnlMusteriMaskomMuafTx.setDrm("I");
				else gnlMusteriMaskomMuafTx.setDrm("A");
				gnlMusteriMaskomMuafTx.setEndDate(iMap.getDate(tableName, i, "END_DATE"));
				gnlMusteriMaskomMuafTx.setKanalKod(iMap.getString(tableName, i, "KANAL_KOD"));
				gnlMusteriMaskomMuafTx.setMusteriNo(iMap.getBigDecimal(tableName, i , "MUSTERI_NO"));
				gnlMusteriMaskomMuafTx.setStartDate(iMap.getDate(tableName, i, "START_DATE"));
				
				session.saveOrUpdate(gnlMusteriMaskomMuafTx);
			}
			session.flush();
			
			tableName = "MUSTERI_MASKOM_TANIM_PR";
			List<?> list1 = (List<?>)iMap.get("MUSTERI_MASKOM_TANIM_PR");
			for (int i = 0; i < list1.size(); i++) {
				GnlMusteriMaskomTanimPrTxId gnlMusteriMaskomTanimPrTxId = new GnlMusteriMaskomTanimPrTxId();
				gnlMusteriMaskomTanimPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlMusteriMaskomTanimPrTxId.setMusteriMaskomId(iMap.getBigDecimal(tableName, i , "MUSTERI_MASKOM_ID"));
				
				GnlMusteriMaskomTanimPrTx gnlMusteriMaskomTanimPrTx = (GnlMusteriMaskomTanimPrTx)session.get(GnlMusteriMaskomTanimPrTx.class, gnlMusteriMaskomTanimPrTxId);
				
				if(gnlMusteriMaskomTanimPrTx == null)gnlMusteriMaskomTanimPrTx = new GnlMusteriMaskomTanimPrTx();
				
				gnlMusteriMaskomTanimPrTx.setId(gnlMusteriMaskomTanimPrTxId);
				if (iMap.getString(tableName,i,"DRM").equals("1")) gnlMusteriMaskomTanimPrTx.setDrm("I");
				else gnlMusteriMaskomTanimPrTx.setDrm("A");
				gnlMusteriMaskomTanimPrTx.setEndDate(iMap.getDate(tableName, i, "END_DATE"));
				gnlMusteriMaskomTanimPrTx.setIslemKod(iMap.getBigDecimal(tableName, i, "ISLEM_KOD"));
				gnlMusteriMaskomTanimPrTx.setKanalKod(iMap.getString(tableName, i, "KANAL_KOD"));
				gnlMusteriMaskomTanimPrTx.setMaskomKatsayi(iMap.getBigDecimal(tableName, i, "MASKOM_KATSAYI"));
				gnlMusteriMaskomTanimPrTx.setMaskomKod(iMap.getString(tableName, i, "MASKOM_KOD"));
				gnlMusteriMaskomTanimPrTx.setMaskomOran(iMap.getBigDecimal(tableName, i, "MASKOM_ORAN"));
				gnlMusteriMaskomTanimPrTx.setMaskomTutar(iMap.getBigDecimal(tableName, i, "MASKOM_TUTAR"));
				gnlMusteriMaskomTanimPrTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				gnlMusteriMaskomTanimPrTx.setStartDate(iMap.getDate(tableName, i, "START_DATE"));
				
				session.saveOrUpdate(gnlMusteriMaskomTanimPrTx);
			}
			session.flush();
			
			GnlMasrafKomKriterTx gnlMasrafKomKriterTx = new GnlMasrafKomKriterTx();
			
			gnlMasrafKomKriterTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			gnlMasrafKomKriterTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			gnlMasrafKomKriterTx.setDrm(iMap.getString("STATU"));
			gnlMasrafKomKriterTx.setKanalKod(iMap.getString("KANAL_KOD"));
			
			session.save(gnlMasrafKomKriterTx);
			session.flush();
			
			iMap.put("TRX_NAME", "1162");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1162_GET_MUSTERI_MASKOM_MUAF_TANIM_INFO")
	public static GMMap getMusteriMaskomMuafTanimInfo(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> muafList = session.createCriteria(GnlMusteriMaskomMuafTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "MUSTERI_MASKOM_MUAF";
			int row = 0;
			for (Iterator<?> iterator = muafList.iterator(); iterator.hasNext();) {
				GnlMusteriMaskomMuafTx gnlMusteriMaskomMuafTx = (GnlMusteriMaskomMuafTx)iterator.next();
				
				if (gnlMusteriMaskomMuafTx.getDrm().equals("I"))
					oMap.put(tableName, row,"DRM","1");
				else
					oMap.put(tableName, row,"DRM","0");
				oMap.put(tableName, row, "END_DATE",gnlMusteriMaskomMuafTx.getEndDate());
				oMap.put(tableName, row, "KANAL_KOD",gnlMusteriMaskomMuafTx.getKanalKod());
				oMap.put(tableName, row, "MUSTERI_GRUP_KOD",gnlMusteriMaskomMuafTx.getMusteriNo());
				oMap.put(tableName, row, "START_DATE",gnlMusteriMaskomMuafTx.getStartDate());
				
				row++;
			}
			
			List<?> tnmList = session.createCriteria(GnlMusteriMaskomTanimPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			tableName = "MUSTERI_MASKOM_TANIM_PR";
			row = 0;
			for (Iterator<?> iterator = tnmList.iterator(); iterator.hasNext();) {
				GnlMusteriMaskomTanimPrTx gnlMusteriMaskomTanimPrTx = (GnlMusteriMaskomTanimPrTx)iterator.next();
				
				if (gnlMusteriMaskomTanimPrTx.getDrm().equals("I"))
					oMap.put(tableName, row,"DRM","1");
				else
					oMap.put(tableName, row,"DRM","0");
				oMap.put(tableName, row, "END_DATE",gnlMusteriMaskomTanimPrTx.getEndDate());
				oMap.put(tableName, row, "ISLEM_KOD",gnlMusteriMaskomTanimPrTx.getIslemKod());
				oMap.put(tableName, row,"DI_ISLEM_KOD",LovHelper.diLov(gnlMusteriMaskomTanimPrTx.getIslemKod(),"1162/LOV_ISLEM","ISLEM_ADI"));
				oMap.put(tableName, row, "KANAL_KOD",gnlMusteriMaskomTanimPrTx.getKanalKod());
				oMap.put(tableName, row, "MASKOM_KATSAYI",gnlMusteriMaskomTanimPrTx.getMaskomKatsayi());
				oMap.put(tableName, row, "MASKOM_KOD",gnlMusteriMaskomTanimPrTx.getMaskomKod());
				oMap.put(tableName, row, "MASKOM_ORAN",gnlMusteriMaskomTanimPrTx.getMaskomOran());
				oMap.put(tableName, row, "MASKOM_TUTAR",gnlMusteriMaskomTanimPrTx.getMaskomTutar());
				oMap.put(tableName, row, "MUSTERI_GRUP_KOD",gnlMusteriMaskomTanimPrTx.getMusteriNo());
				oMap.put(tableName, row, "START_DATE",gnlMusteriMaskomTanimPrTx.getStartDate());
				
				row++;
			}
			
			GnlMasrafKomKriterTx gnlMasrafKomKriterTx = (GnlMasrafKomKriterTx)session.get(GnlMasrafKomKriterTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", gnlMasrafKomKriterTx.getTxNo());
			oMap.put("MUSTERI_NO", gnlMasrafKomKriterTx.getMusteriNo());
			oMap.put("MUSTERI_ADI", LovHelper.diLov(gnlMasrafKomKriterTx.getMusteriNo(), "1162/LOV_MUSTERI_BILGI", "ID_DESC"));
			oMap.put("KANAL_KOD", gnlMasrafKomKriterTx.getKanalKod());
			oMap.put("KANAL_ADI", LovHelper.diLov(gnlMasrafKomKriterTx.getKanalKod(), "1162/LOV_KANAL", "ACIKLAMA"));
			oMap.put("STATU", gnlMasrafKomKriterTx.getDrm());
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
