package tr.com.calikbank.bnspr.accounting.services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MustakrizDevirDetailTx;
import tr.com.aktifbank.bnspr.dao.MustakrizDevirDetailTxId;
import tr.com.aktifbank.bnspr.dao.MustakrizDevirMainTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1158Services {
    
    
	
    @GraymoundService("BNSPR_TRN1158_SAVE")
    public static GMMap save(GMMap iMap) {
       
        Session session = DAOSession.getSession("BNSPRDal");
        try{
            MustakrizDevirMainTx devirMain = new MustakrizDevirMainTx();
            devirMain.setDevirTuru(iMap.getString("DEVIR_TURU"));
            devirMain.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
            devirMain.setTxNo(iMap.getBigDecimal("TRX_NO"));
            session.saveOrUpdate(devirMain);
            
            int sizeOfArray = iMap.getSize("LIST");
            
            for (int i = 0; i < sizeOfArray; i++){
                if(iMap.getBoolean("LIST", i, "SEC"))
                {
                    MustakrizDevirDetailTxId detailId = new MustakrizDevirDetailTxId();
                    detailId.setHesapNo(iMap.getBigDecimal("LIST",i,"HESAP_NO"));
                   
                    detailId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    
                    MustakrizDevirDetailTx detailObj = new MustakrizDevirDetailTx();
                    detailObj.setId(detailId);
                    detailObj.setDovizKod(iMap.getString("LIST",i,"DOVIZ_KODU"));
                    detailObj.setModulTurKod(iMap.getString("LIST",i,"MODUL_TUR_KOD"));
                    detailObj.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
                    detailObj.setSubeKodu(iMap.getString("LIST",i,"SUBE_KODU"));
                    detailObj.setUrunSinifKod(iMap.getString("LIST",i,"URUN_SINIF_KOD"));
                    detailObj.setUrunTurKod(iMap.getString("LIST",i,"URUN_TUR_KOD"));
                    detailObj.setMusteriDkNo(iMap.getString("LIST",i,"MUSTERI_DK_NO"));
                    session.saveOrUpdate(detailObj);
                    
                }
            }
            session.flush();
            iMap.put("TRX_NAME" , "1158");
            return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
     
    }

    @GraymoundService("BNSPR_TRN1158_TUMUNU_SEC")
    public static GMMap tumunuSec(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
          
                String tableName = "LIST";
                List<?> list = (List<?>)iMap.get(tableName);
                for(int i=0;i<list.size();i++)
                {
                    iMap.put(tableName, i,"SEC",iMap.getBoolean("TUMUNU_SEC"));
                }
                return iMap;
           
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }

    }


    @GraymoundService("BNSPR_TRN1158_GET_LIST")
    public static GMMap getList(GMMap iMap) {
        GMMap oMap = new GMMap();
       
        try{
            String func = "{? = call PKG_TRN1158.mustakriz_liste(?,?)}";
            Object[] inputValues =
                    new Object[] { BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),BnsprType.STRING,iMap.getString("ISLEM_TURU")};
            
            oMap = DALUtil.callOracleRefCursorFunction(func , "LIST" , inputValues);
            oMap.put("DEVIR_TURU" ,iMap.getString("ISLEM_TURU"));
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN1158_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");
        
        try{
            MustakrizDevirMainTx mainTx = (MustakrizDevirMainTx) session.createCriteria(MustakrizDevirMainTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            oMap.put("DEVIR_TURU" , mainTx.getDevirTuru());
            oMap.put("MUSTERI_NO" , mainTx.getMusteriNo());
            oMap.put("TRX_NO" , mainTx.getTxNo());
            
            List<MustakrizDevirDetailTx> detailTxList = session.createCriteria(MustakrizDevirDetailTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            
                int row = 0;
                
                for(MustakrizDevirDetailTx detailTxObj : detailTxList){
                    oMap.put("LIST", row, "SEC",Boolean.TRUE);
                    oMap.put("LIST", row, "HESAP_NO",detailTxObj.getId().getHesapNo());
                    oMap.put("LIST", row, "SUBE_KODU",detailTxObj.getSubeKodu());
                    oMap.put("LIST", row, "MODUL_TUR_KOD",detailTxObj.getModulTurKod());
                    oMap.put("LIST", row, "URUN_TUR_KOD",detailTxObj.getUrunTurKod());
                    oMap.put("LIST", row, "URUN_SINIF_KOD",detailTxObj.getUrunSinifKod());
                    oMap.put("LIST", row, "DOVIZ_KODU",detailTxObj.getDovizKod());
                    oMap.put("LIST", row, "MUSTERI_DK_NO",detailTxObj.getMusteriDkNo());
                  row++;
                }
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }

}
