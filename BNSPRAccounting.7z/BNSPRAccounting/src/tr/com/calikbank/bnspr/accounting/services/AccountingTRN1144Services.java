package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.DbsAcente;
import tr.com.aktifbank.bnspr.dao.DbsAcenteSube;
import tr.com.aktifbank.bnspr.dao.DbsAcenteSubeTx;
import tr.com.aktifbank.bnspr.dao.DbsAcenteSubeTxId;
import tr.com.aktifbank.bnspr.dao.DbsAcenteTx;
import tr.com.aktifbank.bnspr.dao.DbsAcenteTxId;
import tr.com.aktifbank.bnspr.dao.DbsAnaFirma;
import tr.com.aktifbank.bnspr.dao.DbsAnaFirmaTx;
import tr.com.aktifbank.bnspr.dao.DbsAnaFirmaTxId;
import tr.com.aktifbank.bnspr.dao.GnlMusteriGrupTx;
import tr.com.aktifbank.bnspr.dao.ParmuhScreenTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMusteriBasvuruTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1144Services {

	
	@GraymoundService("BNSPR_PAR1144_GET_PARMUH_DATA")
	public static GMMap getParMuhData(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap tempMap = new GMMap();
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN1144.Get_Parmuh_data(?,?)}");
			int i = 1;
			stmt.setString(i++, iMap.getString("TX_NO"));
			stmt.setString(i++, iMap.getString("EKRAN_NO"));
			stmt.execute();
			
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			ParmuhScreenTx parmuhScreenTx = (ParmuhScreenTx) session.load(ParmuhScreenTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("SCREEN", parmuhScreenTx.getScreen());
			oMap.put("EXP", parmuhScreenTx.getExp());
			oMap.put("VOUCHER_EXP", parmuhScreenTx.getVoucherExp());
			oMap.put("VOUCHER_TYPE", parmuhScreenTx.getVoucherType());
			oMap.put("VOUCHER_REVOCABLE", parmuhScreenTx.getVoucherRevocable());
			oMap.put("FORCE_DEBIT", parmuhScreenTx.getForceDebit());
			

			// FIELDS
			List<?> fieldlist = (ArrayList<?>) session.createCriteria(GnlMusteriGrupTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName  = "CLK_PAA_SCREEN_FIELDS";
           
			int rowfield = 0;
			for (int row = 0; row < fieldlist.size(); row++) {
				    
				    GnlMusteriGrupTx gnlMusteriGrupTx = (GnlMusteriGrupTx) fieldlist.get(row);

					oMap.put(tableName, rowfield, "SCREEN", gnlMusteriGrupTx.getId().getMusteriGrupKod() );
					oMap.put(tableName, rowfield, "FIELD", LovHelper.diLov(gnlMusteriGrupTx.getId().getMusteriGrupKod(), "10011/LOV_MUSTERI_GRUBU", "ACIKLAMA"));
					oMap.put(tableName, rowfield, "PAR_NAME", gnlMusteriGrupTx.getMusteriGrupDetayKod() );
					oMap.put(tableName, rowfield, "PROMPT", LovHelper.diLov(gnlMusteriGrupTx.getMusteriGrupDetayKod(),gnlMusteriGrupTx.getId().getMusteriGrupKod(), "10011/LOV_MUSTERI_GRUP_DETAY", "ACIKLAMA"));
					oMap.put(tableName, rowfield, "TEST_VAL", gnlMusteriGrupTx.getId().getMusteriGrupKod() );
					oMap.put(tableName, rowfield, "TYPE_", gnlMusteriGrupTx.getId().getMusteriGrupKod() );
					rowfield++;
			}			

			// GROUP
			List<?> grouplist = (ArrayList<?>) session.createCriteria(GnlMusteriGrupTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			tableName  = "CLK_PAA_SCREEN_GROUP";
           
			int rowgroup = 0;
			for (int row = 0; row < grouplist.size(); row++) {
				    
				    GnlMusteriGrupTx gnlMusteriGrupTx = (GnlMusteriGrupTx) grouplist.get(row);

					oMap.put(tableName, rowgroup, "BASE_ACCOUNT", gnlMusteriGrupTx.getId().getMusteriGrupKod() );
					oMap.put(tableName, rowgroup, "EXP", LovHelper.diLov(gnlMusteriGrupTx.getId().getMusteriGrupKod(), "10011/LOV_MUSTERI_GRUBU", "ACIKLAMA"));
					oMap.put(tableName, rowgroup, "GROUP_", gnlMusteriGrupTx.getMusteriGrupDetayKod() );
					oMap.put(tableName, rowgroup, "ORDER_", LovHelper.diLov(gnlMusteriGrupTx.getMusteriGrupDetayKod(),gnlMusteriGrupTx.getId().getMusteriGrupKod(), "10011/LOV_MUSTERI_GRUP_DETAY", "ACIKLAMA"));
					oMap.put(tableName, rowgroup, "ROW_GROUP", gnlMusteriGrupTx.getId().getMusteriGrupKod() );
					oMap.put(tableName, rowgroup, "SCREEN", gnlMusteriGrupTx.getId().getMusteriGrupKod() );
					rowgroup++;
			}					
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
	}	
	

	@GraymoundService("BNSPR_TRN1144_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "CLK_PAA_SCREEN_GROUP";
			String tableName2= "CLK_PAA_SCREEN_GROUP_COND";
			String tableName3 = "CLK_PAA_SCREEN_GROUP_BOOK";
			String tableName4 = "CLK_PAA_SCREEN_GROUP_BOOK_VOUC";
			String tableName5 = "CLK_PAA_SCREEN_GROUP_BOOK_COND";
			String tableName6 = "CLK_PAA_SCREEN_FIELDS";
	
			//CLK_PAA_SCREEN_GROUP
			if(iMap.get(tableName) != null) {
				List<?> list = (List<?>) iMap.get(tableName);
				if(list.size() > 0) {
					for (int i = 0; i < list.size(); i++) {
						DbsAnaFirmaTx birAnaFirmaTx = new DbsAnaFirmaTx();
				
						DbsAnaFirmaTxId id = new DbsAnaFirmaTxId();
				
						id.setTxNo(iMap.getBigDecimal("TRX_NO"));
						id.setId(iMap.getBigDecimal(tableName, i, "ID"));
						birAnaFirmaTx.setId(id);
				
						birAnaFirmaTx.setKurumAdi(iMap.getString(tableName, i, "KURUM"));
						birAnaFirmaTx.setMusteriNo(iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
						birAnaFirmaTx.setEftBankaKodu(iMap.getString(tableName, i, "EFT_BANKA"));
						birAnaFirmaTx.setEftIlKodu(iMap.getString(tableName, i, "EFT_IL"));
						birAnaFirmaTx.setEftSubeKodu(iMap.getString(tableName, i, "EFT_SUBE"));
						birAnaFirmaTx.setEftHesapNo(iMap.getString(tableName, i, "EFT_HESAP_NO"));
						birAnaFirmaTx.setHesapNo(iMap.getBigDecimal(tableName, i, "KURUM_HESAP_NO"));
						birAnaFirmaTx.setDurum(iMap.getString(tableName, i, "DURUM"));
						
						//CLK_PAA_SCREEN_GROUP_COND
						if(iMap.get(tableName, i, tableName2) != null) {
							List<?> list2 = (List<?>) iMap.get(tableName, i, tableName2);
							if(list2.size() > 0) {
								for (int j = 0; j < list2.size(); j++) {
									GMMap acenteMap = new GMMap((HashMap<?, ?>)list2.get(j));
									
									DbsAcenteTx birAcenteTx = new DbsAcenteTx();
									
									DbsAcenteTxId Aid = new DbsAcenteTxId();
									
									Aid.setTxNo(iMap.getBigDecimal("TRX_NO"));
									Aid.setId(acenteMap.getBigDecimal("ID"));
									birAcenteTx.setId(Aid);
									
									birAcenteTx.setAnaFirmaId(acenteMap.getBigDecimal("ANAFIRMA_ID"));
									birAcenteTx.setKurumAdi(acenteMap.getString("KURUM"));
									birAcenteTx.setDurum(acenteMap.getString("DURUM"));
					
									//Acente Sube
									if(acenteMap.get(tableName3) != null) {
										List<?> list3 = (List<?>) acenteMap.get(tableName3);
										if(list3.size() > 0) {
											for (int k = 0; k < list3.size(); k++) {
												GMMap acenteSubeMap = new GMMap((HashMap<?, ?>)list3.get(k));
												
												DbsAcenteSubeTx birAcenteSubeTx = new DbsAcenteSubeTx();
												
												DbsAcenteSubeTxId Sid = new DbsAcenteSubeTxId();
												
												Sid.setTxNo(iMap.getBigDecimal("TRX_NO"));
												Sid.setId(acenteSubeMap.getBigDecimal("ID"));
												birAcenteSubeTx.setId(Sid);
												
												birAcenteSubeTx.setAcenteId(acenteSubeMap.getBigDecimal("ACENTE_ID"));
												birAcenteSubeTx.setSubeAdi(acenteSubeMap.getString("SUBE"));
												birAcenteSubeTx.setIataKodu(acenteSubeMap.getString("IATA"));
												birAcenteSubeTx.setMusteriNo(acenteSubeMap.getBigDecimal("MUSTERI_NO"));
												birAcenteSubeTx.setVdszHesapNo(acenteSubeMap.getBigDecimal("VADESIZ_HESAP_NO"));
												birAcenteSubeTx.setKrediliMi(acenteSubeMap.getString("KREDILI_MI"));
												birAcenteSubeTx.setKrdHesapNo(acenteSubeMap.getBigDecimal("KREDI_HESAP_NO"));
												birAcenteSubeTx.setLimit(acenteSubeMap.getBigDecimal("LIMIT"));
												birAcenteSubeTx.setDurum(acenteSubeMap.getString("DURUM"));
												
												session.save(birAcenteSubeTx);
												session.flush();
											}
										}
									}
					
									session.save(birAcenteTx);
									session.flush();
								}
							}
						}
				
						session.save(birAnaFirmaTx);
						session.flush();
					}
				}
			}
	
			iMap.put("TRX_NAME", "2095");		
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	
	
	@GraymoundService("BNSPR_TRN1144_GET_SCREEN")
	public static GMMap getScreen(GMMap iMap) {
			
			Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			GMMap oMap = new GMMap();
			
			try {
					
				conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{? = call PKG_TRN1144.Get_Screen(?)}"); 
				int i = 1;
				stmt.registerOutParameter(i++, -10);
				stmt.setString(i++, iMap.getString("SCREEN"));
				stmt.execute();
				int row = 0;
				rSet = (ResultSet) stmt.getObject(1);
				while(rSet.next()){

					oMap.put( "SCREEN", rSet.getString("SCREEN"));
					oMap.put( "EXP", rSet.getString("EXP"));
					oMap.put( "VOUCHER_EXP", rSet.getString("VOUCHER_EXP"));
					oMap.put( "VOUCHER_TYPE", rSet.getString("VOUCHER_TYPE"));
					oMap.put( "VOUCHER_REVOCABLE", rSet.getString("VOUCHER_REVOCABLE"));
					oMap.put( "FORCE_DEBIT", rSet.getString("FORCE_DEBIT"));
					row++;
				}
	

				return oMap;
				
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}	
	

	@GraymoundService("BNSPR_TRN1144_GET_CLKPAASCREENFIELD")
	public static GMMap getScreenField(GMMap iMap) {
			
			Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			GMMap oMap = new GMMap();
			
			try {
					
				conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{? = call PKG_TRN1144.Get_ScreenFields(?)}"); 
				int i = 1;
				stmt.registerOutParameter(i++, -10);
				stmt.setString(i++, iMap.getString("SCREEN"));
				stmt.execute();
				
				rSet = (ResultSet) stmt.getObject(1);

				String tableName = "CLK_PAA_SCREEN_FIELDS";
				int row = 0;
				
				while(rSet.next()){
					oMap.put(tableName, row, "SCREEN", rSet.getString("SCREEN"));
					oMap.put(tableName, row, "TYPE_", rSet.getString("TYPE_"));
					oMap.put(tableName, row, "TEST_VAL", rSet.getString("TEST_VAL"));
					oMap.put(tableName, row, "PROMPT", rSet.getString("PROMPT"));
					oMap.put(tableName, row, "PAR_NAME", rSet.getString("PAR_NAME"));
					oMap.put(tableName, row, "FIELD", rSet.getString("FIELD"));
					oMap.put("TABLO_ADI", rSet.getString("PROMPT") ) ;
					row++;
				}
				
				return oMap;
				
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}
	
	
	
	
	@GraymoundService("BNSPR_TRN1144_GET_CLKPAASCREENGROUP")
	public static GMMap getGroup(GMMap iMap) {
			
			Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			GMMap oMap = new GMMap();
			
			try {
					
				conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{? = call PKG_TRN1144.Get_ScreenGroup(?)}"); 
				int i = 1;
				stmt.registerOutParameter(i++, -10);
				stmt.setString(i++, iMap.getString("SCREEN"));
				stmt.execute();
				
				rSet = (ResultSet) stmt.getObject(1);

				String tableName = "CLK_PAA_SCREEN_GROUP";
				int row = 0;
				
				while(rSet.next()){
					oMap.put(tableName, row, "SCREEN", rSet.getString("SCREEN"));
					oMap.put(tableName, row, "GROUP_", rSet.getString("GROUP_"));
					oMap.put(tableName, row, "ORDER_", rSet.getBigDecimal("ORDER_"));
					oMap.put(tableName, row, "EXP", rSet.getString("EXP"));
					oMap.put(tableName, row, "ROW_GROUP", rSet.getString("ROW_GROUP"));
					oMap.put(tableName, row, "BASE_ACCOUNT", rSet.getString("BASE_ACCOUNT"));
					
					oMap.put(tableName, row, "CLK_PAA_SCREEN_GROUP_COND_INFO", GMServiceExecuter.call("BNSPR_TRN1144_GET_CLKPAASCREENGROUPCOND", new GMMap().put("SCREEN", iMap.getString("SCREEN")).put("GROUP_", rSet.getString("GROUP_")) ).get("CLK_PAA_SCREEN_GROUP_COND"));

					oMap.put(tableName, row, "CLK_PAA_SCREEN_GROUP_BOOK_INFO", GMServiceExecuter.call("BNSPR_TRN1144_GET_CLKPAASCREENGROUPBOOK", new GMMap().put("SCREEN", iMap.getString("SCREEN")).put("GROUP_", rSet.getString("GROUP_")) ).get("CLK_PAA_SCREEN_GROUP_BOOK"));
					
					row++;
				}
				
				return oMap;
				
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}

	
	@GraymoundService("BNSPR_TRN1144_GET_CLKPAASCREENGROUPCOND")
	public static GMMap getGroupCond(GMMap iMap) {
			
			Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			GMMap oMap = new GMMap();
			
			try {
				
				
				conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{? = call PKG_TRN1144.Get_ScreenGroupCond(?,?)}"); 
				int i = 1;
				stmt.registerOutParameter(i++, -10);
				stmt.setString(i++, iMap.getString("SCREEN"));
				stmt.setString(i++, iMap.getString("GROUP_"));
				stmt.execute();
				
				rSet = (ResultSet) stmt.getObject(1);

				String tableName = "CLK_PAA_SCREEN_GROUP_COND";
				int row = 0;
				
				while(rSet.next()){
					oMap.put(tableName, row, "SCREEN", rSet.getString("SCREEN"));
					oMap.put(tableName, row, "GROUP_", rSet.getString("GROUP_"));
					oMap.put(tableName, row, "COND_ID", rSet.getBigDecimal("COND_ID"));
					oMap.put(tableName, row, "COND", rSet.getString("COND"));
					
					row++;
				}
				
				return oMap;
				
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}
	
	@GraymoundService("BNSPR_TRN1144_GET_CLKPAASCREENGROUPBOOK")
	public static GMMap getGroupBook(GMMap iMap) {
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		
		try {
			
			
			conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN1144.Get_ScreenGroupBook(?,?)}"); 
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("SCREEN"));
			stmt.setString(i++, iMap.getString("GROUP_"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);

			String tableName = "CLK_PAA_SCREEN_GROUP_BOOK";
			int row = 0;
			
			while(rSet.next()){
				oMap.put(tableName, row, "SCREEN", rSet.getString("SCREEN"));
				oMap.put(tableName, row, "GROUP_", rSet.getString("GROUP_"));
				oMap.put(tableName, row, "BOOK_ID", rSet.getBigDecimal("BOOK_ID"));
				oMap.put(tableName, row, "BOOK_NAME", rSet.getString("BOOK_NAME"));
				oMap.put(tableName, row, "BOOK_TYPE", rSet.getString("BOOK_TYPE"));
				
				oMap.put(tableName, row, "CLK_PAA_SCREEN_GROUP_BOOK_COND_INFO", GMServiceExecuter.call("BNSPR_TRN1144_GET_CLKPAASCREENGROUPBOOKCOND", new GMMap().put("SCREEN", iMap.getString("SCREEN")).put("GROUP_", rSet.getString("GROUP_")).put("BOOK_ID", rSet.getString("BOOK_ID")) ).get("CLK_PAA_SCREEN_GROUP_BOOK_COND"));
				oMap.put(tableName, row, "CLK_PAA_SCREEN_GROUP_BOOK_VOUC_INFO", GMServiceExecuter.call("BNSPR_TRN1144_GET_CLKPAASCREENGROUPBOOKVOUC", new GMMap().put("SCREEN", iMap.getString("SCREEN")).put("GROUP_", rSet.getString("GROUP_")).put("BOOK_ID", rSet.getString("BOOK_ID")) ).get("CLK_PAA_SCREEN_GROUP_BOOK_VOUC"));

				row++;
			}
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}


	
	@GraymoundService("BNSPR_TRN1144_GET_CLKPAASCREENGROUPBOOKVOUC")
	public static GMMap getGroupBookVouc(GMMap iMap) {
	
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		
		try {
			
			
			conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN1144.Get_ScreenGroupBookVouc(?,?,?)}"); 
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("SCREEN"));
			stmt.setString(i++, iMap.getString("GROUP_"));
			stmt.setString(i++, iMap.getString("BOOK_ID"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);

			String tableName = "CLK_PAA_SCREEN_GROUP_BOOK_VOUC";
			int row = 0;
			
			while(rSet.next()){
				oMap.put(tableName, row, "SCREEN", rSet.getString("SCREEN"));
				oMap.put(tableName, row, "GROUP_", rSet.getString("GROUP_"));
				oMap.put(tableName, row, "BOOK_ID", rSet.getBigDecimal("BOOK_ID"));
				oMap.put(tableName, row, "VOUCHER_ORDER", rSet.getBigDecimal("VOUCHER_ORDER"));
				oMap.put(tableName, row, "VOUCHER_PAR_NAME", rSet.getString("VOUCHER_PAR_NAME"));
				oMap.put(tableName, row, "VOUCHER_SOURCE", rSet.getString("VOUCHER_SOURCE"));
				oMap.put(tableName, row, "VOUCHER_SOURCE_TYPE", rSet.getString("VOUCHER_SOURCE_TYPE"));				
				row++;
			}
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
	
	
	@GraymoundService("BNSPR_TRN1144_GET_CLKPAASCREENGROUPBOOKCOND")
	public static GMMap getGroupBookCond(GMMap iMap) {
	
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		
		try {
			
			
			conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN1144.Get_ScreenGroupBookCond(?,?,?)}"); 
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("SCREEN"));
			stmt.setString(i++, iMap.getString("GROUP_"));
			stmt.setString(i++, iMap.getString("BOOK_ID"));
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);

			String tableName = "CLK_PAA_SCREEN_GROUP_BOOK_COND";
			int row = 0;
			
			while(rSet.next()){
				oMap.put(tableName, row, "SCREEN", rSet.getString("SCREEN"));
				oMap.put(tableName, row, "GROUP_", rSet.getString("GROUP_"));
				oMap.put(tableName, row, "BOOK_ID", rSet.getBigDecimal("BOOK_ID"));
				oMap.put(tableName, row, "COND_ID", rSet.getBigDecimal("COND_ID"));
				oMap.put(tableName, row, "COND", rSet.getString("COND"));
				
				row++;
			}
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
		

	

	
	
	
	@GraymoundService("BNSPR_TRN1144_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(DbsAnaFirmaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "ANAFIRMA";
			int row = 0;
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				DbsAnaFirmaTx dbsAnaFirmaTx = (DbsAnaFirmaTx) iterator.next();

				oMap.put(tableName, row, "ID", dbsAnaFirmaTx.getId().getId());
				
				oMap.put(tableName, row, "KURUM", dbsAnaFirmaTx.getKurumAdi());
				oMap.put(tableName, row, "MUSTERI_NO", dbsAnaFirmaTx.getMusteriNo());
				oMap.put(tableName, row, "EFT_BANKA", dbsAnaFirmaTx.getEftBankaKodu());
				oMap.put(tableName, row, "EFT_IL", dbsAnaFirmaTx.getEftIlKodu());
				oMap.put(tableName, row, "EFT_SUBE", dbsAnaFirmaTx.getEftSubeKodu());
				oMap.put(tableName, row, "EFT_HESAP_NO", dbsAnaFirmaTx.getEftHesapNo());
				oMap.put(tableName, row, "KURUM_HESAP_NO", dbsAnaFirmaTx.getHesapNo());
				oMap.put(tableName, row, "DURUM", dbsAnaFirmaTx.getDurum());
				oMap.put(tableName, row, "DBCHECK", "OK");
				//oMap.put(tableName, row, "ACENTE_INFO", GMServiceExecuter.call("BNSPR_TRN1144_GET_ACENTE_LIST", new GMMap().put("ID", birDbsAnaFirmaTx.getId())).get("ACENTE"));

				List<?> list2 = (List<?>) session.createCriteria(DbsAcenteTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("anaFirmaId", dbsAnaFirmaTx.getId().getId())).list();
				
				GMMap oMap2 = new GMMap();
				String tableName2 = "ACENTE";
				int row2 = 0;
				
				for (Iterator<?> iterator2 = list2.iterator(); iterator2.hasNext();) {
					DbsAcenteTx dbsAcenteTx = (DbsAcenteTx) iterator2.next();

					oMap2.put(tableName2, row2, "ID", dbsAcenteTx.getId().getId());
					oMap2.put(tableName2, row2, "ANAFIRMA_ID", dbsAcenteTx.getAnaFirmaId());
					oMap2.put(tableName2, row2, "KURUM", dbsAcenteTx.getKurumAdi());
					oMap2.put(tableName2, row2, "DURUM", dbsAcenteTx.getDurum());
					oMap2.put(tableName2, row2, "DBCHECK", "OK");
					
					List<?> list3 = (List<?>) session.createCriteria(DbsAcenteSubeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("acenteId", dbsAcenteTx.getId().getId())).list();;
	
					GMMap oMap3 = new GMMap();
					String tableName3 = "ACENTE_SUBE";
					int row3 = 0;
					
					for (Iterator<?> iterator3 = list3.iterator(); iterator3.hasNext();) {
						DbsAcenteSubeTx dbsAcenteSubeTx = (DbsAcenteSubeTx) iterator3.next();

						oMap3.put(tableName3, row3, "ID", dbsAcenteSubeTx.getId().getId());
						oMap3.put(tableName3, row3, "ACENTE_ID", dbsAcenteSubeTx.getAcenteId());
						oMap3.put(tableName3, row3, "SUBE", dbsAcenteSubeTx.getSubeAdi());
						oMap3.put(tableName3, row3, "IATA", dbsAcenteSubeTx.getIataKodu());
						oMap3.put(tableName3, row3, "KREDILI_MI", dbsAcenteSubeTx.getKrediliMi());
						oMap3.put(tableName3, row3, "MUSTERI_NO", dbsAcenteSubeTx.getMusteriNo());
						oMap3.put(tableName3, row3, "VADESIZ_HESAP_NO", dbsAcenteSubeTx.getVdszHesapNo());
						oMap3.put(tableName3, row3, "KREDI_HESAP_NO", dbsAcenteSubeTx.getKrdHesapNo());
						oMap3.put(tableName3, row3, "LIMIT", LovHelper.diLov(dbsAcenteSubeTx.getKrdHesapNo(), dbsAcenteSubeTx.getMusteriNo(), dbsAcenteSubeTx.getMusteriNo(), "2095/LOV_KREDI_HESABI", "LIMIT"));				
						oMap3.put(tableName3, row3, "KULLANILABILIR_LIMIT", LovHelper.diLov(dbsAcenteSubeTx.getKrdHesapNo(), dbsAcenteSubeTx.getMusteriNo(), dbsAcenteSubeTx.getMusteriNo(), "2095/LOV_KREDI_HESABI", "KULL_LIMIT"));
						oMap3.put(tableName3, row3, "DURUM", dbsAcenteSubeTx.getDurum());
						oMap3.put(tableName3, row3, "DBCHECK", "OK");
						
						row3++;
					}
					oMap2.put(tableName2, row2, "ACENTE_SUBE_INFO", oMap3.get("ACENTE_SUBE"));
					row2++;
				}
				
				oMap.put(tableName, row, "ACENTE_INFO", oMap2.get("ACENTE"));
				row++;
			}
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	
	@GraymoundService("BNSPR_TRN1144_GET_COMBOBOX_INITIAL_VALUES")
	public static GMMap getComboboxInitialValues(GMMap iMap) {
		
		//Combobox de�erlerinin tan�mlanmas�
		GMMap oMap = new GMMap();
		
		iMap.put("KOD", "PARMUH_GRUP_TIP");
		oMap.put("BOOK_TYPE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "PARMUH_KAYNAK_TIPI");
		oMap.put("VOUCHER_SOURCE_TYPE", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "PARMUH_VOUCHER_PAR_NAME");
		oMap.put("VOUCHER_PAR_NAME", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		iMap.put("KOD", "PARMUH_FIELD_TYPE");
		oMap.put("TYPE_", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		return oMap;
			
	}
	
		


	
	
}
