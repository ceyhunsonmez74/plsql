package tr.com.calikbank.bnspr.accounting.services;


import java.io.File;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.text.DateFormat;
import java.util.Locale;

import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingQRY1101Services {
	private static String ROOT = GMServer.getProperty("graymound.home",null)+
	File.separator 	+
	"Server"		+
	File.separator 	+
	"Content"		+
	File.separator	+
	"Root"			;
	@GraymoundService("BNSPR_QRY1101_GET_DK_INFO")
	public static GMMap getDkInfo(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			/*pc_basDk varchar2, pc_bitDk varchar2, pc_dovizKodu varchar2, pc_subeKodu varchar2,
            pc_hareketTuru varchar2, pd_basTar date, pd_bitTar date, pn_basTutar number,
            pc_bitTutar number*/
			stmt = conn.prepareCall("{? = call pkg_rc_accounting.RC_QRY1101_GET_DK_INFO(?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("BAS_DK"));
			stmt.setString(i++, iMap.getString("BIT_DK"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			stmt.setString(i++, iMap.getString("SUBE_KODU"));
			stmt.setString(i++, iMap.getString("HAREKET_TURU"));
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("BIT_TARIH").getTime()));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BAS_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BIT_TUTAR"));
			stmt.setString(i++, iMap.getBoolean("F_EVALUASYON") ? "E" : "H");
			stmt.setString(i++, AkustikConstants.APP_TYPE);
			
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);
			
			
			int fileNum = 1;
			File f = new File(ROOT+File.separator+"files"+File.separator + "Hesap Listesi_"+fileNum+".csv");
			WritableWorkbook workbook = Workbook.createWorkbook(f); 
			int sheetNum = 0;
			WritableSheet sheet = workbook.createSheet("Hesap Listesi_"+fileNum+"_"+(sheetNum+1), sheetNum);
			//Baslik satiri.
			int row = 0;
			int col = 0;
			int rowNumInt = 0;
			sheet.addCell(new Label(col++, row, "�ube"));
			sheet.addCell(new Label(col++, row, "DK No"));
			sheet.addCell(new Label(col++, row, "D�viz"));
			sheet.addCell(new Label(col++, row, "Sat�r Banka A��klama"));
			sheet.addCell(new Label(col++, row, "��lem Tarihi"));
			sheet.addCell(new Label(col++, row, "��lem Tutar�"));
			sheet.addCell(new Label(col++, row, "��lem T�r�"));
			sheet.addCell(new Label(col++, row, "Fi� Numara"));
			sheet.addCell(new Label(col++, row, "Fi� A��klama"));
			sheet.addCell(new Label(col++, row, "M��teri A��klama"));
			sheet.addCell(new Label(col++, row, "Giri�ci"));
			sheet.addCell(new Label(col++, row, "Onayc�"));
			row++;
			rowNumInt++;
//******************oMap a de yazdiralim bu arada*******************			
			String tableName = "DK_HAREKET";
			int j= 0;
//***************************************************************			
			while(rSet.next()) {
				col = 0;
				sheet.addCell(new Label(col++, row, rSet.getString("satir_hesap_bolum_kodu") == null ? "" : rSet.getBigDecimal("satir_hesap_bolum_kodu").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("satir_hesap_numara")));
				sheet.addCell(new Label(col++, row, rSet.getString("satir_doviz_kod")));
				sheet.addCell(new Label(col++, row, rSet.getString("satir_banka_aciklama")));
				sheet.addCell(new Label(col++, row, rSet.getString("fis_yaratildigi_banka_tarih") == null ? "" : rSet.getDate("fis_yaratildigi_banka_tarih").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("satir_dv_tutar") == null ? "" : rSet.getBigDecimal("satir_dv_tutar").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("satir_tur")));
				sheet.addCell(new Label(col++, row, rSet.getString("fis_numara") == null ? "" : rSet.getBigDecimal("fis_numara").toString()));
				sheet.addCell(new Label(col++, row, rSet.getString("fis_aciklama")));			
				sheet.addCell(new Label(col++, row, rSet.getString("satir_musteri_aciklama")));
				sheet.addCell(new Label(col++, row, rSet.getString("girisci")));
				sheet.addCell(new Label(col++, row, rSet.getString("onayci")));

				row++;
				rowNumInt++;
				//Sorgu bazen maximum excel satirini geciyor. Bu sebeple satir kontrolu eklenip diger scheet'e gecicek.
				if(row>65000){
					if(sheetNum == 2){
						fileNum++;
						workbook.write();
						workbook.close();
						f = new File(ROOT+File.separator+"files"+File.separator + "Hesap Listesi_"+fileNum+".csv");
						workbook = Workbook.createWorkbook(f);
						sheetNum = 0;
					}else
						sheetNum++;
					row = 0;
					sheet = workbook.createSheet("Hesap Listesi_"+fileNum+"_"+(sheetNum+1), sheetNum);
					//yeni sheet e baslik ekleyelim.
					col = 0;
					sheet.addCell(new Label(col++, row, "�ube"));
					sheet.addCell(new Label(col++, row, "DK No"));
					sheet.addCell(new Label(col++, row, "D�viz"));
					sheet.addCell(new Label(col++, row, "Sat�r Banka A��klama"));
					sheet.addCell(new Label(col++, row, "��lem Tarihi"));
					sheet.addCell(new Label(col++, row, "��lem Tutar�"));
					sheet.addCell(new Label(col++, row, "��lem T�r�"));
					sheet.addCell(new Label(col++, row, "Fi� Numara"));
					sheet.addCell(new Label(col++, row, "Fi� A��klama"));
					sheet.addCell(new Label(col++, row, "M��teri A��klama"));
					sheet.addCell(new Label(col++, row, "Giri��i"));
					sheet.addCell(new Label(col++, row, "Onayc�"));
					row++;
					rowNumInt++;
				}
//******************oMap a de yazdiralim bu arada*******************				
			    DateFormat formatter = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.DEFAULT, Locale.getDefault());

				oMap.put(tableName, j, "SATIR_DV_TUTAR", rSet.getBigDecimal("satir_dv_tutar"));
				oMap.put(tableName, j, "SATIR_TUR", rSet.getString("satir_tur"));
				oMap.put(tableName, j, "FIS_NUMARA", rSet.getBigDecimal("fis_numara"));
				oMap.put(tableName, j, "FIS_ACIKLAMA", rSet.getString("fis_aciklama"));
				oMap.put(tableName, j, "FIS_YARATILDIGI_BANKA_TARIH", rSet.getDate("fis_yaratildigi_banka_tarih"));
				oMap.put(tableName, j, "SATIR_BANKA_ACIKLAMA", rSet.getString("satir_banka_aciklama"));
				oMap.put(tableName, j, "SATIR_DOVIZ_KOD", rSet.getString("satir_doviz_kod"));
				oMap.put(tableName, j, "SATIR_HESAP_BOLUM_KODU", rSet.getBigDecimal("satir_hesap_bolum_kodu"));
				oMap.put(tableName, j, "SATIR_HESAP_NUMARA", rSet.getString("satir_hesap_numara"));
				oMap.put(tableName, j, "SATIR_MUSTERI_ACIKLAMA", rSet.getString("satir_musteri_aciklama"));
				oMap.put(tableName, j, "GIRISCI", rSet.getString("girisci"));
				oMap.put(tableName, j, "ONAYCI", rSet.getString("onayci"));
				oMap.put(tableName, j, "SATIR_TARIH", formatter.format(rSet.getTimestamp("satir_tarih")));
				j++;
//************************************************************************************
			}
			workbook.write();
			workbook.close();
			oMap.put("DOSYA_SAYISI", fileNum);

			BigDecimal rowNum = new BigDecimal(rowNumInt);
			BigDecimal excelEsigi = new BigDecimal(DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_N('EKRANDAN_EXCELE_GECME_ESIGI')}", Types.NUMERIC).toString());

			if(rowNum.compareTo(excelEsigi) == 1 || rowNum.compareTo(new BigDecimal(65000)) == 1){
				oMap.put(tableName, "");
				oMap.put(tableName, 0, "SATIR_HESAP_BOLUM_KODU", "");
			}else{
				oMap.put("MESAJI_DEGISTIR", "Y");
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
	
	@GraymoundService("BNSPR_QRY1101_DELETE_TMP_FILE")
	public static GMMap deleteTmpFile(GMMap iMap){ 
		try {
			for (int i = 1; i <= iMap.getInt("DOSYA_SAYISI"); i++) {
				File f = new File(ROOT+File.separator+"files"+File.separator + "Hesap Listesi_"+i+".csv");
				f.delete();
			}
			return iMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	/*public static GMMap getDkInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = GMServerDatasource.getConnection("java:/GraymoundDS");
			
			StringBuilder query = new StringBuilder();
			
			query.append("select a.satir_hesap_numara, a.satir_doviz_kod,a.satir_hesap_bolum_kodu,");
			query.append("a.fis_yaratildigi_banka_tarih,a.satir_banka_aciklama,");
			query.append("a.satir_dv_tutar, a.satir_tur ,a.fis_numara ");
			//query.append("from v_muh_fis_satir a, v_muh_hp_hesap s ");
			//query.append("where a.satir_hesap_bolum_kodu =  s.sube_kod and a.satir_hesap_numara = s.hesap_no ");
			//query.append("and (s.dk_kod between nvl(? , s.dk_kod) and nvl(? , s.dk_kod)) ");
			//query.append("and a.satir_doviz_kod = nvl(?,a.satir_doviz_kod) ");
			//query.append("and s.sube_kod = nvl(?,s.sube_kod) "); MHA 190608
			query.append("from v_muh_fis_satir a ");   
			query.append("where (a.satir_hesap_numara between nvl(rpad(?,9,'0'),a.satir_hesap_numara) and nvl(rpad(?,9,'0'),a.satir_hesap_numara)) ");
			query.append("and a.satir_doviz_kod = nvl(?,a.satir_doviz_kod) ");
			query.append("and a.satir_hesap_bolum_kodu = nvl(?,a.satir_hesap_bolum_kodu) ");
			query.append("and ( ? = 'T' and a.b_a in ('B','A') OR ? = 'B' and a.b_a = 'B' OR ? = 'A' and a.b_a = 'A') ");
			query.append("and trunc(a.fis_yaratildigi_tarih) between nvl(?,trunc(a.fis_yaratildigi_tarih)) and nvl(?,trunc(a.fis_yaratildigi_tarih)) ");
			query.append("and (a.satir_dv_tutar between nvl(?,a.satir_dv_tutar) and nvl(?,a.satir_dv_tutar)) ");
			query.append("order by a.satir_hesap_bolum_kodu, a.satir_hesap_numara, a.satir_doviz_kod, a.fis_yaratildigi_banka_tarih, a.fis_numara");			
			
			stmt = conn.prepareCall(query.toString());

			if(iMap.getString("BAS_DK").equals("")){
				stmt.setString(1, null);
			}else{
				//stmt.setString(1, iMap.getString("BAS_DK") + "%");
				stmt.setString(1, iMap.getString("BAS_DK"));
			}
			//System.out.println(iMap.getString("BAS_DK") + "%");
			if(iMap.getString("BIT_DK").equals("")){
				stmt.setString(2, null);
			}else{
				//stmt.setString(2, iMap.getString("BIT_DK")+ "%");
				stmt.setString(2, iMap.getString("BIT_DK"));
			}
			
			
			stmt.setString(3, iMap.getString("DOVIZ_KODU"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("SUBE_KODU"));

			if (iMap.getString("HAREKET_TURU").equals("T")) {
				for (int i = 5; i <= 7; i++)
					stmt.setString(i, "T");
			} else {
				for (int i = 5; i <= 7; i++)
					stmt.setString(i, iMap.getString("HAREKET_TURU"));
			}

			if (!(iMap.get("BAS_TARIH") == null)) {
				java.util.Date bas_date = (java.util.Date) iMap
						.get("BAS_TARIH");
				stmt.setDate(8, new java.sql.Date(bas_date.getTime()));
			} else {
				stmt.setDate(8, null);
			}
			if (!(iMap.get("BIT_TARIH") == null)) {
				java.util.Date bit_date = (java.util.Date) iMap
						.get("BIT_TARIH");
				stmt.setDate(9, new java.sql.Date(bit_date.getTime()));
			} else {
				stmt.setDate(9, null);
			}
			
			
			if(iMap.getBigDecimal("BAS_TUTAR").toString().equals("0.00")){
				stmt.setBigDecimal(10, null);
			}else{
				stmt.setBigDecimal(10, iMap.getBigDecimal("BAS_TUTAR"));
			}
			if(iMap.getBigDecimal("BIT_TUTAR").toString().equals("0.00")){
				stmt.setBigDecimal(11, null);
			}else{
				stmt.setBigDecimal(11, iMap.getBigDecimal("BIT_TUTAR"));
			}
			
			rSet = stmt.executeQuery();
			
			String tableName = "DK_HAREKET";
			GMMap oMap = new GMMap();
			int i = 0;
			while (rSet.next()) {
				oMap.put(tableName, i, "SATIR_DV_TUTAR", rSet.getBigDecimal("satir_dv_tutar"));
				oMap.put(tableName, i, "SATIR_DV_TUTAR", rSet.getBigDecimal("satir_dv_tutar"));
				oMap.put(tableName, i, "SATIR_TUR", rSet.getString("satir_tur"));
				oMap.put(tableName, i, "FIS_NUMARA", rSet.getBigDecimal("fis_numara"));
				oMap.put(tableName, i, "FIS_YARATILDIGI_BANKA_TARIH", rSet.getDate("fis_yaratildigi_banka_tarih"));
				oMap.put(tableName, i, "SATIR_BANKA_ACIKLAMA", rSet.getString("satir_banka_aciklama"));
				oMap.put(tableName, i, "SATIR_DOVIZ_KOD", rSet.getString("satir_doviz_kod"));
				oMap.put(tableName, i, "SATIR_HESAP_BOLUM_KODU", rSet.getBigDecimal("satir_hesap_bolum_kodu"));
				oMap.put(tableName, i, "SATIR_HESAP_NUMARA", rSet.getString("satir_hesap_numara"));
				i++;
			}
			return oMap;
		} catch (SQLException e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet);
		}
	}*/
}
