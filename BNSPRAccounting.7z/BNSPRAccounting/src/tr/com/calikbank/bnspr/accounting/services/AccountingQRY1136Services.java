package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.math.BigDecimal;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.aktifbank.bnspr.dao.FacHesapTanim;
import tr.com.aktifbank.bnspr.dao.FacHesapTanimId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;
import com.graymound.service.GMServiceExecuter;

public class AccountingQRY1136Services {
	@GraymoundService("BNSPR_QRY1136_GETRECORDS")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_RC1136.RC1136_SORGULA(?,?,?,?,?)}");

			int i = 1;	
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ALACAKLI_MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ALACAKLI_HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BORCLU_MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("BORCLU_HESAP_NO"));
			
			stmt.registerOutParameter(i++, -10);
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(5);

			String tableName = "TBL_BORCLU";

			oMap.putAll(DALUtil.rSetResults(rSet, tableName));
			
			if (oMap.getSize(tableName) == 0){
				iMap.put("HATA_NO", new BigDecimal(1614));
				return (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}

		
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet);
		}
	}
	
}
