package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.FacHesapTanim;
import tr.com.aktifbank.bnspr.dao.FacHesapTanimId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class AccountingPAR1136Services {
	@GraymoundService("BNSPR_PAR1136_GETRECORDS")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> recordList = (List<?>) session.createCriteria(FacHesapTanim.class)
					.add(Restrictions.eq("id.alacHesapNo", iMap.getBigDecimal("ALACAKLI_HESAP_NO")))
					.list();
			
			String tableName = "TBL_BORCLU";

			for (int row = 0; row < recordList.size(); row++) {
				FacHesapTanim facHesapTanim = (FacHesapTanim) recordList.get(row);
				oMap.put(tableName, row, "BORCLU_HESAP_NO", facHesapTanim.getId().getBorcHesapNo());
				oMap.put(tableName, row, "BORCLU_MUSTERI_NO", LovHelper.diLov(facHesapTanim.getId().getBorcHesapNo()
								, null
								,"1136P/LOV_HESAP","MUSTERI_NO"));
				oMap.put(tableName, row, "BORCLU_MUSTERI_UNVAN", LovHelper.diLov(facHesapTanim.getId().getBorcHesapNo()
								,null
								,"1136P/LOV_HESAP","UNVAN"));

			}

			recordList = (List<?>) session.createCriteria(FacHesapTanim.class)
					.list();

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_PAR1136_SAVE")
	public static GMMap saveParameters(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		String tableName = null;
		int rowCount = 0;
		

		try {

			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");

			ArrayList<?> facHesapTanimList = (ArrayList<?>) session.createCriteria(
					FacHesapTanim.class)
					.add(Restrictions.eq("id.alacHesapNo",iMap.getBigDecimal("ALACAKLI_HESAP_NO"))).list();
			for (Iterator<?> iterator = facHesapTanimList.iterator(); iterator
					.hasNext();) {
				FacHesapTanim facHesapTanim = (FacHesapTanim) iterator.next();
				session.delete(facHesapTanim);
			}
			session.flush();
			
			
			tableName = "TBL_BORCLU";
			rowCount = iMap.getSize(tableName);
			
			if (iMap.getBigDecimal("ALACAKLI_HESAP_NO") == null) {
				oMap.put("MESSAGE_WARN", "L�tfen alacakl� hesap giriniz.");
				return oMap;
			}
			for (int i = 0; i < rowCount; i++) {
				if(iMap.getBigDecimal(tableName, i, "BORCLU_HESAP_NO") == null){
					oMap.put("MESSAGE_WARN", "L�tfen bor�lu hesap giriniz.");
					return oMap;
				}
			}

			for (int i = 0; i < rowCount; i++) {
				FacHesapTanimId id = new FacHesapTanimId();
				FacHesapTanim facHesapTanim = new FacHesapTanim();
				id.setAlacHesapNo(iMap.getBigDecimal("ALACAKLI_HESAP_NO"));
				id.setBorcHesapNo(iMap.getBigDecimal(tableName, i, "BORCLU_HESAP_NO"));
				facHesapTanim.setId(id);					
				session.saveOrUpdate(facHesapTanim);
			}


			oMap.put("MESSAGE", "��leminiz Tamamlanm��t�r.");
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
