package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingQRY1113Services {

	@GraymoundService("BNSPR_QRY1113_GET_TERS_BAKIYE")
	public static GMMap getTersBakiye(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC1113.RC_QRY1113_GET_TERS_BAKIYE(?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_TURU"));
			
			if(iMap.getString("DK_BAS_HES_NO") == null || iMap.getString("DK_BAS_HES_NO").isEmpty())
				stmt.setString(i++, iMap.getString("DK_BIT_HES_NO"));
			else
				stmt.setString(i++, iMap.getString("DK_BAS_HES_NO"));
			
			if(iMap.getString("DK_BIT_HES_NO") == null || iMap.getString("DK_BIT_HES_NO").isEmpty())
				stmt.setString(i++, iMap.getString("DK_BAS_HES_NO"));
			else
				stmt.setString(i++, iMap.getString("DK_BIT_HES_NO"));
			
			stmt.setString(i++, iMap.getString("SUBE_KODU"));
		/*	if (!(iMap.get("TARIH") == null)) {
				Date date = new Date(iMap.getDate("TARIH").getTime());
				String toString = date.toString().substring(0, 4);
					toString += date.toString().substring(5, 7);
					toString += date.toString().substring(8, 10);
					
				
				stmt.setString(i++, toString);
			} else {
				stmt.setString(i++, null);
			}
			*/
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i++, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i++, null);
			
			
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
		//	stmt.setString(i++, null);
			if(iMap.getBigDecimal("BAKIYE") == null ||iMap.getString("BAKIYE").equals("0.00"))
				stmt.setBigDecimal(i++, null);
			else
				stmt.setBigDecimal(i++, iMap.getBigDecimal("BAKIYE"));
			
			if(iMap.getString("BAS_HES_NO") == null || iMap.getString("BAS_HES_NO").isEmpty())
				stmt.setString(i++, iMap.getString("BIT_HES_NO"));
			else
				stmt.setString(i++, iMap.getString("BAS_HES_NO"));
			
			if(iMap.getString("BIT_HES_NO") == null || iMap.getString("BIT_HES_NO").isEmpty())
				stmt.setString(i++, iMap.getString("BAS_HES_NO"));
			else
				stmt.setString(i++, iMap.getString("BIT_HES_NO"));
			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet,"CBS_TERS_BAKIYE");
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY1113_GM_SUBE_KULLANICISI_MI")
	public static GMMap gmKullanicisimi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			GMMap oMap = new GMMap();
			stmt = conn.prepareCall("{? = call PKG_PERSONEL.GM_Kullanicisimi(?)}");
			stmt.registerOutParameter(1,Types.VARCHAR);
			stmt.setString(2, iMap.getString("KULLANICI_KOD"));
			stmt.execute();

			oMap.put("GM_KULLANICISI_MI", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}
}


