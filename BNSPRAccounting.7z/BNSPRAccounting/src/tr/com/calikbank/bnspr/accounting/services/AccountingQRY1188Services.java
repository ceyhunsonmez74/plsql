package tr.com.calikbank.bnspr.accounting.services;


import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingQRY1188Services {
	@GraymoundService("BNSPR_QRY1188_SORGULA")
	public static GMMap sorgula(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_RC1188.QRY1188_sorgula(?,?,?,?,?,?,?,?,?)}");

			int i = 1;	

			stmt.registerOutParameter(i++, -10);

			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("SUBE_NO") == null ? "" : iMap.getString("SUBE_NO"));
			stmt.setString(i++, iMap.getString("GIDER_TIPI") == null ? "" : iMap.getString("GIDER_TIPI"));
			stmt.setString(i++, iMap.getString("DK_HESAP_NO") == null ? "" : iMap.getString("DK_HESAP_NO"));
			stmt.setString(i++, iMap.getString("KAR_BOLUM_KODU") == null ? "" : iMap.getString("KAR_BOLUM_KODU"));
			stmt.setString(i++, iMap.getString("GIDER_BOLUM_KODU") == null ? "" : iMap.getString("GIDER_BOLUM_KODU"));
			stmt.setDate  (i++, iMap.getDate("ILK_TARIH") == null ? new java.sql.Date(0) : new java.sql.Date (iMap.getDate("ILK_TARIH").getTime()));
			stmt.setDate  (i++, iMap.getDate("SON_TARIH") == null ? new java.sql.Date(0) : new java.sql.Date (iMap.getDate("SON_TARIH").getTime()));
            stmt.setString(i++, iMap.getString("DOVIZ_KODU"));

			stmt.execute();

			rSet = (ResultSet)stmt.getObject(1);

			String tableName = "TABLE";

			GMMap oMap = new GMMap();

			int j = 0;
			while (rSet.next()) {
				oMap.put(tableName, j, "GIDER_SUBE", rSet.getString("GIDER_SUBE"));
				oMap.put(tableName, j, "GIDER_MUSTERI_NO", rSet.getBigDecimal("GIDER_MUSTERI_NO"));
				oMap.put(tableName, j, "GIDER_HESAP_NO", rSet.getString("GIDER_HESAP_NO"));
				oMap.put(tableName, j, "GIDER_TIPI", rSet.getString("GIDER_TIPI"));
				oMap.put(tableName, j, "BORCLU_DK_HESAP_NO", rSet.getString("BORCLU_DK_HESAP_NO"));
				oMap.put(tableName, j, "TUTAR", rSet.getBigDecimal("TUTAR"));
				oMap.put(tableName, j, "DOVIZ_KODU", rSet.getString("DOVIZ_KODU"));
				oMap.put(tableName, j, "ISLEM_ACIKLAMA", rSet.getString("ISLEM_ACIKLAMA"));
				oMap.put(tableName, j, "KAR_MERKEZI", rSet.getString("KAR_MERKEZI"));
				oMap.put(tableName, j, "GIDER_BOLUM", rSet.getString("GIDER_BOLUM"));
				oMap.put(tableName, j, "ISLEM_TARIH", new java.util.Date(rSet.getDate("ISLEM_TARIH").getTime()));
                oMap.put(tableName, j, "MODUL_TUR_KOD", rSet.getString("MODUL_TUR_KOD"));
                oMap.put(tableName, j, "URUN_TUR_KOD", rSet.getString("URUN_TUR_KOD"));
                oMap.put(tableName, j, "URUN_SINIF_KOD", rSet.getString("URUN_SINIF_KOD"));
                oMap.put(tableName, j, "FIS_NO", rSet.getBigDecimal("FIS_NO"));
                oMap.put(tableName, j, "GIDER_SUBE_AD", rSet.getString("GIDER_SUBE_AD"));
                oMap.put(tableName, j, "GIDER_BOLUM_KODU", rSet.getString("GIDER_BOLUM_KODU"));
				j++;
			}

			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
}