package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
//import java.sql.Types;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;



import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class AccountingQRY1107Services {

	@GraymoundService("BNSPR_QRY1107_GET_MUH_FIS_SATIR")
	public static GMMap getMuhFisRecord(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet1 = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_rc_accounting.RC_QRY1107_GET_MUH_FIS_SATIR(?,?,?,?)}");
			int i = 1;	
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("SUBE_KODU"));
			stmt.setString(i++, iMap.getString("KULLANICI_KOD"));
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			stmt.setDate(i++, new java.sql.Date(iMap.getDate("SON_TARIH").getTime()));

			stmt.execute();

			rSet1 = (ResultSet)stmt.getObject(1);

			String tableName = "FIS_SATIR";
			BigDecimal alacakToplam = new BigDecimal(0);
			BigDecimal borcToplam = new BigDecimal(0);

			GMMap oMap = new GMMap();
			int j = 0;
			while (rSet1.next()) {
				if(iMap.getBoolean("SADECE_BALANSSIZ") && (rSet1.getBigDecimal("BORC").add(rSet1.getBigDecimal("ALAC")).compareTo(new BigDecimal(0))==0))
					continue; 
				oMap.put(tableName, j, "T_AMIR_SUBE_KODU", rSet1.getString("amir_sube_kod"));
				oMap.put(tableName, j, "T_MUHASEBELESTIGI_TARIH", rSet1.getDate("fis_muhasebelestigi_tarih"));
				oMap.put(tableName, j, "T_ISLEM_NUMARA", rSet1.getBigDecimal("fis_islem_numara"));
				oMap.put(tableName, j, "T_FIS_NUMARA", rSet1.getBigDecimal("fis_numara"));
				oMap.put(tableName, j, "T_KULLANICI_ADI", rSet1.getString("kullanici_adi"));
				borcToplam = borcToplam.add(rSet1.getBigDecimal("BORC"));
				oMap.put(tableName, j, "T_BORC", rSet1.getBigDecimal("BORC"));
				alacakToplam = alacakToplam.add(rSet1.getBigDecimal("ALAC"));
				oMap.put(tableName, j, "T_ALACAK", rSet1.getBigDecimal("ALAC"));
				oMap.put(tableName, j, "T_BALANS", rSet1.getBigDecimal("ALAC").add(rSet1.getBigDecimal("BORC")));	
				oMap.put(tableName, j, "EKRAN_NO", rSet1.getBigDecimal("fis_islem_kod"));
				oMap.put(tableName, j,"ISLEM_ADI", rSet1.getString("ISLEM_ADI"));
				oMap.put(tableName, j,"ISLEM_SUBE_ADI", rSet1.getString("ISLEM_SUBE_ADI"));
				oMap.put(tableName, j,"DOVIZ_TURU", rSet1.getString("DOVIZ_TURU"));
				oMap.put(tableName, j,"ONAYLAYAN_KULLANICI", rSet1.getString("ONAYLAYAN_KULLANICI"));
				oMap.put(tableName, j,"IPTAL_KULLANICI_ADI", rSet1.getString("IPTAL_KULLANICI_KODU"));
				oMap.put(tableName, j,"IPTAL_ONAY_KULL_ADI", rSet1.getString("IPTAL_ONAY_KULL_KODU"));
				oMap.put(tableName, j,"DURUM", rSet1.getString("DURUM"));
				oMap.put(tableName, j,"KAYIT_KULLANICI_KODU", rSet1.getString("KAYIT_KULLANICI_KODU"));
				oMap.put(tableName, j,"ONAY_KULL_KODU", rSet1.getString("ONAY_KULL_KODU"));
				oMap.put(tableName, j,"T_ISLEM_TUTARI", rSet1.getString("islem_tutari"));
				j++;
			}

			oMap.put("ALACAK_TOPLAM", alacakToplam);
			oMap.put("BORC_TOPLAM", borcToplam);
			oMap.put("BALANS", alacakToplam.subtract(borcToplam));
		
			
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
}


