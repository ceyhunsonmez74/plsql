package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingRAP1121Services {
	
	@GraymoundService("BNSPR_RAP1121_KAYIT_OLUSTUR")
	public static GMMap kayitYarat(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_resmi_defter.Resmi_Defter_Kayitlari_Olustur(?,?,?,?,?,?)}");
			stmt.setString(1, iMap.getString("SUBE_KODU"));
			Date baslangicTarihi =  iMap.getDate("BAS_TARIH");
			Date bitisTarihi =  iMap.getDate("BIT_TARIH");
			if (baslangicTarihi != null)
				stmt.setDate(2, new java.sql.Date(baslangicTarihi.getTime()));
			else
				stmt.setDate(2, null);

			if (bitisTarihi != null)
				stmt.setDate(3, new java.sql.Date(bitisTarihi.getTime()));
			else
				stmt.setDate(3, null);
			stmt.setBigDecimal(4, iMap.getBigDecimal("BAS_HESAP"));
			stmt.setBigDecimal(5, iMap.getBigDecimal("BIT_HESAP"));
			stmt.setString(6, iMap.getString("RAPOR_TIPI"));

			stmt.execute();
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} catch (ParseException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_RAP1121_DEVIR_OLUSTUR")
	public static GMMap devirYarat(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_resmi_defter.Resmi_Defter_Devir_Olustur(?,?,?)}");
			stmt.setString(1, iMap.getString("SUBE_KODU"));
			Date baslangicTarihi =  iMap.getDate("BAS_TARIHI");
			Date bitisTarihi =  iMap.getDate("BIT_TARIHI");
			if (baslangicTarihi != null)
				stmt.setDate(2, new java.sql.Date(baslangicTarihi.getTime()));
			else
				stmt.setDate(2, null);

			if (bitisTarihi != null)
				stmt.setDate(3, new java.sql.Date(bitisTarihi.getTime()));
			else
				stmt.setDate(3, null);
			/*stmt.setBigDecimal(4, iMap.getBigDecimal("BAS_HESAP"));
			stmt.setBigDecimal(5, iMap.getBigDecimal("BIT_HESAP"));
			stmt.setString(6, iMap.getString("RAPOR_TIPI"));*/

			stmt.execute();
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} catch (ParseException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_RAP1121_SON_YEVMIYE_TARIHI")
	public static GMMap getSonYevmiyeTarihi(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call pkg_resmi_defter.Max_Devir_Tarih (?,?) }");
			int i = 1;
			stmt.registerOutParameter(i++, Types.DATE);	
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SUBE_KODU"));
			if ( iMap.getDate("BAS_TARIH") != null) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			
			stmt.execute();
			
			oMap.put("SON_YEVMIYE_TARIHI",stmt.getDate(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_RAP1121_SON_YEVMIYE_MADDE")
	public static GMMap getSonYevmiyeMadde(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call pkg_resmi_defter.Max_Yevmiye_No (?,?) }");
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);	
			stmt.setBigDecimal(i++, iMap.getBigDecimal("SUBE_KODU"));
			if ( iMap.getDate("BAS_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			else
				stmt.setDate(i++, null);

			stmt.execute();
			
			oMap.put("SON_YEVMIYE_MADDE",stmt.getBigDecimal(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_RAP1121_AYBASI")
	public static GMMap checkTaksitTarihi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			Calendar cal = Calendar.getInstance();
			cal.setTime(new java.util.Date());
			cal.set(Calendar.DATE, 1); //set the date to start of month
			cal.add(Calendar.MONTH,1);
			cal.add(Calendar.DATE,-1);
			GMMap oMap = new GMMap();
			oMap.put("BIT_TARIH", cal.getTime());
			
			Calendar cal2 = Calendar.getInstance();
			cal2.setTime(new java.util.Date());
			cal2.set(Calendar.DATE, 1); //set the date to start of month
			cal2.add(Calendar.MONTH,0);
			oMap.put("BAS_TARIH", cal2.getTime());
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
