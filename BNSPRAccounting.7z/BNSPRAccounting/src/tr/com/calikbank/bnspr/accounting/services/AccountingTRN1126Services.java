package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import tr.com.aktifbank.bnspr.dao.MuhGeciciHesapTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class AccountingTRN1126Services {
    
    
    @GraymoundService("BNSPR_TRN1126_FILL_COMBOBOX_INITIAL_VALUE")
    public static GMMap fillComboBox(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
        	
            iMap.put("ADD_EMPTY_KEY", "H");
            iMap.put("KOD", "MUSTERI_DK_HESAP");
            oMap.put(   "MUSTERI_DK_HESAP_ALACAK",
                    GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
                            iMap).get("RESULTS"));
            
            iMap.put("ADD_EMPTY_KEY", "H");
            iMap.put("KOD", "MUSTERI_DK_HESAP");
            iMap.put("KEY2", "A");
            oMap.put("MUSTERI_DK_HESAP_BORC",
                    GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS",
                            iMap).get("RESULTS"));
 
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
	
   @GraymoundService("BNSPR_TRN1126_SAVE")
    public static Map<?, ?>  saveParameters(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        
        try {
            conn = DALUtil.getGMConnection();
            Session session = DAOSession.getSession("BNSPRDal");

            
            MuhGeciciHesapTx  muhGeciciHesapTx = (MuhGeciciHesapTx)session.get(MuhGeciciHesapTx.class, iMap.getBigDecimal("TRX_NO"));
            
            if(muhGeciciHesapTx == null) {
                muhGeciciHesapTx = new MuhGeciciHesapTx();
            }
            
           
      
                muhGeciciHesapTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
                muhGeciciHesapTx.setReferansNo(iMap.getString("REFERANS"));
                muhGeciciHesapTx.setBorcMusteriDk(iMap.getString("BORC_MUSTERI_DK"));
                muhGeciciHesapTx.setBorcMusteriNo(iMap.getBigDecimal("BORC_MUSTERI_NO"));
                muhGeciciHesapTx.setBorcHesapNo(iMap.getString("BORC_HESAP_NO"));
                muhGeciciHesapTx.setAlacakMusteriDk(iMap.getString("ALACAK_MUSTERI_DK"));
                muhGeciciHesapTx.setAlacakMusteriNo(iMap.getBigDecimal("ALACAK_MUSTERI_NO"));
                muhGeciciHesapTx.setAlacakHesapNo(iMap.getString("ALACAK_HESAP_NO"));
                muhGeciciHesapTx.setTutar(iMap.getBigDecimal("TUTAR"));
                muhGeciciHesapTx.setKur(iMap.getBigDecimal("KUR"));
                muhGeciciHesapTx.setAciklama(iMap.getString("ACIKLAMA"));
                muhGeciciHesapTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
                muhGeciciHesapTx.setDurum("A");
                
                
                session.saveOrUpdate(muhGeciciHesapTx);
            
            session.flush();
            
            iMap.put("TRX_NAME","1126");
            return  GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);  
            
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
   
   @GraymoundService("BNSPR_TRN1126_GET_INFO")
   public static Map<?, ?> trn1126GetInfo(GMMap iMap) {
       GMMap oMap = new GMMap();
       
       try {
           Session session = DAOSession.getSession("BNSPRDal");
           MuhGeciciHesapTx muhGeciciHesapTx = (MuhGeciciHesapTx)session.createCriteria(MuhGeciciHesapTx.class)
                                                   .add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
                                                   .uniqueResult();
           if(muhGeciciHesapTx == null) {
               muhGeciciHesapTx = new MuhGeciciHesapTx();
           }
           java.math.BigDecimal kur =  muhGeciciHesapTx.getKur();
           java.math.BigDecimal netTutar = muhGeciciHesapTx.getTutar();
           
           oMap.put("TRX_NO" , muhGeciciHesapTx.getTxNo());  
           oMap.put("REFERANS" , muhGeciciHesapTx.getReferansNo());  
           oMap.put("BORC_MUSTERI_DK"     , muhGeciciHesapTx.getBorcMusteriDk());
           oMap.put("BORC_MUSTERI_NO"     , muhGeciciHesapTx.getBorcMusteriNo());
           oMap.put("BORC_HESAP_NO"       , muhGeciciHesapTx.getBorcHesapNo());
           oMap.put("ALACAK_MUSTERI_DK"   , muhGeciciHesapTx.getAlacakMusteriDk());
           oMap.put("ALACAK_MUSTERI_NO"   , muhGeciciHesapTx.getAlacakMusteriNo());
           oMap.put("ALACAK_HESAP_NO"     , muhGeciciHesapTx.getAlacakHesapNo());
           oMap.put("TUTAR"               , netTutar);
           oMap.put("KUR"                 , kur);
           oMap.put("ACIKLAMA"            , muhGeciciHesapTx.getAciklama());
           oMap.put("DOVIZ_KODU"          ,muhGeciciHesapTx.getDovizKodu());
           oMap.put("TL_TUTAR"            ,kur.multiply(netTutar));
      
          
           
   return oMap; 
   
   } catch (Exception e) {
       throw ExceptionHandler.convertException(e);
   }
   
}  

   
   @GraymoundService("BNSPR_TRN1126_GET_TL_TUTAR")
   public static GMMap getTLTutar(GMMap iMap) {
       Connection conn = null;
       CallableStatement stmt = null;
       GMMap oMap = new GMMap();

       try {
           conn = DALUtil.getGMConnection();
           stmt = conn.prepareCall("{? = call PKG_KUR.MB_DSK_to_LC (?,?)}");
           stmt.registerOutParameter(1, Types.NUMERIC);
           
           stmt.setString(2,  iMap.getString("DOVIZ_KODU"));
           stmt.setBigDecimal(3,iMap.getBigDecimal("TUTAR"));
           stmt.execute();
    
           oMap.put("TL_TUTAR", stmt.getBigDecimal(1));
       } catch (SQLException e) {
           throw ExceptionHandler.convertException(e);
       } finally {
           GMServerDatasource.close(stmt);
           GMServerDatasource.close(conn);
       }
       return oMap;
   }
   
   @GraymoundService("BNSPR_TRN1126_GET_KUR")
   public static GMMap getKur(GMMap iMap) {
       Connection conn = null;
       CallableStatement stmt = null;
       GMMap oMap = new GMMap();

       try {
           conn = DALUtil.getGMConnection();
           stmt = conn.prepareCall("{? = call PKG_TRN1126.GET_KUR(?)}");
           stmt.registerOutParameter(1, Types.NUMERIC);
           
           stmt.setString(2,  iMap.getString("DOVIZ_KODU"));
           stmt.execute();
           Object obj = stmt.getObject(1);
		   oMap.put("KUR", obj.toString());
    
           //oMap.put("KUR", stmt.getBigDecimal(1));
       } catch (SQLException e) {
           throw ExceptionHandler.convertException(e);
       } finally {
           GMServerDatasource.close(stmt);
           GMServerDatasource.close(conn);
       }
       return oMap;
   }
}
