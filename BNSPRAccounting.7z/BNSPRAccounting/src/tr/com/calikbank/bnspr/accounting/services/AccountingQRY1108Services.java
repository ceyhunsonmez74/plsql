package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingQRY1108Services {
	@GraymoundService("BNSPR_QRY1108_GET_HESAP_PLAN_LIST")
	public static GMMap getHesapPlanList(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet1 = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_rc_accounting.RC_QRY1108_GET_HESAP_PLAN_LIST(?,?,?,?,?)}");

			int i = 1;	

			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("SUBE_KONSOLIDE"));
			stmt.setString(i++, iMap.getString("SUBE_KODU"));
			stmt.setString(i++, iMap.getString("TUR"));
			stmt.setString(i++, iMap.getString("BAS_DK"));
			stmt.setString(i++, iMap.getString("BIT_DK"));

			stmt.execute();

			rSet1 = (ResultSet)stmt.getObject(1);

			GMMap oMap = new GMMap();

			BigDecimal lcToplam = new BigDecimal(0);
			BigDecimal fcToplam = new BigDecimal(0);
			String tableName1 = "HESAP_PLAN";

			for (int row = 0; rSet1.next(); row++ ) {
				if (iMap.getString("SUBE_KONSOLIDE").equals("S")) {
					oMap.put(tableName1, row, "SUBE_KODU", rSet1.getString("sube_kod"));
				}else{
					oMap.put(tableName1, row, "SUBE_KODU", "KON");
				}
				oMap.put(tableName1, row, "HESAP_NO", rSet1.getString("hesap_no"));
				oMap.put(tableName1, row, "DOVIZ_KOD", rSet1.getString("doviz_kod"));
				oMap.put(tableName1, row, "DK_KISA_ISIM", rSet1.getString("dk_kisa_isim"));
				oMap.put(tableName1, row, "MUSTERILI_HESAP_MI", rSet1.getString("musterili_hesap_mi"));
				oMap.put(tableName1, row, "BA_KOD", rSet1.getString("ba_kod"));
				oMap.put(tableName1, row, "LC_BAKIYE", rSet1.getBigDecimal("lc_bakiye"));
				oMap.put(tableName1, row, "FC_BAKIYE", rSet1.getBigDecimal("fc_bakiye"));
				try {
					if(!rSet1.getString("doviz_kod").equals("XXX"))
						lcToplam = lcToplam.add(rSet1.getBigDecimal("lc_bakiye"));
				} catch (Exception e) {
				}
				try {
					if(!rSet1.getString("doviz_kod").equals("XXX"))
						fcToplam = fcToplam.add(rSet1.getBigDecimal("fc_bakiye"));
				} catch (Exception e) {
				}
			}

			oMap.put("LC_TOPLAM", lcToplam);
			oMap.put("FC_TOPLAM", fcToplam);

			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet1);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY1108_GM_SUBE_KULLANICISI_MI")
	public static GMMap gmKullanicisimi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			GMMap oMap = new GMMap();
			stmt = conn.prepareCall("{? = call PKG_PERSONEL.GM_Kullanicisimi(?)}");
			stmt.registerOutParameter(1,Types.VARCHAR);
			stmt.setString(2, iMap.getString("KULLANICI_KOD"));
			stmt.execute();

			oMap.put("GM_KULLANICISI_MI", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}

	
}
