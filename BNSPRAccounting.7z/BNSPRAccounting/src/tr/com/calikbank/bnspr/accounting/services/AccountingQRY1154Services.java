package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingQRY1154Services {


	@GraymoundService("BNSPR_QRY1154_GET_DETAY")
	public static GMMap getDetay(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc1154.RC_QRY1154_GET_DETAY(?,?,?,?,?,?,?,?)}");	
			int i = 1;	
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("REFERANS"));
			if (!(iMap.get("BAS_TARIH") == null)) {
				stmt.setDate(i++, new Date(iMap.getDate("BAS_TARIH").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			
		     if (!(iMap.get("BIT_TARIH") == null)) {
	                stmt.setDate(i++, new Date(iMap.getDate("BIT_TARIH").getTime()));
	            } else {
	                stmt.setDate(i++, null);
	            }
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setString(i++, iMap.getString("DEVIR_TIPI"));
		 
			stmt.setString(i++, iMap.getString("MODUL_TUR_KOD"));
			stmt.setString(i++, iMap.getString("URUN_TUR_KOD"));
			stmt.setString(i++, iMap.getString("URUN_SINIF_KOD"));
			
			stmt.execute();
			String tableName = "MUSTAKRIZ_TABLO";
			rSet = (ResultSet)stmt.getObject(1);
			oMap.putAll(DALUtil.rSetResults(rSet , tableName));
			

			return oMap;
		} catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
	  
    @GraymoundService("BNSPR_QRY1154_GET_ISLEM_LIST")
    public static GMMap getListAlt(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
        	conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call PKG_RC1154.RC_QRY1154_GET_ISLEM(?) }");

            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setString(i++, iMap.getString("REFERANS"));
            
            
            stmt.execute();
            String tableName = "ISLEM_DETAY";
            
            rSet = (ResultSet) stmt.getObject(1);
            GMMap oMap = new GMMap();
        
            int j=0;
            while (rSet.next()) {
                oMap.put(tableName, j, "ISLEM_TARIHI", rSet.getDate("ISLEM_TARIHI"));
                oMap.put(tableName, j, "ISLEM_NO", rSet.getBigDecimal("ISLEM_NO"));
                oMap.put(tableName, j, "TUTAR", rSet.getBigDecimal("TUTAR"));
                oMap.put(tableName, j, "DURUM", rSet.getString("DURUM"));
                oMap.put(tableName, j, "DURUM_KOD", rSet.getString("DURUM_KOD"));
                 
                j++;
            }
            GMServerDatasource.close(rSet);
            
        
            

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
}				 
