package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MuhDkGiderTanimParamTx;
import tr.com.aktifbank.bnspr.dao.MuhDkGiderTanimParamTxId;
import tr.com.aktifbank.bnspr.dao.MuhDkGiderTanimPrmRol;
import tr.com.aktifbank.bnspr.dao.MuhDkGiderTanimPrmRolTx;
import tr.com.aktifbank.bnspr.dao.MuhDkGiderTanimPrmRolTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;









import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1193Services {
    
    @GraymoundService("BNSPR_TRN1193_GET_LIST")
    public static GMMap getList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        Session session = DAOSession.getSession("BNSPRDal");
        try{
        	conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN1193.TRN1193_sorgula}");
            int i = 1;
            stmt.registerOutParameter(i++ , -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            GMMap oMap = new GMMap();
            oMap.putAll(DALUtil.rSetResults(rSet , "LIST"));
            while (i < oMap.getSize("LIST")){
            ArrayList<HashMap<String, Object>> rolesOutList = new ArrayList<HashMap<String, Object>>();
    		ArrayList<?> roles = (ArrayList<?>) session.createCriteria(MuhDkGiderTanimPrmRol.class).add(Restrictions.eq("id.dkHesapNo", oMap.getString("LIST",i,"DK_HESAP_NO"))).list();
    		for (Iterator<?> iterator = roles.iterator(); iterator.hasNext();) {
    			MuhDkGiderTanimPrmRol giderTanimRol = (MuhDkGiderTanimPrmRol) iterator.next();
    			HashMap<String, Object> rowData = new HashMap<String, Object>();
    			rowData.put("DK_HESAP_NO", giderTanimRol.getId().getDkHesapNo());
    			rowData.put("ROL", giderTanimRol.getId().getRol().toString());
    			rowData.put("TANIM", giderTanimRol.getRolAciklama());
    			rolesOutList.add(rowData);
    		}
    		GMContext.getCurrentContext().getSession().put(oMap.getString("LIST",i,"DK_HESAP_NO"), rolesOutList);
    		i++;
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    @GraymoundService("BNSPR_TRN1193_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        Session session = DAOSession.getSession("BNSPRDal");
        try{
        	GMMap oMap = new GMMap();
        	Object[] inputValues = new Object[2];
        	inputValues[0] = BnsprType.NUMBER;
        	inputValues[1] = iMap.getBigDecimal("TRX_NO");
        	String func = "{? = call PKG_TRN1193.TRN1193_GETINFO(?)}";
        	oMap = DALUtil.callOracleRefCursorFunction(func, "LIST", inputValues);
        	int i = 0;
        	while (i < oMap.getSize("LIST")){
            ArrayList<HashMap<String, Object>> rolesOutList = new ArrayList<HashMap<String, Object>>();
    		ArrayList<?> roles = (ArrayList<?>) session.createCriteria(MuhDkGiderTanimPrmRolTx.class).add(Restrictions.eq("id.dkHesapNo", oMap.getString("LIST",i,"DK_HESAP_NO"))).add(Restrictions.eq("id.txNo",iMap.getBigDecimal("TRX_NO"))).list();
    		for (Iterator<?> iterator = roles.iterator(); iterator.hasNext();) {
    			MuhDkGiderTanimPrmRolTx giderTanimRol = (MuhDkGiderTanimPrmRolTx) iterator.next();
    			HashMap<String, Object> rowData = new HashMap<String, Object>();
    			rowData.put("DK_HESAP_NO", giderTanimRol.getId().getDkHesapNo());
    			rowData.put("ROL", giderTanimRol.getId().getRol().toString());
    			rowData.put("TANIM", giderTanimRol.getRolAciklama());
    			rolesOutList.add(rowData);
    		}
    		GMContext.getCurrentContext().getSession().put(oMap.getString("LIST",i,"DK_HESAP_NO"), rolesOutList);
    		i++;
            }
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    @SuppressWarnings("unchecked")
    @GraymoundService("BNSPR_TRN1193_SAVE")
    public static GMMap saveList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        int i = 0;
        String table = "TABLE";
        Session session = DAOSession.getSession("BNSPRDal");
        try{
            List<MuhDkGiderTanimParamTx> list = (List<MuhDkGiderTanimParamTx>) session.createCriteria(MuhDkGiderTanimParamTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            for (MuhDkGiderTanimParamTx rec : list){
                session.delete(rec);
            }
            session.flush();
            
            try{
                while (i < iMap.getSize(table)){
                    MuhDkGiderTanimParamTx muhDkGiderTanimParamTx = new MuhDkGiderTanimParamTx();
                    MuhDkGiderTanimParamTxId muhDkGiderTanimParamTxId = new MuhDkGiderTanimParamTxId();
                    muhDkGiderTanimParamTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    muhDkGiderTanimParamTxId.setDkHesapNo(iMap.getString(table, i, "DK_HESAP_NO"));
                    
                    muhDkGiderTanimParamTx.setId(muhDkGiderTanimParamTxId);
                    session.save(muhDkGiderTanimParamTx);
                    
                    ArrayList<?> roller = (ArrayList<?>)  GMContext.getCurrentContext().getSession().get(iMap.getString(table, i, "DK_HESAP_NO"));
                    Object o = GMContext.getCurrentContext().getSession().get(iMap.getString(table, i, "DK_HESAP_NO"));
                    if(o!=null){
                    	boolean flag = true;
    					for (Iterator<?> iterator2 = roller.iterator(); iterator2.hasNext();) {
    						HashMap<?, ?> rowData2 = (HashMap<?, ?>) iterator2.next();
    					MuhDkGiderTanimPrmRolTx giderTanimPrmRolTx = new MuhDkGiderTanimPrmRolTx();
    					MuhDkGiderTanimPrmRolTxId giderTanimPrmRolTxId = new MuhDkGiderTanimPrmRolTxId();
    					giderTanimPrmRolTxId.setDkHesapNo((String) rowData2.get("DK_HESAP_NO"));
    					giderTanimPrmRolTxId.setRol(BigDecimal.valueOf(Long.valueOf((String) rowData2.get("ROL"))));
    					giderTanimPrmRolTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
    					giderTanimPrmRolTx.setId(giderTanimPrmRolTxId);
    					giderTanimPrmRolTx.setRolAciklama((String) rowData2.get("TANIM"));
    					session.saveOrUpdate(giderTanimPrmRolTx);
    					
    					if(flag){
							GMContext.getCurrentContext().getSession().remove((String)rowData2.get("DK_KOD"));
							flag=false;
						}
    					}
                    }
                    
                    i++;
                }
                session.flush();
                
                iMap.put("TRX_NAME" , "1193");
                GMMap oMap = new GMMap();
                oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap));
                return oMap;
            } catch (Exception e){
                throw ExceptionHandler.convertException(e);
            } finally{
                GMServerDatasource.close(rSet);
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
            }
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    @GraymoundService("BNSPR_TRN1193_PUT_ROLES_TO_CONTEXT")
    public static Map<?, ?> putRolesToContext(GMMap iMap) {
    		GMContext.getCurrentContext().getSession().put(iMap.getString("DK_KOD"), iMap.get("ROLES"));
    		return new GMMap();
    	
    }
    @GraymoundService("BNSPR_TRN1193_GET_ROLES")
    public static Map<?, ?>  getRoles(GMMap iMap){
    	Session session = DAOSession.getSession("BNSPRDal");
    	
    	HashMap<String, Object> oMap = new HashMap<String, Object>();
    	Object o = GMContext.getCurrentContext().getSession().get(iMap.getString("DK_KOD"));
    	ArrayList<?> arr = (ArrayList<?>)GMContext.getCurrentContext().getSession().get(iMap.getString("DK_KOD"));
    	
        
    
    	try {
    		
    		oMap.put("ROLES", GMContext.getCurrentContext().getSession().get(iMap.getString("DK_KOD")));
		}
		catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
    	
    	
    	return oMap;
    }
}