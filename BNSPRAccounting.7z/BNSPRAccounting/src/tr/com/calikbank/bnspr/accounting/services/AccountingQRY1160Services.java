package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingQRY1160Services {
	@GraymoundService("BNSPR_QRY1160_GET_MASKOM_MUAF_LIST")
	public static GMMap getMaskomMuafList(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;   
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_masraf_yeni.Maskom_Muaf_Liste(?,?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("TIP"));
			stmt.setString(i++, iMap.getString("SUBE_KOD"));
			stmt.execute();

			stmt.getMoreResults();
			rSet = (ResultSet)stmt.getObject(1);

			GMMap oMap = new GMMap();
			String tableName = "MASKOM_MUAF";
			int row = 0;
			while (rSet.next()){
				int j = 1;
				oMap.put(tableName, row,"KOD",rSet.getString(j++));
				oMap.put(tableName, row,"ACIKLAMA",rSet.getString(j++));
				oMap.put(tableName, row,"KANAL_KOD",rSet.getString(j++));
				oMap.put(tableName, row,"KANAL_ACK",rSet.getString(j++));
				oMap.put(tableName, row,"START_DATE",rSet.getDate(j++));
				oMap.put(tableName, row,"END_DATE",rSet.getDate(j++));
				oMap.put(tableName, row,"DURUMU",rSet.getString(j++));

				row++;
			}

			return oMap;
		}catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY1160_GET_MASKOM_TANIM_LIST")
	public static GMMap getMaskomTanimList(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_masraf_yeni.Maskom_Tanim_Liste(?,?)}");

			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("TIP"));
			stmt.setString(i++, iMap.getString("SUBE_KOD"));
			
			stmt.execute();

			stmt.getMoreResults();
			rSet = (ResultSet)stmt.getObject(1);

			GMMap oMap = new GMMap();
			String tableName = "MASKOM_TANIM";
			int row = 0;
			while (rSet.next()){
				int j = 1;
				oMap.put(tableName, row,"KOD",rSet.getString(j++));
				oMap.put(tableName, row,"ACIKLAMA",rSet.getString(j++));
				oMap.put(tableName, row,"KANAL_KOD",rSet.getString(j++));
				oMap.put(tableName, row,"KANAL_ACK",rSet.getString(j++));
				oMap.put(tableName, row,"ISLEM_KOD",rSet.getString(j++));
				oMap.put(tableName, row,"ISLEM_ACK",rSet.getString(j++));
				oMap.put(tableName, row,"MASKOM_KOD",rSet.getString(j++));
				oMap.put(tableName, row,"MASKOM_ACK",rSet.getString(j++));
				oMap.put(tableName, row,"MASKOM_TUTAR",rSet.getBigDecimal(j++));
				oMap.put(tableName, row,"MASKOM_ORAN",rSet.getBigDecimal(j++));
				oMap.put(tableName, row,"MASKOM_KATSAYI",rSet.getBigDecimal(j++));
				oMap.put(tableName, row,"START_DATE",rSet.getDate(j++));
				oMap.put(tableName, row,"END_DATE",rSet.getDate(j++));
				oMap.put(tableName, row,"DURUMU",rSet.getString(j++));

				row++;
			}

			return oMap;
		}catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY1160_GM_SUBE_KULLANICISI_MI")
	public static GMMap gmKullanicisimi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			GMMap oMap = new GMMap();
			stmt = conn.prepareCall("{? = call PKG_PERSONEL.GM_Kullanicisimi(?)}");
			stmt.registerOutParameter(1,Types.VARCHAR);
			stmt.setString(2, iMap.getString("KULLANICI_KOD"));
			stmt.execute();

			oMap.put("GM_KULLANICISI_MI", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}
}
