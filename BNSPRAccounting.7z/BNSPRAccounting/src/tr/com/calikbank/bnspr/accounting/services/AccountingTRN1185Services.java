package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlBolumKodPr;
import tr.com.aktifbank.bnspr.dao.MuhSatinalmaTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhSbaFisTx;
import tr.com.calikbank.bnspr.dao.MuhSbaSatirTx;
import tr.com.calikbank.bnspr.dao.MuhSbaSatirTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

@SuppressWarnings("deprecation")
public class AccountingTRN1185Services {
    
    @GraymoundService("BNSPR_TRN1185_AFTER_APPROVAL")
    public static GMMap afterApproval(GMMap iMap) {
        Connection conn = null;
        ResultSet rSet = null;
        String faturano = null;
        CallableStatement stmt = null;
        
        try {
            Session session = DAOSession.getSession("BNSPRDal");
            MuhSatinalmaTx objMuhSatinAlmaTx = (MuhSatinalmaTx) session.get(MuhSatinalmaTx.class, iMap.getBigDecimal("ISLEM_NO"));

            if (objMuhSatinAlmaTx == null) {
                objMuhSatinAlmaTx = new MuhSatinalmaTx();
            }
            conn = DALUtil.getGMConnection();
            faturano = objMuhSatinAlmaTx.getFaturaFormNo();
   
            GMMap sMap = new GMMap();

            sMap.put("FATURA_NO", faturano);
                        
            stmt = conn .prepareCall("{ ? = call PKG_TRN1185.get_kibele_reddet(?)}");
            int index = 1;
            stmt.registerOutParameter(index++, Types.VARCHAR);
            stmt.setBigDecimal(index++, iMap.getBigDecimal("ISLEM_NO")); 
            stmt.execute();
            if("E".equals(stmt.getString(1))){
                sMap.put("SONUC", false);
            }
            else{
                sMap.put("SONUC", true);
            }

            
            
            //Yeni EOS a mi , Eski EOS a mi gidecek kontrolu yapiliyor
            stmt = conn .prepareCall("{ ? = call PKG_TRN1185.yeni_eos_mu(?)}");
            int index2 = 1;
            stmt.registerOutParameter(index2++, Types.INTEGER);
            stmt.setBigDecimal(index2++, iMap.getBigDecimal("ISLEM_NO")); 
            stmt.execute();
            
            

            if (objMuhSatinAlmaTx.getOdemeTipi().equals("F")) {
                sMap = GMServiceExecuter.call("KIBELE_RETURN_FATURA_RESULT_TO_KIBELE", sMap);
            } else if (objMuhSatinAlmaTx.getOdemeTipi().equals("H")) {
                //sMap = GMServiceExecuter.call("KIBELE_RETURN_HARCAMA_RESULT_TO_KIBELE", sMap);
            	
            	if(stmt.getInt(1)==0){
               		//Eski EOS
               		sMap = GMServiceExecuter.call("KIBELE_RETURN_HARCAMA_RESULT_TO_KIBELE", sMap);
                   }
                   else{
                   	//Yeni EOS
                   	sMap = GMServiceExecuter.call("NUEVO_RETURN_HARCAMA_RESULT_TO_NUEVO", sMap);
                   }
               	
            }
            session.flush();

            return new GMMap();
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN1185_AFTER_CANCELATION")
    public static GMMap afterCancellation(GMMap iMap) {
    	   Connection conn = null;
           ResultSet rSet = null;
           String faturano = null;
           CallableStatement stmt = null;
           try {
               Session session = DAOSession.getSession("BNSPRDal");
               MuhSatinalmaTx objMuhSatinAlmaTx = (MuhSatinalmaTx)session.get(MuhSatinalmaTx.class, iMap.getBigDecimal("ISLEM_NO"));
               
               
               if(objMuhSatinAlmaTx == null) {
                   objMuhSatinAlmaTx = new MuhSatinalmaTx();
               }
               conn = DALUtil.getGMConnection();
               faturano = objMuhSatinAlmaTx.getFaturaFormNo();   
               
               GMMap sMap = new GMMap();
                       
               sMap.put("FATURA_NO", faturano);
               sMap.put("SONUC", false);
              
               
               
               //Yeni EOS a mi , Eski EOS a mi gidecek kontrolu yapiliyor
               stmt = conn .prepareCall("{ ? = call PKG_TRN1185.yeni_eos_mu(?)}");
               int index2 = 1;
               stmt.registerOutParameter(index2++, Types.INTEGER);
               stmt.setBigDecimal(index2++, iMap.getBigDecimal("ISLEM_NO")); 
               stmt.execute();
               
               
               if (objMuhSatinAlmaTx.getOdemeTipi().equals("F")) {
                   sMap = GMServiceExecuter.call("KIBELE_RETURN_FATURA_RESULT_TO_KIBELE", sMap);
               } else if (objMuhSatinAlmaTx.getOdemeTipi().equals("H")) {
                   
               	if(stmt.getInt(1)==0){
               		//Eski EOS
               		sMap = GMServiceExecuter.call("KIBELE_RETURN_HARCAMA_RESULT_TO_KIBELE", sMap);
                   }
                   else{
                   	//Yeni EOS
                   	sMap = GMServiceExecuter.call("NUEVO_RETURN_HARCAMA_RESULT_TO_NUEVO", sMap);
                   }
               	
               	
               }
               
               session.flush(); 
                                               
               return new GMMap();
           } catch (Exception e) {
               throw ExceptionHandler.convertException(e);
           }    finally {
               GMServerDatasource.close(rSet);
               GMServerDatasource.close(stmt);
               GMServerDatasource.close(conn);
           }

    }   
        
    @GraymoundService("BNSPR_TRN1185_SAVE_SBA")
    public static Map<?, ?> saveSBA(GMMap iMap) {
        
          Connection conn = null;
          CallableStatement stmt = null;
        try {
                Session session = DAOSession.getSession("BNSPRDal");
                
                if (!"E".equals(iMap.getString("KIBELE_STATUS"))){
                    
                    GMMap oMap = bolumKoduKontrol(iMap);
                    if (oMap.getBigDecimal("HATA_NO") != null){
                        return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", oMap);
                    }
                }
        
                MuhSbaFisTx muhSbaFisTx = (MuhSbaFisTx)session.get(MuhSbaFisTx.class, iMap.getBigDecimal("TRX_NO"));
                if(muhSbaFisTx == null){
                    muhSbaFisTx = new MuhSbaFisTx();
                }
                muhSbaFisTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
                muhSbaFisTx.setUrunSinif(iMap.getString("URUN_SINIF"));
                muhSbaFisTx.setAciklama(iMap.getString("ACIKLAMA"));
                muhSbaFisTx.setRecOwner(iMap.getString("YARATAN_KULLANICI_KODU"));
                muhSbaFisTx.setGecerliOlduguTarih(iMap.getDate("GECERLI_OLDUGU_TARIH"));
                muhSbaFisTx.setRecDate(iMap.getDate("YARATILDIGI_TARIH"));
                muhSbaFisTx.setAmountLcDb(iMap.getBigDecimal("K_AMOUNT_LC_DB"));
                muhSbaFisTx.setAmountLcCr(iMap.getBigDecimal("K_AMOUNT_LC_CR"));
                
                
                session.saveOrUpdate(muhSbaFisTx);
                
                List<?> satirPersistenceList = session.createCriteria(MuhSbaSatirTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
                for (Object name : satirPersistenceList) {  //id.txNo // id.muhSbaFisTx.txNo txNo
                    MuhSbaSatirTx muhSbaSatirTx = (MuhSbaSatirTx) name;
                    session.delete(muhSbaSatirTx);
                }
                
                session.flush();
                
                
                conn = DALUtil.getGMConnection();
                stmt = conn .prepareCall("{call PKG_TRN1185.set_kibele_reddet(?,?)}");
                int index = 1;
                stmt.setBigDecimal(index++, iMap.getBigDecimal("TRX_NO"));
                stmt.setString(index++, iMap.getString("KIBELE_STATUS"));
                stmt.execute();

                
                String tableName = "SATIR_BILGILERI";
                int j = 1;
                List<?> satirBilgileri = (List<?>) iMap.get(tableName);
                for (int i = 0; i < satirBilgileri.size(); i++) {
                    MuhSbaSatirTx muhSbaSatirTx = new MuhSbaSatirTx();
                    muhSbaSatirTx.setTur(iMap.getString(tableName, i, "TUR"));
                    muhSbaSatirTx.setHesapSubeKodu(iMap.getString(tableName,i, "HESAP_SUBE_KODU"));
                    muhSbaSatirTx.setHesapTurKodu(iMap.getString(tableName,i, "HESAP_TUR_KODU"));
                    muhSbaSatirTx.setHesapNumara(iMap.getString(tableName, i, "HESAP_NUMARA"));
                    muhSbaSatirTx.setMusteriNo(iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
                    muhSbaSatirTx.setDovizKod(iMap.getString(tableName, i, "DOVIZ_KOD"));
                    muhSbaSatirTx.setKur(iMap.getBigDecimal(tableName, i, "KUR"));
                    muhSbaSatirTx.setDvTutar(iMap.getBigDecimal(tableName,i, "DV_TUTAR"));
                    muhSbaSatirTx.setLcTutar(iMap.getBigDecimal(tableName,i, "LC_TUTAR"));
                    muhSbaSatirTx.setValorTarihi(iMap.getDate(tableName, i, "VALOR_TARIHI"));
                    muhSbaSatirTx.setBankaAciklama(iMap.getString(tableName, i, "BA"));
                    muhSbaSatirTx.setMusteriAciklama(iMap.getString(tableName, i, "MA"));
                    muhSbaSatirTx.setReferans(iMap.getString(tableName, i, "RF"));
                    muhSbaSatirTx.setIstatistikKodu(iMap.getString(tableName, i, "SK"));
                    muhSbaSatirTx.setBolumKodu(iMap.getString(tableName, i, "BOLUMKODU"));
                    MuhSbaSatirTxId id = new MuhSbaSatirTxId();
                    id.setNumara(new BigDecimal(j++)); //s�ra numaras� servis taraf�ndan veriliyor
                    id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    //id.setMuhSbaFisTx(muhSbaFisTx);
                    //id.TxNo   (txNo)  setMuhSbaFisTx(muhSbaFisTx);   
                    muhSbaSatirTx.setId(id);
                    muhSbaFisTx.getMuhSbaSatirTxes().add(muhSbaSatirTx);
                    
                    session.save(muhSbaSatirTx);
                }
                
                session.flush();
                
                if(iMap.getBoolean("TEMP_SAVE")){
                    iMap.put("TRX_NAME", iMap.getString("EKRAN_NO"));
                    return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION_TEMP", iMap);
                }else{
                    iMap.put("TRX_NAME", iMap.getString("EKRAN_NO"));
                    return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
                }
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
          } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN1185_MUH_SATIN_ALMA_LIST")
    public static GMMap getMuhSatinlAlmaList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap=new GMMap();
        
        try {
            
        	conn = DALUtil.getGMConnection();
            stmt = conn .prepareCall("{? = call PKG_TRN1185.RC_MuhSatinalma_List}");
            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            oMap.putAll(DALUtil.rSetResults(rSet, "MUH_LIST"));
         
        } catch (SQLException e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }

    @GraymoundService("BNSPR_TRN1185_EKRAN_DOLDUR")
    public static GMMap getEkranDoldur(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        GMMap oMap = new GMMap();
        
        try {
           
            Session session = DAOSession.getSession("BNSPRDal");
            conn = DALUtil.getGMConnection();
            stmt = conn .prepareCall("{call PKG_TRN1185.RC_1185_ekran_doldur(?)}");
            stmt.setBigDecimal(1, iMap.getBigDecimal("TX_NO"));
            stmt.execute();
            
            MuhSbaFisTx objSbaFisTx = (MuhSbaFisTx) session.get(MuhSbaFisTx.class, iMap.getBigDecimal("TX_NO"));

            if(objSbaFisTx != null){                
                oMap.put("TX_NO", objSbaFisTx.getTxNo());
                oMap.put("ACIKLAMA", objSbaFisTx.getAciklama());
                oMap.put("GECERLI_OLDUGU_TARIH", objSbaFisTx.getGecerliOlduguTarih());
                oMap.put("YARATAN_KULLANICI_KODU", objSbaFisTx.getRecOwner());
                oMap.put("URUN_SINIF", objSbaFisTx.getUrunSinif());
                oMap.put("FIS_NO", objSbaFisTx.getFisNo());
                oMap.put("YARATILDIGI_TARIH", objSbaFisTx.getRecDate());
                oMap.put("AMOUNT_LC_DB", objSbaFisTx.getAmountLcDb());
                oMap.put("AMOUNT_LC_CR", objSbaFisTx.getAmountLcCr());
            }
            

            stmt = conn .prepareCall("{ ? = call PKG_TRN1185.get_kibele_reddet(?)}");
            int index = 1;
            stmt.registerOutParameter(index++, Types.VARCHAR);
            stmt.setBigDecimal(index++, iMap.getBigDecimal("TX_NO")); 
            stmt.execute();
            if("E".equals(stmt.getString(1)))
                oMap.put("KIBELE_STATUS", true);
            else
                oMap.put("KIBELE_STATUS", false);

            
            List<?>  objSbaSatirTxList = session.createCriteria(MuhSbaSatirTx.class)
                                                                    .add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TX_NO"))).list();

            int row=0;
            String tableName = "CBS_SBA_SATIR_ISLEM";
            for ( Object object :  objSbaSatirTxList) {
                      MuhSbaSatirTx  objSbaSatirTx = (MuhSbaSatirTx) object;
                      if(objSbaSatirTx != null){                
                              
                              oMap.put(tableName, row,  "NUMARA", objSbaSatirTx.getId().getNumara());
                              oMap.put(tableName, row,  "TUR", objSbaSatirTx.getTur());
                              oMap.put(tableName, row,  "MUSTERI_NO", objSbaSatirTx.getMusteriNo());
                              oMap.put(tableName, row,  "MUSTERI_ADI", LovHelper.diLov(objSbaSatirTx.getMusteriNo(), "1101/LOV_MUSTERI", "UNVAN"));
                              oMap.put(tableName, row,  "HA", LovHelper.diLov(objSbaSatirTx.getHesapNumara() ,objSbaSatirTx.getHesapSubeKodu(),"1101/LOV_DK_HESAP" , "KISA_ISIM"));
                              oMap.put(tableName, row,  "HESAP_TUR_KODU", objSbaSatirTx.getHesapTurKodu());
                              oMap.put(tableName, row,  "HESAP_SUBE_KODU", objSbaSatirTx.getHesapSubeKodu());
                              oMap.put(tableName, row,  "HESAP_NUMARA", objSbaSatirTx.getHesapNumara());
                              oMap.put(tableName, row,  "DOVIZ_KOD", objSbaSatirTx.getDovizKod());
                              oMap.put(tableName, row,  "KUR", objSbaSatirTx.getKur());
                              oMap.put(tableName, row,  "DV_TUTAR", objSbaSatirTx.getDvTutar());
                              oMap.put(tableName, row,  "LC_TUTAR", objSbaSatirTx.getLcTutar());
                              oMap.put(tableName, row,  "VALOR_TARIHI", objSbaSatirTx.getValorTarihi());
                              oMap.put(tableName, row, "BA", objSbaSatirTx.getBankaAciklama());
                              oMap.put(tableName, row, "MA", objSbaSatirTx.getMusteriAciklama());
                              oMap.put(tableName, row, "RF", objSbaSatirTx.getReferans());
                              oMap.put(tableName, row, "BOLUMKODU", objSbaSatirTx.getBolumKodu());
                              oMap.put(tableName, row, "BOLUMADI", LovHelper.diLov( objSbaSatirTx.getBolumKodu(),"1101/LOV_BOLUM_KODU", "ADI"));
                              oMap.put(tableName, row, "SK", objSbaSatirTx.getIstatistikKodu());
                              if(objSbaSatirTx.getHesapTurKodu().equals("DK")){
                                  oMap.put(tableName, row,  "MUSTERI_ADI",oMap.get(tableName , row ,"HA"));                                   
                              }
                              
                              row++;
                      }                  
            }
            
           session.close();
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN1185_GET_INFO")
    public static GMMap getGetInfo(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        GMMap oMap = new GMMap();
        
        try {
           
            Session session = DAOSession.getSession("BNSPRDal");
            
            MuhSbaFisTx objSbaFisTx = (MuhSbaFisTx) session.get(MuhSbaFisTx.class, iMap.getBigDecimal("TX_NO"));

            if(objSbaFisTx != null){                
                oMap.put("TX_NO", objSbaFisTx.getTxNo());
                oMap.put("ACIKLAMA", objSbaFisTx.getAciklama());
                oMap.put("GECERLI_OLDUGU_TARIH", objSbaFisTx.getGecerliOlduguTarih());
                oMap.put("YARATAN_KULLANICI_KODU", objSbaFisTx.getRecOwner());
                oMap.put("URUN_SINIF", objSbaFisTx.getUrunSinif());
                oMap.put("FIS_NO", objSbaFisTx.getFisNo());
                oMap.put("YARATILDIGI_TARIH", objSbaFisTx.getRecDate());
                oMap.put("AMOUNT_LC_DB", objSbaFisTx.getAmountLcDb());
                oMap.put("AMOUNT_LC_CR", objSbaFisTx.getAmountLcCr());
            }
            
            conn = DALUtil.getGMConnection();
            stmt = conn .prepareCall("{ ? = call PKG_TRN1185.get_kibele_reddet(?)}");
            int index = 1;
            stmt.registerOutParameter(index++, Types.VARCHAR);
            stmt.setBigDecimal(index++, iMap.getBigDecimal("TX_NO")); 
            stmt.execute();
            if("E".equals(stmt.getString(1)))
                oMap.put("KIBELE_STATUS", true);
            else
                oMap.put("KIBELE_STATUS", false);

            
            List<?>  objSbaSatirTxList = session.createCriteria(MuhSbaSatirTx.class)
                                                                    .add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TX_NO"))).list();

            int row=0;
            String tableName = "CBS_SBA_SATIR_ISLEM";
            for ( Object object :  objSbaSatirTxList) {
                      MuhSbaSatirTx  objSbaSatirTx = (MuhSbaSatirTx) object;
                      if(objSbaSatirTx != null){                
                              
                              oMap.put(tableName, row,  "NUMARA", objSbaSatirTx.getId().getNumara());
                              oMap.put(tableName, row,  "TUR", objSbaSatirTx.getTur());
                              oMap.put(tableName, row,  "MUSTERI_NO", objSbaSatirTx.getMusteriNo());
                              oMap.put(tableName, row,  "MUSTERI_ADI", LovHelper.diLov(objSbaSatirTx.getMusteriNo(), "1101/LOV_MUSTERI", "UNVAN"));
                              oMap.put(tableName, row,  "HA", LovHelper.diLov(objSbaSatirTx.getHesapNumara() ,objSbaSatirTx.getHesapSubeKodu(),"1101/LOV_DK_HESAP" , "KISA_ISIM"));
                              oMap.put(tableName, row,  "HESAP_TUR_KODU", objSbaSatirTx.getHesapTurKodu());
                              oMap.put(tableName, row,  "HESAP_SUBE_KODU", objSbaSatirTx.getHesapSubeKodu());
                              oMap.put(tableName, row,  "HESAP_NUMARA", objSbaSatirTx.getHesapNumara());
                              oMap.put(tableName, row,  "DOVIZ_KOD", objSbaSatirTx.getDovizKod());
                              oMap.put(tableName, row,  "KUR", objSbaSatirTx.getKur());
                              oMap.put(tableName, row,  "DV_TUTAR", objSbaSatirTx.getDvTutar());
                              oMap.put(tableName, row,  "LC_TUTAR", objSbaSatirTx.getLcTutar());
                              oMap.put(tableName, row,  "VALOR_TARIHI", objSbaSatirTx.getValorTarihi());
                              oMap.put(tableName, row, "BA", objSbaSatirTx.getBankaAciklama());
                              oMap.put(tableName, row, "MA", objSbaSatirTx.getMusteriAciklama());
                              oMap.put(tableName, row, "RF", objSbaSatirTx.getReferans());
                              oMap.put(tableName, row, "BOLUMKODU", objSbaSatirTx.getBolumKodu());
                              oMap.put(tableName, row, "BOLUMADI", LovHelper.diLov( objSbaSatirTx.getBolumKodu(),"1101/LOV_BOLUM_KODU", "ADI"));
                              oMap.put(tableName, row, "SK", objSbaSatirTx.getIstatistikKodu());
                              if(objSbaSatirTx.getHesapTurKodu().equals("DK")){
                                  oMap.put(tableName, row,  "MUSTERI_ADI",oMap.get(tableName , row ,"HA"));                                   
                              }
                              row++;
                      }                  
            }
            
           session.close();
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    private static GMMap bolumKoduKontrol(GMMap iMap) throws Exception{
        String tableName = "SATIR_BILGILERI";
        boolean bolumTanimli;
        GMMap oMap = new GMMap();
        List<?> satirBilgileri = (List<?>) iMap.get(tableName);
        for (int i = 0; i < satirBilgileri.size(); i++) {
            if (iMap.getString(tableName, i, "BOLUMKODU") != null ){
                bolumTanimli = bolumKoduTanimli(iMap.getString(tableName, i, "BOLUMKODU"));
                if (!bolumTanimli){
                    oMap.put("HATA_NO", new BigDecimal(660));
                    oMap.put("P1", iMap.getString(tableName, i, "BOLUMKODU") + " nolu b�l�m kodu Akustik'te tan�ml� de�il, �demeyi reddediniz.");
                    break;
                }
            }
        }
        return oMap;
    }
    
    private static boolean bolumKoduTanimli(String bolumKodu){
        Session session = null;
        session = DAOSession.getSession("BNSPRDal");
        Criteria criteria = session.createCriteria(GnlBolumKodPr.class).add(Restrictions.eq("kod" , bolumKodu)).add(Restrictions.eq("durumKodu" , "A"));
        List<?> list = criteria.list();
        if (list != null){
            return list.size() > 0;
        }
        return false;
        //GnlBolumKodPr bolumKodPr = (GnlBolumKodPr)session.get(GnlBolumKodPr.class , bolumKodu);
        //return bolumKodPr != null;
    }   
}
