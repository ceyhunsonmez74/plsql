package tr.com.calikbank.bnspr.accounting.services;
 
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlMasKomFaizGelTipPrTx;
import tr.com.aktifbank.bnspr.dao.GnlMasKomFaizGelTipPrTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1120Services {


	@GraymoundService("BNSPR_TRN1120_SAVE")
	public static Map<?, ?> saveSBA(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "MASKOMFAIZ_TIP_TANIMLAMA";
			List<?> satirBilgileri = (List<?>) iMap.get(tableName);
			GMMap oMap = new GMMap();
			
			for(int i =0; i<satirBilgileri.size();i++ )
			{
				for (int j =0; j<satirBilgileri.size(); j++ )
				{	
					
					if(iMap.getString(tableName,j, "KOD")==null || iMap.getString(tableName,i, "KOD").isEmpty())
					{
						iMap.put("MESSAGE_NO", 330);
						iMap.put("P1", "KOD");
						oMap.put("ERROR_MESSAGE",GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
						return oMap;
					}
					if( i!=j && iMap.getString(tableName,i, "KOD").equals(iMap.getString(tableName,j, "KOD")))
					{
						iMap.put("MESSAGE_NO", 723);
						iMap.put("P1", "KOD");
						oMap.put("ERROR_MESSAGE",GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
						return oMap;
					}
				}
			}
			
			for (int i = 0; i < satirBilgileri.size(); i++) {
				GnlMasKomFaizGelTipPrTx masKomFaizGelTip = new GnlMasKomFaizGelTipPrTx();
				masKomFaizGelTip.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
				masKomFaizGelTip.setDkNoLc(iMap.getString(tableName,i, "DK_NO_LC"));
				masKomFaizGelTip.setDkNoFc(iMap.getString(tableName,i, "DK_NO_FC"));
				masKomFaizGelTip.setGDS(iMap.getString(tableName,i, "G_D_S"));
				masKomFaizGelTip.setMK(iMap.getString(tableName,i, "M_K"));
				masKomFaizGelTip.setHesabaBagliMi(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean(tableName, i, "HESABA_BAGLI_MI")));
				masKomFaizGelTip.setModulTurKod(iMap.getString(tableName,i, "MODUL_TUR_KOD"));
				masKomFaizGelTip.setUrunTurKod(iMap.getString(tableName,i, "URUN_TUR_KOD"));
				masKomFaizGelTip.setBsmvDk(iMap.getString(tableName,i, "BSMV_DK"));
				GnlMasKomFaizGelTipPrTxId id = new GnlMasKomFaizGelTipPrTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO")); 
				id.setKod(iMap.getString(tableName,i, "KOD"));
				masKomFaizGelTip.setId(id);
				
				session.save(masKomFaizGelTip);
			}
			
			session.flush();
			iMap.put("TRX_NAME", "1120");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1120_GET_INFO")
	public static GMMap getSBA(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		
		List<?> satirPersistenceList = session.createCriteria(GnlMasKomFaizGelTipPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
		String tableName = "MASKOMFAIZ_TIP_TANIMLAMA"; 
		for (int i = 0; i < satirPersistenceList.size(); i++) {
			GnlMasKomFaizGelTipPrTx masKomFaizGelTip = (GnlMasKomFaizGelTipPrTx) satirPersistenceList.get(i);
			
			oMap.put(tableName, i, "ACIKLAMA", masKomFaizGelTip.getAciklama());
			oMap.put(tableName, i, "DK_NO_LC", masKomFaizGelTip.getDkNoLc());
			oMap.put(tableName, i, "DK_NO_FC", masKomFaizGelTip.getDkNoFc());
			oMap.put(tableName, i, "M_K", masKomFaizGelTip.getMK());
			oMap.put(tableName, i, "TRX_NO", masKomFaizGelTip.getId().getTxNo());
			oMap.put(tableName, i, "KOD", masKomFaizGelTip.getId().getKod());
			oMap.put(tableName, i ,"HESABA_BAGLI_MI" , masKomFaizGelTip.getHesabaBagliMi().equals("E") ? true : false);
			oMap.put(tableName, i, "MODUL_TUR_KOD", masKomFaizGelTip.getModulTurKod());
			oMap.put(tableName, i, "URUN_TUR_KOD", masKomFaizGelTip.getUrunTurKod());
			if(masKomFaizGelTip.getBsmvDk() != null )
			   oMap.put(tableName, i, "BSMV_DK", masKomFaizGelTip.getBsmvDk());
			
			
			if(masKomFaizGelTip.getGDS()!=null && masKomFaizGelTip.getGDS().equals("S"))
				oMap.put(tableName, i, "DELETE", "true");
			oMap.put("TRX_NO", masKomFaizGelTip.getId().getTxNo());
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1120_LIST")
	public static GMMap getDiUrunSinif(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{      
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN1120.get_list()}"); //PROSEDUR
			
			int i = 0;
			stmt.registerOutParameter(++i, -10);
			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(i);
			           
			return DALUtil.rSetResults(rSet, "MASKOMFAIZ_TIP_TANIMLAMA");
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	
}
