package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlMusHesapMaskomMuafTx;
import tr.com.aktifbank.bnspr.dao.GnlMusHesapMaskomMuafTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlMasrafKomKriterTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingTRN1167Services {
	
	@GraymoundService("BNSPR_TRN1167_GET_TRX_NO")
	public static GMMap getTrxNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_trn1167.get_parameters(?,?,?,?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("HESAP_NO"));
			stmt.setString(4, iMap.getString("KANAL_Q"));
			stmt.setString(5, iMap.getString("STATU_Q"));
			stmt.execute();

			oMap.put("TRX_NO", stmt.getBigDecimal(1));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}
	
	@GraymoundService("BNSPR_TRN1167_GET_MUSTERI_HESAP_MASKOM_MUAF_LIST")
	public static GMMap getMusteriHesapMaskomMuafList(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(GnlMusHesapMaskomMuafTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "MUSTERI_HESAP_MASKOM_MUAF";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlMusHesapMaskomMuafTx gnlMusHesapMaskomMuafTx = (GnlMusHesapMaskomMuafTx)iterator.next();

				if (gnlMusHesapMaskomMuafTx.getDrm().equals("I"))
					oMap.put(tableName, row,"DRM","1");
				else
					oMap.put(tableName, row,"DRM","0");
				
				oMap.put(tableName, row,"END_DATE",gnlMusHesapMaskomMuafTx.getEndDate());
				oMap.put(tableName, row,"KANAL_KOD",gnlMusHesapMaskomMuafTx.getKanalKod());
				oMap.put(tableName, row,"HESAP_MUAF_ID",gnlMusHesapMaskomMuafTx.getId().getHesapMuafId());
				oMap.put(tableName, row,"MUSTERI_NO",gnlMusHesapMaskomMuafTx.getMusteriNo());
				oMap.put(tableName, row,"HESAP_NO",gnlMusHesapMaskomMuafTx.getHesapNo());
				oMap.put(tableName, row,"START_DATE",gnlMusHesapMaskomMuafTx.getStartDate());
				
				oMap.put(tableName, row,"ESKI_KAYIT" ,"ESKI");
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1167_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "MUSTERI_HESAP_MASKOM_MUAF";
			List<?> list = (List<?>)iMap.get(tableName);
			
			for (int i = 0; i < list.size(); i++) {
				GnlMusHesapMaskomMuafTxId gnlMusHesapMaskomMuafTxId = new GnlMusHesapMaskomMuafTxId();
				gnlMusHesapMaskomMuafTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlMusHesapMaskomMuafTxId.setHesapMuafId(iMap.getBigDecimal(tableName, i , "HESAP_MUAF_ID"));
				
				GnlMusHesapMaskomMuafTx gnlMusHesapMaskomMuafTx = (GnlMusHesapMaskomMuafTx)session.get(GnlMusHesapMaskomMuafTx.class, gnlMusHesapMaskomMuafTxId);
				
				if(gnlMusHesapMaskomMuafTx == null)gnlMusHesapMaskomMuafTx = new GnlMusHesapMaskomMuafTx();
				
				gnlMusHesapMaskomMuafTx.setId(gnlMusHesapMaskomMuafTxId);
				if (iMap.getString(tableName,i,"DRM").equals("1")) gnlMusHesapMaskomMuafTx.setDrm("I");
				else gnlMusHesapMaskomMuafTx.setDrm("A");
				gnlMusHesapMaskomMuafTx.setEndDate(iMap.getDate(tableName, i, "END_DATE"));
				gnlMusHesapMaskomMuafTx.setKanalKod(iMap.getString(tableName, i, "KANAL_KOD"));
				gnlMusHesapMaskomMuafTx.setMusteriNo(iMap.getBigDecimal(tableName, i , "MUSTERI_NO"));
				gnlMusHesapMaskomMuafTx.setHesapNo(iMap.getBigDecimal(tableName, i , "HESAP_NO"));
				gnlMusHesapMaskomMuafTx.setStartDate(iMap.getDate(tableName, i, "START_DATE"));
				
				session.saveOrUpdate(gnlMusHesapMaskomMuafTx);
			}
			session.flush();
			
			
			GnlMasrafKomKriterTx gnlMasrafKomKriterTx = new GnlMasrafKomKriterTx();
			
			gnlMasrafKomKriterTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			gnlMasrafKomKriterTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			gnlMasrafKomKriterTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			gnlMasrafKomKriterTx.setKanalKod(iMap.getString("KANAL_KOD"));
			gnlMasrafKomKriterTx.setDrm(iMap.getString("STATU"));
			
			session.save(gnlMasrafKomKriterTx);
			session.flush();
			

			iMap.put("TRX_NAME", "1167");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1167_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> muafList = session.createCriteria(GnlMusHesapMaskomMuafTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "MUSTERI_HESAP_MASKOM_MUAF";
			int row = 0;
			for (Iterator<?> iterator = muafList.iterator(); iterator.hasNext();) {
				GnlMusHesapMaskomMuafTx gnlMusHesapMaskomMuafTx = (GnlMusHesapMaskomMuafTx)iterator.next();
				
				if (gnlMusHesapMaskomMuafTx.getDrm().equals("I"))
					oMap.put(tableName, row,"DRM","1");
				else
					oMap.put(tableName, row,"DRM","0");
				oMap.put(tableName, row, "END_DATE",gnlMusHesapMaskomMuafTx.getEndDate());
				oMap.put(tableName, row, "KANAL_KOD",gnlMusHesapMaskomMuafTx.getKanalKod());
				oMap.put(tableName, row, "MUSTERI_NO",gnlMusHesapMaskomMuafTx.getMusteriNo());
				oMap.put(tableName, row, "HESAP_NO",gnlMusHesapMaskomMuafTx.getHesapNo());
				oMap.put(tableName, row, "START_DATE",gnlMusHesapMaskomMuafTx.getStartDate());
				
				row++;
				
			}
			
			GnlMasrafKomKriterTx gnlMasrafKomKriterTx = (GnlMasrafKomKriterTx)session.get(GnlMasrafKomKriterTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", gnlMasrafKomKriterTx.getTxNo());
			oMap.put("MUSTERI_NO", gnlMasrafKomKriterTx.getMusteriNo());
			oMap.put("HESAP_NO", gnlMasrafKomKriterTx.getHesapNo());
			oMap.put("MUSTERI_ADI", LovHelper.diLov(gnlMasrafKomKriterTx.getMusteriNo(), "1162/LOV_MUSTERI_BILGI", "ID_DESC"));
			oMap.put("KANAL_KOD", gnlMasrafKomKriterTx.getKanalKod());
			oMap.put("KANAL_ADI", LovHelper.diLov(gnlMasrafKomKriterTx.getKanalKod(), "1162/LOV_KANAL", "ACIKLAMA"));
			oMap.put("STATU", gnlMasrafKomKriterTx.getDrm());
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
