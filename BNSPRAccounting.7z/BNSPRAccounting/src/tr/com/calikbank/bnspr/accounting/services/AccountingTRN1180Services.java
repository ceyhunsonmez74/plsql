package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.BinsWbMuhEntegrasyon;
import tr.com.calikbank.bnspr.dao.BinsWbMuhEntegrasyonId;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1180Services {
	@GraymoundService("BNSPR_TRN1180_GET_MUHASEBE_LISTESI")
	public static GMMap getMuhasebeListesi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_BINS_TO_WB.wb_kasa_devir(?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("AKTARIM_NO"));
			stmt.execute();
			
			StringBuilder query = new StringBuilder();
			query.append("select fis_numara,t.satir_numara,t.satir_tur,t.satir_hesap_bolum_kodu hesap_sube,t.satir_hesap_numara hesap_no,t.satir_musteri_hesap_tur mus_hesap_tur, ");
			query.append("   t.SATIR_MUSTERI_HESAP_NUMARA musteri_hesap, ");
			query.append("   t.FIS_MUHASEBELESTIGI_TARIH islem_tarih,t.SATIR_VALOR_TARIHI valor_tarih,lc_tutar,dv_tutar,doviz_kod, fis_islem_numara, fis_islem_sube, satir_musteri_hesap_numara, ");
			query.append("   t.defterid,t.wb_hesap_sube,t.wb_musteri_no,t.wb_musteri_ekno,t.wb_mkkodu,t.wb_islemkodu,t.wb_borc,t.wb_alacak,t.wb_dovizcinsi, t.wb_islem_sube, t.satir_banka_aciklama, t.satir_istatistik_kodu, t.satir_musteri_no ");
			query.append("from v_muh_fis_wb_entegrasyon t ");
			query.append("where t.FIS_MUHASEBELESTIGI_TARIH=?  ");
			query.append("union  ");
			query.append("select fis_numara,t.satir_numara,t.satir_tur,t.satir_hesap_bolum_kodu hesap_sube,t.satir_hesap_numara hesap_no,t.satir_musteri_hesap_tur mus_hesap_tur,  ");
			query.append("t.SATIR_MUSTERI_HESAP_NUMARA musteri_hesap,   ");
			query.append(" t.FIS_MUHASEBELESTIGI_TARIH islem_tarih,t.SATIR_VALOR_TARIHI valor_tarih,lc_tutar,dv_tutar,doviz_kod, null as fis_islem_numara, fis_islem_sube, satir_musteri_hesap_numara, ");
			query.append("t.defterid,t.wb_hesap_sube,t.wb_musteri_no,t.wb_musteri_ekno,t.wb_mkkodu,t.wb_islemkodu,t.wb_borc,t.wb_alacak,t.wb_dovizcinsi, t.wb_islem_sube, t.satir_banka_aciklama, t.satir_istatistik_kodu, t.satir_musteri_no ");
			query.append("from muh_kasa_wb_entegrasyon t   ");
			query.append("where aktarim_no=? ");
			query.append("order by 1,2 ");
			stmt = conn.prepareCall(query.toString());
			stmt.setDate(1, new java.sql.Date(iMap.getDate("AKTARIM_TARIHI").getTime()));
			stmt.setBigDecimal(2, iMap.getBigDecimal("AKTARIM_NO"));
			rSet = stmt.executeQuery();

			String tableName = "MUHASEBE_BILGILERI";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row, "FIS_NO", rSet .getBigDecimal("fis_numara"));
				oMap.put(tableName, row, "SATIR_NO", rSet.getInt("satir_numara"));
				oMap.put(tableName, row, "B_A", rSet.getString("satir_tur"));
				oMap.put(tableName, row, "HESAP_SUBE", rSet.getString("hesap_sube"));
				oMap.put(tableName, row, "HESAP_NO", rSet.getString("hesap_no"));
				oMap.put(tableName, row, "MUS_HESAP_TUR", rSet.getString("mus_hesap_tur"));
				oMap.put(tableName, row, "MUSTERI_HESAP", rSet.getString("musteri_hesap"));
				oMap.put(tableName, row, "ISLEM_TARIH", rSet.getDate("islem_tarih"));
				oMap.put(tableName, row, "VALOR_TARIH", rSet.getDate("valor_tarih"));
				
				oMap.put(tableName, row, "WB_DEFTERID", rSet.getString("defterid"));
				oMap.put(tableName, row, "WB_HESAP_SUBE", rSet.getBigDecimal("wb_hesap_sube"));
				oMap.put(tableName, row, "WB_MUSTERI_NO", rSet.getBigDecimal("wb_musteri_no"));
				oMap.put(tableName, row, "WB_MUSTERI_EKNO", rSet.getBigDecimal("wb_musteri_ekno"));
				oMap.put(tableName, row, "WB_MKKODU", rSet.getBigDecimal("wb_mkkodu"));
				oMap.put(tableName, row, "WB_ISLEMKODU", rSet.getBigDecimal("wb_islemkodu"));
				oMap.put(tableName, row, "WB_BORC", rSet.getBigDecimal("wb_borc"));
				oMap.put(tableName, row, "WB_ALACAK", rSet.getBigDecimal("wb_alacak"));
				oMap.put(tableName, row, "WB_DOVIZCINSI", rSet.getString("wb_dovizcinsi"));
				oMap.put(tableName, row, "WB_ISLEM_SUBE", rSet.getString("wb_islem_sube"));
				
				oMap.put(tableName, row, "LC_TUTAR", rSet.getString("lc_tutar"));
				oMap.put(tableName, row, "DV_TUTAR", rSet.getString("dv_tutar"));
				oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString("doviz_kod"));
				oMap.put(tableName, row, "FIS_ISLEM_NUMARA", rSet.getString("fis_islem_numara"));
				oMap.put(tableName, row, "FIS_ISLEM_SUBE", rSet.getString("fis_islem_sube"));
				oMap.put(tableName, row, "SATIR_MUSTERI_HESAP_NUMARA", rSet.getString("satir_musteri_hesap_numara"));
				oMap.put(tableName, row, "SATIR_MUSTERI_NUMARA", rSet.getString("satir_musteri_no"));
				oMap.put(tableName, row, "SATIR_BANKA_ACIKLAMA", rSet.getString("satir_banka_aciklama"));
				oMap.put(tableName, row, "ISTATISTIK_KODU", rSet.getString("satir_istatistik_kodu"));
				oMap.put(tableName, row, "ONAY_EH", "1");

				row++;
			}
			oMap.put("KAYIT_SAYISI", row);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1180_AKTARIM")
	public static Map<?, ?> saveMuhasebeBilgileri(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "MUHASEBE_BILGILERI";
			List<?> onaylanmisEftGuiList = (List<?>)iMap.get(tableName);
			for (int i = 0; i < onaylanmisEftGuiList.size(); i++) {
				BinsWbMuhEntegrasyon muhEntegrasyon = new BinsWbMuhEntegrasyon();
				
				//test i�in
				if(!"1".equals(iMap.getString(tableName, i, "ONAY_EH"))){
					continue;
				}
				BinsWbMuhEntegrasyonId id = new BinsWbMuhEntegrasyonId();
				id.setFisNo(iMap.getBigDecimal(tableName, i, "FIS_NO"));
				id.setAktarimNo(iMap.getBigDecimal("TRX_NO"));
				id.setSatirNumara(iMap.getBigDecimal(tableName, i, "SATIR_NO"));
				muhEntegrasyon.setOnayEh("E");
				muhEntegrasyon.setId(id);
				muhEntegrasyon.setBA(iMap.getString(tableName, i, "B_A"));
				muhEntegrasyon.setHesapSubeKod(iMap.getString(tableName, i, "HESAP_SUBE"));
				muhEntegrasyon.setHesapNumara(iMap.getString(tableName, i, "HESAP_NO"));
				muhEntegrasyon.setMusteriHesapNo(iMap.getBigDecimal(tableName, i, "MUSTERI_HESAP"));
				muhEntegrasyon.setWbDefterid(iMap.getString(tableName, i, "WB_DEFTERID"));
				muhEntegrasyon.setWbSube(iMap.getBigDecimal(tableName, i, "WB_HESAP_SUBE"));
				muhEntegrasyon.setWbMusteriNo(iMap.getBigDecimal(tableName, i, "WB_MUSTERI_NO"));
				muhEntegrasyon.setWbMusteriEkno(iMap.getBigDecimal(tableName, i, "WB_MUSTERI_EKNO"));
				muhEntegrasyon.setAktarimTarih(iMap.getDate("AKTARIM_TARIHI"));

				muhEntegrasyon.setDovizKod(iMap.getString(tableName, i, "DOVIZ_KOD"));
				muhEntegrasyon.setDvTutar(iMap.getBigDecimal(tableName, i, "DV_TUTAR"));
				//muhEntegrasyon.setHesapTurKodu(iMap.getString(tableName, i, "DV_TUTAR")) �ekmiyoruz, atm�yoruz
				muhEntegrasyon.setIslemNumara(iMap.getBigDecimal(tableName, i, "FIS_ISLEM_NUMARA"));
				muhEntegrasyon.setIslemSubeKod(iMap.getString(tableName, i, "FIS_ISLEM_SUBE"));
				muhEntegrasyon.setLcTutar(iMap.getBigDecimal(tableName, i, "LC_TUTAR"));
				muhEntegrasyon.setMusteriHesapNo(iMap.getBigDecimal(tableName, i, "SATIR_MUSTERI_HESAP_NUMARA"));
				muhEntegrasyon.setMusteriNumara(iMap.getBigDecimal(tableName, i, "SATIR_MUSTERI_NUMARA"));

				session.save(muhEntegrasyon);
			}
			
			session.flush();
			iMap.put("TRX_NAME", "1180");
			Map<?, ?> oMap = GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap); 
			
			Map<?, ?> winbankResultMap = GMServiceExecuter.execute("BNSPR_TRN1180_EFT_MUAHASEBE_TO_WINBANK", iMap);
			String winbankResult = (String)winbankResultMap.get("RESULT");
			if("FAILURE".equals(winbankResult)){
				AccountingChargesServices.throwGMBusssinessException("Winbankda hata al�nd�.");
			}
			
		//	winbankResultMap = GMServiceExecuter.execute("BNSPR_TRN1180_WINBANK_MUHASEBE", iMap);
	/*		String winbankResult1 = (String)winbankResultMap.get("RESULT");
			if ("FAILURE".equals(winbankResult1)) {
				throw new GMRuntimeException(0, "Winbankda muhasebe �al��t�r�l�rken hata al�nd�: ");
			}
*/
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1180_EFT_MUAHASEBE_TO_WINBANK")
	public static Map<?, ?> sendMuhasebeToWinbank(GMMap iMap) {
			Connection connSql = null;
			CallableStatement stmtSql = null;
			GMMap oMap = new GMMap();
			try {
				connSql = DALUtil.getWinbankConnection();
				connSql.setAutoCommit(false);
				StringBuffer sb = new StringBuffer();
				//sb.append("INSERT INTO bins_hareketmuhasebe (aktarimtarihi, subekodu, defterid, musterino, ekno, mkkodu, islemkodu, ");
				//sb.append("borc, alacak, islemtarihi, valor, islemsube, islemsirano, dovizcinsi, aciklama, kullanici, binsref, istkodu, ");
				//sb.append("giristarihi, statu) VALUES ");
				//sb.append("(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");  gonmderilmeyecek alanlari ucurdum MHA 160708
				sb.append("INSERT INTO bins_hareketmuhasebe (subekodu, defterid, musterino, ekno, mkkodu, islemkodu, ");
				sb.append("borc, alacak, islemtarihi, valor, islemsirano, dovizcinsi, aciklama, kullanici, binsref, istkodu, ");
				sb.append("giristarihi, statu) VALUES ");
				sb.append("(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
				
				stmtSql = connSql.prepareCall(sb.toString());
				String tableName = "MUHASEBE_BILGILERI";
				List<?> onaylanmisEftGuiList = (List<?>)iMap.get(tableName);
				for (int i = 0; i < onaylanmisEftGuiList.size(); i++) {
					if(!"1".equals(iMap.getString(tableName, i, "ONAY_EH"))){
						continue;
					}
					//stmtSql = connSql.prepareCall(sb.toString());
					stmtSql.clearParameters();

					int pc = 1;
					//if(iMap.getDate("AKTARIM_TARIHI") != null)  //aktarimtarihi
					//	stmtSql.setTimestamp(pc++, new java.sql.Timestamp(iMap.getDate("AKTARIM_TARIHI").getTime()));
					//else
					//	stmtSql.setNull(pc++, Types.TIMESTAMP);         MHA 160708
					//System.out.println("\n\n\nKAYIT : " + i);
					
					stmtSql.setObject(pc++, iMap.getInt(tableName, i, "WB_HESAP_SUBE"), Types.SMALLINT); //subekodu
					//System.out.println("subekodu: " + iMap.getInt(tableName, i, "WB_HESAP_SUBE"));
					stmtSql.setObject(pc++, iMap.getInt(tableName, i, "WB_DEFTERID"), Types.INTEGER); //defterid
					//System.out.println("defterid: " + iMap.getInt(tableName, i, "WB_DEFTERID"));
					stmtSql.setObject(pc++, iMap.getInt(tableName, i, "WB_MUSTERI_NO"), Types.INTEGER); //musterino
					//System.out.println("musterino: " + iMap.getInt(tableName, i, "WB_MUSTERI_NO"));
					stmtSql.setObject(pc++, iMap.getInt(tableName, i, "WB_MUSTERI_EKNO"), Types.SMALLINT); //ekno
					//System.out.println("ekno: " + iMap.getInt(tableName, i, "WB_MUSTERI_EKNO"));
					stmtSql.setObject(pc++, iMap.getInt(tableName, i, "WB_MKKODU"), Types.SMALLINT); //mkkodu
					//System.out.println("mkkodu: " + iMap.getInt(tableName, i, "WB_MKKODU"));
					stmtSql.setObject(pc++, iMap.getInt(tableName, i, "WB_ISLEMKODU"), Types.SMALLINT); //islemkodu
					//System.out.println("islemkodu: " + iMap.getInt(tableName, i, "WB_ISLEMKODU"));
					
					if(iMap.getBigDecimal(tableName, i, "WB_BORC") != null){ //borc
						stmtSql.setObject(pc++, iMap.getBigDecimal(tableName, i, "WB_BORC"), Types.DECIMAL);
					}else{
						stmtSql.setNull(pc++, Types.DECIMAL);
					}
					//System.out.println("borc: " + iMap.getBigDecimal(tableName, i, "WB_BORC"));
					if(iMap.getBigDecimal(tableName, i, "WB_ALACAK") != null) //alacak
						stmtSql.setObject(pc++, iMap.getBigDecimal(tableName, i, "WB_ALACAK"), Types.DECIMAL); 
					else
						stmtSql.setNull(pc++, Types.DECIMAL);

					if(iMap.getDate(tableName, i, "ISLEM_TARIH") != null) //islemtarihi
						stmtSql.setTimestamp(pc++, new java.sql.Timestamp(iMap.getDate(tableName, i,  "ISLEM_TARIH").getTime())); 
					else
						stmtSql.setNull(pc++, Types.TIMESTAMP);
					if(iMap.getDate(tableName, i, "VALOR_TARIH") != null) //valor 
						stmtSql.setTimestamp(pc++, new java.sql.Timestamp(iMap.getDate(tableName, i,  "VALOR_TARIH").getTime())); 
					else
						stmtSql.setNull(pc++, Types.TIMESTAMP);
					
					//stmtSql.setObject(pc++, iMap.getInt(tableName, i, "WB_ASUBE"), Types.SMALLINT); //islemsube   MHA 160708
					stmtSql.setObject(pc++, iMap.getInt(tableName, i, "SATIR_NO"), Types.SMALLINT); //islemsirano
					stmtSql.setObject(pc++, iMap.getInt(tableName, i, "WB_DOVIZCINSI"), Types.TINYINT); //dovizcinsi
					
					if(iMap.getString(tableName, i, "SATIR_BANKA_ACIKLAMA") != null)
						stmtSql.setString(pc++, iMap.getString(tableName, i, "SATIR_BANKA_ACIKLAMA")); //aciklama
					else
						stmtSql.setNull(pc++, Types.VARCHAR);
					
					stmtSql.setString(pc++,"binspire"); //kullanici MHA 030908 					
					//stmtSql.setString(pc++, "deneme"); //kullanici
					//if(iMap.getString(tableName, i, "binspire") != null)
						
					//else
					//	stmtSql.setNull(pc++, Types.VARCHAR);

					if(iMap.getBigDecimal(tableName, i, "FIS_NO") != null)  //binsref MHA 280708 FIS_ISLEM_NUMARA yerine FIS_NO gonderiyoruz.
						stmtSql.setString(pc++, iMap.getBigDecimal(tableName, i, "FIS_NO").intValue() + "");
					else
						stmtSql.setNull(pc++, Types.VARCHAR);
					
					if(iMap.getString(tableName, i, "ISTATISTIK_KODU") != null) //istkodu
						stmtSql.setString(pc++, iMap.getString(tableName, i, "ISTATISTIK_KODU")); 
					else
						stmtSql.setNull(pc++, Types.VARCHAR);
					
					stmtSql.setTimestamp(pc++, new java.sql.Timestamp(new Date().getTime())); //giristarih
					stmtSql.setObject(pc++, 2, Types.SMALLINT);  //default 1 //statu
					stmtSql.execute();
				}
				connSql.commit();
			oMap.put("RESULT", "SUCCESS");
		} catch (Exception e) {
			oMap.put("RESULT", "FAILURE");
			try {
				connSql.rollback();
			} catch (SQLException e1) { //ignore
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		finally{
			GMServerDatasource.close(stmtSql);
			GMServerDatasource.close(connSql);
		}
		return oMap;
	}
	
	/*
	
	@GraymoundService("BNSPR_TRN1180_CONFIRM_MUAHASEBE_BILGILERI_TO_BINSPIRE")
	public static GMMap confirmMuhasebeBilgileri(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "MUHASEBE_BILGILERI";
			List<?> onaylanmisEftGuiList = (List<?>)iMap.get(tableName);
			for (int i = 0; i < onaylanmisEftGuiList.size(); i++) {
				
				//test i�in
				if(!"1".equals(iMap.getString(tableName, i, "ONAY_EH"))){
					continue;
				}
				
				BinsWbMuhEntegrasyon muhEntegrasyon = (BinsWbMuhEntegrasyon)session.get(BinsWbMuhEntegrasyon.class, new BinsWbMuhEntegrasyonId(iMap.getBigDecimal("AKTARIM_NO"), iMap.getBigDecimal(tableName, i, "FIS_NO"), iMap.getBigDecimal(tableName, i, "SATIR_NO")));
				muhEntegrasyon.setOnayEh("H");
				muhEntegrasyon.setBA(iMap.getString(tableName, i, "B_A"));
				muhEntegrasyon.setHesapSubeKod(iMap.getString(tableName, i, "HESAP_SUBE"));
				muhEntegrasyon.setHesapNumara(iMap.getString(tableName, i, "HESAP_NO"));
				muhEntegrasyon.setMusteriHesapNo(iMap.getBigDecimal(tableName, i, "MUSTERI_HESAP"));
				muhEntegrasyon.setWbDefterid(iMap.getString(tableName, i, "DEFTERID"));
				muhEntegrasyon.setWbSube(iMap.getBigDecimal(tableName, i, "WB_HESAP_SUBE"));
				muhEntegrasyon.setWbMusteriNo(iMap.getBigDecimal(tableName, i, "WB_MUSTERI_NO"));
				muhEntegrasyon.setWbMusteriEkno(iMap.getBigDecimal(tableName, i, "WB_MUSTERI_EKNO"));
				muhEntegrasyon.setAktarimTarih(iMap.getDate("AKTARIM_TARIHI"));
				muhEntegrasyon.setDovizKod(iMap.getString(tableName, i, "DOVIZ_KOD"));
				muhEntegrasyon.setDvTutar(iMap.getBigDecimal(tableName, i, "DV_TUTAR"));
				//muhEntegrasyon.setHesapTurKodu(iMap.getString(tableName, i, "DV_TUTAR")) �ekmiyoruz, atm�yoruz
				muhEntegrasyon.setIslemNumara(iMap.getBigDecimal(tableName, i, "FIS_ISLEM_NUMARA"));
				muhEntegrasyon.setIslemSubeKod(iMap.getString(tableName, i, "FIS_ISLEM_SUBE"));
				muhEntegrasyon.setLcTutar(iMap.getBigDecimal(tableName, i, "LC_TUTAR"));
				muhEntegrasyon.setMusteriNumara(iMap.getBigDecimal(tableName, i, "SATIR_MUSTERI_HESAP_NUMARA"));
				session.saveOrUpdate(muhEntegrasyon);
			}
			session.flush();
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
		return oMap;
	}
	*/
	@GraymoundService("BNSPR_TRN1180_GET_AKTARIM_TARIH")
	public static GMMap getAktarimTarih(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("AKTARIM_TARIHI", DALUtil.callNoParameterFunction("{? = call pkg_trn1180.define_transfer_date }", Types.DATE));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN1180_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "MUHASEBE_BILGILERI";
			List<?> muhEntegrasyonPersistenceList = session.createCriteria(BinsWbMuhEntegrasyon.class).add(Restrictions.eq("id.aktarimNo", iMap.getBigDecimal("TRX_NO"))).list();
			oMap.put("AKTARIM_NO", iMap.getBigDecimal("TRX_NO"));
			int i;
			for (i = 0; i < muhEntegrasyonPersistenceList.size(); i++) {
				BinsWbMuhEntegrasyon muhEntegrasyon = (BinsWbMuhEntegrasyon)muhEntegrasyonPersistenceList.get(i);
				if(i == 0)
					oMap.put("AKTARIM_TARIHI", muhEntegrasyon.getAktarimTarih());
				oMap.put(tableName, i, "FIS_NO", muhEntegrasyon.getId().getFisNo());
				oMap.put(tableName, i, "SATIR_NO", muhEntegrasyon.getId().getSatirNumara());
				oMap.put(tableName, i, "B_A", muhEntegrasyon.getBA());
				oMap.put(tableName, i, "HESAP_SUBE", muhEntegrasyon.getHesapSubeKod());
				oMap.put(tableName, i, "HESAP_NO", muhEntegrasyon.getHesapNumara());
				oMap.put(tableName, i, "MUSTERI_HESAP", muhEntegrasyon.getMusteriHesapNo());
				oMap.put(tableName, i, "WB_DEFTERID", muhEntegrasyon.getWbDefterid());
				oMap.put(tableName, i, "WB_HESAP_SUBE", muhEntegrasyon.getWbSube());
				oMap.put(tableName, i, "WB_MUSTERI_NO", muhEntegrasyon.getWbMusteriNo());
				oMap.put(tableName, i, "WB_MUSTERI_EKNO", muhEntegrasyon.getWbMusteriEkno());
				oMap.put(tableName, i, "AKTARIM_TARIHI", muhEntegrasyon.getAktarimTarih());
				oMap.put(tableName, i, "DOVIZ_KOD", muhEntegrasyon.getDovizKod());
				oMap.put(tableName, i, "DV_TUTAR", muhEntegrasyon.getDvTutar());
				oMap.put(tableName, i, "FIS_ISLEM_NUMARA", muhEntegrasyon.getIslemNumara());
				oMap.put(tableName, i, "FIS_ISLEM_SUBE", muhEntegrasyon.getIslemSubeKod());
				oMap.put(tableName, i, "LC_TUTAR", muhEntegrasyon.getLcTutar());
				oMap.put(tableName, i, "SATIR_MUSTERI_HESAP_NUMARA", muhEntegrasyon.getMusteriNumara());
			}
			oMap.put("KAYIT_SAYISI", i);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_TRN1180_WINBANK_MUHASEBE")
	public static GMMap execWinbankMuhasebe(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection connSql = null;
		CallableStatement stmtSql = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
		    connSql = DALUtil.getWinbankConnection();
			stmtSql = connSql.prepareCall("{ call dbbanking.dbo.bins_up_muhasebe_to_winbank(?) }");
			stmtSql.setDate(1, new java.sql.Date((iMap.getDate("AKTARIM_TARIHI")).getTime()));
			stmtSql.execute();
			
			/*'2009-05-22 00:00:00'  */
			stmt = connSql.prepareStatement("select count(*) as sayi from bins_hareketmuhasebe where islemtarihi=? and islemreferansi is null ");
			iMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap).getDate("BANKA_TARIH"));
			stmt.setDate(1, new java.sql.Date(iMap.getDate("BANKA_TARIHI").getTime()));
			rSet = stmt.executeQuery();
			
			while(rSet.next()){
			//	System.out.println(rSet.getBigDecimal(1).doubleValue());
				if(rSet.getBigDecimal(1).doubleValue()>0.0)
				{
					iMap.put("HATA_NO", new BigDecimal("714"));
					GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMap);
				}
				else if (rSet.getBigDecimal(1).doubleValue() == 0.0)
				{
					iMap.put("MESSAGE_NO", new BigDecimal(711));
					oMap.put("MESSAGE", (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
				}
			}
			oMap.put("RESULT", "SUCCESS");
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmtSql);
			GMServerDatasource.close(connSql);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_1191_FILL_COMBOBOX_INITIAL_VALUE")
	public static GMMap fillComboBoxInitialValues(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			//iMap.put("ADD_EMPTY_KEY", "H");
			DALUtil.fillComboBox(oMap, "KANAL", true, "select t.KOD,t.ACIKLAMA from v_ml_gnl_kanal_grup_kod_pr t order by t.KOD  ");
			//DALUtil.fillComboBox(oMap, "DOVIZ_TURU", true, "select kod,aciklama from v_ml_gnl_doviz_kod_pr where gecerli = 'E' order by sira_no");
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
