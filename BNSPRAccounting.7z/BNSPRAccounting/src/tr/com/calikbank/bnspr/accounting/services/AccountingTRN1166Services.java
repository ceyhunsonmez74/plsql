package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;
import java.util.Map;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import org.hibernate.Session;

import tr.com.calikbank.bnspr.dao.GnlMasrafTahiadeTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class AccountingTRN1166Services {
	
	@GraymoundService("BNSPR_TRN1166_GET_MASRAF_KOMISYON_IADE_LIST")
	public static GMMap getMasrafKomisyonIadeList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call  PKG_RC1166.RC_T1166_MASRAF_KOMISYON_IADE(?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); //ref cursor
			if(iMap.getDate("BAS_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			else
				stmt.setDate(i++, null);
			
			if(iMap.getDate("SON_TARIH") != null)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("SON_TARIH").getTime()));
			else
				stmt.setDate(i++, null);
		
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIS_NO"));
			stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
			String tableName = "MASRAF_KOMISYON_IADE";
			int row = 0;
			while (rSet.next()) {
				int j = 1;
				oMap.put(tableName, row, "MASRAF_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_TX_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "AMIR_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "MUH_TARIH", rSet.getDate(j++));
				oMap.put(tableName, row, "ISLEM_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MUSTERI_UNVAN", rSet.getString(j++));
				oMap.put(tableName, row, "MAS_HESAP_NO", rSet.getString(j++));
				oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_NUMARA", rSet.getString(j++));
				oMap.put(tableName, row, "TOP_MASRAF_TUTAR", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "ISLEM_DOVIZ", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_ADI", rSet.getString(j++));
			
				row++;
			}

			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	/*@GraymoundService("BNSPR_TRN1166_GET_MASRAF_KOMISYON_IADE_LIST")
	public static GMMap getMasrafKomisyonIadeList(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = GMServerDatasource.getConnection("java:/GraymoundDS");

			StringBuilder query = new StringBuilder();
			
			query.append("select m.masraf_kodu,m.tx_no as islem_tx_no,i.amir_sube_kod,f.muh_tarih,i.islem_kod,m.musteri_no,m.mas_hesap_no,pkg_hesap.doviz_kodu(m.mas_hesap_no) doviz,i.fis_numara,");
			query.append("pkg_kur.YUVARLA(i.doviz_kod,sum(m.alinan)) as top_masraf_tutar, ");
			query.append("i.tutar, i.doviz_kod,v.ACIKLAMA ");
			query.append("from muh_islem i,gnl_masraf m ,muh_fis  f,v_ml_muh_islem_tanim_pr v ");
			query.append("where f.muh_tarih between NVL(?,f.muh_tarih) and NVL(?,f.muh_tarih) ");
			query.append("and f.tur = 'G' ");
			query.append("and i.numara = f.islem_numara ");
			query.append("and m.tx_no = i.numara ");
			query.append("and m.musteri_no = NVL(?,m.musteri_no) ");
			query.append("and m.mas_hesap_no = NVL(?,m.mas_hesap_no) ");
			query.append("and i.fis_numara = NVL(?,i.fis_numara) ");
			query.append("and (m.masraf_hesap_tur_kod = 'VS' or (m.masraf_hesap_tur_kod is null and m.mas_hesap_no not like '01%')) ");
			query.append("and m.iade_f is null ");
			query.append("and pkg_kur.YUVARLA(i.doviz_kod,pkg_masraf_yeni.toplam_masraf(m.tx_no)) > 0 ");
			query.append(" and v.KOD = i.islem_kod ");
			query.append("group by m.masraf_kodu,m.tx_no,i.amir_sube_kod,f.muh_tarih,i.islem_kod,m.musteri_no,m.mas_hesap_no,pkg_hesap.doviz_kodu(m.mas_hesap_no),i.fis_numara,i.tutar,i.doviz_kod,v.aciklama ");
			query.append("order by tx_no");
		 
			stmt = conn.prepareStatement(query.toString());

			int i = 1;
			if(iMap.get("BAS_TARIH")!=null) stmt.setDate(i++, new Date(iMap.getDate("BAS_TARIH").getTime()));
			else stmt.setDate(i++, null);
			if(iMap.get("SON_TARIH")!=null) stmt.setDate(i++, new Date(iMap.getDate("SON_TARIH").getTime()));
			else stmt.setDate(i++, null);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("FIS_NO"));

			rSet = stmt.executeQuery();

			GMMap oMap = new GMMap();
			String tableName = "MASRAF_KOMISYON_IADE";
			int row = 0;
			while (rSet.next()) {
				int j = 1;
				oMap.put(tableName, row, "MASRAF_KODU", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_TX_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "AMIR_SUBE_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "MUH_TARIH", rSet.getDate(j++));
				oMap.put(tableName, row, "ISLEM_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "MAS_HESAP_NO", rSet.getString(j++));
				oMap.put(tableName, row, "DOVIZ_KOD", rSet.getString(j++));
				oMap.put(tableName, row, "FIS_NUMARA", rSet.getString(j++));
				oMap.put(tableName, row, "TOP_MASRAF_TUTAR", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_TUTAR", rSet.getBigDecimal(j++));
				oMap.put(tableName, row, "ISLEM_DOVIZ", rSet.getString(j++));
				oMap.put(tableName, row, "ISLEM_ADI", rSet.getString(j++));
			
				row++;
			}

			return oMap;
		} catch (ParseException e) {
			throw new GMRuntimeException(0,e);
		} catch (SQLException e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}*/
	@GraymoundService("BNSPR_TRN1166_GET_TRX_NO")
	public static GMMap getTrxNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_trn1166.Get_iade_txNo(?,?,?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MAS_ISLEM_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("FIS_NO"));
			stmt.setString(4, iMap.getString("MASRAF_KODU"));

			stmt.execute();

			oMap.put("TRX_NO", stmt.getBigDecimal(1));

			return oMap;
		} catch (Exception e) {
			 throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}
	@GraymoundService("BNSPR_TRN1166_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();

			GnlMasrafTahiadeTx gnlMasrafTahiadeTx = (GnlMasrafTahiadeTx) session.get(GnlMasrafTahiadeTx.class, iMap.getBigDecimal("TRX_NO"));
			oMap.put("TRX_NO", gnlMasrafTahiadeTx.getTxNo());
			oMap.put("MASRAF_KODU", gnlMasrafTahiadeTx.getMasrafKodu());
			oMap.put("MASRAF_TAH_TARIHI", gnlMasrafTahiadeTx.getMasrafTahTarihi());
			oMap.put("MASRAF_TAH_ISLEM_NO", gnlMasrafTahiadeTx.getMasrafTahIslemNo());
			oMap.put("MASRAF_TAH_ISLEM_KOD", gnlMasrafTahiadeTx.getMasrafTahIslemKod());
			oMap.put("MASRAF_FIS_NUMARA", gnlMasrafTahiadeTx.getMasrafFisNumara());
			oMap.put("MASRAF_HESAP_NUMARA", gnlMasrafTahiadeTx.getMasrafHesapNumara());
			oMap.put("MASRAF_ALINAN", gnlMasrafTahiadeTx.getMasrafAlinan());
			oMap.put("MASRAF_BSMV", gnlMasrafTahiadeTx.getMasrafBsmv());
			oMap.put("BSMV_TAH_DK", gnlMasrafTahiadeTx.getBsmvTahDk());
			oMap.put("ACIKLAMA", gnlMasrafTahiadeTx.getAciklama());
			oMap.put("IADE_NEDENI", gnlMasrafTahiadeTx.getIadeNedeni());
			oMap.put("MASRAF_DOVIZ_KODU", gnlMasrafTahiadeTx.getMasrafDovizKodu());
			oMap.put("MASRAF_TAHSIL_TUTAR", gnlMasrafTahiadeTx.getMasrafTahsilTutar());
			oMap.put("MASRAF_TAHSIL_BSMV", gnlMasrafTahiadeTx.getMasrafTahsilBsmv());
			oMap.put("MASRAF_HESAP_DVZ", gnlMasrafTahiadeTx.getMasrafHesapDvz());
			oMap.put("MASRAF_MUSTERI_NO", gnlMasrafTahiadeTx.getMasrafMusteriNo());
			
			iMap.put("MUSTERI_NO", gnlMasrafTahiadeTx.getMasrafMusteriNo());
			iMap.put("ISLEM_KOD", gnlMasrafTahiadeTx.getMasrafTahIslemKod());
			
			oMap.put("MASRAF_MUSTERI_ADI", GMServiceExecuter.execute("BNSPR_COMMON_GET_UNVAN", iMap).get("UNVAN"));
			oMap.put("MASRAF_ISLEM_ADI", GMServiceExecuter.execute("BNSPR_COMMON_GET_ISLEM_ADI", iMap).get("ISLEM_ADI"));

			return oMap;
		} catch (Exception e) {
			throw  ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN1166_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlMasrafTahiadeTx gnlMasrafTahiadeTx = (GnlMasrafTahiadeTx) session.get(GnlMasrafTahiadeTx.class, iMap.getBigDecimal("TRX_NO"));

			gnlMasrafTahiadeTx.setIadeNedeni(iMap.getString("IADE_NEDENI"));
			gnlMasrafTahiadeTx.setAciklama(iMap.getString("ACIKLAMA"));
			
			session.update(gnlMasrafTahiadeTx);
			session.flush();

			iMap.put("TRX_NAME", "1166");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
