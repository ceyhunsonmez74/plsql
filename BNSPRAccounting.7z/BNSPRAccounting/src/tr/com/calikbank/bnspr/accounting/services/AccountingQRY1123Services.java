package tr.com.calikbank.bnspr.accounting.services;

import java.sql.CallableStatement;
import java.sql.Connection;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class AccountingQRY1123Services {

	@GraymoundService("BNSPR_QRY1123_GET_RESULT")
	public static GMMap getMuhFisRecord(GMMap iMap) throws ParseException {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_RC1123.RC_QRY1123(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			if(iMap.getDate("TARIH") == null || iMap.getString("TARIH").isEmpty())
				stmt.setDate(i++, null);
			else
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "RESULT";
			GMMap oMap = DALUtil.rSetResults(rSet, tableName);
			
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
