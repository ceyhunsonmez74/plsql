package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import javax.swing.tree.DefaultMutableTreeNode;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class AccountingQRY1192Services {
	
	@GraymoundService("BNSPR_QRY1192_GET_DATA")
	public static GMMap getTableData(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection 			conn	= null;
		CallableStatement 	stmt	= null;
		ResultSet 			rSet	= null;
		CallableStatement 	stmt2	= null;
		ResultSet 			rSet2	= null;
		try{
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC1192.rc1192_izleme(?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("SUBE"));
			stmt.setString(i++, iMap.getString("ISKOLU"));
			stmt.setString(i++, iMap.getString("PORTFOY"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			stmt.setDate(i++, iMap.getDate("BASLANGIC_TARIHI")!= null ? new java.sql.Date(iMap.getDate("BASLANGIC_TARIHI").getTime()) : null);
			stmt.setDate(i++, iMap.getDate("BITIS_TARIHI")!= null ? new java.sql.Date(iMap.getDate("BITIS_TARIHI").getTime()) : null);
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
		
			String controlSubeKodu = null;
			String controlScModul = null;
			String controlScUrunGrubu = null;
			
			DefaultMutableTreeNode lvl1 = null;
			DefaultMutableTreeNode lvl2 = null;
			DefaultMutableTreeNode lvl3 = null;
			
			BigDecimal lvl3TLBakiye = new BigDecimal(0);
			
			BigDecimal lvl1UrunNetKar = new BigDecimal(0);
			BigDecimal lvl2UrunNetKar = new BigDecimal(0);
			BigDecimal lvl3UrunNetKar = new BigDecimal(0);
			BigDecimal totalUrunNetKar = new BigDecimal(0);
			
			DefaultMutableTreeNode root = createNamedNode("�ube / Mod�l / �r�n Grubu");
			
			boolean subeChanged = false;
			boolean modulChanged = false;
			
			while(rSet.next()){
			    subeChanged = false;
	            modulChanged = false;
	            
				String currentSubeKodu = rSet.getString("SUBE_KODU");
				String currentScModul = rSet.getString("SC_MODUL");
				String currentScUrunGrubu = rSet.getString("SC_URUN_GRUBU");
				String currentScModulKey = rSet.getString("SC_MODUL_KEY");
				
				if(controlSubeKodu != null){
					
					if(!controlSubeKodu.equals(currentSubeKodu)){
						
						lvl1UrunNetKar = lvl1UrunNetKar.add(lvl2UrunNetKar);
						modifyNodeForUrunNetKarSums(lvl1, lvl1UrunNetKar);
						
						controlSubeKodu = currentSubeKodu;
						lvl1 = createNamedNode(currentSubeKodu);
						subeChanged = true;
						
						root.add(lvl1);
						
						totalUrunNetKar = totalUrunNetKar.add(lvl1UrunNetKar);
						lvl1UrunNetKar = new BigDecimal(0);
					}
					
				}else{
					controlSubeKodu = currentSubeKodu;
					lvl1 = createNamedNode(currentSubeKodu);
					root.add(lvl1);
				}

				if(controlScModul != null){

					if(!controlScModul.equals(currentScModul) || subeChanged){
						
						if(!subeChanged){
							lvl1UrunNetKar = lvl1UrunNetKar.add(lvl2UrunNetKar);
						}
						
						controlScModul = currentScModul;
						lvl2 = createNamedNode(currentScModul);
						modulChanged = true;
						
						lvl1.add(lvl2);
						
						lvl2UrunNetKar = new BigDecimal(0);
					}

				}else{
					controlScModul = currentScModul;
					lvl2 = createNamedNode(currentScModul);
					lvl1.add(lvl2);
				}

				if(controlScUrunGrubu != null){
					
					if(!controlScUrunGrubu.equals(currentScUrunGrubu) || modulChanged){
						
						controlScUrunGrubu = currentScUrunGrubu;
						lvl3 = createNamedNode(currentScUrunGrubu);
						
						lvl2.add(lvl3);

						lvl3TLBakiye = new BigDecimal(0);
						lvl3UrunNetKar = new BigDecimal(0);
					}

				}else{
					controlScUrunGrubu = currentScUrunGrubu;
					lvl3 = createNamedNode(currentScUrunGrubu);
					lvl2.add(lvl3);
				}
				
				try{
					
					stmt2 = conn.prepareCall("{? = call PKG_RC1192.rc1192_izleme_detay(?,?,?,?,?,?,?,?,?,?)}");
					int k = 1;
					stmt2.registerOutParameter(k++, -10);
					stmt2.setString(k++, currentSubeKodu);
					stmt2.setString(k++, iMap.getString("ISKOLU"));
					stmt2.setString(k++, iMap.getString("PORTFOY"));
					stmt2.setBigDecimal(k++, iMap.getBigDecimal("MUSTERI_NO"));
					stmt2.setBigDecimal(k++, iMap.getBigDecimal("HESAP_NO"));
					stmt2.setString(k++, iMap.getString("DURUM_KODU"));
					stmt2.setDate(k++, iMap.getDate("BASLANGIC_TARIHI")!= null ? new java.sql.Date(iMap.getDate("BASLANGIC_TARIHI").getTime()) : null);
					stmt2.setDate(k++, iMap.getDate("BITIS_TARIHI")!= null ? new java.sql.Date(iMap.getDate("BITIS_TARIHI").getTime()) : null);
					stmt2.setString(k++, currentScModulKey);
					stmt2.setString(k++, currentScUrunGrubu);
					stmt2.execute();
					
					rSet2 = (ResultSet)stmt2.getObject(1);
					
					while(rSet2.next()){
						lvl3UrunNetKar = lvl3UrunNetKar.add(rSet2.getBigDecimal("URUN_NET_KAR") != null ? rSet2.getBigDecimal("URUN_NET_KAR") : BigDecimal.ZERO);
						lvl3TLBakiye = lvl3TLBakiye.add(rSet2.getBigDecimal("TL_BAKIYE") != null ? rSet2.getBigDecimal("TL_BAKIYE") : BigDecimal.ZERO);
						lvl3.add(createUnnamedNode(rSet2));
					}
					
					modifyNodeForTLBakiyeSums(lvl3, lvl3TLBakiye);
					modifyNodeForUrunNetKarSums(lvl3, lvl3UrunNetKar);
					
					lvl2UrunNetKar = lvl2UrunNetKar.add(lvl3UrunNetKar);
					modifyNodeForUrunNetKarSums(lvl2, lvl2UrunNetKar);
					
				}finally{
					GMServerDatasource.close(rSet2);
					GMServerDatasource.close(stmt2);
					GMServerDatasource.close(conn);
				}
				
			}
			
			if(lvl1 != null && lvl2 != null){
				lvl1UrunNetKar = lvl1UrunNetKar.add(lvl2UrunNetKar);
				modifyNodeForUrunNetKarSums(lvl1, lvl1UrunNetKar);
				totalUrunNetKar = totalUrunNetKar.add(lvl1UrunNetKar);
				modifyNodeForUrunNetKarSums(root, totalUrunNetKar);
			}
			
			oMap.put("DATA_TABLE", root);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	private static DefaultMutableTreeNode createNamedNode(String nodeName){
		
		DefaultMutableTreeNode node = new DefaultMutableTreeNode();
		HashMap<String, Object> nodeData = new HashMap<String, Object>();
		
		nodeData.put("NAME", nodeName);
		node.setUserObject(nodeData);
		return node;
	}
	
	private static DefaultMutableTreeNode createUnnamedNode(ResultSet rSet) throws SQLException{
		
		DefaultMutableTreeNode node = new DefaultMutableTreeNode();
		HashMap<String, Object> nodeData = new HashMap<String, Object>();
		
//		nodeData.put("SC_MODUL",rSet.getString("SC_MODUL"));
//		nodeData.put("SC_URUN_GRUBU",rSet.getString("SC_URUN_GRUBU"));
		nodeData.put("SUBE",rSet.getString("SUBE_KODU"));
		nodeData.put("MUSTERI_NO",rSet.getBigDecimal("MUSTERI_NO"));
		nodeData.put("ISIM_UNVAN",rSet.getString("UNVANI"));
		nodeData.put("MODUL",rSet.getString("MODUL_TUR_KOD"));
		nodeData.put("URUN_TURU",rSet.getString("URUN_TUR_KOD"));
		nodeData.put("URUN_SINIFI",rSet.getString("URUN_SINIF_KOD"));
		nodeData.put("PARA_BIRIMI",rSet.getString("DOVIZ_KODU"));
		nodeData.put("HESAP_NO",rSet.getString("HESAP_NO"));
		nodeData.put("ISLEM_SUBESI",rSet.getString("ISLEM_SUBE"));
		nodeData.put("DVZ_ORTALAMA",rSet.getBigDecimal("DVZ_ORTALAMA"));
		nodeData.put("TL_ORTALAMA",rSet.getBigDecimal("TL_ORTALAMA"));
		nodeData.put("DVZ_BAKIYE",rSet.getBigDecimal("DVZ_BAKIYE"));
		nodeData.put("TL_BAKIYE",rSet.getBigDecimal("TL_BAKIYE"));
		nodeData.put("SON_FAIZ_ORANI",rSet.getBigDecimal("SON_FAIZ_ORANI"));
		nodeData.put("ORTALAMA_FAIZ_ORANI",rSet.getBigDecimal("ORTALAMA_FAIZ"));
		nodeData.put("SCH_FAIZ_ORANI",rSet.getBigDecimal("SCH_FAIZ_ORANI"));
		nodeData.put("ALINAN_FAIZ",rSet.getBigDecimal("ALINAN_FAIZ"));
		nodeData.put("VERILEN_FAIZ",rSet.getBigDecimal("VERILEN_FAIZ"));
		nodeData.put("ALINAN_SCF",rSet.getBigDecimal("ALINAN_SCF"));
		nodeData.put("VERILEN_SCF",rSet.getBigDecimal("VERILEN_SCF"));
		nodeData.put("KOMISYON",rSet.getBigDecimal("KOMISYON"));
		nodeData.put("DIGER_FAIZ_DISI_GELIRLER",rSet.getString("DIGER_FAIZ_DISI_GELIRLER"));
		nodeData.put("DIG_FAIZDISI_GIDER",rSet.getString("DIG_FAIZDISI_GIDER"));
		nodeData.put("URUN_NET_GELIR",rSet.getString("URUN_NET_GELIR"));
		nodeData.put("ACILIS_MALIYETI",rSet.getString("ACILIS_MALIYET"));
		nodeData.put("ISLEM_MALIYETI",rSet.getString("ISLEM_MALIYET"));
		nodeData.put("BULUNDURMA_MALIYETI",rSet.getString("BULUNDURMA_MALIYET"));
		nodeData.put("URUN_NET_KAR",rSet.getString("URUN_NET_KAR"));
		nodeData.put("ALINAN_VERILEN_PRIM",rSet.getString("AL_VER_PRIM"));
		nodeData.put("PRIMLI_KAR",rSet.getString("PRIMLI_KAR"));
		nodeData.put("ACILIS_TARIHI",rSet.getDate("ACILIS_TARIHI"));
		nodeData.put("VADE_TARIHI",rSet.getDate("VADE_TARIHI"));
		nodeData.put("PORTFOY",rSet.getString("PORTFOY_KOD"));
		
		node.setUserObject(nodeData);
		return node;
	}
	
	@GraymoundService("BNSPR_QRY1192_INITIALIZE")
	public static GMMap initialize(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			
			String listName = "DURUM_LIST";
			GuimlUtil.wrapMyCombo(oMap, listName, "T", "T�m�");
			GuimlUtil.wrapMyCombo(oMap, listName, "A", "A��k");
			GuimlUtil.wrapMyCombo(oMap, listName, "K", "Kapal�");
			
			listName = "ZAMAN_LIST";
			GuimlUtil.wrapMyCombo(oMap, listName, "B", "Ba�lang��");
			GuimlUtil.wrapMyCombo(oMap, listName, "A", "Ayl�k");
			GuimlUtil.wrapMyCombo(oMap, listName, "Y", "Y�ll�k");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@SuppressWarnings("unchecked")
	private static void modifyNodeForTLBakiyeSums(DefaultMutableTreeNode node, BigDecimal lvlSums){
		HashMap<String, Object> nodeData = (HashMap<String, Object>) node.getUserObject();
		nodeData.put("TL_BAKIYE", lvlSums);
	}
	
	@SuppressWarnings("unchecked")
	private static void modifyNodeForUrunNetKarSums(DefaultMutableTreeNode node, BigDecimal lvlSums){
		HashMap<String, Object> nodeData = (HashMap<String, Object>) node.getUserObject();
		nodeData.put("URUN_NET_KAR", lvlSums);
	}
	
	@GraymoundService("BNSPR_QRY1192_GET_DATES")
	public static GMMap getDates(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(new Date());
			
			if("Y".equals(iMap.getString("ZAMAN_KRITERI"))){
				
				cal.set(Calendar.DAY_OF_YEAR, 1);
				oMap.put("BASLANGIC_TARIHI", cal.getTime());
				cal.add(Calendar.YEAR, 1);
				cal.add(Calendar.DAY_OF_YEAR, -1);
				oMap.put("BITIS_TARIHI", cal.getTime());
				
			}else if("A".equals(iMap.getString("ZAMAN_KRITERI"))){
				
				cal.set(Calendar.DAY_OF_MONTH, 1);
				oMap.put("BASLANGIC_TARIHI", cal.getTime());
				cal.add(Calendar.MONTH, 1);
				cal.add(Calendar.DAY_OF_MONTH, -1);
				oMap.put("BITIS_TARIHI", cal.getTime());
				
			}else if("B".equals(iMap.getString("ZAMAN_KRITERI"))){
				oMap.put("BITIS_TARIHI", cal.getTime());
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
