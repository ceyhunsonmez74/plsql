package tr.com.calikbank.bnspr.accounting.services;

import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class AccountingQRY1195Services {

	@GraymoundService("BNSPR_QRY1195_GET_RECORDS")
	public static GMMap getRecords(GMMap iMap) throws ParseException {
		GMMap oMap = new GMMap();

		try {
			String func = "{? = call PKG_RC1195.rc1195_liste()}";
			String tableName = "TBL";
			oMap = DALUtil.callOracleRefCursorFunction(func, tableName);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_QRY1195_MAKE_PAYMENT")
	public static GMMap makePayment(GMMap iMap) throws ParseException {
		GMMap oMap = new GMMap();
		GMMap oMapRow = new GMMap();
		int i = 0;
		try {
			oMapRow = iMap.getMap("TBL_ROW");
			String func = "{? = call PKG_RC1195.Fatura_Odeme_Cikis(?,?,?,?,?)}";
			Object[] inputValues = new Object[10];

			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = oMapRow.getBigDecimal("TX_NO");

			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = oMapRow.getBigDecimal("MUH_TUTAR");

			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = oMapRow.getString("FIRMA_UNVANI");

			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = oMapRow.getString("IBAN");

			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = oMapRow.getString("BANKA_ACIKLAMA");

			oMap.put("SONUC", DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_QRY1195_GET_ROW_COUNT")
	public static GMMap getRowCount(GMMap iMap) throws ParseException {
		GMMap oMap = new GMMap();
		String tableName = "TBL";
		try {
			return oMap.put("ROW_COUNT", iMap.getSize(tableName));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

}
