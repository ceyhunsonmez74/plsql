package tr.com.calikbank.bnspr.accounting.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.ConstraintViolationException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlKarsiMusMaskomTnmPrTx;
import tr.com.calikbank.bnspr.dao.GnlKarsiMusMaskomTnmPrTxId;
import tr.com.calikbank.bnspr.dao.GnlMasrafKomKriterTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class AccountingTRN1165Services {
	@GraymoundService("BNSPR_TRN1165_GET_TRX_NO")
	public static GMMap getTrxNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn
					.prepareCall("{? = call PKG_TRN1165.get_parameters(?,?,?,?,?)}");
			
			stmt.registerOutParameter(1, Types.DECIMAL);
			
			stmt.setString(2, iMap.getString("MUSTERI_NO"));
			stmt.setString(3, iMap.getString("HESAP_NO"));
			stmt.setString(4, iMap.getString("KANAL_Q"));
			stmt.setString(5, iMap.getString("MASKOM_TURU_Q"));
			stmt.setString(6, iMap.getString("STATU_Q"));
						
			stmt.execute();

			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN1165_GET_KARSI_MUSTERI_TNM_PR_LIST")
	public static GMMap getKarsiMusTnmPrList(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = session.createCriteria(GnlKarsiMusMaskomTnmPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "KARSI_MUS_MASKOM_TNM_PR";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlKarsiMusMaskomTnmPrTx gnlKarsiMusMaskomTnmPrTx = (GnlKarsiMusMaskomTnmPrTx)iterator.next();

				if (gnlKarsiMusMaskomTnmPrTx.getDrm().equals("I"))
					oMap.put(tableName, row,"DRM","1");
				else
					oMap.put(tableName, row,"DRM","0");
				
				oMap.put(tableName, row,"END_DATE",gnlKarsiMusMaskomTnmPrTx.getEndDate());
				oMap.put(tableName, row,"KANAL_KOD",gnlKarsiMusMaskomTnmPrTx.getKanalKod());
				oMap.put(tableName, row,"MUSTERI_NO",gnlKarsiMusMaskomTnmPrTx.getMusteriNo());
				oMap.put(tableName, row,"UNVAN",LovHelper.diLov(gnlKarsiMusMaskomTnmPrTx.getMusteriNo(), "1165/LOV_MUSTERI_BILGI", "ID_DESC"));
				oMap.put(tableName, row,"HESAP_NO",gnlKarsiMusMaskomTnmPrTx.getHesapNo());
				oMap.put(tableName, row,"M_K_TURU",gnlKarsiMusMaskomTnmPrTx.getMaskomTuru());
				oMap.put(tableName, row,"MASKOM_ORAN",gnlKarsiMusMaskomTnmPrTx.getMaskomOran());
				oMap.put(tableName, row,"MASKOM_TUTAR",gnlKarsiMusMaskomTnmPrTx.getMaskomTutar());
				oMap.put(tableName, row,"MUSTERI_MASKOM_ID",gnlKarsiMusMaskomTnmPrTx.getId().getMusteriMaskomId());
				oMap.put(tableName, row, "START_DATE",gnlKarsiMusMaskomTnmPrTx.getStartDate());
				oMap.put(tableName, row,"DOVIZ_KODU",LovHelper.diLov(gnlKarsiMusMaskomTnmPrTx.getHesapNo(),gnlKarsiMusMaskomTnmPrTx.getMusteriNo(), "1165/LOV_HESAP", "DOVIZ_KODU"));
				
				oMap.put(tableName, row,"ESKI_KAYIT" ,"ESKI");
				row++;
			}
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN1165_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "KARSI_MUS_MASKOM_TNM_PR";
			List<?> list1 = (List<?>)iMap.get("KARSI_MUS_MASKOM_TNM_PR");
			for (int i = 0; i < list1.size(); i++) {
				GnlKarsiMusMaskomTnmPrTxId gnlKarsiMusMaskomTnmPrTxId = new GnlKarsiMusMaskomTnmPrTxId();
				gnlKarsiMusMaskomTnmPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				gnlKarsiMusMaskomTnmPrTxId.setMusteriMaskomId(iMap.getBigDecimal(tableName, i , "MUSTERI_MASKOM_ID"));
				
				GnlKarsiMusMaskomTnmPrTx gnlKarsiMusMaskomTnmPrTx = (GnlKarsiMusMaskomTnmPrTx)session.get(GnlKarsiMusMaskomTnmPrTx.class, gnlKarsiMusMaskomTnmPrTxId);
				
				if(gnlKarsiMusMaskomTnmPrTx == null)gnlKarsiMusMaskomTnmPrTx = new GnlKarsiMusMaskomTnmPrTx();
				
				gnlKarsiMusMaskomTnmPrTx.setId(gnlKarsiMusMaskomTnmPrTxId);
				if (iMap.getString(tableName,i,"DRM").equals("1")) gnlKarsiMusMaskomTnmPrTx.setDrm("I");
				else gnlKarsiMusMaskomTnmPrTx.setDrm("A");
				gnlKarsiMusMaskomTnmPrTx.setEndDate(iMap.getDate(tableName, i, "END_DATE"));
				gnlKarsiMusMaskomTnmPrTx.setKanalKod(iMap.getString(tableName, i, "KANAL_KOD"));
				gnlKarsiMusMaskomTnmPrTx.setHesapNo(iMap.getBigDecimal(tableName, i, "HESAP_NO"));
				gnlKarsiMusMaskomTnmPrTx.setMaskomOran(iMap.getBigDecimal(tableName, i, "MASKOM_ORAN"));
				gnlKarsiMusMaskomTnmPrTx.setMaskomTutar(iMap.getBigDecimal(tableName, i, "MASKOM_TUTAR"));
				gnlKarsiMusMaskomTnmPrTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				gnlKarsiMusMaskomTnmPrTx.setStartDate(iMap.getDate(tableName, i, "START_DATE"));
				gnlKarsiMusMaskomTnmPrTx.setMaskomTuru(iMap.getString(tableName, i,"M_K_TURU"));
				
				session.saveOrUpdate(gnlKarsiMusMaskomTnmPrTx);
			}
			session.flush();
			
			GnlMasrafKomKriterTx gnlMasrafKomKriterTx = new GnlMasrafKomKriterTx();
			
			gnlMasrafKomKriterTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			gnlMasrafKomKriterTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			gnlMasrafKomKriterTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			gnlMasrafKomKriterTx.setDrm(iMap.getString("STATU"));
			gnlMasrafKomKriterTx.setKanalKod(iMap.getString("KANAL_KOD"));
			gnlMasrafKomKriterTx.setMaskomKod(iMap.getString("MASKOM_TURU"));
			
			session.save(gnlMasrafKomKriterTx);
			session.flush();
			
			iMap.put("TRX_NAME", "1165");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (ConstraintViolationException e) {
			GMMap myMap = new GMMap();
			myMap.put("MESSAGE_NO", new BigDecimal(716));
			return AccountingChargesServices.throwGMBusssinessException((String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE",myMap).get("ERROR_MESSAGE"));
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN1165_GET_KARSI_MUS_MASKOM_TNM_PR_INFO")
	public static GMMap getKarsiMusMakomTnmPrInfo(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> list = session.createCriteria(GnlKarsiMusMaskomTnmPrTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "MUSTERI_MASKOM_TANIM_PR";
			int row = 0;
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				GnlKarsiMusMaskomTnmPrTx gnlKarsiMusMaskomTnmPrTx = (GnlKarsiMusMaskomTnmPrTx) iterator.next();
				
				if (gnlKarsiMusMaskomTnmPrTx.getDrm().equals("I"))
					oMap.put(tableName, row,"DRM","1");
				else
					oMap.put(tableName, row,"DRM","0");
				oMap.put(tableName, row, "END_DATE",gnlKarsiMusMaskomTnmPrTx.getEndDate());
				oMap.put(tableName, row, "KANAL_KOD",gnlKarsiMusMaskomTnmPrTx.getKanalKod());
				oMap.put(tableName, row, "MUSTERI_NO",gnlKarsiMusMaskomTnmPrTx.getMusteriNo());
				oMap.put(tableName, row, "UNVAN",LovHelper.diLov(gnlKarsiMusMaskomTnmPrTx.getMusteriNo(), "1165/LOV_MUSTERI_BILGI", "ID_DESC"));
				oMap.put(tableName, row, "HESAP_NO",gnlKarsiMusMaskomTnmPrTx.getHesapNo());
				oMap.put(tableName, row, "M_K_TURU",gnlKarsiMusMaskomTnmPrTx.getMaskomTuru());
				oMap.put(tableName, row, "MASKOM_ORAN",gnlKarsiMusMaskomTnmPrTx.getMaskomOran());
				oMap.put(tableName, row, "MASKOM_TUTAR",gnlKarsiMusMaskomTnmPrTx.getMaskomTutar());
				oMap.put(tableName, row, "MUSTERI_MASKOM_ID",gnlKarsiMusMaskomTnmPrTx.getId().getMusteriMaskomId());
				oMap.put(tableName, row, "START_DATE",gnlKarsiMusMaskomTnmPrTx.getStartDate());
				oMap.put(tableName, row,"DOVIZ_KODU",LovHelper.diLov(gnlKarsiMusMaskomTnmPrTx.getHesapNo(),gnlKarsiMusMaskomTnmPrTx.getMusteriNo(), "1165/LOV_HESAP", "DOVIZ_KODU"));
				
				oMap.put(tableName, row,"ESKI_KAYIT" ,"ESKI");
				row++;
			}
			GnlMasrafKomKriterTx gnlMasrafKomKriterTx = (GnlMasrafKomKriterTx)session.get(GnlMasrafKomKriterTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO", gnlMasrafKomKriterTx.getTxNo());
			oMap.put("MUSTERI_NO", gnlMasrafKomKriterTx.getMusteriNo());
			oMap.put("DI_MUSTERI_ADI", LovHelper.diLov(gnlMasrafKomKriterTx.getMusteriNo(), "1165/LOV_MUSTERI_BILGI", "ID_DESC"));
			oMap.put("HESAP_NO", gnlMasrafKomKriterTx.getHesapNo());
			oMap.put("KANAL_KOD", gnlMasrafKomKriterTx.getKanalKod());
			oMap.put("DI_KANAL_KOD", LovHelper.diLov(gnlMasrafKomKriterTx.getKanalKod(), "1165/LOV_KANAL", "ACIKLAMA"));
			oMap.put("STATU", gnlMasrafKomKriterTx.getDrm());
			oMap.put("MASKOM_TURU", gnlMasrafKomKriterTx.getMaskomKod());
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
