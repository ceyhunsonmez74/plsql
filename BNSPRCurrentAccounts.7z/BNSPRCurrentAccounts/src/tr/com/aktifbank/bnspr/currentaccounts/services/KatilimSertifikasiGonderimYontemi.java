package tr.com.aktifbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.SigortaTanimGonderim;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class KatilimSertifikasiGonderimYontemi {

	private static Logger logger = Logger.getLogger(KatilimSertifikasiGonderimYontemi.class);

	/**
	 * Description : TBA
	 * 
	 * @param iMap
	 *            GMMap
	 *            {...}
	 * @return GMMap
	 *         {...}
	 */
	@GraymoundService("BNSPR_SIGORTA_SIRKET_GONDERIM_SEKLI_SAVE")
	public static GMMap insertSigortaTanimGonderim(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			SigortaTanimGonderim sigortaTanimGonderim;

			String tableName = "SIGORTA_TANIM_GONDERIM";
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				sigortaTanimGonderim = (SigortaTanimGonderim) session.get(SigortaTanimGonderim.class, iMap.getString(tableName, i, "SIGORTA_FIRMA_KODU"));
				if (sigortaTanimGonderim == null) {

					sigortaTanimGonderim = new SigortaTanimGonderim();

					sigortaTanimGonderim.setSigortaFirmaKodu(iMap.getString(tableName, i, "SIGORTA_FIRMA_KODU"));
					sigortaTanimGonderim.setGonderimSekli(iMap.getString(tableName, i, "GONDERIM_SEKLI"));

					session.saveOrUpdate(sigortaTanimGonderim);
					session.flush();
					iMap.put("MESSAGE_NO", new BigDecimal(711));
					oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));
					oMap.put("RESPONSE", 2);
				}
				else {
					if ((sigortaTanimGonderim.getSigortaFirmaKodu() == iMap.getString(tableName, i, "SIGORTA_FIRMA_KODU") && sigortaTanimGonderim.getGonderimSekli() != (iMap.getString(tableName, i, "GONDERIM_SEKLI"))) 
							|| (sigortaTanimGonderim.getSigortaFirmaKodu() == iMap.getString(tableName, i, "SIGORTA_FIRMA_KODU") && sigortaTanimGonderim.getGonderimSekli() == null) 
							) {

						sigortaTanimGonderim.setSigortaFirmaKodu(iMap.getString(tableName, i, "SIGORTA_FIRMA_KODU"));
						sigortaTanimGonderim.setGonderimSekli(iMap.getString(tableName, i, "GONDERIM_SEKLI"));

						session.update(sigortaTanimGonderim);
						session.flush();
						iMap.put("MESSAGE_NO", new BigDecimal(711));
						oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));
						oMap.put("RESPONSE", 2);
					}
					else {

						iMap.put("MESSAGE_NO", new BigDecimal(5347));
						oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap).get("ERROR_MESSAGE"));
						oMap.put("RESPONSE", 0);
					}
				}
			}
	}
		catch (Exception e) {
			logger.error("BNSPR_SIGORTA_SIRKET_GONDERIM_SEKLI_SAVE err:" + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_SIGORTA_TANIM_GONDERIM")
	public static GMMap getSigortaTanimGonderimList(GMMap iMap) {
		GMMap oMap = new GMMap();
		String procStr = "{ call PKG_PTT_KREDI.getSigortaTanimGonderim(?)}";
		int i = 0;
		Object[] inputValues = new Object[0];
		Object[] outputValues = new Object[2];

		try {

			i = 0;

			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "RC_LIST";

			GMMap resultMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

			oMap.putAll(resultMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;

	}

	@GraymoundService("BNSPR_SIGORTA_TANIM_GONDERIM_DELETE")
	public static GMMap deleteSigortaTanimGonderim(GMMap iMap) {
		GMMap oMap = new GMMap();
		String procStr = "{ call PKG_PTT_KREDI.deleteSigortaTanimGonderim(?,?)}";
		int i = 0;
		Object[] inputValues = new Object[2];
		Object[] outputValues = new Object[2];

		try {
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SIGORTA_FIRMA_KODU");

			i = 0;

			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "RC_LIST";

			GMMap resultMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

			oMap.putAll(resultMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;

	}
}