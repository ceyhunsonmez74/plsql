package tr.com.aktifbank.bnspr.currentaccounts.transferbatch;

import java.util.ArrayList;
import java.util.StringTokenizer;

import tr.com.aktifbank.bnspr.dao.TransferBatchLine;

import com.graymound.util.GMMap;

abstract class AbstractLineDataExtractor<T extends ILineData> {

    private static class PatternItem {
        int index;
        int length;
        String key;
    }

    private final ArrayList<PatternItem> patternItems = new ArrayList<PatternItem>();
    
    protected AbstractLineDataExtractor(String pattern) {
        StringTokenizer patternTokenizer = new StringTokenizer(pattern , "\r\n");
        
        while (patternTokenizer.hasMoreTokens()) {
            String style = patternTokenizer.nextToken();
            
            StringTokenizer styleTokenizer = new StringTokenizer(style , "-");
            PatternItem patternItem = new PatternItem();
            
            patternItem.index = Integer.valueOf(styleTokenizer.nextToken()) - 1;
            patternItem.length = Integer.valueOf(styleTokenizer.nextToken());
            patternItem.key = styleTokenizer.nextToken();
            
            patternItems.add(patternItem);
        }                
    }

    protected GMMap extractLine(String line) {
        GMMap map = new GMMap();
        
        for(PatternItem patternItem : patternItems) {
            String data = line.substring(patternItem.index, patternItem.index + patternItem.length).trim();
            map.put(patternItem.key, data);
        }
        
        return map;
    }
    
    public abstract T buildLineData(TransferBatchLine batchLine);


}
