package tr.com.aktifbank.bnspr.currentaccounts.transferbatch;

public interface IEnumIdentifier {

    String value();
    
    String description();
    
}
