package tr.com.aktifbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.FomEkentTransferTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2043Services {
	
	@GraymoundService("BNSPR_EKENT_OTOMATIK_LIMIT_OLUSTURMA")
	public static GMMap otomatikLimitOlustur(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		GMMap oMap = new GMMap();
		try {
			BigDecimal txNo = createTx();
			FomEkentTransferTx fomEkentTransferTx = new FomEkentTransferTx();
			fomEkentTransferTx.setAciklama(iMap.getString("ACIKLAMA"));
			fomEkentTransferTx.setBorcHesapNo(iMap.getBigDecimal("NKOLAY_HESAP_NO"));
			fomEkentTransferTx.setEkentBayiKod(iMap.getString("EKENT_BAYI_KOD"));
			fomEkentTransferTx.setEkentIban(iMap.getString("EKENT_IBAN"));
			fomEkentTransferTx.setFomTrnId(iMap.getBigDecimal("FOM_TRN_ID"));
			fomEkentTransferTx.setTutar(iMap.getBigDecimal("TUTAR"));
			fomEkentTransferTx.setTxNo(txNo);
			session.saveOrUpdate(fomEkentTransferTx);
			session.flush();
			iMap.put("TRX_NO", txNo);
			iMap.put("TRX_NAME" , "2043");
	        oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
			oMap.put("RESPONSE_DATA", oMap.getString("MESSAGE"));
			oMap.put("RESPONSE", "2");
		} catch (Exception e) {
			oMap.put("RESPONSE_DATA", e.getMessage());
			oMap.put("RESPONSE", "0");
			e.printStackTrace();
		}
		return oMap;
	}
	public static BigDecimal createTx(){
	    	GMMap oMapN = new GMMap();
			oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", oMapN);
			return oMapN.getBigDecimal("TRX_NO");
	}
}
