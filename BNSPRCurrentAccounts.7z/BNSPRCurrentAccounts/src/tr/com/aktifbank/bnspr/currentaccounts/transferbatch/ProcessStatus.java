package tr.com.aktifbank.bnspr.currentaccounts.transferbatch;

public enum ProcessStatus implements IEnumIdentifier {
    
    WAITING("0", "Bekliyor"),
    FILE_TRANSFERRING("1", "Dosya aktar�l�yor"),
    PROCESSING("2", "��leniyor"),
    COMPLETED("3", "Tamamland�"),
    COMPLETED_WITH_ERROR("4", "Hatal� tamamland�"),
    FAULTY("5", "Hata ald�"),
    NOT_PROCESSED("6", "��lenmedi");
    
    private String value;
    private String description;
    
    private ProcessStatus(String value, String description) {
        this.value = value;
        this.description = description;
    }
    
    @Override
    public String value() {
        return value;
    }
    
    @Override
    public String description() {
        return description;
    }

}
