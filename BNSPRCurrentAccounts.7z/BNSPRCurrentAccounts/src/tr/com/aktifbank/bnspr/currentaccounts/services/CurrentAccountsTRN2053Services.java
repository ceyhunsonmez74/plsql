package tr.com.aktifbank.bnspr.currentaccounts.services;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2053Services {
	
	@GraymoundService("BNSPR_TRN2053_AFTER_CANCELATION")
	public static GMMap afterCancellation(GMMap iMap) {	
		try {
			GMMap sMap = new GMMap();
							
			sMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()));
			sMap.put("ORGINAL_EXTERNAL_TRX_ID", iMap.getBigDecimal("ISLEM_NO"));
			sMap.put("EXTERNAL_TRX_ID", sMap.getBigDecimal("TRX_NO"));
			sMap.put("OPERATION_TYPE", "G");
			GMServiceExecuter.call("BNSPR_DO_TRANSFER_TO_TFF", sMap);
														
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}	
}
