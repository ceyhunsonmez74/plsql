package tr.com.aktifbank.bnspr.currentaccounts.transferbatch;

import java.math.BigDecimal;

import tr.com.aktifbank.bnspr.dao.TransferBatchLine;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.util.GMMap;


public class TransferLineDataExtractor extends AbstractLineDataExtractor<TransferLineData> {
    
    public TransferLineDataExtractor(String pattern) {
        super(pattern);
    }

    @Override
    public TransferLineData buildLineData(TransferBatchLine batchLine) {
        try {
            TransferLineData lineData = new TransferLineData();
            lineData.setType(batchLine.getLine().charAt(0));
            
            if (lineData.getType() == 'D') {
                GMMap map = extractLine(batchLine.getLine());
                
                String amount = map.getString("AMOUNT");
                lineData.setRecordNo(map.getString("RECORD_NO"));
                lineData.setDate(map.getDate("DATE"));
                lineData.setAddress1(map.getString("ADDRESS1"));
                lineData.setAddress2(map.getString("ADDRESS2"));
                lineData.setToAccNo(map.getBigDecimal("T_ACC_NO"));
                lineData.setAmount(new BigDecimal(amount.substring(0, amount.length() - 2) + "." + amount.substring(amount.length() - 2)));
                lineData.setName(map.getString("NAME"));
                lineData.setSurname(map.getString("SURNAME"));
                lineData.setFname(map.getString("T_FNAME"));
                lineData.setTckn(map.getString("TO_TCKN_VKN"));
                lineData.setDescription(map.getString("DESCRIPTION"));
            }
    
            return lineData;
        
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
}
