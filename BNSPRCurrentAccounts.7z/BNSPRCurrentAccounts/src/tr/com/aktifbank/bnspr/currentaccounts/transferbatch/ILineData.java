package tr.com.aktifbank.bnspr.currentaccounts.transferbatch;

import java.math.BigDecimal;

interface ILineData {
    
    BigDecimal getTransactionAmount();
    
}
