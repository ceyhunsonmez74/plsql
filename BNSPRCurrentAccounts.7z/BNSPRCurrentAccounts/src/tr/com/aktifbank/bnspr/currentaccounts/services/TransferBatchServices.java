package tr.com.aktifbank.bnspr.currentaccounts.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.currentaccounts.transferbatch.ProcessStatus;
import tr.com.aktifbank.bnspr.currentaccounts.transferbatch.ProcessType;
import tr.com.aktifbank.bnspr.currentaccounts.transferbatch.TransferBatchProcess;
import tr.com.aktifbank.bnspr.currentaccounts.transferbatch.TransferLineData;
import tr.com.aktifbank.bnspr.currentaccounts.transferbatch.TransferLineDataExtractor;
import tr.com.aktifbank.bnspr.currentaccounts.transferbatch.Util;
import tr.com.aktifbank.bnspr.dao.TransferBatchEntry;
import tr.com.aktifbank.bnspr.dao.TransferBatchLine;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class TransferBatchServices {
    
    private static final GMMap EMPTY_MAP = new GMMap() {
        /**
         * 
         */
        private static final long serialVersionUID = -818131966909611527L;

        public Object put(Object key, Object value) {
            throw ExceptionHandler.convertException(new GMRuntimeException(0, "Disallowed operation"));
        }
        
        public void putAll(java.util.Map<? extends Object,? extends Object> m) {
            throw ExceptionHandler.convertException(new GMRuntimeException(0, "Disallowed operation"));
        }

    };

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_SUBMIT_TRANSFER_BATCH")
    public static GMMap submitTransferBatch(GMMap iMap) {
        GMMap oMap = new GMMap();
        oMap.putAll(GMServiceExecuter.executeNT("BNSPR_CURRENT_ACCOUNTS_CREATE_TRANSFER_BATCH_ENTRY", iMap));
        
        callJobService(oMap);
        
        return oMap;
    }

    /**
     * Should be called from BNK instance and run in JOB instance in
     * order to process transfer lines in JOB instance. By this way BNK
     * instance is prevented from being overloaded by batch service. BNK
     * will be only responsible for business operations.
     * 
     * @param iMap
     * @return
     */
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_START_TRANSFER_BATCH")
    public static GMMap startTransferBatch(GMMap iMap) {
        GMServiceExecuter.executeAsync("BNSPR_CURRENT_ACCOUNTS_START_TRANSFER_BATCH_ASYNC", iMap);

        return iMap;
    }

    /**
     * Called from BNSPR_CURRENT_ACCOUNTS_START_TRANSFER_BATCH asynchronously
     * in order to start a new thread processing transfer lines in JOB instance.
     * 
     * @param iMap
     * @return
     */
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_START_TRANSFER_BATCH_ASYNC")
    public static GMMap startTransferBatchAsync(GMMap iMap) {
        try {
            BigDecimal processId = iMap.getBigDecimal("PROCESS_ID");
            ByteArrayInputStream inputStream = new ByteArrayInputStream(iMap.getString("FILE_CONTENT").getBytes("ISO-8859-9"));
    
            new TransferBatchProcess(processId).startProcess(inputStream);

            return iMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_CREATE_TRANSFER_BATCH_ENTRY")
    public static GMMap createTransferBatchEntry(GMMap iMap) {
        Session session = DAOSession.getSession("BNSPRDal");

        BigDecimal processId = createProcessId();
        BigDecimal customerNo = iMap.getBigDecimal("CUSTOMER_NO");
        BigDecimal userId = iMap.getBigDecimal("USER_ID");
        BigDecimal accountNumber = iMap.getBigDecimal("ACCOUNT_NUMBER");
        String processType = iMap.getString("PROCESS_TYPE");
        
        TransferBatchEntry entry = new TransferBatchEntry();
        entry.setAccountNumber(accountNumber);
        entry.setCustomerNo(customerNo);
        entry.setProcessId(processId);
        entry.setProcessStatus(ProcessStatus.WAITING.value());
        entry.setProcessType(ProcessType.valueOf(processType).value());
        entry.setUserId(userId);
        
        session.save(entry);
        session.flush();
        
        iMap.put("PROCESS_ID", processId);
        
        return iMap;

    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_UPDATE_TRANSFER_BATCH_ENTRY")
    public static GMMap updateTransferBatchEntry(GMMap iMap) {
        TransferBatchEntry newEntry = (TransferBatchEntry) iMap.get("ENTRY");
        Session session = DAOSession.getSession("BNSPRDal");
        
        TransferBatchEntry entry = Util.findEntry(session, newEntry.getProcessId(), null);
        
        entry.setAccountNumber(newEntry.getAccountNumber());
        entry.setCustomerNo(newEntry.getCustomerNo());
        entry.setError(newEntry.getError());
        entry.setFaultyAmount(newEntry.getFaultyAmount());
        entry.setFaultyCount(newEntry.getFaultyCount());
        entry.setProcessDate(newEntry.getProcessDate());
        entry.setProcessId(newEntry.getProcessId());
        entry.setProcessStatus(newEntry.getProcessStatus());
        entry.setProcessType(newEntry.getProcessType());
        entry.setSuccessAmount(newEntry.getSuccessAmount());
        entry.setSuccessCount(newEntry.getSuccessCount());
        entry.setTotalAmount(newEntry.getTotalAmount());
        entry.setTotalCount(newEntry.getTotalCount());
        entry.setUserId(newEntry.getUserId());
        
        session.save(entry);
        session.flush();
        
        return iMap;
    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_LIST_TRANSFER_BATCH_ENTRIES")
    public static GMMap listTransferBatchEntries(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");

        BigDecimal customerNo = iMap.getBigDecimal("CUSTOMER_NO");
        String processType = iMap.getString("PROCESS_TYPE");
        
        @SuppressWarnings("unchecked")
        List<TransferBatchEntry> entries = session.createCriteria(TransferBatchEntry.class)
                                                .add(Restrictions.eq("customerNo", customerNo))
                                                .add(Restrictions.eq("processType", Util.getEnumType(ProcessType.class, processType).value()))
                                                .addOrder(Order.desc("processId"))
                                                .list();
        
        int i = 0;
        for(TransferBatchEntry entry : entries) {
            oMap.put("TABLE", i, "ACCOUNT_NUMBER", entry.getAccountNumber());
            oMap.put("TABLE", i, "CUSTOMER_NO", entry.getCustomerNo());
            oMap.put("TABLE", i, "ERROR", entry.getError());
            oMap.put("TABLE", i, "FAULTY_AMOUNT", entry.getFaultyAmount());
            oMap.put("TABLE", i, "FAULTY_COUNT", entry.getFaultyCount());
            oMap.put("TABLE", i, "OID", entry.getOid());
            oMap.put("TABLE", i, "PROCESS_DATE", Util.toDateTimeString(entry.getProcessDate()));
            oMap.put("TABLE", i, "PROCESS_ID", entry.getProcessId());
            oMap.put("TABLE", i, "PROCESS_STATUS", Util.getEnumType(ProcessStatus.class, entry.getProcessStatus()).description());
            oMap.put("TABLE", i, "PROCESS_TYPE", Util.getEnumType(ProcessType.class, entry.getProcessType()).description());
            oMap.put("TABLE", i, "SUCCESS_AMOUNT", entry.getSuccessAmount());
            oMap.put("TABLE", i, "SUCCESS_COUNT", entry.getSuccessCount());
            oMap.put("TABLE", i, "TOTAL_AMOUNT", entry.getTotalAmount());
            oMap.put("TABLE", i, "TOTAL_COUNT", entry.getTotalCount());
            oMap.put("TABLE", i, "USER_ID", entry.getUserId());
            
            i++;
        }
        
        return oMap;
    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_LIST_TRANSFER_BATCH_LINE_DETAILS")
    public static GMMap listTransferBatchLineDetails(GMMap iMap) {
        GMMap oMap = new GMMap();
        Session session = DAOSession.getSession("BNSPRDal");

        BigDecimal processId = iMap.getBigDecimal("PROCESS_ID");
        String processStatus = iMap.getString("PROCESS_STATUS", "");

        Criteria criteria = session.createCriteria(TransferBatchLine.class)
                .add(Restrictions.eq("processId", processId));

        if (!processStatus.isEmpty()) {
            criteria.add(Restrictions.eq("processStatus", Util.getEnumType(ProcessStatus.class, processStatus).value()));
        }
        
        @SuppressWarnings("unchecked")
        List<TransferBatchLine> lines = criteria.addOrder(Order.asc("lineNumber")).list();
        
        TransferLineDataExtractor transferLineDataExtractor = new TransferLineDataExtractor(Util.TRANSFER_FILE_PATTERN);
        
        int i = 0;
        for(TransferBatchLine line : lines) {
            TransferLineData lineData = transferLineDataExtractor.buildLineData(line);
            
            if (lineData.getType() == 'D') {
                oMap.put("TABLE", i, "PROCESS_ID", line.getProcessId());
                oMap.put("TABLE", i, "PROCESS_STATUS", Util.getEnumType(ProcessStatus.class, line.getProcessStatus()).description());
                oMap.put("TABLE", i, "PROCESS_DATE", Util.toDateTimeString(line.getProcessDate()));
                oMap.put("TABLE", i, "ERROR", line.getError());
                oMap.put("TABLE", i, "ADDRESS1", lineData.getAddress1());
                oMap.put("TABLE", i, "ADDRESS2", lineData.getAddress2());
                oMap.put("TABLE", i, "DATE", Util.toDateString(lineData.getDate()));
                oMap.put("TABLE", i, "DESCRIPTION", lineData.getDescription());
                oMap.put("TABLE", i, "F_NAME", lineData.getFname());
                oMap.put("TABLE", i, "NAME", lineData.getName());
                oMap.put("TABLE", i, "RECORD_NO", lineData.getRecordNo());
                oMap.put("TABLE", i, "SURNAME", lineData.getSurname());
                oMap.put("TABLE", i, "TCKN", lineData.getTckn());
                oMap.put("TABLE", i, "ACCOUNT_NUMBER", lineData.getToAccNo());
                oMap.put("TABLE", i, "AMOUNT", lineData.getTransactionAmount());
                oMap.put("TABLE", i, "LINE_NUMBER", line.getLineNumber());
    
                i++;
            }
        }
        
        return oMap;
    }

    private static BigDecimal createProcessId() {
        return GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", EMPTY_MAP).getBigDecimal("TRX_NO");
    }
    
    private static GMMap callJobService(GMMap iMap) {
        return callRemoteService("SCHEDULER", "BNSPR_CURRENT_ACCOUNTS_START_TRANSFER_BATCH", iMap);
    }
    
    private static GMMap callRemoteService(String target, String serviceName, GMMap iMap) {
        try {
            GMMap oMap = new GMMap();
            
            oMap.putAll(GMConnection.getConnection(target).serviceCall(serviceName, iMap));
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

}
