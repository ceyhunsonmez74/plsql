package tr.com.aktifbank.bnspr.currentaccounts.transferbatch;


interface IProcessVisitor {

    void visit(ProcessStatus processStatus, ILineData lineData);

}
