package tr.com.aktifbank.bnspr.currentaccounts.transferbatch;

import java.math.BigDecimal;
import java.util.HashSet;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.dao.TransferBatchEntry;
import tr.com.aktifbank.bnspr.dao.TransferBatchLine;


abstract class AbstractProcess<T extends ILineData> {
    
    private final AllowedAccountNumberHolder accountNumberHolder;
    private final AbstractLineDataExtractor<T> lineDataExtractor;
    private final IProcessVisitor processVisitor;
    private final TransferBatchEntry entry;
    
    private static class AllowedAccountNumberHolder {
        
        private final HashSet<BigDecimal> allowedAccounts = new HashSet<BigDecimal>();
        
        AllowedAccountNumberHolder(BigDecimal customerNo, ProcessType processType) {
            GMMap serviceInMap = new GMMap();
            serviceInMap.put("CUSTOMER_NO", customerNo);
            serviceInMap.put("ORDER_TYPE", (processType == ProcessType.EFT) ? "1" : "2");
            
            GMMap serviceOutMap = GMServiceExecuter.call("COS_GET_RECIPIENTS_BY_CUSTOMER_NO", serviceInMap);
            
            int size = serviceOutMap.getSize("RECIPIENT_LIST");
            for (int i = 0; i < size; i++) {
                BigDecimal accountNumber = serviceOutMap.getBigDecimal("RECIPIENT_LIST", i, "ACCOUNT_NO");
                allowedAccounts.add(accountNumber);
            }
        }
        
        boolean isAllowed(BigDecimal accountNo) {
            return allowedAccounts.isEmpty()
                    || allowedAccounts.contains(accountNo);
        }
    
    }

    protected AbstractProcess(TransferBatchEntry entry, AbstractLineDataExtractor<T> lineDataExtractor, IProcessVisitor processVisitor) {
        ProcessType processType = Util.getEnumType(ProcessType.class, entry.getProcessType());
        
        accountNumberHolder = new AllowedAccountNumberHolder(entry.getCustomerNo(), processType);
        this.lineDataExtractor = lineDataExtractor;
        this.processVisitor = processVisitor;
        this.entry = entry;
    }

    protected void validateAccountNumber(BigDecimal accountNo) {
        if (!accountNumberHolder.isAllowed(accountNo)) {
            Util.throwMessage("TRNBCHINVACC");
        }
    }

    ProcessStatus process(TransferBatchLine batchLine) throws Exception {
        T lineData = lineDataExtractor.buildLineData(batchLine);
        
        try {
            ProcessStatus processStatus = processInternal(lineData);
            if (processVisitor != null) {
                processVisitor.visit(processStatus, lineData);
            }
            
            return processStatus;
        } catch (Exception e) {
            if (processVisitor != null) {
                processVisitor.visit(ProcessStatus.FAULTY, lineData);
            }
            
            throw e;
        }
    }
    
    protected abstract ProcessStatus processInternal(T lineData);

    protected TransferBatchEntry getEntry() {
        return entry;
    }

}
