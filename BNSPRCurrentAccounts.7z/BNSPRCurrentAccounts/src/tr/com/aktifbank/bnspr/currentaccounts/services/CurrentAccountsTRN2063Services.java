package tr.com.aktifbank.bnspr.currentaccounts.services;

import java.sql.Connection;
import java.sql.SQLException;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ClksHavaleOdemeTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2063Services {

	@GraymoundService("BNSPR_TRN2063_SAVE")
	public static GMMap save(GMMap iMap) {
		Connection conn = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");
			boolean isInsert = false;
			ClksHavaleOdemeTx clksHavaleOdemeTx = (ClksHavaleOdemeTx) session
					.get(ClksHavaleOdemeTx.class, iMap.getBigDecimal("TRX_NO"));
			if (clksHavaleOdemeTx == null) {
				clksHavaleOdemeTx = new ClksHavaleOdemeTx();
				isInsert = true;
			}
			clksHavaleOdemeTx.setTxNo(iMap.getBigDecimal("TRX_NO",
					clksHavaleOdemeTx.getTxNo()));
			oMap.put("TRX_NO", clksHavaleOdemeTx.getTxNo());
			clksHavaleOdemeTx.setAciklama(iMap.getString("ACIKLAMA",
					clksHavaleOdemeTx.getAciklama()));
			oMap.put("ACIKLAMA", clksHavaleOdemeTx.getAciklama());
			clksHavaleOdemeTx.setAlacakHesapNo(iMap.getBigDecimal(
					"ALACAKHESAPNO", clksHavaleOdemeTx.getAlacakHesapNo()));
			clksHavaleOdemeTx.setAlacakMusteriNo(iMap.getBigDecimal(
					"ALACAKMUSTERINO", clksHavaleOdemeTx.getAlacakMusteriNo()));
			clksHavaleOdemeTx.setAliciAdSoyad(iMap.getString("ALICIADSOYAD",
					clksHavaleOdemeTx.getAliciAdSoyad()));
			clksHavaleOdemeTx.setAliciAdres(iMap.getString("ALICIADRES",
					clksHavaleOdemeTx.getAliciAdres()));
			clksHavaleOdemeTx.setAliciAnneadi(iMap.getString("ALICIANNEADI",
					clksHavaleOdemeTx.getAliciAnneadi()));
			clksHavaleOdemeTx.setAliciBabaadi(iMap.getString("ALICIBABAADI",
					clksHavaleOdemeTx.getAliciBabaadi()));
			clksHavaleOdemeTx.setDovizKodu(iMap.getString("DOVIZKODU",
					clksHavaleOdemeTx.getDovizKodu()));
			oMap.put("DOVIZKODU", clksHavaleOdemeTx.getDovizKodu());
			clksHavaleOdemeTx.setDurumKodu(iMap.getString("DURUMKODU",
					clksHavaleOdemeTx.getDurumKodu()));
			clksHavaleOdemeTx.setGizliSoruNo(iMap.getBigDecimal("GIZLISORUNO",
					clksHavaleOdemeTx.getGizliSoruNo()));
			clksHavaleOdemeTx.setGonderenAdSoyad(iMap.getString(
					"GONDERENADSOYAD", clksHavaleOdemeTx.getGonderenAdSoyad()));
			clksHavaleOdemeTx.setGonderenAdres(iMap.getString("GONDERENADRES",
					clksHavaleOdemeTx.getGonderenAdres()));
			clksHavaleOdemeTx.setGonderenTelefon(iMap.getString(
					"GONDERENTELEFON", clksHavaleOdemeTx.getGonderenTelefon()));
			clksHavaleOdemeTx.setHesapNo(iMap.getBigDecimal("BORCHESAPNO",
					clksHavaleOdemeTx.getHesapNo()));
			clksHavaleOdemeTx.setIsleminYapildigiYer(iMap
					.getString("ISLEMINYAPILDIGIYER"));
			clksHavaleOdemeTx.setIslemiYapanKullanici(iMap.getString(
					"ISLEMIYAPANKULLANICI",
					clksHavaleOdemeTx.getIslemiYapanKullanici()));
			clksHavaleOdemeTx.setMasrafTutari(iMap.getBigDecimal(
					"MASRAFTUTARI", clksHavaleOdemeTx.getMasrafTutari()));
			oMap.put("MASRAFTUTARI", clksHavaleOdemeTx.getMasrafTutari());
			clksHavaleOdemeTx.setMusteriNo(iMap.getBigDecimal("MUSTERINO",
					clksHavaleOdemeTx.getMusteriNo()));
			clksHavaleOdemeTx.setReferansNo(iMap.getString("REFERANSNO",
					clksHavaleOdemeTx.getReferansNo()));
			clksHavaleOdemeTx.setSubeKodu(iMap.getString("SUBEKODU",
					clksHavaleOdemeTx.getSubeKodu()));
			clksHavaleOdemeTx.setTckno(iMap.getString("TCNO",
					clksHavaleOdemeTx.getTckno()));
			clksHavaleOdemeTx.setTutar(iMap.getBigDecimal("TUTAR",
					clksHavaleOdemeTx.getTutar()));
			oMap.put("TUTAR", clksHavaleOdemeTx.getTutar());
			clksHavaleOdemeTx.setValorTarihi(iMap.getDate("VALORTARIHI",
					clksHavaleOdemeTx.getValorTarihi()));
			clksHavaleOdemeTx.setYanit(iMap.getString("YANIT",
					clksHavaleOdemeTx.getYanit()));
			clksHavaleOdemeTx.setIslemSekli(iMap.getString("ISLEMSEKLI",
					clksHavaleOdemeTx.getIslemSekli()));
			clksHavaleOdemeTx.setAliciTckno(iMap.getString("ALICITCKNO",
					clksHavaleOdemeTx.getAliciTckno()));
			clksHavaleOdemeTx.setMasrafTahsilDoviz(iMap.getString(
					"MASRAFTAHSILDOVIZ",
					clksHavaleOdemeTx.getMasrafTahsilDoviz()));
			oMap.put("MASRAFTAHSILDOVIZ",
					clksHavaleOdemeTx.getMasrafTahsilDoviz());
			clksHavaleOdemeTx.setAliciTelefon(iMap.getString("ALICITELEFON",
					clksHavaleOdemeTx.getAliciTelefon()));
			clksHavaleOdemeTx.setIstatistikKodu(iMap.getString(
					"ISTATISTIKKODU", clksHavaleOdemeTx.getIstatistikKodu()));
			clksHavaleOdemeTx.setIslem(iMap.getBigDecimal("islem",
					clksHavaleOdemeTx.getIslem()));
			clksHavaleOdemeTx.setPttIslemNo(iMap.getBigDecimal("islemNoPTT",
					clksHavaleOdemeTx.getPttIslemNo()));
			clksHavaleOdemeTx.setEuptHesapNo(iMap.getBigDecimal("EUPT_HESAP_NO",
					clksHavaleOdemeTx.getEuptHesapNo()));
			oMap.put("EUPT_HESAP_NO",
					clksHavaleOdemeTx.getEuptHesapNo());
			session.saveOrUpdate(clksHavaleOdemeTx);
			session.flush();
			if (isInsert) {
				iMap.put("TRX_NAME", "2063");
				GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			}
			return oMap;
		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		} finally {
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2063_AFTER_CANCELATION")
	public static GMMap afterCancellation(GMMap iMap) {	
		try {
			GMMap sMap = new GMMap();
							
			sMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
			GMServiceExecuter.call("BNSPR_EUPT_EUPT_ISLEM_IPTAL", sMap);
														
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}	

}
