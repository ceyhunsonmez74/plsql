package tr.com.aktifbank.bnspr.currentaccounts.services;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.math.BigDecimal;

import java.util.List;
import java.util.Locale;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import jxl.read.biff.File;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.igdasVezneTransferTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
public class CurrentAccountsTRN2088Services{
	 @GraymoundService("BNSPR_TRN2088_IMPORT_EXCEL")
	    public static GMMap excelToTable(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        try {
	        	byte[] inputFile = (byte[]) iMap.get("FILE");
	        	if (inputFile == null) {
		                iMap.put("HATA_NO", new BigDecimal(660));
		                iMap.put("P1", "Dosya se�mediniz.");
		                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		            }
	        	BufferedReader br;
	        	
	        	
	        	ByteArrayInputStream bInput = new ByteArrayInputStream(inputFile);
	        	br = new BufferedReader(new InputStreamReader(bInput,"windows-1254"));
	        	String line;
                BigDecimal toplamTutar = BigDecimal.ZERO;
                int j=0;
                while ((line = br.readLine()) != null) {
                	oMap.put("TUTAR_LISTESI", j, "TUTAR",Double.valueOf(line.substring(0, 15))/100);
                	toplamTutar = toplamTutar.add(BigDecimal.valueOf(Double.valueOf(line.substring(0, 15))/100));
                	oMap.put("TUTAR_LISTESI", j, "ACIKLAMA", line.substring(15, 65));
                       //String[] values = line.split(";");
//                       for (int i = 0; i < 2; i++) {
//                    	   if (i==0){
//                    		   oMap.put("TUTAR_LISTESI", j, "TUTAR", values[i].replace(",", "."));
//	                		toplamTutar = toplamTutar.add(BigDecimal.valueOf(Double.valueOf(values[i].replace(",", "."))));
//	                		}
//                    	   if (i==1){
//                    		   oMap.put("TUTAR_LISTESI", j, "ACIKLAMA", values[i]);
//                    	   }
//                    	      
//                       }
                       j++;
                }
                br.close();

	           
//	            Workbook workbook;
//	            WorkbookSettings ws = new WorkbookSettings();
//
//	            //ws.setCharacterSet(cs);
//	            ws.setEncoding("ISO-8859-9");
//	            ws.setExcelDisplayLanguage("TR");
//	            ws.setExcelRegionalSettings("TR");
//	            ws.setLocale(new Locale("tr", "TR"));
//	            BigDecimal toplamTutar=BigDecimal.ZERO;
//	            
//	            try {
//	                workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
//	            } catch (Exception e) {
//	                iMap.put("HATA_NO", new BigDecimal(660));
//	                iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
//	                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
//	            }
//	            Sheet sheet = workbook.getSheet(0);
//	            for (int j = 1; j < sheet.getRows(); j++) {
//	                for (int i = 0; i < sheet.getColumns(); i++) {
//	                	if(i==0){
//	                		oMap.put("TUTAR_LISTESI", j-1, "TUTAR", sheet.getCell(i, j).getContents().replace(",", "."));
//	                		toplamTutar = toplamTutar.add(BigDecimal.valueOf(Double.valueOf(sheet.getCell(i, j).getContents().replace(",", "."))));
//	                	}
//	                	if(i==1)
//	                		oMap.put("TUTAR_LISTESI", j-1, "ACIKLAMA", sheet.getCell(i, j).getContents());
//	                	
//	                }
//	            }
	            oMap.put("TOPLAM",toplamTutar);
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {}

	    }
	

		@GraymoundService("BNSPR_TRN2088_SAVE")
		public static GMMap save(GMMap iMap){
			GMMap oMap = new GMMap();
			int a=0;
			BigDecimal tx_no = BigDecimal.ZERO;
			BigDecimal odeme_tx_no = BigDecimal.ZERO;
			Session session = DAOSession.getSession("BNSPRDal");
			try{
			String aliciHesapNo = getGlobalParam("IGDAS_TRANSFER_ALICI_HESAP");
			String borcluHesapNo = getGlobalParam("IGDAS_TRANSFER_BORCLU_HESAP");
			GMMap sMap = new GMMap();
			sMap.put("HESAP_NO", aliciHesapNo);
			sMap = GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_SUBE_KOD", sMap);		
			String sube = sMap.getString("SUBE_KODU");
			
			
			for (int i = 0; i < iMap.getSize("TUTAR_LISTESI"); i++) {
				if (iMap.get("TUTAR_LISTESI",i,"TUTAR") != null && !iMap.getString("TUTAR_LISTESI",i,"TUTAR").isEmpty()){
					igdasVezneTransferTx transfer = new igdasVezneTransferTx();
					transfer.setAciklama(iMap.getString("TUTAR_LISTESI",i,"ACIKLAMA"));
					transfer.setAliciHesapCinsi("VS");
					transfer.setAliciHesapNo(aliciHesapNo);
					transfer.setBorcHesapCinsi("DK");
					transfer.setBorcHesapNo(borcluHesapNo);
					transfer.setDovizKodu("TRY");
					transfer.setDurumKodu("A");
					tx_no = createTx();
					transfer.setOdemeTxNo(iMap.getBigDecimal("TRX_NO"));
					transfer.setSube(sube);
					transfer.setTutar(iMap.getBigDecimal("TUTAR_LISTESI",i,"TUTAR"));
					transfer.setTxNo(tx_no);
					session.saveOrUpdate(transfer);
					a++;
					
				}
				
			}
			if (a>0){
			session.flush();
			iMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			 iMap.put("TRX_NAME" , "2089");
	            return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION" , iMap);
			} else{
				oMap.put("MESSAGE", "B�t�n hesap numaralar� bo�");
				return oMap;
			}
				
			
			}
			catch (GMRuntimeException e) {
				throw ExceptionHandler.convertException(e);
				
			}
			
		}
		@GraymoundService("BNSPR_TRN2088_GET_INFO")
		public static GMMap getInfo(GMMap iMap){
			GMMap oMap = new GMMap();
			try {
				Session session = DAOSession.getSession("BNSPRDal");
				List<?> tutarList = session.createCriteria(igdasVezneTransferTx.class).add(Restrictions.eq("odemeTxNo", iMap.getBigDecimal("TRX_NO"))).list();
				int i=0;
				BigDecimal toplamTutar = BigDecimal.ZERO;
				for (Object name : tutarList) {
					igdasVezneTransferTx transfer = (igdasVezneTransferTx) name;
					oMap.put("TUTAR_LIST",i,"TUTAR",transfer.getTutar());
					oMap.put("TUTAR_LIST",i,"ACIKLAMA",transfer.getAciklama());
					toplamTutar=toplamTutar.add(transfer.getTutar());
					i++;
				}
				oMap.put("TOPLAM", toplamTutar);
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
			return oMap;
			
		}
		
		 public static BigDecimal createTx(){
		    	GMMap oMapN = new GMMap();
				oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", oMapN);
				return oMapN.getBigDecimal("TRX_NO");
			}
		 public static String getGlobalParam(String code) {
				GMMap iMapG = new GMMap();
				iMapG.put("KOD", code);
				iMapG.put("TRIM_QUOTES", true);
				String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", iMapG).getString("DEGER");
				return batchNo;
			}
}