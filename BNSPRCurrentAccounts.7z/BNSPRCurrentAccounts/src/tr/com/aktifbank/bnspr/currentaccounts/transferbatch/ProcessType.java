package tr.com.aktifbank.bnspr.currentaccounts.transferbatch;

public enum ProcessType implements IEnumIdentifier {

    TRANSFER("0", "Havale"),
    EFT("1", "EFT");

    private String value;
    private String description;

    private ProcessType(String value, String description) {
        this.value = value;
        this.description = description;
    }

    @Override
    public String value() {
        return value;
    }

    @Override
    public String description() {
        return description;
    }

}
