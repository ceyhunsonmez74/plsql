package tr.com.aktifbank.bnspr.currentaccounts.transferbatch;

import java.math.BigDecimal;
import java.util.Date;


public class TransferLineData implements ILineData {
    
    private char type;
    private String recordNo;
    private Date date;
    private String address1;
    private String address2;
    private BigDecimal toAccNo;
    private BigDecimal amount;
    private String name;
    private String surname;
    private String fname;
    private String tckn;
    private String description;

    @Override
    public BigDecimal getTransactionAmount() {
        return amount;
    }

    public char getType() {
        return type;
    }

    public void setType(char type) {
        this.type = type;
    }

    public String getRecordNo() {
        return recordNo;
    }

    public void setRecordNo(String recordNo) {
        this.recordNo = recordNo;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }

    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }

    public BigDecimal getToAccNo() {
        return toAccNo;
    }

    public void setToAccNo(BigDecimal toAccNo) {
        this.toAccNo = toAccNo;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getTckn() {
        return tckn;
    }

    public void setTckn(String tckn) {
        this.tckn = tckn;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
    
}
