package tr.com.aktifbank.bnspr.currentaccounts.clks.transaction;


public enum TransactionType {
	
	/**
	 * Nakit Yatan
	 */
	CASH_DEPOSIT("1"),
	
	/**
	 * Taksit Tahsilati, Kredi Kapama
	 */
	INSTALLMENT_LOAN("4"),
	
	/**
	 * Nakit Cekilen
	 */
	CASH_WITHDRAWAL("5"),

	/**
	 * Referansli Odeme
	 */
	REFERENCE_PAYMENT("6"),
	
	/**
	 * Kredi Odemesi
	 */
	CONSUMERLOAN_PAYMENT("7"),
	
	/**
	 * Kredi Basvuru
	 */
	CONSUMERLOAN_APPLICATION("9"),
	
	/**
	 * EFT (TL UPT)
	 */
	ELECTRONIC_FUND_TRANSFER("10"),
	
	/**
	 * EFT Odeme
	 */
	ELECTRONIC_FUND_TRANSFER_PAYMENT("11"),
	
	/**
	 * UPT/SWIFT Yurt Ici Gonderim
	 */
	FOREIGN_CURRENCY_TRANSFER_LOCAL("12"),
	
	/**
	 * UPT/SWIFT Yurt Disi Gonderim
	 */
	FOREIGN_CURRENCY_TRANSFER_GLOBAL("13"),
	
	/**
	 * YP UPT (UPT/SWIFT) Odeme 
	 */
	FOREIGN_CURRENCY_TRANSFER_PAYMENT("14"),
	
	/**
	 * EFT (TL UPT) PCH ile
	 */
	ELECTRONIC_FUND_TRANSFER_FROM_PCH("70"),
	
	/**
	 * EFT (TL UPT) Internet PCH ile
	 */
	ELECTRONIC_FUND_TRANSFER_FROM_IPCH("83"),
	
	/**
	 * EFT (TL UPT) PCH ile - Iade
	 */
	ELECTRONIC_FUND_TRANSFER_FROM_PCH_REFUND("77"),
	
	/**
	 * EFT (TL UPT) Internet PCH ile - Iade
	 */
	ELECTRONIC_FUND_TRANSFER_FROM_IPCH_REFUND("84"),
	
	/**
	 * Iade odeme
	 */
	REFUND_PAYMENT("27"),
	
	/**
	 * Masraf dahil iade odeme
	 */
	REFUND_PAYMENT_WITH_EXPENSE("85"),

	/**
	 * Gise passolig kart odemesi
	 */
	CARD_PAYMENT_PASSO("65"),
	
	/**
	 * Gise nkolay kart odemesi
	 */
	CARD_PAYMENT_NKOLAY("72"),
	
	/**
	 * ATM'den hesaba nakit yatirma
	 */
	ATM_CASH_DEPOSIT_TO_ACCOUNT("60.60"),
	
	/**
	 * ATM'den hesaba nakit yatirma
	 */
	ATM_CASH_DEPOSIT_TO_IBAN("60.61"),
	
	/**
	 * ATM'den passolig kart odemesi
	 */
	ATM_CARD_PAYMENT_PASSO("60.63"),
	
	/**
	 * ATM'den passolig kart odemesi
	 */
	ATM_CARD_PAYMENT_PASSO_WITH_ID("60.64"),
	
	/**
	 * ATM'den nkolay kart odemesi
	 */
	ATM_CARD_PAYMENT_NKOLAY("60.65"),
	
	/**
	 * UPT Referans - EFT
	 */
	UPT_REFERENCE_TRANSFER_EFT("80"),
	
	/**
	 * UPT Referans - Yurt Ici Gonderim
	 */
	UPT_REFERENCE_TRANSFER_LOCAL("81"),
	
	/**
	 * UPT Referans - Yurt Disi Gonderim
	 */
	UPT_REFERENCE_TRANSFER_GLOBAL("82"),
	
	/**
	 * Hesap Acma
	 */
	CUSTOMER_ACQUISITION("137"),
	
	/**
	 * Otomatik Taksit Tahsilati
	 */
	INSTALLMENT_LOAN_AUTOMATION("OTO_TT"),
	
	/**
	 * Bayi Kredi Odemesi
	 */
	DEALER_CONSUMERLOAN_PAYMENT("BAYI_KK"),
	
	/**
	 * Bayi Taksit Tahsilati
	 */
	DEALER_INSTALLMENT_LOAN("BAYI_TT");
	
	private String code;
	
	private TransactionType(String code) {
		this.code = code;
	}
	
	public String getCode() {
		return code;
	}

	/**
	 * @param code	Islem turu/tipi
	 * @return
	 */
	public static TransactionType getEnum(String code) {
		for(TransactionType v : values())
			if(v.getCode().equals(code)) return v;
		throw new IllegalArgumentException();
	}
}
