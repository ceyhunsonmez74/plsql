package tr.com.aktifbank.bnspr.currentaccounts.transferbatch;

import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.TransferBatchEntry;
import tr.com.aktifbank.bnspr.dao.TransferBatchLine;

import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class TransferBatchProcess implements IProcessVisitor {
    
    private final Session session;
    private final TransferBatchEntry entry;
    private final List<TransferBatchLine> batchLines;
    
    private int totalCount = 0;
    private int faultyCount = 0;
    private int successCount = 0;
    private BigDecimal totalAmount = BigDecimal.ZERO;
    private BigDecimal faultyAmount = BigDecimal.ZERO;
    private BigDecimal successAmount = BigDecimal.ZERO;
    
    public TransferBatchProcess(BigDecimal processId) {
        session = DAOSession.getSession("BNSPRDal");
        entry = findEntry(processId);
        batchLines = new ArrayList<TransferBatchLine>();
    }

    private TransferBatchEntry findEntry(BigDecimal processId) {
        TransferBatchEntry entry = Util.findEntry(session, processId, ProcessStatus.WAITING);
        
        return cloneEntry(entry);
    }
    
    private TransferBatchEntry cloneEntry(TransferBatchEntry entry) {
        TransferBatchEntry newEntry = new TransferBatchEntry();
        newEntry.setAccountNumber(entry.getAccountNumber());
        newEntry.setCustomerNo(entry.getCustomerNo());
        newEntry.setError(entry.getError());
        newEntry.setFaultyAmount(entry.getFaultyAmount());
        newEntry.setFaultyCount(entry.getFaultyCount());
        newEntry.setOid(entry.getOid());
        newEntry.setProcessDate(entry.getProcessDate());
        newEntry.setProcessId(entry.getProcessId());
        newEntry.setProcessStatus(entry.getProcessStatus());
        newEntry.setProcessType(entry.getProcessType());
        newEntry.setSuccessAmount(entry.getSuccessAmount());
        newEntry.setSuccessCount(entry.getSuccessCount());
        newEntry.setTotalAmount(entry.getTotalAmount());
        newEntry.setTotalCount(entry.getTotalCount());
        newEntry.setUserId(entry.getUserId());
        
        return newEntry;
    }
    
    private AbstractProcess<? extends ILineData> buildBatchProcess() {
        if (entry.getProcessType().equals(ProcessType.TRANSFER.value())) {
            return new TransferProcess(entry, this);
        }
        return null;
    }

    public void startProcess(InputStream fileContentInputStream) {
        AbstractProcess<? extends ILineData> batchProcess = buildBatchProcess();
        
        try {
            updateEntryStatus(ProcessStatus.FILE_TRANSFERRING);

            createLineData(fileContentInputStream);

            updateEntryStatus(ProcessStatus.PROCESSING);

            if (processLines(batchProcess)) {
                updateEntryStatus(ProcessStatus.COMPLETED);
            } else {
                updateEntryStatus(ProcessStatus.COMPLETED_WITH_ERROR);
            }
        } catch (Exception e) {
            updateEntryStatus(e);
        }             
    }
    
    private void createLineData(InputStream fileContentInputStream) {
        Scanner scanner = new Scanner(fileContentInputStream).useDelimiter("\n");
        
        BigDecimal processId = entry.getProcessId();

        int lineNumber = 1;
        while(scanner.hasNext()) {
            String line = scanner.next();
            
            if (!line.isEmpty()) {
                TransferBatchLine batchLine = new TransferBatchLine();
                batchLine.setLine(line);
                batchLine.setProcessId(processId);
                batchLine.setProcessStatus(ProcessStatus.WAITING.value());
                batchLine.setLineNumber(BigDecimal.valueOf(lineNumber++));

                batchLines.add(batchLine);
            }
        }
    }
    
    private boolean processLines(AbstractProcess<? extends ILineData> batchProcess) {
        boolean isTotallySuccessful = true;
        
        for (TransferBatchLine batchLine : batchLines) {
            validateLine(batchLine);
            isTotallySuccessful &= processLine(batchLine, batchProcess);
            
            session.saveOrUpdate(batchLine);
        }
        
        session.flush();

        return isTotallySuccessful;
    }
    
    private void validateLine(TransferBatchLine batchLine) {
        if (batchLine.getLine().trim().length() > 500) {
            Util.throwMessage("TRNBCHINVLN");
        }
    }

    private boolean processLine(TransferBatchLine batchLine, AbstractProcess<? extends ILineData> batchProcess) {
        boolean isSuccessful = true;
        
        try {
            ProcessStatus processStatus = batchProcess.process(batchLine);
            batchLine.setProcessStatus(processStatus.value());
        } catch (Exception e) {
            batchLine.setProcessStatus(ProcessStatus.FAULTY.value());
            batchLine.setError(Util.limit(e.getMessage(), 200));
            
            isSuccessful = false;
        }

        return isSuccessful;
    }

    private void updateEntryStatus(ProcessStatus processStatus) {
        entry.setProcessDate(Calendar.getInstance().getTime());
        entry.setProcessStatus(processStatus.value());
        entry.setTotalAmount(totalAmount);
        entry.setTotalCount(BigDecimal.valueOf(totalCount));
        entry.setSuccessAmount(successAmount);
        entry.setSuccessCount(BigDecimal.valueOf(successCount));
        entry.setFaultyAmount(faultyAmount);
        entry.setFaultyCount(BigDecimal.valueOf(faultyCount));
        
        GMMap map = new GMMap();
        map.put("ENTRY", entry);
        GMServiceExecuter.executeNT("BNSPR_CURRENT_ACCOUNTS_UPDATE_TRANSFER_BATCH_ENTRY", map);
    }
    
    private void updateEntryStatus(Exception e) {
        entry.setError(Util.limit(e.getMessage(), 200));
        updateEntryStatus(ProcessStatus.FAULTY);
    }

    @Override
    public void visit(ProcessStatus processStatus, ILineData lineData) {
        if (processStatus == ProcessStatus.NOT_PROCESSED) {
            return;
        }
        
        BigDecimal amount = lineData.getTransactionAmount();
        
        if (processStatus == ProcessStatus.COMPLETED) {
            successCount++;
            successAmount = successAmount.add(amount );
        } else {
            faultyCount++;
            faultyAmount = faultyAmount.add(amount);
        }

        totalCount++;
        totalAmount = totalAmount.add(amount);
    }

}
