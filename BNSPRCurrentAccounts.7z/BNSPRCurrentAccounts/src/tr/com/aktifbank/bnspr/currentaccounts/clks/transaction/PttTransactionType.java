package tr.com.aktifbank.bnspr.currentaccounts.clks.transaction;

public enum PttTransactionType {
	
	/**
	 * Upt Kabul (TL)
	 */
	UPT_EFT_TRY("386"),
	
	/**
	 * Upt Kabul (USD)
	 */
	UPT_EFT_USD("405"),
	
	/**
	 * Upt Kabul (EURO)
	 */
	UPT_EFT_EUR("406"),
	
	/**
	 * Upt YP Kabul (TL)
	 */
	UPT_FC_LOCAL_TRY("671"),
	
	/**
	 * Upt YP Kabul (USD)
	 */
	UPT_FC_LOCAL_USD("672"),
	
	/**
	 * Upt YP Kabul (EUR)
	 */
	UPT_FC_LOCAL_EUR("673"),
	
	/**
	 * Upt YP YURTDISI Kabul (TL)
	 */
	UPT_FC_GLOBAL_TRY("674"),
	
	/**
	 * Upt YP YURTDISI Kabul (USD)
	 */
	UPT_FC_GLOBAL_USD("675"),
	
	/**
	 * Upt YP YURTDISI Kabul (EUR)
	 */
	UPT_FC_GLOBAL_EUR("676"),
	
	/**
	 * Upt YP IADE Kabul (TL)
	 */
	UPT_REFUND_LOCAL_TRY("571"),
	
	/**
	 * Upt YP IADE Kabul (USD)
	 */
	UPT_REFUND_LOCAL_USD("572"),
	
	/**
	 * Upt YP IADE Kabul (EURO)
	 */
	UPT_REFUND_LOCAL_EUR("573"),
	
	/**
	 * Upt �DEME (TL)
	 */
	UPT_PAYMENT_LOCAL_TRY("645"),
	
	/**
	 * Upt �DEME (USD)
	 */
	UPT_PAYMENT_LOCAL_USD("646"),
	
	/**
	 * Upt �DEME (EURO)
	 */
	UPT_PAYMENT_LOCAL_EUR("647"),
	
	/**
	 * AKT�F BANK P�H �LE TL UPT
	 */
	UPT_EFT_PCH_TRY("733"),
	
	/**
	 * AKT�F BANK P�H �LE TL UPT �ADE
	 */
	UPT_EFT_PCH_REFUND_TRY("734"),
	
	/**
	 * AKT�F BANK MASRAF DAH�L �ADE KABUL (TRY)
	 */
	UPT_REFUND_PAYMENT_WITH_EXPENSE_TRY("7461"),
	
	/**
	 * AKT�F BANK MASRAF DAH�L �ADE KABUL (USD)
	 */
	UPT_REFUND_PAYMENT_WITH_EXPENSE_USD("7462"),
	
	/**
	 * AKT�F BANK MASRAF DAH�L �ADE KABUL (EUR)
	 */
	UPT_REFUND_PAYMENT_WITH_EXPENSE_EUR("7463");
	
	
	private String pttCode;
	
	private PttTransactionType(String pttCode) {
		this.pttCode = pttCode;
	}
	
	public String getPttCode() {
		return pttCode;
	}

	
	public static PttTransactionType getPttCodeEnum(String code){
		for(PttTransactionType p : values())
			if(p.getPttCode().equals(code)) return p;
		throw new IllegalArgumentException();
	}
	
}
