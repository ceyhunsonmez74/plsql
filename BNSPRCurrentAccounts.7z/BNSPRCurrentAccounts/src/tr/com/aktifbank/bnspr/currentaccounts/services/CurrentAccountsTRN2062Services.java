package tr.com.aktifbank.bnspr.currentaccounts.services;

import java.sql.Connection;
import java.sql.SQLException;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ClksHavaleGirisTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2062Services {

	/**
	 * TRN2062 EUPT Hesabina para yukleme servisi,
	 * @param  iMap  
	 * 	-TRX_NO *
	 * 	-ACIKLAMA *
	 * 	-ALICIHESAPNO *
	 * 	-BORCHESAPNO *
	 * 	-BORCMUSTERINO *
	 * 	-DOVIZKODU *
	 * 	-DURUMKODU *
	 * 	-ISLEMINYAPILDIGIYER *
	 * 	-ISLEMIYAPANADSOYAD *
	 * 	-KULLANICISICIL * 
	 * 	-ISLEMIYAPANTCKNO *
	 * 	-ISLEMIYAPANTELNO *
	 * 	-MASRAFHESAPNO *
	 * 	-MASRAFTAHSILDOVIZ *
	 * 	-MASRAFTUTARI *
	 * 	-TUTAR *
	 * 	-islemNoPTT *
	 * 	-kasaKimlikTipi *
	 * 	-EUPT_HESAP_NO *
	 *  -ISLEM_SEKLI *
	 * @return oMap
	 * 	-TRX_NO
	 * 	-ACIKLAMA
	 * 	-TUTAR
	 * 	-DOVIZKODU
	 * 	-MASRAFTUTARI
	 * 	-MASRAFTAHSILDOVIZ
	 * 	-EUPT_HESAP_NO
	 * */
	@GraymoundService("BNSPR_TRN2062_SAVE")
	public static GMMap save(GMMap iMap) {
		Connection conn = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");

			ClksHavaleGirisTx clksHavaleGirisTx = (ClksHavaleGirisTx) session
					.get(ClksHavaleGirisTx.class, iMap.getBigDecimal("TRX_NO"));
			boolean isInsert = false;
			if (clksHavaleGirisTx == null) {
				clksHavaleGirisTx = new ClksHavaleGirisTx();
				isInsert = true;
			}

			clksHavaleGirisTx.setTxNo(iMap.getBigDecimal("TRX_NO",
					clksHavaleGirisTx.getTxNo()));
			oMap.put("TRX_NO", clksHavaleGirisTx.getTxNo());
			clksHavaleGirisTx.setAciklama(iMap.getString("ACIKLAMA",
					clksHavaleGirisTx.getAciklama()));
			oMap.put("ACIKLAMA", clksHavaleGirisTx.getAciklama());
			clksHavaleGirisTx.setAliciHesapNo(iMap.getBigDecimal(
					"ALICIHESAPNO", clksHavaleGirisTx.getAliciHesapNo()));
			clksHavaleGirisTx.setBorcHesapNo(iMap.getBigDecimal("BORCHESAPNO",
					clksHavaleGirisTx.getBorcHesapNo()));
			clksHavaleGirisTx.setBorcMusteriNo(iMap.getBigDecimal(
					"BORCMUSTERINO", clksHavaleGirisTx.getBorcMusteriNo()));
			clksHavaleGirisTx.setDovizKodu(iMap.getString("DOVIZKODU",
					clksHavaleGirisTx.getDovizKodu()));
			oMap.put("DOVIZKODU", clksHavaleGirisTx.getDovizKodu());
			clksHavaleGirisTx.setDurumKodu(iMap.getString("DURUMKODU",
					clksHavaleGirisTx.getDurumKodu()));
			clksHavaleGirisTx.setIsleminYapildigiYer(iMap.getString(
					"ISLEMINYAPILDIGIYER",
					clksHavaleGirisTx.getIsleminYapildigiYer()));
			clksHavaleGirisTx.setIslemiYapanAdsoyad(iMap.getString(
					"ISLEMIYAPANADSOYAD",
					clksHavaleGirisTx.getIslemiYapanAdsoyad()));
			clksHavaleGirisTx.setIslemiYapanKullanici(iMap.getString(
					"ISLEMIYAPANKULLANICI",
					clksHavaleGirisTx.getIslemiYapanKullanici()));
			clksHavaleGirisTx
					.setIslemiYapanTckno(iMap.getString("ISLEMIYAPANTCKNO",
							clksHavaleGirisTx.getIslemiYapanTckno()));
			clksHavaleGirisTx
					.setIslemiYapanTelno(iMap.getString("ISLEMIYAPANTELNO",
							clksHavaleGirisTx.getIslemiYapanTelno()));
			clksHavaleGirisTx.setMasrafHesapNo(iMap.getBigDecimal(
					"MASRAFHESAPNO", clksHavaleGirisTx.getMasrafHesapNo()));
			clksHavaleGirisTx.setMasrafTahsilDoviz(iMap.getString(
					"MASRAFTAHSILDOVIZ",
					clksHavaleGirisTx.getMasrafTahsilDoviz()));
			oMap.put("MASRAFTAHSILDOVIZ",
					clksHavaleGirisTx.getMasrafTahsilDoviz());
			clksHavaleGirisTx.setMasrafTutari(iMap.getBigDecimal(
					"MASRAFTUTARI", clksHavaleGirisTx.getMasrafTutari()));
			oMap.put("MASRAFTUTARI", clksHavaleGirisTx.getMasrafTutari());
			clksHavaleGirisTx.setTutar(iMap.getBigDecimal("TUTAR",
					clksHavaleGirisTx.getTutar()));
			oMap.put("TUTAR", clksHavaleGirisTx.getTutar());
			clksHavaleGirisTx.setPttIslemNo(iMap.getBigDecimal("islemNoPTT",
					clksHavaleGirisTx.getPttIslemNo()));
			clksHavaleGirisTx.setKasaKimlikTipi(iMap.getBigDecimal(
					"kasaKimlikTipi", clksHavaleGirisTx.getKasaKimlikTipi()));
			clksHavaleGirisTx.setEuptHesapNo(iMap.getBigDecimal(
					"EUPT_HESAP_NO", clksHavaleGirisTx.getEuptHesapNo()));
			oMap.put("euptHesapNo", clksHavaleGirisTx.getEuptHesapNo());
			clksHavaleGirisTx.setTcKimlikNo(iMap.getString("tcNo",
					clksHavaleGirisTx.getTcKimlikNo()));
			clksHavaleGirisTx.setIslemSekli(iMap.getString("ISLEMSEKLI",
					clksHavaleGirisTx.getIslemSekli()));
			clksHavaleGirisTx.setEuptAbMusteriNo(iMap.getBigDecimal(
					"ABMUSTERINO", clksHavaleGirisTx.getEuptAbMusteriNo()));

			session.saveOrUpdate(clksHavaleGirisTx);
			session.flush();
			if (isInsert) {
				iMap.put("TRX_NAME", "2062");
				GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			}
			return oMap;
		} catch (Exception ex) {
			throw ExceptionHandler.convertException(ex);
		} finally {
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN2062_AFTER_CANCELATION")
	public static GMMap afterCancellation(GMMap iMap) {	
		try {
			GMMap sMap = new GMMap();
							
			sMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
			GMServiceExecuter.call("BNSPR_EUPT_EUPT_ISLEM_IPTAL", sMap);
														
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}	

}
