package tr.com.aktifbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Map;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.ClksPttDailyAgreement;
import tr.com.aktifbank.bnspr.dao.GnlBeyazListeHesapWsTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2790Services {
	private static Logger logger = Logger.getLogger(CurrentAccountsTRN2790Services.class);
	
	/* @ input TRX_NO
	 *         KANAL NO
	 *         HESAP NO
	 * @ output Messsage (Onay islminin oldugunu s�yler)
	 * 
	 * durumu =1 yeni kay�t 
	 */
	@GraymoundService("BNSPR_TRN2790_SAVE")
	public static Map<?, ?> whiteListSave(GMMap iMap) {
		GMMap oMap = new GMMap();
		logger.info("BNSPR_TRN2790_SAVE in:" + iMap.toString());
		try {
			
			if ((iMap.getString("E_TRXNO")==null)||(iMap.getString("E_TRXNO").isEmpty()))
			{
			String funcStr = "{ ? = call  PKG_TRN2790.Hesap_Kanal_Kontol(?,?)}";
			int i=0;
				Object [] input0Values = new Object [4];
				input0Values[i++] = BnsprType.NUMBER;
				input0Values[i++] = iMap.getBigDecimal("HESAP_NO");
				input0Values[i++] = BnsprType.NUMBER;
				input0Values[i++] = iMap.getBigDecimal("KANAL_KOD");
				oMap.put("VAR",(BigDecimal) DALUtil.callOracleFunction(funcStr, BnsprType.NUMBER, input0Values));
				
		 if (oMap.getString("VAR").equals("0")){
			BigDecimal durum =new BigDecimal(1);
			Session session = DAOSession.getSession("BNSPRDal");			
			GnlBeyazListeHesapWsTx beyazHesap= new GnlBeyazListeHesapWsTx();
			beyazHesap.setTxNo(iMap.getBigDecimal("TRX_NO"));
			beyazHesap.setKanalKod(iMap.getBigDecimal("KANAL_KOD"));
			beyazHesap.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			beyazHesap.setDurumu(durum); /* durumu=1 yeni kay�t durum =2 Silme*/
			session.saveOrUpdate(beyazHesap);
			session.flush();
			iMap.put("TRX_NAME", "2790");
		
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		 }
		 else{
			 oMap.put("MESSAGE","Bu Hesap ve Kanal Kodu daha �nceden Kay�tl�");
			 return oMap;
		 }
	     } else
	     {
	     Session session = DAOSession.getSession("BNSPRDal");
	    GnlBeyazListeHesapWsTx beyazHesap = (GnlBeyazListeHesapWsTx) session
				.get(GnlBeyazListeHesapWsTx.class,
						iMap.getBigDecimal("E_TRXNO"));
		GnlBeyazListeHesapWsTx beyazHesaptx= new GnlBeyazListeHesapWsTx();
		iMap.put("TRX_NO",iMap.getBigDecimal("TRX_NO"));
		beyazHesaptx.setTxNo(iMap.getBigDecimal("TRX_NO"));
		beyazHesaptx.setKanalKod(beyazHesap.getKanalKod());
		beyazHesaptx.setHesapNo(beyazHesap.getHesapNo());
		beyazHesaptx.setDurumu(new BigDecimal(2));
		beyazHesap.setDurumu(new BigDecimal(2));
		session.saveOrUpdate(beyazHesaptx);
		session.flush();
		iMap.put("TRX_NAME", "2790");
		return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
	     }
		} catch (Exception e)
		{
			logger.error("BNSPR_TRN2790_SAVE err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
			
	}
	@GraymoundService("BNSPR_TRN2790_DELETE")
	public static Map<?, ?> whiteListdelete(GMMap iMap) {
		GMMap oMap = new GMMap();
		logger.info("BNSPR_TRN2790_DELETE in:" + iMap.toString());
		try {
			
		   String tableName="TABLE";
			int i=0;
			for(int row = 0; row < iMap.getSize(tableName); row++) {
				if (!((iMap.getString(tableName, row, "KAYIT_NO").equals(iMap
						.getString("TRX_NO_E")))
						&& (iMap.getString(tableName, row, "HESAP_NO")
								.equals(iMap.getString("HESAP_NO")))
						&& (iMap.getString(tableName, row, "KOD")
								.equals(iMap.getString("KOD"))))) {
					oMap.put(tableName,i,"KAYIT_NO",iMap.getString(tableName, row, "KAYIT_NO"));
					oMap.put(tableName,i,"HESAP_NO",iMap.getString(tableName, row, "HESAP_NO"));
					oMap.put(tableName,i,"KISA_ISIM",iMap.getString(tableName, row, "KISA_ISIM"));
					oMap.put(tableName,i,"KOD",iMap.getString(tableName, row, "KOD"));
					oMap.put(tableName,i,"ACIKLAMA",iMap.getString(tableName, row, "ACIKLAMA"));
					oMap.put(tableName,i,"MUSTERI_NO",iMap.getString(tableName, row, "MUSTERI_NO"));
					oMap.put(tableName,i,"ISIM_UNVAN",iMap.getString(tableName, row, "ISIM_UNVAN"));
					oMap.put(tableName,i,"SERVICE_NAME",iMap.getString(tableName, row, "SERVICE_NAME"));
                    i++;
				} 
			
			}
			
			oMap.put("E_TRXNO", iMap.getString("TRX_NO_E"));
			return oMap;
			
		 }catch (Exception e)
			{
				logger.error("BNSPR_TRN2790_DELETE err: " + e);
				throw ExceptionHandler.convertException(e);
			}
	}
	@GraymoundService("BNSPR_TRN2790_LIST")
	public static Map<?, ?> whiteListListesi(GMMap iMap) {
		GMMap oMap = new GMMap();
		logger.info("BNSPR_TRN2790_LIST in:" + iMap.toString());
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String izlemetablosu = "IZLEMETABLOSU";
		int i = 0;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call  PKG_TRN2790.White_List(?)}");
			stmt.registerOutParameter(++i, -10);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(i);
			oMap = DALUtil.rSetResults(rSet, izlemetablosu);
			return oMap;
		 }catch (Exception e)
			{
				logger.error("BNSPR_TRN2790_LIST err: " + e);
				throw ExceptionHandler.convertException(e);
			}
		finally {
			logger.info("BNSPR_TRN2790_LIST out:" + oMap.toString());
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN2790_SAYAC")
	public static Map<?, ?> sayac(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("COUNT", "100");
		iMap.put("TRX_NAME", "2790");
		iMap.put("TRX_NAME", "2790");
		iMap.put("TRX_NAME", "2790");
		iMap.put("TRX_NAME", "2790");
		oMap.put("SAYAC", "100");
		
		return oMap;
	}
}
