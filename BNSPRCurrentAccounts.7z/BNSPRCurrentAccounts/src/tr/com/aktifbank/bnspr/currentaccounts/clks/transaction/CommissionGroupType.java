package tr.com.aktifbank.bnspr.currentaccounts.clks.transaction;

import java.util.EnumSet;
import java.util.Set;

import tr.com.aktifbank.bnspr.currentaccounts.accounting.CurrencyType;

public enum CommissionGroupType {

	UPT_EFT_GROUP("AKT�F BANK UPT KABUL", EnumSet.of(CurrencyType.TRY,CurrencyType.USD,CurrencyType.EUR)),
	UPT_FC_TRANSFER_LOCAL_GROUP("AKT�F BANK YP UPT KABUL", EnumSet.of(CurrencyType.TRY, CurrencyType.USD, CurrencyType.EUR)),
	UPT_FC_TRANSFER_GLOBAL_GROUP("AKT�F BANK YP UPT Y.DI�I KABUL", EnumSet.of(CurrencyType.TRY, CurrencyType.USD, CurrencyType.EUR)),
	UPT_REFUND_PAYMENT_GROUP("AKT�F BANK �ADE KABUL", EnumSet.of(CurrencyType.TRY, CurrencyType.USD, CurrencyType.EUR)),
	UPT_REFUND_PAYMENT_WITH_EXPENSE_GROUP("AKT�F BANK MASRAF DAH�L �ADE KABUL", EnumSet.of(CurrencyType.TRY, CurrencyType.USD, CurrencyType.EUR)),
	UPT_PAYMENT_GROUP("AKT�F BANK UPT �DEME", EnumSet.of(CurrencyType.TRY, CurrencyType.USD, CurrencyType.EUR)),
	UPT_EFT_PCH_GROUP("AKT�F BANK P�H �LE TL UPT", EnumSet.of(CurrencyType.TRY)),
	UPT_EFT_PCH_REFUND_GROUP("AKT�F BANK P�H �LE TL UPT �ADE", EnumSet.of(CurrencyType.TRY)),
	CASH_DEPOSIT_GROUP("AKT�F BANK NAK�T YATAN", EnumSet.of(CurrencyType.TRY, CurrencyType.USD, CurrencyType.EUR)),
	CASH_WITHDRAWAL_GROUP("AKT�F BANK NAK�T CEKME", EnumSet.of(CurrencyType.TRY, CurrencyType.USD, CurrencyType.EUR)),
	CARD_PASSO_GROUP("AKT�F BANK PASSOL�G KART", EnumSet.of(CurrencyType.TRY)),
	CARD_NKOLAY_GROUP("AKT�F BANK NKOLAY KART", EnumSet.of(CurrencyType.TRY)),
	ATM_CARD_PASSO_GROUP("AKT�F BANK PASSOL�G KART (ATM)", EnumSet.of(CurrencyType.TRY)),
	ATM_CARD_NKOLAY_GROUP("AKT�F BANK NKOLAY KART (ATM)", EnumSet.of(CurrencyType.TRY)),
	ATM_CASH_DEPOSIT_TO_ACCOUNT_GROUP("AKT�F BANK NAK�T YATAN (ATM) - HESABA", EnumSet.of(CurrencyType.TRY)),
	ATM_CASH_DEPOSIT_TO_IBAN_GROUP("AKT�F BANK NAK�T YATAN (ATM) - IBAN'A", EnumSet.of(CurrencyType.TRY)),
	INSTALLMENT_LOAN_AUTOMATION_GROUP("OTOMAT�K KRED� TAHS�LATI", EnumSet.of(CurrencyType.TRY)),
	INSTALLMENT_LOAN_GROUP("AKT�F BANK TAKS�T TAHS�LAT", EnumSet.of(CurrencyType.TRY)),
	CONSUMERLOAN_PAYMENT_GROUP("AKT�F BANK KRED� KULLANDIRIM", EnumSet.of(CurrencyType.TRY)),
	CONSUMERLOAN_APPLICATION_GROUP("AKT�F BANK KRED� BASVURU", EnumSet.of(CurrencyType.TRY)),
	CUSTOMER_ACQUISITION_GROUP("AKT�F BANK HESAP A�MA ��LEMLER�", null);
	
	private String description;
	private Set<CurrencyType> currencySet;
	
	private CommissionGroupType(String description, Set<CurrencyType> currencySet) {
		this.description = description;
		this.currencySet = currencySet;
	}
	
	@Override
	public String toString() {
		return description;
	}

	/**
	 * @return the currencySet
	 */
	public Set<CurrencyType> getCurrencySet() {
		return currencySet;
	}
}
