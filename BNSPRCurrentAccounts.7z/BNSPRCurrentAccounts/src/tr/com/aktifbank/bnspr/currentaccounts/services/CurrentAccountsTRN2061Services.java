package tr.com.aktifbank.bnspr.currentaccounts.services;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2061Services {
	
	@GraymoundService("BNSPR_TRN2061_AFTER_CANCELATION")
	public static GMMap afterCancellation(GMMap iMap) {	
		try {
			GMMap sMap = new GMMap();
							
			sMap.put("TRX_NO", iMap.getBigDecimal("ISLEM_NO"));
			GMServiceExecuter.call("BNSPR_EUPT_EUPT_ISLEM_IPTAL", sMap);
														
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}		
	}	
}
