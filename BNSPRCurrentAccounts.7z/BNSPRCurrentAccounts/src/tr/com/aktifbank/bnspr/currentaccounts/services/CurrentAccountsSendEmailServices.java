package tr.com.aktifbank.bnspr.currentaccounts.services;



import java.util.Map;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsSendEmailServices {
	

	@GraymoundService("BNSPR_TRN_SEND_EMAIL")
	public static Map<?, ?> senEmail(GMMap iMap) {
		GMMap oMap = new GMMap();
		String procStr = "{call PKG_EPOS.ws_epos_extre_mail(?,?,?,?,?)}";
		Object [] inputValues = new Object [6];
		Object [] outputValues= new Object [4];
		
		try {
			
			inputValues[0] = BnsprType.NUMBER;
			inputValues[1] = iMap.getBigDecimal("HESAP_NO");
			inputValues[2] = BnsprType.STRING;
			inputValues[3] = iMap.getString("EKSTRE_BASLANGIC_TAR");
			inputValues[4] = BnsprType.STRING;
			inputValues[5] = iMap.getString("EKSTRE_BITIS_TAR");
			
			
			outputValues[0] = BnsprType.STRING;
			outputValues[1] = "pc_unvan";
			outputValues[2] = BnsprType.STRING;
			outputValues[3] = "pc_mail";
		
			
			 oMap = (GMMap)DALUtil.callOracleProcedure(procStr, inputValues, outputValues);
			 iMap.put("MUSTERI_ADI", oMap.getString("pc_unvan"));
			 iMap.put("EPOSTA", oMap.getString("pc_mail"));
			 oMap.put("MESSAGE",GMServiceExecuter.execute("BNSPR_EKSTRE_MAIL_GONDER", iMap));
		    return oMap;

		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
