package tr.com.aktifbank.bnspr.currentaccounts.transferbatch;

import java.io.File;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.TransferBatchEntry;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.message.GMMessageFactory;
import com.graymound.server.GMServer;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.graymound.util.GMToolkit;

public class Util {
    
    public static final String PATTERN_ROOT = GMServer.getProperty("graymound.home" , null)
            + File.separator + "Server" + File.separator + "Content" + File.separator + "Root"
            + File.separator + "files" + File.separator;

    public static final String TRANSFER_FILE_PATTERN =
            new String(GMToolkit.getFileContent(new File(Util.PATTERN_ROOT + "TRANSFER_BATCH_PATTERN.TXT")));

    private static final ThreadLocal<SimpleDateFormat> regularDateTimeFormat = new ThreadLocal<SimpleDateFormat>() {

        protected SimpleDateFormat initialValue() {
            return new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        }

    };

    private static final ThreadLocal<SimpleDateFormat> regularDateFormat = new ThreadLocal<SimpleDateFormat>() {

        protected SimpleDateFormat initialValue() {
            return new SimpleDateFormat("dd/MM/yyyy");
        }

    };


    public static void throwMessage(String messageId) {
        String message = GMMessageFactory.getMessage(messageId, null);
        throw ExceptionHandler.convertException(new GMRuntimeException(0, message));
    }

    public static String limit(String str, int length) {
        if (str.length() > length) {
            return str.substring(0, length);
        }
        return str;
    }

    public static boolean isAfterToday(Date date) {

        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);

        Date today = cal.getTime();

        return date.after(today);

    }
    
    public static String getBranchCode(BigDecimal accountNumber) {
        GMMap serviceInMap = new GMMap();
        serviceInMap.put("HESAP_NO", accountNumber);
        
        return GMServiceExecuter.call("BNSPR_COMMON_GET_HESAP_SUBE_KOD", serviceInMap).getString("SUBE_KODU");
    }

    public static TransferBatchEntry findEntry(Session session, BigDecimal processId, ProcessStatus processStatus) {
        Criteria criteria = session.createCriteria(TransferBatchEntry.class)
                .add(Restrictions.eq("processId", processId));
        
        if (processStatus != null) {
            criteria.add(Restrictions.eq("processStatus", processStatus.value()));
        }
    
        TransferBatchEntry entry = (TransferBatchEntry) criteria.uniqueResult();
        
        if (entry == null) {
            throw ExceptionHandler.convertException(new GMRuntimeException(0, "Entry cannot be found with process id: " + processId));
        }
        
        return entry;
    }
    
    
    public static <T extends IEnumIdentifier> T getEnumType(Class<T> enumType, String value) {
        T[] enumConstants = enumType.getEnumConstants();
        for (int i = 0; i < enumConstants.length; i++) {
            if(enumConstants[i].value().equals(value)) {
                return enumConstants[i];
            }
        }
        return null;
    }
    
    public static String toDateTimeString(Date date) {
        return regularDateTimeFormat.get().format(date);
    }
    
    public static String toDateString(Date date) {
        return regularDateFormat.get().format(date);
    }

}
