package tr.com.aktifbank.bnspr.currentaccounts.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class CashFlowServices {

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_LIST_CASH_FLOW")
    public static GMMap listCashFlow(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();

            stmt = conn.prepareCall("{? = call Pkg_External.Nakit_Akis_Liste(?,?,?,?)}");

            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setBigDecimal(i++, iMap.getBigDecimal("CUSTOMER_NO"));
            stmt.setDate(i++, new java.sql.Date(iMap.getDate("START_DATE").getTime()));
            stmt.setDate(i++, new java.sql.Date(iMap.getDate("END_DATE").getTime()));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("ACCOUNT_NO"));

            stmt.execute();
            stmt.getMoreResults();
            rSet = (ResultSet) stmt.getObject(1);

            /* Simdilik tableName bu sekilde birakildi. */
            String tableName = "RESULTS";
            return DALUtil.rSetResults(rSet, tableName);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }

}
