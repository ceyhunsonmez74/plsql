package tr.com.aktifbank.bnspr.currentaccounts.transferbatch;


import tr.com.aktifbank.bnspr.dao.TransferBatchEntry;

import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

class TransferProcess extends AbstractProcess<TransferLineData> {
    
    TransferProcess(TransferBatchEntry entry, IProcessVisitor processVisitor) {
        super(entry, new TransferLineDataExtractor(Util.TRANSFER_FILE_PATTERN), processVisitor);
    }

    @Override
    protected ProcessStatus processInternal(TransferLineData lineData) {
        if (lineData.getType() == 'D') {
            validateAccountNumber(lineData.getToAccNo());
            
            if (Util.isAfterToday(lineData.getDate())) {
                createTransferDirective(lineData);
            } else {
                doTransfer(lineData);
            }
            
            return ProcessStatus.COMPLETED;
        }
        
        return ProcessStatus.NOT_PROCESSED;
    }
    
    private void doTransfer(TransferLineData lineData) {
        GMMap serviceInmap = new GMMap();
        
        serviceInmap.put("GONDEREN_HESAP_NO"    , getEntry().getAccountNumber());
        serviceInmap.put("GONDEREN_MUSTERI_NO"  , getEntry().getCustomerNo());
        serviceInmap.put("ALICI_HESAP_NO"       , lineData.getToAccNo());
        serviceInmap.put("ALICI_SUBE"           , Util.getBranchCode(lineData.getToAccNo()));
        serviceInmap.put("TUTAR"                , lineData.getTransactionAmount());
        serviceInmap.put("HAVALE_TIPI"          , 1);
        
        GMServiceExecuter.executeNT("BNSPR_CURRENT_ACCOUNTS_SAVE_TRANSFER", serviceInmap);
    }

    private void createTransferDirective(TransferLineData lineData) {
        GMMap serviceInmap = new GMMap();
        
        serviceInmap.put("ODEME_TIPI"           , "DUZENSIZ");
        serviceInmap.put("HVL_TIPI"             , "1");
        serviceInmap.put("ONCE_SONRA_FLAG"      , "S");
        serviceInmap.put("KMH_KULLANILSINMI"    , "H");
        serviceInmap.put("DOVIZ_KODU"           , "TRY");
        serviceInmap.put("ODEME_SEKLI"          , "HVL");
        serviceInmap.put("ILK_ODEME_TARIHI"     , lineData.getDate());
        serviceInmap.put("BITIS_TARIHI"         , lineData.getDate());
        serviceInmap.put("TUTAR"                , lineData.getTransactionAmount());
        serviceInmap.put("GON_HESAP_NO"         , getEntry().getAccountNumber());
        serviceInmap.put("HAV_SUBE_KODU"        , Util.getBranchCode(lineData.getToAccNo()));
        serviceInmap.put("HAV_HESAP_NO"         , lineData.getToAccNo());
        serviceInmap.put("HAV_ALICI_ADI"        , lineData.getName() + " " + lineData.getSurname());
        serviceInmap.put("HVL_ALICI_BABA_ADI"   , Util.limit(lineData.getFname(), 14));
        serviceInmap.put("HAV_ACIKLAMA"         , Util.limit(lineData.getDescription(), 50));
        serviceInmap.put("GON_MUSTERI_NO"       , getEntry().getCustomerNo());

        GMServiceExecuter.executeNT("BNSPR_CURRENT_ACCOUNTS_SAVE_TRANSFER_DIRECTIVE", serviceInmap);
    }

}

