package tr.com.aktifbank.bnspr.currentaccounts.accounting;

public enum CurrencyType {
	TRY, USD, EUR;

	public static CurrencyType getEnum(String code) {
		for(CurrencyType v : values())
			if(v.toString().equalsIgnoreCase(code)) return v;
		throw new IllegalArgumentException();
	}
}
