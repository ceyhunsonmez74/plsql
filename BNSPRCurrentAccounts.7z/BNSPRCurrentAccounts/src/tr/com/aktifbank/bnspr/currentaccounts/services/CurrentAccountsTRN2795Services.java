package tr.com.aktifbank.bnspr.currentaccounts.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import net.sf.jasperreports.engine.JRPrintPage;
import net.sf.jasperreports.engine.JasperPrint;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import jxl.CellType;
import jxl.DateCell;
import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import tr.com.aktifbank.bnspr.dao.IadeUptihbarnameTx;
import tr.com.aktifbank.bnspr.dao.IadeUptihbarnameTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.ReportUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2795Services {
	private static Logger logger = Logger.getLogger(CurrentAccountsTRN2795Services.class);
	 @GraymoundService("BNSPR_TRN2795_IMPORT_EXCEL")
	    public static GMMap excelToTable(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        try {
	            byte[] inputFile = (byte[]) iMap.get("FILE");
	            if (inputFile == null) {
	                iMap.put("HATA_NO", new BigDecimal(660));
	                iMap.put("P1", "Dosya se�mediniz.");
	                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
	            }
	            Workbook workbook;
	            WorkbookSettings ws = new WorkbookSettings();

	            //ws.setCharacterSet(cs);
	            ws.setEncoding("ISO-8859-9");
	            ws.setExcelDisplayLanguage("TR");
	            ws.setExcelRegionalSettings("TR");
	            ws.setLocale(new Locale("tr", "TR"));
	            try {
	                workbook = Workbook.getWorkbook(new ByteArrayInputStream(inputFile), ws);
	            } catch (Exception e) {
	                iMap.put("HATA_NO", new BigDecimal(660));
	                iMap.put("P1", "Ge�erli Bir Excel Dosyas� Se�mediniz.");
	                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
	            }
	            Sheet sheet = workbook.getSheet(0);
	            SimpleDateFormat sdfPass2 = new SimpleDateFormat("dd/MM/yyyy");
	            int t=0;
	            for (int j = 1; j < sheet.getRows(); j++) {
	                for (int i = 0; i < sheet.getColumns(); i++) {
	                    if (sheet.getCell(i, j) != null && sheet.getCell(i, j).getType().equals(CellType.DATE)) oMap.put("TABLE", t, "COLUMN_" + (i),
	                        sheet.getCell(i, j).getContents());
	                    else
	                    	 if (!sheet.getCell(i, j).getContents().isEmpty()){ 
	                    	oMap.put("TABLE", t, "COLUMN_" + (i), sheet.getCell(i, j).getContents());
	                    	 }
     
	                }
	                t++; 
	            }
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {}

	    }
	 @GraymoundService("BNSPR_TRN2795_GENERATE_REPORT")
	    public static GMMap generateReport(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        oMap = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", oMap);
	        int i;
	        try {
	            HashMap<String, Object> parameters = new HashMap<String, Object>();
	            parameters.put("BANKA_TARIHI", oMap.getDate("BANKA_TARIH"));
	           
	            if (iMap.getSize("TABLE_DATA")<1) {
	                iMap.put("HATA_NO", new BigDecimal(442));
	                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
	            }
	            i = 0;
	            for (int j = 0; j < iMap.getSize("TABLE_DATA"); j++) {
	                if (iMap.getBoolean("TABLE_DATA", j, "EKLE")) {
	                    parameters.put("ALAN_1", StringUtils.isBlank(iMap.getString("TABLE_DATA", j, "COLUMN_0")) ? "" : iMap.getString("TABLE_DATA", j, "COLUMN_0"));
	                    parameters.put("ALAN_2", StringUtils.isBlank(iMap.getString("TABLE_DATA", j, "COLUMN_1")) ? "" : iMap.getString("TABLE_DATA", j, "COLUMN_1"));
	                    parameters.put("ALAN_3", StringUtils.isBlank(iMap.getString("TABLE_DATA", j, "COLUMN_2")) ? "" : iMap.getString("TABLE_DATA", j, "COLUMN_2"));
	                    parameters.put("ALAN_4", StringUtils.isBlank(iMap.getString("TABLE_DATA", j, "COLUMN_3")) ? "" : iMap.getString("TABLE_DATA", j, "COLUMN_3"));
	                    parameters.put("ALAN_5", StringUtils.isBlank(iMap.getString("TABLE_DATA", j, "COLUMN_5")) ? "" : iMap.getString("TABLE_DATA", j, "COLUMN_5"));
	                    parameters.put("ALAN_6", StringUtils.isBlank(iMap.getString("TABLE_DATA", j, "COLUMN_6")) ? "" : iMap.getString("TABLE_DATA", j, "COLUMN_6"));
	                    parameters.put("ALAN_7", StringUtils.isBlank(iMap.getString("TABLE_DATA", j, "COLUMN_6")) ? "" : iMap.getString("TABLE_DATA", j, "COLUMN_6"));
	        
	                    parameters.put("ALAN_9", StringUtils.isBlank(iMap.getString("TABLE_DATA", j, "COLUMN_7")) ? "" : iMap.getString("TABLE_DATA", j, "COLUMN_7"));
	                    parameters.put("ALAN_10",StringUtils.isBlank(iMap.getString("TABLE_DATA", j, "COLUMN_8")) ? "" : iMap.getString("TABLE_DATA", j, "COLUMN_8"));
	                    parameters.put("ALAN_11",StringUtils.isBlank(iMap.getString("TABLE_DATA", j, "COLUMN_9")) ? "":  iMap.getString("TABLE_DATA", j, "COLUMN_9"));
	                    parameters.put("ALAN_12",StringUtils.isBlank(iMap.getString("TABLE_DATA", j, "COLUMN_10")) ? "": iMap.getString("TABLE_DATA", j, "COLUMN_10"));
	                  
	                    oMap.put("REPORT_" + i, ReportUtil.generateReport("BNSPR_TRN2795_IADE_UPT_IHBARNAME_BASIM", parameters));
	                    i++;

	                }
	            }
	            oMap.put("REPORT_COUNT", i);

	            oMap.putAll(printAll(oMap));

	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {}

	    }
	 public static GMMap printAll(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        JasperPrint tmp;
	        JasperPrint result = (JasperPrint) iMap.get("REPORT_0");

	        for (int j = 1; j < iMap.getInt("REPORT_COUNT"); j++) {
	            tmp = (JasperPrint) iMap.get("REPORT_" + j);
	            for (Object jasperPrintPage : tmp.getPages()) {
	                result.addPage((JRPrintPage) jasperPrintPage);
	            }
	        }
	        oMap.put("REPORT_ALL", result);
	        return oMap;
	    }
	    @GraymoundService("BNSPR_TRN2795_SELECT_ALL")
	    public static GMMap selectAll(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        try {
	            if (iMap.getBoolean("CHECKED")) {
	                for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
	                    iMap.put("TABLE_DATA", i, "EKLE", true);
	                }
	            } else {
	                for (int i = 0; i < iMap.getSize("TABLE_DATA"); i++) {
	                    iMap.put("TABLE_DATA", i, "EKLE", false);
	                }
	            }
	            oMap.put("TABLE_DATA", iMap.get("TABLE_DATA"));
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {}

	    }
	    @GraymoundService("BNSPR_TRN2795_SAVE")
	    public static GMMap save2795(GMMap iMap) {
	        Session session = DAOSession.getSession("BNSPRDal");
	        int selectedRecords = 0;
	        GMMap oMap = new GMMap();
	        try {
	        	BigDecimal txNo= BigDecimal.ZERO;
	           /* List<?> ihbarnameList = session.createCriteria(IadeUptihbarnameTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	            Object[] arrayTeminatlar = ihbarnameList.toArray();
	            for (Object element : arrayTeminatlar) {
	            	ihbarnameList.remove(element);
	                session.delete(element);
	            }
	            session.flush();
	            */
	        	BigDecimal j = BigDecimal.ZERO;
	            String tableName = "TABLE_DATA";
	            if (iMap.getSize(tableName)<=0) {
	                iMap.put("HATA_NO", new BigDecimal(985));
	                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
	            }
	            int i=0;
	            for (int k = 0; k < iMap.getSize("TABLE_DATA"); k++) {
	                if (iMap.getBoolean("TABLE_DATA", k, "EKLE")) {
	                    i++;
	                    if (i > 25) {
	                        iMap.put("HATA_NO", new BigDecimal(660));
	                        iMap.put("P1", "25'den fazla rapor se�ilemez");
	                        return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
	                    }
	                }
	            }
	            
	            for (i = 0; i < iMap.getSize(tableName); i++) {
	                if (iMap.getBoolean(tableName, i, "EKLE")) {
	                   
	            		GMMap servisMap = new GMMap();
	            		servisMap.put("TABLE_NAME", "HESAP_HAREKET_NO");
	            		BigDecimal idNo = (BigDecimal)GMServiceExecuter.execute("BNSPR_COMMON_GET_GENEL_ID", servisMap).get("ID");

	                    IadeUptihbarnameTx iadeUptihbarnameTx = new IadeUptihbarnameTx();
	                    IadeUptihbarnameTxId iadeUptihbarnameTxId = new IadeUptihbarnameTxId();
	                    
	                    txNo= createTx();
	                    iMap.put ("TRX_NO"+selectedRecords, txNo);
	                    
	                    selectedRecords++;
	                    
	                    iadeUptihbarnameTxId.setIdNo(idNo);
	                    iadeUptihbarnameTxId.setTxNo(txNo);
	                    
	                    iadeUptihbarnameTx.setGonderenAdSoyadi(iMap.getString(tableName, i, "COLUMN_0"));
	                    iadeUptihbarnameTx.setEftTarihi(iMap.getString(tableName, i, "COLUMN_1"));
	                    iadeUptihbarnameTx.setIsleminYapildigiYer(iMap.getString(tableName, i, "COLUMN_2"));
	                    iadeUptihbarnameTx.setEftSorguNo(iMap.getString(tableName, i, "COLUMN_3"));
	                    iadeUptihbarnameTx.setTutar(iMap.getString(tableName, i, "COLUMN_4"));
	                    iadeUptihbarnameTx.setBasimTarihi(iMap.getString(tableName, i, "COLUMN_5"));
	                    iadeUptihbarnameTx.setAdres(iMap.getString(tableName, i, "COLUMN_6"));
	                   //iadeUptihbarnameTx.setBanka(iMap.getString(tableName, i, "COLUMN_7"));   
	                    iadeUptihbarnameTx.setOnaylayan1AdSoyad(iMap.getString(tableName, i, "COLUMN_7"));
	                    iadeUptihbarnameTx.setOnaylayan1Unvan(iMap.getString(tableName, i, "COLUMN_8"));	                    
	                    iadeUptihbarnameTx.setOnaylayan2AdSoyad(iMap.getString(tableName, i, "COLUMN_9"));
	                    iadeUptihbarnameTx.setOnaylayan2Unvan(iMap.getString(tableName, i, "COLUMN_10"));
	                    iadeUptihbarnameTx.setId(iadeUptihbarnameTxId);
	                    session.save(iadeUptihbarnameTx);
	                }
	                
	            }
	            if (selectedRecords<=0) {
	                iMap.put("HATA_NO", new BigDecimal(442));
	                return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
	            }
	            session.flush();
	            iMap.put("TRX_NAME", "2795");
	            for (i = 0; i < selectedRecords; i++) {
	            	
	            	 BigDecimal currentTxNo= iMap.getBigDecimal("TRX_NO"+i);
	            	 iMap.put ("TRX_NO", currentTxNo);
	            	 GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
	            	
	            }
	            //i�lemler ba�ar�l�
	            iMap.put("MESSAGE_NO", 1544);
     			oMap.put("MESSAGE",GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
     			
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {}

	    }
	    
	    @GraymoundService("BNSPR_TRN2795_GET_INFO")
	    public static GMMap getInfo1053(GMMap iMap) {
	        GMMap oMap = new GMMap();
	        Session session = DAOSession.getSession("BNSPRDal");
	        try {
	            String tableName = "TABLE_DATA";
	            int row = 0;
	            List<?> ihbarnameList = session.createCriteria(IadeUptihbarnameTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	            for(Iterator<?> iterator = ihbarnameList.iterator(); iterator.hasNext();){
	            	IadeUptihbarnameTx iadeUptihbarnameTx = (IadeUptihbarnameTx) iterator.next();
	                oMap.put(tableName, row,  "COLUMN_0", iadeUptihbarnameTx.getGonderenAdSoyadi());
	                oMap.put(tableName, row,  "COLUMN_1", iadeUptihbarnameTx.getEftTarihi());
	                oMap.put(tableName, row,  "COLUMN_2", iadeUptihbarnameTx.getIsleminYapildigiYer());
	                oMap.put(tableName, row,  "COLUMN_3", iadeUptihbarnameTx.getEftSorguNo());
	                oMap.put(tableName, row,  "COLUMN_4", iadeUptihbarnameTx.getTutar());
	                oMap.put(tableName, row,  "COLUMN_5", iadeUptihbarnameTx.getBasimTarihi());
	                oMap.put(tableName, row,  "COLUMN_6", iadeUptihbarnameTx.getAdres());
	                oMap.put(tableName, row,  "COLUMN_7", iadeUptihbarnameTx.getOnaylayan1AdSoyad());
	                oMap.put(tableName, row,  "COLUMN_8", iadeUptihbarnameTx.getOnaylayan1Unvan());
	                oMap.put(tableName, row,  "COLUMN_9", iadeUptihbarnameTx.getOnaylayan2AdSoyad());
	                oMap.put(tableName, row,  "COLUMN_10", iadeUptihbarnameTx.getOnaylayan2Unvan());
	                oMap.put(tableName, row,  "EKLE", true);
	                row++;
	            }
	            Object onaylanabilirMi =  DALUtil.callOneParameterFunction("{? = call PKG_TX.Onaylanabilir_mi(?)}" ,Types.NUMERIC , iMap.getBigDecimal("TRX_NO"));
	            Object islemTamamlanmisMi = DALUtil.callOneParameterFunction("{? = call PKG_TX.Islem_tamamlanmis_mi(?)}" , Types.NUMERIC  , iMap.getBigDecimal("TRX_NO"));
	            String enabled = "false";
	            if (onaylanabilirMi.toString().equals("1")|| islemTamamlanmisMi.toString().equals("0"))
	            {
	                enabled = "true";
	            }
	            oMap.put("BUTTON_RAPOR_ENABLED" , enabled);    
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {}

	    }
	    
	    public static BigDecimal createTx(){
	    	GMMap oMapN = new GMMap();
			oMapN = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", oMapN);
			return oMapN.getBigDecimal("TRX_NO");
		}
	}


