package tr.com.aktifbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.ClksPromosyonBasvuruTx;
import tr.com.aktifbank.bnspr.dao.ClksPromosyonKimlikTx;
import tr.com.aktifbank.bnspr.dao.ClksPromosyonSgkTx;
import tr.com.aktifbank.bnspr.dao.ClksPromosyonSgkTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2918Services {

	private static Logger logger = Logger.getLogger(CurrentAccountsTRN2918Services.class);
	
	@GraymoundService("BNSPR_TRN2918_GET_APPLICATION_NO")
	public static GMMap getApplicationNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("BASVURU_NO", new BigDecimal(DALUtil.getResult("select seq_clks_promosyon_basvuru.nextval from dual")));
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN2918_SAVE")
	public static GMMap save(GMMap iMap) {
	
		BigDecimal tutar = BigDecimal.ZERO;
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksPromosyonBasvuruTx clksPromosyonBasvuruTx = (ClksPromosyonBasvuruTx) session.get(ClksPromosyonBasvuruTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(clksPromosyonBasvuruTx == null) {
				clksPromosyonBasvuruTx = new ClksPromosyonBasvuruTx();
				clksPromosyonBasvuruTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}

			clksPromosyonBasvuruTx.setPostaCekiHesapNumarasi(iMap.getBigDecimal("POSTA_CEKI_HESAP_NUMARASI"));
			clksPromosyonBasvuruTx.setSgkPromosyonKademesi(iMap.getString("SGK_PROMOSYON_KADEMESI"));
			clksPromosyonBasvuruTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			clksPromosyonBasvuruTx.setBasvuruNo(iMap.getBigDecimal("BASVURU_NO"));
			clksPromosyonBasvuruTx.setIsleminYapildigiSubeId(iMap.getString("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMIN_YAPILDIGI_SUBE_ID"));
			clksPromosyonBasvuruTx.setIslemiYapanKullanici(iMap.getString("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI"));
			clksPromosyonBasvuruTx.setIslemiYapanKullaniciSicil(iMap.getString("ISYERI_VE_KULLANICI_BILGILERI", 0, "ISLEMI_YAPAN_KULLANICI_SICIL"));
			clksPromosyonBasvuruTx.setPttIslemNo(iMap.getBigDecimal("ISYERI_VE_KULLANICI_BILGILERI", 0, "PTT_ISLEM_NO"));
			session.saveOrUpdate(clksPromosyonBasvuruTx);
			
			ClksPromosyonKimlikTx clksPromosyonKimlikTx = (ClksPromosyonKimlikTx) session.get(ClksPromosyonKimlikTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(clksPromosyonKimlikTx == null) {
				clksPromosyonKimlikTx = new ClksPromosyonKimlikTx(iMap.getBigDecimal("TRX_NO"));
			}
			
			clksPromosyonKimlikTx.setAdi(iMap.getString("KPS_BILGILERI", 0, "ADI"));
			clksPromosyonKimlikTx.setAnneAdi(iMap.getString("KPS_BILGILERI", 0, "ANNE_ADI"));
			clksPromosyonKimlikTx.setAnneKizlikSoyadi(iMap.getString("ANNE_KIZLIK_SOYADI"));
			clksPromosyonKimlikTx.setBabaAdi(iMap.getString("KPS_BILGILERI", 0, "BABA_ADI"));
			clksPromosyonKimlikTx.setCepTelAlanKodu(iMap.getString("CEP_TEL_KOD"));
			clksPromosyonKimlikTx.setCepTelNo(iMap.getString("CEP_TEL_NO"));
			clksPromosyonKimlikTx.setCinsiyet(iMap.getString("KPS_BILGILERI", 0, "CINSIYET"));
			clksPromosyonKimlikTx.setDogumTarihi(iMap.getDate("KPS_BILGILERI", 0, "DOGUM_TARIHI"));
			clksPromosyonKimlikTx.setDogumYeri(iMap.getString("KPS_BILGILERI", 0, "DOGUM_YERI"));
			clksPromosyonKimlikTx.setEvAdresAps(iMap.getString("APS_BILGILERI", 0, "EV_ADRES"));
			clksPromosyonKimlikTx.setEvAdrIlceKodAps(iMap.getString("APS_BILGILERI", 0, "EV_ADR_ILCE_KOD"));
			clksPromosyonKimlikTx.setEvAdrIlKodAps(iMap.getString("APS_BILGILERI", 0, "EV_ADR_IL_KOD"));
			clksPromosyonKimlikTx.setEvPostakodAps(iMap.getString("APS_BILGILERI", 0, "EV_POSTAKOD"));
			clksPromosyonKimlikTx.setEvTelAlanKodu(iMap.getString("EV_TEL_KOD"));
			clksPromosyonKimlikTx.setEvTelNo(iMap.getString("EV_TEL_KOD"));
			clksPromosyonKimlikTx.setFAdresBilgileriUyumlu(iMap.getString("F_ADRES_BILGILERI_UYUMLU"));
			clksPromosyonKimlikTx.setFApsYapildi(iMap.getString("F_APS_YAPILDI"));
			clksPromosyonKimlikTx.setFKimlikBilgileriUyumlu(iMap.getString("F_KIMLIK_BILGILERI_UYUMLU"));
			clksPromosyonKimlikTx.setFKpsYapildi(iMap.getString("F_KPS_YAPILDI"));
			clksPromosyonKimlikTx.setIkinciAdi(iMap.getString("KPS_BILGILERI", 0, "IKINCI_AD"));
			clksPromosyonKimlikTx.setKayipKimlikSeriNo(iMap.getString("KPS_BILGILERI", 0, "KAYIP_KIMLIK_SERI_NO"));
			clksPromosyonKimlikTx.setKayipKimlikSiraNo(iMap.getString("KPS_BILGILERI", 0, "KAYIP_KIMLIK_SIRA_NO"));
			clksPromosyonKimlikTx.setKimlikKayitNo(iMap.getString("KPS_BILGILERI", 0, "KIMLIK_KAYIT_NO"));
			clksPromosyonKimlikTx.setKimlikSeriNo(iMap.getString("KPS_BILGILERI", 0, "KIMLIK_SERI_NO"));
			clksPromosyonKimlikTx.setKimlikSeriNoKps(iMap.getString("KPS_BILGILERI", 0, "KIMLIK_SERI_NO"));
			clksPromosyonKimlikTx.setKimlikSiraNo(iMap.getString("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO"));
			clksPromosyonKimlikTx.setKimlikSiraNoKps(iMap.getString("KPS_BILGILERI", 0, "KIMLIK_SIRA_NO"));
			clksPromosyonKimlikTx.setMedeniHal(iMap.getString("KPS_BILGILERI", 0, "MEDENI_HAL"));
			clksPromosyonKimlikTx.setNufusAileSiraNo(iMap.getString("KPS_BILGILERI", 0, "NUFUS_AILE_SIRA_NO"));
			clksPromosyonKimlikTx.setNufusCiltNo(iMap.getString("KPS_BILGILERI", 0, "NUFUS_CILT_NO"));
			clksPromosyonKimlikTx.setNufusIlceKod(iMap.getString("KPS_BILGILERI", 0, "NUFUS_ILCE_KOD"));
			clksPromosyonKimlikTx.setNufusIlKod(iMap.getString("KPS_BILGILERI", 0, "NUFUS_IL_KOD"));
			clksPromosyonKimlikTx.setNufusMahalle(iMap.getString("KPS_BILGILERI", 0, "MAHALLE_KOY"));
			clksPromosyonKimlikTx.setNufusSiraNo(iMap.getString("KPS_BILGILERI", 0, "NUFUS_SIRA_NO"));
			clksPromosyonKimlikTx.setNufusVerildigiYer(iMap.getString("KPS_BILGILERI", 0, "NUFUS_VERILDIGI_YER"));
			clksPromosyonKimlikTx.setNufusVerilisNedeni(iMap.getString("KPS_BILGILERI", 0, "NUFUS_VERILIS_NEDENI"));
			clksPromosyonKimlikTx.setNufusVerilisTarihi(iMap.getDate("KPS_BILGILERI", 0, "NUFUS_VERILIS_TARIHI"));
			clksPromosyonKimlikTx.setSoyadi(iMap.getString("KPS_BILGILERI", 0, "SOYADI"));
			clksPromosyonKimlikTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			session.saveOrUpdate(clksPromosyonKimlikTx);
			
			String[] data = iMap.getString("SGK_BRUT_MAAS_TUTARI").split("#");
			int count = Integer.parseInt(data[0]);

			for(int i = 1; i <= count * 2; i++) {
				
				// Case: Aylik Id
				if(i % 2 == 0) {
					
					ClksPromosyonSgkTxId id = new ClksPromosyonSgkTxId(iMap.getBigDecimal("TRX_NO"), data[i]);
					ClksPromosyonSgkTx clksPromosyonSgkTx = (ClksPromosyonSgkTx) session.get(ClksPromosyonSgkTx.class, id);
					
					if(clksPromosyonSgkTx == null) {
						clksPromosyonSgkTx = new ClksPromosyonSgkTx(id);
					}
					
					clksPromosyonSgkTx.setSgkBrutMaasTutari(tutar);
					session.saveOrUpdate(clksPromosyonSgkTx);
				} 
				
				// Case: Tutar
				else {
					tutar = new BigDecimal(data[i]);
				}
			}
			
			session.flush();
			
			iMap.put("TRX_NAME" , "2918");
            return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		}
		
		catch(Exception e) {
			logger.error("BNSPR_TRN2918_SAVE err: " + e);
            throw ExceptionHandler.convertException(e);
		}
	}
}
