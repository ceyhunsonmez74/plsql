package tr.com.calikbank.bnspr.currentaccounts.services;

import java.sql.Types;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.DbsAcente;
import tr.com.aktifbank.bnspr.dao.DbsAcenteSube;
import tr.com.aktifbank.bnspr.dao.DbsAcenteSubeTx;
import tr.com.aktifbank.bnspr.dao.DbsAcenteSubeTxId;
import tr.com.aktifbank.bnspr.dao.DbsAcenteTx;
import tr.com.aktifbank.bnspr.dao.DbsAcenteTxId;
import tr.com.aktifbank.bnspr.dao.DbsAnaFirma;
import tr.com.aktifbank.bnspr.dao.DbsAnaFirmaTx;
import tr.com.aktifbank.bnspr.dao.DbsAnaFirmaTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsTRN2095Services {
	
	@GraymoundService("BNSPR_TRN2095_GET_COMBOBOX_INITIAL_VALUES")
	public static GMMap getComboboxInitialValues(GMMap iMap) {
		
		//Combobox de�erlerinin tan�mlanmas�
		GMMap oMap = new GMMap();
		
		getDurum(oMap, "DURUM");
		getKredili(oMap, "KREDI");
		getMerkezSube(oMap, "MERKEZ_SUBE");
		return oMap;
	}

	public static void getDurum(GMMap oMap, String listName) {
		GuimlUtil.wrapMyCombo(oMap, listName, "G", "Ge�erli");
		GuimlUtil.wrapMyCombo(oMap, listName, "I", "�ptal");
	}
	
	public static void getKredili(GMMap oMap, String listName) {
		GuimlUtil.wrapMyCombo(oMap, listName, "E", "Evet");
		GuimlUtil.wrapMyCombo(oMap, listName, "H", "Hay�r");
	}
	public static void getMerkezSube(GMMap oMap, String listName) {
		GuimlUtil.wrapMyCombo(oMap, listName, "M", "Merkez");
		GuimlUtil.wrapMyCombo(oMap, listName, "S", "Sube");
	}
	
	@GraymoundService("BNSPR_TRN2095_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "ANAFIRMA";
			String tableName2= "ACENTE_INFO";
			String tableName3 = "ACENTE_SUBE_INFO";
			
			//Anafirma
			if(iMap.get(tableName) != null) {
				List<?> list = (List<?>) iMap.get(tableName);
				if(list.size() > 0) {
					for (int i = 0; i < list.size(); i++) {
						DbsAnaFirmaTx birAnaFirmaTx = new DbsAnaFirmaTx();
				
						DbsAnaFirmaTxId id = new DbsAnaFirmaTxId();
				
						id.setTxNo(iMap.getBigDecimal("TRX_NO"));
						id.setId(iMap.getBigDecimal(tableName, i, "ID"));
						birAnaFirmaTx.setId(id);
				
						birAnaFirmaTx.setKurumAdi(iMap.getString(tableName, i, "KURUM"));
						birAnaFirmaTx.setMusteriNo(iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
						birAnaFirmaTx.setEftBankaKodu(iMap.getString(tableName, i, "EFT_BANKA"));
						birAnaFirmaTx.setEftIlKodu(iMap.getString(tableName, i, "EFT_IL"));
						birAnaFirmaTx.setEftSubeKodu(iMap.getString(tableName, i, "EFT_SUBE"));
						birAnaFirmaTx.setEftHesapNo(iMap.getString(tableName, i, "EFT_HESAP_NO"));
						birAnaFirmaTx.setHesapNo(iMap.getBigDecimal(tableName, i, "KURUM_HESAP_NO"));
						birAnaFirmaTx.setDurum(iMap.getString(tableName, i, "DURUM"));
						
						//Acente
						if(iMap.get(tableName, i, tableName2) != null) {
							List<?> list2 = (List<?>) iMap.get(tableName, i, tableName2);
							if(list2.size() > 0) {
								for (int j = 0; j < list2.size(); j++) {
									GMMap acenteMap = new GMMap((HashMap<?, ?>)list2.get(j));
									
									DbsAcenteTx birAcenteTx = new DbsAcenteTx();
									
									DbsAcenteTxId Aid = new DbsAcenteTxId();
									
									Aid.setTxNo(iMap.getBigDecimal("TRX_NO"));
									Aid.setId(acenteMap.getBigDecimal("ID"));
									birAcenteTx.setId(Aid);
									
									birAcenteTx.setAnaFirmaId(acenteMap.getBigDecimal("ANAFIRMA_ID"));
									birAcenteTx.setKurumAdi(acenteMap.getString("KURUM"));
									birAcenteTx.setDurum(acenteMap.getString("DURUM"));
					
									//Acente Sube
									if(acenteMap.get(tableName3) != null) {
										List<?> list3 = (List<?>) acenteMap.get(tableName3);
										if(list3.size() > 0) {
											for (int k = 0; k < list3.size(); k++) {
												GMMap acenteSubeMap = new GMMap((HashMap<?, ?>)list3.get(k));
												
												DbsAcenteSubeTx birAcenteSubeTx = new DbsAcenteSubeTx();
												
												DbsAcenteSubeTxId Sid = new DbsAcenteSubeTxId();
												
												Sid.setTxNo(iMap.getBigDecimal("TRX_NO"));
												Sid.setId(acenteSubeMap.getBigDecimal("ID"));
												birAcenteSubeTx.setId(Sid);
												
												birAcenteSubeTx.setAcenteId(acenteSubeMap.getBigDecimal("ACENTE_ID"));
												birAcenteSubeTx.setSubeAdi(acenteSubeMap.getString("SUBE"));
												birAcenteSubeTx.setIataKodu(acenteSubeMap.getString("IATA"));
												birAcenteSubeTx.setMusteriNo(acenteSubeMap.getBigDecimal("MUSTERI_NO"));
												birAcenteSubeTx.setVdszHesapNo(acenteSubeMap.getBigDecimal("VADESIZ_HESAP_NO"));
												birAcenteSubeTx.setKrediliMi(acenteSubeMap.getString("KREDILI_MI"));
												birAcenteSubeTx.setKrdHesapNo(acenteSubeMap.getBigDecimal("KREDI_HESAP_NO"));
												birAcenteSubeTx.setLimit(acenteSubeMap.getBigDecimal("LIMIT"));
												birAcenteSubeTx.setDurum(acenteSubeMap.getString("DURUM"));
												birAcenteSubeTx.setMerkezSube(acenteSubeMap.getString("MERKEZ_SUBE"));
												session.save(birAcenteSubeTx);
												session.flush();
											}
										}
									}
					
									session.save(birAcenteTx);
									session.flush();
								}
							}
						}
				
						session.save(birAnaFirmaTx);
						session.flush();
					}
				}
			}
	
			iMap.put("TRX_NAME", "2095");		
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2095_GET_ANA_FIRMA_LIST")
	public static GMMap getAnaFirmaList(GMMap iMap) {
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(DbsAnaFirma.class).list();
			
			GMMap oMap = new GMMap();
			String tableName = "ANAFIRMA";
			int row = 0;
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				DbsAnaFirma birDbsAnaFirma = (DbsAnaFirma) iterator.next();

				oMap.put(tableName, row, "ID", birDbsAnaFirma.getId());
				
				oMap.put(tableName, row, "KURUM", birDbsAnaFirma.getKurumAdi());
				oMap.put(tableName, row, "MUSTERI_NO", birDbsAnaFirma.getMusteriNo());
				oMap.put(tableName, row, "EFT_BANKA", birDbsAnaFirma.getEftBankaKodu());
				oMap.put(tableName, row, "EFT_IL", birDbsAnaFirma.getEftIlKodu());
				oMap.put(tableName, row, "EFT_SUBE", birDbsAnaFirma.getEftSubeKodu());
				oMap.put(tableName, row, "EFT_HESAP_NO", birDbsAnaFirma.getEftHesapNo());
				oMap.put(tableName, row, "KURUM_HESAP_NO", birDbsAnaFirma.getHesapNo());
				oMap.put(tableName, row, "DURUM", birDbsAnaFirma.getDurum());
				oMap.put(tableName, row, "DBCHECK", "OK");
				oMap.put(tableName, row, "ACENTE_INFO", GMServiceExecuter.call("BNSPR_TRN2095_GET_ACENTE_LIST", new GMMap().put("ID", birDbsAnaFirma.getId())).get("ACENTE"));
								
				row++;
			}
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN2095_GET_ACENTE_LIST")
	public static GMMap getAcenteList(GMMap iMap) {
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> list = (List<?>) session.createCriteria(DbsAcente.class).add(Restrictions.eq("anaFirmaId", iMap.getBigDecimal("ID"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "ACENTE";
			int row = 0;
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				DbsAcente birDbsAcente = (DbsAcente) iterator.next();

				oMap.put(tableName, row, "ID", birDbsAcente.getId());
				oMap.put(tableName, row, "ANAFIRMA_ID", birDbsAcente.getAnaFirmaId());
				oMap.put(tableName, row, "KURUM", birDbsAcente.getKurumAdi());
				oMap.put(tableName, row, "DURUM", birDbsAcente.getDurum());
				oMap.put(tableName, row, "DBCHECK", "OK");
				oMap.put(tableName, row, "ACENTE_SUBE_INFO", GMServiceExecuter.call("BNSPR_TRN2095_GET_ACENTE_SUBE_LIST", new GMMap().put("ID", birDbsAcente.getId())).get("ACENTE_SUBE"));
				
				row++;
			}
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN2095_GET_ACENTE_SUBE_LIST")
	public static GMMap getAcenteSubeList(GMMap iMap) {
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> list = (List<?>) session.createCriteria(DbsAcenteSube.class).add(Restrictions.eq("acenteId", iMap.getBigDecimal("ID"))).list();;
			
			GMMap oMap = new GMMap();
			String tableName = "ACENTE_SUBE";
			int row = 0;
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				DbsAcenteSube birDbsAcenteSube = (DbsAcenteSube) iterator.next();

				oMap.put(tableName, row, "ID", birDbsAcenteSube.getId());
				oMap.put(tableName, row, "ACENTE_ID", birDbsAcenteSube.getAcenteId());
				oMap.put(tableName, row, "SUBE", birDbsAcenteSube.getSubeAdi());
				oMap.put(tableName, row, "IATA", birDbsAcenteSube.getIataKodu());
				oMap.put(tableName, row, "KREDILI_MI", birDbsAcenteSube.getKrediliMi());
				oMap.put(tableName, row, "MUSTERI_NO", birDbsAcenteSube.getMusteriNo());
				oMap.put(tableName, row, "VADESIZ_HESAP_NO", birDbsAcenteSube.getVdszHesapNo());
				oMap.put(tableName, row, "KREDI_HESAP_NO", birDbsAcenteSube.getKrdHesapNo());
				oMap.put(tableName, row, "LIMIT",DALUtil.callOneParameterFunction("{? = call PKG_DBS_THY.get_dbs_thy_kredi_limit(?)}", Types.DECIMAL,birDbsAcenteSube.getMusteriNo()));
				oMap.put(tableName, row, "KULLANILABILIR_LIMIT",DALUtil.callOneParameterFunction("{? = call PKG_DBS_THY.get_dbs_thy_kredi_kull_limit(?)}", Types.DECIMAL,birDbsAcenteSube.getMusteriNo()));
				//oMap.put(tableName, row, "LIMIT", LovHelper.diLov(birDbsAcenteSube.getKrdHesapNo(), birDbsAcenteSube.getMusteriNo(), birDbsAcenteSube.getMusteriNo(), "2095/LOV_KREDI_HESABI", "LIMIT"));				
				//oMap.put(tableName, row, "KULLANILABILIR_LIMIT", LovHelper.diLov(birDbsAcenteSube.getKrdHesapNo(), birDbsAcenteSube.getMusteriNo(), birDbsAcenteSube.getMusteriNo(), "2095/LOV_KREDI_HESABI", "KULL_LIMIT"));
				oMap.put(tableName, row, "DURUM", birDbsAcenteSube.getDurum());
				oMap.put(tableName, row, "MERKEZ_SUBE", birDbsAcenteSube.getMerkezSube());
				oMap.put(tableName, row, "DBCHECK", "OK");
				
				row++;
			}
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
	@GraymoundService("BNSPR_TRN2095_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> list = (List<?>) session.createCriteria(DbsAnaFirmaTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			
			GMMap oMap = new GMMap();
			String tableName = "ANAFIRMA";
			int row = 0;
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				DbsAnaFirmaTx dbsAnaFirmaTx = (DbsAnaFirmaTx) iterator.next();

				oMap.put(tableName, row, "ID", dbsAnaFirmaTx.getId().getId());
				
				oMap.put(tableName, row, "KURUM", dbsAnaFirmaTx.getKurumAdi());
				oMap.put(tableName, row, "MUSTERI_NO", dbsAnaFirmaTx.getMusteriNo());
				oMap.put(tableName, row, "EFT_BANKA", dbsAnaFirmaTx.getEftBankaKodu());
				oMap.put(tableName, row, "EFT_IL", dbsAnaFirmaTx.getEftIlKodu());
				oMap.put(tableName, row, "EFT_SUBE", dbsAnaFirmaTx.getEftSubeKodu());
				oMap.put(tableName, row, "EFT_HESAP_NO", dbsAnaFirmaTx.getEftHesapNo());
				oMap.put(tableName, row, "KURUM_HESAP_NO", dbsAnaFirmaTx.getHesapNo());
				oMap.put(tableName, row, "DURUM", dbsAnaFirmaTx.getDurum());
				oMap.put(tableName, row, "DBCHECK", "OK");
				//oMap.put(tableName, row, "ACENTE_INFO", GMServiceExecuter.call("BNSPR_TRN2095_GET_ACENTE_LIST", new GMMap().put("ID", birDbsAnaFirmaTx.getId())).get("ACENTE"));

				List<?> list2 = (List<?>) session.createCriteria(DbsAcenteTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("anaFirmaId", dbsAnaFirmaTx.getId().getId())).list();
				
				GMMap oMap2 = new GMMap();
				String tableName2 = "ACENTE";
				int row2 = 0;
				
				for (Iterator<?> iterator2 = list2.iterator(); iterator2.hasNext();) {
					DbsAcenteTx dbsAcenteTx = (DbsAcenteTx) iterator2.next();

					oMap2.put(tableName2, row2, "ID", dbsAcenteTx.getId().getId());
					oMap2.put(tableName2, row2, "ANAFIRMA_ID", dbsAcenteTx.getAnaFirmaId());
					oMap2.put(tableName2, row2, "KURUM", dbsAcenteTx.getKurumAdi());
					oMap2.put(tableName2, row2, "DURUM", dbsAcenteTx.getDurum());
					oMap2.put(tableName2, row2, "DBCHECK", "OK");
					
					List<?> list3 = (List<?>) session.createCriteria(DbsAcenteSubeTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("acenteId", dbsAcenteTx.getId().getId())).list();;
	
					GMMap oMap3 = new GMMap();
					String tableName3 = "ACENTE_SUBE";
					int row3 = 0;
					
					for (Iterator<?> iterator3 = list3.iterator(); iterator3.hasNext();) {
						DbsAcenteSubeTx dbsAcenteSubeTx = (DbsAcenteSubeTx) iterator3.next();

						oMap3.put(tableName3, row3, "ID", dbsAcenteSubeTx.getId().getId());
						oMap3.put(tableName3, row3, "ACENTE_ID", dbsAcenteSubeTx.getAcenteId());
						oMap3.put(tableName3, row3, "SUBE", dbsAcenteSubeTx.getSubeAdi());
						oMap3.put(tableName3, row3, "IATA", dbsAcenteSubeTx.getIataKodu());
						oMap3.put(tableName3, row3, "KREDILI_MI", dbsAcenteSubeTx.getKrediliMi());
						oMap3.put(tableName3, row3, "MUSTERI_NO", dbsAcenteSubeTx.getMusteriNo());
						oMap3.put(tableName3, row3, "VADESIZ_HESAP_NO", dbsAcenteSubeTx.getVdszHesapNo());
						oMap3.put(tableName3, row3, "KREDI_HESAP_NO", dbsAcenteSubeTx.getKrdHesapNo());
						oMap3.put(tableName3, row3, "LIMIT", LovHelper.diLov(dbsAcenteSubeTx.getKrdHesapNo(), dbsAcenteSubeTx.getMusteriNo(), dbsAcenteSubeTx.getMusteriNo(), "2095/LOV_KREDI_HESABI", "LIMIT"));				
						oMap3.put(tableName3, row3, "KULLANILABILIR_LIMIT", LovHelper.diLov(dbsAcenteSubeTx.getKrdHesapNo(), dbsAcenteSubeTx.getMusteriNo(), dbsAcenteSubeTx.getMusteriNo(), "2095/LOV_KREDI_HESABI", "KULL_LIMIT"));
						oMap3.put(tableName3, row3, "DURUM", dbsAcenteSubeTx.getDurum());
						oMap3.put(tableName3, row3, "MERKEZ_SUBE", dbsAcenteSubeTx.getMerkezSube());
						oMap3.put(tableName3, row3, "DBCHECK", "OK");
						
						row3++;
					}
					oMap2.put(tableName2, row2, "ACENTE_SUBE_INFO", oMap3.get("ACENTE_SUBE"));
					row2++;
				}
				
				oMap.put(tableName, row, "ACENTE_INFO", oMap2.get("ACENTE"));
				row++;
			}
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
	}
	
}
