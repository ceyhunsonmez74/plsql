package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.currentaccounts.utils.KasaFarkEnum;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsQRY2027Services {
	public static SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");

	
	@GraymoundService("BNSPR_QRY2027_KASA_FARK_MAIN")
	public static GMMap getKasaFarkMain(GMMap iMap) {
		int i = 0;
		GMMap oMap = new GMMap();
		try {
			validateRequest(iMap);

			String tableName = KasaFarkEnum.TBL_GML.getKeyValue();
			String func = KasaFarkEnum.FUNC_MAIN.getKeyValue();
			Object[] inputValues = new Object[18];

			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("MIN_TUTAR");

			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("MAX_TUTAR");

			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("DOVIZ_KODU");

			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("FARK_TIPI");

			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("SUBE_KODU");

			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KASA_KODU");

			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KULLANICI_KODU");

			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("BAS_TARIH");

			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("BIT_TARIH");

			oMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
			i = 0;
			while (i < oMap.getSize(tableName)) {
				oMap.put(tableName, i, "KULLANICI_KODU", oMap.getString(tableName, i, "REC_OWNER"));
				oMap.put(tableName, i, "SUBE_ADI", LovHelper.diLov(oMap.getString(tableName, i, "SUBE_KODU"), "2017/LOV_SUBE", "ADI"));
				String diffType = oMap.getString(tableName, i, "FARK_TIPI");
				setFarkTipi(oMap,i,diffType);
				i++;
			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	public static Date makeFormattDate(GMMap iMap, String key) {
		String formatDate = null;
		Date formatedDate = null;
		try {

			if ((iMap.getDate(key) != null) && (key != null)) {
				formatDate = formatter.format(iMap.getDate(key));
				if (formatDate != null)
					formatedDate = formatter.parse(formatDate);
			}

			return formatedDate;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	
	public static void setFarkTipi(GMMap iMap, int i, String diffType) {

		try {
			String tableName = KasaFarkEnum.TBL_GML.getKeyValue();

			if (!StringUtils.isBlank(diffType)) {

				if (diffType.equals(KasaFarkEnum.FARK_TIPI_TL_KASA_FAZLA.getKeyValue()))
					iMap.put(tableName, i, "FARK_TIPI", KasaFarkEnum.TL_KASA_FAZLA.getKeyValue());

				if (diffType.equals(KasaFarkEnum.FARK_TIPI_YP_KASA_FAZLA.getKeyValue()))
					iMap.put(tableName, i, "FARK_TIPI", KasaFarkEnum.YP_KASA_FAZLA.getKeyValue());

				if (diffType.equals(KasaFarkEnum.FARK_TIPI_TL_KASA_NOKSAN.getKeyValue()))
					iMap.put(tableName, i, "FARK_TIPI", KasaFarkEnum.TL_KASA_NOKSAN.getKeyValue());

				if (diffType.equals(KasaFarkEnum.FARK_TIPI_YP_KASA_NOKSAN.getKeyValue()))
					iMap.put(tableName, i, "FARK_TIPI", KasaFarkEnum.YP_KASA_NOKSAN.getKeyValue());
				
				if (diffType.equals(KasaFarkEnum.FARK_TIPI_DEFAULT.getKeyValue()))
					iMap.put(tableName, i, "FARK_TIPI","");
				
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	public static void validateRequest(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal errorCode;
		try {

			oMap = GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", iMap);

			Date dateOfBank = makeFormattDate(oMap, "BANKA_TARIH");

			Date beginDate = makeFormattDate(iMap, "BAS_TARIH");
			Date endDate = makeFormattDate(iMap, "BIT_TARIH");

			if ((beginDate != null) && (endDate != null)) {
				if (beginDate.after(endDate)) {
					errorCode = new BigDecimal(KasaFarkEnum.QRY_H1.getKeyValue());
					throw new GMRuntimeException(errorCode.intValue(), getErrorText(errorCode));
				}
			}

			if (beginDate != null) {
				if (beginDate.after(dateOfBank)) {
					errorCode = new BigDecimal(KasaFarkEnum.QRY_H2.getKeyValue());
					throw new GMRuntimeException(errorCode.intValue(), getErrorText(errorCode));
				}
			}

			if (endDate != null) {
				if (endDate.after(dateOfBank)) {
					errorCode = new BigDecimal(KasaFarkEnum.QRY_H3.getKeyValue());
					throw new GMRuntimeException(errorCode.intValue(), getErrorText(errorCode));
				}
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	public static String getErrorText(BigDecimal errorCode) {
		GMMap errorIMap = new GMMap();
		String errorDescription;

		errorIMap.put("MESSAGE_NO", errorCode);
		errorDescription = GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", errorIMap).getString("ERROR_MESSAGE");

		return errorDescription;

	}

}
