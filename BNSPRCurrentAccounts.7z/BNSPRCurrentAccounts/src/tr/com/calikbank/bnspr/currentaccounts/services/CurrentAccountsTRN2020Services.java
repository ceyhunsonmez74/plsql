package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhKasaKullaniciTanimTx;
import tr.com.calikbank.bnspr.util.BeanSetProperties;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsTRN2020Services {
	@GraymoundService("BNSPR_TRN2020_SAVE_KASA_KULLANICI")
	public static Map<?, ?> saveKasaKullanici(GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			MuhKasaKullaniciTanimTx muhKasaKullaniciTanimTx = new MuhKasaKullaniciTanimTx();
			muhKasaKullaniciTanimTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			muhKasaKullaniciTanimTx.setTanimNo(iMap.getBigDecimal("TANIM_NO"));
			muhKasaKullaniciTanimTx.setModulTurKod(iMap.getString("MODUL_TUR_KOD"));
			muhKasaKullaniciTanimTx.setUrunTurKod(iMap.getString("URUN_TUR_KOD"));
			muhKasaKullaniciTanimTx.setUrunSinifKod(iMap.getString("URUN_SINIF_KOD"));
			muhKasaKullaniciTanimTx.setBankaTarihi(iMap.getDate("BANKA_TARIHI"));
			muhKasaKullaniciTanimTx.setSubeKodu(iMap.getString("SUBE_KODU"));
			muhKasaKullaniciTanimTx.setKasaKodu(iMap.getString("KASA_KODU"));
			muhKasaKullaniciTanimTx.setKullaniciKodu(iMap.getString("KULLANICI_KODU"));
			
			session.save(muhKasaKullaniciTanimTx);
			session.flush();
			
			iMap.put("TRX_NAME", "2020");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2020_GET_KASA_KULLANICI_DATA")
	public static GMMap getKasaKullaniciDate(GMMap iMap) throws Exception{
		GMMap oMap = new GMMap();
		oMap.put("TANIM_NO", callNoneParameterOracleFunction("{? = call pkg_genel_pr.genel_kod_al('KASA_TANIM_NO')}", Types.NUMERIC) );
		oMap.put("MODUL_TUR_KOD", callNoneParameterOracleFunction("{? = call Pkg_kasa.kasa_modul_tur_kod}", Types.VARCHAR) );
		oMap.put("URUN_TUR_KOD", callNoneParameterOracleFunction("{? = call Pkg_kasa.kasa_urun_tur_kod}", Types.VARCHAR) );
		oMap.put("URUN_SINIF_KOD", callNoneParameterOracleFunction("{? = call Pkg_kasa.kasa_urun_sinif_kod}", Types.VARCHAR) );
		oMap.put("BANKA_TARIHI", callNoneParameterOracleFunction("{? = call pkg_muhasebe.banka_tarihi_bul}", Types.DATE) );
		oMap.put("SUBE_KODU", callNoneParameterOracleFunction("{? = call pkg_global.GET_SUBEKOD}", Types.VARCHAR) );
		return oMap;
	}
	
	private static Object callNoneParameterOracleFunction(String functionName, int returnType){
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(functionName);			
			stmt.registerOutParameter(1, returnType);
			stmt.execute();
			return stmt.getObject(1);
		}catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2020_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			MuhKasaKullaniciTanimTx oldMuhKasaKullaniciTanimTx;
			MuhKasaKullaniciTanimTx muhKasaKullaniciTanimTx = (MuhKasaKullaniciTanimTx) session.createCriteria(MuhKasaKullaniciTanimTx.class)
																							.add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();	
			
			BigDecimal oldTx = (BigDecimal) session.createCriteria(MuhKasaKullaniciTanimTx.class)
													.add(Restrictions.lt("txNo", iMap.getBigDecimal("TRX_NO")))
													.add(Restrictions.eq("kasaKodu", muhKasaKullaniciTanimTx.getKasaKodu()))
													.setProjection(Projections.projectionList().add(Projections.max("txNo"))).uniqueResult();
			
			if(oldTx != null){
				oldMuhKasaKullaniciTanimTx = (MuhKasaKullaniciTanimTx) session.createCriteria(MuhKasaKullaniciTanimTx.class)
																							.add(Restrictions.eq("txNo", oldTx)).uniqueResult();
			}
			else{
				oldMuhKasaKullaniciTanimTx = null;
			}
			
			
			oMap.put("TANIM_NO", muhKasaKullaniciTanimTx.getTanimNo());
			oMap.put("MODUL_TUR_KOD", muhKasaKullaniciTanimTx.getModulTurKod());
			oMap.put("URUN_TUR_KOD", muhKasaKullaniciTanimTx.getUrunTurKod());
			oMap.put("URUN_SINIF_KOD", muhKasaKullaniciTanimTx.getUrunSinifKod());
			oMap.put("BANKA_TARIHI", muhKasaKullaniciTanimTx.getBankaTarihi());
			oMap.put("SUBE_KODU", muhKasaKullaniciTanimTx.getSubeKodu());
			oMap.put("KASA_KODU", muhKasaKullaniciTanimTx.getKasaKodu());
			oMap.put("ACIKLAMA",LovHelper.diLov(muhKasaKullaniciTanimTx.getKasaKodu(), "2020/LOV_KASA", "ACIKLAMA"));
			oMap.put("KULLANICI_KODU", muhKasaKullaniciTanimTx.getKullaniciKodu());
			
			oMap.putAll(BeanSetProperties.reflectDifference(oldMuhKasaKullaniciTanimTx, muhKasaKullaniciTanimTx, null, null));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
