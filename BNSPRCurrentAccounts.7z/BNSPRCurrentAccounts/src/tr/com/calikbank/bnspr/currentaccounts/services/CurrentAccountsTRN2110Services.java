package tr.com.calikbank.bnspr.currentaccounts.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.SwftMt941HesapTanimTx;
import tr.com.aktifbank.bnspr.dao.SwftMt941HesapTanimTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class CurrentAccountsTRN2110Services { 
    
    @GraymoundService("BNSPR_TRN2110_GET_RECORDS")
    public static GMMap getTransactionNo(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        String tableName = "TBL_TURKCELL_OZET_EKSTRE";
     
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN2110.get_records}");
            stmt.registerOutParameter(1 , -10); // ref cursor
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            int row = 0;
            while (rSet.next()) {
                oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
                oMap.put(tableName , row , "MUSTERI_NO" , rSet.getBigDecimal("MUSTERI_NO"));
                oMap.put(tableName, row, "UNVAN", rSet.getString("UNVAN"));
                oMap.put(tableName, row, "HESAP_NO",rSet.getBigDecimal("HESAP_NO"));
                oMap.put(tableName, row, "HESAP_ADI", rSet.getString("HESAP_ADI"));
                oMap.put(tableName , row , "E_MAIL" , rSet.getString("E_MAIL"));
                oMap.put(tableName , row , "SIL" , rSet.getString("SIL"));
                oMap.put(tableName , row , "G_S" , rSet.getString("G_S"));
                row++;
               }
          
            return oMap;
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(conn);
        }
        
    }
    
    @GraymoundService("BNSPR_TRN2110_SAVE")
    public static Map<?, ?> save(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            String tableName = "TBL_TURKCELL_OZET_EKSTRE";
            
            List<?> recordList = (List<?>) iMap.get(tableName);
            
            for (int row = 0; row < recordList.size(); row++){
                
               SwftMt941HesapTanimTxId id = new SwftMt941HesapTanimTxId();
            
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                id.setHesapNo(iMap.getBigDecimal(tableName, row, "HESAP_NO"));
             
                SwftMt941HesapTanimTx swftMt941HesapTanimTx = (SwftMt941HesapTanimTx) session.get(SwftMt941HesapTanimTx.class , id);
                if (swftMt941HesapTanimTx == null){
                    swftMt941HesapTanimTx = new SwftMt941HesapTanimTx();
                }
                swftMt941HesapTanimTx.setId(id);
                
                if (("S").equals(iMap.getString(tableName , row , "G_S")))
                    swftMt941HesapTanimTx.setGS("S");
                else if (("G").equals(iMap.getString(tableName, row, "G_S")))
                    swftMt941HesapTanimTx.setGS("G");
                else if (("D").equals(iMap.getString(tableName, row, "G_S")))
                    swftMt941HesapTanimTx.setGS("D");
                else swftMt941HesapTanimTx.setGS("");
                
               swftMt941HesapTanimTx.setEMail(iMap.getString(tableName, row, "E_MAIL"));
               
                session.saveOrUpdate(swftMt941HesapTanimTx);
            }
            session.flush();
            iMap.put("TRX_NAME" , "2110");
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    @GraymoundService("BNSPR_TRN2110_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try{
            // Get Master
            String tableName = "TBL_TURKCELL_OZET_EKSTRE";
            Session session = DAOSession.getSession("BNSPRDal");
            Criteria criteria = session.createCriteria(SwftMt941HesapTanimTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO")));
            
            List<?> recordList = (List<?>) criteria.list();
            
            for (int row = 0; row < recordList.size(); row++){
                SwftMt941HesapTanimTx swftMt941HesapTanimTx = (SwftMt941HesapTanimTx) recordList.get(row);
                oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
                oMap.put(tableName , row , "MUSTERI_NO" ,DALUtil.getResult("select musteri_no from v_muh_hesap_izleme_tum where hesap_no = "+swftMt941HesapTanimTx.getId().getHesapNo()+""));
                oMap.put(tableName, row, "UNVAN", DALUtil.getResult("select unvan from v_gnl_musteri_aktif where musteri_no in (select musteri_no from v_muh_hesap_izleme where hesap_no = "+swftMt941HesapTanimTx.getId().getHesapNo()+")"));
                oMap.put(tableName , row , "HESAP_NO" , swftMt941HesapTanimTx.getId().getHesapNo());
                oMap.put(tableName , row , "HESAP_ADI" ,DALUtil.getResult("select isim_unvan from v_muh_hesap_izleme_tum where hesap_no = '"+swftMt941HesapTanimTx.getId().getHesapNo()+"' "));
                oMap.put(tableName , row , "E_MAIL" , swftMt941HesapTanimTx.getEMail());
                oMap.put(tableName , row , "SIL" , ("S").equals(swftMt941HesapTanimTx.getGS()) ? true : false);
                oMap.put(tableName, row, "G_S",swftMt941HesapTanimTx.getGS());
              }
            
            GMMap colorChangedD = new GMMap();
			colorChangedD.put("setBackground", Color.WHITE);
			colorChangedD.put("setForeground", Color.RED);
			
			GMMap colorChangedG = new GMMap();
			colorChangedG.put("setBackground", Color.WHITE);
			colorChangedG.put("setForeground", Color.BLUE);
			
			GMMap colorNotChanged  = new GMMap();
			colorNotChanged.put("setBackground", Color.WHITE);
			colorNotChanged.put("setForeground", Color.BLACK);
			
			GMMap colorCase = new GMMap();
			
			for (int j=0; j<oMap.getSize(tableName);j++)
			{
				if (StringUtils.isBlank(oMap.getString(tableName, j, "G_S"))) {
					colorCase = colorNotChanged;
				}
				else if(oMap.getString(tableName, j, "G_S").equals("D"))
				{
					colorCase = colorChangedD;
				}
				else if(oMap.getString(tableName, j, "G_S").equals("G"))
				{
					colorCase = colorChangedG;
				}
				else
				{
					colorCase = colorNotChanged;
				}
				oMap.put("TABLE_COLOR", j, "MUSTERI_NO", colorCase);
				oMap.put("TABLE_COLOR", j, "UNVAN", colorCase);
				oMap.put("TABLE_COLOR", j, "HESAP_NO", colorCase);
				oMap.put("TABLE_COLOR", j, "HESAP_ADI", colorCase);
				oMap.put("TABLE_COLOR", j, "E_MAIL", colorCase);
				oMap.put("TABLE_COLOR", j, "SIL", colorCase);
		}
			
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    @GraymoundService("BNSPR_TRN2110_KAYIT_KONTROLU")
    public static GMMap getTanimliHesapVarMi(GMMap iMap) {
        
        Connection conn = null;
        CallableStatement stmt = null;

        
        try{
            
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call PKG_TRN2110.tanimli_kayit_kontrolu(?)}");
            stmt.registerOutParameter(1 , Types.VARCHAR);
            stmt.setString(2 , iMap.getString("HESAP_NO"));
            stmt.execute();
            
            GMMap oMap = new GMMap();
            oMap.put("MESSAGE" , stmt.getString(1));
            
            return oMap;
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN2110_OZET_EKSTRE_GONDER")
    public static GMMap ozetEkstreGonder(GMMap iMap) {
                                            
            Connection conn = null;
            PreparedStatement stmt = null;
            ResultSet rSet = null;
            try{
                String query="select hesap_no from swft_mt941_hesap_tanim";

                conn = DALUtil.getGMConnection();
                stmt = conn.prepareStatement(query);
                rSet = stmt.executeQuery();
                                                            
                    GMMap oMap = new GMMap();
                    stmt = conn.prepareStatement(query);
                
                    
                    while (rSet.next()){
                    
                    BigDecimal hesapNo = rSet.getBigDecimal(1);
                 
                    stmt = conn.prepareCall("{call PKG_MT941.MT941_hesap_ozet_ekstre(?)}");
                    stmt.setBigDecimal(1 , hesapNo);
                    stmt.execute();
                    }                                                
                    return oMap;
                                                                      
            } catch (Exception e) {
                      throw ExceptionHandler.convertException(e);

            } finally {
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
                GMServerDatasource.close(rSet);
            }
    }
}
