package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhKasaTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsTRN2023Services {
	@GraymoundService("BNSPR_TRN2023_CALL_BEKLEYEN_ISLEM_VARMI")
	public static Map<?, ?> callBekleyenIslemVarmi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_trn2023.bekleyen_kasa_islemi_varmi(?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			stmt.setString(2, iMap.getString("KASA_KOD"));
	    	stmt.execute();
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return new HashMap<String, Object>();
	}
	
	@GraymoundService("BNSPR_TRN2023_CALL_KASA_ISLEME_AT")
	public static Map<?, ?> callKasaIslemeAt(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_Kasa.kasa_isleme_at (?,?,?,pkg_global.GET_SUBEKOD,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setBigDecimal(i++, new BigDecimal(2023));
			stmt.setString(i++, iMap.getString("KASA_KODU"));
			stmt.setString(i++, iMap.getString("KULLANICI_KOD"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TANIM_NO"));
	    	stmt.execute();
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return new HashMap<String, Object>();
	}
	
	@GraymoundService("BNSPR_TRN2023_GET_KASA")
	public static Map<?, ?> getKasa(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rs = null;
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			MuhKasaTx muhKasaTx = (MuhKasaTx)session.load(MuhKasaTx.class, iMap.getBigDecimal("TRX_NO"));
			oMap.put("KASA_KODU", muhKasaTx.getKasaKodu());
			oMap.put("SUBE_KODU", muhKasaTx.getSubeKodu());
			oMap.put("URUN_SINIF_KOD", muhKasaTx.getUrunSinifKod());
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_genel_pr.urun_sinif_adi(pkg_kasa.kasa_modul_tur_kod,pkg_kasa.kasa_urun_tur_kod, ? )}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, muhKasaTx.getUrunSinifKod());
			stmt.execute();
			oMap.put("URUN_SINIF_AD", stmt.getString(1));
			
			
			StringBuffer sb = new StringBuffer();
			sb.append("select t.doviz_kodu DOVIZ_KODU, ");
			sb.append("pkg_kasa.kasa_bakiye_al(pkg_kasa.ana_kasa_kodu, t.sube_kodu, t.doviz_kodu, pkg_tarih.geri_is_gunu(t.banka_tarihi)) ONCEKI_BAKIYE, ");
			sb.append("pkg_kasa.kasa_bakiye_al(t.kasa_kodu, t.sube_kodu, t.doviz_kodu, t.banka_tarihi) KULKASA_BAKIYE, ");
			sb.append("t.bakiye_fazla, t.bakiye_eksik, t.kasa_kodu KASA_KODU,t.sube_kodu SUBE_KODU,t.banka_tarihi BANKA_TARIHI ");
			sb.append("from MUH_KASA_BAKIYE_TX t ");
			sb.append("where t.tx_no= ? ");
			
			stmt = conn.prepareCall(sb.toString());
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));
			ArrayList<HashMap<String, Object>> outList = new ArrayList<HashMap<String, Object>>();
			rs = stmt.executeQuery();
			while (rs.next()) {
				int i = 1;
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				rowData.put("DOVIZ_KODU", rs.getString(i++));
				rowData.put("DI_ONCEKI_BAKIYE", rs.getBigDecimal(i++));
				rowData.put("DI_KULKASA_BAKIYE", rs.getBigDecimal(i++));
				rowData.put("BAKIYE_FAZLA", rs.getBigDecimal(i++));
				rowData.put("BAKIYE_EKSIK", rs.getBigDecimal(i++));
				rowData.put("KASA_KODU", rs.getString(i++));
				rowData.put("SUBE_KODU", rs.getString(i++));
				rowData.put("BANKA_TARIHI", rs.getDate(i++));
				outList.add(rowData);
			}
			
			oMap.put("KASA_DURUMU", outList);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rs);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN2023_GET_KASA_KUPUR_DURUM")
	public static Map<?, ?> getKasaKupurDurum(GMMap iMap) {
		Connection conn = null;
		GMMap oMap = new GMMap();
		try {
			StringBuffer sb = new StringBuffer();
			sb.append("select v.DOVIZ_KODU, v.KUPUR_KODU, v.KUPUR_ADEDI, v.KUPUR_BAKIYE ");
			sb.append("from muh_kasa_kupur_bakiye_tx v ");
			sb.append("where v.KASA_KODU=? ");
			sb.append("and v.SUBE_KODU=? ");
			sb.append("and v.tx_no=? ");
			sb.append("and v.DOVIZ_KODU=? ");
			conn = DALUtil.getGMConnection();

			oMap.put("KULLANICI_KASA_KUPUR_DURUMU", readKasaKupurBakiye(sb.toString(), conn, iMap));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	private static ArrayList<HashMap<String, Object>> readKasaKupurBakiye(String sqlQuery, Connection conn, GMMap iMap) throws SQLException{
		CallableStatement stmt = conn.prepareCall(sqlQuery);
		int j = 1;
	    stmt.setString(j++, iMap.getString("KASA_KODU"));
		stmt.setString(j++, iMap.getString("SUBE_KODU"));
		stmt.setBigDecimal(j++, iMap.getBigDecimal("TRX_NO"));
		stmt.setString(j++, iMap.getString("DOVIZ_KODU"));
		
		ArrayList<HashMap<String, Object>> outList = new ArrayList<HashMap<String, Object>>();
		ResultSet rs = stmt.executeQuery();
		while (rs.next()) {
			int i = 1;
			HashMap<String, Object> rowData = new HashMap<String, Object>();

			rowData.put("DOVIZ_KODU", rs.getString(i++));
			rowData.put("KUPUR_KODU", rs.getBigDecimal(i++));
			rowData.put("KUPUR_ADEDI", rs.getBigDecimal(i++));
			rowData.put("KUPUR_BAKIYE", rs.getString(i++));
			outList.add(rowData);
		}
		GMServerDatasource.close(rs);
		return outList;
	}
	@GraymoundService("BNSPR_TRN2023_UPDATE_BAKIYELER")
	public static Map<?, ?> updateBakiyeler(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rs = null;
		try {
			StringBuffer sb = new StringBuffer();
			sb.append("update muh_kasa_bakiye_tx t ");
			sb.append("set t.bakiye_fazla = ?,  ");
			sb.append("t.bakiye_eksik = ? ");
			sb.append("where t.tx_no= ? ");
			sb.append("and t.doviz_kodu = ? ");
			conn = DALUtil.getGMConnection();
			List<?> kasaDurum = (List<?>) iMap.get("KASA_DURUM");		
			for (Iterator<?> iterator = kasaDurum.iterator(); iterator.hasNext();) {
				HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
				stmt = conn.prepareCall(sb.toString());
				stmt.setBigDecimal(1, new BigDecimal(rowData.get("BAKIYE_FAZLA").toString()));
				stmt.setBigDecimal(2, new BigDecimal(rowData.get("BAKIYE_EKSIK").toString()));
				stmt.setBigDecimal(3, iMap.getBigDecimal("TRX_NO"));
				stmt.setString(4, rowData.get("DOVIZ_KODU").toString());
				stmt.execute();
			}
			
			iMap.put("TRX_NAME", "2023");

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rs);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
	}
	
	@GraymoundService("BNSPR_TRN2023_UPDATE_KUPUR_ADET_BAKIYE")
	public static Map<?, ?> updateKupurAdetBakiye(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rs = null;
		try {
			StringBuffer sb = new StringBuffer();
			sb.append("update muh_kasa_kupur_bakiye_tx k ");
			sb.append("set k.kupur_adedi= ?, ");
			sb.append("k.kupur_bakiye=? ");
			sb.append("where k.tx_no=? ");
			sb.append("and k.kasa_kodu=? ");
			sb.append("and k.sube_kodu=? ");
			sb.append("and k.doviz_kodu=? ");
			sb.append("and k.kupur_kodu=? ");
			conn = DALUtil.getGMConnection();
			List<?> kasaKupurDurum = (List<?>) iMap.get("KASA_KUPUR_DURUM");		
			for (Iterator<?> iterator = kasaKupurDurum.iterator(); iterator.hasNext();) {
				HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
				int i = 1;
				stmt = conn.prepareCall(sb.toString());
				stmt.setBigDecimal(i++, new BigDecimal(rowData.get("KUPUR_ADEDI").toString()));
				stmt.setBigDecimal(i++, new BigDecimal(rowData.get("KUPUR_BAKIYE").toString()));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
				stmt.setString(i++, iMap.getString("KASA_KODU"));
				stmt.setString(i++, iMap.getString("SUBE_KODU"));
				stmt.setString(i++, rowData.get("DOVIZ_KODU").toString());
				stmt.setBigDecimal(i++, new BigDecimal(rowData.get("KUPUR_KODU").toString()));
				stmt.execute();
			}
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rs);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return new HashMap<String, Object>();
	}
}
