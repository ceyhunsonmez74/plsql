package tr.com.calikbank.bnspr.currentaccounts.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import org.apache.log4j.Logger;
import org.hibernate.criterion.Restrictions;
import org.hibernate.Session;








import tr.com.aktifbank.bnspr.dao.PttMaasSorguTcknListTx;
import tr.com.aktifbank.bnspr.dao.PttMaasSorguTcknListTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.integration.ssl.AktifSSLSocketFactory;
import tr.com.obss.adc.core.util.ADCSession;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class CurrentAccountsQRY4123Services {
	
	private static final Logger logger=Logger.getLogger(CurrentAccountsQRY4123Services.class);
	
	@GraymoundService("BNSPR_PTT_MAAS_SORGU_LOAD_EXCEL")
	public static GMMap pttMaasSorguList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Workbook workbook = null;
		try {			
			String tableName = "TCKN_LIST";
			
			WorkbookSettings setting = new WorkbookSettings();
            setting.setEncoding("ISO-8859-9");
            workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("DOSYA")) , setting);
            Sheet dataSheet = workbook.getSheet(0);

            for (int i = 0; i < dataSheet.getRows() - 2 ; i++){
            	oMap.put(tableName , i , "TCKN" , dataSheet.getCell(0 , i + 1).getContents());
            }


			return oMap;
			
			}	  catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
		
	
	@GraymoundService("BNSPR_PTT_MAAS_SORGU_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		
		Connection conn = null;
		PreparedStatement stmt = null;
		
		GMMap oMap = new GMMap();

		try{
			Session session = DAOSession.getSession("BNSPRDal"); 

            String tableName = "TCKN_LIST";
			List<?> guiList = (List<?>)iMap.get(tableName);
			if(guiList.size()==0){
				iMap.put("HATA_NO", new BigDecimal(1064));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if(iMap.getString("DOSYA_ADI")==null || iMap.getString("DOSYA_ADI").length()==0){
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "DOSYA_ADI");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement("select * from bnspr.ptt_maas_sorgu_tckn_list_tx h where REC_OWNER = ? and CHECKED = 'H'");
			
			stmt.setString(1, ADCSession.getString("USER_NAME")); // MIKTAR PARAMETRESI
			
			logger.info("USER_NAME: " + ADCSession.getString("USER_NAME"));
			
			ResultSet rSet = stmt.executeQuery();
			
			int cnt = 0;
			
			while (rSet.next()) {
				cnt++;
			}
			
			
			if (cnt > 0) {
				iMap.put("HATA_NO", new BigDecimal(5547)); // HATA KODU TANIMLA : Excel y�klemi� ki�i, y�kledikleri i�lemeden yeni excel y�kleyemez
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
				
			BigDecimal internalId = new BigDecimal(1);
			for (int i = 0; i < guiList.size(); i++) {
				PttMaasSorguTcknListTx pttMaasSorguTcknListTx = new PttMaasSorguTcknListTx();
				PttMaasSorguTcknListTxId pttMaasSorguTcknListTxId = new PttMaasSorguTcknListTxId(iMap.getBigDecimal("TRX_NO"), internalId);
				pttMaasSorguTcknListTx.setId(pttMaasSorguTcknListTxId);
				internalId = internalId.add(new BigDecimal(1));
				
				pttMaasSorguTcknListTx.setTckn(iMap.getLong(tableName, i, "TCKN"));
				pttMaasSorguTcknListTx.setDosyaAdi(iMap.getString("DOSYA_ADI"));
				pttMaasSorguTcknListTx.setChecked("H");
				pttMaasSorguTcknListTx.setCreateId(new BigDecimal(0));
				
				
				session.save(pttMaasSorguTcknListTx);
				}
			session.flush();
			oMap.put("MESSAGE", "TCKN'ler ba�ar�yla y�klenmi�tir");
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	
	@GraymoundService("BNSPR_PTT_MAAS_SORGU_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> list = (List<?>)session.createCriteria(PttMaasSorguTcknListTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	
		String tableName = "TCKN_LIST";
		int row = 0;
		for (Object name : list) {
			
			PttMaasSorguTcknListTx pttMaasSorguTcknListTx = (PttMaasSorguTcknListTx) name;
			oMap.put(tableName, row, "TCKN", pttMaasSorguTcknListTx.getTckn());
			oMap.put(tableName, row, "INTERNAL_ID", pttMaasSorguTcknListTx.getId().getInternalId());
			oMap.put("DOSYA_ADI", pttMaasSorguTcknListTx.getDosyaAdi());			
			row++;
		}
        	return oMap;
        	
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_SGK_EMEKLI_GET_EMEKLI_AYLIK_BILGILERI_KAYDET")
	public static GMMap getEmekliAylikBilgileriKaydet(GMMap iMap){
		
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		
		String batchParamCode = "4123_MAAS_SORGU_MIKTAR";
		GMMap gMap = new GMMap();
		gMap.put("KOD" , batchParamCode);
        String miktar = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , gMap).getString("DEGER");
		
		try{
			
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareStatement("select * from (select h.tckn, h.REC_OWNER from bnspr.ptt_maas_sorgu_tckn_list_tx h where h.CHECKED = 'H') where rownum <= ?");
			stmt.setString(1, miktar); // MIKTAR PARAMETRESI
			
			rSet = stmt.executeQuery();
			
			String report = "<html><body>";
			report += "<table style=\"width:100%\"><tr>" +
			"<th>TC_KIMLIK_NO</th>" +
			"<th>ADI</th>" +
			"<th>SOYADI</th>" +
			"<th>AYLIK_ID</th>" +
			"<th>AYLIK_SONUC_ACIKLAMA</th>" +
			"<th>SIGORTA_KOLU</th>" +
			"<th>TAHSIS_SEKLI</th>" +
			"<th>SICIL_NO</th>" +
			"<th>SISTEM_ACIK_KAPALI</th>" +
			"<th>AYLIK_BANKAMDA</th>" +
			"<th>AYLIK_SONUC_KODU</th>" +
			"</tr>";

			while (rSet.next()) {
				iMap.put("TCKN", rSet.getBigDecimal("TCKN"));
				iMap.put("ISLEMI_YAPAN", rSet.getString("REC_OWNER"));
				GMMap aylikMap = GMServiceExecuter.call("BNSPR_SGK_EMEKLI_GET_EMEKLI_AYLIK_BILGILERI",iMap);
				int aylikMiktari = aylikMap.getSize("AYLIKLAR");
				
				logger.info("Ayl�k miktar�: " + ADCSession.getString("USER_NAME"));
				for (int i = 0; i < aylikMiktari; i++) {
					report += 
							( "<tr>" +
						      "<td>" + aylikMap.getMap("AYLIKLAR", i).getString("TC_KIMLIK_NO") + "</td>" +
						      "<td>" + aylikMap.getMap("AYLIKLAR", i).getString("ADI") + "</td>" +
						      "<td>" + aylikMap.getMap("AYLIKLAR", i).getString("SOYADI") +"</td>" +
						      "<td>" + aylikMap.getMap("AYLIKLAR", i).getString("AYLIK_ID") + "</td>" +
						      "<td>" + aylikMap.getMap("AYLIKLAR", i).getString("AYLIK_SONUC_ACIKLAMA") + "</td>" +
						      "<td>" + aylikMap.getMap("AYLIKLAR", i).getString("SIGORTA_KOLU") + "</td>" +
						      "<td>" + aylikMap.getMap("AYLIKLAR", i).getString("TAHSIS_SEKLI") + "</td>" +
						      "<td>" + aylikMap.getMap("AYLIKLAR", i).getString("SICIL_NO") + "</td>" +
						      "<td>" + aylikMap.getMap("AYLIKLAR", i).getString("SISTEM_ACIK_KAPALI") +"</td>" +
						      "<td>" + aylikMap.getMap("AYLIKLAR", i).getString("AYLIK_BANKAMDA") + "</td>" +
						      "<td>" + aylikMap.getMap("AYLIKLAR", i).getString("AYLIK_SONUC_KODU") +"</td>" +
							  "</tr>");
							
				}
				
				PreparedStatement updateStatement;
				 updateStatement = 
						conn.prepareStatement("update bnspr.ptt_maas_sorgu_tckn_list_tx h set CHECKED = 'E' where h.TCKN = ?");
				 updateStatement.setBigDecimal(1, iMap.getBigDecimal("TCKN")); // kayd� g�ncelle
				 
				 updateStatement.executeUpdate();

			}
			
			report +="</table></body></html>";
			
			
			// mail g�nder , bnspr.gnl_kullanici tablosundan detaylar� al
			
			stmt = conn.prepareStatement("select EMAIL, AD, SOYAD from bnspr.gnl_kullanici where kod = ?");
			
			stmt.setString(1, iMap.getString("ISLEMI_YAPAN")); // MIKTAR PARAMETRESI
			
			rSet = stmt.executeQuery();
			
			while (rSet.next()) {
				iMap.put("EMAIL", rSet.getString("EMAIL"));
				iMap.put("AD", rSet.getString("AD"));
				iMap.put("SOYAD", rSet.getString("SOYAD"));
			}
			
			 GMMap servisMap = new GMMap();
	         servisMap.put("MAIL_FROM" , "Aktifbank@aktifbank.com.tr");
	         servisMap.put("MAIL_TO" , iMap.getString("EMAIL"));
	         servisMap.put("TRX_NO" , iMap.getBigDecimal("TX_NO"));
	         servisMap.put("MAIL_SUBJECT" , "PTT Maa� Sorgu Sonu�lar�");
	         servisMap.put("MAIL_BODY" , report);
	         servisMap.put("IS_BODY_HTML" , "E");
	         oMap.putAll(GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL" , servisMap));
	         oMap.put("MESSAGE" , "Mail ba�ar�l� �ekilde g�nderilmi�tir.");
			
			
			// bizim tabloya create_id alan� eklendi , istSgkEmekliSorguDetay tablosunu id si ile e�lenmi� olacak. 
        	return oMap;
        	
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
		}
	}

	
}
