package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ClksMutabakatFisDetay;
import tr.com.aktifbank.bnspr.dao.ClksMutabakatFisDetayId;
import tr.com.aktifbank.bnspr.dao.ClksMutabakatFisHavuz;
import tr.com.aktifbank.bnspr.dao.ClksMutabakatFisTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2052Services {
	
	private static Logger logger = Logger.getLogger(CurrentAccountsTRN2052Services.class);
	private static String tableName = "FIS_DETAY"; 
	
	private static String DURUM_KOD_ACIK = "A";
	private static String DURUM_KOD_BEKLEME = "B";
	private static String DURUM_KOD_DEGISTIRILDI = "D";
	private static String DURUM_KOD_RED = "R";

	/**
	 * 
	 * Description : "SAVE" butonu arkasinda cagirilir, 2052 transaction'inin baslatilabilmesi icin ekrandan alinan girdiler dogrultusunda 
	 * bnspr.clks_mutabakat_fis_tx ve bnspr.clks_mutabakat_fis_detay tablolar� beslenir.
	 *
	 * @param iMap (GMMap)
	 *		{TRX_NO, TARIH, ACIKLAMA, DOVIZ_KOD, ALACAK_TOPLAM, BORC_TOPLAM, BALANS, 
	 *      FIS_DETAY=[{KOD, B_A, HESAP_NO, TUTAR, DOVIZ_KOD, ISLEM_TARIHI}]}
	 *
	 * @return oMap (GMMap)
	 *      {MESSAGE}
	 * 
	 * TODO: Yeni havuz kayitlari icin validasyon.
	 */
	@GraymoundService("BNSPR_TRN2052_SAVE")
	public static GMMap save(GMMap iMap) {

		GMMap oMap = new GMMap();
		boolean contains = false;
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksMutabakatFisTx clksMutabakatFisTx = (ClksMutabakatFisTx)session.get(ClksMutabakatFisTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(clksMutabakatFisTx == null) {
				clksMutabakatFisTx = new ClksMutabakatFisTx();
			}
			
			clksMutabakatFisTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			clksMutabakatFisTx.setIslemTarihi(iMap.getDate("TARIH"));
			clksMutabakatFisTx.setDovizKod(iMap.getString("DOVIZ_KOD"));
			clksMutabakatFisTx.setAlacakToplam(iMap.getBigDecimal("ALACAK_TOPLAM"));
			clksMutabakatFisTx.setBorcToplam(iMap.getBigDecimal("BORC_TOPLAM"));
			clksMutabakatFisTx.setAciklama(iMap.getString("ACIKLAMA"));
			session.saveOrUpdate(clksMutabakatFisTx);
			
			for(int i = 0; i < iMap.getSize(tableName); i++) {
				
				// Case: Yeni kayit (Job ile yaratilmamis)
				if(BigDecimal.ZERO.equals(iMap.getBigDecimal(tableName, i, "KOD"))) {
					
					// Havuz icin yeni kod al.
					iMap.put(tableName, i, "KOD", new BigDecimal(DALUtil.getResult("select seq_clks_mutabakat_fis_havuz.nextval from dual")));
				
					// Havuza yeni kayit at.
					ClksMutabakatFisHavuz clksMutabakatFisHavuz = new ClksMutabakatFisHavuz();
					
					clksMutabakatFisHavuz.setKod(iMap.getBigDecimal(tableName, i, "KOD"));
					clksMutabakatFisHavuz.setBA(iMap.getString(tableName, i, "B_A"));
					clksMutabakatFisHavuz.setDovizKod(iMap.getString(tableName, i, "DOVIZ_KOD"));
					clksMutabakatFisHavuz.setDurumKod(DURUM_KOD_ACIK);
					clksMutabakatFisHavuz.setFJob("H");
					clksMutabakatFisHavuz.setTutar(iMap.getBigDecimal(tableName, i, "TUTAR"));
					clksMutabakatFisHavuz.setHesapNo(iMap.getBigDecimal(tableName, i, "HESAP_NO"));
					clksMutabakatFisHavuz.setValorTarihi(iMap.getDate(tableName, i, "ISLEM_TARIHI"));
					session.save(clksMutabakatFisHavuz);
					
					ClksMutabakatFisDetay clksMutabakatFisDetay = new ClksMutabakatFisDetay();
					clksMutabakatFisDetay.setId(new ClksMutabakatFisDetayId(iMap.getBigDecimal("TRX_NO"), iMap.getBigDecimal(tableName, i, "KOD")));
					session.save(clksMutabakatFisDetay);
				}
			}
			
			// List: Job tarafindan yaratilan durumKod'u A olan kayitlar
			List<?> list = session.createCriteria(ClksMutabakatFisHavuz.class)
					.add(Restrictions.conjunction()
						.add(Restrictions.eq("islemTarihi", iMap.getDate("TARIH")))
						.add(Restrictions.eq("dovizKod", iMap.getString("DOVIZ_KOD")))
						.add(Restrictions.eq("durumKod", DURUM_KOD_ACIK)))
					.list();
				
			Iterator<?> iterator = list.iterator();
			
			while(iterator.hasNext()) {
				
				contains = false;
				ClksMutabakatFisHavuz clksMutabakatFisHavuz = (ClksMutabakatFisHavuz) iterator.next();
				
				for(int i = 0; i < iMap.getSize(tableName); i++) {
					
					// Case: Job tarafindan yaratilmis kayit.
					if(clksMutabakatFisHavuz.getKod().equals(iMap.getBigDecimal(tableName, i, "KOD")) && clksMutabakatFisHavuz.getFJob().equals("E")) {
					
						// Case: Job tarafindan yaratilmis kayit uzerinde tutar degisikligi var.
						if(clksMutabakatFisHavuz.getTutar().compareTo(iMap.getBigDecimal(tableName, i, "TUTAR")) != 0) {
							
							clksMutabakatFisHavuz.setDurumKod(DURUM_KOD_DEGISTIRILDI);
							session.save(clksMutabakatFisHavuz);
							
							ClksMutabakatFisDetay clksMutabakatFisDetay = new ClksMutabakatFisDetay();
							clksMutabakatFisDetay.setId(new ClksMutabakatFisDetayId(iMap.getBigDecimal("TRX_NO"), clksMutabakatFisHavuz.getKod()));
							session.saveOrUpdate(clksMutabakatFisDetay);
							
							// Havuza yeni kayit at.
							ClksMutabakatFisHavuz clksMutabakatFisHavuzTrn = new ClksMutabakatFisHavuz();
							
							BigDecimal kod = new BigDecimal(DALUtil.getResult("select seq_clks_mutabakat_fis_havuz.nextval from dual"));
							
							clksMutabakatFisHavuzTrn.setKod(kod);
							clksMutabakatFisHavuzTrn.setBA(iMap.getString(tableName, i, "B_A"));
							clksMutabakatFisHavuzTrn.setDovizKod(iMap.getString(tableName, i, "DOVIZ_KOD"));
							clksMutabakatFisHavuzTrn.setDurumKod(DURUM_KOD_ACIK);
							clksMutabakatFisHavuzTrn.setFJob("H");
							clksMutabakatFisHavuzTrn.setTutar(iMap.getBigDecimal(tableName, i, "TUTAR"));
							clksMutabakatFisHavuzTrn.setHesapNo(iMap.getBigDecimal(tableName, i, "HESAP_NO"));
							clksMutabakatFisHavuzTrn.setValorTarihi(iMap.getDate(tableName, i, "ISLEM_TARIHI"));
							session.save(clksMutabakatFisHavuzTrn);
							
							clksMutabakatFisDetay = new ClksMutabakatFisDetay();
							clksMutabakatFisDetay.setId(new ClksMutabakatFisDetayId(iMap.getBigDecimal("TRX_NO"), kod));
							session.save(clksMutabakatFisDetay);
						}
						
						// Case: Job tarafindan yaratilmis kayit.
						else {
							
							ClksMutabakatFisDetay clksMutabakatFisDetay = new ClksMutabakatFisDetay();
							clksMutabakatFisDetay.setId(new ClksMutabakatFisDetayId(iMap.getBigDecimal("TRX_NO"), clksMutabakatFisHavuz.getKod()));
							session.saveOrUpdate(clksMutabakatFisDetay);
						}
						
						contains = true;
					}
				}
				
				// Case: Job tarafindan yaratilmis kayit silinmis.
				if(!contains && clksMutabakatFisHavuz.getFJob().equals("E")) {
					
					clksMutabakatFisHavuz.setDurumKod(DURUM_KOD_DEGISTIRILDI);
					session.save(clksMutabakatFisHavuz);
					
					ClksMutabakatFisDetay clksMutabakatFisDetay = new ClksMutabakatFisDetay();
					clksMutabakatFisDetay.setId(new ClksMutabakatFisDetayId(iMap.getBigDecimal("TRX_NO"), clksMutabakatFisHavuz.getKod()));
					session.saveOrUpdate(clksMutabakatFisDetay);
				}
			}
			
			session.flush();
			
			iMap.put("TRX_NAME", "2052");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		} catch (Exception e) {
			
			logger.error("BNSPR_TRN2052_SAVE err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	
	/**
	 * 
	 * Description : Mesaj Kutusu araciligi ile BNSPR_TRN2052.guiml ekrani acildiginda cagirilir, 
	 * baslatilan transaction'a ait bilgileri getirir.
	 *
	 * @param iMap (GMMap)
	 *		{TRX_NO}
	 *
	 * @return oMap (GMMap)
	 *      {TRX_NO, TARIH, ACIKLAMA, DOVIZ_KOD, ALACAK_TOPLAM, BORC_TOPLAM, BALANS, 
	 *      FIS_DETAY=[{KOD, B_A, HESAP_NO, TUTAR, DOVIZ_KOD, ISLEM_TARIHI}]}
	 *
	 */
	@GraymoundService("BNSPR_TRN2052_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksMutabakatFisTx clksMutabakatFisTx = (ClksMutabakatFisTx)session.get(ClksMutabakatFisTx.class, iMap.getBigDecimal("TRX_NO"));
		
			oMap.put("TRX_NO", clksMutabakatFisTx.getTxNo());
			oMap.put("TARIH", clksMutabakatFisTx.getIslemTarihi());
			oMap.put("ACIKLAMA", clksMutabakatFisTx.getAciklama());
			oMap.put("DOVIZ_KOD", clksMutabakatFisTx.getDovizKod());
			oMap.put("ALACAK_TOPLAM", clksMutabakatFisTx.getAlacakToplam());
			oMap.put("BORC_TOPLAM", clksMutabakatFisTx.getBorcToplam());
			oMap.put("BALANS", clksMutabakatFisTx.getBorcToplam().subtract(clksMutabakatFisTx.getAlacakToplam()));


			List<?> list = session.createCriteria(ClksMutabakatFisDetay.class)
						.add(Restrictions.eq("id.mutabakatFisTxNo", oMap.getBigDecimal("TRX_NO")))
					.list();
			
			Iterator<?> iterator = list.iterator();
			int i = 0;
			
			while(iterator.hasNext()) {
				
				ClksMutabakatFisDetay clksMutabakatFisDetay = (ClksMutabakatFisDetay) iterator.next();
				
				ClksMutabakatFisHavuz clksMutabakatFisHavuz = (ClksMutabakatFisHavuz)session.get(ClksMutabakatFisHavuz.class, clksMutabakatFisDetay.getId().getMutabakatHavuzKod());
				
				if(!DURUM_KOD_DEGISTIRILDI.equals(clksMutabakatFisHavuz.getDurumKod()) && !DURUM_KOD_RED.equals(clksMutabakatFisHavuz.getDurumKod())) {
					
					oMap.put(tableName, i, "KOD", clksMutabakatFisHavuz.getKod());
					oMap.put(tableName, i, "B_A", clksMutabakatFisHavuz.getBA());
					oMap.put(tableName, i, "HESAP_NO", clksMutabakatFisHavuz.getHesapNo());
					oMap.put(tableName, i, "TUTAR", clksMutabakatFisHavuz.getTutar());
					oMap.put(tableName, i, "DOVIZ_KOD", clksMutabakatFisHavuz.getDovizKod());
					oMap.put(tableName, i, "ISLEM_TARIHI", clksMutabakatFisHavuz.getValorTarihi());
					oMap.put(tableName, i, "ACIKLAMA", clksMutabakatFisHavuz.getAciklama());
					
					i++;
				}
			}
			
		} catch (Exception e) {
			
			logger.error("BNSPR_TRN2052_GET_INFO err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	
	/**
	 * 
	 * Description : "Fis Getir" butonu arkasinda cagirilir, bnspr.clks_mutabakat_fis_havuz tablosundan
	 * durum_kod'u "A" olan kayitlari getirir.
	 *
	 * @param iMap (GMMap)
	 *		{TARIH, DOVIZ_KOD}
	 *
	 * @return oMap (GMMap)
	 *      {FIS_DETAY=[{KOD, B_A, HESAP_NO, TUTAR, DOVIZ_KOD, ISLEM_TARIHI}]}
	 *
	 */
	@GraymoundService("BNSPR_TRN2052_FIS_GETIR")
	public static GMMap fisGetir(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			List<?> list = session.createCriteria(ClksMutabakatFisHavuz.class)
				.add(Restrictions.conjunction()
					.add(Restrictions.eq("islemTarihi", iMap.getDate("TARIH")))
					.add(Restrictions.eq("dovizKod", iMap.getString("DOVIZ_KOD")))
					.add(Restrictions.eq("durumKod", DURUM_KOD_ACIK)))
				.list();
			
			Iterator<?> iterator = list.iterator();
			
			int i = 0;
			
			while(iterator.hasNext()) {
				
				ClksMutabakatFisHavuz clksMutabakatFisHavuz = (ClksMutabakatFisHavuz) iterator.next();

				oMap.put(tableName, i, "KOD", clksMutabakatFisHavuz.getKod());
				oMap.put(tableName, i, "B_A", clksMutabakatFisHavuz.getBA());
				oMap.put(tableName, i, "HESAP_NO", clksMutabakatFisHavuz.getHesapNo());
				oMap.put(tableName, i, "TUTAR", clksMutabakatFisHavuz.getTutar());
				oMap.put(tableName, i, "DOVIZ_KOD", clksMutabakatFisHavuz.getDovizKod());
				oMap.put(tableName, i, "ISLEM_TARIHI", clksMutabakatFisHavuz.getValorTarihi());
				oMap.put(tableName, i, "ACIKLAMA", clksMutabakatFisHavuz.getAciklama());
				
				
				i++;
			}
			
		} catch (Exception e) {
			
			logger.error("BNSPR_TRN2052_FIS_GETIR err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * 
	 * Description : BNSPR_TRN2052.guiml ekrani fis detay tablosunda bir degisiklik oldugu zaman cagirilir,
	 * yeni alacak / borc toplamlarini ve balansi hesaplar. 
	 *
	 * @param iMap (GMMap)
	 *		{FIS_DETAY=[{KOD, B_A, HESAP_NO, TUTAR, DOVIZ_KOD, ISLEM_TARIHI}]}
	 *
	 * @return oMap (GMMap)
	 *      {ALACAK_TOPLAM, BORC_TOPLAM, BALANS}
	 *
	 */
	@GraymoundService("BNSPR_TRN2052_TOPLAM_HESAPLA")
	public static GMMap toplamHesapla(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		BigDecimal borcToplam = BigDecimal.ZERO;
		BigDecimal alacakToplam = BigDecimal.ZERO;
		
		try {
			
			for(int i = 0; i < iMap.getSize(tableName); i++) {
				
				// Case: Borc
				if("B".equals(iMap.getString(tableName, i, "B_A"))) {
					
					borcToplam = borcToplam.add(iMap.getBigDecimal(tableName, i, "TUTAR") != null ? iMap.getBigDecimal(tableName, i, "TUTAR") : BigDecimal.ZERO);
				}
				
				// Case: Alacak
				else if("A".equals(iMap.getString(tableName, i, "B_A"))) {
					
					alacakToplam = alacakToplam.add(iMap.getBigDecimal(tableName, i, "TUTAR") != null ? iMap.getBigDecimal(tableName, i, "TUTAR") : BigDecimal.ZERO);
				}
			}
			
			oMap.put("BORC_TOPLAM", borcToplam);
			oMap.put("ALACAK_TOPLAM", alacakToplam);
			oMap.put("BALANS", borcToplam.subtract(alacakToplam));
			
		} catch (Exception e) {
			
			logger.error("BNSPR_TRN2052_TOPLAM_HESAPLA err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}	
	
    /**
     * Mutabakat i�lem toplamlar�n� mutabakat fi� havuz tablosuna kaydeder.
     * 
     * @param iMap
     * @author Omer Yusufoglu
     * @since 11.06.2015
     */
    @GraymoundService("BNSPR_TRN2052_MUT_FIS_HAVUZ_JOB")
    public static GMMap mutFisHavuzJob(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        
        try{
            
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_TRN2052.Mut_Fis_Havuz_Ekle_Job}");
            stmt.execute();
            
        } catch (Exception ex){
            logger.error("BNSPR_TRN2052_MUT_FIS_HAVUZ_JOB err: " + ex);
            throw ExceptionHandler.convertException(ex);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }
}
