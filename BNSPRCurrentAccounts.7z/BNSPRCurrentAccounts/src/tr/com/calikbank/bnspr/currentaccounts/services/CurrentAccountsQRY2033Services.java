package tr.com.calikbank.bnspr.currentaccounts.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Date;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class CurrentAccountsQRY2033Services {
	
	

	@GraymoundService("BNSPR_QRY2033_GET_GUNLUK_BAKIYE")
	public static GMMap getIstatistikKodlari(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{      
			
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC2033.QRY2033_Gunluk_bBakiye_Izleme(?,?,?,?,?,?,?)}"); //PROSEDUR
			
			int i = 0;
			stmt.setString	(++i, iMap.getString("SUBE_KODU"));
			stmt.setBigDecimal	(++i, iMap.getBigDecimal("MUSTERI_NO"));
			
			
			if(iMap.get("TARIH_BAS")!=null)
				stmt.setDate(++i, new Date(iMap.getDate("TARIH_BAS").getTime()));
			else 
				stmt.setDate(++i, null);
			if(iMap.get("TARIH_SON")!=null)
				stmt.setDate(++i, new Date(iMap.getDate("TARIH_SON").getTime()));
			else 
				stmt.setDate(++i, null);
			
			
			stmt.setBigDecimal	(++i, iMap.getBigDecimal("HESAP_NO"));
			stmt.setString	(++i, iMap.getString("DOVIZ_KODU"));

			
			
			stmt.registerOutParameter(++i, -10);
			stmt.execute();
			//stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(i);
			return DALUtil.rSetResults(rSet, "TABLO");
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
