package tr.com.calikbank.bnspr.currentaccounts.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class CurrentAccountsQRY2026Services {
	
	@GraymoundService("BNSPR_QRY2026_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc2026.get_info(?,?,?,?,?)}");

			stmt.registerOutParameter(1, -10); //ref cursor 
			stmt.setString(2, iMap.getString("GONDEREN_SUBE"));
			stmt.setString(3, iMap.getString("DEVIR_YAPILAN_SUBE"));
			stmt.setString(4, iMap.getString("DOVIZ_KODU"));
			if(iMap.getDate("TARIH_BAS") != null)
				stmt.setDate(5,  new java.sql.Date(iMap.getDate("TARIH_BAS").getTime()));
			else
				stmt.setDate(5, null);
			if(iMap.getDate("TARIH_BIT") != null)
				stmt.setDate(6,  new java.sql.Date(iMap.getDate("TARIH_BIT").getTime()));
			else
				stmt.setDate(6, null);
			stmt.execute();
             
			rSet = (ResultSet)stmt.getObject(1);
			
			return DALUtil.rSetResults(rSet,"TABLO");

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
}
