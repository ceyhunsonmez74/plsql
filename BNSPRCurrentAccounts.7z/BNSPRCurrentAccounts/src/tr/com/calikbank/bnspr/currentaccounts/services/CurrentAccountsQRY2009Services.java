package tr.com.calikbank.bnspr.currentaccounts.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class CurrentAccountsQRY2009Services {
    
    @GraymoundService("BNSPR_QRY2009_DETAY_INITIALIZE")
    public static GMMap detayGetir(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        int index = 0;
        int row = 0;
        try {
        	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        	String tarih = sdf.format( new Date(iMap.getDate("TARIH").getTime()));
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ?=call PKG_VAKIFBANK.MutabakatDetay(?)}");
            stmt.registerOutParameter(++index, -10);
            stmt.setBigDecimal(++index, BigDecimal.valueOf(Long.valueOf(tarih)));
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            while (rSet.next()) {
                oMap.put("AKTIFDETAY", row, "ACCOUNT_NO", rSet.getObject("ACCOUNT_NO"));
                oMap.put("AKTIFDETAY", row, "AMOUNT", rSet.getObject("AMOUNT"));
                oMap.put("AKTIFDETAY", row, "ATM_CODE", rSet.getObject("ATM_CODE"));
                oMap.put("AKTIFDETAY", row, "CARD_NO", rSet.getObject("CARD_NO"));
                oMap.put("AKTIFDETAY", row, "CURR_CODE", rSet.getObject("CURR_CODE"));
                oMap.put("AKTIFDETAY", row, "IBAN", rSet.getObject("IBAN"));
                oMap.put("AKTIFDETAY", row, "IDENTITYNO", rSet.getObject("IDENTITYNO"));
                oMap.put("AKTIFDETAY", row, "STAN", rSet.getObject("STAN"));
                oMap.put("AKTIFDETAY", row, "TRANSACTIONDATETIME2", rSet.getObject("TRANSACTIONDATETIME2"));
                oMap.put("AKTIFDETAY", row, "TX_NO", rSet.getObject("TX_NO"));
                oMap.put("AKTIFDETAY", row, "NUMARA", rSet.getObject("NUMARA"));
                oMap.put("AKTIFDETAY", row, "NEW_ATM", rSet.getObject("NEW_ATM"));
                row++;
                
            }
            
            
            return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
            
        }
        
    }
    
    @GraymoundService("BNSPR_QRY2009_QUERY_GETIR")
    public static GMMap sorguGetir(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        int index = 0;
        int row = 0;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            String tarih = sdf.format(new Date(iMap.getDate("BANKA_TARIH").getTime()));
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ call PKG_VAKIFBANK.MUTABAKAT(?,?,?)}");
            stmt.setBigDecimal(++index, BigDecimal.valueOf(Long.valueOf(tarih)));
            stmt.registerOutParameter(++index, -10);
            stmt.registerOutParameter(++index, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(index - 1);
            while (rSet.next()) {
                oMap.put("YATAN", row, "AKTIFSAYI", rSet.getObject("AKTIFSAYI"));
                oMap.put("YATAN", row, "AKTIFTUTAR", rSet.getObject("AKTIFTUTAR"));
                row++;
                
            }
            rSet = (ResultSet) stmt.getObject(index);
            
            row = 0;
            while (rSet.next()) {
                oMap.put("YATAN", row, "VAKIFSAYI", rSet.getObject("VAKIFSAYI"));
                oMap.put("YATAN", row, "VAKIFTUTAR", rSet.getObject("VAKIFTUTAR"));
                row++;
                
            }
            
            GMMap colorChanged = new GMMap();
            colorChanged.put("setBackground", Color.RED);
            colorChanged.put("setForeground", Color.BLACK);
            
            GMMap colorNotChanged  = new GMMap();
            colorNotChanged.put("setBackground", Color.WHITE);
            colorNotChanged.put("setForeground", Color.BLACK);
            
            index = 0;
            while (index < oMap.getSize("YATAN")) {
                if (oMap.getString("YATAN", index, "AKTIFTUTAR") != null && oMap.getString("YATAN", index, "VAKIFTUTAR") != null) {
                    if (!oMap.getString("YATAN", index, "AKTIFTUTAR").equals(oMap.getString("YATAN", index, "VAKIFTUTAR"))) {
                        oMap.put("COLOR_DATA_YATAN", index, "AKTIFTUTAR", colorChanged);
                        oMap.put("COLOR_DATA_YATAN", index, "VAKIFTUTAR", colorChanged);
                    }
                    
                    else {
                        oMap.put("COLOR_DATA_YATAN", index, "AKTIFTUTAR", colorNotChanged);
                        oMap.put("COLOR_DATA_YATAN", index, "VAKIFTUTAR", colorNotChanged);
                    }
                }
                else {
                    if (oMap.getString("YATAN", index, "VAKIFTUTAR") != null && oMap.getString("YATAN", index, "AKTIFTUTAR") == null) {
                        oMap.put("COLOR_DATA_YATAN", index, "VAKIFTUTAR", colorChanged);
                    }
                    if (oMap.getString("YATAN", index, "VAKIFTUTAR") == null && oMap.getString("YATAN", index, "AKTIFTUTAR") != null) {
                        oMap.put("COLOR_DATA_YATAN", index, "AKTIFTUTAR", colorChanged);
                    }
                    
                }
                if (oMap.getString("YATAN", index, "AKTIFSAYI") != null && oMap.getString("YATAN", index, "VAKIFSAYI") != null) {
                    if (!oMap.getString("YATAN", index, "AKTIFSAYI").equals(oMap.getString("YATAN", index, "VAKIFSAYI"))) {
                        oMap.put("COLOR_DATA_YATAN", index, "AKTIFSAYI", colorChanged);
                        oMap.put("COLOR_DATA_YATAN", index, "VAKIFSAYI", colorChanged);
                    }
                    else {
                        oMap.put("COLOR_DATA_YATAN", index, "VAKIFTUTAR", colorNotChanged);
                        oMap.put("COLOR_DATA_YATAN", index, "AKTIFTUTAR", colorNotChanged);
                    }
                }
                else {
                    if (oMap.getString("YATAN", index, "AKTIFSAYI") != null && oMap.getString("YATAN", index, "VAKIFSAYI") == null) {
                        oMap.put("COLOR_DATA_YATAN", index, "AKTIFSAYI", colorChanged);
                    }
                    if (oMap.getString("YATAN", index, "AKTIFSAYI") == null && oMap.getString("YATAN", index, "VAKIFSAYI") != null) {
                        oMap.put("COLOR_DATA_YATAN", index, "VAKIFSAYI", colorChanged);
                    }
                }
                index++;
            }
            
            return oMap;
            
        }
        
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
            
        }
        
    }
    
    
    @GraymoundService("BNSPR_QRY2084_IZLEME_SORGULA")
    public static GMMap izlemeSorgula (GMMap iMap) {
        
        GMMap oMap = new GMMap();
        String proc = "{call PKG_SEKER.islemIzleme(?,?)}";
        
        
        try {
            Object[] inputValues =  new Object[]{ BnsprType.DATE, iMap.getDate("TARIH")};
            Object[] outputValues = new Object[]{ BnsprType.REFCURSOR, "MUTABAKAT"};
            oMap = (GMMap) DALUtil.callOracleProcedure(proc ,inputValues ,outputValues );
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    
}
