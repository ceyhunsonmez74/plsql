package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MaasOdemeleriKulPrTx;
import tr.com.calikbank.bnspr.dao.MaasOdemeleriKulPrTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsTRN2404Services {
	@GraymoundService("BNSPR_TRN2404_GET_KURUMLAR")
	public static GMMap queryKurumPersonel(GMMap iMap){
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			StringBuilder query = new StringBuilder();
			GMMap oMap = new GMMap();
			
			query.append("select decode((select k.kurum_kodu from maas_odemeleri_kul_pr k where k.kullanici_kodu = ? and k.kurum_kodu = m.kod), null, null, 1) SEC, ");
			query.append("m.kod, m.aciklama from gnl_musteri_grup_kod_pr m ");
			query.append("where kod in (select grup_kod from GNL_MUST_GRUP_AMAC_ILISKI_PR Where amac_kod = '1') ");
			query.append("order by m.kod");
			
			stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, iMap.getString("KULLANICI_KODU"));
			
			rSet = stmt.executeQuery();
			
			String tableName = "KURUMLAR_TABLE";
			int i = 0;
			while (rSet.next()) {
				if (rSet.getString("SEC") == null)
					oMap.put(tableName, i, "SEC", "0");
				else
					oMap.put(tableName, i, "SEC", "1");
				oMap.put(tableName, i, "KURUM_KODU", rSet.getString("kod"));
				oMap.put(tableName, i, "KURUM_ADI", rSet.getString("aciklama"));
				i++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2404_SAVE_KURUMLAR")
	public static Map<?, ?> saveKurumPersonel(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "KURUMLAR_TABLE";
			List<?> firmaList = (List<?>) iMap.get(tableName);
			
			for (int j = 0; j < firmaList.size(); j++) {
				MaasOdemeleriKulPrTx maasOdemeleriKulPrTx = new MaasOdemeleriKulPrTx();
				MaasOdemeleriKulPrTxId id = new MaasOdemeleriKulPrTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setKullaniciKodu(iMap.getString("KULLANICI_KODU"));
				id.setKurumKodu(iMap.getString(tableName, j, "KURUM_KODU"));
				maasOdemeleriKulPrTx.setId(id);
				if(iMap.getString(tableName, j, "SEC").equals("0"))
					maasOdemeleriKulPrTx.setSec("0");
				else
					maasOdemeleriKulPrTx.setSec("1");

				session.save(maasOdemeleriKulPrTx);
			}
			
			session.flush();
			
			iMap.put("TRX_NAME", "2404");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
		}
	}	

	@GraymoundService("BNSPR_TRN2404_GET_PERSONEL_KURUM_INFO")
	public static GMMap getPersonelKurumInfo(GMMap iMap) {
		GMMap oMap=new GMMap();
		try{
			Session session=DAOSession.getSession("BNSPRDal");
			ArrayList<HashMap<String, Object>> kurumList = new ArrayList<HashMap<String, Object>>();
			
			List<?> list = (List<?>)session.createCriteria(MaasOdemeleriKulPrTx.class)
										   .add(Restrictions.eq("id.txNo", new BigDecimal((String)iMap.getString("TRX_NO"))))
										   .list();
			
			oMap.put("KULLANICI_KODU", ((MaasOdemeleriKulPrTx)list.get(0)).getId().getKullaniciKodu());
			oMap.put("KULLANICI_ADI", LovHelper.diLov(oMap.getString("KULLANICI_KODU"), "2404/LOV_KULLANICI", "KULLANICI_ADI"));
			
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				MaasOdemeleriKulPrTx maasOdemeleriKulPrTx = (MaasOdemeleriKulPrTx) iterator.next();
				
				HashMap<String, Object> rowData = new HashMap<String, Object>();
				
				rowData.put("SEC", GuimlUtil.convertToCheckBoxValue(maasOdemeleriKulPrTx.getSec()));
				rowData.put("KURUM_KODU", maasOdemeleriKulPrTx.getId().getKurumKodu());
				rowData.put("KURUM_ADI", getKurumAdi(maasOdemeleriKulPrTx.getId().getKurumKodu()));
				
				kurumList.add(rowData);
			}

			oMap.put("KURUMLAR_TABLE", kurumList);

	        return oMap; 
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static String getKurumAdi(String kurumKodu)
	{
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			StringBuilder query = new StringBuilder();
			
			query.append("select aciklama from gnl_musteri_grup_kod_pr where kod = ?");
			
			stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, kurumKodu);
			
			rSet = stmt.executeQuery();
			
			rSet.next();
			return rSet.getString("aciklama");
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
	}
}
