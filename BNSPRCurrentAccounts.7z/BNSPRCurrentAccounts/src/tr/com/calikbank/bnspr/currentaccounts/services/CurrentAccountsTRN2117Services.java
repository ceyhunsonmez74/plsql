package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.commons.lang3.StringUtils;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.UptHavaleGirisTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2117Services {

	@GraymoundService("BNSPR_TRN2117_SAVE")
	public static GMMap save(GMMap iMap) {
		Connection conn 		= null;
		try
		{
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");
			
			UptHavaleGirisTx uptHavaleGirisTx = (UptHavaleGirisTx) session.get(UptHavaleGirisTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if (uptHavaleGirisTx == null) {
				uptHavaleGirisTx = new UptHavaleGirisTx();
			}
			
			
			GMMap islemYapanMap = iMap.getMap("ISLEM_YAPAN_BILGI" ,0);
			if(islemYapanMap != null){
				uptHavaleGirisTx.setGonderenAdSoyad(islemYapanMap.getString("UNVAN"));
				uptHavaleGirisTx.setGonderenKimlikSeriSiraNo(islemYapanMap.getString("KIMLIK_SERI_SIRA_NO"));
				uptHavaleGirisTx.setGonderenKimlikTipi(islemYapanMap.getString("KIMLIK_TIPI"));
				uptHavaleGirisTx.setGonderenPasaportNo(islemYapanMap.getString("PASAPORT_NO"));
				uptHavaleGirisTx.setGonderenTcKimlikNo(islemYapanMap.getString("TCKN"));
				uptHavaleGirisTx.setGonderenVknTckn(iMap.getString("ISLEM_YAPAN_TCKN_VKN"));
				uptHavaleGirisTx.setGonderenTelNo(islemYapanMap.getString("TEL_NO"));
				uptHavaleGirisTx.setGonderenUyruk(islemYapanMap.getString("UYRUK"));
			}
			
			GMMap hesapMusteriBilgiMap = iMap.getMap("HESAP_MUSTERI_BILGILERI" ,0);
			if(hesapMusteriBilgiMap != null){
				uptHavaleGirisTx.setAliciAdSoyad(hesapMusteriBilgiMap.getString("UNVAN"));
				uptHavaleGirisTx.setAliciMusteriNo(hesapMusteriBilgiMap.getBigDecimal("MUSTERI_NO"));
				uptHavaleGirisTx.setAliciVknTckn(!StringUtils.isEmpty(hesapMusteriBilgiMap.getString("TCKN")) ? hesapMusteriBilgiMap.getString("TCKN") : hesapMusteriBilgiMap.getString("VKN"));
				
			}
			uptHavaleGirisTx.setAbOfis(iMap.getString("AB_OFIS"));
			uptHavaleGirisTx.setAciklama(iMap.getString("ACIKLAMA"));			
			uptHavaleGirisTx.setAliciHesapNo(iMap.getString("ALICI_HESAP_NO"));
			uptHavaleGirisTx.setAliciIban(iMap.getString("IBAN"));
			uptHavaleGirisTx.setAliciSube(iMap.getString("ALICI_SUBE_KODU"));
		

			uptHavaleGirisTx.setBayiKod(iMap.getString("BAYI_KOD"));
			uptHavaleGirisTx.setBorcHesapNo(iMap.getBigDecimal("BORC_HESAP_NO"));
			uptHavaleGirisTx.setBorcMusteriNo(iMap.getBigDecimal("BORC_MUSTERI_NO") == null ? new BigDecimal(1003289) : new BigDecimal(1003289));
			uptHavaleGirisTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			uptHavaleGirisTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			

			uptHavaleGirisTx.setIptalTarihi(iMap.getDate("IPTAL_TARIHI"));
			uptHavaleGirisTx.setIptalTersFisNo(iMap.getBigDecimal("IPTAL_TERS_FIS_NO"));
			uptHavaleGirisTx.setIslem(iMap.getString("ISLEM"));
			uptHavaleGirisTx.setIslemTarihi(iMap.getDate("ISLEM_TARIHI"));
			uptHavaleGirisTx.setIslemYapanAdSoyad(iMap.getString("ISLEM_YAPAN_AD_SOYAD"));
			uptHavaleGirisTx.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
			uptHavaleGirisTx.setKasaKimlikTipi(iMap.getBigDecimal("KASA_KIMLIK_TIPI"));
			uptHavaleGirisTx.setKurumAdi(iMap.getString("KURUM_ADI"));
			uptHavaleGirisTx.setKurumKod(iMap.getString("KURUM_KOD"));
			uptHavaleGirisTx.setKurumReferans(iMap.getString("KURUM_REFERANS"));
			uptHavaleGirisTx.setMasraf(iMap.getBigDecimal("MASRAF"));
			uptHavaleGirisTx.setMasrafHesapNo(iMap.getBigDecimal("MASRAF_HESAP_NO"));
			uptHavaleGirisTx.setMasrafTahsilDoviz(iMap.getString("MASRAF_TAHSIL_DOVIZ"));
			uptHavaleGirisTx.setMasrafTutari(iMap.getBigDecimal("MASRAF_TUTARI"));
			uptHavaleGirisTx.setOdemeTuru(iMap.getString("ODEME_TURU"));
			uptHavaleGirisTx.setOfisAdi(iMap.getString("OFIS_ADI"));
			uptHavaleGirisTx.setReferansNo(iMap.getString("REFERANS_NO"));
			uptHavaleGirisTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			uptHavaleGirisTx.setTuReferans(iMap.getString("TU_REFERANS"));
			uptHavaleGirisTx.setTutar(iMap.getBigDecimal("TUTAR"));
			uptHavaleGirisTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));



			session.saveOrUpdate(uptHavaleGirisTx);
			session.flush();
			
			

			iMap.put("TRX_NAME", "2117");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		} catch (Exception ex)
		{
			throw ExceptionHandler.convertException(ex);
		}
		finally {
				GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2117_ISLEM_BILGISI_GUNCELLE")
	public static GMMap islemBilgisiGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN2117.UPT_islem_bilgisi_guncelle(?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
			stmt.setString(i++, iMap.getString("ACIKLAMA"));
			GMMap islemYapanMap = iMap.getMap("ISLEM_YAPAN_BILGI", 0);
			stmt.setString(i++, islemYapanMap != null ? islemYapanMap.getString("UNVAN") : null);
			stmt.setString(i++, iMap.getString("ISLEM_YAPAN_TCKN_VKN"));
			stmt.setString(i++, iMap.getString("TU_REFERANS"));
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.execute();
			
			oMap.put("ESKI_TUTAR", stmt.getBigDecimal(7));
			
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}

	}
	


	@GraymoundService("BNSPR_TRN2117_CANCEL")
	public static GMMap cancel(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN2117.cash_transfer_cancel(?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("BANKA_ISLEM_NO"));

			stmt.execute();

			oMap.put("RESPONSE", "2");

			return oMap;
		}
		catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}

	}

}
