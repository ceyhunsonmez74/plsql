package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsQRY2041Services {
	@GraymoundService("BNSPR_QRY2041_GET_BLOKE_HAREKET")
	public static GMMap getHavaleHareket1(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int pCount = 1;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_current_accounts.RC_QRY2041_GET_BLOKE_HAREKET(?,?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(pCount++, -10); //ref cursor
			stmt.setBigDecimal(pCount++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(pCount++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setBigDecimal(pCount++, iMap.getBigDecimal("SUBE_KODU"));
			stmt.setString(pCount++, iMap.getString("DURUM_KODU"));
			stmt.setString(pCount++, iMap.getString("BLOKE_NEDEN_KOD"));

			if ((iMap.get("K_BLOKE_COZME_TARIHI_1") != null)) {
				stmt.setDate(pCount++, new java.sql.Date(iMap.getDate("K_BLOKE_COZME_TARIHI_1").getTime()));
			} else {
				stmt.setDate(pCount++, null);
			}

			if ((iMap.get("K_BLOKE_COZME_TARIHI_2") != null)) {
				stmt.setDate(pCount++, new java.sql.Date(iMap.getDate("K_BLOKE_COZME_TARIHI_2").getTime()));
			} else {
				stmt.setDate(pCount++, null);
			}

			if ((iMap.get("BLOKE_TARIHI_1") != null)) {
				stmt.setDate(pCount++, new java.sql.Date(iMap.getDate("BLOKE_TARIHI_1").getTime()));
			} else {
				stmt.setDate(pCount++, null);
			}

			if ((iMap.get("BLOKE_TARIHI_2") != null)) {
				stmt.setDate(pCount++, new java.sql.Date(iMap.getDate("BLOKE_TARIHI_2").getTime()));
			} else {
				stmt.setDate(pCount++, null);
			}
			stmt.setString(pCount++, iMap.getString("DOVIZ_KODU"));

			if (iMap.getBigDecimal("TUTAR_1").toString().equals("0.00")) {
				stmt.setBigDecimal(pCount++, null);
			} else {
				stmt.setBigDecimal(pCount++, iMap.getBigDecimal("TUTAR_1"));
			}

			if (iMap.getBigDecimal("TUTAR_2").toString().equals("0.00")) {
				stmt.setString(pCount++, null);
			} else {
				stmt.setBigDecimal(pCount++, iMap.getBigDecimal("TUTAR_2"));
			}

			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			String tableName = "BLOKE_IZLEME";
			
			int i = 0;
			while (rSet.next()) {
				oMap.put(tableName, i, "HESAP_NO", rSet.getString("hesap_no"));
				oMap.put(tableName, i, "MUSTERI_NO", rSet.getString("musteri_no"));
				oMap.put(tableName, i, "UNVAN", rSet.getString("UNVAN"));
				oMap.put(tableName, i, "BLOKE_REFERANS", rSet.getString("bloke_referans"));
				oMap.put(tableName, i, "DOVIZ_KODU", rSet.getString("doviz_kodu"));
				oMap.put(tableName, i, "DURUM_KODU", rSet.getString("durum_kodu"));
				oMap.put(tableName, i, "BLOKE_TUTARI_DI", rSet.getString("bloke_tutari"));
				oMap.put(tableName, i, "BLOKE_ACIKLAMA", rSet.getString("BLOKE_ACIKLAMA"));
				
				GMMap myMap = new GMMap();
				myMap.put("HESAP_NO", rSet.getString("hesap_no"));
				oMap.put(tableName, i, "GUNCEL_BAKIYE", 
						GMServiceExecuter.call("BNSPR_COMMON_GET_DEFTER_BAKIYE"	, myMap).getBigDecimal("DEFTER_BAKIYE"));
				
				oMap.put(tableName, i, "GUNCEL_TOPLAM_BLOKE", getBlokeTutari(rSet.getString("hesap_no")));
				oMap.put(tableName, i, "BLOKE_TARIHI", rSet.getDate("bloke_tarihi"));
				oMap.put(tableName, i, "BLOKE_BITIS_TARIHI", rSet.getDate("bloke_bitis_tarihi"));
				if ("E".equals(rSet.getString("ortak_hesap_f"))) {
					oMap.put(tableName, i, "ORTAK_HESAP_F", "Evet");
				} else {
					oMap.put(tableName, i, "ORTAK_HESAP_F", "Hay�r");
				}
				oMap.put(tableName, i, "BLOKE_NEDEN_KODU", rSet.getString("bloke_neden_kodu"));
				oMap.put(tableName, i, "BLOKE_NEDEN_ACIKLAMASI", LovHelper.diLov(rSet.getString("bloke_neden_kodu"), "2041Q/LOV_BLOKE_NEDEN", "ACIKLAMA"));
				oMap.put(tableName, i, "BAKIYE_DI", rSet.getString("bakiye"));
				oMap.put(tableName, i, "TOPLAM_BLOKE_DI", rSet.getString("toplam_bloke_tutari"));
				if(rSet.getBigDecimal("toplam_bloke_tutari") != null && rSet.getBigDecimal("bloke_tutari") != null )
					oMap.put(tableName, i, "ISLEM_SONRASI_BLOKE_TUTARI", rSet.getBigDecimal("toplam_bloke_tutari").add(rSet.getBigDecimal("bloke_tutari")));
				else if(rSet.getBigDecimal("toplam_bloke_tutari") == null && rSet.getBigDecimal("bloke_tutari") != null)
					oMap.put(tableName, i, "ISLEM_SONRASI_BLOKE_TUTARI", rSet.getBigDecimal("bloke_tutari"));
				else if(rSet.getBigDecimal("toplam_bloke_tutari") != null && rSet.getBigDecimal("bloke_tutari") == null)
					oMap.put(tableName, i, "ISLEM_SONRASI_BLOKE_TUTARI", rSet.getBigDecimal("toplam_bloke_tutari"));
				oMap.put(tableName, i, "F_MUSTERI_BLOKE", LovHelper.diLov(rSet.getString("musteri_no"), "2041Q/LOV_MUSTERI", "F_MUSTERI_BLOKE"));
				i++;
			}
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet);
		}
	}
	


	private static BigDecimal getBlokeTutari(String hesapNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_hesap.bloke_tutari_al(?)}");

			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setString(2, hesapNo);

			stmt.execute();

			return stmt.getBigDecimal(1);

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}
	
	@GraymoundService("BNSPR_QRY2041_GET_BLOKE_DETAY")
    public static GMMap getBlokeDetay(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
           
            String procStr= "{call PKG_RC_2041.get_bloke_info(?,?)}";
            DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy"); //Simple date formatter
            DateFormat stf = new SimpleDateFormat("hh:mm:ss"); //simple time formatter
            int i = 0;
            Object [] inputValues = new Object [2];
            Object [] outputValues= new Object [2];
            inputValues[i++]=BnsprType.STRING;
            inputValues[i++]=iMap.getString("REFERANS_NO");
            i=0;
            outputValues[i++]=BnsprType.REFCURSOR;
            outputValues[i++]="LIST";
      
         
               
            oMap=(GMMap)DALUtil.callOracleProcedure(procStr , inputValues , outputValues);
              
            oMap.put("HESAP_NO", oMap.getString("LIST" , 0 , "HESAP_NO"));
            oMap.put("DOVIZ_KODU", oMap.getString("LIST" , 0 , "DOVIZ_KODU"));
            oMap.put("BLOKE_REFERANS", oMap.getString("LIST" , 0 , "BLOKE_REFERANS"));
            oMap.put("BLOKE_TARIHI", oMap.getString("LIST" , 0 , "BLOKE_TARIHI")==null?null:sdf.parse(oMap.getString("LIST" , 0 , "BLOKE_TARIHI")));
            oMap.put("BLOKE_BITIS_TARIHI",oMap.getString("LIST" , 0 , "BLOKE_BITIS_TARIHI")==null?null:sdf.parse(oMap.getString("LIST" , 0 , "BLOKE_BITIS_TARIHI")));
            oMap.put("BLOKE_TUTARI", oMap.getBigDecimal("LIST" , 0 , "BLOKE_TUTARI"));
            oMap.put("BLOKE_NEDEN_KODU", LovHelper.diLov(oMap.getString("LIST" , 0 , "BLOKE_NEDEN_KODU"),"2041Q/LOV_BLOKE_NEDEN","ACIKLAMA"));
            oMap.put("DI_BLOKE_NEDEN_KODU", oMap.getString("LIST" , 0 , "DOVIZ_KODU"));
            oMap.put("ACIKLAMA", oMap.getString("LIST" , 0 , "ACIKLAMA"));
            oMap.put("KAYIT_TARIH", oMap.getString("LIST" , 0 , "KAYIT_TARIH")==null?null:sdf.parse(oMap.getString("LIST" , 0 , "KAYIT_TARIH")));
            oMap.put("KAYIT_SISTEM_TARIHI", oMap.getString("LIST" , 0 , "KAYIT_SISTEM_TARIHI")==null?null:sdf.parse(oMap.getString("LIST" , 0 , "KAYIT_SISTEM_TARIHI")));
            oMap.put("KAYIT_KULLANICI_KODU", oMap.getString("LIST" , 0 , "KAYIT_KULLANICI_KODU"));
            oMap.put("ONAY_TARIH", oMap.getString("LIST" , 0 , "ONAY_TARIH")==null?null:sdf.parse(oMap.getString("LIST" , 0 , "ONAY_TARIH")));
            oMap.put("ONAY_SISTEM_TARIHI", oMap.getString("LIST" , 0 , "ONAY_SISTEM_TARIHI")==null?null:sdf.parse(oMap.getString("LIST" , 0 , "ONAY_SISTEM_TARIHI")));
            oMap.put("ONAY_KULLANICI_KODU", oMap.getString("LIST" , 0 , "ONAY_KULLANICI_KODU"));
            oMap.put("COZ_KAYIT_SISTEM_TARIH", oMap.getString("LIST" , 0 , "COZ_KAYIT_SISTEM_TARIH")==null?null:sdf.parse(oMap.getString("LIST" , 0 , "COZ_KAYIT_SISTEM_TARIH")));
            oMap.put("COZ_KAYIT_TARIH",oMap.getString("LIST" , 0 , "COZ_KAYIT_TARIH")==null?null:sdf.parse(oMap.getString("LIST" , 0 , "COZ_KAYIT_TARIH")));
            oMap.put("COZ_KAYIT_KULLANICI_KODU", oMap.getString("LIST" , 0 , "COZ_KAYIT_KULLANICI_KODU"));
            oMap.put("COZ_ONAY_TARIH", oMap.getString("LIST" , 0 , "COZ_ONAY_TARIH")==null?null:sdf.parse(oMap.getString("LIST" , 0 , "COZ_ONAY_TARIH")));
            oMap.put("COZ_ONAY_SISTEM_TARIH", oMap.getString("LIST" , 0 , "COZ_ONAY_SISTEM_TARIH")==null?null:sdf.parse(oMap.getString("LIST" , 0 , "COZ_ONAY_SISTEM_TARIH")));
            oMap.put("COZ_ONAY_KULLANICI_KODU", oMap.getString("LIST" , 0 , "COZ_ONAY_KULLANICI_KODU"));
            oMap.put("KAYIT_SISTEM_SAATI",oMap.getString("LIST" , 0 , "KAYIT_SISTEM_SAATI"));
            oMap.put("ONAY_SISTEM_SAATI", oMap.getString("LIST" , 0 , "ONAY_SISTEM_SAATI"));
            oMap.put("COZ_SISTEM_SAATI", oMap.getString("LIST" , 0 , "COZ_SISTEM_SAATI"));
            oMap.put("COZ_SISTEM_ONAY_SAATI", oMap.getString("LIST" , 0 , "COZ_SISTEM_ONAY_SAATI"));
            oMap.put("HBN", oMap.getString("LIST" , 0 , "HBN"));
            oMap.put("VDKOD", oMap.getString("LIST" , 0 , "VDKOD"));
            oMap.put("DI_VDKOD",  LovHelper.diLov(oMap.getString("LIST" , 0 , "VDKOD"), "2005/LOV_VDKOD", "VERGI_D_ADI") );
        

            return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }

    }
}



/*  package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.dao.MuhBloke;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsQRY2041Services {
    @GraymoundService("BNSPR_QRY2041_GET_BLOKE_HAREKET")
    public static GMMap getHavaleHareket1(GMMap iMap) {

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = GMServerDatasource.getConnection("java:/GraymoundDS");

            StringBuilder query = new StringBuilder();

            query.append("select a.hesap_no, a.musteri_no, pkg_musteri.unvan(a.musteri_no) UNVAN,");
            query.append("a.bloke_referans, a.doviz_kodu, a.durum_kodu, a.bloke_tutari,");
            query.append("a.bloke_tarihi, a.bloke_bitis_tarihi, /*pkg_hesap.ortak_hesap_f(a.hesap_no )*/ /*'H' ortak_hesap_f,a.bloke_neden_kodu,a.kull_bakiye as bakiye,a.toplam_bloke_tutari ");
            query.append("from muh_bloke a ");
            query.append("where a.musteri_no = NVL(?,musteri_no) ");
            query.append("and a.hesap_no = NVL(?,a.hesap_no) ");
            query.append("and a.kayit_kullanici_bolum_kodu = NVL(?,a.kayit_kullanici_bolum_kodu) ");
            query.append("and a.durum_kodu = NVL(?,a.durum_kodu) ");
            query.append("and a.bloke_neden_kodu = NVL(?,a.bloke_neden_kodu) ");
            query.append("and trunc(NVL(a.bloke_bitis_tarihi,sysdate)) between NVL(?,trunc(NVL(a.bloke_bitis_tarihi,sysdate))) and NVL(?,trunc(NVL(a.bloke_bitis_tarihi,sysdate))) ");
            query.append("and trunc(a.bloke_tarihi) between NVL(?,trunc(a.bloke_tarihi)) and NVL(?,trunc(a.bloke_tarihi)) ");
            query.append("and a.doviz_kodu = NVL(?,a.doviz_kodu) ");
            query.append("and a.bloke_tutari between NVL(?,a.bloke_tutari) and NVL(?,a.bloke_tutari) ");
            query.append("order by a.musteri_no,a.hesap_no,a.bloke_referans ");

            stmt = conn.prepareCall(query.toString());

            stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setBigDecimal(2, iMap.getBigDecimal("HESAP_NO"));
            stmt.setBigDecimal(3, iMap.getBigDecimal("SUBE_KODU"));
            stmt.setString(4, iMap.getString("DURUM_KODU"));
            stmt.setString(5, iMap.getString("BLOKE_NEDEN_KOD"));

            if ((iMap.get("K_BLOKE_COZME_TARIHI_1") != null)) {
                stmt.setDate(6, new java.sql.Date(iMap.getDate("K_BLOKE_COZME_TARIHI_1").getTime()));
            } else {
                stmt.setDate(6, null);
            }

            if ((iMap.get("K_BLOKE_COZME_TARIHI_2") != null)) {
                stmt.setDate(7, new java.sql.Date(iMap.getDate("K_BLOKE_COZME_TARIHI_2").getTime()));
            } else {
                stmt.setDate(7, null);
            }

            if ((iMap.get("BLOKE_TARIHI_1") != null)) {
                stmt.setDate(8, new java.sql.Date(iMap.getDate("BLOKE_TARIHI_1").getTime()));
            } else {
                stmt.setDate(8, null);
            }

            if ((iMap.get("BLOKE_TARIHI_2") != null)) {
                stmt.setDate(9, new java.sql.Date(iMap.getDate("BLOKE_TARIHI_2").getTime()));
            } else {
                stmt.setDate(9, null);
            }
            stmt.setString(10, iMap.getString("DOVIZ_KODU"));

            if (iMap.getBigDecimal("TUTAR_1").toString().equals("0.00")) {
                stmt.setBigDecimal(11, null);
            } else {
                stmt.setBigDecimal(11, iMap.getBigDecimal("TUTAR_1"));
            }

            if (iMap.getBigDecimal("TUTAR_2").toString().equals("0.00")) {
                stmt.setString(12, null);
            } else {
                stmt.setBigDecimal(12, iMap.getBigDecimal("TUTAR_2"));
            }
            GMMap oMap = new GMMap();
            
            rSet = stmt.executeQuery();

            String tableName = "BLOKE_IZLEME";
            int i = 0;
            while (rSet.next()) {
                oMap.put(tableName, i, "HESAP_NO", rSet.getString("hesap_no"));
                oMap.put(tableName, i, "MUSTERI_NO", rSet.getString("musteri_no"));
                oMap.put(tableName, i, "UNVAN", rSet.getString("UNVAN"));
                oMap.put(tableName, i, "BLOKE_REFERANS", rSet.getString("bloke_referans"));
                oMap.put(tableName, i, "DOVIZ_KODU", rSet.getString("doviz_kodu"));
                oMap.put(tableName, i, "DURUM_KODU", rSet.getString("durum_kodu"));
                oMap.put(tableName, i, "BLOKE_TUTARI_DI", rSet.getString("bloke_tutari"));
                oMap.put(tableName, i, "GUNCEL_BAKIYE", getHesapBakiye(rSet.getString("hesap_no")));
                oMap.put(tableName, i, "GUNCEL_TOPLAM_BLOKE", getBlokeTutari(rSet.getString("hesap_no")));
                oMap.put(tableName, i, "BLOKE_TARIHI", rSet.getDate("bloke_tarihi"));
                oMap.put(tableName, i, "BLOKE_BITIS_TARIHI", rSet.getDate("bloke_bitis_tarihi"));
                if ("E".equals(rSet.getString("ortak_hesap_f"))) {
                    oMap.put(tableName, i, "ORTAK_HESAP_F", "Evet");
                } else {
                    oMap.put(tableName, i, "ORTAK_HESAP_F", "Hay�r");
                }
                oMap.put(tableName, i, "BLOKE_NEDEN_KODU", rSet.getString("bloke_neden_kodu"));
                oMap.put(tableName, i, "BLOKE_NEDEN_ACIKLAMASI", LovHelper.diLov(rSet.getString("bloke_neden_kodu"), "2041Q/LOV_BLOKE_NEDEN", "ACIKLAMA"));
                oMap.put(tableName, i, "BAKIYE_DI", rSet.getString("bakiye"));
                oMap.put(tableName, i, "TOPLAM_BLOKE_DI", rSet.getString("toplam_bloke_tutari"));
                i++;
            }
            return oMap;

        } catch (Exception e) {
            throw new GMRuntimeException(1, e);
        } finally {
            GMServerDatasource.close(conn);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(rSet);
        }
    }

    private static BigDecimal getHesapBakiye(String hesapNo) {
        Connection conn = null;
        CallableStatement stmt = null;
        try {
            conn = GMServerDatasource.getConnection("java:/GraymoundDS");

            stmt = conn.prepareCall("{? = call pkg_hesap.Hesap_Bakiye(?)}");

            stmt.registerOutParameter(1, Types.INTEGER);
            stmt.setString(2, hesapNo);

            stmt.execute();

            return stmt.getBigDecimal(1);

        } catch (Exception e) {
            throw new GMRuntimeException(0, e);
        } finally {
            GMServerDatasource.close(conn);
            GMServerDatasource.close(stmt);
        }
    }

    private static BigDecimal getBlokeTutari(String hesapNo) {
        Connection conn = null;
        CallableStatement stmt = null;
        try {
            conn = GMServerDatasource.getConnection("java:/GraymoundDS");

            stmt = conn.prepareCall("{? = call pkg_hesap.bloke_tutari_al(?)}");

            stmt.registerOutParameter(1, Types.DECIMAL);
            stmt.setString(2, hesapNo);

            stmt.execute();

            return stmt.getBigDecimal(1);

        } catch (SQLException e) {
            throw new GMRuntimeException(0, e);
        } finally {
            GMServerDatasource.close(conn);
            GMServerDatasource.close(stmt);
        }
    }

    @GraymoundService("BNSPR_QRY2041_GET_BLOKE_DETAY")
    public static GMMap getBlokeDetay(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            MuhBloke muhBloke = (MuhBloke) session.createCriteria(MuhBloke.class).add(Restrictions.eq("blokeReferans", iMap.getString("REFERANS_NO"))).uniqueResult();
            oMap.put("HESAP_NO", muhBloke.getHesapNo());
            oMap.put("DOVIZ_KODU", muhBloke.getDovizKodu());
            oMap.put("BLOKE_REFERANS", muhBloke.getBlokeReferans());
            oMap.put("BLOKE_TARIHI", muhBloke.getBlokeTarihi());
            oMap.put("BLOKE_BITIS_TARIHI", muhBloke.getBlokeBitisTarihi());
            oMap.put("BLOKE_TUTARI", muhBloke.getBlokeTutari());
            oMap.put("BLOKE_NEDEN_KODU", muhBloke.getBlokeNedenKodu());
            oMap.put("DI_BLOKE_NEDEN_KODU", LovHelper.diLov(muhBloke.getBlokeNedenKodu(), "2041Q/LOV_BLOKE_NEDEN", "ACIKLAMA"));
            oMap.put("ACIKLAMA", muhBloke.getAciklama());
            oMap.put("KAYIT_TARIH", muhBloke.getKayitTarih());
            oMap.put("KAYIT_SISTEM_TARIHI", muhBloke.getKayitSistemTarihi());
            oMap.put("KAYIT_KULLANICI_KODU", muhBloke.getKayitKullaniciKodu());
            oMap.put("ONAY_TARIH", muhBloke.getOnayTarih());
            oMap.put("ONAY_SISTEM_TARIHI", muhBloke.getOnaySistemTarihi());
            oMap.put("ONAY_KULLANICI_KODU", muhBloke.getOnayKullaniciKodu());
            oMap.put("COZ_KAYIT_TARIH", muhBloke.getCozKayitTarih());
            oMap.put("COZ_KAYIT_SISTEM_TARIH", muhBloke.getCozKayitSistemTarih());
            oMap.put("COZ_KAYIT_KULLANICI_KODU", muhBloke.getCozKayitKullaniciKodu());
            oMap.put("COZ_ONAY_TARIH", muhBloke.getCozOnayTarih());
            oMap.put("COZ_ONAY_SISTEM_TARIH", muhBloke.getCozOnaySistemTarih());
            oMap.put("COZ_ONAY_KULLANICI_KODU", muhBloke.getCozOnayKullaniciKodu());
    
            return oMap;
        }
        catch (Exception e) {
            throw new GMRuntimeException(0, e);
        }

    }
}
*/
