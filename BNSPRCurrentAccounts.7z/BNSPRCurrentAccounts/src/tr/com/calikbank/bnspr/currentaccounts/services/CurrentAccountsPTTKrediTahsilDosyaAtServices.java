package tr.com.calikbank.bnspr.currentaccounts.services;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.PttKrediTahsilDosyaFtpLog;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.integration.ftp.FtpClient;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsPTTKrediTahsilDosyaAtServices {
	private static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";

	@GraymoundService("BNSPR_PTT_KREDI_TAHSIL_DOSYA_AT")
	public static GMMap pttKrediTahsilDosyaAt(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		PreparedStatement stmt = null;
		CallableStatement stmt1 = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		GMMap xMap = new GMMap();

		GMMap fMap = new GMMap();
		fMap.put("TATIL_GUNU_CALISSIN", "E");
		GMServiceExecuter.executeNT("BNSPR_PTT_KREDI_TAHSIL_DOSYA_FTP", fMap);

		String dosyaNo = DALUtil.getResult("select max(dosya_no) from PTT_KREDI_TAHSIL_DOSYA_FTP_LOG");
		if (checkDosyaFtp(dosyaNo)) {
			try {
				// data gonsonu devam ederken olusuyor ancak bunu sonraki is gunu icin gonderecegiz.
				// loga atilan banka tarihini alip sonrakini buluyoruz.
				String tarih = DALUtil.getResult("select max(tarih) from PTT_KREDI_TAHSIL_DOSYA_FTP_LOG");
				// yyyy-MM-dd 00:00:00.0 olarak geliyor.
				// xMap.put("TARIH_STRING", DALUtil.getResult("select max(tarih) from PTT_KREDI_TAHSIL_DOSYA_FTP_LOG"));
				// DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
				// xMap.put("TARIH", dateFormat.parse(xMap.getString("TARIH_STRING")));
				// xMap.put("SONRAKI_BANKA_TARIHI", GMServiceExecuter.execute("BNSPR_COMMON_SONRAKI_ISGUNU",
				// xMap).get("TARIH"));
				// String tarih = xMap.get("SONRAKI_BANKA_TARIHI").toString();
				String mesajTarih = tarih.subSequence(0, 10).toString();
				tarih = tarih.subSequence(8, 10).toString() + tarih.subSequence(5, 7).toString() + tarih.subSequence(2, 4).toString();

				// dosyaya atilacak bilgiler tablodan okunuyor.
				conn = DALUtil.getGMConnection();
				StringBuffer query = new StringBuffer();

				query.append("SELECT DATA FROM CLKS_PTT_DOSYA ");
				query.append("WHERE DOSYA_NO = (select max(dosya_no) from PTT_KREDI_TAHSIL_DOSYA_FTP_LOG) ");
				query.append("ORDER BY SIRA");

				stmt = conn.prepareStatement(query.toString());
				rSet = stmt.executeQuery();

				// result set teki datalar dosyaya atiliyor.
				FileOutputStream fout;
				BufferedWriter bw;
				String dosyaAdi = "AB" + tarih + ".txt";
				fout = new FileOutputStream(ROOT + File.separator + "files" + File.separator + dosyaAdi);
				bw = new BufferedWriter(new OutputStreamWriter(fout, "ISO-8859-9"));

				while (rSet.next())
					bw.write(new String(rSet.getString(1).getBytes("ISO-8859-9"), "ISO-8859-9") + ((char) 13) + ((char) 10));

				bw.close();
				fout.close();

				// simdi olusan dosyayi atalim.

				conn = DALUtil.getGMConnection();
				stmt1 = conn.prepareCall("{? = call PKG_TRN2070.read_gnl_sifre(?)}");
				stmt1.registerOutParameter(1, -10);
				stmt1.setString(2, "PTT_BORC");
				stmt1.execute();
				rSet = (ResultSet) stmt1.getObject(1);
				rSet.next();

				String serverUri = rSet.getString("ip");
				String username = rSet.getString("user_name");
				String password = rSet.getString("passwd");
				String path = rSet.getString("path");
				BigDecimal port = rSet.getBigDecimal("port");
				String ftpType = rSet.getString("FTP_TURU");

				File file = new File(ROOT + File.separator + "files" + File.separator + dosyaAdi);
				FtpClient ftpClient = new FtpClient(serverUri, port, ftpType, username, password);
				ftpClient.put(path, dosyaAdi, file);

				// log dosyasima log atalim.
				Session session = DAOSession.getSession("BNSPRDal");
				PttKrediTahsilDosyaFtpLog pttKrediTahsilDosyaFtpLog = new PttKrediTahsilDosyaFtpLog();
				pttKrediTahsilDosyaFtpLog.setDosyaNo(new BigDecimal(DALUtil.getResult("select max(dosya_no) from PTT_KREDI_TAHSIL_DOSYA_FTP_LOG")));
				pttKrediTahsilDosyaFtpLog.setMesaj(dosyaAdi + " dosyasi ftp folder a birakilmistir.");
				xMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", xMap).getDate("BANKA_TARIH"));
				pttKrediTahsilDosyaFtpLog.setTarih(xMap.getDate("BANKA_TARIHI"));
				session.save(pttKrediTahsilDosyaFtpLog);
				session.flush();
				sendMail("PTT Kredi Tahsil Bildirim", mesajTarih + " tarihi i�in PTT Kredi Tahsil dosya bildirimi yap�ld�. Dosya adi: " + dosyaAdi);

				file.delete();

				stmt2 = conn.prepareCall("{call PKG_PTT_DOSYA.DOSYA_FTP_GERCEKLESTI (?)}");
				stmt2.setString(1, dosyaNo);
				stmt2.execute();

			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
			finally {
				GMServerDatasource.close(conn);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(stmt1);
				GMServerDatasource.close(stmt2);
				GMServerDatasource.close(rSet);
			}
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_PTT_KREDI_TAHSIL_DOSYA_AT_FTM")
    public static GMMap pttKrediTahsilDosyaAtFTM(GMMap iMap) {

        GMMap oMap = new GMMap();
        Connection conn = null;
        PreparedStatement stmt = null;
        CallableStatement stmt1 = null;
        ResultSet rSet = null;
        String  dosyaAdi= "";
        GMMap fMap = new GMMap();
        fMap.put("TATIL_GUNU_CALISSIN", "E");
        BigDecimal ftmProcessId = new BigDecimal(-1);
        String ftmId = "";
        GMServiceExecuter.executeNT("BNSPR_PTT_KREDI_TAHSIL_DOSYA_FTP", fMap);

        String dosyaNo = DALUtil.getResult("select max(dosya_no) from PTT_KREDI_TAHSIL_DOSYA_FTP_LOG");
        if (checkDosyaFtp(dosyaNo)) {
            try {
                ftmProcessId = FtmUtility.getNextValueOfFTMProcessId();
                ftmId = FtmUtility.getGlobalParam("KREDI_BORC_BILDIRIM_FTM_ID");
                String tarih = DALUtil.getResult("select max(tarih) from PTT_KREDI_TAHSIL_DOSYA_FTP_LOG");
                tarih = tarih.subSequence(8, 10).toString() + tarih.subSequence(5, 7).toString() + tarih.subSequence(2, 4).toString();

                // TODO : BNSPR_PTT_KREDI_TAHSIL_DOSYA_FTP service guncelleyip direk FTM DB atacak hale getirilecek. 
                //        B�ylece DB link ile direk g�nderilecek. Java'ya indirilmeyecek. 
                
                dosyaAdi = "AB" + tarih + ".txt";
                iMap.put("FTM_PROCESS_ID", ftmProcessId);
                GMServiceExecuter.executeNT("BNSPR_PTT_KREDI_TAHSIL_DOSYA_BULK_INSERT_TO_FTM_CONTENT", iMap);
                FtmUtility.ftmTransferSingleFile(ftmId, ftmProcessId, dosyaAdi);
            }
            catch (Exception e) {
                String stackTrace = FtmUtility.getExceptionStackTrace(e);
                FtmUtility.sendMail("!!HATA!!_KREDI BORC DOSYASI" ,"Dosya ��lemede Hata olu�tu.\r\n File Name : "+ dosyaAdi +"\r\nHata : " + e.getMessage() + "\r\n" + stackTrace);
                ExceptionHandler.convertException(e);
                throw ExceptionHandler.convertException(e);
            }
            finally {
                GMServerDatasource.close(conn);
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(stmt1);
                GMServerDatasource.close(rSet);
            }
        }
        return oMap;
	}
	
	
	@GraymoundService("BNSPR_PTT_KREDI_TAHSIL_DOSYA_BULK_INSERT_TO_FTM_CONTENT")
    public static GMMap bulkInsertToFtmContent(GMMap iMap) {
	    Connection conn = null;
	    Connection conn1 = null;
	    PreparedStatement pSet1 = null;
	    PreparedStatement pSet = null;
	    ResultSet rSet = null;

	    try {
	     BigDecimal ftmProcessId =  iMap.getBigDecimal("FTM_PROCESS_ID");   
	     conn = DALUtil.getGMConnection();
	     conn1 = DALUtil.getGMConnection();
	     String SQL = "INSERT INTO FTM.FTM_FILE_CONTENT(OID,FTM_PROCESS_OID,LINE_NUMBER,LINE) VALUES (?,?,?,?)";
	     StringBuffer query = new StringBuffer();
         query.append("SELECT DATA FROM CLKS_PTT_DOSYA ");
         query.append("WHERE DOSYA_NO = (select max(dosya_no) from PTT_KREDI_TAHSIL_DOSYA_FTP_LOG) ");
         query.append("ORDER BY SIRA");

	     pSet1 = conn1.prepareStatement(SQL);
         pSet = conn.prepareStatement(query.toString());
         rSet = pSet.executeQuery();
         BigDecimal lineNumber = BigDecimal.ZERO;
         int i = 0 ; 
         while (rSet.next()) {
             lineNumber = lineNumber.add(BigDecimal.ONE);
             
             pSet1.setString(1, lineNumber.toString());
             pSet1.setBigDecimal(2, ftmProcessId);
             pSet1.setBigDecimal(3, lineNumber);
             pSet1.setString(4, new String(rSet.getString(1).getBytes("ISO-8859-9"),"ISO-8859-9"));
              i++;
             
             pSet1.addBatch();
             if (i % 1000 == 0) {
                pSet1.executeBatch();
             }
         }
         pSet1.executeBatch();
	    }catch (Exception e ) {
	        throw ExceptionHandler.convertException(e);
	    }finally {
	        GMServerDatasource.close(rSet);
            GMServerDatasource.close(pSet);
            GMServerDatasource.close(pSet1);
            GMServerDatasource.close(conn1);
            GMServerDatasource.close(conn);
	    }
	    return iMap;
	}
	
	
	

	   @GraymoundService("BNSPR_PTT_KREDI_TAHSIL_DOSYA_AT_FTM_FINISH")
	    public static GMMap pttKrediTahsilat_Dosya_AT_FTM_Finish(GMMap iMap) {
	   
	       Connection conn = null;
	       CallableStatement stmt2 = null;
	       
	       try {
    	       String dosyaAdi = iMap.getString("FILE_NAME");
    	       GMMap xMap = new GMMap();
    	       Session session = DAOSession.getSession("BNSPRDal");
               String tarih = DALUtil.getResult("select max(tarih) from PTT_KREDI_TAHSIL_DOSYA_FTP_LOG");
               String dosyaNo = DALUtil.getResult("select max(dosya_no) from PTT_KREDI_TAHSIL_DOSYA_FTP_LOG");
               String mesajTarih = tarih.subSequence(0, 10).toString();
    
              PttKrediTahsilDosyaFtpLog pttKrediTahsilDosyaFtpLog = new PttKrediTahsilDosyaFtpLog();
              pttKrediTahsilDosyaFtpLog.setDosyaNo(new BigDecimal(DALUtil.getResult("select max(dosya_no) from PTT_KREDI_TAHSIL_DOSYA_FTP_LOG")));
              pttKrediTahsilDosyaFtpLog.setMesaj(dosyaAdi + " dosyasi FTM ile ftp folder a birakilmistir.");
              xMap.put("BANKA_TARIHI", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", xMap).getDate("BANKA_TARIH"));
              pttKrediTahsilDosyaFtpLog.setTarih(xMap.getDate("BANKA_TARIHI"));
              session.save(pttKrediTahsilDosyaFtpLog);
              session.flush();
              conn = DALUtil.getGMConnection();
              stmt2 = conn.prepareCall("{call PKG_PTT_DOSYA.DOSYA_FTP_GERCEKLESTI (?)}");
              stmt2.setString(1, dosyaNo);
              stmt2.execute();
              
              FtmUtility.sendMail("PTT Kredi Tahsil Bildirim", mesajTarih + " tarihi i�in PTT Kredi Tahsil dosya bildirimi yap�ld�. Dosya adi: " + dosyaAdi);


	       }catch (Exception e) {
	           throw ExceptionHandler.convertException(e);
	       }finally {
	           GMServerDatasource.close(stmt2);
	           GMServerDatasource.close(conn);
              
	       }
	       return iMap;
	       
	   }

	
	private static Boolean checkDosyaFtp(String dosyaNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		String sonuc = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_PTT_DOSYA.DOSYA_FTP_GECEKLESMIS_MI (?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, dosyaNo);
			stmt.execute();
			sonuc = stmt.getString(1);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
		}
		return sonuc.equals("H") ? true : false;
	}

	private static void sendMail(String subject, String mailBody) {
		GMMap servisMap = new GMMap();
		servisMap.put("MAIL_FROM", "system@aktifbank.com.tr");
		GMMap xMap = new GMMap();
		// KKB bildiriminde mail giden kisilerle bu is icin mail giden kisiler ayni.
		xMap.put("PARAMETRE", "KKB_GUNLUK_BILDIRIM_MAIL");
		servisMap.put("MAIL_TO", GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", xMap).get("DEGER"));
		servisMap.put("MAIL_SUBJECT", subject);
		servisMap.put("MAIL_BODY", mailBody);
		servisMap.put("IS_BODY_HTML", "H");
		GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", servisMap);

	}

	
	@GraymoundService("BNSPR_PTT_AYLIK_KREDI_BILDIRIM")
	public static GMMap pttAylikKrediBildirim(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			iMap.putAll(GMServiceExecuter.call("BNSPR_QRY2073_DOSYA_OLUSTUR_SSK", iMap));
			String tmpDosyaAdiSsk = iMap.getString("TEMP_DOSYA_ADI");
			String dosyaAdiSsk = iMap.getString("DOSYA_ADI");

			iMap.putAll(GMServiceExecuter.call("BNSPR_QRY2073_DOSYA_OLUSTUR_EMSAN", iMap));
			String tmpDosyaAdiEmsan = iMap.getString("TEMP_DOSYA_ADI");
			String dosyaAdiEmsan = iMap.getString("DOSYA_ADI");

			iMap.putAll(GMServiceExecuter.call("BNSPR_QRY2073_DOSYA_OLUSTUR_BAGKUR", iMap));
			String tmpDosyaAdiBagkur = iMap.getString("TEMP_DOSYA_ADI");
			String dosyaAdiBagkur = iMap.getString("DOSYA_ADI");

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN2070.read_gnl_sifre(?) }");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, "PTT_KREDI");
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			rSet.next();

			String serverUri = rSet.getString("ip");
			String username = rSet.getString("user_name");
			String password = rSet.getString("passwd");
			String path = rSet.getString("path");
			BigDecimal port = rSet.getBigDecimal("port");
			String ftpType = rSet.getString("FTP_TURU");

			File file = new File(ROOT + File.separator + "files" + File.separator + tmpDosyaAdiSsk);
			FtpClient ftpClient = new FtpClient(serverUri, port, ftpType, username, password);
			ftpClient.put(path, dosyaAdiSsk, file);
			file.delete();

			file = new File(ROOT + File.separator + "files" + File.separator + tmpDosyaAdiEmsan);
			ftpClient.put(path, dosyaAdiEmsan, file);
			file.delete();

			file = new File(ROOT + File.separator + "files" + File.separator + tmpDosyaAdiBagkur);
			ftpClient.put(path, dosyaAdiBagkur, file);
			file.delete();

			sendMail("Kredili M��teri Listesi", dosyaAdiSsk + " , " + dosyaAdiEmsan + " , " + dosyaAdiBagkur + " dosyalar� iletildi.");

			file.delete();

			return iMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet);
		}
	}
	
	
	@GraymoundService("BNSPR_PTT_AYLIK_KREDI_BILDIRIM_FTM")
    public static GMMap pttKrediBildirimOverFTM(GMMap iMap) {
       
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");
        BigDecimal ftmProcessIdForBagKur = new BigDecimal(-1);
        BigDecimal ftmProcessIdForSSK = new BigDecimal(-1);
        BigDecimal ftmProcessIdForEmeksan = new BigDecimal(-1);
        String ftmId = "";
        try {
            ftmProcessIdForSSK = FtmUtility.getNextValueOfFTMProcessId();
            ftmId = FtmUtility.getGlobalParam("KREDI_LISTESI_FTM_ID");
            iMap.put("FTM_PROCESS_ID", ftmProcessIdForSSK);
            iMap.put("KURUM", "SSK");
            GMServiceExecuter.executeNT("BNSPR_QRY2073_KREDI_LISTESI_KAYIT_OLUSTUR_FTM", iMap);
            String SSKfileName = "SS" + dateFormat.format(Calendar.getInstance().getTime()) + ".txt";
            //FtmUtility.ftmTransferFile(ftmId, ftmProcessIdForSSK, fileName);

            ftmProcessIdForBagKur = FtmUtility.getNextValueOfFTMProcessId();
            iMap.put("FTM_PROCESS_ID", ftmProcessIdForBagKur);
            iMap.put("KURUM", "BAGKUR");
            GMServiceExecuter.executeNT("BNSPR_QRY2073_KREDI_LISTESI_KAYIT_OLUSTUR_FTM", iMap);
            String BAGKURfileName = "BG" + dateFormat.format(Calendar.getInstance().getTime()) + ".txt";
            //FtmUtility.ftmTransferFile(ftmId, ftmProcessIdForBagKur,fileName);

            ftmProcessIdForEmeksan = FtmUtility.getNextValueOfFTMProcessId();
            iMap.put("FTM_PROCESS_ID", ftmProcessIdForEmeksan);
     
            iMap.put("KURUM", "EMEKSAN");
            GMServiceExecuter.executeNT("BNSPR_QRY2073_KREDI_LISTESI_KAYIT_OLUSTUR_FTM", iMap);
            String EmeklifileName = "EM" + dateFormat.format(Calendar.getInstance().getTime()) + ".txt";
            FtmUtility.ftmTransferFile(ftmId, ftmProcessIdForEmeksan, EmeklifileName,ftmProcessIdForSSK,SSKfileName,ftmProcessIdForBagKur,BAGKURfileName);
        }catch (Exception e) {
            
            String stackTrace = FtmUtility.getExceptionStackTrace(e);
            FtmUtility.sendMail("!!HATA!!_KREDILI LISTESI" ,"Dosya Transferinde Hata olu�tu.\r\n Hata : " + e.getMessage() + "\r\n" + stackTrace);
            ExceptionHandler.convertException(e);
           }
        FtmUtility.sendMail("!!BA�ARILI!!_KREDI_MUSTERI_LISTESI", "FTM Process ID Listesi \r\n SSK :" + ftmProcessIdForSSK + " , BAGKUR : " + ftmProcessIdForBagKur + " , Emekli Sand��� : " + ftmProcessIdForEmeksan + " dosyalar ba�ar�l� FTM'e iletildi.");

        return iMap;
       
    }
	
	@GraymoundService("BNSPR_PTT_AYLIK_KREDI_BILDIRIM_FTM_FINISH")
	 public static GMMap pttKrediBildirimOverFTM_Finish(GMMap iMap) {
      
	  try{
	      
        String fileDef =   iMap.getString("FILE_DEF_ID");
        String processID =  iMap.getString("PROCESS_ID");
        String readProcessID =  iMap.getString("READ_PROCESS_ID");
        String fileName =  iMap.getString("FILE_NAME");
        
        boolean errorExists = iMap.containsKey("ERROR");
        String mailHeader = "Dosya ismi : " + fileName + " File Definition ID : " + fileDef + " Process ID : " + processID + "  Read Process ID : " + readProcessID;
       
        String subject =  (errorExists ? "FTM_GONDERI_BASARISIZ." : "FTM_GONDERI_BASARILI");
    
        FtmUtility.sendMail(subject+ "!!_KREDI_MUSTERI_LISTESI",mailHeader );

        }catch (Exception e) {
            throw ExceptionHandler.convertException(e); 
        }
	  return iMap;
	   
	}
	
	@GraymoundService("BNSPR_PTT_KREDI_TAHSIL_DOSYA_FTP")
	public static GMMap pttKrediTahsilDosyaFtp(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String proc = "{ call PKG_PTT_DOSYA.PTT_KREDI_TAHSIL_DOSYA_FTP(?) }";
			Object[] inputValues = new Object[2];
			inputValues[0] = BnsprType.STRING;
			inputValues[1] = iMap.getString("TATIL_GUNU_CALISSIN");
			Object[] outputValues = new Object[0];
			DALUtil.callOracleProcedure(proc, inputValues, outputValues);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_PTT_KREDI_BILDIRIM")
	public static GMMap pttKrediBildirim(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{ ? = call PKG_PTT_DOSYA.PTT_KREDI_BILDIRIM_LISTESI(?,?,?,?,?) }";
			Object[] inputValues = new Object[10];
			inputValues[0] = BnsprType.DATE;
			inputValues[1] = iMap.getDate("BASLANGIC_TARIHI");
			inputValues[2] = BnsprType.DATE;
			inputValues[3] = iMap.getDate("BITIS_TARIHI");
			inputValues[4] = BnsprType.STRING;
			inputValues[5] = iMap.getString("DURUM");
			inputValues[6] = BnsprType.STRING;
			inputValues[7] = iMap.getString("TCKN");
			inputValues[8] = BnsprType.NUMBER;
			inputValues[9] = iMap.getBigDecimal("BAVURU_NO");
			oMap = DALUtil.callOracleRefCursorFunction(func, "KREDI_BILDIRIM", inputValues);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_BAYI_PTT_KREDI_KOMISYON")
	public static GMMap bayiPttKrediKomisyon(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String func = "{ ? = call PKG_PTT_DOSYA.BAYI_PTT_EMEKLI_KREDI_LISTESI(?,?) }";
			Object[] inputValues = new Object[4];
			inputValues[0] = BnsprType.DATE;
			inputValues[1] = iMap.getDate("BASLANGIC_TARIHI");
			inputValues[2] = BnsprType.DATE;
			inputValues[3] = iMap.getDate("BITIS_TARIHI");
			oMap = DALUtil.callOracleRefCursorFunction(func, "KREDI_KOMISYON", inputValues);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
