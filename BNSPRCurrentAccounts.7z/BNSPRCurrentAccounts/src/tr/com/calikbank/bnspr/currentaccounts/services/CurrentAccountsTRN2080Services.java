package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhBinsWbTutarDevirTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsTRN2080Services {

	@GraymoundService("BNSPR_TRN2080_SAVE")
	public static Map<?, ?> trn2080Save(GMMap iMap) {

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			MuhBinsWbTutarDevirTx muhBinsWbTutarDevirTx = (MuhBinsWbTutarDevirTx)session.get(MuhBinsWbTutarDevirTx.class, iMap.getBigDecimal("TRX_NO"));
			if (muhBinsWbTutarDevirTx == null)
				muhBinsWbTutarDevirTx = new MuhBinsWbTutarDevirTx();
			
			muhBinsWbTutarDevirTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			muhBinsWbTutarDevirTx.setIslemTuru(iMap.getString("ISLEM_TURU"));
			muhBinsWbTutarDevirTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			muhBinsWbTutarDevirTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			muhBinsWbTutarDevirTx.setWbSube(iMap.getBigDecimal("WB_SUBE_KOD"));
			muhBinsWbTutarDevirTx.setWbMusteriNo(iMap.getBigDecimal("WB_MUSTERI_NO"));
			muhBinsWbTutarDevirTx.setWbMusteriEkno(iMap.getBigDecimal("WB_MUSTERI_EK_NO"));
			muhBinsWbTutarDevirTx.setTutar(iMap.getBigDecimal("TUTAR"));
			muhBinsWbTutarDevirTx.setDrm("A");
			muhBinsWbTutarDevirTx.setWbDefterid(iMap.getString("WB_DEFTER_ID"));
			muhBinsWbTutarDevirTx.setWbDovizCinsi(iMap.getBigDecimal("WB_DOVIZ_CINSI"));
			muhBinsWbTutarDevirTx.setWbMusteriKisaadi(iMap.getString("WB_MUSTERI_KISA_AD"));
			muhBinsWbTutarDevirTx.setAciklama(iMap.getString("ACIKLAMA"));
			muhBinsWbTutarDevirTx.setDkHesapNo(iMap.getString("DK_HESAP_NO"));
			muhBinsWbTutarDevirTx.setIslemTipi(iMap.getString("ISLEM_TIPI"));
			muhBinsWbTutarDevirTx.setVirmanEh(GuimlUtil.convertFromCheckBoxValue(iMap.getBoolean("VIRMAN_EH")));
			muhBinsWbTutarDevirTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			
			session.saveOrUpdate(muhBinsWbTutarDevirTx);
			session.flush();
			
			iMap.put("TRX_NAME", "2080");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2080_GET")
	public static GMMap trn2080Get(GMMap iMap) {

		try {
			Session session = DAOSession.getSession("BNSPRDal");			
			GMMap oMap = new GMMap();
			
			MuhBinsWbTutarDevirTx muhBinsWbTutarDevirTx = (MuhBinsWbTutarDevirTx)session.get(MuhBinsWbTutarDevirTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("ISLEM_TURU",muhBinsWbTutarDevirTx.getIslemTuru());
			BigDecimal musteriNo = muhBinsWbTutarDevirTx.getMusteriNo();
			BigDecimal hesapNo = muhBinsWbTutarDevirTx.getHesapNo();
			String dovizKodu = muhBinsWbTutarDevirTx.getDovizKodu();
			oMap.put("MUSTERI_NO",musteriNo);
			oMap.put("DI_MUSTERI_NO",LovHelper.diLov(musteriNo, "2080/LOV_MUSTERI", "UNVAN"));			
			oMap.put("HESAP_NO",muhBinsWbTutarDevirTx.getHesapNo());
			oMap.put("DI_HESAP_NO",LovHelper.diLov(hesapNo, musteriNo,dovizKodu,"2080/LOV_HESAP", "KISA_ISIM"));	
			oMap.put("WB_SUBE_KOD",muhBinsWbTutarDevirTx.getWbSube());
			oMap.put("WB_MUSTERI_NO",muhBinsWbTutarDevirTx.getWbMusteriNo());
			oMap.put("WB_MUSTERI_EK_NO",muhBinsWbTutarDevirTx.getWbMusteriEkno());
			oMap.put("TUTAR",muhBinsWbTutarDevirTx.getTutar());
			oMap.put("DURUM", muhBinsWbTutarDevirTx.getDrm());
			oMap.put("WB_DEFTER_ID", muhBinsWbTutarDevirTx.getWbDefterid());
			oMap.put("WB_DOVIZ_CINSI", muhBinsWbTutarDevirTx.getWbDovizCinsi());
			oMap.put("WB_MUSTERI_KISA_AD", muhBinsWbTutarDevirTx.getWbMusteriKisaadi());
			oMap.put("ACIKLAMA", muhBinsWbTutarDevirTx.getAciklama());
			oMap.put("DK_HESAP_NO",muhBinsWbTutarDevirTx.getDkHesapNo());
			oMap.put("DI_DK_HESAP_NO",LovHelper.diLov(muhBinsWbTutarDevirTx.getDkHesapNo(),dovizKodu,"2080/LOV_DK_HESAP","ACIKLAMA"));
			oMap.put("ISLEM_TIPI",muhBinsWbTutarDevirTx.getIslemTipi());
			oMap.put("VIRMAN_EH",GuimlUtil.convertToCheckBoxSelected(muhBinsWbTutarDevirTx.getVirmanEh()));
			oMap.put("DOVIZ_KODU",muhBinsWbTutarDevirTx.getDovizKodu());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2080_GET_DEFTERID")
	public static GMMap getDefterID(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection connSql = null;
		CallableStatement stmtSql = null;
		ResultSet rSet = null;
		try {
			connSql = DALUtil.getWinbankConnection();
			StringBuffer sb = new StringBuffer();
			sb.append("select dovizcinsi,defterid from dbbanking..hesap where subekodu=? and musterino = ? and ekno = ? and kapanistarihi is null");
			stmtSql = connSql.prepareCall(sb.toString());
			stmtSql.setObject(1, iMap.getInt("WB_SUBE_KOD"), Types.SMALLINT); 
			stmtSql.setObject(2, iMap.getInt("WB_MUSTERI_NO"), Types.INTEGER);
			stmtSql.setObject(3, iMap.getInt("WB_MUSTERI_EK_NO"), Types.SMALLINT);
			rSet = stmtSql.executeQuery();
			if(rSet.next()){
				oMap.put("WB_DOVIZ_CINSI", rSet.getInt(1));
				oMap.put("WB_DEFTER_ID", rSet.getInt(2));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmtSql);
			GMServerDatasource.close(connSql);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_WB_TO_BINS_DOVIZ_CINSI")
	public static GMMap getUnvan(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("BINS_DOVIZ_CINSI", DALUtil.callOneParameterFunction("{? = call pkg_bins_to_wb.bins_doviz_kodu(?)}", Types.VARCHAR, iMap.getBigDecimal("WB_DOVIZ_KOD")));
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN2080_GET_MUSTERI_KISAADI")
	public static GMMap getMusteriKisaadi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection connSql = null;
		CallableStatement stmtSql = null;
		ResultSet rSet = null;
		try {
			connSql = DALUtil.getWinbankConnection();
			StringBuffer sb = new StringBuffer();
			sb.append("select kisaadi from dbbanking..musteri where musterino = ? ");
			stmtSql = connSql.prepareCall(sb.toString());
			stmtSql.setObject(1, iMap.getInt("WB_MUSTERI_NO"), Types.INTEGER);
			rSet = stmtSql.executeQuery();
			if(rSet.next()){
				oMap.put("WB_KISAADI", rSet.getString(1));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmtSql);
			GMServerDatasource.close(connSql);
		}
		return oMap;
	}

}
