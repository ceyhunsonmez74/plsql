package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsQRY2085Services {

	// public static String

	@GraymoundService("BNSPR_QRY2085_RC_QRY_GET_1ST_LEVEL")
	public static GMMap getFirstLevel(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		BigDecimal PTTYT1 = new BigDecimal(0);
		BigDecimal AKTIFBANKYT1 = new BigDecimal(0);
		BigDecimal pttbankYT2 = new BigDecimal(0);
		BigDecimal YATAN_AKT_EUR = new BigDecimal(0);
		BigDecimal pttbankYT3 = new BigDecimal(0);
		BigDecimal AKTIFBANKYT3 = new BigDecimal(0);

		BigDecimal MASRAFYATANPTTTRY = new BigDecimal(0);
		BigDecimal MASRAFYATANAKTIFBANKTRY = new BigDecimal(0);
		BigDecimal MASRAFYATANPTTEUR = new BigDecimal(0);
		BigDecimal MASRAFYATANAKTIFBANKEUR = new BigDecimal(0);
		BigDecimal MASRAFYATANPTTUSD = new BigDecimal(0);
		BigDecimal MASRAFYATANAKTIFBANKUSD = new BigDecimal(0);

		BigDecimal PPTYATANADETTRY = new BigDecimal(0);
		BigDecimal AKTIFBANKYATANADETTRY = new BigDecimal(0);
		BigDecimal PTTYATANADETEUR = new BigDecimal(0);
		BigDecimal AKTIFBANKYATANADETEUR = new BigDecimal(0);
		BigDecimal PTTYATANADETUSD = new BigDecimal(0);
		BigDecimal AKTIFBANKYATANADETUSD = new BigDecimal(0);

		BigDecimal pttbankCT1 = new BigDecimal(0);
		BigDecimal AKTIFBANKCT1 = new BigDecimal(0);
		BigDecimal pttbankCT2 = new BigDecimal(0);
		BigDecimal AKTIFBANKCT2 = new BigDecimal(0);
		BigDecimal pttbankCT3 = new BigDecimal(0);
		BigDecimal AKTIFBANKCT3 = new BigDecimal(0);

		BigDecimal MASRAFCEKILENPTTTRY = new BigDecimal(0);
		BigDecimal MASRAFCEKILENAKTIFBANKTRY = new BigDecimal(0);
		BigDecimal MASRAFCEKILENPTTEUR = new BigDecimal(0);
		BigDecimal MASRAFCEKILENAKTIFBANKEUR = new BigDecimal(0);
		BigDecimal MASRAFCEKILENPTTUSD = new BigDecimal(0);
		BigDecimal MASRAFCEKILENAKTIFBANKUSD = new BigDecimal(0);

		BigDecimal PPTCEKILENADETTRY = new BigDecimal(0);
		BigDecimal AKTIFBANKCEKILENADETTRY = new BigDecimal(0);
		BigDecimal PTTCEKILENADETEUR = new BigDecimal(0);
		BigDecimal AKTIFBANKCEKILENADETEUR = new BigDecimal(0);
		BigDecimal PTTCEKILENADETUSD = new BigDecimal(0);
		BigDecimal AKTIFBANKCEKILENADETUSD = new BigDecimal(0);

		BigDecimal IPTALPTTYATANTRY = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANTRY = new BigDecimal(0);
		BigDecimal IPTALPTTYATANUSD = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANUSD = new BigDecimal(0);
		BigDecimal IPTALPTTYATANEUR = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANEUR = new BigDecimal(0);

		BigDecimal IPTALPTTCEKILENTRY = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKCEKILENTRY = new BigDecimal(0);
		BigDecimal IPTALPTTCEKILENEUR = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKCEKILENEUR = new BigDecimal(0);
		BigDecimal IPTALPTTCEKILENUSD = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKCEKILENUSD = new BigDecimal(0);

		BigDecimal IPTALMASRAFPTTYATANTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKYATANTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFPTTYATANUSD = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKYATANUSD = new BigDecimal(0);
		BigDecimal IPTALMASRAFPTTYATANEUR = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKYATANEUR = new BigDecimal(0);

		BigDecimal IPTALMASRAFPTTCEKILENTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKCEKILENTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFPTTCEKILENEUR = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKCEKILENEUR = new BigDecimal(0);
		BigDecimal IPTALMASRAFPTTCEKILENUSD = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKCEKILENUSD = new BigDecimal(0);

		BigDecimal IPTALPTTYATANADETTRY = new BigDecimal(0);
		BigDecimal IPTALBANKAYATANADETTRY = new BigDecimal(0);
		BigDecimal IPTALPTTYATANADETEUR = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANADETEUR = new BigDecimal(0);
		BigDecimal IPTALPTTYATANADETUSD = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANADETUSD = new BigDecimal(0);

		BigDecimal IPTALPTTCEKILENADETTRY = new BigDecimal(0);
		BigDecimal IPTALBANKACEKILENADETTRY = new BigDecimal(0);
		BigDecimal IPTALPTTCEKILENADETEUR = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKCEKILENADETEUR = new BigDecimal(0);
		BigDecimal IPTALPTTCEKILENADETUSD = new BigDecimal(0);
		BigDecimal IPTALBANKACEKILENADETUSD = new BigDecimal(0);

		GMMap oMapOnlyMutabakatsiz = new GMMap();

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC_PTT.RC_QRY_GET_1ST_LEVEL(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.get("TARIH") != null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);

			oMap.put("CBS_AKTIFBANK_PTT", GMServiceExecuter.execute("BNSPR_QRY2085_RC_QRY_GET_2ST_LEVEL_AKTIF", iMap).get("CBS_AKTIFBANK"));

			String tableName = "CBS_AKTIFBANK_PTT";
			i = oMap.getSize(tableName);
			int j = 0;

			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2085_RC_ONLY_MUTABAKATSIZLAR", iMap));

			String tableName2 = "CBS_AKTIFBANK_PTT";
			tableName = "CBS_AKTIFBANK_PTT";
			for (j = 0; j < iMap.getSize(tableName); j++) {
				oMap.put(tableName2, i, "ISLEM_TURU_PTT", iMap.getString(tableName, j, "ISLEM_TURU_PTT"));
				oMap.put(tableName2, i, "PTT_ISLEM_TUTARI", iMap.getString(tableName, j, "PTT_ISLEM_TUTARI"));
				oMap.put(tableName2, i, "PTT_MASRAF_TUTARI", iMap.getString(tableName, j, "PTT_MASRAF_TUTARI"));
				oMap.put(tableName2, i, "ISLEM_NO_PTT", iMap.getString(tableName, j, "ISLEM_NO_PTT"));
				oMap.put(tableName2, i, "NUMARA", iMap.getString(tableName, j, "NUMARA")); // ISLEMNOBANKA
				oMap.put(tableName2, i, "PTT_DOVIZ_KOD", iMap.getString(tableName, j, "PTT_DOVIZ_KOD"));
				oMap.put(tableName2, i, "EFT_HESAP_KASA", iMap.getString(tableName, j, "EFT_HESAP_KASA"));
				oMap.put(tableName2, i, "ISLEM", iMap.getString(tableName, j, "ISLEM"));
				oMap.put(tableName2, i, "PTT_TOPLAM_TUTAR", iMap.getString(tableName, j, "PTT_TOPLAM_TUTAR"));
				oMap.put(tableName2, i, "ISLEM_ADI_PTT", iMap.getString(tableName, j, "ISLEM_ADI_PTT"));
				oMap.put(tableName2, i, "MASRAF_DOVIZ_KODU", iMap.getString(tableName, j, "MASRAF_DOVIZ_KODU"));
				oMap.put(tableName2, i, "AKTIFBANK_DOVIZ_KODU", iMap.getString(tableName, j, "AKTIFBANK_DOVIZ_KODU"));
				oMap.put(tableName2, i, "AKTIFBANK_DOVIZ_TUTARI", iMap.getString(tableName, j, "AKTIFBANK_DOVIZ_TUTARI"));
				oMap.put(tableName2, i, "PTT_DOVIZ_TUTARI", iMap.getString(tableName, j, "PTT_DOVIZ_TUTARI"));
				oMap.put(tableName2, i, "AKTIFBANK_TL_TUTARI", iMap.getString(tableName, j, "AKTIFBANK_TL_TUTARI"));
				oMap.put(tableName2, i, "PTT_TL_TUTARI", iMap.getString(tableName, j, "PTT_TL_TUTARI"));
				oMap.put(tableName2, i, "PTT_MASRAF_DOVIZ_KOD", iMap.getString(tableName, j, "PTT_MASRAF_DOVIZ_KOD"));

				/*iMap.getBigDecimal(tableName, j,"PTT_ISLEM_TUTARI").intValue()+ iMap.getBigDecimal(tableName, j,"PTT_MASRAF_TUTARI").intValue());*/
				i++;
			}

			tableName2 = "CBS_AKTIFBANK_PTT";
			for (j = 0; j < oMap.getSize(tableName2); j++) { // Aktifbank i�lem T�P� null sa demekki banka islemi

				// YATAN ptt
				if (oMap.getString(tableName2, j, "ISLEM_ADI_PTT") != null && oMap.getString(tableName2, j, "ISLEM") != null) {

					if (oMap.getString(tableName2, j, "ISLEM_ADI_PTT").compareTo("IPTAL") != 0 && oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONHURDAAL") == 0) {
						MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
					}

					if (oMap.getString(tableName2, j, "ISLEM_ADI_PTT").compareTo("IPTAL") != 0 && (oMap.getString(tableName2, j, "ISLEM").compareTo("BONOAL") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("PTT MUSTERI") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONAL") == 0))

						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD").compareTo("TRY") == 0) {
								PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));

								if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0) {
									MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}
								PPTYATANADETTRY = PPTYATANADETTRY.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD").compareTo("EUR") == 0) {
								pttbankYT2 = pttbankYT2.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));

								if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("EUR") == 0) {
									MASRAFYATANPTTEUR = MASRAFYATANPTTEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}
								if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0) {
									MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}
								PTTYATANADETEUR = PTTYATANADETEUR.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD").compareTo("USD") == 0) {

								pttbankYT3 = pttbankYT3.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));

								if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("USD") == 0) {
									MASRAFYATANPTTUSD = MASRAFYATANPTTUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}
								if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0) {
									MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}
								PTTYATANADETUSD = PTTYATANADETUSD.add(new BigDecimal(1));

							}
						}

				}

				// CEKILEN PTT
				if (oMap.getString(tableName2, j, "ISLEM_ADI_PTT") != null && oMap.getString(tableName2, j, "ISLEM") != null) {

					if (oMap.getString(tableName2, j, "ISLEM_ADI_PTT").compareTo("IPTAL") != 0 && (oMap.getString(tableName2, j, "ISLEM").compareTo("BONOSAT") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONSAT") == 0))

						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD").compareTo("TRY") == 0) {
								pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));

								if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0) {
									MASRAFCEKILENPTTTRY = MASRAFCEKILENPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}
								PPTCEKILENADETTRY = PPTCEKILENADETTRY.add(new BigDecimal(1));
							}

						}

				}

				// IPTAL YATAN ptt
				if (oMap.getString(tableName2, j, "ISLEM_ADI_PTT") != null && oMap.getString(tableName2, j, "ISLEM") != null) {

					if (oMap.getString(tableName2, j, "ISLEM_ADI_PTT").compareTo("IPTAL") == 0 && oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONHURDAAL") == 0) {
						IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
					}

					if (oMap.getString(tableName2, j, "ISLEM_ADI_PTT").compareTo("IPTAL") == 0 && (oMap.getString(tableName2, j, "ISLEM").compareTo("BONOAL") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONAL") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("PTT MUSTERI") == 0))

					{

						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD").compareTo("TRY") == 0) {
								IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
								IPTALPTTYATANADETTRY = IPTALPTTYATANADETTRY.add(new BigDecimal(1));

								if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0) {
									IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}

							}
						}
					}
				}

				// IPTAL CEKILEN ptt

				if (oMap.getString(tableName2, j, "ISLEM_ADI_PTT") != null && oMap.getString(tableName2, j, "ISLEM") != null) {
					if (oMap.getString(tableName2, j, "ISLEM_ADI_PTT").compareTo("IPTAL") == 0 && (oMap.getString(tableName2, j, "ISLEM").compareTo("BONOSAT") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONSAT") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("PTT MUSTERI") == 0))

					{

						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD").compareTo("TRY") == 0) {
								IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
								IPTALPTTCEKILENADETTRY = IPTALPTTCEKILENADETTRY.add(new BigDecimal(1));

								if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0) {
									IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}

							}
						}
					}
				}

				// AKTIFBANKISLEMLERI
				if (oMap.getString(tableName2, j, "ISLEM_KOD") != null && oMap.getString(tableName2, j, "ISLEM") != null && oMap.getString(tableName2, j, "ISLEM_ADI_PTT") != null) {

					// AKTIFBANKYATAN

					if (!oMap.getString(tableName2, j, "ISLEM_ADI_PTT").equals("IPTAL") && oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2112)) == 0) {

						MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
					}

					if (!oMap.getString(tableName2, j, "ISLEM_ADI_PTT").equals("IPTAL")) {

						if (oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(1401)) == 0 || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2111)) == 0 || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(10011)) == 0 /*&& 
																																																																								(oMap.getString(tableName2, j, "ISLEM").compareTo("PTT MUSTERI") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("BONOAL") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONAL") == 0)*/) {

							if (oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

								if (oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU").compareTo("TRY") == 0) {
									AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
									AKTIFBANKYATANADETTRY = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
								}
								if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
									MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
								}
							}
						}

					}

				}

				if (oMap.getString(tableName2, j, "ISLEM_KOD") != null && oMap.getString(tableName2, j, "ISLEM") != null && oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null) {

					if (!oMap.getString(tableName2, j, "ISLEM_TURU_PTT").equals("IPTAL")) {

						if (oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(1406)) == 0 || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2113)) == 0
						/*	&& (oMap.getString(tableName2, j, "ISLEM").compareTo("BONOSAT") == 0 ||
							oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONSAT") == 0)*/) {

							if (oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

								if (oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU").compareTo("TRY") == 0) {
									AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
									AKTIFBANKCEKILENADETTRY = AKTIFBANKCEKILENADETTRY.add(new BigDecimal(1));

									if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
										MASRAFCEKILENAKTIFBANKTRY = MASRAFCEKILENAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
									}
								}

							}
						}
					}

					if (oMap.getString(tableName2, j, "ISLEM_KOD") != null && oMap.getString(tableName2, j, "ISLEM") != null && oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null) {

						if (oMap.getString(tableName2, j, "ISLEM_ADI_PTT").equals("IPTAL") && oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2112)) == 0) {

							IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
						}

						if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT").equals("IPTAL")) {

							if (oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(1401)) == 0 || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2111)) == 0 || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(10011)) == 0) {
								if (oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").equals("KASA")) {

									if (oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU").compareTo("TRY") == 0) {
										IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
										IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));

									}
									if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
										IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
									}
								}
							}
						}
					}

					if (oMap.getString(tableName2, j, "ISLEM_KOD") != null && oMap.getString(tableName2, j, "ISLEM") != null && oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null) {

						if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT").equals("IPTAL")) {

							if (oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(1406)) == 0 || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2113)) == 0)

								if (oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").equals("KASA")) {

									if (oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU").compareTo("TRY") == 0) {
										IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
										IPTALBANKACEKILENADETTRY = IPTALBANKACEKILENADETTRY.add(new BigDecimal(1));

									}
									if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 && oMap.getString(tableName2, j, "EFT_HESAP_KASA").equals("KASA")) {
										IPTALMASRAFAKTIFBANKCEKILENTRY = IPTALMASRAFAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
									}
								}
						}
					}
				}

			}

			oMap.put("PTTYT1", PTTYT1);
			oMap.put("AKTIFBANKYT1", AKTIFBANKYT1);
			oMap.put("pttbankYT2", pttbankYT2);
			oMap.put("YATAN_AKT_EUR", YATAN_AKT_EUR);
			oMap.put("pttbankYT3", pttbankYT3);
			oMap.put("AKTIFBANKYT3", AKTIFBANKYT3);

			MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(MASRAFYATANPTTEUR).add(MASRAFYATANPTTUSD);
			MASRAFYATANPTTEUR = new BigDecimal("0");
			MASRAFYATANPTTUSD = new BigDecimal("0");

			MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(MASRAFYATANAKTIFBANKEUR).add(MASRAFYATANAKTIFBANKUSD);
			MASRAFYATANAKTIFBANKEUR = new BigDecimal("0");
			MASRAFYATANAKTIFBANKUSD = new BigDecimal("0");

			oMap.put("MASRAFYATANPTTTRY", MASRAFYATANPTTTRY);
			oMap.put("MASRAFYATANAKTIFBANKTRY", MASRAFYATANAKTIFBANKTRY);
			oMap.put("MASRAFYATANPTTEUR", MASRAFYATANPTTEUR);
			oMap.put("MASRAFYATANAKTIFBANKEUR", MASRAFYATANAKTIFBANKEUR);
			oMap.put("MASRAFYATANPTTUSD", MASRAFYATANPTTUSD);
			oMap.put("MASRAFYATANAKTIFBANKUSD", MASRAFYATANAKTIFBANKUSD);

			oMap.put("PPTYATANADETTRY", PPTYATANADETTRY);
			oMap.put("AKTIFBANKYATANADETTRY", AKTIFBANKYATANADETTRY);
			oMap.put("PTTYATANADETEUR", PTTYATANADETEUR);
			oMap.put("AKTIFBANKYATANADETEUR", AKTIFBANKYATANADETEUR);
			oMap.put("PTTYATANADETUSD", PTTYATANADETUSD);
			oMap.put("AKTIFBANKYATANADETUSD", AKTIFBANKYATANADETUSD);

			oMap.put("pttbankCT1", pttbankCT1);
			oMap.put("AKTIFBANKCT1", AKTIFBANKCT1);
			oMap.put("pttbankCT2", pttbankCT2);
			oMap.put("AKTIFBANKCT2", AKTIFBANKCT2);
			oMap.put("pttbankCT3", pttbankCT3);
			oMap.put("AKTIFBANKCT3", AKTIFBANKCT3);

			MASRAFCEKILENPTTTRY = MASRAFCEKILENPTTTRY.add(MASRAFCEKILENPTTEUR).add(MASRAFCEKILENPTTUSD);
			MASRAFCEKILENPTTEUR = new BigDecimal("0");
			MASRAFCEKILENPTTUSD = new BigDecimal("0");
			MASRAFCEKILENAKTIFBANKTRY = MASRAFCEKILENAKTIFBANKTRY.add(MASRAFCEKILENAKTIFBANKEUR).add(MASRAFCEKILENAKTIFBANKUSD);
			MASRAFCEKILENAKTIFBANKEUR = new BigDecimal("0");
			MASRAFCEKILENAKTIFBANKUSD = new BigDecimal("0");

			oMap.put("MASRAFCEKILENPTTTRY", MASRAFCEKILENPTTTRY);
			oMap.put("MASRAFCEKILENAKTIFBANKTRY", MASRAFCEKILENAKTIFBANKTRY);
			oMap.put("MASRAFCEKILENPTTEUR", MASRAFCEKILENPTTEUR);
			oMap.put("MASRAFCEKILENAKTIFBANKEUR", MASRAFCEKILENAKTIFBANKEUR);
			oMap.put("MASRAFCEKILENPTTUSD", MASRAFCEKILENPTTUSD);
			oMap.put("MASRAFCEKILENAKTIFBANKUSD", MASRAFCEKILENAKTIFBANKUSD);

			oMap.put("PPTCEKILENADETTRY", PPTCEKILENADETTRY);
			oMap.put("AKTIFBANKCEKILENADETTRY", AKTIFBANKCEKILENADETTRY);
			oMap.put("PTTCEKILENADETEUR", PTTCEKILENADETEUR);
			oMap.put("AKTIFBANKCEKILENADETEUR", AKTIFBANKCEKILENADETEUR);
			oMap.put("PTTCEKILENADETUSD", PTTCEKILENADETUSD);
			oMap.put("AKTIFBANKCEKILENADETUSD", AKTIFBANKCEKILENADETUSD);

			oMap.put("IPTALPTTYATANTRY", IPTALPTTYATANTRY);
			oMap.put("IPTALAKTIFBANKYATANTRY", IPTALAKTIFBANKYATANTRY);
			oMap.put("IPTALPTTYATANUSD", IPTALPTTYATANUSD);
			oMap.put("IPTALAKTIFBANKYATANUSD", IPTALAKTIFBANKYATANUSD);
			oMap.put("IPTALPTTYATANEUR", IPTALPTTYATANEUR);
			oMap.put("IPTALAKTIFBANKYATANEUR", IPTALAKTIFBANKYATANEUR);

			oMap.put("IPTALPTTCEKILENTRY", IPTALPTTCEKILENTRY);
			oMap.put("IPTALAKTIFBANKCEKILENTRY", IPTALAKTIFBANKCEKILENTRY);
			oMap.put("IPTALPTTCEKILENEUR", IPTALPTTCEKILENEUR);
			oMap.put("IPTALAKTIFBANKCEKILENEUR", IPTALAKTIFBANKCEKILENEUR);
			oMap.put("IPTALPTTCEKILENUSD", IPTALPTTCEKILENUSD);
			oMap.put("IPTALAKTIFBANKCEKILENUSD", IPTALAKTIFBANKCEKILENUSD);

			BigDecimal PTT_BORC_TL = new BigDecimal(0);

			BigDecimal PTT_BORC_EUR = new BigDecimal(0);

			BigDecimal PTT_BORC_USD = new BigDecimal(0);

			BigDecimal AKTIFBANK_BORC_TL = new BigDecimal(0);

			BigDecimal AKTIFBANK_BORC_EUR = new BigDecimal(0);

			BigDecimal AKTIFBANK_BORC_USD = new BigDecimal(0);

			oMap.put("pttbankYT2", pttbankYT2);

			BigDecimal TOPLAMYATANPTTTRY = PTTYT1.add(MASRAFYATANPTTTRY);
			BigDecimal TOPLAMYATANAKTIFBANKTRY = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY);
			BigDecimal TOPLAMYATANPTTEUR = pttbankYT2.add(MASRAFYATANPTTEUR);
			BigDecimal TOPLAMYATANAKTIFBANKEUR = YATAN_AKT_EUR.add(MASRAFYATANAKTIFBANKEUR);
			BigDecimal TOPLAMYATANPTTUSD = pttbankYT3.add(MASRAFYATANPTTUSD);
			BigDecimal TOPLAMYATANAKTIFBANKUSD = AKTIFBANKYT3.add(MASRAFYATANAKTIFBANKUSD);

			oMap.put("TOPLAMYATANPTTTRY", TOPLAMYATANPTTTRY);
			oMap.put("TOPLAMYATANAKTIFBANKTRY", TOPLAMYATANAKTIFBANKTRY);
			oMap.put("TOPLAMYATANPTTEUR", TOPLAMYATANPTTEUR);
			oMap.put("TOPLAMYATANAKTIFBANKEUR", TOPLAMYATANAKTIFBANKEUR);
			oMap.put("TOPLAMYATANPTTUSD", TOPLAMYATANPTTUSD);
			oMap.put("TOPLAMYATANAKTIFBANKUSD", TOPLAMYATANAKTIFBANKUSD);

			BigDecimal TOPLAMCEKILENPTTTRY = pttbankCT1.subtract(MASRAFCEKILENPTTTRY);
			BigDecimal TOPLAMCEKILENAKTIFBANKTRY = AKTIFBANKCT1.subtract(MASRAFCEKILENAKTIFBANKTRY);
			BigDecimal TOPLAMCEKILENPTTEUR = pttbankCT2.subtract(MASRAFCEKILENPTTEUR);
			BigDecimal TOPLAMCEKILENAKTIFBANKEUR = AKTIFBANKCT2.subtract(MASRAFCEKILENAKTIFBANKEUR);
			BigDecimal TOPLAMCEKILENPTTUSD = pttbankCT3.subtract(MASRAFCEKILENPTTUSD);
			BigDecimal TOPLAMCEKILENAKTIFBANKUSD = AKTIFBANKCT3.subtract(MASRAFCEKILENAKTIFBANKUSD);

			oMap.put("TOPLAMCEKILENPTTTRY", TOPLAMCEKILENPTTTRY);
			oMap.put("TOPLAMCEKILENAKTIFBANKTRY", TOPLAMCEKILENAKTIFBANKTRY);
			oMap.put("TOPLAMCEKILENPTTEUR", TOPLAMCEKILENPTTEUR);
			oMap.put("TOPLAMCEKILENAKTIFBANKEUR", TOPLAMCEKILENAKTIFBANKEUR);
			oMap.put("TOPLAMCEKILENPTTUSD", TOPLAMCEKILENPTTUSD);
			oMap.put("TOPLAMCEKILENAKTIFBANKUSD", TOPLAMCEKILENAKTIFBANKUSD);

			IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(IPTALMASRAFPTTYATANUSD).add(IPTALMASRAFPTTYATANEUR);
			IPTALMASRAFPTTYATANUSD = new BigDecimal(0);
			IPTALMASRAFPTTYATANEUR = new BigDecimal(0);
			IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(IPTALMASRAFAKTIFBANKYATANUSD).add(IPTALMASRAFAKTIFBANKYATANEUR);
			IPTALMASRAFAKTIFBANKYATANUSD = new BigDecimal(0);
			IPTALMASRAFAKTIFBANKYATANEUR = new BigDecimal(0);

			oMap.put("IPTALMASRAFPTTYATANTRY", IPTALMASRAFPTTYATANTRY);
			oMap.put("IPTALMASRAFAKTIFBANKYATANTRY", IPTALMASRAFAKTIFBANKYATANTRY);
			oMap.put("IPTALMASRAFPTTYATANUSD", IPTALMASRAFPTTYATANUSD);
			oMap.put("IPTALMASRAFAKTIFBANKYATANUSD", IPTALMASRAFAKTIFBANKYATANUSD);
			oMap.put("IPTALMASRAFPTTYATANEUR", IPTALMASRAFPTTYATANEUR);
			oMap.put("IPTALMASRAFAKTIFBANKYATANEUR", IPTALMASRAFAKTIFBANKYATANEUR);

			IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(IPTALMASRAFPTTCEKILENEUR).add(IPTALMASRAFPTTCEKILENUSD);
			IPTALMASRAFPTTCEKILENEUR = new BigDecimal(0);
			IPTALMASRAFPTTCEKILENUSD = new BigDecimal(0);
			IPTALMASRAFAKTIFBANKCEKILENTRY = IPTALMASRAFAKTIFBANKCEKILENTRY.add(IPTALMASRAFAKTIFBANKCEKILENEUR).add(IPTALMASRAFAKTIFBANKCEKILENUSD);
			IPTALMASRAFAKTIFBANKCEKILENEUR = new BigDecimal(0);
			IPTALMASRAFAKTIFBANKCEKILENUSD = new BigDecimal(0);

			oMap.put("IPTALMASRAFPTTCEKILENTRY", IPTALMASRAFPTTCEKILENTRY);
			oMap.put("IPTALMASRAFAKTIFBANKCEKILENTRY", IPTALMASRAFAKTIFBANKCEKILENTRY);
			oMap.put("IPTALMASRAFPTTCEKILENEUR", IPTALMASRAFPTTCEKILENEUR);
			oMap.put("IPTALMASRAFAKTIFBANKCEKILENEUR", IPTALMASRAFAKTIFBANKCEKILENEUR);
			oMap.put("IPTALMASRAFPTTCEKILENUSD", IPTALMASRAFPTTCEKILENUSD);
			oMap.put("IPTALMASRAFAKTIFBANKCEKILENUSD", IPTALMASRAFAKTIFBANKCEKILENUSD);

			oMap.put("IPTALPTTYATANADETTRY", IPTALPTTYATANADETTRY);
			oMap.put("IPTALBANKAYATANADETTRY", IPTALBANKAYATANADETTRY);
			oMap.put("IPTALPTTYATANADETEUR", IPTALPTTYATANADETEUR);
			oMap.put("IPTALAKTIFBANKYATANADETEUR", IPTALAKTIFBANKYATANADETEUR);
			oMap.put("IPTALPTTYATANADETUSD", IPTALPTTYATANADETUSD);
			oMap.put("IPTALAKTIFBANKYATANADETUSD", IPTALAKTIFBANKYATANADETUSD);

			oMap.put("IPTALPTTCEKILENADETTRY", IPTALPTTCEKILENADETTRY);
			oMap.put("IPTALBANKACEKILENADETTRY", IPTALBANKACEKILENADETTRY);
			oMap.put("IPTALPTTCEKILENADETEUR", IPTALPTTCEKILENADETEUR);
			oMap.put("IPTALAKTIFBANKCEKILENADETEUR", IPTALAKTIFBANKCEKILENADETEUR);
			oMap.put("IPTALPTTCEKILENADETUSD", IPTALPTTCEKILENADETUSD);
			oMap.put("IPTALBANKACEKILENADETUSD", IPTALBANKACEKILENADETUSD);

			PTT_BORC_TL = PTTYT1.add(MASRAFYATANPTTTRY).subtract(IPTALPTTYATANTRY).subtract(IPTALMASRAFPTTYATANTRY).add(MASRAFCEKILENPTTTRY).subtract(pttbankCT1).add(IPTALPTTCEKILENTRY).subtract(IPTALMASRAFPTTCEKILENTRY).add(MASRAFYATANPTTEUR).add(MASRAFCEKILENPTTEUR).subtract(IPTALMASRAFPTTYATANEUR).subtract(IPTALMASRAFPTTCEKILENEUR).add(MASRAFYATANPTTUSD).subtract(IPTALMASRAFPTTYATANUSD).add(MASRAFCEKILENPTTUSD).subtract(IPTALMASRAFPTTCEKILENUSD);

			PTT_BORC_EUR = pttbankYT2.subtract(IPTALPTTYATANEUR).subtract(pttbankCT2).add(IPTALPTTCEKILENEUR);

			PTT_BORC_USD = pttbankYT3.subtract(IPTALPTTYATANUSD).subtract(pttbankCT3).add(IPTALPTTCEKILENUSD);

			/*Nakit yatan nakit cekilen ptt -aktifbank tan iptal tutarlari dusuldu  */
			// oMap.put("PTTYT1", PTTYT1.intValue()-(IPTALPTTYATANTRY.intValue())) ;
			// oMap.put("pttbankYT2", pttbankYT2.intValue()-(IPTALPTTYATANEUR.intValue())) ;
			// oMap.put("pttbankYT3", pttbankYT3.intValue()-(IPTALPTTYATANUSD.intValue())) ;
			// oMap.put("AKTIFBANKYT1", AKTIFBANKYT1.intValue() - IPTALAKTIFBANKCEKILENTRY.intValue() ) ;
			// oMap.put("YATAN_AKT_EUR", YATAN_AKT_EUR.intValue() - IPTALAKTIFBANKCEKILENEUR.intValue() ) ;
			// oMap.put("IPTALAKTIFBANKCEKILENUSD", IPTALAKTIFBANKCEKILENUSD.intValue() - IPTALAKTIFBANKCEKILENUSD.intValue() ) ;
			/******************/

			oMap.put("BORC_TL_PTT", PTT_BORC_TL);
			oMap.put("BORC_USD_PTT", PTT_BORC_USD);
			oMap.put("BORC_EUR_PTT", PTT_BORC_EUR);

			oMap.put("BORC_TL_BANKA", "0");
			oMap.put("BORC_EUR_BANKA", "0");
			oMap.put("BORC_USD_BANKA", "0");

			if (PTT_BORC_TL.intValue() < 0) {
				AKTIFBANK_BORC_TL = PTT_BORC_TL;
				oMap.put("BORC_TL_BANKA", AKTIFBANK_BORC_TL);
				oMap.put("BORC_TL_PTT", "0");
			}

			if (PTT_BORC_EUR.intValue() < 0) {
				AKTIFBANK_BORC_EUR = PTT_BORC_EUR;
				oMap.put("BORC_EUR_BANKA", AKTIFBANK_BORC_EUR);
				oMap.put("BORC_EUR_PTT", "0");
			}
			if (PTT_BORC_USD.intValue() < 0) {
				AKTIFBANK_BORC_USD = PTT_BORC_USD;
				oMap.put("BORC_USD_BANKA", AKTIFBANK_BORC_USD);
				oMap.put("BORC_USD_PTT", "0");
			}

			AKTIFBANK_BORC_TL = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY).subtract(IPTALAKTIFBANKYATANTRY).subtract(IPTALMASRAFAKTIFBANKYATANTRY).add(MASRAFCEKILENAKTIFBANKTRY).subtract(AKTIFBANKCT1).add(IPTALAKTIFBANKCEKILENTRY).subtract(IPTALMASRAFAKTIFBANKCEKILENTRY).add(MASRAFCEKILENAKTIFBANKEUR).subtract(IPTALMASRAFAKTIFBANKCEKILENEUR).add(MASRAFYATANAKTIFBANKEUR).subtract(IPTALMASRAFAKTIFBANKYATANEUR).add(MASRAFYATANAKTIFBANKUSD).subtract(IPTALMASRAFAKTIFBANKYATANUSD).add(MASRAFCEKILENAKTIFBANKUSD).subtract(IPTALMASRAFAKTIFBANKCEKILENUSD);

			AKTIFBANK_BORC_EUR = YATAN_AKT_EUR.subtract(IPTALAKTIFBANKYATANEUR).subtract(AKTIFBANKCT2).add(IPTALAKTIFBANKCEKILENEUR);

			AKTIFBANK_BORC_USD = AKTIFBANKYT3.subtract(IPTALAKTIFBANKYATANUSD).subtract(AKTIFBANKCT3).add(IPTALAKTIFBANKCEKILENUSD);

			GMMap sMap = new GMMap();

			sMap.put("TARIH", iMap.get("TARIH"));

			sMap.put("AKTIFBANK_BORC_TL", AKTIFBANK_BORC_TL);
			sMap.put("AKTIFBANK_BORC_EUR", AKTIFBANK_BORC_EUR);
			sMap.put("AKTIFBANK_BORC_USD", AKTIFBANK_BORC_USD);

			sMap.put("PTT_BORC_TL", PTT_BORC_TL);
			sMap.put("PTT_BORC_USD", PTT_BORC_USD);
			sMap.put("PTT_BORC_EUR", PTT_BORC_EUR);

			GMServiceExecuter.execute("BNSPR_QRY2052_SET_NET_OFF", sMap);
			oMap.put("KAYIT_SAYISI", "1");

			// BU KONTROL BLOGU KALDIRILIRSA MUTABAKATLILARDA LISTELENECEK
			if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("true") == 0) {
				oMapOnlyMutabakatsiz.putAll(GMServiceExecuter.execute("BNSPR_QRY2085_RC_ONLY_MUTABAKATSIZLAR", iMap));

				oMap.put("KAYIT_SAYISI", oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT"));

				if (oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT") > 0) {
					oMap.putAll(oMapOnlyMutabakatsiz);
				}
				else {
					oMap.remove("CBS_AKTIFBANK_PTT");
				}

			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2085_RC_QRY_GET_2ST_LEVEL_AKTIF")
	public static GMMap getSecondLevelAktif(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2085.RC_QRY_GET_2nd_LEVEL_AKT(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.get("TARIH") != null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2085_RC_ONLY_MUTABAKATSIZLAR")
	public static GMMap getMutabakatOnlyMutabatsiz(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2085.Agreement_Response(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.get("TARIH") != null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");

			// }
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2085_RC_QRY_GET_ISLEMLER_BONO")
	public static GMMap Get_Islemler_Bono(GMMap iMap) {
		int row = 0;
		int size = iMap.getSize("ISLEM_LIST");
		int filterRow = 0;
		int columnIndex = 0;
		int columnSize = iMap.getSize("COLUMN_LIST");
		GMMap oMap = new GMMap();

		while (row < size) {

			if (iMap.get("ISLEM_LIST", row, "ISLEM") != null && iMap.get("ISLEM_LIST", row, "ISLEM").equals(iMap.getString("ISLEM_TIPI"))) {
				while (columnIndex < columnSize) {
					oMap.put("SONUC_LIST", filterRow, iMap.getString("COLUMN_LIST", columnIndex, "NAME"), iMap.getString("ISLEM_LIST", row, iMap.getString("COLUMN_LIST", columnIndex, "NAME")));
					columnIndex++;
				}
				columnIndex = 0;
				filterRow++;
			}
			row++;
		}

		BigDecimal PTT_ISLEM_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_TRY = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_TRY = new BigDecimal(0);

		BigDecimal PTT_ISLEM_TOPLAM_EUR = new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_EUR = new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_EUR = new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_EUR = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_EUR = new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_EUR = new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_EUR = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_EUR = new BigDecimal(0);

		BigDecimal PTT_ISLEM_TOPLAM_USD = new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_USD = new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_USD = new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_USD = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_USD = new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_USD = new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_USD = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_USD = new BigDecimal(0);

		BigDecimal PTT_ISLEM_TOPLAM_XAU = new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_XAU = new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_XAU = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_XAU = new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_XAU = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_XAU = new BigDecimal(0);

		int tableSize = oMap.getSize("SONUC_LIST");
		String tableName2 = "SONUC_LIST";

		for (int j = 0; j < tableSize; j++) {

			if (oMap.getString(tableName2, j, "ISLEM_ADI_PTT") != null) {

				if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD") != null)
				// /oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null*/
				/*&& oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0*/{

					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
						PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
						if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0) {
							PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));

						}

						PTT_ISLEM_ADET_TRY = PTT_ISLEM_ADET_TRY.add(new BigDecimal(1));
						BANKA_ISLEM_ADET_TRY = BANKA_ISLEM_ADET_TRY.add(new BigDecimal(1));
						PTT_GENEL_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY);
						BANKA_GENEL_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY);
					}

					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("XAU") == 0 && oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0) {

						PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
						BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));

					}

					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0) {
						PTT_ISLEM_TOPLAM_EUR = PTT_ISLEM_TOPLAM_EUR.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						BANKA_ISLEM_TOPLAM_EUR = BANKA_ISLEM_TOPLAM_EUR.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
						if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("EUR") == 0) {
							PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));

						}
						PTT_ISLEM_ADET_EUR = PTT_ISLEM_ADET_EUR.add(new BigDecimal(1));
						BANKA_ISLEM_ADET_EUR = BANKA_ISLEM_ADET_EUR.add(new BigDecimal(1));
						PTT_GENEL_TOPLAM_EUR = PTT_ISLEM_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_TRY);
						BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_TRY);
					}

					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0) {
						PTT_ISLEM_TOPLAM_USD = PTT_ISLEM_TOPLAM_USD.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						BANKA_ISLEM_TOPLAM_USD = BANKA_ISLEM_TOPLAM_USD.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));

						if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("USD") == 0) {
							PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
						}
						PTT_ISLEM_ADET_USD = PTT_ISLEM_ADET_USD.add(new BigDecimal(1));
						BANKA_ISLEM_ADET_USD = BANKA_ISLEM_ADET_USD.add(new BigDecimal(1));
						PTT_GENEL_TOPLAM_USD = PTT_ISLEM_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_TRY);
						BANKA_GENEL_TOPLAM_USD = BANKA_ISLEM_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_TRY);
					}

					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("XAU") == 0) {
						PTT_ISLEM_TOPLAM_XAU = PTT_ISLEM_TOPLAM_XAU.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						BANKA_ISLEM_TOPLAM_XAU = BANKA_ISLEM_TOPLAM_XAU.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));

						if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("XAU") == 0) {
							PTT_MASRAF_TOPLAM_XAU = PTT_MASRAF_TOPLAM_XAU.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							BANKA_MASRAF_TOPLAM_XAU = BANKA_MASRAF_TOPLAM_XAU.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
						}
						PTT_ISLEM_ADET_XAU = PTT_ISLEM_ADET_XAU.add(new BigDecimal(1));
						BANKA_ISLEM_ADET_XAU = BANKA_ISLEM_ADET_XAU.add(new BigDecimal(1));

						PTT_GENEL_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY);
						BANKA_GENEL_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY);

					}

				}

			}

		}

		oMap.put("PTT_ISLEM_TOPLAM_TRY", PTT_ISLEM_TOPLAM_TRY);
		oMap.put("PTT_MASRAF_TOPLAM_TRY", PTT_MASRAF_TOPLAM_TRY);
		oMap.put("PTT_GENEL_TOPLAM_TRY", PTT_GENEL_TOPLAM_TRY);
		oMap.put("PTT_ISLEM_ADET_TRY", PTT_ISLEM_ADET_TRY);

		oMap.put("PTT_ISLEM_TOPLAM_USD", PTT_ISLEM_TOPLAM_USD);
		oMap.put("PTT_MASRAF_TOPLAM_USD", PTT_MASRAF_TOPLAM_USD);
		oMap.put("PTT_GENEL_TOPLAM_USD", PTT_GENEL_TOPLAM_USD);
		oMap.put("PTT_ISLEM_ADET_USD", PTT_ISLEM_ADET_USD);

		oMap.put("PTT_ISLEM_TOPLAM_EUR", PTT_ISLEM_TOPLAM_EUR);
		oMap.put("PTT_MASRAF_TOPLAM_EUR", PTT_MASRAF_TOPLAM_EUR);
		oMap.put("PTT_GENEL_TOPLAM_EUR", PTT_GENEL_TOPLAM_EUR);
		oMap.put("PTT_ISLEM_ADET_EUR", PTT_ISLEM_ADET_EUR);

		oMap.put("BANKA_ISLEM_TOPLAM_TRY", BANKA_ISLEM_TOPLAM_TRY);
		oMap.put("BANKA_GENEL_TOPLAM_TRY", BANKA_GENEL_TOPLAM_TRY);
		oMap.put("BANKA_ISLEM_ADET_TRY", BANKA_ISLEM_ADET_TRY);
		oMap.put("BANKA_MASRAF_TOPLAM_TRY", BANKA_MASRAF_TOPLAM_TRY);

		oMap.put("BANKA_ISLEM_TOPLAM_EUR", BANKA_ISLEM_TOPLAM_EUR);
		oMap.put("BANKA_MASRAF_TOPLAM_EUR", BANKA_MASRAF_TOPLAM_EUR);
		oMap.put("BANKA_ISLEM_ADET_EUR", BANKA_ISLEM_ADET_EUR);
		oMap.put("BANKA_GENEL_TOPLAM_EUR", BANKA_GENEL_TOPLAM_EUR);

		oMap.put("BANKA_ISLEM_TOPLAM_USD", BANKA_ISLEM_TOPLAM_USD);
		oMap.put("BANKA_MASRAF_TOPLAM_USD", BANKA_MASRAF_TOPLAM_USD);
		oMap.put("BANKA_ISLEM_ADET_USD", BANKA_ISLEM_ADET_USD);
		oMap.put("BANKA_GENEL_TOPLAM_USD", BANKA_GENEL_TOPLAM_USD);

		oMap.put("PTT_ISLEM_TOPLAM_XAU", PTT_ISLEM_TOPLAM_XAU);
		oMap.put("PTT_MASRAF_TOPLAM_XAU", PTT_MASRAF_TOPLAM_XAU);
		oMap.put("PTT_GENEL_TOPLAM_XAU", PTT_ISLEM_TOPLAM_XAU);
		oMap.put("PTT_ISLEM_ADET_XAU", PTT_ISLEM_ADET_XAU);

		oMap.put("BANKA_ISLEM_TOPLAM_XAU", BANKA_ISLEM_TOPLAM_XAU);
		oMap.put("BANKA_MASRAF_TOPLAM_XAU", BANKA_MASRAF_TOPLAM_XAU);
		oMap.put("BANKA_GENEL_TOPLAM_XAU", BANKA_ISLEM_TOPLAM_XAU);
		oMap.put("BANKA_ISLEM_ADET_XAU", BANKA_ISLEM_ADET_XAU);

		return oMap;
	}

	@GraymoundService("BNSPR_QRY2085_RC_ONLY_MUTABAKATSIZLAR_BONO")
	public static GMMap getMutabakatOnlyMutabatsizBono(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2085.Agreement_Response_Yatirim(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.get("TARIH") != null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2085_RC_QRY_GET_BONO_DATA")
	public static GMMap getBonoData(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		BigDecimal PTTYT1 = new BigDecimal(0);
		BigDecimal AKTIFBANKYT1 = new BigDecimal(0);
		BigDecimal pttbankYT2 = new BigDecimal(0);
		BigDecimal pttbankYT3 = new BigDecimal(0);
		BigDecimal AKTIFBANKYT3 = new BigDecimal(0);

		BigDecimal MASRAFYATANPTTTRY = new BigDecimal(0);
		BigDecimal MASRAFYATANAKTIFBANKTRY = new BigDecimal(0);

		BigDecimal PPTYATANADETTRY = new BigDecimal(0);
		BigDecimal AKTIFBANKYATANADETTRY = new BigDecimal(0);

		BigDecimal IPTALPTTYATANTRY = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANTRY = new BigDecimal(0);

		BigDecimal IPTALMASRAFPTTYATANTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKYATANTRY = new BigDecimal(0);

		BigDecimal IPTALPTTYATANADETTRY = new BigDecimal(0);
		BigDecimal IPTALBANKAYATANADETTRY = new BigDecimal(0);

		BigDecimal PTTCEKILENTRY = new BigDecimal(0);
		BigDecimal AKTIFCEKILENTRY = new BigDecimal(0);

		BigDecimal MASRAFCEKILENPTTTRY = new BigDecimal(0);
		BigDecimal MASRAFCEKILENAKTIFBANKTRY = new BigDecimal(0);

		BigDecimal PPTCEKILENADETTRY = new BigDecimal(0);
		BigDecimal AKTIFBANKCEKILENADETTRY = new BigDecimal(0);

		BigDecimal IPTALPTTCEKILENTRY = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKCEKILENTRY = new BigDecimal(0);

		BigDecimal IPTALMASRAFPTTCEKILENTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKCEKILENTRY = new BigDecimal(0);

		BigDecimal IPTALPTTCEKILENADETTRY = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKCEKILENADETTRY = new BigDecimal(0);

		GMMap oMapOnlyMutabakatsiz = new GMMap();

		try {

			int i = 1;

			oMap.put("CBS_AKTIFBANK_PTT", GMServiceExecuter.execute("BNSPR_QRY2085_RC_QRY_GET_2ST_LEVEL_AKTIF_BONO", iMap).get("CBS_AKTIFBANK"));

			String tableName = "CBS_AKTIFBANK_PTT";
			i = oMap.getSize(tableName);
			int j = 0;

			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2085_RC_MUTABAKATSIZLAR_BONO", iMap));

			/* Ek son */
			// o0Map=CLKSUtil.remoteCall("CLKS_PTT_KREDI_BASVURU_BILGI",(GMMap)new
			// GMMap().put("MUSTERI_NO", iMap.getString("musteriNo")));
			String tableName2 = "CBS_AKTIFBANK_PTT";
			tableName = "CBS_AKTIFBANK_PTT_MUTABAKATSIZ";
			for (j = 0; j < iMap.getSize(tableName); j++) {
				oMap.put(tableName2, i, "ISLEM_TURU_PTT", iMap.getString(tableName, j, "ISLEM_TURU_PTT"));
				oMap.put(tableName2, i, "PTT_ISLEM_TUTARI", iMap.getString(tableName, j, "PTT_ISLEM_TUTARI"));
				oMap.put(tableName2, i, "PTT_MASRAF_TUTARI", iMap.getString(tableName, j, "PTT_MASRAF_TUTARI"));
				oMap.put(tableName2, i, "ISLEM_NO_PTT", iMap.getString(tableName, j, "ISLEM_NO_PTT"));
				oMap.put(tableName2, i, "NUMARA", iMap.getString(tableName, j, "NUMARA")); // ISLEMNOBANKA

				oMap.put(tableName2, i, "PTT_DOVIZ_KODU", iMap.getString(tableName, j, "PTT_DOVIZ_KODU"));

				oMap.put(tableName2, i, "EFT_HESAP_KASA", iMap.getString(tableName, j, "EFT_HESAP_KASA"));

				oMap.put(tableName2, i, "ISLEM", iMap.getString(tableName, j, "ISLEM"));

				oMap.put(tableName2, i, "PTT_TOPLAM_TUTAR", iMap.getString(tableName, j, "PTT_TOPLAM_TUTAR"));

				oMap.put(tableName2, i, "ISLEM_ADI_PTT", iMap.getString(tableName, j, "ISLEM_ADI_PTT"));

				oMap.put(tableName2, i, "PTT_MASRAF_DOVIZ_KOD", iMap.getString(tableName, j, "PTT_MASRAF_DOVIZ_KOD"));

				i++;
			}

			tableName2 = "CBS_AKTIFBANK_PTT";
			for (j = 0; j < oMap.getSize(tableName2); j++) { // Aktifbank i�lem
				// T�P� null sa
				// demekki banka
				// islemi

				// ptt'den gelecek nakit, bono ya da altin alinmasi durumunda
				if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null && oMap.getString(tableName2, j, "ISLEM") != null) {

					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") != 0 && oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONHURDAAL") == 0) {
						MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
					}

					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") != 0 && (oMap.getString(tableName2, j, "ISLEM").compareTo("BONOAL") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONAL") == 0))

					{
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
								// sadece nakit yatirimlari gosteriyoruz.
								PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
								PPTYATANADETTRY = PPTYATANADETTRY.add(new BigDecimal(1));
							}

							if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0) {
								MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							}
						}
					}

				}

				// ptt'ye yat�r�lacak nakit, bono ya da altin bozdurulmasi durumunda..
				if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null && oMap.getString(tableName2, j, "ISLEM") != null) {

					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") != 0 && (oMap.getString(tableName2, j, "ISLEM").compareTo("BONOSAT") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONSAT") == 0))

					{
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
								PTTCEKILENTRY = PTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
								PPTCEKILENADETTRY = PPTCEKILENADETTRY.add(new BigDecimal(1));
							}

							if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0) {
								MASRAFCEKILENPTTTRY = MASRAFCEKILENPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							}
						}
					}

				}

				// IPTAL YATAN ptt
				if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null && oMap.getString(tableName2, j, "ISLEM") != null) {

					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") == 0 && oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONHURDAAL") == 0) {
						IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
					}

					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") == 0 && (oMap.getString(tableName2, j, "ISLEM").compareTo("BONOAL") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONAL") == 0))

					{
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
								IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
								IPTALPTTYATANADETTRY = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0 && oMap.getString(tableName2, j, "EFT_HESAP_KASA").equals("KASA")) {
								IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							}
						}
					}
				}

				// iptal cekilen ptt

				if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null && oMap.getString(tableName2, j, "ISLEM") != null) {

					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") == 0 && (oMap.getString(tableName2, j, "ISLEM").compareTo("BONOSAT") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONSAT") == 0))

					{
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {

								IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
								IPTALPTTCEKILENADETTRY = IPTALPTTCEKILENADETTRY.add(new BigDecimal(1));
							}

							if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0) {
								IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							}
						}
					}
				}

				// AKTIFBANKISLEMLERI
				if (oMap.getString(tableName2, j, "ISLEM_KOD") != null && oMap.getString(tableName2, j, "ISLEM") != null && oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null) {

					// AKTIFBANKYATAN

					if (!oMap.getString(tableName2, j, "ISLEM_ADI_PTT").equals("IPTAL") && oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2112)) == 0) {

						MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
					}

					if (!oMap.getString(tableName2, j, "ISLEM_TURU_PTT").equals("IPTAL")) {

						if (oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(1401)) == 0 || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2111)) == 0
						/*&& (oMap.getString(tableName2, j, "ISLEM").compareTo("BONOAL") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINAL") == 0)*/) {

							if (oMap.getString(tableName2, j, "ISLEM_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

								if (oMap.getString(tableName2, j, "ISLEM_DOVIZ_KODU").compareTo("TRY") == 0) {
									AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
									AKTIFBANKYATANADETTRY = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
								}
								if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
									MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
								}
							}
						}
					}

					// aktifbank iptal YATAN
					if (oMap.getString(tableName2, j, "ISLEM_KOD") != null && oMap.getString(tableName2, j, "ISLEM") != null && oMap.getString(tableName2, j, "ISLEM_ADI_PTT") != null) {

						// AKTIFBANKYATAN

						if (oMap.getString(tableName2, j, "ISLEM_ADI_PTT").equals("IPTAL") && oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2112)) == 0) {

							IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
						}

						if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT").equals("IPTAL")) {

							if (oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(1401)) == 0 || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2111)) == 0
							/*&& (oMap.getString(tableName2, j, "ISLEM").compareTo("BONOAL") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINAL") == 0)*/) {

								if (oMap.getString(tableName2, j, "ISLEM_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

									if (oMap.getString(tableName2, j, "ISLEM_DOVIZ_KODU").compareTo("TRY") == 0) {
										IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
										IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));

									}
									if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
										IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
									}
								}
							}
						}
					}
				}

				if (oMap.getString(tableName2, j, "ISLEM_KOD") != null && oMap.getString(tableName2, j, "ISLEM") != null && oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null) {

					if (!oMap.getString(tableName2, j, "ISLEM_TURU_PTT").equals("IPTAL")) {
						// AKTIFBANKCEKILEN
						if (oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(1406)) == 0 || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2113)) == 0 /*&& (oMap.getString(tableName2, j, "ISLEM").compareTo("BONOSAT") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONSAT") == 0)*/) {

							if (oMap.getString(tableName2, j, "ISLEM_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

								if (oMap.getString(tableName2, j, "ISLEM_DOVIZ_KODU").compareTo("TRY") == 0) {
									AKTIFCEKILENTRY = AKTIFCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
									AKTIFBANKCEKILENADETTRY = AKTIFBANKCEKILENADETTRY.add(new BigDecimal(1));
								}
								if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
									MASRAFCEKILENAKTIFBANKTRY = MASRAFCEKILENAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
								}
							}

						}
					}
				}

				// aktifbank iptal cekilen
				if (oMap.getString(tableName2, j, "ISLEM_KOD") != null && oMap.getString(tableName2, j, "ISLEM") != null && oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null) {

					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT").equals("IPTAL")) {

						if (oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(1406)) == 0 || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2113)) == 0 /*&& (oMap.getString(tableName2, j, "ISLEM").compareTo("BONOSAT") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("ALTINFONSAT") == 0)*/) {

							if (oMap.getString(tableName2, j, "ISLEM_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0) {

								if (oMap.getString(tableName2, j, "ISLEM_DOVIZ_KODU").compareTo("TRY") == 0) {
									IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
									IPTALAKTIFBANKCEKILENADETTRY = IPTALAKTIFBANKCEKILENADETTRY.add(new BigDecimal(1));

								}
								if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
									IPTALMASRAFAKTIFBANKCEKILENTRY = IPTALMASRAFAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
								}
							}
						}
					}
				}
			}

			oMap.put("PTTYT1", PTTYT1);
			oMap.put("AKTIFBANKYT1", AKTIFBANKYT1);
			oMap.put("pttbankYT2", pttbankYT2);
			oMap.put("pttbankYT3", pttbankYT3);
			oMap.put("AKTIFBANKYT3", AKTIFBANKYT3);

			oMap.put("MASRAFYATANPTTTRY", MASRAFYATANPTTTRY);
			oMap.put("MASRAFYATANAKTIFBANKTRY", MASRAFYATANAKTIFBANKTRY);

			oMap.put("PPTYATANADETTRY", PPTYATANADETTRY);
			oMap.put("AKTIFBANKYATANADETTRY", AKTIFBANKYATANADETTRY);

			oMap.put("IPTALPTTYATANTRY", IPTALPTTYATANTRY);
			oMap.put("IPTALAKTIFBANKYATANTRY", IPTALAKTIFBANKYATANTRY);

			oMap.put("IPTALAKTIFBANKCEKILENTRY", IPTALAKTIFBANKCEKILENTRY);
			oMap.put("IPTALAKTIFBANKCEKILENADETTRY", IPTALAKTIFBANKCEKILENADETTRY);
			oMap.put("IPTALMASRAFAKTIFBANKCEKILENTRY", IPTALMASRAFAKTIFBANKCEKILENTRY);

			oMap.put("AKTIFCEKILENTRY", AKTIFCEKILENTRY);
			oMap.put("AKTIFBANKCEKILENADETTRY", AKTIFBANKCEKILENADETTRY);
			oMap.put("MASRAFCEKILENAKTIFBANKTRY", MASRAFCEKILENAKTIFBANKTRY);

			BigDecimal PTT_BORC_TL = new BigDecimal(0);

			BigDecimal PTT_BORC_EUR = new BigDecimal(0);

			BigDecimal PTT_BORC_USD = new BigDecimal(0);

			BigDecimal AKTIFBANK_BORC_TL = new BigDecimal(0);

			BigDecimal AKTIFBANK_BORC_EUR = new BigDecimal(0);

			BigDecimal AKTIFBANK_BORC_USD = new BigDecimal(0);

			oMap.put("pttbankYT2", pttbankYT2);

			BigDecimal TOPLAMYATANPTTTRY = PTTYT1.add(MASRAFYATANPTTTRY);
			BigDecimal TOPLAMYATANAKTIFBANKTRY = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY);
			BigDecimal TOPLAMCEKILENAKTIF = AKTIFCEKILENTRY.subtract(MASRAFCEKILENAKTIFBANKTRY);
			BigDecimal TOPLAMCEKILENPTT = PTTCEKILENTRY.subtract(MASRAFCEKILENPTTTRY);

			oMap.put("TOPLAMYATANPTTTRY", TOPLAMYATANPTTTRY);
			oMap.put("TOPLAMYATANAKTIFBANKTRY", TOPLAMYATANAKTIFBANKTRY);
			oMap.put("TOPLAMCEKILENAKTIF", TOPLAMCEKILENAKTIF);

			oMap.put("PPTCEKILENADETTRY", PPTCEKILENADETTRY);
			oMap.put("PTTCEKILENTRY", PTTCEKILENTRY);
			oMap.put("MASRAFCEKILENPTTTRY", MASRAFCEKILENPTTTRY);
			oMap.put("TOPLAMCEKILENPTT", TOPLAMCEKILENPTT);

			oMap.put("IPTALPTTCEKILENADETTRY", IPTALPTTCEKILENADETTRY);
			oMap.put("IPTALMASRAFPTTCEKILENTRY", IPTALMASRAFPTTCEKILENTRY);
			oMap.put("IPTALPTTCEKILENTRY", IPTALPTTCEKILENTRY);

			oMap.put("IPTALMASRAFPTTYATANTRY", IPTALMASRAFPTTYATANTRY);
			oMap.put("IPTALMASRAFAKTIFBANKYATANTRY", IPTALMASRAFAKTIFBANKYATANTRY);

			oMap.put("IPTALPTTYATANADETTRY", IPTALPTTYATANADETTRY);
			oMap.put("IPTALBANKAYATANADETTRY", IPTALBANKAYATANADETTRY);

			PTT_BORC_TL = PTTYT1.add(MASRAFYATANPTTTRY).subtract(IPTALPTTYATANTRY).subtract(IPTALMASRAFPTTYATANTRY).subtract(PTTCEKILENTRY).subtract(MASRAFCEKILENPTTTRY).add(IPTALPTTCEKILENTRY).add(IPTALMASRAFPTTCEKILENTRY);

			oMap.put("BORC_TL_PTT", PTT_BORC_TL);
			oMap.put("BORC_USD_PTT", PTT_BORC_USD);
			oMap.put("BORC_EUR_PTT", PTT_BORC_EUR);

			oMap.put("BORC_TL_BANKA", "0");
			oMap.put("BORC_EUR_BANKA", "0");
			oMap.put("BORC_USD_BANKA", "0");

			if (PTT_BORC_TL.intValue() < 0) {
				AKTIFBANK_BORC_TL = PTT_BORC_TL;
				oMap.put("BORC_TL_BANKA", AKTIFBANK_BORC_TL);
				oMap.put("BORC_TL_PTT", "0");
			}

			if (PTT_BORC_EUR.intValue() < 0) {
				AKTIFBANK_BORC_EUR = PTT_BORC_EUR;
				oMap.put("BORC_EUR_BANKA", AKTIFBANK_BORC_EUR);
				oMap.put("BORC_EUR_PTT", "0");
			}
			if (PTT_BORC_USD.intValue() < 0) {
				AKTIFBANK_BORC_USD = PTT_BORC_USD;
				oMap.put("BORC_USD_BANKA", AKTIFBANK_BORC_USD);
				oMap.put("BORC_USD_PTT", "0");
			}

			AKTIFBANK_BORC_TL = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY).subtract(IPTALAKTIFBANKYATANTRY).subtract(IPTALMASRAFAKTIFBANKYATANTRY);

			GMMap sMap = new GMMap();

			sMap.put("TARIH", iMap.get("TARIH"));

			sMap.put("AKTIFBANK_BORC_TL", AKTIFBANK_BORC_TL);
			sMap.put("AKTIFBANK_BORC_EUR", AKTIFBANK_BORC_EUR);
			sMap.put("AKTIFBANK_BORC_USD", AKTIFBANK_BORC_USD);

			sMap.put("PTT_BORC_TL", PTT_BORC_TL);
			sMap.put("PTT_BORC_USD", PTT_BORC_USD);
			sMap.put("PTT_BORC_EUR", PTT_BORC_EUR);

			// GMServiceExecuter.execute("BNSPR_QRY2052_SET_NET_OFF", sMap);
			oMap.put("KAYIT_SAYISI", "1");

			// BU KONTROL BLOGU KALDIRILIRSA MUTABAKATLILARDA LISTELENECEK
			if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("true") == 0) {
				oMapOnlyMutabakatsiz.putAll(GMServiceExecuter.execute("BNSPR_QRY2085_RC_ONLY_MUTABAKATSIZLAR_BONO", iMap));

				oMap.put("KAYIT_SAYISI", oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT"));

				if (oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT") > 0) {
					oMap.putAll(oMapOnlyMutabakatsiz);
				}
				else {
					oMap.remove("CBS_AKTIFBANK_PTT");
				}

				// oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR", iMap));
			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2085_RC_MUTABAKATSIZLAR_BONO")
	public static GMMap getMutabakatsizIslemlerBono(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2085.Agreement_Response_Yatirim(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.get("TARIH") != null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			// if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("1")==0){
			// oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
			// }else{
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT_MUTABAKATSIZ");
			// }
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/*@GraymoundService("BNSPR_QRY2085_RC_QRY_GET_YATIRIM_DATA")
	public static GMMap getSecondLevelAktifBono(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2085.Rc_Qry_2nd_Level_Akt_Yatirim(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}*/
	@GraymoundService("BNSPR_QRY2085_RC_QRY_GET_URUN_MUSTERI_DATA")
	public static GMMap getUrunMusteriData(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		BigDecimal MASRAFYATANPTTTRY = new BigDecimal(0);
		BigDecimal MASRAFYATANAKTIFBANKTRY = new BigDecimal(0);

		BigDecimal PPTYATANADETTRY = new BigDecimal(0);
		BigDecimal AKTIFBANKYATANADETTRY = new BigDecimal(0);

		BigDecimal IPTALMASRAFPTTYATANTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKYATANTRY = new BigDecimal(0);

		BigDecimal IPTALPTTYATANADETTRY = new BigDecimal(0);
		BigDecimal IPTALBANKAYATANADETTRY = new BigDecimal(0);

		GMMap oMapOnlyMutabakatsiz = new GMMap();

		try {

			int i = 1;

			oMap.put("CBS_AKTIFBANK_PTT", GMServiceExecuter.execute("BNSPR_QRY2085_RC_QRY_GET_2ST_LEVEL_AKTIF_URUN_MUSTERI", iMap).get("CBS_AKTIFBANK"));

			String tableName = "CBS_AKTIFBANK_PTT";
			i = oMap.getSize(tableName);
			int j = 0;

			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2085_RC_MUTABAKATSIZLAR_URUN_MUSTERI", iMap));

			/* Ek son */
			// o0Map=CLKSUtil.remoteCall("CLKS_PTT_KREDI_BASVURU_BILGI",(GMMap)new
			// GMMap().put("MUSTERI_NO", iMap.getString("musteriNo")));
			String tableName2 = "CBS_AKTIFBANK_PTT";
			tableName = "CBS_AKTIFBANK_PTT_MUTABAKATSIZ";
			for (j = 0; j < iMap.getSize(tableName); j++) {
				oMap.put(tableName2, i, "ISLEM_TURU_PTT", iMap.getString(tableName, j, "ISLEM_TURU_PTT"));
				oMap.put(tableName2, i, "PTT_ISLEM_TUTARI", iMap.getString(tableName, j, "PTT_ISLEM_TUTARI"));
				oMap.put(tableName2, i, "PTT_MASRAF_TUTARI", iMap.getString(tableName, j, "PTT_MASRAF_TUTARI"));
				oMap.put(tableName2, i, "ISLEM_NO_PTT", iMap.getString(tableName, j, "ISLEM_NO_PTT"));
				oMap.put(tableName2, i, "NUMARA", iMap.getString(tableName, j, "NUMARA")); // ISLEMNOBANKA

				oMap.put(tableName2, i, "PTT_DOVIZ_KODU", iMap.getString(tableName, j, "PTT_DOVIZ_KODU"));

				oMap.put(tableName2, i, "EFT_HESAP_KASA", iMap.getString(tableName, j, "EFT_HESAP_KASA"));

				oMap.put(tableName2, i, "ISLEM", iMap.getString(tableName, j, "ISLEM"));

				oMap.put(tableName2, i, "PTT_TOPLAM_TUTAR", iMap.getString(tableName, j, "PTT_TOPLAM_TUTAR"));

				oMap.put(tableName2, i, "ISLEM_ADI_PTT", iMap.getString(tableName, j, "ISLEM_ADI_PTT"));

				oMap.put(tableName2, i, "MASRAF_DOVIZ_KODU", iMap.getString(tableName, j, "MASRAF_DOVIZ_KODU"));

				i++;
			}

			tableName2 = "CBS_AKTIFBANK_PTT";
			for (j = 0; j < oMap.getSize(tableName2); j++) { // Aktifbank i�lem
				// T�P� null sa
				// demekki banka
				// islemi

				// YATAN ptt
				if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null) {
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {

						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
							PPTYATANADETTRY = PPTYATANADETTRY.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
							MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
						}
					}
				}

				// IPTAL YATAN ptt
				if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null && oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") == 0) {

					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {

						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
							IPTALPTTYATANADETTRY = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
							IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
						}
					}
				}

				// AKTIFBANKISLEMLERI
				if (oMap.getString(tableName2, j, "ISLEM_KOD") != null) {
					// AKTIFBANKYATAN
					if (oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(10011)) == 0 || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2059)) == 0) {
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {

							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
								AKTIFBANKYATANADETTRY = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
								MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
							}
						}
					}

					// aktifbank iptal YATAN
					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null && oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") == 0) {
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
								IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
								IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							}
						}
					}
				}

			}

			oMap.put("MASRAFYATANPTTTRY", MASRAFYATANPTTTRY);
			oMap.put("MASRAFYATANAKTIFBANKTRY", MASRAFYATANAKTIFBANKTRY);

			oMap.put("PPTYATANADETTRY", PPTYATANADETTRY);
			oMap.put("AKTIFBANKYATANADETTRY", AKTIFBANKYATANADETTRY);

			BigDecimal PTT_BORC_TL = new BigDecimal(0);

			BigDecimal PTT_BORC_EUR = new BigDecimal(0);

			BigDecimal PTT_BORC_USD = new BigDecimal(0);

			BigDecimal AKTIFBANK_BORC_TL = new BigDecimal(0);

			BigDecimal AKTIFBANK_BORC_EUR = new BigDecimal(0);

			BigDecimal AKTIFBANK_BORC_USD = new BigDecimal(0);

			oMap.put("IPTALMASRAFPTTYATANTRY", IPTALMASRAFPTTYATANTRY);
			oMap.put("IPTALMASRAFAKTIFBANKYATANTRY", IPTALMASRAFAKTIFBANKYATANTRY);

			oMap.put("IPTALPTTYATANADETTRY", IPTALPTTYATANADETTRY);
			oMap.put("IPTALBANKAYATANADETTRY", IPTALBANKAYATANADETTRY);

			PTT_BORC_TL = MASRAFYATANPTTTRY.subtract(IPTALMASRAFPTTYATANTRY);

			oMap.put("BORC_TL_PTT", PTT_BORC_TL);

			oMap.put("BORC_TL_BANKA", "0");

			if (PTT_BORC_TL.intValue() < 0) {
				AKTIFBANK_BORC_TL = PTT_BORC_TL;
				oMap.put("BORC_TL_BANKA", AKTIFBANK_BORC_TL);
				oMap.put("BORC_TL_PTT", "0");
			}

			GMMap sMap = new GMMap();

			sMap.put("TARIH", iMap.get("TARIH"));

			sMap.put("AKTIFBANK_BORC_TL", AKTIFBANK_BORC_TL);
			sMap.put("AKTIFBANK_BORC_EUR", AKTIFBANK_BORC_EUR);
			sMap.put("AKTIFBANK_BORC_USD", AKTIFBANK_BORC_USD);

			sMap.put("PTT_BORC_TL", PTT_BORC_TL);
			sMap.put("PTT_BORC_USD", PTT_BORC_USD);
			sMap.put("PTT_BORC_EUR", PTT_BORC_EUR);

			// GMServiceExecuter.execute("BNSPR_QRY2052_SET_NET_OFF", sMap);
			oMap.put("KAYIT_SAYISI", "1");

			// BU KONTROL BLOGU KALDIRILIRSA MUTABAKATLILARDA LISTELENECEK
			if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("true") == 0) {
				oMapOnlyMutabakatsiz.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_URUN_MUSTERI", iMap));

				oMap.put("KAYIT_SAYISI", oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT"));

				if (oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT") > 0) {
					oMap.putAll(oMapOnlyMutabakatsiz);
				}
				else {
					oMap.remove("CBS_AKTIFBANK_PTT");
				}

				// oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR", iMap));
			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2085_RC_QRY_GET_2ST_LEVEL_AKTIF_URUN_MUSTERI")
	public static GMMap getSecondLevelAktifUrunMusteri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2085.Rc_Qry_Get_2nd_Level_Akt_Must(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.get("TARIH") != null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2085_RC_MUTABAKATSIZLAR_URUN_MUSTERI")
	public static GMMap getMutabakatsizIslemlerUrunMusteri(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2085.Agreement_Response_Musteri(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.get("TARIH") != null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			// if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("1")==0){
			// oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
			// }else{
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT_MUTABAKATSIZ");
			// }
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2085_RC_QRY_GET_ISLEMLER_URUN_MUSTERI")
	public static GMMap Get_Islemler_Urun_Musteri(GMMap iMap) {
		GMMap oMap = new GMMap();

		BigDecimal PTT_MASRAF_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_TRY = new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_TRY = new BigDecimal(0);

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {
			int j = 0;

			for (int i = 0; i < iMap.getSize("ISLEM_LIST"); i++) {

				if (iMap.getString("ISLEM_TIPI").compareTo(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT")) == 0) {
					oMap.put("SONUC_LIST", j, "ANAISLEMDURUM", iMap.getString("ISLEM_LIST", i, "ANAISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "EFT_HESAP_KASA", iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA"));
					oMap.put("SONUC_LIST", j, "IPTALISLEMDURUM", iMap.getString("ISLEM_LIST", i, "IPTALISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "ISLEM_KOD", iMap.getString("ISLEM_LIST", i, "ISLEM_KOD"));
					oMap.put("SONUC_LIST", j, "ISLEM_NO_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_NO_PTT"));
					oMap.put("SONUC_LIST", j, "ISLEM_TURU_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF", iMap.getString("ISLEM_LIST", i, "MASRAF"));
					oMap.put("SONUC_LIST", j, "NUMARA", iMap.getString("ISLEM_LIST", i, "NUMARA"));
					oMap.put("SONUC_LIST", j, "PTT_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "PTT_ISLEM_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_MASRAF_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "PTT_TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "PTTISLEMNO", iMap.getString("ISLEM_LIST", i, "PTTISLEMNO"));
					oMap.put("SONUC_LIST", j, "REFERANS", iMap.getString("ISLEM_LIST", i, "REFERANS"));
					oMap.put("SONUC_LIST", j, "TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "TUTAR", iMap.getString("ISLEM_LIST", i, "TUTAR"));
					oMap.put("SONUC_LIST", j, "ISLEM_ADI_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_ADI_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"));

					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {

						if (iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("H") != 0) {

							PTT_ISLEM_ADET_TRY = PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));

							if (iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
								PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}

							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null) {
								// BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								BANKA_ISLEM_ADET_TRY = BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));

								if (iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
									BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
							}
						}
					}

					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("USD") == 0) {

						if (iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("H") != 0) {

							if (iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
								PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}

							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null) {

								if (iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
									BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}

							}

						}
					}

					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("EUR") == 0) {

						if (iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("H") != 0) {

							if (iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
								PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}

							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null) {
								// BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));

								if (iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
									BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}

							}

						}
					}

					if (iMap.getString("ISLEM_TIPI").compareTo("IPTAL") == 0) {

						conn = DALUtil.getGMConnection();
						stmt = conn.prepareCall("{ ? = call pkg_tx.Islem_kod(?) }");

						stmt.registerOutParameter(1, Types.NUMERIC);
						stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_LIST", i, "NUMARA"));

						stmt.execute();

						iMap.put("ISLEM_KODU", stmt.getBigDecimal(1));

					}
					j++;
				}
			}
			oMap.put("PTT_MASRAF_TOPLAM_TRY", PTT_MASRAF_TOPLAM_TRY);
			oMap.put("PTT_ISLEM_ADET_TRY", PTT_ISLEM_ADET_TRY);

			oMap.put("BANKA_MASRAF_TOPLAM_TRY", BANKA_MASRAF_TOPLAM_TRY);
			oMap.put("BANKA_ISLEM_ADET_TRY", BANKA_ISLEM_ADET_TRY);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2085_RC_QRY_GET_2ST_LEVEL_AKTIF_BONO")
	public static GMMap getSecondLevelAktifBono(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2085.Rc_Qry_2nd_Level_Akt_Yatirim(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.get("TARIH") != null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2085_RC_QRY_GET_MUTABAKATSIZ_ISLEMLER")
	public static GMMap getIslemlerMutabakat(GMMap iMap) {

		int row = 0;
		int size = iMap.getSize("ISLEM_LIST");
		int filterRow = 0;
		int columnIndex = 0;
		int columnSize = iMap.getSize("COLUMN_LIST");
		GMMap oMap = new GMMap();

		while (row < size) {

			if (iMap.get("ISLEM_LIST", row, "ISLEM") != null && iMap.get("ISLEM_LIST", row, "ISLEM_TURU_PTT").equals(iMap.getString("ISLEM_TIPI"))) {
				while (columnIndex < columnSize) {
					oMap.put("SONUC_LIST", filterRow, iMap.getString("COLUMN_LIST", columnIndex, "NAME"), iMap.getString("ISLEM_LIST", row, iMap.getString("COLUMN_LIST", columnIndex, "NAME")));
					columnIndex++;
				}
				columnIndex = 0;
				filterRow++;
			}
			row++;
		}

		BigDecimal PTT_ISLEM_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_TRY = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_TRY = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_TRY = new BigDecimal(0);

		BigDecimal PTT_ISLEM_TOPLAM_EUR = new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_EUR = new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_EUR = new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_EUR = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_EUR = new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_EUR = new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_EUR = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_EUR = new BigDecimal(0);

		BigDecimal PTT_ISLEM_TOPLAM_USD = new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_USD = new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_USD = new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_USD = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_USD = new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_USD = new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_USD = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_USD = new BigDecimal(0);

		BigDecimal PTT_ISLEM_TOPLAM_XAU = new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_XAU = new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_XAU = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_XAU = new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_XAU = new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_XAU = new BigDecimal(0);

		int tableSize = oMap.getSize("SONUC_LIST");
		String tableName2 = "SONUC_LIST";

		for (int j = 0; j < tableSize; j++) {

			if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null) {

				if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD") != null && oMap.getString(tableName2, j, "EFT_HESAP_KASA") != null
				/*&& oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("KASA") == 0*/) {

					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD").compareTo("TRY") == 0) {
						PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
						if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0) {
							PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));

						}

						PTT_ISLEM_ADET_TRY = PTT_ISLEM_ADET_TRY.add(new BigDecimal(1));
						BANKA_ISLEM_ADET_TRY = BANKA_ISLEM_ADET_TRY.add(new BigDecimal(1));
						PTT_GENEL_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY);
						BANKA_GENEL_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY);
					}

					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD").compareTo("XAU") == 0 && oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("TRY") == 0) {

						PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
						BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));

					}

					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD").compareTo("EUR") == 0) {
						PTT_ISLEM_TOPLAM_EUR = PTT_ISLEM_TOPLAM_EUR.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						BANKA_ISLEM_TOPLAM_EUR = BANKA_ISLEM_TOPLAM_EUR.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
						if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("EUR") == 0) {
							PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));

						}
						PTT_ISLEM_ADET_EUR = PTT_ISLEM_ADET_EUR.add(new BigDecimal(1));
						BANKA_ISLEM_ADET_EUR = BANKA_ISLEM_ADET_EUR.add(new BigDecimal(1));
						PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_TRY);
						BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_TRY);
					}

					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD").compareTo("USD") == 0) {
						PTT_ISLEM_TOPLAM_USD = PTT_ISLEM_TOPLAM_USD.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						BANKA_ISLEM_TOPLAM_USD = BANKA_ISLEM_TOPLAM_USD.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));

						if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("USD") == 0) {
							PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
						}
						PTT_ISLEM_ADET_USD = PTT_ISLEM_ADET_USD.add(new BigDecimal(1));
						BANKA_ISLEM_ADET_USD = BANKA_ISLEM_ADET_USD.add(new BigDecimal(1));
						PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_TRY);
						BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_TRY);
					}

					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KOD").compareTo("XAU") == 0) {
						PTT_ISLEM_TOPLAM_XAU = PTT_ISLEM_TOPLAM_XAU.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						BANKA_ISLEM_TOPLAM_XAU = BANKA_ISLEM_TOPLAM_XAU.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));

						if (oMap.getString(tableName2, j, "PTT_MASRAF_DOVIZ_KOD").compareTo("XAU") == 0) {
							PTT_MASRAF_TOPLAM_XAU = PTT_MASRAF_TOPLAM_XAU.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							BANKA_MASRAF_TOPLAM_XAU = BANKA_MASRAF_TOPLAM_XAU.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
						}
						PTT_ISLEM_ADET_XAU = PTT_ISLEM_ADET_XAU.add(new BigDecimal(1));
						BANKA_ISLEM_ADET_XAU = BANKA_ISLEM_ADET_XAU.add(new BigDecimal(1));
						PTT_GENEL_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY);
						BANKA_GENEL_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY);

					}

				}

			}

		}

		oMap.put("PTT_ISLEM_TOPLAM_TRY", PTT_ISLEM_TOPLAM_TRY);
		oMap.put("PTT_MASRAF_TOPLAM_TRY", PTT_MASRAF_TOPLAM_TRY);
		oMap.put("PTT_GENEL_TOPLAM_TRY", PTT_GENEL_TOPLAM_TRY);
		oMap.put("PTT_ISLEM_ADET_TRY", PTT_ISLEM_ADET_TRY);

		oMap.put("PTT_ISLEM_TOPLAM_USD", PTT_ISLEM_TOPLAM_USD);
		oMap.put("PTT_MASRAF_TOPLAM_USD", PTT_MASRAF_TOPLAM_USD);
		oMap.put("PTT_GENEL_TOPLAM_USD", PTT_GENEL_TOPLAM_USD);
		oMap.put("PTT_ISLEM_ADET_USD", PTT_ISLEM_ADET_USD);

		oMap.put("PTT_ISLEM_TOPLAM_EUR", PTT_ISLEM_TOPLAM_EUR);
		oMap.put("PTT_MASRAF_TOPLAM_EUR", PTT_MASRAF_TOPLAM_EUR);
		oMap.put("PTT_GENEL_TOPLAM_EUR", PTT_GENEL_TOPLAM_EUR);
		oMap.put("PTT_ISLEM_ADET_EUR", PTT_ISLEM_ADET_EUR);

		oMap.put("BANKA_ISLEM_TOPLAM_TRY", BANKA_ISLEM_TOPLAM_TRY);
		oMap.put("BANKA_GENEL_TOPLAM_TRY", BANKA_GENEL_TOPLAM_TRY);
		oMap.put("BANKA_ISLEM_ADET_TRY", BANKA_ISLEM_ADET_TRY);
		oMap.put("BANKA_MASRAF_TOPLAM_TRY", BANKA_MASRAF_TOPLAM_TRY);

		oMap.put("BANKA_ISLEM_TOPLAM_EUR", BANKA_ISLEM_TOPLAM_EUR);
		oMap.put("BANKA_MASRAF_TOPLAM_EUR", BANKA_MASRAF_TOPLAM_EUR);
		oMap.put("BANKA_ISLEM_ADET_EUR", BANKA_ISLEM_ADET_EUR);
		oMap.put("BANKA_GENEL_TOPLAM_EUR", BANKA_GENEL_TOPLAM_EUR);

		oMap.put("BANKA_ISLEM_TOPLAM_USD", BANKA_ISLEM_TOPLAM_USD);
		oMap.put("BANKA_MASRAF_TOPLAM_USD", BANKA_MASRAF_TOPLAM_USD);
		oMap.put("BANKA_ISLEM_ADET_USD", BANKA_ISLEM_ADET_USD);
		oMap.put("BANKA_GENEL_TOPLAM_USD", BANKA_GENEL_TOPLAM_USD);

		oMap.put("PTT_ISLEM_TOPLAM_XAU", PTT_ISLEM_TOPLAM_XAU);
		oMap.put("PTT_MASRAF_TOPLAM_XAU", PTT_MASRAF_TOPLAM_XAU);
		oMap.put("PTT_GENEL_TOPLAM_XAU", PTT_ISLEM_TOPLAM_XAU);
		oMap.put("PTT_ISLEM_ADET_XAU", PTT_ISLEM_ADET_XAU);

		oMap.put("BANKA_ISLEM_TOPLAM_XAU", BANKA_ISLEM_TOPLAM_XAU);
		oMap.put("BANKA_MASRAF_TOPLAM_XAU", BANKA_MASRAF_TOPLAM_XAU);
		oMap.put("BANKA_GENEL_TOPLAM_XAU", BANKA_ISLEM_TOPLAM_XAU);
		oMap.put("BANKA_ISLEM_ADET_XAU", BANKA_ISLEM_ADET_XAU);

		return oMap;
	}

	@GraymoundService("BNSPR_QRY2085_MUTABAKAT_TAMAMLA")
	public static GMMap mutabakatTamamla(GMMap iMap) {

		GMMap oMap = new GMMap();
		if (iMap.getString("ISLEM_TURU").equals("ALTIN FONU ALIS") || iMap.getString("ISLEM_TURU").equals("ALTIN FONU HURDA ALIS"))
			oMap = GMServiceExecuter.call("ALTIN_ALIS_ONAY", iMap);
		else if (iMap.getString("ISLEM_TURU").equals("ALTIN FONU SATIS"))
			oMap = GMServiceExecuter.call("ALTIN_SATIS_ONAY", iMap);

		return oMap;
	}
}
