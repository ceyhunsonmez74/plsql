package tr.com.calikbank.bnspr.currentaccounts.settings;

public class CurrentAccountSettings {

	//ORACLE FUNCTIONS
	public static final String TRN2015_ORACLE_FUNC_GET_EFEKTIF_SATIS_REFERANSNO = "{? = call BNSPR.Pkg_TRN2015.Efektif_Satis_Referansi_Al}";
	public static final String TRN2015_ORACLE_FUNC_GET_EFEKTIF_SATIS_KURU = "{? = call BNSPR.pkg_kur.ESK_to_LC(?,1)}";
	public static final String TRN2015_ORACLE_FUNC_GET_REZERVASYON_ACIKMI = "{? = call pkg_parametre.Deger_Al_K('EF_KUR_REZERVASYON_ACIK_MI')}";
	public static final String TRN2015_ORACLE_FUNC_GET_KMV = "{? = call pkg_parametre.Deger_Al_K_N('KMV_ORANI')}";
	
}
