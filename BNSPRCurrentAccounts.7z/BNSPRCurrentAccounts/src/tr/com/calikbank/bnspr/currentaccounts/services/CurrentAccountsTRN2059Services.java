package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ClksEuptHesapAcmaTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsTRN2059Services {
	
    @GraymoundService("BNSPR_TRN2059_SAVE")
    public static Map<?, ?> save(GMMap iMap) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd");

            Session session = DAOSession.getSession("BNSPRDal");

            ClksEuptHesapAcmaTx hesapAcmaTx = (ClksEuptHesapAcmaTx) session.createCriteria(ClksEuptHesapAcmaTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();

            if (hesapAcmaTx == null) {
                hesapAcmaTx = new ClksEuptHesapAcmaTx(iMap.getBigDecimal("TRX_NO"));
            }

            hesapAcmaTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO", hesapAcmaTx.getMusteriNo()));
            hesapAcmaTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO", hesapAcmaTx.getTcKimlikNo()));
            hesapAcmaTx.setAd(iMap.getString("AD", hesapAcmaTx.getAd()));
            hesapAcmaTx.setIkinciAd(iMap.getString("IKINCI_AD", hesapAcmaTx.getIkinciAd()));
            hesapAcmaTx.setSoyad(iMap.getString("SOYAD", hesapAcmaTx.getSoyad()));
            hesapAcmaTx.setTelefonKod(iMap.getString("TELEFON_KOD", hesapAcmaTx.getTelefonKod()));
            hesapAcmaTx.setTelefonNo(iMap.getString("TELEFON_NO", hesapAcmaTx.getTelefonNo()));
            hesapAcmaTx.setCepTelefonKod(iMap.getString("CEP_TEL_KOD", hesapAcmaTx.getCepTelefonKod()));
            hesapAcmaTx.setCepTelefonNo(iMap.getString("CEP_TEL_NO", hesapAcmaTx.getCepTelefonNo()));
            hesapAcmaTx.setEPosta(iMap.getString("E_POSTA", hesapAcmaTx.getEPosta()));
            hesapAcmaTx.setKullaniciAdi(iMap.getString("KULLANICI_ADI", hesapAcmaTx.getKullaniciAdi()));
            hesapAcmaTx.setDogumTarihi(StringUtils.isBlank(iMap.getString("DOGUM_TARIHI")) ? null : nvl(dateFormat.parse(iMap.getString("DOGUM_TARIHI")), hesapAcmaTx.getDogumTarihi()));
            hesapAcmaTx.setDogumYeri(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "DOGUM_YERI"), hesapAcmaTx.getDogumYeri()));
            hesapAcmaTx.setAnneAdi(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "ANNE_ADI"), hesapAcmaTx.getAnneAdi()));
            hesapAcmaTx.setBabaAdi(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "BABA_ADI"), hesapAcmaTx.getBabaAdi()));
            hesapAcmaTx.setCinsiyet(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "CINSIYET_KODU"), hesapAcmaTx.getCinsiyet()));
            hesapAcmaTx.setMedeniHal(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "MEDENI_HAL_KODU"), hesapAcmaTx.getMedeniHal()));
            hesapAcmaTx.setKimlikSeriNo(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "NUFUS_CUZDANI_SERI_NO"), hesapAcmaTx.getKimlikSeriNo()));
            hesapAcmaTx.setKimlikSiraNo(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "NUFUS_CUZDANI_SIRA_NO"), hesapAcmaTx.getKimlikSiraNo()));
            hesapAcmaTx.setNufusIlKodu(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "NUFUS_IL_KODU"), hesapAcmaTx.getNufusIlKodu()));
            hesapAcmaTx.setNufusIlceKodu(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "ILCE_KODU"), hesapAcmaTx.getNufusIlceKodu()));
            hesapAcmaTx.setNufusVerilisTarihi(StringUtils.isBlank(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "VERILIS_TARIHI")) ? null : nvl(
                dateFormat.parse(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "VERILIS_TARIHI")), hesapAcmaTx.getNufusVerilisTarihi()));
            hesapAcmaTx.setNufusVerildigiYer(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "VERILDIGI_YER"), hesapAcmaTx.getNufusVerildigiYer()));
            hesapAcmaTx.setNufusVerilisNedeni(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0,"NUF_VERILIS_NEDENI"), hesapAcmaTx.getNufusVerilisNedeni()));
            hesapAcmaTx.setNufusMahalle(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "MAHALLE_KOY"), hesapAcmaTx.getNufusMahalle()));
            hesapAcmaTx.setNufusCiltNo(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "CILT_NO"), hesapAcmaTx.getNufusCiltNo()));
            hesapAcmaTx.setNufusAileSiraNo(nvl(iMap.getString("KPS_KIMLIK_BILGILERI", 0, "AILE_SIRA_NO"), hesapAcmaTx.getNufusAileSiraNo()));
            hesapAcmaTx.setNufusBireyNo(nvl(iMap.getString("KPS_KIMLIK_BILGILERI",0, "SIRA_NO"), hesapAcmaTx.getNufusBireyNo()));
            hesapAcmaTx.setPttIslemNo(nvl(iMap.getBigDecimal("PTT_ISLEM_BILGILERI",0, "PTT_ISLEM_NO"), hesapAcmaTx.getPttIslemNo()));
            hesapAcmaTx.setIsleminYapildigiBasmudurluk(nvl(iMap.getString("PTT_ISLEM_BILGILERI",0, "ISLEMIN_YAPILDIGI_BASMUDURLUK"), hesapAcmaTx.getIsleminYapildigiBasmudurluk()));
            hesapAcmaTx.setIsleminYapildigiIl(nvl(iMap.getString("PTT_ISLEM_BILGILERI",0, "ISLEMIN_YAPILDIGI_IL"), hesapAcmaTx.getIsleminYapildigiIl()));
            hesapAcmaTx.setIsleminYapildigiMerkez(nvl(iMap.getString("PTT_ISLEM_BILGILERI",0, "ISLEMIN_YAPILDIGI_MERKEZ"), hesapAcmaTx.getIsleminYapildigiMerkez()));
            hesapAcmaTx.setIsleminYapildigiSube(nvl(iMap.getString("PTT_ISLEM_BILGILERI",0, "ISLEMIN_YAPILDIGI_SUBE"), hesapAcmaTx.getIsleminYapildigiSube()));
            hesapAcmaTx.setIsleminYapildigiYer(nvl(iMap.getString("PTT_ISLEM_BILGILERI",0, "ISLEMIN_YAPILDIGI_YER"), hesapAcmaTx.getIsleminYapildigiYer()));
            hesapAcmaTx.setMerkezSubeBasmudurluk(nvl(iMap.getString("PTT_ISLEM_BILGILERI",0, "MERKEZ_SUBE_BASMUDURLUK"), hesapAcmaTx.getMerkezSubeBasmudurluk()));
            hesapAcmaTx.setIslemiYapanSicil(nvl(iMap.getString("PTT_ISLEM_BILGILERI",0, "ISLEMI_YAPAN_SICIL"), hesapAcmaTx.getIslemiYapanSicil()));
            hesapAcmaTx.setIslemiYapanKullanici(nvl(iMap.getString("PTT_ISLEM_BILGILERI",0, "ISLEMI_YAPAN_KULLANICI"), hesapAcmaTx.getIslemiYapanKullanici()));
            hesapAcmaTx.setIsleminYapildigiMerkezId(nvl(iMap.getString("PTT_ISLEM_BILGILERI",0, "ISLEMIN_YAPILDIGI_MERKEZ_ID"), hesapAcmaTx.getIsleminYapildigiMerkezId()));
            hesapAcmaTx.setIsleminYapildigiSubeId(nvl(iMap.getString("PTT_ISLEM_BILGILERI",0, "ISLEMIN_YAPILDIGI_SUBE_ID"), hesapAcmaTx.getIsleminYapildigiSubeId()));
            hesapAcmaTx.setIptalinYapildigiYer(nvl(iMap.getString("PTT_ISLEM_BILGILERI",0, "IPTALIN_YAPILDIGI_YER"), hesapAcmaTx.getIptalinYapildigiYer()));
            hesapAcmaTx.setPttIptaliYapanKullanici(nvl(iMap.getString("PTT_ISLEM_BILGILERI",0, "PTT_IPTALI_YAPAN_KULLANICI"), hesapAcmaTx.getPttIptaliYapanKullanici()));
            BigDecimal masraf = iMap.getBigDecimal("TOPLAM_MASRAF").add(iMap.getBigDecimal("TOPLAM_BSMV"));
            hesapAcmaTx.setMasraf(nvl(masraf, BigDecimal.ZERO));
            hesapAcmaTx.setMasrafDovizKodu("TRY");

            session.saveOrUpdate(hesapAcmaTx);

            session.flush();

            iMap.put("TRX_NAME", "2059");
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } 

    }
    public static <T> T nvl(T object, T defaultValue) {
        return object==null ? defaultValue : object;
    }
    
    @GraymoundService("BNSPR_TRN2059_UPDATE_EUPT_HESAP_NO")
    public static GMMap trn2059UpdateEuptHesapNO(GMMap iMap){
        Connection conn = null;
        CallableStatement stmt = null;
        try {
            GMMap oMap = new GMMap();
    
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_TRN2059.Update_Eupt_Hesap_no(?,?,?)}");  
            
            stmt.setBigDecimal(1,iMap.getBigDecimal("ISLEM_NO"));
            stmt.setBigDecimal(2,iMap.getBigDecimal("EUPT_HESAP_NO"));
            stmt.setBigDecimal(3,iMap.getBigDecimal("PTT_ISLEM_NO"));
            
            stmt.execute();
            
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
    }
}
