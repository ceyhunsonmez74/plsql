package tr.com.calikbank.bnspr.currentaccounts.services;

import java.io.ByteArrayInputStream;
import java.util.Calendar;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;
import tr.com.aktifbank.bnspr.dao.istPttEmekliSorguLog;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsQRY3961Services {
	
	static final String GUNLUK_LIMIT = "G�nl�k limite ula��lmas� sebebiyle listedeki ilk %d tane TCKN i�in maa� hesab� yap�lm��t�r.";
	static final String ISLEM_BASARILI = "��lem tamamland�.";
	
	@GraymoundService("BNSPR_TOPLU_SORGU_LOAD_EXCEL")
	public static GMMap emekliTopluSorgu(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		Workbook workbook = null;
		try {
          
			String tableName = "TOPLU_SORGU_DATALARI";
			
			String maasBilgileri = "MAAS_TABLE";
			
			WorkbookSettings setting = new WorkbookSettings();
            setting.setEncoding("ISO-8859-9");
            workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("DOSYA")) , setting);
            Sheet dataSheet = workbook.getSheet(0);
            
            GMMap tcknMap = new GMMap();
            tcknMap.put("PARAM_REF_TUR", "TOPLU_SORGU");
            
            // IST_PTT_EMEKLI_SORGU_LOG tablosundan o g�nk� record say�s�n� hesapla            
            Date startOfDay = atStartOfDay(new Date());
            Date endOfDay = atEndOfDay(new Date());
            
            
            int preCountOfToday = Integer.valueOf(DALUtil.getResult("SELECT count(*) FROM   bnspr.ist_ptt_emekli_sorgu_log "
            		+ " where PARAM_REF_TUR = 'TOPLU_SORGU' and QUERY_RESULT_STATUS = 'SUCCESS' "
            		+ "and REC_DATE >sysdate-1"));
            
//            int preCountOfToday = ((Integer) session.createCriteria(istPttEmekliSorguLog.class)
//            													 .add(Restrictions.eq("PARAM_REF_TUR", "TOPLU_SORGU"))
//            													 .add(Restrictions.eq("QUERY_RESULT_STATUS", "SUCCESS"))
//            													 .add(Restrictions.between("REC_DATE", startOfDay, endOfDay))
//            													 .uniqueResult()).intValue();
            
            GMMap paramMap = new GMMap();
            paramMap.put("KOD", "TOPLU_SORGU_LIMIT");
    		final int TOPLU_SORGU_LIMIT = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE", paramMap).getInt("DEGER");
            
            int counter = 0;
            boolean fGunluklimit = false;
            int yapilanMiktar = 0;
            
            for (int i = 0; i < dataSheet.getRows() - 1; i++){		
    			//validation, e�er �imdiye kadarki i�lem say�s� limite e�it ya da ge�erse hata ver ve i�lemi durdur           			
    			if (preCountOfToday + i >= TOPLU_SORGU_LIMIT) {
    				fGunluklimit = true;
    				yapilanMiktar = i;
    				break;
    			}  			
            	String tckn =  dataSheet.getCell(0 , i + 1).getContents();
            	
            	if (tckn ==null && tckn.trim().length()==0) {
            		System.out.println("TCKN is null");
            		continue;
            	}
            	
            	tcknMap.put("PARAM_REF_TUR", "TOPLU_SORGU");
            	tcknMap.put("PARAM_REF_ID", tckn);
            	tcknMap.put("TCKN", tckn);
            	
            	GMMap maasOdemeBilgileriMap = GMServiceExecuter.call("BNSPR_EXT_PTT_EMEKLI_ODEME_SORGULA" , tcknMap);
            	if (maasOdemeBilgileriMap != null) {
            		for (int j = 0; j < maasOdemeBilgileriMap.getSize("MAAS_TABLE"); j++) {

            			oMap.put(tableName, counter, "ACIKLAMA", maasOdemeBilgileriMap.getString(maasBilgileri, j, "ACIKLAMA"));
            			oMap.put(tableName, counter, "KIMLIK_NO", maasOdemeBilgileriMap.getString(maasBilgileri, j, "KIMLIK_NO"));
            			oMap.put(tableName, counter, "KURUM_AD", maasOdemeBilgileriMap.getString(maasBilgileri, j, "KURUM_AD"));
            			oMap.put(tableName, counter, "KURUM_DONEM", maasOdemeBilgileriMap.getInt(maasBilgileri, j, "KURUM_DONEM"));
            			oMap.put(tableName, counter, "KURUM_KOD", maasOdemeBilgileriMap.getInt(maasBilgileri, j, "KURUM_KOD"));
            			oMap.put(tableName, counter, "MAAS_HAREKET_TARIHI", maasOdemeBilgileriMap.getInt(maasBilgileri, j, "MAAS_HAREKET_TARIHI"));
            			oMap.put(tableName, counter, "MAAS_TUTAR", maasOdemeBilgileriMap.getBigDecimal(maasBilgileri, j, "MAAS_TUTAR"));
            			oMap.put(tableName, counter, "MAAS_YER", maasOdemeBilgileriMap.getString(maasBilgileri, j, "MAAS_YER"));
            			oMap.put(tableName, counter, "ODEME_BASLANGIC_TARIHI", maasOdemeBilgileriMap.getInt(maasBilgileri, j, "ODEME_BASLANGIC_TARIHI"));
            			oMap.put(tableName, counter, "ODEME_DONEM", maasOdemeBilgileriMap.getInt(maasBilgileri, j, "ODEME_DONEM"));
            			oMap.put(tableName, counter, "TAHSIS_NO", maasOdemeBilgileriMap.getString(maasBilgileri, j, "TAHSIS_NO"));
            			counter++;
            		}
            	}
            }
            
            String mesaj = "";
            
            if (fGunluklimit) {
            	mesaj = String.format(GUNLUK_LIMIT, yapilanMiktar);
            } else {
            	mesaj = ISLEM_BASARILI;
            }
            
            oMap.put("MESSAGE", mesaj);

			return oMap;
			
			}	  catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	public static Date atEndOfDay(Date date) {
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
	    calendar.set(Calendar.HOUR_OF_DAY, 23);
	    calendar.set(Calendar.MINUTE, 59);
	    calendar.set(Calendar.SECOND, 59);
	    calendar.set(Calendar.MILLISECOND, 999);
	    return calendar.getTime();
	}

	public static Date atStartOfDay(Date date) {
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
	    calendar.set(Calendar.HOUR_OF_DAY, 0);
	    calendar.set(Calendar.MINUTE, 0);
	    calendar.set(Calendar.SECOND, 0);
	    calendar.set(Calendar.MILLISECOND, 0);
	    return calendar.getTime();
	}

}
