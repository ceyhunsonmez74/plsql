package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.sql.ResultSet;
import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.hibernate.exception.GenericJDBCException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ClksBasvuruDokumanPr;
import tr.com.calikbank.bnspr.dao.ClksBasvuruDokumanPrId;
import tr.com.aktifbank.bnspr.dao.VMlGnlAciklamaPr;
import tr.com.aktifbank.bnspr.dao.VMlGnlAciklamaPrId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap; 
import java.util.List;

public class CurrentAccountsPAR2076Services {

	@GraymoundService("BNSPR_PAR2076_SAVE")
	public static GMMap save(GMMap iMap) {
		Connection conn 		= null;
		try
		{
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");

			String tableName = "DEKONT_ACIKLAMA_TABLE";
			List<?> dekontAciklamaList = (List<?>) iMap.get(tableName);

			if(dekontAciklamaList != null){
				for (int i = 0; i < dekontAciklamaList.size(); i++) {
					if(iMap.getBigDecimal(tableName, i, "ACK_NO") == null)
					{
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "A��klama No");
						return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}
					
					/*if(iMap.getString(tableName, i, "ACIKLAMA") == null|| iMap.getString(tableName, i, "ACIKLAMA").length() ==0)
					{
						iMap.put("HATA_NO", new BigDecimal(330));
						iMap.put("P1", "A��klama");
						return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
					}*/
					 for(int j=i+1;j<dekontAciklamaList.size();j++){
						 if(iMap.getBigDecimal(tableName, j, "ACK_NO") == null)
							{
								iMap.put("HATA_NO", new BigDecimal(330));
								iMap.put("P1", "A��klama No");
								return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
							}
							
							/*if(iMap.getString(tableName, j, "ACIKLAMA") == null|| iMap.getString(tableName, j, "ACIKLAMA").length() ==0)
							{
								iMap.put("HATA_NO", new BigDecimal(330));
								iMap.put("P1", "A��klama");
								return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
							}*/
							int l=0;
				            
							l = iMap.getBigDecimal(tableName, j, "ACK_NO").compareTo(iMap.getBigDecimal(tableName, i, "ACK_NO") );
							  if ( l==0){	
								iMap.put("HATA_NO", new BigDecimal(2145));
								iMap.put("P1", i+1);
								iMap.put("P2", j+1);
								GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);	
							  }
					 }
					VMlGnlAciklamaPr vMlGnlAciklamaPr = new VMlGnlAciklamaPr();
					VMlGnlAciklamaPrId id = new VMlGnlAciklamaPrId();
					id.setAckNo(iMap.getBigDecimal(tableName, i, "ACK_NO"));	
					id.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
					id.setTip(iMap.getString(tableName,i,"TIP"));
					vMlGnlAciklamaPr.setId(id);
								    
					session.saveOrUpdate(vMlGnlAciklamaPr);
				}
			}
			session.flush();
			GMMap oMap = new GMMap();
			iMap.put("MESSAGE_NO", new BigDecimal(711));
			oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE"));
			
		
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_PAR2076_GET_LIST")
	public static GMMap getList(GMMap iMap){
		Connection conn 		= null;
		CallableStatement stmt = null;
		ResultSet rSet=null;
		String tableName="DEKONT_ACIKLAMA_TABLE";
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_RC2076.RC_PAR2076_GET_LIST}");
			stmt.registerOutParameter(1, -10);
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			int row=0;
            while(rSet.next()){
			oMap.put(tableName, row, "ACK_NO", rSet.getBigDecimal("ACK_NO"));
			oMap.put(tableName, row, "ACIKLAMA", rSet.getString("ACIKLAMA"));
			oMap.put(tableName, row, "TIP", rSet.getString("TIP"));
			oMap.put(tableName, row, "YENI", "1");
			row++;
            }
         
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
		}
	}
}
