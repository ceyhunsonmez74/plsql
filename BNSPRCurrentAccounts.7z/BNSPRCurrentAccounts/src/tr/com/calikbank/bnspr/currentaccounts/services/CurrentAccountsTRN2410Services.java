package tr.com.calikbank.bnspr.currentaccounts.services;

import java.awt.Color;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlMusteriVipTx;
import tr.com.aktifbank.bnspr.dao.GnlMusteriVipTxId;
import tr.com.aktifbank.bnspr.dao.SwftMt941HesapTanimTx;
import tr.com.aktifbank.bnspr.dao.SwftMt941HesapTanimTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class CurrentAccountsTRN2410Services { 
    
    @GraymoundService("BNSPR_TRN2410_GET_RECORDS")
    public static GMMap getRecords(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        String tableName = "TBL_VIP_MUSTERI";
     
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_TRN2410.get_records}");
            stmt.registerOutParameter(1 , -10); // ref cursor
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            int row = 0;
            while (rSet.next()) {
                oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
                oMap.put(tableName , row , "MUSTERI_NO" , rSet.getBigDecimal("MUSTERI_NO"));
                oMap.put(tableName,  row , "UNVAN"      , rSet.getString("UNVAN"));
                row++;
               }
          
            return oMap;
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(conn);
        }
        
    }

    @GraymoundService("BNSPR_TRN2410_SAVE")
    public static Map<?, ?> save(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            String tableName = "TBL_VIP_MUSTERI";
            
            List<?> recordList = (List<?>) iMap.get(tableName);
            
            for (int row = 0; row < recordList.size(); row++){
                
               GnlMusteriVipTxId id = new GnlMusteriVipTxId();
            
                id.setTxNo(iMap.getBigDecimal("TRX_NO"));
                id.setMusteriNo(iMap.getBigDecimal(tableName, row, "MUSTERI_NO"));
             
                GnlMusteriVipTx gnlMusteriVipTx = (GnlMusteriVipTx) session.get(GnlMusteriVipTx.class , id);
                if (gnlMusteriVipTx == null){
                	gnlMusteriVipTx = new GnlMusteriVipTx();
                }
                gnlMusteriVipTx.setId(id);
                
                gnlMusteriVipTx.setGS(iMap.getString(tableName, row, "G_S"));
               
                session.saveOrUpdate(gnlMusteriVipTx);
            }
            session.flush();
            iMap.put("TRX_NAME" , "2410");
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN2410_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try{
            // Get Master
            String tableName = "TBL_VIP_MUSTERI";
            Session session = DAOSession.getSession("BNSPRDal");
            Criteria criteria = session.createCriteria(GnlMusteriVipTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO")));
            
            List<?> recordList = (List<?>) criteria.list();
            
            for (int row = 0; row < recordList.size(); row++){
            	GnlMusteriVipTx gnlMusteriVipTx = (GnlMusteriVipTx) recordList.get(row);
                oMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
                oMap.put(tableName , row , "MUSTERI_NO" ,gnlMusteriVipTx.getId().getMusteriNo() );
                oMap.put(tableName, row, "UNVAN",  LovHelper.diLov(gnlMusteriVipTx.getId().getMusteriNo(), "2410/LOV_MUSTERI_NO", "UNVAN"));
                oMap.put(tableName , row , "SIL" , ("S").equals(gnlMusteriVipTx.getGS()) ? true : false);
                oMap.put(tableName, row, "G_S",gnlMusteriVipTx.getGS());
              }
            
            GMMap colorChangedD = new GMMap();
			colorChangedD.put("setBackground", Color.WHITE);
			colorChangedD.put("setForeground", Color.RED);
			
			GMMap colorChangedG = new GMMap();
			colorChangedG.put("setBackground", Color.WHITE);
			colorChangedG.put("setForeground", Color.BLUE);
			
			GMMap colorNotChanged  = new GMMap();
			colorNotChanged.put("setBackground", Color.WHITE);
			colorNotChanged.put("setForeground", Color.BLACK);
			
			GMMap colorCase = new GMMap();
			
			for (int j=0; j<oMap.getSize(tableName);j++)
			{
				if (StringUtils.isBlank(oMap.getString(tableName, j, "G_S"))) {
					colorCase = colorNotChanged;
				}
				else if(oMap.getString(tableName, j, "G_S").equals("D"))
				{
					colorCase = colorChangedD;
				}
				else if(oMap.getString(tableName, j, "G_S").equals("G"))
				{
					colorCase = colorChangedG;
				}
				else
				{
					colorCase = colorNotChanged;
				}
				oMap.put("TABLE_COLOR", j, "MUSTERI_NO", colorCase);
				oMap.put("TABLE_COLOR", j, "UNVAN", colorCase);
				oMap.put("TABLE_COLOR", j, "SIL", colorCase);
		}
			
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
}
