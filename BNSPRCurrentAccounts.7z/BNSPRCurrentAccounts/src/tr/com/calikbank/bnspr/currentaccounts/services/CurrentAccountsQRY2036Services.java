package tr.com.calikbank.bnspr.currentaccounts.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsQRY2036Services {
	@GraymoundService("BNSPR_QRY2036_GET_GELEN_HAVALE_HAREKET")
	public static GMMap getHavaleHareket(GMMap iMap) {
	                                                                  
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			int i =1;
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_current_accounts.RC_QRY2035_GELEN_HAVALE_HRKT(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor

			stmt.setString(i++, iMap.getString("SUBE_KODU"));
			stmt.setString(i++, iMap.getString("HAVALE_TIPI"));
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			
			/*if (iMap.getBigDecimal("MIN_TUTAR").toString().equals("0.00")) {
				stmt.setBigDecimal(4, null);*/
				stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_TUTAR"));
			//}

			/*if (iMap.getBigDecimal("MAX_TUTAR").toString().equals("0.00")) {
				stmt.setBigDecimal(5, null);
			} else {*/
				stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_TUTAR"));
			//}
			
			if ((iMap.get("BAS_TARIH") != null)) {
				java.util.Date bas_date = (java.util.Date) iMap
						.get("BAS_TARIH");
				stmt.setDate(i++, new java.sql.Date(bas_date.getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			
			
			if ((iMap.get("SON_TARIH") != null)) {
				java.util.Date son_date = (java.util.Date) iMap
						.get("SON_TARIH");
				stmt.setDate(i++, new java.sql.Date(son_date.getTime()));
			} else {
				stmt.setDate(i++, null);
			}

			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			stmt.setString(i++, iMap.getString("ALICI_MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("GONDEREN_MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("GONDERIM_AMACI"));
			stmt.setString(i++, iMap.getString("KANAL"));
			stmt.setString(i++, iMap.getString("GONDEREN_MUSTERI_ADI"));
			stmt.setString(i++, iMap.getString("ALICI_MUSTERI_ADI"));
			stmt.setString(i++, iMap.getString("REFERANS"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			String tableName = "CBS_HAVALE_LISTE";
			int j = 0;
			while (rSet.next()) {
				oMap.put(tableName, j, "REFERANS", rSet.getString("referans"));
				oMap.put(tableName, j, "DOVIZ_KODU", rSet.getString("doviz_kodu"));
				oMap.put(tableName, j, "TUTAR", rSet.getString("tutar"));
				oMap.put(tableName, j, "GONDEREN_MUSTERI_NO", rSet.getString("gonderen_musteri_no"));
				oMap.put(tableName, j, "GONDEREN_ISIM_UNVAN", rSet.getString("gonderen_isim_unvan"));
				oMap.put(tableName, j, "ALICI_MUSTERI_NO", rSet.getString("alici_musteri_no"));
				oMap.put(tableName, j, "ALICI_ISIM_UNVAN", rSet.getString("alici_isim_unvan"));
				oMap.put(tableName, j, "DURUM", rSet.getString("durum_kodu"));
				oMap.put(tableName, j, "KANAL", rSet.getString("kanal"));
				oMap.put(tableName, j, "HAVALE_TARIHI", rSet.getDate("havale_tarihi"));
				j++;
			}

			return oMap;
			
	
	      } catch (SQLException e) {
	            throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet);
		}
	}
	
@GraymoundService("BNSPR_TRN2036_GET_KANAL_KODLARI")
	public static GMMap getKanalKodlari(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "KANAL_KODLARI");
		iMap.put("LIST_QUERY", "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr order by 1");
		DALUtil.fillComboBox(iMap);
		return iMap;
	}

}

/* package tr.com.calikbank.bnspr.currentaccounts.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsQRY2036Services {
	@GraymoundService("BNSPR_QRY2036_GET_GELEN_HAVALE_HAREKET")
	public static GMMap getHavaleHareket(GMMap iMap) {
	                                                                  
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = GMServerDatasource.getConnection("java:/GraymoundDS");

			StringBuilder query = new StringBuilder();

			query.append("select a.referans, a.doviz_kodu, a.tutar, a.gonderen_musteri_no, a.gonderen_isim_unvan, a.alici_musteri_no,");
			query.append("a.alici_isim_unvan, a.durum_kodu ");
			query.append("from Cari_Subelerarasi_Hav_Giris a ");
			query.append("where a.alici_sube = NVL(?,alici_sube) ");
			query.append("and a.urun_tur = NVL(?,urun_tur) ");//havale_tipi
			query.append("and a.doviz_kodu = NVL(?,doviz_kodu) ");
			query.append("and a.tutar between NVL(?,tutar) and NVL(?,tutar) ");
			query.append("and trunc(a.havale_tarihi) between NVL(?,trunc(havale_tarihi)) and NVL(?,trunc(havale_tarihi))");
			query.append("and a.durum_kodu = NVL(?,durum_kodu) ");
			query.append("and a.alici_musteri_no = NVL(?,alici_musteri_no) ");
			query.append("and a.gonderen_musteri_no = NVL(?,gonderen_musteri_no) ");
			query.append("and a.gonderim_amaci = NVL(?,gonderim_amaci) ");
			

			stmt = conn.prepareCall(query.toString());

			stmt.setString(1, iMap.getString("SUBE_KODU"));
			stmt.setString(2, iMap.getString("HAVALE_TIPI"));
			stmt.setString(3, iMap.getString("DOVIZ_KODU"));
			
			if (iMap.getBigDecimal("MIN_TUTAR").toString().equals("0.00")) {
				stmt.setBigDecimal(4, null);
			} else {
				stmt.setBigDecimal(4, iMap.getBigDecimal("MIN_TUTAR"));
			}

			if (iMap.getBigDecimal("MAX_TUTAR").toString().equals("0.00")) {
				stmt.setBigDecimal(5, null);
			} else {
				stmt.setBigDecimal(5, iMap.getBigDecimal("MAX_TUTAR"));
			}
			
			if ((iMap.get("BAS_TARIH") != null)) {
				java.util.Date bas_date = (java.util.Date) iMap
						.get("BAS_TARIH");
				stmt.setDate(6, new java.sql.Date(bas_date.getTime()));
			} else {
				stmt.setDate(6, null);
			}

			if ((iMap.get("SON_TARIH") != null)) {
				java.util.Date son_date = (java.util.Date) iMap
						.get("SON_TARIH");
				stmt.setDate(7, new java.sql.Date(son_date.getTime()));
			} else {
				stmt.setDate(7, null);
			}

			stmt.setString(8, iMap.getString("DURUM_KODU"));
			stmt.setString(9, iMap.getString("ALICI_MUSTERI_NO"));
			stmt.setString(10, iMap.getString("GONDEREN_MUSTERI_NO"));
			stmt.setString(11, iMap.getString("GONDERIM_AMACI"));
			rSet = stmt.executeQuery();
			GMMap oMap = new GMMap();
			String tableName = "CBS_HAVALE_LISTE";
			int i = 0;
			while (rSet.next()) {
				oMap.put(tableName, i, "REFERANS", rSet.getString("referans"));
				oMap.put(tableName, i, "DOVIZ_KODU", rSet.getString("doviz_kodu"));
				oMap.put(tableName, i, "TUTAR", rSet.getString("tutar"));
				oMap.put(tableName, i, "GONDEREN_MUSTERI_NO", rSet.getString("gonderen_musteri_no"));
				oMap.put(tableName, i, "GONDEREN_ISIM_UNVAN", rSet.getString("gonderen_isim_unvan"));
				oMap.put(tableName, i, "ALICI_MUSTERI_NO", rSet.getString("alici_musteri_no"));
				oMap.put(tableName, i, "ALICI_ISIM_UNVAN", rSet.getString("alici_isim_unvan"));
				oMap.put(tableName, i, "DURUM", rSet.getString("durum_kodu"));
			}

			return oMap;

		} catch (SQLException e) {
			throw new GMRuntimeException(1, e);
		} finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(rSet);
		}
	}
}
*/