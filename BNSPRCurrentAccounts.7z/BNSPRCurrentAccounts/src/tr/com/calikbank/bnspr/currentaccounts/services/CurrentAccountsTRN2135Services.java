package tr.com.calikbank.bnspr.currentaccounts.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import jxl.Sheet;
import jxl.Workbook;
import tr.com.aktifbank.bnspr.dao.MuhBlokeTopluTx;
import tr.com.aktifbank.bnspr.dao.MuhBlokeTopluTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsTRN2135Services {

	private static SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
	private static String PROCESS_TYPE_SET_BLOKE = "K";
	private static String PROCESS_TYPE_SOLVE_BLOKE = "C";
	private static String HATA_ACIKLAMA = "HATA_ACIKLAMA";
	private static String HATA_KODU = "HATA_KODU";
	private static String H0 = "H0";
	private static String F = "F";
	private static String T = "T";
	private static BigDecimal H1 = new BigDecimal(5598);
	private static BigDecimal H2 = new BigDecimal(5599);
	private static BigDecimal H3 = new BigDecimal(5600);
	private static BigDecimal H4 = new BigDecimal(5604);
	private static BigDecimal H5 = new BigDecimal(5601);
	private static BigDecimal H6 = new BigDecimal(5602);
	private static BigDecimal H7 = new BigDecimal(5596);
	private static BigDecimal H8 = new BigDecimal(5603);

	public static void validateExcelFormat(Sheet sheet, String processType) {
		int i = 0;
		if (processType.equals(PROCESS_TYPE_SET_BLOKE)) {
			if (!"HESAP_NO".equals(sheet.getCell(0, i).getContents().trim()))
				throw new GMRuntimeException(H4.intValue(), getErrorText(H4));

			if (!"TUTAR".equals(sheet.getCell(1, i).getContents().trim()))
				throw new GMRuntimeException(H4.intValue(), getErrorText(H4));

			if (!"BLOKE_BITIS_TARIHI".equals(sheet.getCell(2, i).getContents().trim()))
				throw new GMRuntimeException(H4.intValue(), getErrorText(H4));

			if (!"ACIKLAMA".equals(sheet.getCell(3, i).getContents().trim()))
				throw new GMRuntimeException(H4.intValue(), getErrorText(H4));
		}
		else if (processType.equals(PROCESS_TYPE_SOLVE_BLOKE)) {

			if (!"BLOKE_REF_NO".equals(sheet.getCell(i, i).getContents().trim()))
				throw new GMRuntimeException(H4.intValue(), getErrorText(H4));
		}

	}

	public static boolean isNotExistAndNull(GMMap iMap, String key) {

		if (iMap.containsKey(key) && iMap.get(key) != null && iMap.get(key).toString().length() > 0) {
			return true;
		}
		else {
			return false;
		}

	}

	public static String getErrorText(BigDecimal errorCode) {
		GMMap errorIMap = new GMMap();
		String errorDescription;

		errorIMap.put("MESSAGE_NO", errorCode);
		errorDescription = GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", errorIMap).getString("ERROR_MESSAGE");

		return errorDescription;

	}

	private static void checkRequest(GMMap iMap) {

		String tableName = "TBL_BLOKE";
		boolean isSelected = false;
		int rowCount = iMap.getSize(tableName);

		if (iMap.getString("BLOKE_DURUM_KODU").equals(PROCESS_TYPE_SET_BLOKE)) {
			if (!isNotExistAndNull(iMap, "BLOKE_NEDEN_KODU")) {
				throw new GMRuntimeException(H8.intValue(), getErrorText(H8));

			}
		}

		if (rowCount == 0) {
			throw new GMRuntimeException(H6.intValue(), getErrorText(H6));
		}
		else if (rowCount > 0) {
			for (int i = 0; i < rowCount; i++) {
				if (iMap.getBoolean(tableName, i, "EKLE")) {
					isSelected = true;
					break;
				}
			}

			if (!isSelected)
				throw new GMRuntimeException(H6.intValue(), getErrorText(H6));

		}
	}

	public static Date toDateFormat(String dateInString) {
		Date date = null;
		try {
			if (!StringUtils.isBlank(dateInString)) {
				date = formatter.parse(dateInString.replace('.', '/'));
			}

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return date;

	}

	public static GMMap getCustomerByAccount(BigDecimal accountNo) {
		GMMap oMap = new GMMap();
		CallableStatement stmt = null;
		String call = "{call PKG_TRN2135.getCustomerByAccountNo(?,?,?)}";
		Connection conn = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(call);
			stmt.setBigDecimal(1, accountNo);
			stmt.registerOutParameter(2, Types.DECIMAL);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.execute();

			oMap.put("CUSTOMER_NO", stmt.getBigDecimal(2));
			oMap.put("TITLE", stmt.getString(3));

		}
		catch (SQLException e) {

			e.printStackTrace();
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return oMap;
	}

	public static String checkAccount(BigDecimal customerNo, BigDecimal accountNo) {
		CallableStatement stmt = null;
		String call = "{call PKG_TRN2135.checkAccount(?,?,?)}";
		Connection conn = null;
		String result = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(call);
			stmt.setBigDecimal(1, customerNo);
			stmt.setBigDecimal(2, accountNo);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.execute();

			result = stmt.getString(3);

		}
		catch (SQLException e) {

			e.printStackTrace();
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return result;

	}

	public static String checkBlokeRefNo(String blokeRefNo) {
		CallableStatement stmt = null;
		String call = "{call PKG_TRN2135.checkBlokeRefNo(?,?)}";
		Connection conn = null;
		String result = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(call);
			stmt.setString(1, blokeRefNo);
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.execute();
			result = stmt.getString(2);

		}
		catch (SQLException e) {

			e.printStackTrace();
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

		return result;

	}

	public static BigDecimal getBlokeRefNo() {
		Connection conn = null;
		CallableStatement stmt = null;
		BigDecimal blokeRefNo = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call SEQ_Bloke_Internal_Refno.Nextval}");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.execute();
			blokeRefNo = stmt.getBigDecimal(1);

		}
		catch (SQLException e) {

			e.printStackTrace();
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return blokeRefNo;

	}

	public static Date getBankDate() {
		Connection conn = null;
		Date bankaTarihi = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_MUHASEBE.BANKA_TARIHI_BUL()}");
			stmt.registerOutParameter(1, Types.DATE);
			stmt.execute();
			bankaTarihi = stmt.getDate(1);
		}
		catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return bankaTarihi;

	}

	@GraymoundService("BNSPR_TRN2135_LOAD_EXCEL")
	public static GMMap getBlokeDetayFromExcell(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap oMapCustomer = new GMMap();
		BigDecimal accountNo = null;
		BigDecimal blokeTutar = null;
		String blokeAciklama = null;
		String blokeRefNo = null;
		Sheet sheet;
		Workbook workbook;
		try {
			try {
				workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("DOSYA")));
				sheet = workbook.getSheet(0);

				validateExcelFormat(sheet, iMap.getString("PROCESS_TYPE"));
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);

			}

			String tableName = "TBL_BLOKE";
			int tableRow = 0;
			for (int excelRow = 1; excelRow < sheet.getRows(); excelRow++, tableRow++) {
				int excelCol = 0;

				if (iMap.getString("PROCESS_TYPE").equals(PROCESS_TYPE_SET_BLOKE)) {

					if (StringUtils.isBlank(sheet.getCell(excelCol, excelRow).getContents()))
						throw new GMRuntimeException(H7.intValue(), "Hesap No: " + getErrorText(H7));
					else
						accountNo = new BigDecimal(sheet.getCell(excelCol++, excelRow).getContents().trim());

					if (StringUtils.isBlank(sheet.getCell(excelCol, excelRow).getContents())) {
						throw new GMRuntimeException(H5.intValue(), "Bloke Tutar: " + getErrorText(H5));
					}
					else {
						blokeTutar = new BigDecimal(sheet.getCell(excelCol++, excelRow).getContents().trim());
						if (blokeTutar.compareTo(BigDecimal.ZERO) < 1)
							throw new GMRuntimeException(H5.intValue(), "Bloke Tutar: " + getErrorText(H5));
					}

					oMap.put(tableName, tableRow, "BLOKE_BITIS_TARIHI", toDateFormat(sheet.getCell(excelCol++, excelRow).getContents()));

					if (StringUtils.isBlank(sheet.getCell(excelCol, excelRow).getContents())) {
						throw new GMRuntimeException(H7.intValue(), "Bloke Aciklama: " + getErrorText(H7));
					}
					else {
						blokeAciklama = StringUtils.substring(sheet.getCell(excelCol++, excelRow).getContents().trim(), 0, 150);
					}

					oMapCustomer = getCustomerByAccount(accountNo);
					if (oMapCustomer.getBigDecimal("CUSTOMER_NO") == null) {
						oMap.put(tableName, tableRow, HATA_ACIKLAMA, getErrorText(H1));
						oMap.put(tableName, tableRow, HATA_KODU, "H1");
						oMap.put(tableName, tableRow, "EKLE", false);
					}
					else {
						oMap.put(tableName, tableRow, "MUSTERI_NO", oMapCustomer.getBigDecimal("CUSTOMER_NO"));
						oMap.put(tableName, tableRow, "UNVAN", oMapCustomer.getString("TITLE"));

						if (F.equals(checkAccount(oMapCustomer.getBigDecimal("CUSTOMER_NO"), accountNo))) {
							oMap.put(tableName, tableRow, HATA_ACIKLAMA, getErrorText(H2));
							oMap.put(tableName, tableRow, HATA_KODU, "H2");
							oMap.put(tableName, tableRow, "EKLE", false);
						}
						else {
							oMap.put(tableName, tableRow, HATA_KODU, H0);
							oMap.put(tableName, tableRow, "EKLE", true);
						}

					}

					oMap.put(tableName, tableRow, "ACIKLAMA", blokeAciklama);
					oMap.put(tableName, tableRow, "HESAP_NO", accountNo);
					oMap.put(tableName, tableRow, "BLOKE_TUTARI", blokeTutar);

				}
				else if (iMap.getString("PROCESS_TYPE").equals(PROCESS_TYPE_SOLVE_BLOKE)) {

					if (StringUtils.isBlank(sheet.getCell(excelCol, excelRow).getContents())) {
						throw new GMRuntimeException(H7.intValue(), "Bloke Referans No: " + getErrorText(H7));
					}
					else {
						blokeRefNo = sheet.getCell(excelCol++, excelRow).getContents().trim();

						if (F.equals(checkBlokeRefNo(blokeRefNo))) {
							oMap.put(tableName, tableRow, HATA_KODU, "H3");
							oMap.put(tableName, tableRow, HATA_ACIKLAMA, getErrorText(H3));
							oMap.put(tableName, tableRow, "EKLE", false);
						}
						else {
							oMap.put(tableName, tableRow, HATA_KODU, H0);
							oMap.put(tableName, tableRow, "EKLE", true);
						}
					}

					oMap.put(tableName, tableRow, "BLOKE_REF_NO", blokeRefNo);
				}

			}
			workbook.close();

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);

		}
	}

	@GraymoundService("BNSPR_TRN2135_SAVE")
	public static GMMap save(GMMap iMap) {
		try {
			String tableName = "TBL_BLOKE";
			Session session = DAOSession.getSession("BNSPRDal");
			checkRequest(iMap);
			int size = iMap.getSize(tableName);
			for (int i = 0; i < size; i++) {
				if (iMap.getBoolean(tableName, i, "EKLE") == true) {
					MuhBlokeTopluTx muhTopluBlokeTx = new MuhBlokeTopluTx();
					MuhBlokeTopluTxId muhBlokeTopluTxId = new MuhBlokeTopluTxId();
					muhBlokeTopluTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
					muhBlokeTopluTxId.setInternalRefNo(getBlokeRefNo());

					if (iMap.getString("BLOKE_DURUM_KODU").equals(PROCESS_TYPE_SET_BLOKE)) {
						muhTopluBlokeTx.setMusteriNo(iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
						muhTopluBlokeTx.setUnvan(iMap.getString(tableName, i, "UNVAN"));
						muhTopluBlokeTx.setHesapNo(iMap.getBigDecimal(tableName, i, "HESAP_NO"));
						muhTopluBlokeTx.setBlokeAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
						muhTopluBlokeTx.setBlokeTutari(iMap.getBigDecimal(tableName, i, "BLOKE_TUTARI"));
						muhTopluBlokeTx.setBlokeBitisTarihi(iMap.getDate(tableName, i, "BLOKE_BITIS_TARIHI"));
					}
					else if (iMap.getString("BLOKE_DURUM_KODU").equals(PROCESS_TYPE_SOLVE_BLOKE)) {
						muhTopluBlokeTx.setBlokeReferansNo(iMap.getString(tableName, i, "BLOKE_REF_NO"));
					}

					muhTopluBlokeTx.setBlokeDurumKod(iMap.getString("BLOKE_DURUM_KODU"));
					muhTopluBlokeTx.setBlokeNedenKodu(iMap.getString("BLOKE_NEDEN_KODU"));
					muhTopluBlokeTx.setBlokeTarihi(getBankDate());
					if (H0.equals(iMap.getString(tableName, i, "HATA_KODU"))) {
						muhTopluBlokeTx.setHataDurum(F);

					}
					else {
						muhTopluBlokeTx.setHataDurum(T);
						muhTopluBlokeTx.setHataAcklama(iMap.getString(tableName, i, "HATA_ACIKLAMA"));
					}

					muhTopluBlokeTx.setId(muhBlokeTopluTxId);
					session.saveOrUpdate(muhTopluBlokeTx);
					session.flush();
				}
			}
			iMap.put("TRX_NAME", "2135");
			GMMap oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN2135_GET_INFO")
	public static Map<?, ?> getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> recordList = (List<?>) session.createCriteria(MuhBlokeTopluTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("hataDurum", "F")).list();

			MuhBlokeTopluTx muhBlokeTopluTx = null;
			String tableName = "TBL_BLOKE";
			for (int i = 0; i < recordList.size(); i++) {
				muhBlokeTopluTx = (MuhBlokeTopluTx) recordList.get(i);
				if (muhBlokeTopluTx.getBlokeDurumKod().equals(PROCESS_TYPE_SET_BLOKE)) {
					oMap.put(tableName, i, "MUSTERI_NO", muhBlokeTopluTx.getMusteriNo());
					oMap.put(tableName, i, "UNVAN", muhBlokeTopluTx.getUnvan());
					oMap.put(tableName, i, "HESAP_NO", muhBlokeTopluTx.getHesapNo());
					oMap.put(tableName, i, "ACIKLAMA", muhBlokeTopluTx.getBlokeAciklama());
					oMap.put(tableName, i, "BLOKE_TUTARI", muhBlokeTopluTx.getBlokeTutari());
					oMap.put(tableName, i, "BLOKE_BITIS_TARIHI", muhBlokeTopluTx.getBlokeBitisTarihi());

				}
				else if (muhBlokeTopluTx.getBlokeDurumKod().equals(PROCESS_TYPE_SOLVE_BLOKE)) {
					oMap.put(tableName, i, "BLOKE_REF_NO", muhBlokeTopluTx.getBlokeReferansNo());
				}

				oMap.put(tableName, i, "EKLE", true);
				oMap.put("BLOKE_DURUM_KODU", muhBlokeTopluTx.getBlokeDurumKod());
				oMap.put("BLOKE_NEDEN_KODU", muhBlokeTopluTx.getBlokeNedenKodu());
				oMap.put("DI_BLOKE_NEDEN_KODU", LovHelper.diLov(muhBlokeTopluTx.getBlokeNedenKodu(), "2135/LOV_BLOKE", "ACIKLAMA"));

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN2135_SELECT_REMOVE_ALL")
	public static GMMap getSelectedList(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			String tableName = "TBL_BLOKE";
			if (iMap.get(tableName) != null) {

				oMap.put(tableName, iMap.get(tableName));
				if (iMap.getBoolean("SELECT_ALL_REMOVE")) {
					for (int i = 0; i < iMap.getSize(tableName); i++) {
						oMap.put(tableName, i, "EKLE", true);
					}
				}
				else {
					for (int i = 0; i < iMap.getSize(tableName); i++) {
						oMap.put(tableName, i, "EKLE", false);
					}
				}

			}

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
