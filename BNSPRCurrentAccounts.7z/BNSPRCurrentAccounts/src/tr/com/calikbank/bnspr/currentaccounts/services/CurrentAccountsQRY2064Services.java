package tr.com.calikbank.bnspr.currentaccounts.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class CurrentAccountsQRY2064Services {

	@GraymoundService("BNSPR_QRY2064_KAYIT_GETIR")
	public static GMMap getPTTMutabakat(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap= new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2064.Mutabakat_Listesi(?,?,?,?) }");
			
			stmt.registerOutParameter(1, -10);
			stmt.setDate(2, new Date(iMap.getDate("TARIH").getTime()));
			stmt.setString(3, StringUtils.isBlank(iMap.getString("ISLEM_TURU"))? "X" : iMap.getString("ISLEM_TURU"));
	        stmt.setString(4, StringUtils.isBlank(iMap.getString("SIRKET_TURU"))? "X" : iMap.getString("SIRKET_TURU"));
			stmt.setString(5, iMap.getBoolean("MUTABAKATSIZ")?"E":"");
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "SIGORTALAR");
			
			stmt= conn.prepareCall("{call PKG_RC2064.Mutabakat_Genel_Bilgi(?,?,?,?,?,?,?,?,?,?,?) }");
			int i=1;
			
			stmt.setDate(i++,  new Date(iMap.getDate("TARIH").getTime()));
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i, Types.NUMERIC);
			stmt.execute();
			
			oMap.put("AKTIF_BORC",stmt.getBigDecimal(i--));
			oMap.put("AKTIF_IPTAL_YATAN_ADET",stmt.getBigDecimal(i--));
			oMap.put("AKTIF_IPTAL_YATAN_TOPLAM",stmt.getBigDecimal(i--));
			oMap.put("AKTIF_YATAN_ADET",stmt.getBigDecimal(i--));
			oMap.put("AKTIF_YATAN_TOPLAM",stmt.getBigDecimal(i--));
			oMap.put("PTT_BORC",stmt.getBigDecimal(i--));
			oMap.put("PTT_IPTAL_YATAN_ADET",stmt.getBigDecimal(i--));
			oMap.put("PTT_IPTAL_YATAN_TOPLAM",stmt.getBigDecimal(i--));
			oMap.put("PTT_YATAN_ADET",stmt.getBigDecimal(i--));
			oMap.put("PTT_YATAN_TOPLAM",stmt.getBigDecimal(i--));
			oMap.put("FARK_YATAN_ADET",oMap.getBigDecimal("AKTIF_YATAN_ADET").subtract(oMap.getBigDecimal("PTT_YATAN_ADET")));
			oMap.put("FARK_YATAN_TOPLAM",oMap.getBigDecimal("AKTIF_YATAN_TOPLAM").subtract(oMap.getBigDecimal("PTT_YATAN_TOPLAM")));
			oMap.put("FARK_IPTAL_YATAN_ADET",oMap.getBigDecimal("AKTIF_IPTAL_YATAN_ADET").subtract(oMap.getBigDecimal("PTT_IPTAL_YATAN_ADET")));
			oMap.put("FARK_IPTAL_YATAN_TOPLAM",oMap.getBigDecimal("AKTIF_IPTAL_YATAN_TOPLAM").subtract(oMap.getBigDecimal("PTT_IPTAL_YATAN_TOPLAM")));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_QRY2064_GET_TOPLAM")
	public static GMMap getPTTMutabakatToplam(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap= new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt= conn.prepareCall("{call PKG_RC2064.Mutabakat_Tur_Bilgi(?,?,?,?,?,?,?) }");
			int i=1;

			stmt.setDate(i++,  new Date(iMap.getDate("TARIH").getTime()));
			stmt.setString(i++ , StringUtils.isBlank(iMap.getString("ISLEM_TURU")) ? "X" : iMap.getString("ISLEM_TURU"));
            stmt.setString(i++ , StringUtils.isBlank(iMap.getString("SIRKET_TURU")) ? "X" : iMap.getString("SIRKET_TURU"));
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.registerOutParameter(i, Types.NUMERIC);

			stmt.execute();
			oMap.put("AKTIF_ADET",stmt.getBigDecimal(i--));
			oMap.put("AKTIF_TOPLAM",stmt.getBigDecimal(i--)); 
			oMap.put("PTT_ADET",stmt.getBigDecimal(i--));
			oMap.put("PTT_TOPLAM",stmt.getBigDecimal(i));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY2064_MUTABAKATSIZ_SORUNLU")
	public static GMMap getPTTMutabakatsizSorunluYap(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap= new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt= conn.prepareCall("{call PKG_RC2064.Mutabakatsiz_SorunluYap(?,?,?) }");
			int i=1;

			stmt.setBigDecimal(i++,  iMap.getBigDecimal("ISLEM_NO"));
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i, Types.VARCHAR);
			stmt.execute();

			oMap.put("DURUM_KODU",stmt.getString(i--));
			oMap.put("ISLEM_TIPI",stmt.getString(i--));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		oMap.put("RESPONSE", 2);
		return oMap;
	}
	
    /**
     * Aktifbank ve EBS'de yap�lm�� sigorta i�lemleri listesini d�ner.
     * 
     * @param iMap TARIH
     * @return oMap SIGORTALAR
     * @author Omer Yusufoglu
     * @since 31.10.2014
     */
    @GraymoundService("BNSPR_QRY2064_EBS_AB_KAYIT_GETIR")
    public static GMMap getEbsAbMutabakat(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call PKG_RC2064.AB_EBS_Islem_Getir(?,?,?,?) }");
            
            stmt.registerOutParameter(1 , -10);
            stmt.setDate(2 , new Date(iMap.getDate("TARIH").getTime()));
            stmt.setString(3 , StringUtils.isBlank(iMap.getString("ISLEM_TURU")) ? "X" : iMap.getString("ISLEM_TURU"));
            stmt.setString(4 , StringUtils.isBlank(iMap.getString("SIRKET_TURU")) ? "X" : iMap.getString("SIRKET_TURU"));
            stmt.setString(5 , iMap.getBoolean("MUTABAKATSIZ") ? "E" : "");
            stmt.execute();
            
            rSet = (ResultSet) stmt.getObject(1);
            oMap = DALUtil.rSetResults(rSet , "SIGORTALAR");
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }
    
    /**
     * Aktifbank ve EBS'de yap�lm�� sigorta i�lemleri adet ve toplam tutarlarini d�ner.
     * 
     * @param iMap TARIH
     * @return oMap AKTIF_ADET AKTIF_TOPLAM EBS_ADET EBS_TOPLAM
     * @author Omer Yusufoglu
     * @since 31.10.2014
     */
    @GraymoundService("BNSPR_QRY2064_EBS_AB_GET_TOPLAM")
    public static GMMap getEbsAbIslemToplam(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_RC2064.AB_EBS_Genel_Toplam(?,?,?,?,?,?,?,?) }");
            int i = 1;
            
            stmt.setDate(i++ , new Date(iMap.getDate("TARIH").getTime()));
            stmt.setString(i++,  StringUtils.isBlank(iMap.getString("ISLEM_TURU")) ? "X" : iMap.getString("ISLEM_TURU"));
            stmt.setString(i++,  StringUtils.isBlank(iMap.getString("SIRKET_TURU")) ? "X" : iMap.getString("SIRKET_TURU"));
            stmt.setString(i++ , iMap.getBoolean("MUTABAKATSIZ") ? "E" : "");
            stmt.registerOutParameter(i++ , Types.NUMERIC);
            stmt.registerOutParameter(i++ , Types.NUMERIC);
            stmt.registerOutParameter(i++ , Types.NUMERIC);
            stmt.registerOutParameter(i , Types.NUMERIC);
            
            stmt.execute();
            oMap.put("AKTIF_ADET" , stmt.getBigDecimal(i--));
            oMap.put("AKTIF_TOPLAM" , stmt.getBigDecimal(i--));
            oMap.put("EBS_ADET" , stmt.getBigDecimal(i--));
            oMap.put("EBS_TOPLAM" , stmt.getBigDecimal(i));
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }
    
    /**
     * Se�ilen kayd�n uretim tablosuna eklenmesini sa�lar
     * 
     * @param iMap BANKA_ISLEM_NO
     * @return oMap AKTIF_ADET AKTIF_TOPLAM EBS_ADET EBS_TOPLAM
     * @author Omer Yusufoglu
     * @since 04.11.2014
     */
    @GraymoundService("BNSPR_QRY2064_EBS_URETIME_EKLE")
    public static GMMap ebsUretimeEkle(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_RC2064.EBS_Uretime_Ekle(?) }");
            
            stmt.setString(1 , iMap.getString("BANKA_ISLEM_NO"));
            stmt.execute();
            
            oMap.put("MESSAGE" , "��leminiz tamamland�!");
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }
    
	/**
	 * EBS'de ve banka sigorta i�lemleri listesini d�ner.
	 * 
	 * @param iMap
	 *            TARIH
	 * @return oMap SIGORTA_URETIM_LIST
	 * @author Omer Yusufoglu
	 * @since 05.11.2014
	 */
	@GraymoundService("BNSPR_QRY2064_EBS_URETIM_KAYIT_GETIR")
	public static GMMap getEbsUretimIslemleri(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try {

			// gelen tarih format� de�i�tirilir
			iMap.put("TANZIM_TARIHI", new SimpleDateFormat("yyyyMMdd").format(iMap.getDate("TARIH")));

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2064.EBS_AB_Uretim_Bilgileri(?,?,?)}");

			int i = 0;
			stmt.registerOutParameter(++i, -10); // ref cursor
			stmt.setString(++i, iMap.getString("TANZIM_TARIHI") == null ? null : iMap.getString("TANZIM_TARIHI"));
            stmt.setString(++i, StringUtils.isBlank(iMap.getString("ISLEM_TURU"))? "X" : iMap.getString("ISLEM_TURU"));
            stmt.setString(++i, StringUtils.isBlank(iMap.getString("SIRKET_TURU"))? "X" : iMap.getString("SIRKET_TURU"));
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			String tableName = "SIGORTA_URETIM_LIST";
			return DALUtil.rSetResults(rSet, tableName);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
	/**
     * Sigorta Iade i�lemleri listesini d�ner.
     * 
     * @param iMap
     *            TARIH
     * @return oMap SIGORTA_IADE_LIST
     * @author Omer Yusufoglu
     * @since 04.05.2015
     */
    @GraymoundService("BNSPR_QRY2064_AB_PTT_IADE_KAYIT_GETIR")
    public static GMMap getIadeIslemleri(GMMap iMap) {

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;

        try {

            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_RC2064.AB_PTT_Iade_Islem_Getir(?,?,?,?)}");

            stmt.registerOutParameter(1, -10); // ref cursor
            stmt.setDate(2, new Date(iMap.getDate("TARIH").getTime()));
            stmt.setString(3, StringUtils.isBlank(iMap.getString("ISLEM_TURU"))? "X" : iMap.getString("ISLEM_TURU"));
            stmt.setString(4, StringUtils.isBlank(iMap.getString("SIRKET_TURU"))? "X" : iMap.getString("SIRKET_TURU"));
            stmt.setString(5 , iMap.getBoolean("MUTABAKATSIZ") ? "E" : "");
            stmt.execute();

            rSet = (ResultSet) stmt.getObject(1);
            return DALUtil.rSetResults(rSet, "SIGORTALAR");

        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }

    }
    
    /**
     * Banka ve Ptt'deki sigorta iade i�lemleri adet ve toplam tutarlarini d�ner.
     * 
     * @param iMap TARIH
     * @return oMap AKTIF_ADET AKTIF_TOPLAM EBS_ADET EBS_TOPLAM
     * @author Omer Yusufoglu
     * @since 07.05.2015
     */
    @GraymoundService("BNSPR_QRY2064_AB_PTT_IADE_GET_TOPLAM")
    public static GMMap getIadeIslemToplam(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try{
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_RC2064.AB_PTT_Iade_Genel_Toplam(?,?,?,?,?,?,?,?) }");
            int i = 1;
            
            stmt.setDate(i++ , new Date(iMap.getDate("TARIH").getTime()));
            stmt.setString(i++,  StringUtils.isBlank(iMap.getString("ISLEM_TURU")) ? "X" : iMap.getString("ISLEM_TURU"));
            stmt.setString(i++,  StringUtils.isBlank(iMap.getString("SIRKET_TURU")) ? "X" : iMap.getString("SIRKET_TURU"));
            stmt.setString(i++ , iMap.getBoolean("MUTABAKATSIZ") ? "E" : "");
            stmt.registerOutParameter(i++ , Types.NUMERIC);
            stmt.registerOutParameter(i++ , Types.NUMERIC);
            stmt.registerOutParameter(i++ , Types.NUMERIC);
            stmt.registerOutParameter(i , Types.NUMERIC);
            
            stmt.execute();
            oMap.put("AB_ADET" , stmt.getBigDecimal(i--));
            oMap.put("AB_TOPLAM" , stmt.getBigDecimal(i--));
            oMap.put("PTT_ADET" , stmt.getBigDecimal(i--));
            oMap.put("PTT_TOPLAM" , stmt.getBigDecimal(i));
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }
    
}
