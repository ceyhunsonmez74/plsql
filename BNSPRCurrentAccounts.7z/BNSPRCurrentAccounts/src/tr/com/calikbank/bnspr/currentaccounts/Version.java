package tr.com.calikbank.bnspr.currentaccounts;

public class Version {

}
