package tr.com.calikbank.bnspr.currentaccounts.services;

import java.io.File;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.StringTokenizer;

import javax.xml.bind.DatatypeConverter;

import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRPdfExporter;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CrdDebitTransferBakiye;
import tr.com.aktifbank.bnspr.dao.CrdDebitTransferBakiyeDty;
import tr.com.aktifbank.bnspr.dao.FonAlimSatimTx;
import tr.com.aktifbank.bnspr.dao.FonAltinHareketTx;
import tr.com.aktifbank.bnspr.dao.GnlDokumanBaglantiTx;
import tr.com.aktifbank.bnspr.dao.GnlDokumanKodPr;
import tr.com.aktifbank.bnspr.dao.GnlMusteriimajDetay;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.dao.MuhHesapKopruiban;
import tr.com.aktifbank.bnspr.pdfViewerPanelBean.ByteArrayType;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.core.util.CoreEnums;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.ReportUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.module.custom.services.LOVExecuter;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsCommonServices {
	private static Logger log = Logger.getLogger(CurrentAccountsCommonServices.class);

    @GraymoundService("BNSPR_COMMON_BAKIYE_GORUNSUN_MU")
	public static GMMap bakiyeGorunsunMu(GMMap iMap) { 
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_hesap.personel_bakiye_gosterilsin(?)}");
			stmt.registerOutParameter(1, Types.CHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("HESAP_NO"));

			stmt.execute();

			oMap.put("GORUNSUN", stmt.getObject(1)); // values {0,1}
			oMap.put("IS_GORUNSUN", GuimlUtil.convertBinaryToCheckBoxSelected(stmt.getString(1))); // values
																									// {false,true}}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_LC_KOD")
	public static GMMap getLC_Kod(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("LC_KOD", DALUtil.callNoParameterFunction("{? = call pkg_genel_pr.lc_al}", Types.VARCHAR));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_DOVIZ_AD")
	public static GMMap getDovizAd(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("DOVIZ_AD", DALUtil.callNoParameterFunction("{? = call pkg_genel_pr.doviz_adi('" + iMap.getString("DOVIZ_KOD") + "')}", Types.VARCHAR));
		return oMap;
	}
	
	@GraymoundService("BNSPR_COMMON_GET_DOVIZ_BASIM_KODU")
	public static GMMap getDovizBasimKodu(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("DOVIZ_BASIM_KODU", DALUtil.callNoParameterFunction("{? = call pkg_genel_pr.Basim_Doviz_Kodu('" + iMap.getString("DOVIZ_KODU") + "')}", Types.VARCHAR));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_KULLANICI_KOD")
	public static GMMap getKullaniciKod(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("KULLANICI_KOD", DALUtil.callNoParameterFunction("{? = call pkg_global.GET_KULLANICIKOD}", Types.VARCHAR));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_UNVAN")
	public static GMMap getUnvan(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("UNVAN", DALUtil.callOneParameterFunction("{? = call pkg_musteri.unvan(?)}", Types.VARCHAR, iMap.getBigDecimal("MUSTERI_NO")));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_AYIN_SON_ISGUNU")
	public static GMMap getAyinSonIsGunu(GMMap iMap) {
		try{
			GMMap oMap = new GMMap();
			oMap.put("SON_GUN", DALUtil.callOneParameterFunction("{? = call pkg_tarih.ayin_son_is_gunu(?)}", Types.DATE, iMap.getDate("BANKA_TARIHI")));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_COMMON_GET_AYIN_SON_GUNU")
	public static GMMap getAyinSonGunu(GMMap iMap) {
		try{
			GMMap oMap = new GMMap();
			oMap.put("SON_GUN", DALUtil.callOneParameterFunction("{? = call pkg_tarih.ayin_son_gunu(?)}", Types.DATE, iMap.getDate("BANKA_TARIHI")));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_COMMON_GET_ISLEM_ADI")
	public static GMMap getIslemAdi(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("ISLEM_ADI", DALUtil.callOneParameterFunction("{? = call pkg_tablo.muh_islem_tanim_tablo(?).aciklama}", Types.VARCHAR, iMap.getBigDecimal("ISLEM_KOD")));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_KANAL_KOD")
	public static GMMap getKanalKod(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_global.Get_kanalkod}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();
			oMap.put("KANAL_KOD", stmt.getObject(1));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_COMMON_GET_KANAL_ADI")
	public static GMMap getKanalAdi(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {
			String func="{? = call pkg_genel_pr.kanal_adi(?)}";
			String kanalAdi = (String) DALUtil.callOneParameterFunction(func, Types.VARCHAR, iMap.getString("KANAL_KODU"));
			oMap.put("KANAL_ADI",kanalAdi);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_KANAL_ALT_KOD")
	public static GMMap getKanalAltKod(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_global.Get_KanalAltKod}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();
			oMap.put("KANAL_ALT_KOD", stmt.getObject(1));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_HESAP_SUBE_KOD")
	public static GMMap getHesapSubeKod(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
	        oMap.put("SUBE_KODU" , DALUtil.callOneParameterFunction("{? = call pkg_hesap.sube_kodu(?)}" , Types.VARCHAR , iMap.getString("HESAP_NO")));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		return oMap;
	}
	
	@GraymoundService("BNSPR_COMMON_GET_SUBE_KOD")
	public static GMMap getSubeKod(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_global.get_sube_kodu_adi(?,?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.execute();
			oMap.put("SUBE_KOD", stmt.getObject(1));
			oMap.put("SUBE_ADI", stmt.getObject(2));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_SUBE_ADI")
	public static GMMap getSubeAdi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_genel_pr.sube_adi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("SUBE_KODU"));
			stmt.execute();
			oMap.put("SUBE_ADI", stmt.getObject(1));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_BOLUM_ADI")
	public static GMMap getBolumAdi(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("BOLUM_ADI", DALUtil.callOneParameterFunction("{? = call pkg_genel_pr.bolum_adi(?)}", Types.VARCHAR, iMap.getString("BOLUM_KODU")));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_SUBE_VEYA_GM")
	public static GMMap getSubeVeyaGm(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_genel_pr.sube_gm(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("SUBE_KODU"));
			stmt.execute();
			oMap.put("SUBE_GM", stmt.getObject(1));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_COMMON_GET_ISLEM_SUBE_KODU_ADI")
	public static GMMap getIslemSubeKoduAdi(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("ISLEM_SUBE_KODU", DALUtil.callOneParameterFunction(
								"{? = call pkg_tx.Islem_SubeKodu_Al(?)}", Types.VARCHAR, 
								iMap.getBigDecimal("TRX_NO")));
		oMap.put("ISLEM_SUBE_ADI", getSubeAdi(new GMMap().put("SUBE_KODU", oMap.getString("ISLEM_SUBE_KODU")))
								.getString("SUBE_ADI"));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_LOCAL_CUR")
	public static GMMap getLocalCur(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("DOVIZ_KODU", DALUtil.callNoParameterFunction("{? = call PKG_GLOBAL.get_LocalCur}", Types.VARCHAR));
		return oMap;
	}
	
	@GraymoundService("BNSPR_COMMON_GET_BANKA_TARIH")
	public static GMMap getBankaTarih(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("BANKA_TARIH", (Date)DALUtil.callNoParameterFunction("{? = call pkg_global.GET_BANKATARIH}", Types.DATE));
		return oMap;
	}

	// TODO : Bu servisi kaldir, BNSPR_COMMON_GET_BANKA_TARIH kullanilsin
	@GraymoundService("BNSPR_COMMON_GET_BANKA_TARIHI")
	public static GMMap getBankaTarihi(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("BANKA_TARIH", (Date)DALUtil.callNoParameterFunction("{? = call pkg_global.GET_BANKATARIH}", Types.DATE));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_ONCEKI_BANKA_TARIHI")
	public static GMMap getOncekiBankaTarihi(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("BANKA_TARIHI", DALUtil.callNoParameterFunction("{? = call PKG_MUHASEBE.Onceki_Banka_Tarihi_Bul}", Types.DATE));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_SONRAKI_BANKA_TARIHI")
	public static GMMap getSonrakiBankaTarihi(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("BANKA_TARIHI", DALUtil.callNoParameterFunction("{? = call PKG_MUHASEBE.sonraki_banka_tarihi_bul}", Types.DATE));
		return oMap;
	}
	
	@GraymoundService("BNSPR_COMMON_GET_GLOBAL_DOVIZ_KODU")
	public static GMMap getGlobalDovizKodu(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("DOVIZ_KODU", DALUtil.callNoParameterFunction("{? = call pkg_global.WBaseCurr}", Types.VARCHAR));
		return oMap;
	}
	@GraymoundService("BNSPR_COMMON_GET_PERSONEL_KURUM_KODU")
	public static GMMap getPersonelKurumKodu(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("KURUM_KODU", DALUtil.callNoParameterFunction("{? = call pkg_personel.Get_kurum_kod}", Types.VARCHAR));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_KUR")
	public static GMMap getKur(GMMap iMap) {
		BigDecimal kur = getKur(iMap.getString("ISLEM_SEKLI"), iMap.getString("ALIS_SATIS"), iMap.getString("DOVIZ_KODU"));
		GMMap oMap = new GMMap();
		oMap.put("KUR", kur);
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE")
	public static GMMap getKullanilabilirBakiye(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try{
			if(iMap.containsKey("NEGATIVE_ACCEPTED")) {			
				Object[] inputValues = new Object[]{BnsprType.STRING, iMap.getString("HESAP_NO"), BnsprType.NUMBER, BigDecimal.ZERO, BnsprType.NUMBER, BigDecimal.ZERO, BnsprType.STRING, "", BnsprType.STRING, iMap.get("NEGATIVE_ACCEPTED")};
				BigDecimal bakiye = (BigDecimal) DALUtil.callOracleFunction("{? = call pkg_hesap.Kullanilabilir_Bakiye_Al(?, ?, ?, ?, ?)}", BnsprType.NUMBER, inputValues);
				
				oMap.put("KULLANILABILIR_BAKIYE", bakiye);
			} else {			
				if(iMap.containsKey("KMHSIZ") && "E".equals(iMap.getString("KMHSIZ"))){
					Object[] inputValues = new Object[]{BnsprType.STRING, iMap.getString("HESAP_NO"), BnsprType.NUMBER, BigDecimal.ZERO, BnsprType.NUMBER, BigDecimal.ZERO, BnsprType.STRING, "K", BnsprType.STRING, ""};
					BigDecimal bakiye = (BigDecimal) DALUtil.callOracleFunction("{? = call pkg_hesap.Kullanilabilir_Bakiye_Al(?, ?, ?, ?, ?)}", BnsprType.NUMBER, inputValues);
					oMap.put("KULLANILABILIR_BAKIYE", bakiye);
				}else{
				oMap.put("KULLANILABILIR_BAKIYE", DALUtil.callOneParameterFunction("{? = call pkg_hesap.Kullanilabilir_Bakiye_Al(?)}", Types.NUMERIC, iMap.getString("HESAP_NO")));
				}
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_KMH_GRUP_KULLANILABILIR_BAKIYE")
	public static GMMap getKmhKullanilabilirBakiye(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_hesap.Kullanilabilir_Bakiye_Al(?,?,?)}");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("HESAP_NO"));
			stmt.setBigDecimal(3, null);
			stmt.setString(4, iMap.getString("KMH_GRUP_KOD"));
			
			stmt.execute();
			oMap.put("KULLANILABILIR_BAKIYE", stmt.getBigDecimal(1));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}
	
	@GraymoundService("BNSPR_COMMON_GET_MUSTERI_NO")
	public static GMMap getMusteriNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("MUSTERI_NO", DALUtil.callOneParameterFunction("{? = call pkg_hesap.musteri_no(?)}", Types.NUMERIC, iMap.getString("HESAP_NO")));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_HESAP_DOVIZ_KODU")
	public static GMMap getBlokeHesapDovizKodu(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("BLOKE_DOVIZ_KODU", 	DALUtil.callOneParameterFunction("{? = call pkg_hesap.doviz_kodu(?)}", 
										Types.VARCHAR, 
										iMap.getString("HESAP_NO")));
		return oMap;
	}
	
	@GraymoundService("BNSPR_COMMON_GET_IBAN")
	public static GMMap getIBAN(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("IBAN", DALUtil.callOneParameterFunction("{? = call pkg_hesap.IBAN(?)}", Types.VARCHAR, iMap.getString("HESAP_NO")));
		return oMap;
	}
	@GraymoundService("BNSPR_COMMON_GET_ACCOUNT_WITH_IBAN")
	public static GMMap getAccountWithIban(GMMap iMap){
		GMMap oMap = new GMMap();
		oMap.put("ACCOUNT_NO", DALUtil.callOneParameterFunction("{? = call pkg_hesap.IBANDAN_HESAPNOAL(?)}", Types.BIGINT, iMap.getString("IBAN")));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_VKN_CHECK_DIGIT")
	public static GMMap vknCheckDigit(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("SONUC", DALUtil.callOneParameterFunction("{? = call vergino_checkdigit(?)}", Types.VARCHAR, iMap.getString("VERGI_NO")));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_TCKN_CHECK_DIGIT")
	public static GMMap tcknCheckDigit(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("SONUC", DALUtil.callOneParameterFunction("{? = call pkg_musteri.tckn_kontrol(?)}", Types.VARCHAR, iMap.getString("TC_KIMLIK_NO")));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_DEFTER_BAKIYE")
	public static GMMap getDefterBakiye(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_hesap.bakiyebilgial(?,?,?,?)}");

			stmt.setString(1, iMap.getString("HESAP_NO"));
			stmt.registerOutParameter(2, Types.DECIMAL);
			stmt.registerOutParameter(3, Types.DECIMAL);
			stmt.registerOutParameter(4, Types.DECIMAL);

			stmt.execute();

			oMap.put("DEFTER_BAKIYE", stmt.getBigDecimal(2));

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_COMMON_DOVIZ_CEVIR")
	public static GMMap dovizCevir(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_kur.DOVIZ_CEVIR(?,?,?,?,?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("DOVIZ1"));
			stmt.setString(3, iMap.getString("DOVIZ2"));
			if (iMap.get("TARIH") != null)
				stmt.setDate(4, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(4, null);
			stmt.setBigDecimal(5, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(6, iMap.getBigDecimal("KUR_TIP"));
			stmt.setBigDecimal(7, iMap.getBigDecimal("KUR_DEGER1"));
			stmt.setBigDecimal(8, iMap.getBigDecimal("KUR_DEGER2"));
			stmt.setString(9, iMap.getString("KUR_TABLO"));
			stmt.setString(10, iMap.getString("ALIS_SATIS"));
			stmt.execute();
			oMap.put("KARSILIK", stmt.getBigDecimal(1));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_COMMON_GET_LOCAL_COUNTRY")
	public static GMMap getLocalCountry(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rs = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("select pkg_global.GET_LOCALCountry COUNTRY_CODE, pkg_genel_pr.ulke_adi( pkg_global.GET_LOCALCountry) COUNTRY_NAME from dual");
			rs = stmt.executeQuery();
			String ulkeKodu = null, ulkeAdi = null;
			if (rs.next()) {
				ulkeKodu = rs.getString(1);
				ulkeAdi = rs.getString(2);
			}
			oMap.put("ULKE_KODU", ulkeKodu);
			oMap.put("ULKE_ADI", ulkeAdi);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rs);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	public static BigDecimal getKur(String kurTipi, String alisSatis, String dovizKodu) {
		return (BigDecimal) DALUtil.callOneParameterFunction("{? = call pkg_kur." + kurTipi + alisSatis + "K_to_LC(? ,1)}", Types.NUMERIC, dovizKodu);
	}

	public static boolean isNotNullOrNotEmpty(Object obj) {
		if (obj == null)
			return false;
		if (obj instanceof String)
			return !((String) obj).trim().equals("");
		return true;
	}

	@GraymoundService("BNSPR_GET_DEFTER_BAKIYESI")
	public static GMMap getDefterBakiyesi(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();

		if ((!"".equals(iMap.getString("HESAP_NO"))) && (iMap.getString("HESAP_NO") != null)) {
			try {
				conn = DALUtil.getGMConnection();

				stmt = conn.prepareCall("{? = call pkg_hesap.HesapBakiyeAl(?)}");

				stmt.registerOutParameter(1, Types.DECIMAL);
				stmt.setString(2, iMap.getString("HESAP_NO"));

				stmt.execute();

				BigDecimal defterBakiye = stmt.getBigDecimal(1);
				oMap.put("DEFTER_BAKIYE", defterBakiye);

				return oMap;

			} catch (SQLException e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}
		oMap.put("DEFTER_BAKIYE", 0);
 
		return oMap;

	}

	@GraymoundService("BNSPR_GET_KMV_ORAN")
	public static Map<?, ?> getKMVOran(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("KMV_ORAN", DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_N('KMV_ORANI')}", Types.NUMERIC));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_FC_TO_LC")
	public static GMMap getFcToLc(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_kur.FC_TO_LC(?,?,?,?)}");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("DOVIZ"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("KUR_TIPI"));
			stmt.setString(5, iMap.getString("ALIS_SATIS"));

			stmt.execute();

			BigDecimal kur = stmt.getBigDecimal(1);
			oMap.put("KUR", kur);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_COMMON_LC_TO_FC")
	public static GMMap getLcToFc(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_kur.LC_TO_FC(?,?,?,?)}");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("DOVIZ"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TUTAR"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("KUR_TIPI"));
			stmt.setString(5, iMap.getString("ALIS_SATIS"));

			stmt.execute();

			BigDecimal kur = stmt.getBigDecimal(1);
			oMap.put("KUR", kur);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_GET_SYSDATE")
	public static GMMap getSysDate(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			String q = "select to_char(sysdate,'dd.mm.yyyy hh24:mi:ss') SYS_DATE from dual";

			stmt = conn.prepareCall(q);
			rSet = stmt.executeQuery();
			while (rSet.next()) {

				String o = rSet.getString("SYS_DATE");

				oMap.put("SYS_DATE", o);

			}
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService(value="BNSPR_COMMON_GET_ERROR_MESSAGE",authenticationRequired=false)
	public static GMMap getErrorMessage(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			if (iMap.containsKey("P1"))
				stmt = conn.prepareCall("{? = call pkg_hata.mesajolustur(?,?,?,?,?,?)}");
			else
				stmt = conn.prepareCall("{? = call pkg_hata.mesajolustur(?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);

			if (iMap.containsKey("P1")) {
				stmt.setBigDecimal(2, iMap.getBigDecimal("MESSAGE_NO"));
				stmt.setString(3, iMap.getString("P1"));
				stmt.setString(4, iMap.getString("P2"));
				stmt.setString(5, iMap.getString("P3"));
				stmt.setString(6, iMap.getString("P4"));
				stmt.setString(7, iMap.getString("P5")); //Kanal
			} else
				stmt.setBigDecimal(2, iMap.getBigDecimal("MESSAGE_NO"));

			stmt.execute();
			GMMap oMap = new GMMap();
			
			String errMsg = stmt.getString(1);
			
			String akustikBEPrefix= CoreEnums.EXCEPTION_PREFIX.AKUSTIK_BUSINESS_EXCEPTION.getValue();
            if(errMsg.startsWith( akustikBEPrefix) ){
            	int msgCodeColonIndex = errMsg.indexOf(":");
            	if(!Boolean.valueOf( GMServer.getProperty("exception.displayMsgCode", "false") )){ // mesaj kodu hata mesajinda gosterilmeyecekse cikariyoruz
            		errMsg = errMsg.substring(msgCodeColonIndex + 1).trim();
            	}
            }
			
			oMap.put("ERROR_MESSAGE", errMsg);
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService(value="BNSPR_COMMON_GET_KODSUZ_MESSAGE",authenticationRequired=false)
	public static GMMap getKodsuzMessage(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			if (iMap.containsKey("P1"))
				stmt = conn.prepareCall("{? = call pkg_hata.kodsuzMesajOlustur(?,?,?,?,?,?)}");
			else
				stmt = conn.prepareCall("{? = call pkg_hata.kodsuzMesajOlustur(?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);

			if (iMap.containsKey("P1")) {
				stmt.setBigDecimal(2, iMap.getBigDecimal("MESSAGE_NO"));
				stmt.setString(3, iMap.getString("P1"));
				stmt.setString(4, iMap.getString("P2"));
				stmt.setString(5, iMap.getString("P3"));
				stmt.setString(6, iMap.getString("P4"));
				stmt.setString(7, iMap.getString("P5")); //Kanal
			} else
				stmt.setBigDecimal(2, iMap.getBigDecimal("MESSAGE_NO"));

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("ERROR_MESSAGE", stmt.getString(1));
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService(value="BNSPR_COMMON_GET_KODSUZ_MESSAGE_DILKOD",authenticationRequired=false)
	public static GMMap callServiceAfterChangingLanguageTemporarily(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		String dilKod = getDilKod();
		try {
			setDilKod(iMap.getString("DIL_KOD"));
			return GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			setDilKod(dilKod);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	private static String getDilKod(){
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_GLOBAL.GET_DILKOD()}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();
			return stmt.getString(1);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	private static void setDilKod(String dilKod){
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_GLOBAL.SET_DILKOD(?)}");
			stmt.setString(1, dilKod);
			stmt.execute();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2106_BELGEKONTROL")
    public static GMMap AltinfonBelgeKontrol(GMMap iMap) {
		  Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;
	        try {
	            
	            GMMap oMap = new GMMap();

	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{call PKG_TRN2105.Altin_Fon_Belge_Kontrol(?, ?,?) }");
	     
	            stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));
	         //   stmt.setString(2 , iMap.getString("BHS"));
	          //  stmt.setString(3 , iMap.getString("ADS")); // Alt�n Fon Sozlesme belgesi kontrol
	            stmt.registerOutParameter(2 , Types.VARCHAR);
	            stmt.registerOutParameter(3 , Types.VARCHAR);
	            stmt.execute(); 
	            String bhs = (String)stmt.getObject(2);
	            String ads =(String) stmt.getObject(3);
	            oMap.put("BHS" ,bhs);
	            oMap.put("ADS" ,ads);
	            
	            if (oMap.getString("BHS").equalsIgnoreCase("H") && oMap.getString("ADS").equalsIgnoreCase("E"))
	            	oMap.put("MESSAGE_NO","2704" );
	            if (oMap.getString("ADS").equalsIgnoreCase("H") && oMap.getString("BHS").equalsIgnoreCase("E"))
	            	oMap.put("MESSAGE_NO","2694" );
	            if (oMap.getString("ADS").equalsIgnoreCase("H") && oMap.getString("BHS").equalsIgnoreCase("H"))
	            	oMap.put("MESSAGE_NO","2705" );
	            
	            
	            return oMap;
	        }
	        catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        }
	        finally{
	          
	            GMServerDatasource.close(rSet);
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	            
	        }
	}
	
	
	@GraymoundService("BNSPR_COMMON_HATA_YAZ")
	public static GMMap hataYaz(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_hata.hata_yaz(?,true,?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("HATA_NO"));
			stmt.setString(2, iMap.getString("P1"));
			stmt.setString(3, iMap.getString("P2"));
			stmt.setString(4, iMap.getString("P3"));
			stmt.setString(5, iMap.getString("P4"));

			stmt.execute();

			return new GMMap();

		} catch (Exception e) {
			//throw new GMRuntimeException(0, e);
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_COMMON_GET_GENEL_ID")
	public static GMMap getGenelID(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al(?)}");

			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("TABLE_NAME"));
			stmt.execute();

			oMap.put("ID", stmt.getObject(1));

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	// BPM projesi i�in
	@GraymoundService("BNSPR_COMMON_FILL_COMBOBOX")
	public static GMMap fillComboboxTRN3161(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			StringBuffer query = new StringBuffer();
			query.append("SELECT KEY1, TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = ? ORDER BY SIRA_NO");

			stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, iMap.getString("KOD"));
			rSet = stmt.executeQuery();
			String tableName = "RESULTS";
			for (int row = 0; rSet.next(); row++) {
				iMap.put(tableName, row, "KEY1", rSet.getString(1));
				iMap.put(tableName, row, "TEXT", rSet.getString(2));
			}
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_COMMON_GET_PARAM_TEXT")
	public static GMMap getParamText(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_parametre.paramtextal(?,?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("KOD"));
			stmt.setString(3, iMap.getString("KEY"));
			stmt.setString(4, iMap.getString("KEY2"));
			stmt.setString(5, iMap.getString("KEY3"));

			stmt.execute();

			oMap.put("TEXT", stmt.getString(1));

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_COMMON_GET_MESAJ_TEXT")
	public static GMMap getMesajText(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_parametre.MesajTextAl(?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("KOD"));
			stmt.setString(3, iMap.getString("KEY"));
			stmt.setString(4, (iMap.getString("KANAL_KOD") == null ) ? getKanalKod(new GMMap()).getString("KANAL_KOD") : iMap.getString("KANAL_KOD"));
			
			stmt.execute();

			oMap.put("TEXT", stmt.getString(1));

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_GET_PARAMETRE_DEGER_AL_K")
	public static Map<?, ?> getParametreDegerAlK(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("DEGER", DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K('"+iMap.getString("PARAMETRE")+"')}", Types.VARCHAR));
		return oMap;
	}
	
	@GraymoundService("BNSPR_GET_PARAMETRE_DEGER_AL_K_N")
	public static Map<?, ?> getParametreDegerAlKN(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("DEGER", DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_N('"+iMap.getString("PARAMETRE")+"')}", Types.INTEGER));
		return oMap;
	}
	
	@GraymoundService("BNSPR_COMMON_GET_COMBO_PARAMETERS")
	public static GMMap getComboParameter(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			if (iMap.getString("KEY2") == null || iMap.getString("KEY2").equals("null")) {
				stmt = conn.prepareStatement("SELECT KEY1, TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = ? ORDER BY SIRA_NO,TEXT");
			} else {
				stmt = conn.prepareStatement("SELECT KEY1, TEXT FROM V_ML_GNL_PARAM_TEXT WHERE KOD = ? AND KEY2 = ? ORDER BY SIRA_NO,TEXT");
				stmt.setString(2, iMap.getString("KEY2"));
			}

			stmt.setString(1, iMap.getString("KOD"));

			rSet = stmt.executeQuery();

			String listName = getTableName(iMap);
			if (iMap.containsKey("ADD_EMPTY_KEY"))
				if (iMap.getString("ADD_EMPTY_KEY").equals("E")) GuimlUtil.wrapMyCombo(oMap, listName, null, " ");
				else if(iMap.getString("ADD_EMPTY_KEY").equals("HEPSI")) GuimlUtil.wrapMyCombo(oMap, listName, null, "Hepsi");
				else if(iMap.getString("ADD_EMPTY_KEY").equals("SECINIZ")) GuimlUtil.wrapMyCombo(oMap, listName, null, "Se�iniz");
			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString(1), rSet.getString(2));
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_COMMON_GET_COMBO_PARAMETERS_WITH_KEY3")
	public static GMMap getComboParameterKey3(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			String orderStmt = iMap.getString("ORDERBY_STMT", " ORDER BY SIRA_NO");
			
			if(iMap.containsKey("ALL_PARAMETERS")){
				stmt = conn.prepareStatement("SELECT KEY1, TEXT , KEY2, KEY3, ID FROM V_ML_GNL_PARAM_TEXT WHERE KOD = ? " + orderStmt);
			}
			else if (iMap.getString("KEY3") == null) {
				stmt = conn.prepareStatement("SELECT KEY1, TEXT , KEY2, KEY3, ID FROM V_ML_GNL_PARAM_TEXT WHERE KOD = ? AND KEY2 = ? " + orderStmt);
				stmt.setString(2, iMap.getString("KEY2"));
			} else {
				stmt = conn.prepareStatement("SELECT KEY1, TEXT , KEY2, KEY3, ID FROM V_ML_GNL_PARAM_TEXT WHERE KOD = ? AND KEY2 = ? AND KEY3 = ? " + orderStmt);
				stmt.setString(2, iMap.getString("KEY2"));
				stmt.setString(3, iMap.getString("KEY3"));
			}
			
			stmt.setString(1, iMap.getString("KOD"));
			
			rSet = stmt.executeQuery();

			String listName = getTableName(iMap);
			if (iMap.containsKey("ADD_EMPTY_KEY"))
				if (iMap.getString("ADD_EMPTY_KEY").equals("E")) GuimlUtil.wrapMyCombo(oMap, listName, null, " ");
				else if(iMap.getString("ADD_EMPTY_KEY").equals("HEPSI")) GuimlUtil.wrapMyCombo(oMap, listName, null, "Hepsi");
			int index = 0;
			
			String comboboxNameKey = iMap.getString("COMBOBOX_NAME_KEY", "TEXT");
			
			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString(1), rSet.getString(2));
				oMap.put(listName + "_TABLE", index, "KEY1",  rSet.getString(1));
				oMap.put(listName + "_TABLE", index, "VALUE", rSet.getString(2));
				oMap.put(listName + "_TABLE", index, "KEY2",  rSet.getString(3));
				oMap.put(listName + "_TABLE", index, "NAME",  rSet.getString(comboboxNameKey)); // for comboboxes
				oMap.put(listName + "_TABLE", index, "KEY3",  rSet.getString(4));
				oMap.put(listName + "_TABLE", index, "ID",  rSet.getString(5));
				index++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	
	/** Verilen kod ve key ile bulunan parametre listesini tableName olarak {@link GMMap}e ekler.<br>
	 *  addOption secenegi set edilmisse listeye yeni bir satir ekler.
	 *  
	 * @author murat.el
	 * @since BT-6615
	 * @param iMap - Parametre sorgu bilgisi<br>
	 *         <li>TABLE_NAME - Parametre listesi adi:Ekrana input
	 *         <li>KOD - Parametre Adi
	 *         <li>KEY1 - Parametre Kriteri 1
	 *         <li>KEY2 - Parametre Kriteri 2
	 *         <li>KEY3 - Parametre Kriteri 3
	 *         <li>ADD_EMPTY_KEY - "E":Bos, "Hepsi":Hepsi Satiri Eklensin
	 * @return oMap - Parametre sorgu sonucu<br>
	 *         <li>TABLE_NAME - Parametre listesini doner, TABLE_NAME bos ise RESULTS olarak yer alir.
	 */
	@GraymoundService("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_KEY")
	public static GMMap getComboParameterByKey(GMMap iMap) {
		GMMap oMap = new GMMap();
		//initial database variables
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;

		try {
			//Parametre verilmis mi?
			boolean isExistKey1 = StringUtils.isNotBlank(iMap.getString("KEY1"));
			boolean isExistKey2 = StringUtils.isNotBlank(iMap.getString("KEY2"));
			boolean isExistKey3 = StringUtils.isNotBlank(iMap.getString("KEY3"));
			
			//Sorguyu olustur
			StringBuilder query = new StringBuilder();
			query.append(" SELECT KEY1, TEXT, KEY2, KEY3 FROM V_ML_GNL_PARAM_TEXT");
			query.append(" WHERE KOD = ?");
			if (isExistKey1) query.append(" AND KEY1 = ?");
			if (isExistKey2) query.append(" AND KEY2 = ?");
			if (isExistKey3) query.append(" AND KEY3 = ?");
			query.append(" ORDER BY SIRA_NO");
			
			//Sorgula
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareStatement(query.toString());
			int index = 1;
			stmt.setString(index++, iMap.getString("KOD"));
			if (isExistKey1) stmt.setString(index++, iMap.getString("KEY1"));
			if (isExistKey2) stmt.setString(index++, iMap.getString("KEY2"));
			if (isExistKey3) stmt.setString(index++, iMap.getString("KEY3"));
			rSet = stmt.executeQuery();
			
			//Listeyi al
			//Listeyi initialize et
			String listName = getTableName(iMap);
			int i = 0;
			if ("E".equals(iMap.getString("ADD_EMPTY_KEY"))) {
				oMap.put(listName, i, "VALUE", StringUtils.EMPTY);//KEY1
				oMap.put(listName, i, "NAME", " ");//TEXT
				oMap.put(listName, i, "KEY2", StringUtils.EMPTY);//KEY2
				oMap.put(listName, i, "KEY3", StringUtils.EMPTY);//KEY3
				i++;
			}
			else if ("HEPSI".equals(iMap.getString("ADD_EMPTY_KEY"))) {
				oMap.put(listName, i, "VALUE", StringUtils.EMPTY);//KEY1
				oMap.put(listName, i, "NAME", "Hepsi");//TEXT
				oMap.put(listName, i, "KEY2", StringUtils.EMPTY);//KEY2
				oMap.put(listName, i, "KEY3", StringUtils.EMPTY);//KEY3
				i++;
			}
			//DBden sonuclari al.
			for (; rSet.next(); i++) {
				oMap.put(listName, i, "VALUE", rSet.getString(1));//KEY1
				oMap.put(listName, i, "NAME", rSet.getString(2));//TEXT
				oMap.put(listName, i, "KEY2", rSet.getString(3));//KEY2
				oMap.put(listName, i, "KEY3", rSet.getString(4));//KEY3
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		
		return oMap;
	}

	/*
	 * LOV : Lov ismi (zorunlu) P1..P5 : Input parametreler VALUE : Combobox
	 * i�in lov dan d�nen kolon ismi (zorunlu) NAME : Combobox i�in lov dan
	 * d�nen kolon ismi (zorunlu) -- RESULTS : Combobox a set edilecek liste
	 * INITIAL_VALUE : �lk de�er
	 */
	@GraymoundService("BNSPR_COMMON_GET_COMBO_PARAMETERS_BY_LOV")
	public static GMMap getComboParameterByLov(GMMap iMap) {

		try {

			List<Object> inputParameters = new ArrayList<Object>();
			List<?> outputParameters = new ArrayList<String>();

			GMMap oMap = new GMMap();

			if (iMap.get("P1") != null)
				inputParameters.add(iMap.get("P1"));

			if (iMap.get("P2") != null)
				inputParameters.add(iMap.get("P2"));

			if (iMap.get("P3") != null)
				inputParameters.add(iMap.get("P3"));

			if (iMap.get("P4") != null)
				inputParameters.add(iMap.get("P4"));

			if (iMap.get("P5") != null)
				inputParameters.add(iMap.get("P5"));

			outputParameters = LOVExecuter.execute(iMap.getString("LOV"), "%", inputParameters);
			int i = 0;
			String listName = getTableName(iMap);
			for (Iterator<?> iterator = outputParameters.iterator(); iterator.hasNext();) {
				HashMap<?, ?> data = (HashMap<?, ?>) iterator.next();
				if ((data.get(iMap.getString("VALUE")) != null) && (data.get(iMap.getString("NAME")) != null)) {
					if (i == 0)
						oMap.put("INITIAL_VALUE", data.get(iMap.getString("VALUE")));
					GuimlUtil.wrapMyCombo(oMap, listName, data.get(iMap.getString("VALUE")).toString(), data.get(iMap.getString("NAME")).toString());
					i++;
				}
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/*
	 * P1..P5 : Input parametreler (Exam. Y-Yes, N-No) (Y,N: Value, Yes,No:
	 * Name) -- RESULTS : Combobox a set edilecek liste
	 */
	@GraymoundService("BNSPR_COMMON_GET_COMBO_PARAMETERS_STATIC")
	public static GMMap getComboParameterStatic(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			String listName = "RESULTS";
			if (iMap.containsKey("ADD_EMPTY_KEY"))
				if (iMap.getString("ADD_EMPTY_KEY").equals("E"))
					GuimlUtil.wrapMyCombo(oMap, listName, null, " ");

			if (iMap.get("P1") != null)
				seperationParametersWrapCombo(oMap, listName, iMap.getString("P1"));

			if (iMap.get("P2") != null)
				seperationParametersWrapCombo(oMap, listName, iMap.getString("P2"));

			if (iMap.get("P3") != null)
				seperationParametersWrapCombo(oMap, listName, iMap.getString("P3"));

			if (iMap.get("P4") != null)
				seperationParametersWrapCombo(oMap, listName, iMap.getString("P4"));

			if (iMap.get("P5") != null)
				seperationParametersWrapCombo(oMap, listName, iMap.getString("P5"));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static GMMap seperationParametersWrapCombo(GMMap oMap, String listName, String str) {
		try {
			List<String> list = new ArrayList<String>();
			StringTokenizer tok = new StringTokenizer(str, "-");
			while (tok.hasMoreTokens()) {
				String token = tok.nextToken();
				list.add(token);
			}
			return GuimlUtil.wrapMyCombo(oMap, listName, list.get(0), list.get(1));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_COMMON_ISLEM_BATCH_ISLEM_MI")
	public static GMMap islemBatchIslemMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_genel_pr.islem_batch_islem_mi(?)}");
			stmt.registerOutParameter(1, Types.CHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_NO"));
			stmt.execute();
			oMap.put("CEVAP", stmt.getObject(1));

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_CUSTOMER_ACCOUNT_CONTROL")
	public static GMMap customerAccontControl(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call pkg_hesap.customer_account_control(?,?,?,?)}");
			stmt.setString(1, iMap.getString("SUBE_KOD"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("HESAP_NO"));
			stmt.setString(4, iMap.getString("DOVIZ_KOD"));
			stmt.execute();

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_ACCOUNT_BALANCE_CONTROL")
	public static GMMap AccountBalanceControl(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call pkg_hesap.account_balance_control(?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("HESAP_NO"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TUTAR"));
			stmt.registerOutParameter(4, Types.VARCHAR);

			stmt.execute();

			oMap.put("SONUC", stmt.getString(1));
			oMap.put("MESAJ", stmt.getString(4));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_COMMON_ADD_MONTHS")
	public static GMMap commonAddMounth(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		try {
			Date date = iMap.getDate("DATE");
			BigDecimal months = iMap.getBigDecimal("MONTHS");

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call Add_Months(?,?)}");

			stmt.registerOutParameter(1, Types.DATE);
			stmt.setDate(2, new java.sql.Date(date.getTime()));
			stmt.setBigDecimal(3, months);

			stmt.execute();
			GMMap oMap = new GMMap();
			oMap.put("DATE", stmt.getDate(1));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_COMMON_GET_USER_NAME")
	public static GMMap getUserName(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("USER_NAME", GMContext.getCurrentContext().getSession().get("USER_NAME"));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_YILBASI_VE_BANKA_TARIHI")
	public static GMMap getStartDate(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			GregorianCalendar cal = new GregorianCalendar();
			oMap.put("BANKA_TARIH", GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH"));
			//cal.setTime(new Date());
			cal.setTime(oMap.getDate("BANKA_TARIH"));
			cal.set(GregorianCalendar.DAY_OF_YEAR, 1);
			oMap.put("YILBASI", cal.getTime());
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_COMMON_FORMAT_DATE")
	public static GMMap getBasDate(GMMap iMap) throws Exception {
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = null;
		if (iMap.containsKey("PATTERN"))
			sdf = new SimpleDateFormat(iMap.getString("PATTERN"));
		else
			sdf = new SimpleDateFormat("dd.MM.yyyy");

		oMap.put("FORMATTED_DATE", sdf.format(iMap.getDate("TARIH")));

		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GM_KULLANICISIMI")
	public static GMMap getGMKullanicisiMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("GM_KULLANICISI", DALUtil.callNoParameterFunction("{? = call pkg_personel.GM_Kullanicisimi}", Types.VARCHAR));
		return oMap;
	}

	@GraymoundService("BNSPR_COMMON_GET_MUSTERI_NO_BY_TRX_NO")
	public static GMMap getMusteriNoByTrxNo(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			StringBuffer query = new StringBuffer();
			query.append("select m.musteri_no from gnl_musteri_basvuru_tx m where m.tx_no = ?");
			stmt = conn.prepareStatement(query.toString());
			stmt.setBigDecimal(1, iMap.getBigDecimal("TRX_NO"));

			rSet = stmt.executeQuery();
			while (rSet.next()) {
				oMap.put("MUSTERI_NO", rSet.getBigDecimal(1));
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_COMMON_GET_MEDENI_HAL_KOD")
	public static GMMap getMedeniHalKod(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			StringBuffer query = new StringBuffer("select m.kod  from gnl_medeni_hal_kod_pr m where m.aciklama = ?");
			stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, iMap.getString("MEDENI_HAL").toUpperCase());
			rSet = stmt.executeQuery();
			return DALUtil.rSetMap(rSet);			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_COMMON_GET_CINSIYET_KOD")
	public static GMMap getCinsiyet(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			StringBuffer query = new StringBuffer("select c.kod from gnl_cinsiyet_kod_pr c where c.aciklama = ?");
			stmt = conn.prepareStatement(query.toString());
			stmt.setString(1, iMap.getString("CINSIYET").toUpperCase());
			rSet = stmt.executeQuery();
			return DALUtil.rSetMap(rSet);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_COMMON_STRING_KONTROL")
	public static Map<?, ?> stringKontrol(GMMap iMap) {
		try {
			String value = iMap.getString("VALUE");
			String name = iMap.getString("NAME");

			value = value.toUpperCase();
			String charSet = "QWERTYUIOP��ASDFGHJKL��ZXCVBNM��";
			for (int i = 0; i < charSet.length(); i++)
				value = value.replace(charSet.charAt(i), ' ').trim();
			if (value.length() != 0) {
				iMap.put("HATA_NO", new BigDecimal(974));
				iMap.put("P1", name);
				return GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_COMMON_ADK_USER_INFO_MAIL")
	public static GMMap adkUserInfoMail(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_Musteri.ADK_user_creation_infomail(?, ?, ?)}");
			stmt.setBigDecimal	(1, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString		(2, iMap.getString("USERNAME"));
			stmt.setString		(3, iMap.getString("PASSWORD"));
			stmt.execute();
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static String getTableName(GMMap iMap){
		String tableName = "RESULTS";
		if (iMap.containsKey("TABLE_NAME"))
			tableName = iMap.getString("TABLE_NAME");
		return tableName;
	}
	
	@GraymoundService("BNSPR_COMMON_SONRAKI_ISGUNU")
	public static GMMap  getSonrakiIsgunu(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			oMap.put("TARIH", DALUtil.callOneParameterFunction("{? = call pkg_tarih.ileri_is_gunu(?)}", Types.DATE, iMap.getDate("TARIH")));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_COMMON_SONRAKI_GUN")
	public static GMMap  getSonrakiGun(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_tarih.ileri_gun(?,?)}");
			stmt.registerOutParameter(1, java.sql.Types.DATE);
			stmt.setDate(2, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			stmt.setBigDecimal(3, iMap.getBigDecimal("GUN"));
			stmt.execute();
			oMap.put("TARIH", stmt.getDate(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_COMMON_SONRAKI_ISGUNU_ADD_YARIM_GUN_TATIL")
	public static GMMap  getSonrakiIsgunuYarimGunTatil(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_tarih.ileri_is_gunu(?,?,?)}");
			stmt.registerOutParameter(1, java.sql.Types.DATE);
			stmt.setDate(2, new java.sql.Date(iMap.getDate("TARIH").getTime()));
			stmt.setString(3, iMap.getString("COUNTRY"));
			stmt.setString(4, iMap.getString("YARIM_GUN_TATIL_KABUL"));
			stmt.execute();
			oMap.put("TARIH", stmt.getDate(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_COMMON_ONCEKI_ISGUNU")
	public static GMMap getOncekiIsgunu(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			oMap.put("TARIH", DALUtil
					.callNoParameterFunction(
							"{? = call pkg_tarih.geri_is_gunu()}",
							Types.DATE));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_COMMON_GET_TARIH_TATILSE_ILK_ISGUNU")
	public static GMMap getTatilseIlkIsgunu(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			oMap.put("TARIH", DALUtil.callOneParameterFunction(
					"{? = call pkg_tarih.Tatilse_ilk_isgunu_bul(?)}",
					Types.DATE, iMap.getDate("TARIH")));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_COMMON_GET_REFERANS_NO")
	public static GMMap  getReferansNo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			oMap.put("REFERANS_NO", DALUtil.callOneParameterFunction("{? = call pkg_genel_pr.referans_al(?)}", Types.VARCHAR, iMap.getString("KOD")));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	/*
	 * Kullan�c�n� �ube kullan�c�s� m� yoksa genel m�d�rl�k kullan�c�s� m� 
	 * oldu�una bakan servis
	 * 
	 */
	@GraymoundService("BNSPR_COMMON_GM_SUBE_KULLANICISI_MI")
	public static GMMap gmKullanicisimi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			GMMap oMap = new GMMap();
			stmt = conn.prepareCall("{? = call PKG_PERSONEL.GM_Kullanicisimi(?)}");
			stmt.registerOutParameter(1,Types.VARCHAR);
			stmt.setString(2, null);
			stmt.execute();

			oMap.put("GM_KULLANICISI_MI", stmt.getString(1).equals("E"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_COMMON_GET_TCKN")
	public static GMMap getTckn(GMMap iMap){
		try{	
			GMMap oMap = new GMMap();
			oMap.put("TCKN", DALUtil.callOneParameterFunction("{? = call pkg_musteri.tc_kimlik_no(?)}", Types.VARCHAR,iMap.getBigDecimal("MUSTERI_NO")));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_COMMON_GET_VKN")
	public static GMMap getVkn(GMMap iMap){
		try{	
			GMMap oMap = new GMMap();
			oMap.put("VKN", DALUtil.callOneParameterFunction("{? = call pkg_musteri.vergi_no(?)}", Types.VARCHAR,iMap.getBigDecimal("MUSTERI_NO")));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_COMMON_GET_CHANNEL_CODE")
	public static GMMap getChannelCode(GMMap iMap){
		try{	
			GMMap oMap = new GMMap();
			oMap.put("CHANNEL_CODE", DALUtil.callOneParameterFunction("{? = call pkg_tablo.kanal_kod(?).integration_id}", Types.VARCHAR,iMap.getBigDecimal("KANAL_KOD")));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_COMMON_GET_ISLEM_DETAY")
	public static GMMap getIslemDetay(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			GMMap oMap = new GMMap();
			stmt = conn.prepareCall("{? = call pkg_tx.islem_detay(?)}");
			stmt.registerOutParameter(1,-10);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			rSet= (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally
		{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_COMMON_KURDAN_DOVIZ_CEVIR")
	public static GMMap kurdanDovizCevir(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_limit.kurdan_cevir(?,?,?)}");

			int i=1;
			stmt.registerOutParameter(i++, Types.DECIMAL);
			stmt.setString(i++, iMap.getString("DOVIZ1"));
			stmt.setString(i++, iMap.getString("DOVIZ2"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));

			stmt.execute();
			oMap.put("SONUC", stmt.getBigDecimal(1));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_COMMON_GET_SQL_DATE")
	public static GMMap getSqlDate(GMMap iMap) throws Exception {
		try {
			GMMap oMap = new GMMap();
			Calendar cal = Calendar.getInstance();
			cal.setTime(iMap.getDate("TARIH"));
			String tarih = "" + cal.get(GregorianCalendar.DAY_OF_MONTH) + "."
					+ (cal.get(GregorianCalendar.MONTH) + 1) + "."
					+ cal.get(GregorianCalendar.YEAR);
			oMap.put("UTIL_TARIH", tarih);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_ISLEM_BITMIS_MI")
	public static GMMap callIslemBitmismi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_tx.Islem_bitmis_mi(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			oMap.put("ISLEM_BITMIS", stmt.getBigDecimal(1));
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_OTAMATIK_DEKONT_URETILSIN_MI")
	public static GMMap otomatikDekontUretilsinMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_Dekont.otomatik_dekont_uretsinmi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			oMap.put("OTOMATIK_DEKONT_URETILSIN", stmt.getString(1));
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_ONCEKI_ISLEM_NUMARASI")
	public static GMMap oncekiIslemNumarasi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_tx.onceki_onaylanmis_tx_no(?)}");
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			oMap.put("OLD_TX_NO", stmt.getBigDecimal(1));
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_DEKONT_URETILMIS_MI")
	public static GMMap otomatikDekontUretmisMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try { 
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_Dekont.islem_dekont_uretmismi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));
			stmt.execute();
			oMap.put("DEKONT_URETILMIS_MI", stmt.getString(1));
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap; 
	}

	@GraymoundService("BNSPR_COMMON_GET_ACIKLAMA_PR")
	public static GMMap getAciklamaPr(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;

		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_dekont.AciklamaOlustur(?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("ACK_NO"));
			stmt.setString(3, iMap.getString("P1"));
			stmt.setString(4, iMap.getString("P2"));
			stmt.setString(5, iMap.getString("P3"));
			stmt.setString(6, iMap.getString("P4"));
			
			stmt.execute();

			oMap.put("TEXT", stmt.getString(1));

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_COMMON_GET_BIREYSEL_SUBE_KODU")
	public static GMMap getGlobalBireyselSubeKodu(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("SUBE_KODU", DALUtil.callNoParameterFunction("{? = call pkg_global.Get_Bireysel_Sube}", Types.VARCHAR));
		return oMap;
	}
	
	@GraymoundService("BNSPR_COMMON_GET_RANDOM_SESSION_PREFIX")
	public static GMMap getRandomSessionPrefix(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			  Random r = new Random();
			  String token = Long.toString(Math.abs(r.nextLong()), 36);
			  oMap.put("RANDOM_SESSION_PREFIX",	token);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_COMMON_GET_GENEL_SIRA_NO")
    public static GMMap getBranchName(GMMap iMap) {
            GMMap oMap = new GMMap();
            oMap.put("SIRA_NO", DALUtil.callNoParameterFunction("{? = call pkg_genel_pr.Genel_Sira_No_Al}", Types.NUMERIC));
            return oMap;
    }
	
	@GraymoundService("BNSPR_COMMON_HESAP_SORGULA")
	public static GMMap bnsprCommonHesapSorgula(GMMap iMap) {
		log.info("bnsprCommonHesapSorgula IN : " + iMap);
		
		GMMap oMap = new GMMap();
		Connection conn = null ;
		CallableStatement stmt = null ;
		
		String call = "{call PKG_TU.WS_TU_HESAP_SORGULA(?,?,?,?,?,?)}";
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall(call);
			
			/*in parameters*/
			stmt.setLong(1, iMap.getLong("MUSTERI_NO")); //pn_musteri_no
			stmt.setString(2, iMap.getString("DOVIZ_KOD")); //ps_doviz_kod
			stmt.setString(3, iMap.getString("HESAP_NO")); //ps_hesap_no
			stmt.setString(4, iMap.getString("IBAN")); //ps_iban
			
			/*out parameters*/
			stmt.registerOutParameter(3, Types.VARCHAR); //ps_hesap_no
			stmt.registerOutParameter(4, Types.VARCHAR); //ps_iban
			stmt.registerOutParameter(5, Types.NUMERIC); //ps_response
			stmt.registerOutParameter(6, Types.VARCHAR); //ps_response_data

			stmt.execute();
			
			oMap.put("RESPONSE", stmt.getInt(5)); //ps_response  0-Error 2-success
			oMap.put("RESPONSE_DATA", stmt.getString(6)); //ps_response_data
			oMap.put("HESAP_NO" , stmt.getString(3)); //ps_hesap_no
			oMap.put("IBAN", stmt.getString(4)); //ps_iban
			
			log.info("bnsprCommonHesapSorgula OUT : " + oMap);
			
			return oMap;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw ExceptionHandler.convertException(e,false);
			
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_COMMON_GET_KULLANICI_SUBE_KOD")
	public static GMMap getKullaniciSubeKod(GMMap iMap) {
		try {
			iMap.put("SUBE_KODU", DALUtil.getResult("select k.sube_kod from gnl_kullanici k where k.kod = pkg_global.GET_KULLANICIKOD"));
			return iMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	/**
	 * @Description: Musteri no ile KMH Sorgular KMH_VAR="E"(kmh var) KMH_VAR"H"(kmh yok) KMH E ise bakiye doner.
	 * 
	 * {@link BNSPRCalikusu:tr.com.aktifbank.calikusu.services.CLKSSMSHandler#otpRequest(GMMap)}
	 *
	 */
	@GraymoundService("CLKS_KMH_SORGULA")
	public static GMMap kmhSorgula(GMMap iMap){
		GMMap oMap =new GMMap();
		
		Connection conn = null;
		CallableStatement stmt = null;

		try {

			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{call PKG_KMH_UTIL.Musteri_OTP_KMH_Hesap_Bakiye(?,?,?)}");
			
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.execute();
			
			oMap.put("KMH_VAR", stmt.getString(2));
			oMap.put("BAKIYE", stmt.getBigDecimal(3));
			
			return oMap;
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
	
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
	
		}
		
	}
	@GraymoundService("BNSPR_COMMON_GET_ACCOUNT_LIST")
	public static GMMap commonGetAccountList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_current_accounts.RC_VARLIK_HESAP_LISTE(?,?)}");
			int i=1;
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, BigDecimal.ONE);//
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			oMap.putAll(DALUtil.rSetResults(rSet, "ACCOUNT_LIST"));
//			i=0;
//			int tableSize= oMap.getSize("ACCOUNT_LIST");
//			while(i<tableSize){
//				if()
//			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_COMMON_GET_ACCOUNT_LIST_ALL")
	public static GMMap commonGetAccountListAll(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_current_accounts.RC_VARLIK_HESAP_LISTE_TUM(?,?)}");
			int i=1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, BigDecimal.ONE);//
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			oMap.putAll(DALUtil.rSetResults(rSet, "ACCOUNT_LIST"));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	/**
	 * 
	 * Calculates days difference by subtracting FIRST_DATE from SECOND_DATE ( SECOND_DATE - FIRST_DATE )
	 * 
	 * @param iMap { FIRST_DATE, SECOND_DATE }
	 * @return oMap { DAYS }
	 */
	@GraymoundService("BNSPR_COMMON_GUN_FARKI_HESAPLA")
	public static GMMap gunFarkiHesapla(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TARIH.GUN_FARKI_BUL(?,?)}");
			
			int i = 1;
			stmt.registerOutParameter(i++, Types.NUMERIC);
			stmt.setDate(i++, iMap.getDate("FIRST_DATE") != null ? new java.sql.Date(iMap.getDate("FIRST_DATE").getTime()) : null);
			stmt.setDate(i++, iMap.getDate("SECOND_DATE") != null ? new java.sql.Date(iMap.getDate("SECOND_DATE").getTime()) : null);
			stmt.execute();
			
			oMap.put("DAYS", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	/**
	 * 
	 * @param iMap
	 * 			-BLOKE_REF_NO
	 * 				or
	 * 			-INTERNAL_REF_NO
	 * @return
	 * 		oMap
	 * 			-BLOKE_DURUM (A:Acik, K:Kapali)
	 */
	@GraymoundService("BNSPR_COMMON_GET_BLOKE_DURUM")
	public static GMMap getBlokeDurum(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			
			String refNo = "";
			if(iMap.containsKey("BLOKE_REF_NO")){
				stmt = conn.prepareCall("{? = call pkg_bloke.Sf_bloke_durum_Kodu_Al(?)}");
				refNo =  iMap.getString("BLOKE_REF_NO");
			}	
			else{
				stmt = conn.prepareCall("{? = call Pkg_bloke.sf_bloke_durum_kodu_al_ir(?)}");
				refNo =  iMap.getString("INTERNAL_REF_NO");			
			}
			int i=1;
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setString(i++, refNo);
			
			stmt.execute();
			oMap.put("BLOKE_DURUM", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_COMMON_GET_HESAP_LIST")
	public static GMMap getHesapList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		String ALL="ALL";
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_Hesap.HesapListe(?,?,?,?,?,?,?)}");
			int i = 1;
            String dovizKodu=iMap.getString("DOVIZ_KODU","NULL");
			
            
            /* Fon Hareketlerde istenen XAu ve TRY atraksiyonu yuzunden eklendi*/
			if (dovizKodu.equals(ALL)) 
			{
						stmt.registerOutParameter(i++, -10);
						stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
						stmt.setString(i++, "TRY");
						stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
						stmt.setString(i++, null);
						stmt.setString(i++, iMap.getString("HESAP_KISIT_FLAG"));
						stmt.setString(i++, iMap.getString("GORUNTULE_KONTROL"));
						stmt.setString(i++, iMap.getString("DURUM", "A"));
						stmt.execute();
			
						stmt.getMoreResults();
						rSet = (ResultSet) stmt.getObject(1);
			
						String tableName = getTableName(iMap);

					int row = 0;
					while (rSet.next()) {
						int j = 1;
						oMap.put(tableName, row, "HESAP_NO", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "RUMUZ", rSet.getString(j++));
						oMap.put(tableName, row, "HESAP_TIPI", rSet.getString(j++));
						oMap.put(tableName, row, "DOVIZ_KODU", rSet.getString(j++));
						oMap.put(tableName, row, "SUBE", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "SUBE_ADI", rSet.getString(j++));
						oMap.put(tableName, row, "BAKIYE", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "KULLANILABILIR_BAKIYE", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "KMH_LIMIT", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "BASIM_DOVIZ_KODU", rSet.getString(j++));
						oMap.put(tableName, row, "HESAP_KISIT_KODU", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "IBAN", rSet.getString(j++));
						String hesapHareketKodu = rSet.getString(j++);
						oMap.put(tableName, row, "BORC_ALACAK_GIRILEMEZ", "4".equals(hesapHareketKodu));
						oMap.put(tableName, row, "DURUM", rSet.getString(j++));
						oMap.put(tableName, row, "KMH_EH", rSet.getString(j++));
						oMap.put(tableName, row, "HESAP_HAREKET_KODU", hesapHareketKodu);
						oMap.put(tableName, row, "TOPUP_BAKIYE", rSet.getString(j++));
						oMap.put(tableName, row, "INTERNET_GORUNTULE", rSet.getString(j++));
						oMap.put(tableName, row, "OTOMATIK_FON", rSet.getString(j++));
						oMap.put(tableName, row, "F_MUSTERI_BLOKE", rSet.getString(j++));
	                    oMap.put(tableName, row, "BLOKE_TUTARI", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "GENEL_KMH_LIMIT", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "ORTAKLIK_TURU", rSet.getBigDecimal(j++));
						row++;
					}
					GMServerDatasource.close(rSet);
					
					int k = 1;
					stmt2 = conn.prepareCall("{? = call Pkg_Hesap.HesapListe(?,?,?,?,?,?,?)}");
					stmt2.registerOutParameter(k++, -10);
					stmt2.setBigDecimal(k++, iMap.getBigDecimal("MUSTERI_NO"));
					stmt2.setString(k++, "XAU");
					stmt2.setBigDecimal(k++, iMap.getBigDecimal("HESAP_NO"));
					stmt2.setString(k++, null);
					stmt2.setString(k++, iMap.getString("HESAP_KISIT_FLAG"));
					stmt2.setString(k++, iMap.getString("GORUNTULE_KONTROL"));
					stmt2.setString(k++, iMap.getString("DURUM", "A"));
					stmt2.execute();
		
					stmt2.getMoreResults();
					rSet = (ResultSet) stmt2.getObject(1);
		
				while (rSet.next()) {
					int j = 1;
					oMap.put(tableName, row, "HESAP_NO", rSet.getBigDecimal(j++));
					oMap.put(tableName, row, "RUMUZ", rSet.getString(j++));
					oMap.put(tableName, row, "HESAP_TIPI", rSet.getString(j++));
					oMap.put(tableName, row, "DOVIZ_KODU", rSet.getString(j++));
					oMap.put(tableName, row, "SUBE", rSet.getBigDecimal(j++));
					oMap.put(tableName, row, "SUBE_ADI", rSet.getString(j++));
					oMap.put(tableName, row, "BAKIYE", rSet.getBigDecimal(j++));
					oMap.put(tableName, row, "KULLANILABILIR_BAKIYE", rSet.getBigDecimal(j++));
					oMap.put(tableName, row, "KMH_LIMIT", rSet.getBigDecimal(j++));
					oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
					oMap.put(tableName, row, "BASIM_DOVIZ_KODU", rSet.getString(j++));
					oMap.put(tableName, row, "HESAP_KISIT_KODU", rSet.getBigDecimal(j++));
					oMap.put(tableName, row, "IBAN", rSet.getString(j++));
					String hesapHareketKodu = rSet.getString(j++);
					oMap.put(tableName, row, "BORC_ALACAK_GIRILEMEZ", "4".equals(hesapHareketKodu));
					oMap.put(tableName, row, "DURUM", rSet.getString(j++));
					oMap.put(tableName, row, "KMH_EH", rSet.getString(j++));
					oMap.put(tableName, row, "HESAP_HAREKET_KODU", hesapHareketKodu);
                    oMap.put(tableName, row, "TOPUP_BAKIYE", rSet.getString(j++));
                    oMap.put(tableName, row, "INTERNET_GORUNTULE", rSet.getString(j++));
                    oMap.put(tableName, row, "OTOMATIK_FON", rSet.getString(j++));
					oMap.put(tableName, row, "F_MUSTERI_BLOKE", rSet.getString(j++));
                    oMap.put(tableName, row, "BLOKE_TUTARI", rSet.getBigDecimal(j++));
					oMap.put(tableName, row, "GENEL_KMH_LIMIT", rSet.getBigDecimal(j++));
					oMap.put(tableName, row, "ORTAKLIK_TURU", rSet.getBigDecimal(j++));
					row++;
				}
			}
			
			GMServerDatasource.close(rSet);
		
            
			if (!dovizKodu.equals(ALL)) 
			{
						stmt.registerOutParameter(i++, -10);
						stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
						stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
						stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
						stmt.setString(i++, null);
						stmt.setString(i++, iMap.getString("HESAP_KISIT_FLAG"));
						stmt.setString(i++, iMap.getString("GORUNTULE_KONTROL"));
						stmt.setString(i++, iMap.getString("DURUM", "A"));
						stmt.execute();
			
						stmt.getMoreResults();
						rSet = (ResultSet) stmt.getObject(1);
			
						String tableName = getTableName(iMap);

					int row = 0;
					while (rSet.next()) {
						int j = 1;
						oMap.put(tableName, row, "HESAP_NO", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "RUMUZ", rSet.getString(j++));
						oMap.put(tableName, row, "HESAP_TIPI", rSet.getString(j++));
						oMap.put(tableName, row, "DOVIZ_KODU", rSet.getString(j++));
						oMap.put(tableName, row, "SUBE", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "SUBE_ADI", rSet.getString(j++));
						oMap.put(tableName, row, "BAKIYE", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "KULLANILABILIR_BAKIYE", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "KMH_LIMIT", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "BASIM_DOVIZ_KODU", rSet.getString(j++));
						oMap.put(tableName, row, "HESAP_KISIT_KODU", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "IBAN", rSet.getString(j++));
						String hesapHareketKodu = rSet.getString(j++);
						oMap.put(tableName, row, "BORC_ALACAK_GIRILEMEZ", "4".equals(hesapHareketKodu));
						oMap.put(tableName, row, "DURUM", rSet.getString(j++));
						oMap.put(tableName, row, "KMH_EH", rSet.getString(j++));
                        oMap.put(tableName, row, "TOPUP_BAKIYE", rSet.getString(j++));
                        oMap.put(tableName, row, "INTERNET_GORUNTULE", rSet.getString(j++));
                        oMap.put(tableName, row, "OTOMATIK_FON", rSet.getString(j++));
						oMap.put(tableName, row, "HESAP_HAREKET_KODU", hesapHareketKodu);
						oMap.put(tableName, row, "F_MUSTERI_BLOKE", rSet.getString(j++));
	                    oMap.put(tableName, row, "BLOKE_TUTARI", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "GENEL_KMH_LIMIT", rSet.getBigDecimal(j++));
						oMap.put(tableName, row, "ORTAKLIK_TURU", rSet.getBigDecimal(j++));
						row++;
					}
			}
			
			
			if (iMap.getBigDecimal("HESAP_NO") != null)
				oMap.putAll(GMServiceExecuter.execute("INTERNET_GET_IBAN", iMap));
		
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_COMMON_GET_AKTIF_HESAP")
	public static GMMap getHesapAktifHesap(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap inMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		BigDecimal hesapNo = BigDecimal.ZERO;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{?=call PKG_HESAP.Aktif_Fon_Hesap(?)}"); 
	        
	        int i = 1; 
	        stmt.registerOutParameter(i++, Types.BIGINT);
	        stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
	        stmt.execute(); 
	        
	        if (stmt.getBigDecimal(1) !=null && stmt.getBigDecimal(1) != BigDecimal.ZERO){
	        	hesapNo = stmt.getBigDecimal(1);
	        	//inMap.put("MUSTERI_NO",iMap.getBigDecimal("MUSTERI_NO"));
	        	inMap.put("HESAP_NO", hesapNo);
	        	oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_HESAP_LIST", inMap));
	        }
	        else{
	        	throwGMBusssinessException("Aktif Hesap Bulunamad�");
	        }
	        	
			
			return oMap;
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static GMMap throwGMBusssinessException(String string) {				
		GMMap exMap = new GMMap();
		exMap.put("P1", string);
		exMap.put("HATA_NO", "660");
		return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", exMap);
	}
	
	@GraymoundService("BNSPR_DEKONT_NUMARASI_VER")
	public static GMMap otomatikDekontNoVer(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try { 
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call Pkg_Dekont.islem_dekont_no_ver(?,?)}");
			int i = 1;
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));
			stmt.setDate(i++, iMap.getDate("TARIH") != null ? new java.sql.Date(iMap.getDate("TARIH").getTime()) : null);
			 
			stmt.execute();
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap; 
	}
	
	   @GraymoundService("BNSPR_COMMON_GET_HESAP_HAREKET_LIST")
	    public static GMMap getHesapHareketList(GMMap iMap) {

	        Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;
	        try {
	            conn = DALUtil.getGMConnection();

	            stmt = conn.prepareCall("{? = call Pkg_hesap.HesapHareket(?,?,?,?,?,?,?,?)}");

	            int i = 1;
	            stmt.registerOutParameter(i++, -10);
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
	            if (iMap.get("BASLANGIC_TARIHI") != null)
	                stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TARIHI").getTime()));
	            else
	                stmt.setDate(i++, null);
	            if (iMap.get("BITIS_TARIHI") != null)
	                stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TARIHI").getTime()));
	            else
	                stmt.setDate(i++, null);
	            stmt.setString(i++, iMap.getString("ISLEM_TIPI"));
	            stmt.setString(i++, iMap.getString("KANAL_TIPI"));
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_TUTAR"));
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_TUTAR"));
	            stmt.setString(i++, iMap.getString("LANGUAGE"));

	            stmt.execute();
	            stmt.getMoreResults();
	            rSet = (ResultSet) stmt.getObject(1);
	            GMMap oMap = DALUtil.rSetResults(rSet, BnsprCommonFunctions.getTableName(iMap));
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {
	            GMServerDatasource.close(rSet);
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }
    
	@GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_FUND_LIST")
    public static GMMap getFundList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        PreparedStatement stmt2 = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_FON_WRAPPER.Fon_Fiyat_List(?,?)}");
            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setObject(i++, getTarih(iMap.getString("PROCESS_TYPE")));
            stmt.setString(i++, iMap.getString("FUND_CODE"));
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);

            String tableName = iMap.getString("TABLE_NAME");
            GMMap serviceOutMap = DALUtil.rSetResults(rSet, tableName);
            int size = serviceOutMap.getSize(tableName);
            for (i = 0; i < size; i++) {
                oMap.put(tableName, i, "MAT_SIRA_NO", serviceOutMap.get(tableName, i, "MAT_SIRA_NO"));
                oMap.put(tableName, i, "ALIS_FIYATI", serviceOutMap.get(tableName, i, "ALIS_FIYATI"));
                oMap.put(tableName, i, "SATIS_FIYATI", serviceOutMap.get(tableName, i, "SATIS_FIYATI"));
                oMap.put(tableName, i, "FON_KODU", serviceOutMap.get(tableName, i, "FON_KODU"));
                oMap.put(tableName, i, "IMKB_KODU", serviceOutMap.get(tableName, i, "IMKB_KODU"));
                oMap.put(tableName, i, "STOK", serviceOutMap.get(tableName, i, "STOK"));
                oMap.put(tableName, i, "MIN_PAY", serviceOutMap.get(tableName, i, "MIN_PAY"));
                oMap.put(tableName, i, "ALT_SINIR", serviceOutMap.get(tableName, i, "ALT_SINIR"));
                oMap.put(tableName, i, "DOVIZ_KODU", serviceOutMap.get(tableName, i, "DOVIZ_KODU"));
                oMap.put(tableName, i, "FON_ADI", serviceOutMap.get(tableName, i, "FON_ADI"));
                oMap.put(tableName, i, "FON_FIYATI", serviceOutMap.get(tableName, i, "FON_FIYATI"));
            }
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(stmt2);
            GMServerDatasource.close(conn);
        }
    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_FUND_CALCULATE")
    public static GMMap fundCalculate(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        try {

            String amountUnit = iMap.getString("TUTAR_BIRIM");
            String fundCode = iMap.getString("FUND_CODE");
            String fundUnit = getFundUnit(fundCode);
            BigDecimal tempTutar;
            
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call PKG_FON_WRAPPER.Fon_Toplam_Stok(?,?)}");

            stmt.registerOutParameter(1, Types.NUMERIC);
            stmt.setString(2, iMap.getString("FUND_CODE"));
            stmt.setString(3, iMap.getString("ISLEM_TIPI"));
            
            stmt.execute();

            BigDecimal totalAmountFund = stmt.getBigDecimal(1);
             
            // likit tutar ile hesap 
            if (iMap.get("TUTAR") != null &&  !fundUnit.trim().equals("XAU") ) {
                BigDecimal newTutar = dovizCevir(amountUnit, fundUnit, iMap.getBigDecimal("TUTAR"), null);
                iMap.put("TUTAR", newTutar);
            }
            
            // Likit adet ile hesap
            /*if (iMap.get("ADET") != null &&  !fundUnit.trim().equals("XAU") ) {
                BigDecimal newTutar = dovizCevir(fundUnit,amountUnit, iMap.getBigDecimal("ADET"), null);
                //iMap.put("TUTAR", newTutar);
            }
            */
            
            if (iMap.getString("ISLEM_TIPI").equals("G") && iMap.get("ADET") != null &&  fundUnit.trim().equals("XAU")) {
                BigDecimal newTutar = dovizCevir(fundUnit, amountUnit, iMap.getBigDecimal("ADET"), null);
                iMap.put("TUTAR", newTutar);
                BigDecimal newAdet = dovizCevir(amountUnit, fundUnit, iMap.getBigDecimal("TUTAR"), null);
                iMap.put("ADET", newAdet);
            }
            
            if (iMap.getString("ISLEM_TIPI").equals("F") && iMap.get("ADET") != null && fundUnit.trim().equals("XAU") ) {
                BigDecimal newTutar = dovizCevir(fundUnit, amountUnit, iMap.getBigDecimal("ADET"), null);
                iMap.put("TUTAR", newTutar);
                BigDecimal newAdet = dovizCevir(amountUnit, fundUnit, iMap.getBigDecimal("TUTAR"), null);
                iMap.put("ADET", newAdet);
            
                oMap.put("TUTAR", newTutar);
                oMap.put("GRAM_KARSILIK", newAdet);
                oMap.put("DOVIZ_KODU", amountUnit);
            }

            stmt = conn.prepareCall("{call PKG_FON_WRAPPER.Fon_Tutar_Adet_Kontrol(?,?,?,?,?,?,?,?,?,?,?)}");

            stmt.setString(1, iMap.getString("ISLEM_TIPI"));
            stmt.setBigDecimal(2, iMap.getBigDecimal("HESAP_NO"));
            stmt.setBigDecimal(3, iMap.getBigDecimal("KAT"));
            stmt.setBigDecimal(4, iMap.getBigDecimal("ALT_SINIR"));
            stmt.setBigDecimal(5, totalAmountFund==null?totalAmountFund:iMap.getBigDecimal("ANLIK_STOK"));
            stmt.setInt(6, iMap.getInt("MAT_SIRA_NO"));
            stmt.setBigDecimal(7, iMap.getBigDecimal("FIYAT"));
            stmt.setString(8, iMap.getString("FUND_CODE"));
            
            BigDecimal adet=iMap.getBigDecimal("ADET", BigDecimal.ZERO);
            
            if (fundUnit.trim().equals("XAU") && adet.intValue()>0)
               stmt.setBigDecimal(9,  BigDecimal.ZERO);
            else
                stmt.setBigDecimal(9, iMap.getBigDecimal("ADET"));

            tempTutar = iMap.getBigDecimal("TUTAR", BigDecimal.ZERO);
            if (tempTutar == BigDecimal.ZERO) {
                stmt.setBigDecimal(10, null);
            }

            if (tempTutar != BigDecimal.ZERO && fundUnit.trim().equals("XAU") && iMap.get("ADET") != null)
            {
                BigDecimal newTutar = dovizCevir(amountUnit,fundUnit, tempTutar, null);             
                stmt.setBigDecimal(10, newTutar);               
            }
            
            if (tempTutar != BigDecimal.ZERO && fundUnit.trim().equals("XAU") && iMap.get("TUTAR") != null)
            {               
                BigDecimal newTutar = dovizCevir(amountUnit,fundUnit,iMap.getBigDecimal("TUTAR"), null);                           
                stmt.setBigDecimal(10, newTutar);                       
            }
            
            if (tempTutar != BigDecimal.ZERO && !fundUnit.trim().equals("XAU"))
            {
                stmt.setBigDecimal(10, iMap.getBigDecimal("TUTAR", BigDecimal.ZERO));
            }

            stmt.registerOutParameter(9, Types.NUMERIC);
            stmt.registerOutParameter(10, Types.NUMERIC);

            stmt.setBigDecimal(11, BigDecimal.ONE);
            stmt.execute();

            oMap.put("ADET", stmt.getBigDecimal(9));

            BigDecimal calculated = stmt.getBigDecimal(10);
            
            stmt.setString(1, iMap.getString("ISLEM_TIPI"));
            stmt.setBigDecimal(2, iMap.getBigDecimal("HESAP_NO"));
            stmt.setBigDecimal(3, iMap.getBigDecimal("KAT"));
            stmt.setBigDecimal(4, null);// iMap.getBigDecimal("MIN_PAY"));
            stmt.setBigDecimal(5, totalAmountFund==null?totalAmountFund:iMap.getBigDecimal("ANLIK_STOK"));
            stmt.setInt(6, iMap.getInt("MAT_SIRA_NO"));
            stmt.setBigDecimal(7, iMap.getBigDecimal("FIYAT"));
            stmt.setString(8, iMap.getString("FUND_CODE"));
            
            adet=oMap.getBigDecimal("ADET", BigDecimal.ZERO);
            
            if (fundUnit.trim().equals("XAU") && adet.intValue()>0)         
            {
                stmt.setBigDecimal(9, oMap.getBigDecimal("ADET", BigDecimal.ZERO));
                stmt.setBigDecimal(10, null);
            }

            stmt.registerOutParameter(9, Types.NUMERIC);
            stmt.registerOutParameter(10, Types.NUMERIC);

            stmt.setBigDecimal(11, BigDecimal.ONE);
            stmt.execute();

            oMap.put("ADET", stmt.getBigDecimal(9));

            calculated = stmt.getBigDecimal(10);

            if (!fundUnit.trim().equals(amountUnit)) {
                BigDecimal newTutar = dovizCevir(fundUnit, amountUnit, calculated, null);
                oMap.put("TUTAR", newTutar);
                oMap.put("GRAM_KARSILIK", calculated);
                oMap.put("DOVIZ_KODU", amountUnit);
            }
            else {
                oMap.put("TUTAR", stmt.getBigDecimal(10));
                oMap.put("DOVIZ_KODU", amountUnit);
            }

            return oMap;
        }
        catch (Exception e) {
            log.error("INTERNET_FON_TUTAR_HESAPLA", e);
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }

    private static BigDecimal dovizCevir(String fromDoviz, String toDoviz, BigDecimal tutar, String alisSatis) throws SQLException {

        Connection conn = null;
        CallableStatement stmt = null;
        BigDecimal returnVal = null;

        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_kur.doviz_cevir(?,?,?,?,?,?,?,?,?)}");

            int i = 1;

            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.setString(i++, fromDoviz);
            stmt.setString(i++, toDoviz);
            stmt.setNull(i++, Types.DATE);
            stmt.setBigDecimal(i++, tutar);
            stmt.setNull(i++, Types.NUMERIC);
            stmt.setNull(i++, Types.NUMERIC);
            stmt.setNull(i++, Types.NUMERIC);
            stmt.setNull(i++, Types.VARCHAR);
            if (alisSatis == null || alisSatis.trim().length() == 0) {
                stmt.setNull(i++, Types.VARCHAR);
            }
            else {
                stmt.setString(i++, alisSatis);
            }

            stmt.execute();

            returnVal = stmt.getBigDecimal(1);

        }
        finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }

        return returnVal;
    }

    private static String getFundUnit(String imkbCode) {
        Session session = DAOSession.getSession("BNSPRDal");
        Query q = session.createSQLQuery("SELECT doviz_kodu FROM fon_tanim WHERE imkb_kodu = :imkb ");
        q.setParameter("imkb", imkbCode);

        List<?> l = q.list();

        if (l != null && !l.isEmpty()) {
            return l.get(0).toString().trim();
        }

        return null;
    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_LIST_CUSTOMER_FUNDS")
    public static GMMap listCustomerFunds(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_FON_WRAPPER.HesapListe(?,?,?,?,?,?,?)}");
            int i = 1;

            stmt.registerOutParameter(i++, -10);
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
            stmt.setString(i++, null);
            stmt.setString(i++, iMap.getString("HESAP_KISIT_FLAG"));
            stmt.setString(i++, iMap.getString("GORUNTULE_KONTROL"));
            stmt.setString(i++, iMap.getString("ISLEM_TIPI"));
            
            stmt.execute();

            stmt.getMoreResults();
            rSet = (ResultSet) stmt.getObject(1);

            GMMap oMap = new GMMap();
            String tableName = BnsprCommonFunctions.getTableName(iMap);

            int row = 0;
            while (rSet.next()) {
                int j = 1;
                oMap.put(tableName, row, "HESAP_NO", rSet.getBigDecimal(j++));
                oMap.put(tableName, row, "RUMUZ", rSet.getString(j++));
                oMap.put(tableName, row, "HESAP_TIPI", rSet.getString(j++));
                oMap.put(tableName, row, "DOVIZ_KODU", rSet.getString(j++));
                oMap.put(tableName, row, "SUBE", rSet.getBigDecimal(j++));
                oMap.put(tableName, row, "SUBE_ADI", rSet.getString(j++));
                oMap.put(tableName, row, "BAKIYE", rSet.getBigDecimal(j++));
                oMap.put(tableName, row, "KULLANILABILIR_BAKIYE", rSet.getBigDecimal(j++));
                oMap.put(tableName, row, "KMH_LIMIT", rSet.getBigDecimal(j++));
                oMap.put(tableName, row, "MUSTERI_NO", rSet.getBigDecimal(j++));
                oMap.put(tableName, row, "BASIM_DOVIZ_KODU", rSet.getString(j++));
                oMap.put(tableName, row, "HESAP_KISIT_KODU", rSet.getBigDecimal(j++));
                oMap.put(tableName, row, "FON_ADET", rSet.getBigDecimal(j++));
                oMap.put(tableName, row, "FON_NET_DEGER", rSet.getBigDecimal(j++));
                oMap.put(tableName, row, "FON_BIRIM_FIYAT", rSet.getBigDecimal(j++));
                oMap.put(tableName, row, "FON_KODU", rSet.getString(j++));
                oMap.put(tableName, row, "FON_ADI", rSet.getString(j++));
                oMap.put(tableName, row, "FON_DOVIZ_KODU", rSet.getString(j++));
                oMap.put(tableName, row, "IMKB_KODU", rSet.getString(j++));

                row++;
            }
            return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_FUND_TYPES")
    public static GMMap getFundTypes(GMMap iMap) {
        GMMap oMap = new GMMap();

        Session session = DAOSession.getSession("BNSPRDal");
        Query q = session.createSQLQuery("SELECT kod, aciklama, imkb_kodu, doviz_kodu FROM fon_tanim where imkb_kodu is not null");
        
        @SuppressWarnings("unchecked")
        List<Object[]> list = q.list();
        
        String tableName = BnsprCommonFunctions.getTableName(iMap);
        int i = 0;
        for (Object[] row : list) {
            oMap.put(tableName, i, "FUND_CODE", row[0]);
            oMap.put(tableName, i, "FUND_NAME", row[1]);
            oMap.put(tableName, i, "IMKB_CODE", row[2]);
            oMap.put(tableName, i, "CURRENCY_CODE", row[3]);
            i++;
        }
        
        return oMap;
    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_PROFIT_LIST")
    public static GMMap getProfitList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        GMMap i2Map = new GMMap();
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_RC2103.Get_Fon_Getiri_Bilgileri(?,?,?)}");

            int i = 1;
            stmt.registerOutParameter(i++, -10);
            i2Map.put("TARIH", iMap.getDate("BASLANGIC_TARIHI"));
            stmt.setDate(i++, new java.sql.Date((GMServiceExecuter.call("INTERNET_TATILSE_ILERI_IS_GUNU", i2Map).getDate("TARIH")).getTime()));
            i2Map.put("TARIH", iMap.getDate("BITIS_TARIHI"));
            stmt.setDate(i++, new java.sql.Date((GMServiceExecuter.call("INTERNET_TATILSE_ILERI_IS_GUNU", i2Map).getDate("TARIH")).getTime()));
            stmt.setString(i++, iMap.getString("FUND_CODE"));
            stmt.execute();

            String tableName = BnsprCommonFunctions.getTableName(iMap);

            rSet = (ResultSet) stmt.getObject(1);
            oMap.putAll(DALUtil.rSetResults(rSet, tableName));

        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_LIST_CUSTOMER_TRANSACTIONS")
    public static GMMap listCustomerTransactions(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_RC2103.Get_Fon_Hareket_Bilgileri(?,?,?,?,?,?)}");

            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setString(i++, iMap.getString("FON_TIPI"));
            stmt.setString(i++, iMap.getString("ISLEM_TIPI"));
            stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TARIHI").getTime()));
            stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TARIHI").getTime()));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));

            stmt.execute();

            rSet = (ResultSet) stmt.getObject(1);
            oMap.putAll(DALUtil.rSetResults(rSet, "TRANSACTION_LIST"));

        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_BUY_FUND_FROM_CUSTOMER")
    public static GMMap buyFundFromCustomer(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            iMap.put("ALIM_SATIM", "A");
            iMap.put("TRX_NAME", "2105");

            String amountUnit = iMap.getString("TUTAR_BIRIM");
            String fundCode = iMap.getString("IMKB_CODE");
            String fundUnit = getFundUnit(fundCode);

            if (iMap.get("TUTAR") != null && !fundUnit.trim().equals(amountUnit) ) {
                BigDecimal newTutar = dovizCevir(amountUnit, fundUnit, iMap.getBigDecimal("TUTAR"), null);
                iMap.put("ALINAN_MIKTAR", newTutar);
            }
            else if (iMap.get("TUTAR") != null) {
                iMap.put("ALINAN_MIKTAR", iMap.get("TUTAR"));
            }

            oMap.putAll(GMServiceExecuter.execute("BNSPR_CURRENT_ACCOUNTS_BUY_SELL_FUND", iMap));
            return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_SELL_FUND_TO_CUSTOMER")
    public static GMMap sellFundToCustomer(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            iMap.put("ALIM_SATIM", "S");
            iMap.put("TRX_NAME", "2106");

            String amountUnit = iMap.getString("TUTAR_BIRIM");
            String fundCode = iMap.getString("IMKB_CODE");
            String fundUnit = getFundUnit(fundCode);

            if (iMap.get("TUTAR") != null && !fundUnit.trim().equals(amountUnit)) {
                BigDecimal newTutar = dovizCevir(amountUnit, fundUnit, iMap.getBigDecimal("TUTAR"), null);
                iMap.put("ALINAN_MIKTAR", newTutar);
            }
            else if (iMap.get("TUTAR") != null) {
                iMap.put("ALINAN_MIKTAR", iMap.get("TUTAR"));
            }

            oMap.putAll(GMServiceExecuter.execute("BNSPR_CURRENT_ACCOUNTS_BUY_SELL_FUND", iMap));
            return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_BUY_SELL_FUND")
    public static GMMap buySellFund(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            Session session = DAOSession.getSession("BNSPRDal");

            BigDecimal muhasebeTutari = iMap.get("MUHASEBE_TUTAR") != null
                                                         ? iMap.getBigDecimal("MUHASEBE_TUTAR")
                                                         :iMap.getBigDecimal("TUTAR")
            ;           
            FonAlimSatimTx fonAlimSatimTx = new FonAlimSatimTx();
            fonAlimSatimTx.setTxNo(GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
            fonAlimSatimTx.setAdetFiyati(iMap.getBigDecimal("BIRIM_FIYAT"));
            fonAlimSatimTx.setAlimSatim(iMap.getString("ALIM_SATIM"));
            fonAlimSatimTx.setFonKod(iMap.getString("FON_KODU"));
            if (iMap.get("DONEN_HESAP_NO") != null)
                fonAlimSatimTx.setHesapNo(iMap.getBigDecimal("DONEN_HESAP_NO"));
            else
                fonAlimSatimTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
            fonAlimSatimTx.setKanalKod(GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD", new GMMap()).getString("KANAL_KOD"));
            //fonAlimSatimTx.setKanalKod("4");
            fonAlimSatimTx.setMatSiraNo(iMap.getBigDecimal("MAT_SIRA_NO"));
            fonAlimSatimTx.setOtomatikMi("H");
            fonAlimSatimTx.setParaf((String) (GMContext.getCurrentContext().getSession().get("USER_NAME")));
            fonAlimSatimTx.setPayAdedi(iMap.getBigDecimal("NOMINAL"));
            fonAlimSatimTx.setSaat(getZaman());
            fonAlimSatimTx.setXauHesapNo(iMap.getBigDecimal("XAU_HESAP_NO"));
            fonAlimSatimTx.setAlinanMiktar(iMap.getBigDecimal("GRAM_KARSILIK"));
            if (iMap.getString("FON_KODU").equals("AFF")) {
                fonAlimSatimTx.setSatisCinsi(iMap.getString("ALIM_SATIM").equals("A") ? "M" : "P");
            } else {
                fonAlimSatimTx.setSatisCinsi(iMap.getString("ISLEM_TIPI"));
            }
            fonAlimSatimTx.setSubeKodu(iMap.getString("MUSTERI_SUBE"));
            if (iMap.getString("FON_KODU").equals("XAU") || iMap.getString("FON_KODU").equals("AFF")) {
                fonAlimSatimTx.setTarih(getBankaTarih());
            } else {
                fonAlimSatimTx.setTarih(getIslemTarih(iMap.getString("ALIM_SATIM").equals("A") ? "G" : "F"));
            }
            fonAlimSatimTx.setTutar(muhasebeTutari);
            fonAlimSatimTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
            fonAlimSatimTx.setOtomatikMi("H");
            fonAlimSatimTx.setValorTarihi(iMap.getDate("ISLEM_TARIHI"));

            if (iMap.getBigDecimal("VERGI_TUTARI") != null) {
                fonAlimSatimTx.setVergiTutari(iMap.getBigDecimal("VERGI_TUTARI"));
            }

            fonAlimSatimTx.setCagiranKanal(iMap.getString("CHANNEL"));      
            fonAlimSatimTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
            
            
            
            boolean isXauFundSellPhysical = "E".equals(iMap.getString("FIZIKIMI")) && "A".equals(iMap.getString("ALIM_SATIM")) && iMap.getString("FON_KODU").equals("XAU");
            
            // Fiziki teslim bilgileri
            if ( isXauFundSellPhysical ) 
            {
                FonAltinHareketTx fas = new FonAltinHareketTx();
                BigDecimal bd = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO");

                fas.setAnaIslemTx(fonAlimSatimTx.getTxNo());
                fas.setTxNo(bd);
                fas.setMusteriNo(fonAlimSatimTx.getMusteriNo());
                fas.setXauGr(iMap.getBigDecimal("SATILAN_ALTIN_MIKTARI"));
                fas.setXauHesap(iMap.getBigDecimal("XAU_HESAP_NO"));
                fas.setXauTeslimGr(iMap.getBigDecimal("FIZIKI_TESLIM_GR"));
                fas.setTlIarMasraf(iMap.getBigDecimal("FIZIKI_MASRAF_IAR"));
                fas.setTlBankaMasraf(iMap.getBigDecimal("FIZIKI_MASRAF_BANKA"));
                fas.setTlMasrafHesap(iMap.getBigDecimal("FIZIKI_MASRAF_HESAP"));
                fas.setTeslimAdres(iMap.getString("FIZIKI_TESLIM_ADRES_KOD"));
                fas.setIslemTipi("B");
                fas.setIslemYonu("S");
                fas.setStatus("1");
                session.saveOrUpdate(fas);

                fonAlimSatimTx.setFizikimi("E");
            }

            session.save(fonAlimSatimTx);
            session.flush();

            iMap.put("TRX_NO", fonAlimSatimTx.getTxNo());

            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
            
            oMap.put("TRX_NO", fonAlimSatimTx.getTxNo());
            
            
            if ( isXauFundSellPhysical )
            {
                GMMap apMap = new GMMap();
                apMap.put("MUSTERI_NO", iMap.getBigDecimal("MUSTERI_NO"));
                apMap.put("FIZIKI_TESLIM_ADRES_KOD", iMap.getString("FIZIKI_TESLIM_ADRES_KOD"));
                apMap.put("FIZIKI_TESLIM_GR", iMap.getString("FIZIKI_TESLIM_GR"));
                apMap.put("TX_NO", fonAlimSatimTx.getTxNo());
                apMap.putAll(GMServiceExecuter.execute("INTERNET_FUND_XAU_SAVE_PHYSICAL_APPOINTMENT", apMap));
            }
            
            return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }

    private static String getZaman() {
        Connection conn = null;
        CallableStatement stmt = null;
        try {
            conn = DALUtil.getGMConnection();

            stmt = conn.prepareCall("{? = call PKG_FON_JAVASP.SP_SAAT_EX()}");
            stmt.registerOutParameter(1, Types.VARCHAR);
            stmt.execute();

            return stmt.getString(1);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    private static Date getBankaTarih() {
        Connection conn = null;
        CallableStatement stmt = null;
        try {
            conn = DALUtil.getGMConnection();

            stmt = conn.prepareCall("{? = call pkg_muhasebe.Banka_Tarihi_Bul(?)}");
            stmt.registerOutParameter(1, Types.DATE);
            stmt.setString(2, "CLK");
            stmt.execute();
            

            return stmt.getDate(1);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }

    private static Date getIslemTarih(String islemTipi) {
        Connection conn = null;
        CallableStatement stmt = null;
        try {
            conn = DALUtil.getGMConnection();

            stmt = conn.prepareCall("{? = call PKG_FON_JAVASP.ISLEM_TARIH_AL(?)}");
            stmt.registerOutParameter(1, Types.DATE);
            stmt.setString(2, islemTipi);
            stmt.execute();

            return stmt.getDate(1);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_BALANCE_CONTROL")
    public static GMMap balanceControl(GMMap iMap) {

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_EXTERNAL.Bakiye_Kontrol(?,?,?)}");

            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setString(i++, iMap.getString("PROCESS_CODE"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("ACCOUNT_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("AMOUNT"));

            stmt.execute();

            rSet = (ResultSet) stmt.getObject(1);
            oMap.putAll(DALUtil.rSetResults(rSet, "TABLE"));

        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    
    }
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_TRANSFER_COMMISION")
    public static GMMap getTransferCommision(GMMap iMap) {

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call Pkg_masraf_yeni.kanal_masraf_hesapla(?,?,?,?,?,?,?,?)}");

            int i = 1;
            stmt.setString(i++, iMap.getString("SCREEN_CODE"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("AMOUNT"));
            stmt.setString(i++, iMap.getString("CURRENCY_CODE"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("CUSTOMER_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("F_ACCOUNT_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("T_ACCOUT_NO"));

            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.registerOutParameter(i++, Types.NUMERIC);

            stmt.execute();

            oMap.put("TOTAL_COMMISION", stmt.getBigDecimal(7));
            oMap.put("TOTAL_TAX", stmt.getBigDecimal(8));

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }

    }
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_RECORDED_FAST_TRANSFER_LIST")
    public static GMMap getRecordedFastTransferList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_External.Hizli_HAVALE_Liste(?,?,?) }");

            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("RUMUZ_ID"));
            stmt.setString(i++, iMap.getString("PTT_EH", "H"));
            stmt.execute();

            rSet = (ResultSet) stmt.getObject(1);

            String tableName = "HIZLI_HAVALE_LIST";

            return DALUtil.rSetResults(rSet, tableName);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_TRANSFER_DIRECTIVE_LIST")
    public static GMMap getTransferDirectiveList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call pkg_external.kayitli_havale_talimat_liste(?, ?)}");
            stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setBigDecimal(3, iMap.getBigDecimal("HAVALE_TALIMAT_TIPI"));
            stmt.registerOutParameter(1, -10);
            stmt.execute();

            stmt.getMoreResults();
            rSet = (ResultSet) stmt.getObject(1);
            String tableName = BnsprCommonFunctions.getTableName(iMap);

            return DALUtil.rSetResults(rSet, tableName);

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_SAVE_TRANSFER")
    public static GMMap saveTransfer(GMMap iMap) {

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            setBranchCode(iMap.getString("GONDEREN_HESAP_NO"));

            GMMap oMap = new GMMap();

            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call Pkg_External.HAVALE_Giris_Initials(?,?,?,?,?,?,?,?,?,?,?,?,?)}");

            int i = 1;

            if (iMap.containsKey("EKSTRE_MUSTERI_NO"))
                stmt.setBigDecimal(i++, iMap.getBigDecimal("EKSTRE_MUSTERI_NO"));
            else
                stmt.setBigDecimal(i++, iMap.getBigDecimal("GONDEREN_MUSTERI_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("GONDEREN_HESAP_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("ALICI_HESAP_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR"));
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.setString(i++, iMap.getString("PS_URUN_SINIF"));

            stmt.execute();

            i = 5;

            iMap.put("TRX_NO", stmt.getBigDecimal(i++));
            iMap.put("DOVIZ_KODU", stmt.getString(i++));
            iMap.put("GONDEREN_ISIM_UNVAN", stmt.getString(i++));
            iMap.put("GONDEREN_ADRES", stmt.getString(i++));
            iMap.put("GONDEREN_TEL_NO", stmt.getString(i++));
            if (!iMap.containsKey("MASRAF_TUTARI")) // E-Kent kart �demelerinden al�nacak masraf int.bankac�l���nda set ediliyor
                iMap.put("MASRAF_TUTARI", stmt.getBigDecimal(i++));
            else
                i++;
            iMap.put("REFERANS", stmt.getString(i++));
            iMap.put("ALICI_MUSTERI_NO", stmt.getBigDecimal(i++));

            iMap.put("URUN_TUR", "HAVALEHESP");
            if (iMap.getBigDecimal("HAVALE_TIPI").compareTo(new BigDecimal(1)) == 0)
                iMap.put("URUN_SINIF", "HESABA");
            else if (iMap.getBigDecimal("HAVALE_TIPI").compareTo(new BigDecimal(2)) == 0)
                iMap.put("URUN_SINIF", "ISME");
            else if (iMap.getBigDecimal("HAVALE_TIPI").compareTo(new BigDecimal(3)) == 0) {
                iMap.put("ALICI_SUBE", getPttSubeKod());
                iMap.put("URUN_SINIF", "PTT");
            }

            iMap.put("TALIMAT_FORMU", "H");
            iMap.put("MASRAF_TAHSIL_DOVIZ", iMap.getString("DOVIZ_KODU"));
            iMap.put("MASRAF_TAHSIL_SEKLI", "HAVALEHESP");
            iMap.put("MASRAF_HESAP_NO", iMap.getBigDecimal("GONDEREN_HESAP_NO"));
            iMap.put("MASRAF_TUTARI_MAS_DVZ", iMap.getBigDecimal("MASRAF_TUTARI"));
            iMap.put("MASRAF_IC_DIS", "D");
            iMap.put("KASA_KIMLIK_TIPI", "1");

            oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
            oMap.put("REFERANS", iMap.getString("REFERANS"));
            oMap.put("GONDERIM_AMACI", iMap.getString("GONDERIM_AMACI"));
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2030_SAVE_SUBELERARASI_HAVALE", iMap));
            return oMap;

        } catch (Exception e) {
            return throwGMBusssinessException(e.getMessage());
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_SAVE_TRANSFER_DIRECTIVE")
    public static GMMap saveTransferDirective(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        Connection conn = null;
        CallableStatement stmt = null;
        try {
            setBranchCode(iMap.getString("GON_HESAP_NO"));
            conn = DALUtil.getGMConnection();
            iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2301_SAVE_DUZENLI_ODEME", iMap));
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_DELETE_TRANSFER_DIRECTIVE")
    public static GMMap deleteTransferDirective(GMMap iMap) {
        GMMap oMap = new GMMap();
        
        try {
            iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2302_SAVE_DUZENLI_ODEME_IPTAL", iMap));
            
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_DELETE_FUTURE_DATE_TRANSFER")
    public static GMMap deleteFutureDateTransfer(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        GMMap oMap = new GMMap();
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ call Pkg_TRN2030.Islem_Iptal(?)}");
            stmt.setString(1, iMap.getString("HAVALE_ID"));
            stmt.execute();
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }

    }

    
    public static void setBranchCode(String accountNo) throws Exception {
        try {
        	BnsprCommonFunctions.setBranchCode(accountNo);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
        }
    }
    
    
    private static String getPttSubeKod() {
        try {
            String subeKodu = (String) DALUtil.callOneParameterFunction("{? = call pkg_hesap.sube_kodu(?)}", Types.VARCHAR, (String) DALUtil.callOneParameterFunction("{? = call pkg_ptt.ptt_hesap(?)}", Types.VARCHAR, "TRY"));
            return subeKodu;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_RECORDED_TRANSFER_DIRECTIVE_PAYMENT_PLAN")
    public static GMMap getRecordedTransferDirectivePaymentPlan(GMMap iMap) {

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_external.kayitli_havale_odeme_plani(?)}");
            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setBigDecimal(i++, iMap.getBigDecimal("DRT_ID"));
            stmt.execute();
            stmt.getMoreResults();
            rSet = (ResultSet) stmt.getObject(1);
            String tableName = "TABLE";
            return DALUtil.rSetResults(rSet, tableName);

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }

    }
    
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_CONSTRUCT_PAYMENT_PLAN")
    public static GMMap constructPaymentPlan(GMMap iMap) {
       String DIRECTIVE_TYPE_REGULAR        = "1";
       String DIRECTIVE_TYPE_IRREGULAR      = "2";
       
       String DIRECTIVE_END_TYPE_DATE       = "DATE";
       String DIRECTIVE_END_TYPE_INSTALMENT = "INSTALMENT";
        
        GMMap oMap = new GMMap();
        try {
            if (iMap.getString("DRT_TYPE").equals(DIRECTIVE_TYPE_REGULAR)) {
                BigDecimal tutar = iMap.getBigDecimal("AMOUNT");
                String donemTipi = iMap.getString("PAYMENT_PERIOD"); // GUN,HAFTA,AY,YIL
                java.util.Date ilkOdemeTarihi = iMap.getDate("BEGIN_DATE");
                java.util.Date bitisTarihi = null;
                String endType = iMap.getString("END_TYPE");
                
                if (endType.equals(DIRECTIVE_END_TYPE_DATE)) {
                    bitisTarihi = iMap.getDate("END_DATE");
                }else if (endType.equals(DIRECTIVE_END_TYPE_INSTALMENT)) {
                    int numberOfInstalment = iMap.getInt("NUMBER_OF_INSTALMENT");
                    Calendar calendar = new GregorianCalendar();
                    calendar.setTime(ilkOdemeTarihi);
                    int calendarField = Calendar.MONTH;
                    if (donemTipi.equals("YIL")) {
                        calendarField = Calendar.YEAR;
                    } else if (donemTipi.equals("AY")) {
                        calendarField = Calendar.MONTH;
                    } else if (donemTipi.equals("HAFTA")) {
                        calendarField = Calendar.WEEK_OF_YEAR;
                    } else if (donemTipi.equals("GUN")) {
                        calendarField = Calendar.DAY_OF_YEAR;
                    }
                    calendar.add(calendarField, numberOfInstalment - 1);
                    bitisTarihi = calendar.getTime();
                }

                GregorianCalendar bitisTarihiCalendar = null;

                GregorianCalendar todayCalender = new GregorianCalendar();
                todayCalender.setTime(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH"));
                todayCalender.set(GregorianCalendar.MINUTE, 0);
                todayCalender.set(GregorianCalendar.SECOND, 0);
                todayCalender.set(GregorianCalendar.HOUR, 0);

                if (bitisTarihi != null) {
                    bitisTarihiCalendar = new GregorianCalendar();
                    bitisTarihiCalendar.setTime(bitisTarihi);
                }

                GregorianCalendar currentTaksitCalender = new GregorianCalendar();
                currentTaksitCalender.setFirstDayOfWeek(GregorianCalendar.MONDAY);
                GregorianCalendar calendar = new GregorianCalendar();
                calendar.setTime(ilkOdemeTarihi);
                int i = 0;
                while (!calendar.after(bitisTarihiCalendar)) {

                    currentTaksitCalender.setTime(calendar.getTime());

                    if (!isWorkDay(currentTaksitCalender.getTime())) {
                        if (iMap.getString("DAY_FOR_PROCESS") != null && iMap.getString("DAY_FOR_PROCESS").equals("O")) {
                            currentTaksitCalender.setTime(getGeriIsGunu(currentTaksitCalender.getTime()));
                            if (currentTaksitCalender.before(todayCalender))
                                currentTaksitCalender.setTime(todayCalender.getTime());
                        } else if (iMap.getString("DAY_FOR_PROCESS") != null && iMap.getString("DAY_FOR_PROCESS").equals("S")) {
                            currentTaksitCalender.setTime(getIleriIsGunu(currentTaksitCalender.getTime()));
                        }
                    }
                    oMap.put("PAYMENT_PLAN", i, "PAYMENT_DATE", currentTaksitCalender.getTime());
                    oMap.put("PAYMENT_PLAN", i, "PAYMENT_AMOUNT", tutar);
                    oMap.put("PAYMENT_PLAN", i, "PAYMENT_NO", i + 1);
                    i++;
                    if (donemTipi.equals("GUN"))
                        calendar.add(GregorianCalendar.DAY_OF_YEAR, 1);
                    else if (donemTipi.equals("HAFTA"))
                        calendar.add(GregorianCalendar.WEEK_OF_YEAR, 1);
                    else if (donemTipi.equals("AY"))
                        calendar.add(GregorianCalendar.MONTH, 1);
                    else if (donemTipi.equals("YIL"))
                        calendar.add(GregorianCalendar.YEAR, 1);
                }
            } else if (iMap.getString("DRT_TYPE").equals(DIRECTIVE_TYPE_IRREGULAR)) {
                String tableName = "PAYMENT_PLAN";
                for (int i = 0; i < iMap.getSize(tableName); i++) {
                    java.util.Date paymentDate = iMap.getDate(tableName, i, "PAYMENT_DATE");
                    if (!isWorkDay(paymentDate)) {
                        if (iMap.getString("DAY_FOR_PROCESS") != null && iMap.getString("DAY_FOR_PROCESS").equals("PREV")) {
                            paymentDate = getGeriIsGunu(paymentDate);
                        } else if (iMap.getString("DAY_FOR_PROCESS") != null && iMap.getString("DAY_FOR_PROCESS").equals("AFTER")) {
                            paymentDate = getIleriIsGunu(paymentDate);
                        }
                    }
                    oMap.put("PAYMENT_PLAN", i, "PAYMENT_DATE", paymentDate);
                    oMap.put("PAYMENT_PLAN", i, "PAYMENT_AMOUNT", iMap.getBigDecimal(tableName, i, "PAYMENT_AMOUNT"));
                    oMap.put("PAYMENT_PLAN", i, "PAYMENT_NO", i + 1);
                }
            }
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
        }
        return oMap;
    }
    
    public static boolean isWorkDay(java.util.Date aDate) {
        GMMap oMap = new GMMap();
        oMap.put("TARIH", aDate);
        return GMServiceExecuter.execute("BNSPR_TRN2301_GET_GUN_OZELLIK", oMap).get("RESULT").equals(new BigDecimal(0)) ? true : false;
    }

    public static Date getIleriIsGunu(java.util.Date aDate) {
        GMMap oMap = new GMMap();
        oMap.put("TARIH", aDate);
        return (Date) GMServiceExecuter.execute("BNSPR_TRN2301_GET_ILERI_ISGUNU", oMap).get("SONUC");
    }

    public static Date getGeriIsGunu(java.util.Date aDate) {
        GMMap oMap = new GMMap();
        oMap.put("TARIH", aDate);
        return (Date) GMServiceExecuter.execute("BNSPR_TRN2301_GET_GERI_ISGUNU", oMap).get("SONUC");
    }
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_TRANSFER_EFT_PAYMENT_STATUS")
    public static GMMap getTransferEftPaymentStatus(GMMap iMap) {
        try {
            Connection conn = null;
            CallableStatement stmt = null;
            GMMap oMap = new GMMap();
            try {
                conn = DALUtil.getGMConnection();
                stmt = conn.prepareCall("{? = call pkg_external.EFTHVL_Odeme_Durum(?,?)}");

                String trnType = iMap.getString("TRN_TYPE");
                stmt.registerOutParameter(1, Types.NUMERIC);
                stmt.setString(2, trnType);
                stmt.setString(3, iMap.getString("HVL".equals(trnType) ? "REFERANS" : "TRX_NO"));
                stmt.execute();

                oMap.put("STATUS", stmt.getBigDecimal(1));
                return oMap;
            } catch (Exception e) {
                throw ExceptionHandler.convertException(e);
            } finally {
                GMServerDatasource.close(stmt);
                GMServerDatasource.close(conn);
            }
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_TRANSFER_EFT_INSTALLMENT_STATUS")
    public static GMMap getTransferEftInstallmentStatus(GMMap iMap) {
        try {
            GMMap oMap = new GMMap();
            oMap.put("STATUS", DALUtil.callOracleFunction("{? = call PKG_DUZENLI_ODEME.Taksit_Durumu(?,?)}", BnsprType.STRING, BnsprType.STRING, iMap.getString("SEQUENCE"), BnsprType.STRING, iMap.getString("INSTALLMENT_SEQUENCE")));
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    public static Date getTarih(String islemTipi) {
        Connection conn = null;
        CallableStatement stmt = null;
        try {
            conn = DALUtil.getGMConnection();

            stmt = conn.prepareCall("{? = call PKG_FON_JAVASP.TARIH_AL(?)}");
            stmt.registerOutParameter(1, Types.DATE);
            stmt.setString(2, islemTipi);
            stmt.execute();
            

            return stmt.getDate(1);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_ACCOUNT_DETAIL")
    public static GMMap getAccountDetail(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_EXTERNAL.ib_hesap_detay_bilgi(?,?)}");

            stmt.registerOutParameter(1, -10);
            stmt.setBigDecimal(2, iMap.getBigDecimal("ACCOUNT_NO"));
            stmt.setString(3, iMap.getString("LANGUAGE"));
            stmt.execute();
            stmt.getMoreResults();
            rSet = (ResultSet) stmt.getObject(1);

            return DALUtil.rSetMap(rSet);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_EXTRE_SENDING_PERIOD_LIST")
    public static GMMap getExtreSendingPeriodList(GMMap iMap) {
        try {
            GMMap oMap = new GMMap();
            String tableName = BnsprCommonFunctions.getTableName(iMap);
            oMap.put(tableName, DALUtil.fillComboBox("select kod,aciklama from v_ml_gnl_ekstre_siklik_kod_pr order by kod"));
            return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_INQUIRE_ACCOUNT_CREATION_AUTHORIZATION")
    public static GMMap inquireAccountCreationAuthorization(GMMap iMap) {
        BigDecimal customerNo = iMap.getBigDecimal("CUSTOMERNO");
        String func = "{ ? = call pkg_card.Kisitli_BHSli_Musterimi(?) }";
        String response = (String) DALUtil.callOneParameterFunction(func, 1, customerNo);
        boolean isAuthorized = response.equals("H");
        return new GMMap().put("ISAUTHORIZED", isAuthorized);
    }
    
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_ACCOUNT_CREATION_BRANCH_LIST")
    public static GMMap getAccountCreationBranchList(GMMap iMap) {
        GMMap oMap = new GMMap();
        String tn = BnsprCommonFunctions.getTableName(iMap);

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ? = call PKG_EXTERNAL.IB_hesap_acma_sube_liste()}");
            int i = 1;
            stmt.registerOutParameter(i, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(i);
            i = 0;
            while (rSet.next()) {
                GuimlUtil.wrapMyCombo(oMap, tn, i++, rSet.getString("KOD"), rSet.getString("SUBE_ADI"));
            }
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_CREATE_DRAWING_ACCOUNT")
    public static Map<?, ?> createDrawingAccount(GMMap iMap) {
        CallableStatement stmt = null;
        Connection conn = null;
        try {
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();

            BigDecimal txNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>()).get("TRX_NO").toString());

            iMap.put("TRX_NO", txNo);
            stmt = conn.prepareCall("{call Pkg_External.Vadesiz_Hesap_Acilis_Initials(?,?,?,?,?,?,?)}");

            int i = 1;
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.execute();
            
            i = 3;
            iMap.put("URUN_TUR_KOD", stmt.getString(i++));
            iMap.put("URUN_SINIF_KOD", stmt.getString(i++));
            iMap.put("BORC_KAYDI", stmt.getBigDecimal(i++));
            iMap.put("ESAS_GUN_SAYISI", stmt.getBigDecimal(i++));
            iMap.put("BAKIYE_TURU", stmt.getBigDecimal(i++));
            iMap.put("TUTAR", "0");
            iMap.put("EKSTRE_NOTERDEN", "H");
            iMap.put("HESAP_UCRETI_F", "H");

            GMMap serviceInMap = new GMMap();
            serviceInMap.put("KOD", "2001");
            serviceInMap.put("KEY", "ACIKLAMA");
            iMap.put("ACIKLAMA", GMServiceExecuter.execute("BNSPR_COMMON_GET_MESAJ_TEXT", serviceInMap).get("TEXT"));

            iMap.put("KISA_ISIM", iMap.getString("RUMUZ"));
            iMap.put("ORTAKLIK_BILGILERI", new ArrayList<String>());

            oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_TRN2001_SAVE", iMap));
            oMap.put("TRX_NO", txNo);
            oMap.putAll(GMServiceExecuter.execute("INTERNET_GET_SUBE_ADI_HESAP_NO", oMap));

            return oMap;

        } catch (Exception e) {
        	log.error("BNSPR_CURRENT_ACCOUNTS_CREATE_DRAWING_ACCOUNT", e);
            throw ExceptionHandler.convertException(e);

        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);

        }
    }
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_DRAWING_ACCOUNT_LIST")
    public static GMMap getDrawingAccountList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        GMMap oMap = new GMMap();
        GMMap sMap = new GMMap();
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_TRN2101.Get_Vadesiz_Hesaplar(?,?,?,?,?)}");
            int i = 1;
            stmt.setBigDecimal(i++, iMap.getBigDecimal("CUSTOMER_NO"));
            stmt.setString(i++, "E");
            stmt.registerOutParameter(i++, -10);
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(3);
            oMap.putAll(DALUtil.rSetResults(rSet, "FON_HESAP_LIST"));
            oMap.put("ACC_LIMIT", stmt.getBigDecimal(4));
            oMap.put("FON_KODU", stmt.getString(5));
            sMap.put("PARAMETRE", "CATI_ALT_LIMIT");
            oMap.put("MIN_LIMIT", GMServiceExecuter.call("BNSPR_GET_PARAMETRE_DEGER_AL_K_N", sMap).getBigDecimal("DEGER"));

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_ADD_FUND_PROPERTY_TO_ACCOUNT")
    public static GMMap addFundPropertyToAccount(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            iMap.put("GUNCELLE", "H");
            iMap.put("ALT_LIMIT", iMap.get("LIMIT"));
            iMap.put("HESAP_TABLO", 0, "HESAP_NO", iMap.get("ACC_NO"));
            iMap.put("HESAP_TABLO", 0, "SEC", true);
            iMap.put("ISLEM_TABLO", GMServiceExecuter.call("BNSPR_TRN2101_GET_ILGILI_ISLEMLER", iMap).get("ISLEM_TABLO"));
            for (int i = 0; i < iMap.getSize("ISLEM_TABLO"); i++) {
                iMap.put("ISLEM_TABLO", i, "SEC", true);
            }
            iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).get("TRX_NO"));
            GMServiceExecuter.execute("BNSPR_TRN2101_SAVE", iMap);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_REMOVE_FUND_PROPERTY_FROM_ACCOUNT")
    public static GMMap removeFundPropertyFromAccount(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            iMap.put("ALT_LIMIT", iMap.get("LIMIT"));
            iMap.put("HESAP_NO", iMap.get("ACC_NO"));
            iMap.put("FON_KODU", iMap.get("FUND_CODE"));
            iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).get("TRX_NO"));
            GMServiceExecuter.execute("BNSPR_TRN2102_SAVE", iMap);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_UPDATE_FUND_ACCOUNT")
    public static GMMap updateFundAccount(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {
            iMap.put("GUNCELLE", "E");
            iMap.put("ALT_LIMIT", iMap.get("LIMIT"));
            iMap.put("HESAP_TABLO", 0, "HESAP_NO", iMap.get("ACC_NO"));
            iMap.put("HESAP_TABLO", 0, "SEC", true);
            iMap.put("ISLEM_TABLO", GMServiceExecuter.call("BNSPR_TRN2101_GET_ILGILI_ISLEMLER", iMap).get("ISLEM_TABLO"));
            for (int i = 0; i < iMap.getSize("ISLEM_TABLO"); i++) {
                iMap.put("ISLEM_TABLO", i, "SEC", true);
            }
            iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).get("TRX_NO"));
            GMServiceExecuter.execute("BNSPR_TRN2101_SAVE", iMap);
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
	@GraymoundService("BNSPR_COMMON_PARAMTEXT_DEGER_VAR_MI")
	public static GMMap isExistParamText(GMMap iMap) {
		GMMap oMap = new GMMap();
		String isExistParamText = "H";
	
		try {
			Object[] inputValues = new Object[8];
			int i=0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KOD");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KEY");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KEY2");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KEY3");
			
			String func= "{ ? = call pkg_parametre.ParamTextDegerVarMi (?,?,?,?) }";
			
			String deger =(String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);
			
			isExistParamText = nvl(deger, "H");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
		oMap.put("IS_EXIST", isExistParamText);
		return oMap;
	}
	public static <T> T nvl(T value, T defaultValue) {
		if (value instanceof String) {
			return StringUtils.isBlank((String) value) ? defaultValue : value;
		}

		return value == null ? defaultValue : value;
	}
	@GraymoundService("DEBIT_EMV_TRANSACTION")
	public static GMMap debitEmvTransaction (GMMap iMap){
		BigDecimal accountNo= iMap.getBigDecimal("ACCOUNT_NO");
		CrdDebitTransferBakiye crdDebitTransferBakiye = findTopupRecord(accountNo);
		BigDecimal tutar = iMap.getBigDecimal("AMOUNT");
		BigDecimal dusBakiye = BigDecimal.ZERO;
		if (crdDebitTransferBakiye != null){
			if (tutar.compareTo(crdDebitTransferBakiye.getBakiye())>0){
				dusBakiye= crdDebitTransferBakiye.getBakiye();
			}
			else{
				dusBakiye = tutar;
			}
			GMMap bkyMap= new GMMap();
			bkyMap.put("HESAP_NO",accountNo);
			bkyMap.put("TUTAR",dusBakiye.multiply(BigDecimal.valueOf(-1)));
			bkyMap.put("EXTERNAL_TRX_ID", iMap.getString("TRX_NO"));
			GMServiceExecuter.call("BNSPR_TRANSFER_TO_DEBIT_FROM_CREDIT", bkyMap);
		}
		return iMap;
	}
	@GraymoundService("DEBIT_EMV_TRANSACTION_REVERSE")
	public static GMMap debitEmvTransactionReverse (GMMap iMap){
		Session session = DAOSession.getSession("BNSPRDal");
		CrdDebitTransferBakiyeDty crdDebitTransferBakiyeDty =
	                (CrdDebitTransferBakiyeDty) session.createCriteria(CrdDebitTransferBakiyeDty.class).add(Restrictions.eq("externalRefNo" , iMap.getString("ORIGINAL_TRX_NO")))
	                        .uniqueResult();
		if(crdDebitTransferBakiyeDty !=null){
			GMMap bkyMap= new GMMap();
			bkyMap.put("HESAP_NO",crdDebitTransferBakiyeDty.getHesapNo());
			bkyMap.put("TUTAR",crdDebitTransferBakiyeDty.getBakiye().multiply(BigDecimal.valueOf(-1)));
			bkyMap.put("EXTERNAL_TRX_ID", iMap.getString("TRX_NO"));
			GMServiceExecuter.call("BNSPR_TRANSFER_TO_DEBIT_FROM_CREDIT", bkyMap);
		}
		return iMap;
	}
	private static CrdDebitTransferBakiye findTopupRecord(BigDecimal accountNo){
		Session session = DAOSession.getSession("BNSPRDal");
		 CrdDebitTransferBakiye crdDebitTransferBakiye =
	                (CrdDebitTransferBakiye) session.createCriteria(CrdDebitTransferBakiye.class).add(Restrictions.eq("hesapNo" , accountNo))
	                        .uniqueResult();
		 return crdDebitTransferBakiye;
	}
	
	/**
	 * 
	 * Description : Hesap - Kanal - (Servis) Whitelist Servisi
	 * BNSPR.GNL_BEYAZ_LISTE_HESAP_WS tablosunda kanal, hesap_no kaydi var ise 1 yok ise 0 d�ner. 
	 *
	 * @param iMap (GMMap)
	 *		{HESAP_NO}
	 *
	 * @return oMap (GMMap)
	 *      {SONUC}
	 *
	 */
	@GraymoundService("BNSPR_COMMON_CHECK_ACCOUNT_WHITELIST_FOR_WS")
	public static GMMap checkWhitelistForWs(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
            oMap.put("SONUC", DALUtil.callOracleFunction("{? = call pkg_hesap.BeyazListeWsKontrol(?,?)}", BnsprType.NUMBER, new Object[]{BnsprType.NUMBER, iMap.getBigDecimal("HESAP_NO"), BnsprType.NUMBER, iMap.get("KANAL_KODU") == null ? null : iMap.getBigDecimal("KANAL_KODU")}));
        }
        catch (SQLException e) {
            log.error("BNSPR_COMMON_CHECK_ACCOUNT_WHITELIST_FOR_WS err:" + e);
            throw ExceptionHandler.convertException(e);
        }
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_CURRENT_ACCOUNTS_SAVE_INTERNAL_TRANSFER")
    public static Map<?, ?> saveInternalTransfer(GMMap iMap) {
        try {
            GMMap oMap = new GMMap();
            setBranchCode(iMap.getString("BORC_HESAP_NO"));
            BigDecimal txNo = new BigDecimal(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>()).get("TRX_NO").toString());
            iMap.put("TRX_NO", txNo);
            iMap.put("DEKONT_BASIM_F", "H");
           // String aciklama = iMap.getString("ACIKLAMA");
           // if (aciklama == null || aciklama.isEmpty()) {
           //     iMap.put("ACIKLAMA", "Virman");
           // } -- art�k bo� ge�ilmesine izin veriyorum MHA 28022019
            oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_TRN2010_SAVE", iMap));
            oMap.put("TRX_NO", txNo);
            return oMap;
        } catch (Exception e) {
            return throwGMBusssinessException(e.getMessage());
        }
    }
	
	   
    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_RECEIPT")
    public static Map<?, ?> getReceipt(GMMap iMap) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rSet = null;
        try {
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("select"
                                    + " d.vergi_d_adi vergi_dairesi, a.*,"
                                    + " pkg_hesap.iban_formatli(a.musteri_hesap_no) iban,"
                                    + " pkg_genel_pr.sube_adi(a.sube_kodu) sube_adi,"
                                    + " a.masraf_doviz_kodu di_masraf_doviz_kodu,"
                                    + " to_char (f.yarat_tar , 'DD.MM.YYYY HH24:mi')"
                                    + " from"
                                    + " v_muh_dekont a ,muh_fis f, gnl_vergi_daire_kod_pr d"
                                    + " where"
                                    + " a.tx_no = ?"
                                    + " and a.fis_numara = f.numara"
                                    + " and a.musteri_vergi_d = d.vergi_d_kod(+)"
                                    + " and pkg_tx.islem_kod(?)<>1101"
                                    + " and nvl(a.musteri_no,0) = nvl(?,nvl(a.musteri_no,0))");
            stmt.setString(1, iMap.getString("TRX_NO"));
            stmt.setString(2, iMap.getString("TRX_NO"));
            stmt.setString(3, iMap.getString("MUSTERI_NO"));
            rSet = stmt.executeQuery();
            if (rSet.next()) {
                oMap.put("VERGI_DAIRESI", rSet.getString("VERGI_DAIRESI"));
                oMap.put("IBAN", rSet.getString("IBAN"));
                oMap.put("SUBE_ADI", rSet.getString("SUBE_ADI"));
                oMap.put("DI_MASRAF_DOVIZ_KODU", rSet.getString("DI_MASRAF_DOVIZ_KODU"));
                
                oMap.put("ACIKLAMA", rSet.getString("ACIKLAMA"));
                oMap.put("ACIKLAMA1", rSet.getString("ACIKLAMA1"));
                oMap.put("ACIKLAMA2", rSet.getString("ACIKLAMA2"));
                oMap.put("ACIKLAMA3", rSet.getString("ACIKLAMA3"));
                oMap.put("ACIKLAMA4", rSet.getString("ACIKLAMA4"));
                oMap.put("AMIR_SUBE_ADI", rSet.getString("AMIR_SUBE_ADI"));
                oMap.put("AMIR_SUBE_KODU", rSet.getString("AMIR_SUBE_KODU"));
                oMap.put("BANKAMIZ_KISA_ADI", rSet.getString("BANKAMIZ_KISA_ADI"));
                oMap.put("DEKONT_BASILSIN", rSet.getString("DEKONT_BASILSIN"));
                oMap.put("DEKONT_TIPI", rSet.getString("DEKONT_TIPI"));
                oMap.put("DK_HESAP_NO", rSet.getString("DK_HESAP_NO"));
                oMap.put("DOVIZ_KODU", rSet.getString("DOVIZ_KODU"));
                oMap.put("FIS_NO_GUNLUK", rSet.getString("FIS_NO_GUNLUK"));
                oMap.put("FIS_NUMARA", rSet.getString("FIS_NUMARA"));
                oMap.put("HITAP", rSet.getString("HITAP"));
                oMap.put("ISLEMI_YAPAN_ACK", rSet.getString("ISLEMI_YAPAN_ACK"));
                oMap.put("ISLEM_KOD", rSet.getString("ISLEM_KOD"));
                oMap.put("ISLEM_TARIHI", rSet.getString("ISLEM_TARIHI"));
                oMap.put("ISLEM_TURU", rSet.getString("ISLEM_TURU"));
                oMap.put("ISL_ADI", rSet.getString("ISL_ADI"));
                oMap.put("ISL_ADRES", rSet.getString("ISL_ADRES"));
                oMap.put("ISL_TCKIMLIK", rSet.getString("ISL_TCKIMLIK"));
                oMap.put("ISL_VERGINO", rSet.getString("ISL_VERGINO"));
                oMap.put("KASA_KODU", rSet.getString("KASA_KODU"));
                oMap.put("KAYIT_KULLANICI_KODU", rSet.getString("KAYIT_KULLANICI_KODU"));
                oMap.put("KAYIT_SISTEM_TARIHI", rSet.getString("KAYIT_SISTEM_TARIHI"));
                oMap.put("KAYIT_TARIH", rSet.getString("KAYIT_TARIH"));
                oMap.put("KUR", rSet.getString("KUR"));
                oMap.put("MASRAF_DOVIZ_KODU", rSet.getString("MASRAF_DOVIZ_KODU"));
                oMap.put("MASRAF_KOMISYON", rSet.getString("MASRAF_KOMISYON"));
                oMap.put("MUSTERI_ADI", rSet.getString("MUSTERI_ADI"));
                oMap.put("MUSTERI_ADRES", rSet.getString("MUSTERI_ADRES"));
                oMap.put("MUSTERI_HESAP_NO", rSet.getString("MUSTERI_HESAP_NO"));
                oMap.put("MUSTERI_NO", rSet.getString("MUSTERI_NO"));
                oMap.put("MUSTERI_VERGI_D", rSet.getString("MUSTERI_VERGI_D"));
                oMap.put("MUSTERI_VKN", rSet.getString("MUSTERI_VKN"));
                oMap.put("SIRA_NO", rSet.getString("SIRA_NO"));
                oMap.put("SUBE_KODU", rSet.getString("SUBE_KODU"));
                oMap.put("TUTARI", rSet.getString("TUTARI"));
                oMap.put("TUTAR_LC", rSet.getString("TUTAR_LC"));
                oMap.put("TX_NO", rSet.getString("TX_NO"));
                oMap.put("VALOR", rSet.getString("VALOR"));
                oMap.put("VERGI", rSet.getString("VERGI"));
                oMap.put("VERGI_DAIRE", rSet.getString("VERGI_DAIRE"));
                oMap.put("VERGI_NO", rSet.getString("VERGI_NO"));
            }
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }

    @GraymoundService("BNSPR_CURRENT_ACCOUNTS_GET_HESAP_HAREKET_KODU")
        public static GMMap getHesapHareketKodu(GMMap iMap) {
        		GMMap oMap = new GMMap();
        		oMap.put("HESAP_HAREKET_KODU", DALUtil.callOneParameterFunction("{? = call pkg_hesap.hesap_hareket_kodu(?)}", Types.VARCHAR, iMap.getBigDecimal("hesapNo")));
        		return oMap;
     }
    
    @GraymoundService("BNSPR_IBAN_KONTROL_WITH_NO_ERROR")
    public static GMMap bnsprIbanKontrolWithNoError(GMMap iMap) {
             GMMap oMap = new GMMap();
             
             String funcStr = "{? = call pkg_iban.sp_IBAN_Kontrol_Et(?)}";
             int i = 0;
                 
                 Object [] inputValues = new Object [8];
                 
                 try {
                         
                         inputValues[i++] = BnsprType.STRING;
                         inputValues[i++] = iMap.getString("IBAN");
                         oMap.put("ibanControl", (String)DALUtil.callOracleFunction(funcStr, BnsprType.STRING, inputValues));
                 
                         
                 }
                 catch(Exception e) {
                         
                         e.printStackTrace();
                         throw ExceptionHandler.convertException(e);
                 }
                 
             return oMap;
    }
    @GraymoundService("BNSPR_GET_KULL_EMAIL")
    public static GMMap getKullaniciEmail(GMMap iMap){
    	GMMap oMap = new GMMap();
    	try {
    		 String funcStr = "{? = call pkg_personel.personel_mail(?)}";
    		 Object [] inputValues = new Object [2];
    		 inputValues[0] = BnsprType.STRING;
             inputValues[1] = iMap.getString("KULL_KOD");
             oMap.put("EMAIL", (String)DALUtil.callOracleFunction(funcStr, BnsprType.STRING, inputValues));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
    	return oMap;
    }
    
    @GraymoundService("BNSPR_GET_MUSTERI_EMAIL")
    public static GMMap getMusteriEmail(GMMap iMap) {
    	
    	GMMap oMap = new GMMap();
    	
    	try {
    		
    		if(iMap.containsKey("TC_KIMLIK_NO") && !iMap.containsKey("MUSTERI_NO")) {
    			iMap.put("MUSTERI_NO", (BigDecimal) DALUtil.callOracleFunction("{? = call pkg_musteri.Musteri_Varmi_TCKN(?)}", 
    				BnsprType.NUMBER,
    				BnsprType.STRING, iMap.getString("TC_KIMLIK_NO")));
    		}
    		
    		if(!iMap.containsKey("EMAIL_TIP") || "K".equals(iMap.getString("EMAIL_TIP"))) {
    			oMap.put("EMAIL", (String) DALUtil.callOracleFunction("{? = call pkg_musteri.email_kisisel(?)}", 
    				BnsprType.STRING, 
    				BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO")));
    		} else if("I".equals(iMap.getString("EMAIL_TIP"))) {
    			oMap.put("EMAIL", (String) DALUtil.callOracleFunction("{? = call pkg_musteri.email_is(?)}", 
    				BnsprType.STRING, 
    				BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO")));
    		} else {
    			iMap.put("HATA_NO", 660).put("P1", "Hatal� parametre de�eri. (EMAIL_TIP)");
    			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
    		}
    		
    		return oMap;
    		
    	} catch(Exception e) {
    		log.error("BNSPR_GET_MUSTERI_EMAIL err:", e);
    		throw ExceptionHandler.convertException(e);
    	}
    }
    
    @GraymoundService("BNSPR_EKSTRE_MAIL_GONDER")
    public static GMMap ekstreMailGonder(GMMap iMap){
    	GMMap oMap = new GMMap();
    	try {
    		Object[] inputValues = new Object[4];
			inputValues[0] = BnsprType.STRING;
			inputValues[1] = iMap.getString("EPOSTA");
			Object[] outputValues = new Object[0];
			String proc = "{ call pkg_trn10011.e_mail_check(?) }";
			DALUtil.callOracleProcedure(proc, inputValues, outputValues);
			
    		iMap.put("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", iMap).getBigDecimal("TRX_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_MAIL_ICIN_EKSTRE_OLUSTUR", iMap));
			GMMap servisMap = new GMMap();
			servisMap.put("FROM", "Aktifbank@aktifbank.com.tr");
			servisMap.put("RECIPIENTS_TO", GuimlUtil.createFromCommaSeparatedList(iMap.getString("EPOSTA")));
			servisMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			servisMap.put("SUBJECT", "Hesap Ekstresi");
			servisMap.put("MESSAGE_BODY", "Say�n <b>"+iMap.getString("MUSTERI_ADI")+"</b><br>Hesap Ekstrenize ekte ula�abilirsiniz.<br> Sayg�lar�m�zla<br><b>Aktif Bank</b>");
			servisMap.put("IS_BODY_HTML", true);
			servisMap.put("SEND_ATTACHMENT_WITHOUT_DYS", true);
			servisMap.put("ATTACMENT_FILE_LIST", 0, "FILE_NAME", oMap.getString("FILENAME"));
			servisMap.put("ATTACMENT_FILE_LIST", 0, "FILE_BYTE_ARRAY", FileUtil.readFileToByteArray(new File(oMap.getString("FILENAMEPATH"))));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", servisMap));
			oMap.put("MESSAGE", "Mail ba�ar�l� �ekilde g�nderilmi�tir.");
			oMap.putAll(GMServiceExecuter.execute("BNSPR_EXTRE_MAIL_GONDERIM_LOG",iMap));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
    	return oMap;
    }
    @GraymoundService("BNSPR_MAIL_ICIN_EKSTRE_OLUSTUR")
    public static GMMap mailEkstreOlustur(GMMap iMap){
    	GMMap oMap = new GMMap();
    	try {
    		HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("HESAP_NO",iMap.getBigDecimal("HESAP_NO"));
			parameters.put("EKSTRE_BASLANGIC_TAR",iMap.getString("EKSTRE_BASLANGIC_TAR"));
			parameters.put("EKSTRE_BITIS_TAR",iMap.getString("EKSTRE_BITIS_TAR"));
			parameters.put("LOGOLU",iMap.getBoolean("LOGOLU"));
			
    		String fileName = iMap.getString("HESAP_NO") +  "_" + System.currentTimeMillis() + ".pdf";
			String fileNamePath = System.getProperty("java.io.tmpdir") + System.getProperty("file.separator") + fileName;
			JasperPrint jasperPrint = new JasperPrint();
			if (iMap.getBoolean("INGILIZCE")){
				jasperPrint = ReportUtil.generateReport("HESAP_EKSTRESI_INGILIZCE", parameters);
			}
			else
			{
				jasperPrint = ReportUtil.generateReport("HESAP_EKSTRESI", parameters);
			}
			JRPdfExporter pdfexporter = new JRPdfExporter();
			pdfexporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			pdfexporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, fileNamePath);
			pdfexporter.exportReport();
			oMap.put("FILENAME", fileName);
			oMap.put("FILENAMEPATH", fileNamePath);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
    	return oMap;
    }
    @GraymoundService("BNSPR_HESAP_ACILIS_TARIHI_AL")
    public static GMMap getHesapAcilisTarihi(GMMap iMap){
    	GMMap oMap = new GMMap();
    	try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			
			Object[] inputValues = new Object[2];
			inputValues[0] = BnsprType.NUMBER;
			inputValues[1] = iMap.getBigDecimal("HESAP_NO");
			String func = "{? = call pkg_hesap.acilis_tarihi(?)}";
			String acilisTarih = sdf.format((Date) DALUtil.callOracleFunction(func, BnsprType.DATE, inputValues));
			oMap.put("TARIH_YIL", acilisTarih.substring(0, 4));
			oMap.put("TARIH_AY", acilisTarih.substring(4, 6));
			oMap.put("TARIH_GUN", acilisTarih.substring(6));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
    	return oMap;
    }
    @GraymoundService("BNSPR_HESAP_DEVIR_BAKIYE_AL")
    public static GMMap getHesapDevirBakiye(GMMap iMap){
    	GMMap oMap = new GMMap();
    	try {
			Object[] inputValues = new Object[8];
			inputValues[0] = BnsprType.NUMBER;
			inputValues[1] = iMap.getBigDecimal("HESAP_NO");
			inputValues[2] = BnsprType.NUMBER;
			inputValues[3] = iMap.getBigDecimal("YIL");
			inputValues[4] = BnsprType.NUMBER;
			inputValues[5] = iMap.getBigDecimal("AY");
			inputValues[6] = BnsprType.NUMBER;
			inputValues[7] = iMap.getBigDecimal("GUN");
			String func = "{? = call pkg_hesap.DevirBakiyeAl(?,?,?,?)}";
			BigDecimal bakiye = (BigDecimal) DALUtil.callOracleFunction(func, BnsprType.NUMBER, inputValues);
			oMap.put("BAKIYE", bakiye);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
    	return oMap;
    }
    @GraymoundService("BNSPR_DEKONT_MAIL_GONDER")
    public static GMMap dekontMailGonder(GMMap iMap){
    	GMMap oMap = new GMMap();
    	try {
    		Object[] inputValues = new Object[4];
			inputValues[0] = BnsprType.STRING;
			inputValues[1] = iMap.getString("EPOSTA");
			Object[] outputValues = new Object[0];
			String proc = "{ call pkg_trn10011.e_mail_check(?) }";
			DALUtil.callOracleProcedure(proc, inputValues, outputValues);
			oMap.putAll(GMServiceExecuter.execute("BNSPR_MAIL_ICIN_DEKONT_OLUSTUR", iMap));
			GMMap servisMap = new GMMap();
			servisMap.put("FROM", "Aktifbank@aktifbank.com.tr");
			servisMap.put("RECIPIENTS_TO", GuimlUtil.createFromCommaSeparatedList(iMap.getString("EPOSTA")));
			servisMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			servisMap.put("SUBJECT", "��lem Dekontu");
			servisMap.put("MESSAGE_BODY", "Say�n <b>"+iMap.getString("MUSTERI_ADI")+"</b><br>��lem dekontunuza ekte ula�abilirsiniz.<br> Sayg�lar�m�zla<br><b>Aktif Bank</b>");
			servisMap.put("IS_BODY_HTML", true);
			servisMap.put("SEND_ATTACHMENT_WITHOUT_DYS", true);
			servisMap.put("ATTACMENT_FILE_LIST", 0, "FILE_NAME", oMap.getString("FILENAME"));
			servisMap.put("ATTACMENT_FILE_LIST", 0, "FILE_BYTE_ARRAY", FileUtil.readFileToByteArray(new File(oMap.getString("FILENAMEPATH"))));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_SYSTEM_MAIL_SEND_EMAIL", servisMap));
			oMap.put("MESSAGE", "Mail ba�ar�l� �ekilde g�nderilmi�tir.");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
    	return oMap;
    }
    @GraymoundService("BNSPR_MAIL_ICIN_DEKONT_OLUSTUR")
    public static GMMap mailDekontOlustur(GMMap iMap){
    	GMMap oMap = new GMMap();
    	try {
    		HashMap<String, Object> parameters = new HashMap<String, Object>();
			parameters.put("TX_NO",iMap.getBigDecimal("TRX_NO"));
			parameters.put("SIRA_NO", iMap.getString("SIRA_NO"));
			
    		String fileName = iMap.getString("TRX_NO") +  "_" + System.currentTimeMillis() + ".pdf";
			String fileNamePath = System.getProperty("java.io.tmpdir") + System.getProperty("file.separator") + fileName;
			JasperPrint jasperPrint = new JasperPrint();
			if (iMap.getBoolean("INGILIZCE")){
				jasperPrint = ReportUtil.generateReport("dekont_new2_en", parameters);
			}
			else
			{
				jasperPrint = ReportUtil.generateReport("dekont_new2", parameters);
			}
			JRPdfExporter pdfexporter = new JRPdfExporter();
			pdfexporter.setParameter(JRExporterParameter.JASPER_PRINT, jasperPrint);
			pdfexporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, fileNamePath);
			pdfexporter.exportReport();
			oMap.put("FILENAME", fileName);
			oMap.put("FILENAMEPATH", fileNamePath);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
    	return oMap;
    }
    
	@GraymoundService("BNSPR_COMMON_GET_BOLUM_KODU")
	public static GMMap getBolumKodu(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("BOLUM_KODU", DALUtil.callNoParameterFunction("{? = call pkg_global.GET_BOLUMKOD}", Types.VARCHAR));
		return oMap;
	}
    
    @GraymoundService("BNSPR_HESAP_NO_MAIL_GONDER")
    public static GMMap hesapNoMailG�nder(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            Object[] inputValues = new Object[4];
            inputValues[0] = BnsprType.STRING;
            inputValues[1] = iMap.getString("EPOSTA");
            Object[] outputValues = new Object[0];
            String proc = "{ call pkg_trn10011.e_mail_check(?) }";
            DALUtil.callOracleProcedure(proc , inputValues , outputValues);
            
            iMap.put("TRX_NO" , GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , iMap).getBigDecimal("TRX_NO"));
            GMMap servisMap = new GMMap();
            servisMap.put("MAIL_FROM" , "Aktifbank@aktifbank.com.tr");
            servisMap.put("MAIL_TO" , iMap.getString("EPOSTA"));
            servisMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
            servisMap.put("MAIL_SUBJECT" , "Hesap Numaras�");
            servisMap.put("MAIL_BODY" , "Say�n <b>" + iMap.getString("MUSTERI_ADI") + "</b><br>�ube Kodunuz: " + iMap.getString("SUBE_KODU") + 
                    "<br>Hesap Numaran�z: " + iMap.getString("HESAP_NO") +
                    "<br> Sayg�lar�m�zla<br><b>Aktif Bank</b>");
            servisMap.put("IS_BODY_HTML" , "E");
            oMap.putAll(GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL" , servisMap));
            oMap.put("MESSAGE" , "Mail ba�ar�l� �ekilde g�nderilmi�tir.");
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_HESAP_NO_SMS_GONDER")
    public static GMMap hesapNoSmsG�nder(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            iMap.put("HEADER" , "Aktif Bank");
            oMap = GMServiceExecuter.call("CNSPR_MUSTERI_TELEFON_NO_LISTE" , iMap);
            
            String otpPhoneNumber = null;
            
            for (int i = 0; i < oMap.getSize("MUSTERI_TEL_NO_LISTE"); i++){
                
                String tip = oMap.getString("MUSTERI_TEL_NO_LISTE" , i , "TEL_TIP");
                String otpMi = oMap.getString("MUSTERI_TEL_NO_LISTE" , i , "OTP_MI");
                
                if ("E".equalsIgnoreCase(otpMi)){
                    otpPhoneNumber = oMap.getString("MUSTERI_TEL_NO_LISTE" , i , "TEL");
                } else
                    if ("3".equals(tip)){
                        otpPhoneNumber = oMap.getString("MUSTERI_TEL_NO_LISTE" , i , "TEL");
                    }
            }
            String MSISDN = otpPhoneNumber;
            boolean FILTER = true;
            boolean SECURE_CONTENT = true;
            
            iMap.put("CONTENT" , "Sayin musterimiz, �ube kodunuz: " +iMap.getString("SUBE_KODU") +" hesap numaran�z: " +iMap.getString("HESAP_NO"));
            
            String MUSTERI_NO = iMap.getString("CUSTOMER_NO");
            
            iMap.put("MSISDN" , MSISDN);
            iMap.put("FILTER" , FILTER);
            iMap.put("SECURE_CONTENT" , SECURE_CONTENT);
            iMap.put("MUSTERI_NO" , MUSTERI_NO);
            
            GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_IBAN_MAIL_GONDER")
    public static GMMap ibanNoMailG�nder(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            Object[] inputValues = new Object[4];
            inputValues[0] = BnsprType.STRING;
            inputValues[1] = iMap.getString("EPOSTA");
            Object[] outputValues = new Object[0];
            String proc = "{ call pkg_trn10011.e_mail_check(?) }";
            DALUtil.callOracleProcedure(proc , inputValues , outputValues);
            
            iMap.put("TRX_NO" , GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO" , iMap).getBigDecimal("TRX_NO"));
            GMMap servisMap = new GMMap();
            servisMap.put("MAIL_FROM" , "Aktifbank@aktifbank.com.tr");
            servisMap.put("MAIL_TO" , iMap.getString("EPOSTA"));
            servisMap.put("TRX_NO" , iMap.getBigDecimal("TRX_NO"));
            servisMap.put("MAIL_SUBJECT" , "Hesap Numaras�");
            servisMap.put("MAIL_BODY" , "Say�n <b>" + iMap.getString("MUSTERI_ADI") + "</b><br>IBAN Numaran�z: " + iMap.getString("IBAN") + "<br> Sayg�lar�m�zla<br><b>Aktif Bank</b>");
            servisMap.put("IS_BODY_HTML" , "E");
            oMap.putAll(GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL" , servisMap));
            oMap.put("MESSAGE" , "Mail ba�ar�l� �ekilde g�nderilmi�tir.");
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_IBAN_SMS_GONDER")
    public static GMMap ibanNoSmsG�nder(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
            iMap.put("HEADER" , "Aktif Bank");
            oMap = GMServiceExecuter.call("CNSPR_MUSTERI_TELEFON_NO_LISTE" , iMap);
            
            String otpPhoneNumber = null;
            
            for (int i = 0; i < oMap.getSize("MUSTERI_TEL_NO_LISTE"); i++){
                
                String tip = oMap.getString("MUSTERI_TEL_NO_LISTE" , i , "TEL_TIP");
                String otpMi = oMap.getString("MUSTERI_TEL_NO_LISTE" , i , "OTP_MI");
                
                if ("E".equalsIgnoreCase(otpMi)){
                    otpPhoneNumber = oMap.getString("MUSTERI_TEL_NO_LISTE" , i , "TEL");
                } else
                    if ("3".equals(tip)){
                        otpPhoneNumber = oMap.getString("MUSTERI_TEL_NO_LISTE" , i , "TEL");
                    }
            }
            String MSISDN = otpPhoneNumber;
            boolean FILTER = true;
            boolean SECURE_CONTENT = true;
            
            iMap.put("CONTENT" , "Sayin musterimiz, IBAN numaran�z: " +iMap.getString("IBAN") + " iletisim@aktifbank.com.tr SMS almamak icin AKTIFBANK yazip 3525'e g�nderebilirsiniz Iletisim:08507243050 Mersis:0225013653700015" );

            
            String MUSTERI_NO = iMap.getString("CUSTOMER_NO");
            
            iMap.put("MSISDN" , MSISDN);
            iMap.put("FILTER" , FILTER);
            iMap.put("SECURE_CONTENT" , SECURE_CONTENT);
            iMap.put("MUSTERI_NO" , MUSTERI_NO);
            
            GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC" , iMap);
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_COMMON_SHOW_DOCUMENT_CONTENT")
	public static GMMap getTRN2016ShowDocumentContent(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {
			String documentName = iMap.getString("DOKUMAN_ADI");
			ByteArrayType data = new ByteArrayType();
			GMMap dMap = GMServiceExecuter.call("DYS_CMIS_GET_DOKUMAN_LINK_BY_FILENAME_V2", new GMMap()
													.put("DOKUMAN_ADI", documentName)
													.put("DOKUMAN_CLASS", "Musteri")
													.put("DOKUMAN_BYTE_ARRAY_NEEDED", StringUtils.lowerCase(FilenameUtils.getExtension(documentName)).equals("pdf")));

			if (dMap.containsKey("DOKUMAN_BYTE_ARRAY")) {
				data.setData((byte[]) dMap.get("DOKUMAN_BYTE_ARRAY"));
			}
			oMap.put("DOKUMAN_LINK", dMap.get("DOKUMAN_LINK"));
			oMap.put("DOKUMAN_BYTE_ARRAY", data);
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}
    
    @GraymoundService("BNSPR_COMMON_GET_CUSTOMER_DOCUMENT_LIST")
	public static GMMap getCustomerDocumentList(GMMap iMap) {
		GMMap resultMap = new GMMap();
		String musNo = iMap.getString("MUSTERI_NO");
		Session session = DAOSession.getSession("BNSPRDal");
		String[] gnlParamText = { "BHS_DOKUMAN_KODLARI", "NAKIT_EKRANLARI_DOKUMAN_KODLARI" };
		List<GnlParamText> gnlParams = (List<GnlParamText>) session.createCriteria(GnlParamText.class).add(Restrictions.in("kod", gnlParamText)).list();
		List<String> docTypes = new ArrayList<String>();
		for (GnlParamText gnlParamText2 : gnlParams) {
			docTypes.add(gnlParamText2.getKey1());
		}

		List<GnlMusteriimajDetay> gnlMusteriImajList = (List<GnlMusteriimajDetay>) session.createCriteria(GnlMusteriimajDetay.class).add(Restrictions.eq("id.musteriNo", new BigDecimal(musNo))).add(Restrictions.in("id.dokumanTipi", docTypes)).list();
		int index = 0;
		for (GnlMusteriimajDetay gnlMusteriImajDetay : gnlMusteriImajList) {
			resultMap.put("DOCUMENT_LIST", index, "T_DOKUMAN_TIP_KOD", gnlMusteriImajDetay.getId().getDokumanTipi());
			resultMap.put("DOCUMENT_LIST", index, "T_DOKUMAN_ACIKLAMA", getDocumentCode(gnlMusteriImajDetay.getId().getDokumanTipi()).getAciklama());
			resultMap.put("DOCUMENT_LIST", index, "T_DOKUMAN_FILE_NAME", gnlMusteriImajDetay.getImajFileName());
			index++;
		}

		return resultMap;

	}
    @GraymoundService("BNSPR_GET_HESAP_URUN_KOD")
    public static GMMap getHesapUrunKod (GMMap iMap){
    	try {
    		GMMap oMap = new GMMap();
    		Object[] inputValues = new Object[2];
			inputValues[0] = BnsprType.NUMBER;
			inputValues[1] = iMap.getBigDecimal("HESAP_NO");
			String func = "{? = call pkg_hesap.urun_tur_kod(?)}";
			String urunTurKod =  (String) DALUtil.callOracleFunction(func, BnsprType.STRING, inputValues);
			oMap.put("URUN_TUR_KOD", urunTurKod);
    		return oMap;
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
    }
    public static GnlDokumanKodPr getDocumentCode(String documentCode){
    	Session session = DAOSession.getSession("BNSPRDal");
    	return (GnlDokumanKodPr) session.get(GnlDokumanKodPr.class, documentCode);	    	
    }
    
    /**
	 * {@code MSISDN} telefon numaras�na, e�er ilgili key yok ise {@code CUSTOMER_NO} numaras�na 
	 * sahip m��teriye kay�tl� GSM numaras�na, {@code DOCUMENT_CODE} de�erine sahip belgeyi g�r�nt�leyebilmesi i�in 
	 * {@code MESSAGE_NO} ve {@code MESSAGE_CONTENT} ile SMS g�nderimi talebi olu�turur.
	 * 
	 * <p>{@code MESSAGE_NO} i�inde bir URL ge�melidir ve URL'e ait query string [url]?k=#1 format�nda olmal�d�r.
	 * Parametrik mesaja ait farkl� parametreler mevcut ise {@code MESSAGE_CONTENT} alt�nda ge�ilebilir.</p>
	 * <p>{@code SAVE_DOCUMENT} de�eri {@code true} olmas� durumunda belgeye ili�kin parametre de�erleri de g�nderilmelidir,
	 * aksi takdirde {@link #bnsprCommonGetQsDocumentPdfByte(GMMap) BNSPR_COMMON_GET_QS_DOCUMENT_PDF_BYTE} servisi �a��r�ld���nda
	 * belge yarat�labilmesi i�in {@code SERVICE_NAME} de�eri ge�ilmelidir.</p>
	 * <p>* Zorunlu, ** Ko�ullu Zorunlu</p>
	 * 
	 * @param iMap {TRX_NO}					Banka i�lem numaras�, ge�ilmemesi durumunda {@link BNSPR_TRX_GET_TRANSACTION_NO} 
	 * 										ile yeni{@code TRX_NO} al�narak, ilerlenir.
	 * @param iMap {DOCUMENT_CODE*}			{@code bnspr.gnl_musteri_dokuman_kod_pr} tablosunda 
	 * 										{@code kod} alan� ile e�le�ir.
	 * @param iMap {CUSTOMER_NO*}			M��teri numaras�
	 * @param iMap {MSISDN}					Mesaj�n g�nderilece�i telefon numaras�.
	 * @param iMap {MESSAGE_NO*}			Parametrik mesaj numaras�, {@code bnspr.gnl_mesaj_pr}
	 * 										tablosunda {@code mesaj_no}
	 * 										alan� ile e�le�ir.
	 * @param iMap {MESSAGE_CONTENT}		Parametrik mesaj i�in {@code GMMap} tipinde mesaj parametrelerini 
	 * 										(#2, #3, ...)  al�r. �rnek;
	 * 										<ul>
	 * 										<li><code>{P2=<i>M��teri Ad�</i>}</code></li>
	 * 										<li><code>{P2=<i>M��teri Ad�</i>, P3=<i>Tutar</i>}</code></li>
	 * 										</ul> 
	 * @param iMap {SAVE_DOCUMENT}			Belgenin DYS'de saklanmas� isteniyorsa {@code boolean} tipinde 
	 * 										{@code true} de�eri g�nderilmelidir. 
	 * @param iMap {SERVICE_NAME**}			{@code SAVE_DOCUMENT} de�eri {@code false} olmas� durumunda zorunludur. 
	 * 										{@link #bnsprCommonGetQsDocumentPdfByte(GMMap) BNSPR_COMMON_GET_QS_DOCUMENT_PDF_BYTE} 
	 * 										servisinde belgeyi getirmek i�in �a��r�lacak {@code GraymoundService} de�eri.
	 * @param iMap {REFERENCE**}			{@code SAVE_DOCUMENT} de�eri {@code true} olmas� durumunda zorunludur. DYS Referans�.
	 * @param iMap {REFERENCE_TYPE**}		{@code SAVE_DOCUMENT} de�eri {@code true} olmas� durumunda zorunludur. DYS Referans Tipi.
	 * 										<br/>Referans: {@code bnspr.gnl_param_text.kod = 'REFERANS_TUR_KOD'}
	 * @param iMap {DOCUMENT_PARAMETERS**}	{@code SAVE_DOCUMENT} de�eri {@code true} olmas� durumunda zorunludur. 
	 * 										{@code HashMap<String, Object>} Rapor parametreleri
	 * @param iMap {DOCUMENT_REPORT_NAME**}	{@code SAVE_DOCUMENT} de�eri {@code true} olmas� durumunda zorunludur. 
	 * 										{@code List<String>} veya {@code String} tipinde rapor isim(leri)nin de�er(ler)i
	 * @return								E�er bildirim talebi ba�ar�l� �ekilde olu�turulursa <code>GMMap{RESPONSE=2,TRX_NO}</code> d�ner, aksi takdirde
	 * 										{@code GMRuntimeException} f�rlat�l�r.
	 * @throws GMRuntimeException			Belge i�in talep SMS g�nderim talebi olu�turulamaz ise.
	 * 
	 * @see <a href="http://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRCore/src/tr/com/calikbank/bnspr/core/transaction/services/BNSPRTransactionServices.java?r=418145">
	 * 		BNSPR_TRX_GET_TRANSACTION_NO</a>
	 * @see <a href="http://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRCustomer/src/tr/com/calikbank/bnspr/customer/services/CustomerTRN1090Services.java?r=416235">
	 * 		BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST</a>,
	 *  	<a href="http://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRCustomer/src/tr/com/calikbank/bnspr/customer/services/CustomerTRN1091Services.java?r=416235">
	 * 		BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN</a>,
	 *  	<a href="http://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRCustomer/src/tr/com/calikbank/bnspr/customer/services/CustomerTRN1090Services.java?r=416235">
	 * 		BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN</a>
	 * @see <a href="http://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRCustomer/src/tr/com/calikbank/bnspr/customer/services/CustomerCommonServices.java?r=423282">
	 * 		BNSPR_MUSTERI_DOKUMAN_EKLE</a>,
	 * @see #getKodsuzMessage(GMMap)
	 * @see <a href="http://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRSystem/src/tr/com/calikbank/bnspr/sms/services/SmsServices.java?r=402769">
	 * 		BNSPR_SMS_SEND_SMS_ASYNC</a>
	 */
	@GraymoundService("BNSPR_COMMON_SEND_QS_DOCUMENT")
	public static GMMap bnsprCommonSendQsDocument(GMMap iMap) {
		
    	GMMap oMap = new GMMap();
    	BigDecimal trxNo;
    	final String referenceType = "1";
    	
		try {
			trxNo = iMap.getBigDecimal("TRX_NO", GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO"));
			
			MessageDigest md = MessageDigest.getInstance("SHA1");
		    md.update(trxNo.toString().concat(iMap.getString("DOCUMENT_CODE")).getBytes());
		    String hash = DatatypeConverter.printHexBinary(md.digest()).toUpperCase();
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			GnlDokumanBaglantiTx dokumanBaglantiTx = (GnlDokumanBaglantiTx) session.get(GnlDokumanBaglantiTx.class, trxNo);
			
			if(dokumanBaglantiTx == null) {
				dokumanBaglantiTx = new GnlDokumanBaglantiTx(trxNo, iMap.getString("DOCUMENT_CODE"), 
					iMap.getBigDecimal("CUSTOMER_NO"), hash, new java.util.Date(), iMap.getString("SERVICE_NAME"),
					iMap.getString("REFERENCE"));
			} else {
				dokumanBaglantiTx.setLastModified(new java.util.Date());
			}
			
			session.saveOrUpdate(dokumanBaglantiTx);
			session.flush();
			
			if(iMap.getBoolean("SAVE_DOCUMENT")) {
				
				JasperPrint jasperPrint;
				
				@SuppressWarnings("unchecked")
				HashMap<String, Object> parameters = (HashMap<String, Object>) iMap.get("DOCUMENT_PARAMETERS");
				
				if(iMap.get("DOCUMENT_REPORT_NAME") instanceof List<?>) {
					@SuppressWarnings("unchecked")
					ArrayDeque<String> reportNames = new ArrayDeque<String>((List<String>) iMap.get("DOCUMENT_REPORT_NAME"));
					jasperPrint = ReportUtil.generateAndConcatReports(reportNames, parameters);
				} else {
					jasperPrint = ReportUtil.generateReport(iMap.getString("DOCUMENT_REPORT_NAME"), parameters);
				}
				
				byte[] report = JasperExportManager.exportReportToPdf(jasperPrint);
				
				GMMap dysMap = new GMMap();
				dysMap.put("DOKUMAN_TIPI", dokumanBaglantiTx.getDokumanKod());
				dysMap.put("REFERANS_TIPI", iMap.getString("REFERENCE_TYPE", referenceType));
				dysMap.put("MUSTERI_NO", dokumanBaglantiTx.getMusteriNo());
				dysMap.put("REFERANS_NO", iMap.getString("REFERENCE"));
				dysMap.put("TRX_NO", trxNo);
				dysMap.put("ONAYSIZ_ISLEM_MI", true);
				dysMap.put("DOSYA_SAYFA", 0, "CONTENT", report);
				dysMap.put("DOSYA_SAYFA", 0, "FILE_NAME", "MUST_IMAJ_" + dokumanBaglantiTx.getMusteriNo().toString() + "_" + dokumanBaglantiTx.getDokumanKod() + "_1.pdf");
				dysMap.put("DOSYA_SAYFA", 0, "PAGE_NUMBER", 1);
				
				if(GMServiceExecuter.call("BNSPR_CUSTOMER_TRN1090_IS_DOCUMENT_EXIST", dysMap).getBoolean("RESULT")) {
					GMServiceExecuter.execute("BNSPR_TRN1091_UPDATE_MUSTERI_DOKUMAN", dysMap);
				} else{
					GMServiceExecuter.execute("BNSPR_TRN1090_SAVE_MUSTERI_DOKUMAN", dysMap);
				}
				
				GMServiceExecuter.execute("BNSPR_MUSTERI_DOKUMAN_EKLE",
					new GMMap().put("MUSTERI_NO", dokumanBaglantiTx.getMusteriNo()).put("DOKUMAN_KODU",
						dokumanBaglantiTx.getDokumanKod()));
			}
			
			// TODO MSISDN ge�ilmediyse m��teri �zerindeki telefon numaras� ile ilerlenecek
			
			GMMap smsMap = new GMMap();
			if(iMap.containsKey("MESSAGE_CONTENT") && iMap.get("MESSAGE_CONTENT") instanceof GMMap) {
	    		iMap.putAll(iMap.getMap("MESSAGE_CONTENT"));
	    	}		
			smsMap.put("CONTENT", CurrentAccountsCommonServices.getKodsuzMessage(iMap.put("P1", hash))
				.getString("ERROR_MESSAGE"));
			smsMap.put("MSISDN" , iMap.getString("MSISDN"));
			smsMap.put("HEADER" , iMap.getString("HEADER"));
            smsMap.put("FILTER" , true);
            smsMap.put("SECURE_CONTENT" , true);
            smsMap.put("MUSTERI_NO", dokumanBaglantiTx.getMusteriNo());
            smsMap.put("TRX_NO", trxNo);
            GMServiceExecuter.call("BNSPR_SMS_SEND_SMS_ASYNC" , smsMap);
			
            oMap.put("RESPONSE", "2");
			oMap.put("TRX_NO", trxNo);
		} catch(Exception e) {
			log.error("BNSPR_COMMON_SEND_QS_DOCUMENT err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
    
    /**
     * Sorgu dizesi kar��l��� g�nderilmi� bir SMS mevcut ise, sorgu dizesi ile e�le�mi� belge servisini �a��r�r.
     * Belge servisinin <code>REPORT</code> key'ine kar��l�k gelen de�erin <code>JasperPrint</code> tipinde olmas�
     * bekleniyor.
     * 
     * @param iMap {K}	Validasyon ve belge e�le�tirmek i�in gerekli sorgu dizesi de�eri.
     * @return			E�er validasyon sa�lanamaz ise veya istisnai bir durum ortaya ��kar ise 
     * 					<code>GMMap{RESPONSE=0,RESPONSE_DATA=[Mesaj]}</code> d�ner, aksi takdirde 
     * 					<code>GMMap{RESPONSE=2,DOCUMENT_CODE=[Belge kodu],DOCUMENT_NAME=[Belge Ad�]}</code> d�ner.
     * 
     * 
	 * @see #getKodsuzMessage(GMMap)
	 * @see <a href="http://taksim.aktifbank.com.tr/fisheye/browse/BInspire/trunk/BNSPRDYS/src/tr/com/aktifbank/dys/services/DysFilenetServices.java?r=425146">
	 * 		DYS_CMIS_GET_DOCUMENT_LINK_BY_FILENAME_WITH_METADATA</a>
     */
    @GraymoundService("BNSPR_COMMON_GET_QS_DOCUMENT_PDF_BYTE")
	public static GMMap bnsprCommonGetQsDocumentPdfByte(GMMap iMap) {

		GMMap oMap = new GMMap();
		final String metaDataKey = "txNo";
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			GnlDokumanBaglantiTx dokumanBaglantiTx = (GnlDokumanBaglantiTx) 
				session.createCriteria(GnlDokumanBaglantiTx.class).add(Restrictions.eq("sorguDizesi" , iMap.getString("K")))
                .uniqueResult();
			
			if(dokumanBaglantiTx == null) {
				oMap.put("RESPONSE", "0");
				oMap.put("RESPONSE_DATA", CurrentAccountsCommonServices.getKodsuzMessage(new GMMap()
					.put("MESSAGE_NO", 50009)).getString("ERROR_MESSAGE"));
				return oMap;
			}
			
			if(dokumanBaglantiTx.getServis() != null) {
				oMap = GMServiceExecuter.call(dokumanBaglantiTx.getServis(), new GMMap().put("TRX_NO", dokumanBaglantiTx.getTxNo()));

				/**
				 * GMMap, REPORT key'ine kar��l�k JasperPrint tipinde de�er i�ermeli.
				 */
				if(!(oMap.containsKey("REPORT") && oMap.get("REPORT") instanceof JasperPrint)) {
					oMap.put("RESPONSE", "0");
					oMap.put("RESPONSE_DATA", CurrentAccountsCommonServices.getKodsuzMessage(new GMMap()
						.put("MESSAGE_NO", 5772)).getString("ERROR_MESSAGE"));
					return oMap;
				}
				
				oMap.put("REPORT", JasperExportManager.exportReportToPdf((JasperPrint) oMap.get("REPORT")));
					
			} else {
				
				String fileName = "MUST_IMAJ_" + dokumanBaglantiTx.getMusteriNo().toString() + "_" + dokumanBaglantiTx.getDokumanKod() + "_1.pdf";
				
				oMap = GMServiceExecuter.call("DYS_CMIS_GET_DOCUMENT_LINK_BY_FILENAME_WITH_METADATA", new GMMap()
					.put("DOKUMAN_ADI", fileName)
					.put("DOKUMAN_CLASS", "Musteri")
					.put("METADATA_MAP_KEY", metaDataKey)
					.put("METADATA_VALUE", dokumanBaglantiTx.getTxNo())
					.put("DOKUMAN_BYTE_ARRAY_NEEDED", true));
				
				@SuppressWarnings("unchecked")
				List<HashMap<?, ?>> documentByteArrayList = (ArrayList<HashMap<?,?>>) oMap.remove("DOKUMAN_BYTE_ARRAY_LIST");
				oMap.remove("DOKUMAN_LINK_LIST");
				
				// metaDataKey i�in tek bir s�r�m d�nmeli.
				for (Map.Entry<?, ?> entry : documentByteArrayList.get(0).entrySet()) {
					oMap.put("REPORT", entry.getValue());
					break;
				}
			}
			
			oMap.put("DOCUMENT_CODE", dokumanBaglantiTx.getDokumanKod());
			oMap.put("RESPONSE", "2");
			
			GnlDokumanKodPr dokuman = (GnlDokumanKodPr) session.get(GnlDokumanKodPr.class, dokumanBaglantiTx.getDokumanKod());
			
			if(dokuman != null) {
				oMap.put("DOCUMENT_NAME", dokuman.getAciklama());
			}
			
		} catch (Exception e) {
			log.error("BNSPR_COMMON_GET_QS_DOCUMENT_PDF_BYTE err:", e);
			oMap.put("RESPONSE", "0");
			oMap.put("RESPONSE_DATA", e.getMessage());
		}

		return oMap;
	}

	   @GraymoundService("BNSPR_COMMON_NKOLAYAPP_HAREKET_LIST")
	    public static GMMap getNKolayappHareketList(GMMap iMap) {

	        Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;
	        try {
	            conn = DALUtil.getGMConnection();

	            stmt = conn.prepareCall("{? = call PKG_NKOLAY_APP.Hesap_Hareket(?,?,?,?,?,?,?,?,?)}");

	            int i = 1;
	            stmt.registerOutParameter(i++, -10);
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
	            if (!StringUtil.isEmpty(iMap.getString("BASLANGIC_TARIHI")))
	                stmt.setDate(i++, new java.sql.Date(iMap.getDate("BASLANGIC_TARIHI").getTime()));
	            else
	                stmt.setDate(i++, null);
	            if (!StringUtil.isEmpty(iMap.getString("BITIS_TARIHI")))
	                stmt.setDate(i++, new java.sql.Date(iMap.getDate("BITIS_TARIHI").getTime()));
	            else
	                stmt.setDate(i++, null);
	            stmt.setString(i++, iMap.getString("ISLEM_TIPI"));
	            stmt.setString(i++, iMap.getString("KANAL_TIPI"));
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_TUTAR"));
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_TUTAR"));
	            stmt.setString(i++, iMap.getString("LANGUAGE"));
	            stmt.setString(i++, iMap.getString("F_SON10"));

	            stmt.execute();
	            stmt.getMoreResults();
	            rSet = (ResultSet) stmt.getObject(1);
	            GMMap oMap = DALUtil.rSetResults(rSet, BnsprCommonFunctions.getTableName(iMap));
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {
	            GMServerDatasource.close(rSet);
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }

	   @GraymoundService("BNSPR_COMMON_NKOLAYAPP_RETRAN_DETAIL")
	    public static GMMap getNKolayappRetranDetail(GMMap iMap) {

	        Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;
	        try {
	            conn = DALUtil.getGMConnection();

	            stmt = conn.prepareCall("{? = call PKG_NKOLAY_APP.Islem_Tekrar_Detay(?)}");

	            int i = 1;
	            stmt.registerOutParameter(i++, -10);
	            stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_NO"));

	            stmt.execute();
	            stmt.getMoreResults();
	            rSet = (ResultSet) stmt.getObject(1);
	            GMMap oMap = DALUtil.rSetResults(rSet, BnsprCommonFunctions.getTableName(iMap));
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        } finally {
	            GMServerDatasource.close(rSet);
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }
		@GraymoundService("BNSPR_FIS_KONTROL")
		public static GMMap fisKontrol(GMMap iMap) throws SQLException{
			GMMap oMap = new GMMap();
			Object[] inputValues = new Object[4];
			inputValues[0] = BnsprType.STRING;
			inputValues[1] = iMap.getString("ISLEM_KOD");
			inputValues[2] = BnsprType.NUMBER;
			inputValues[3] = iMap.getBigDecimal("ISLEM_NO");
			Object[] outputValues = new Object[0];
			String proc = "{ call PKG_PAR_BOOK_CONTROL.FIS_YARAT(?,?)}";
			DALUtil.callOracleProcedure(proc, inputValues, outputValues);
			return oMap;
		}

	    @GraymoundService("BNSPR_COMMON_VIP_HESAP_IZLEYEBILIRMI")
		public static GMMap vipHesapIzleyebilirmi(GMMap iMap) { 
			GMMap oMap = new GMMap();
			Connection conn = null;
			CallableStatement stmt = null;
			try {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call pkg_rc_current_accounts.VIP_Hesap_izleyebilirmi(?)}");
				stmt.registerOutParameter(1, Types.CHAR);
				stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));

				stmt.execute();

				oMap.put("IZLESIN", stmt.getObject(1)); // values {0,1}
				oMap.put("IS_IZLESIN", GuimlUtil.convertBinaryToCheckBoxSelected(stmt.getString(1))); // values
																										// {false,true}}

			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
			return oMap;
		}
	    
	  @GraymoundService("BNSPR_EXTRE_MAIL_GONDERIM_LOG")
		public static GMMap extreMailGonderimLog(GMMap iMap) { 
			GMMap oMap = new GMMap();
			Connection conn = null;
			CallableStatement stmt = null;
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call PKG_EKSTRE.R2040_Ekstre_Logla(?,?,?,?,?,?)}");
				stmt.setBigDecimal(1, iMap.getBigDecimal("HESAP_NO"));
				stmt.setString(2, sdf.format(iMap.getDate("EKSTRE_BASLANGIC_TAR")));
				stmt.setString(3, sdf.format(iMap.getDate("EKSTRE_BITIS_TAR")));
                stmt.setString(4, iMap.getString("EPOSTA"));
    			if (iMap.getBoolean("INGILIZCE")){
    				 stmt.setString(5, "EN");
    			}
    			else
    			{
   				 stmt.setString(5, "TR");
    			}
    			stmt.setString(6, iMap.getString("EMAIL_PDF"));
				
				stmt.execute();

			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
			return oMap;
		}
	  
	  @GraymoundService("BNSPR_COMMON_CLOSE_ACCOUNT")
	    public static Map<?, ?> closeAccount(GMMap iMap) {
	        GMMap oMapAccountInfo = new GMMap();
	        BigDecimal defterBakiye = null;
	        String referans = null;
	        try 
	        {                        
	            oMapAccountInfo.putAll(
	            	GMServiceExecuter.execute("BNSPR_TRN2002_GET_ACCOUNT_INFO",new GMMap() 
	            															   .put("ACCOUNT_NO", iMap.getBigDecimal("HESAP_NO"))
	            										                       .put("KAPAMA_TURU", "K")));

	            GMServiceExecuter.execute("BNSPR_TRN2002_HAZINE_KONTROL",new GMMap() 
				   														   .put("MUSTERI_NO", oMapAccountInfo.getBigDecimal("MUSTERI_NO"))
				   														   .put("HESAP_NO", iMap.getBigDecimal("HESAP_NO")));
	            
	            defterBakiye = GMServiceExecuter.call("BNSPR_COMMON_GET_DEFTER_BAKIYE", 
	            									  new GMMap() .put("HESAP_NO", iMap.getBigDecimal("HESAP_NO"))).getBigDecimal("DEFTER_BAKIYE");
	            
	        	if (!(defterBakiye.compareTo(new BigDecimal(0)) == 0)) 
	        	{
	        		GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", new GMMap() .put("HATA_NO", 6144));
				}
	        	
	            referans = GMServiceExecuter.call("BNSPR_TRN2002_DISISLEMLER_KONTROL", 
						  new GMMap() .put("MUSTERI_NO", oMapAccountInfo.getBigDecimal("MUSTERI_NO"))).getString("REFERANS");
	            
	        	if (!("X".equalsIgnoreCase(referans)))
	        	{
	        		GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", new GMMap() .put("HATA_NO", 6145) .put("P1", referans));
				}
	        	       
	        	oMapAccountInfo.put("ACIKLAMA","M��teri Hesap Kapama");
	        	oMapAccountInfo.put("TRX_ONAYSIZ_ISLEM","E");
	        	GMServiceExecuter.execute("BNSPR_TRN2002_SAVE",oMapAccountInfo);
	        	
	        	oMapAccountInfo.put("RESPONSE","2");
	        } catch (Exception e) {
	        	throw ExceptionHandler.convertException(e);
	        }//end of try-catch
	        return oMapAccountInfo;
	    }//end of closeAccount
	  
	  @GraymoundService("BNSPR_KOPRU_IBAN_HESAP_MI")
	  public static GMMap kopruIbanHesapMi(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		try {
			String kopruHesap = "H";
			String kisaIsim = "";
					
			MuhHesapKopruiban kopruIban = null;
			
			if(iMap.containsKey("HESAP_NO")){
				kopruIban = (MuhHesapKopruiban) session.createCriteria(MuhHesapKopruiban.class).add(Restrictions.eq("id.hesapNo", iMap.getBigDecimal("HESAP_NO"))).uniqueResult();
			}
			else if(iMap.containsKey("IBAN")){
				kopruIban = (MuhHesapKopruiban) session.createCriteria(MuhHesapKopruiban.class).add(Restrictions.eq("iban", iMap.getString("IBAN"))).uniqueResult();
			}
			
			if(kopruIban != null){
				kopruHesap = "E";
				kisaIsim = kopruIban.getKisaIsim();
			}
			
			oMap.put("KOPRU_HESAP", kopruHesap);
			oMap.put("KISA_ISIM", kisaIsim);
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		  return oMap;
	  }

}
