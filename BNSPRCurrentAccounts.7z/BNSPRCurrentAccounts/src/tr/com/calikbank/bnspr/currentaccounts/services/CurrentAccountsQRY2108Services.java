package tr.com.calikbank.bnspr.currentaccounts.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class CurrentAccountsQRY2108Services {
 
	
	@GraymoundService("BNSPR_QRY2108GET_TALIMAT_LIST")
    public static GMMap getTalimatList(GMMap iMap){
	    Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
	    try
	    {
	        
	    	conn = DALUtil.getGMConnection();
	    	stmt = conn .prepareCall("{? = call PKG_RC2108.getTalimatList(?,?,?,?,?)}");
            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setBigDecimal(2 ,iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setBigDecimal(3 ,iMap.getBigDecimal("HESAP_NO"));
            stmt.setString(4 ,iMap.getString("DOVIZ_KODU"));
            if(iMap.getDate("ILK_TARIH")!=null)
              stmt.setDate(5 ,  new Date(iMap.getDate("ILK_TARIH").getTime()));
            else
                stmt.setDate(5,null);
            if(iMap.getDate("SON_TARIH")!=null)
                stmt.setDate(6 , new Date(iMap.getDate("SON_TARIH").getTime()));
            else
                stmt.setDate(6,null);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            return DALUtil.rSetResults(rSet, "PLAN_LIST");
	    } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
	}
	@GraymoundService("BNSPR_QRY2108GET_TALIMAT_DETAIL")
    public static GMMap getTalimatDetails(GMMap iMap){
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try
        {            
        	conn = DALUtil.getGMConnection();
            stmt = conn .prepareCall("{? = call PKG_RC2108.getTalimatDetailList(?)}");
            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setBigDecimal(2 ,iMap.getBigDecimal("TX_NO"));
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(1);
            return DALUtil.rSetResults(rSet, "PLAN_DETAIL_LIST");
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
	
	
}
