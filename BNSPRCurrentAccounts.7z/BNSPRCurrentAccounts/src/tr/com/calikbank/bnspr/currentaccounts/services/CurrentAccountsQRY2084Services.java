package tr.com.calikbank.bnspr.currentaccounts.services;

import java.awt.Color;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class CurrentAccountsQRY2084Services {
    
    @GraymoundService("BNSPR_QRY2084_DETAY_INITIALIZE")
    public static GMMap detayGetir(GMMap iMap) {
        GMMap oMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        int index = 0;
        int row = 0;
        try {
            
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ call PKG_SEKER.MutabakatDetay(?,?,?,?,?)}");
            stmt.setDate(++index, new Date(iMap.getDate("TARIH").getTime()));
            stmt.setString(++index, iMap.getString("DOVIZ"));
            stmt.setString(++index, iMap.getString("ISLEM"));
            stmt.registerOutParameter(++index, -10);
            stmt.registerOutParameter(++index, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(index - 1);
            while (rSet.next()) {
                oMap.put("TABLE", row, "HESAPNO", rSet.getObject("HESAPNO"));
                oMap.put("TABLE", row, "ISIM", rSet.getObject("ISIM"));
                oMap.put("TABLE", row, "TUTAR", rSet.getObject("TUTAR"));
                oMap.put("TABLE", row, "PARACINSI", rSet.getObject("PARACINSI"));
                oMap.put("TABLE", row, "SEKERBANKREFERANS", rSet.getObject("SEKERBANKREFERANS"));
                oMap.put("TABLE", row, "ISLEMNO", rSet.getObject("ISLEMNO"));
                row++;
                
            }
            row = 0;
            rSet = (ResultSet) stmt.getObject(index);
            while (rSet.next()) {
                oMap.put("TABLE", row, "SEKERHESAPNO", rSet.getObject("SEKERHESAPNO"));
                oMap.put("TABLE", row, "SEKERTUTAR", rSet.getObject("SEKERTUTAR"));
                oMap.put("TABLE", row, "SEKERPARACINSI", rSet.getObject("SEKERPARACINSI"));
                oMap.put("TABLE", row, "SSEKERBANKREFERANS", rSet.getObject("SSEKERBANKREFERANS"));
                row++;
                
            }
            
            return oMap;
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
            
        }
        
    }
    
    @GraymoundService("BNSPR_QRY2084_QUERY_GETIR")
    public static GMMap sorguGetir(GMMap iMap) {
        GMMap oMap = new GMMap();
        GMMap sMap = new GMMap();
        GMMap aMap = new GMMap();
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        int index = 0;
        int row = 0;
        try {
            
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ call PKG_SEKER.MutabakatOzet(?,?,?,?,?)}");
            stmt.setDate(++index, new Date(iMap.getDate("BANKA_TARIH").getTime()));
            stmt.registerOutParameter(++index, -10);
            stmt.registerOutParameter(++index, -10);
            stmt.registerOutParameter(++index, -10);
            stmt.registerOutParameter(++index, -10);
            stmt.execute();
            rSet = (ResultSet) stmt.getObject(index - 3);
            while (rSet.next()) {
                oMap.put("YATAN", row, "DOVIZ_KODU", rSet.getObject("DOVIZ_KODU"));
                oMap.put("YATAN", row, "COUNT(*)", rSet.getObject("COUNT(*)"));
                oMap.put("YATAN", row, "SUM(S.TUTAR)", rSet.getObject("SUM(S.TUTAR)"));
                row++;
                
            }
            rSet = (ResultSet) stmt.getObject(index - 1);
            
            row = 0;
            while (rSet.next()) {
                oMap.put("YATAN", row, "CURR_CODE", rSet.getObject("CURR_CODE"));
                oMap.put("YATAN", row, "SEKERCOUNT", rSet.getObject("SEKERCOUNT"));
                oMap.put("YATAN", row, "SUM(AMOUNT)", rSet.getObject("SUM(AMOUNT)"));
                row++;
                
            }
            
            rSet = (ResultSet) stmt.getObject(index - 2);
            row = 0;
            
            while (rSet.next()) {
                oMap.put("CEKILEN", row, "DOVIZ_KODU", rSet.getObject("DOVIZ_KODU"));
                oMap.put("CEKILEN", row, "COUNT(*)", rSet.getObject("COUNT(*)"));
                oMap.put("CEKILEN", row, "SUM(S.TUTAR)", rSet.getObject("SUM(S.TUTAR)"));
                row++;
                
            }
            
            rSet = (ResultSet) stmt.getObject(index);
            row = 0;
            while (rSet.next()) {
                oMap.put("CEKILEN", row, "CURR_CODE", rSet.getObject("CURR_CODE"));
                oMap.put("CEKILEN", row, "SEKERCOUNT", rSet.getObject("SEKERCOUNT"));
                oMap.put("CEKILEN", row, "SUM(AMOUNT)", rSet.getObject("SUM(AMOUNT)"));
                row++;
                
            }
            
            
            GMMap colorChanged = new GMMap();
            colorChanged.put("setBackground", Color.RED);
            colorChanged.put("setForeground", Color.BLACK);
            
            GMMap colorNotChanged  = new GMMap();
            colorNotChanged.put("setBackground", Color.WHITE);
            colorNotChanged.put("setForeground", Color.BLACK);
            
            index = 0;
            while (index < oMap.getSize("YATAN")) {
                if (oMap.getString("YATAN", index, "SUM(S.TUTAR)") != null && oMap.getString("YATAN", index, "SUM(AMOUNT)") != null) {
                    if (!oMap.getString("YATAN", index, "SUM(S.TUTAR)").equals(oMap.getString("YATAN", index, "SUM(AMOUNT)"))) {
                        oMap.put("COLOR_DATA_YATAN", index, "SUM(S.TUTAR)", colorChanged);
                        oMap.put("COLOR_DATA_YATAN", index, "SUM(AMOUNT)", colorChanged);
                    }
                    
                    else {
                        oMap.put("COLOR_DATA_YATAN", index, "SUM(S.TUTAR)", colorNotChanged);
                        oMap.put("COLOR_DATA_YATAN", index, "SUM(AMOUNT)", colorNotChanged);
                    }
                }
                else {
                    if (oMap.getString("YATAN", index, "SUM(S.TUTAR)") != null && oMap.getString("YATAN", index, "SUM(AMOUNT)") == null) {
                        oMap.put("COLOR_DATA_YATAN", index, "SUM(S.TUTAR)", colorChanged);
                    }
                    if (oMap.getString("YATAN", index, "SUM(S.TUTAR)") == null && oMap.getString("YATAN", index, "SUM(AMOUNT)") != null) {
                        oMap.put("COLOR_DATA_YATAN", index, "SUM(AMOUNT)", colorChanged);
                    }
                    
                }
                if (oMap.getString("YATAN", index, "COUNT(*)") != null && oMap.getString("YATAN", index, "SEKERCOUNT") != null) {
                    if (!oMap.getString("YATAN", index, "COUNT(*)").equals(oMap.getString("YATAN", index, "SEKERCOUNT"))) {
                        oMap.put("COLOR_DATA_YATAN", index, "COUNT(*)", colorChanged);
                        oMap.put("COLOR_DATA_YATAN", index, "SEKERCOUNT", colorChanged);
                    }
                    else {
                        oMap.put("COLOR_DATA_YATAN", index, "SUM(S.TUTAR)", colorNotChanged);
                        oMap.put("COLOR_DATA_YATAN", index, "SUM(AMOUNT)", colorNotChanged);
                    }
                }
                else {
                    if (oMap.getString("YATAN", index, "COUNT(*)") != null && oMap.getString("YATAN", index, "SEKERCOUNT") == null) {
                        oMap.put("COLOR_DATA_YATAN", index, "COUNT(*)", colorChanged);
                    }
                    if (oMap.getString("YATAN", index, "COUNT(*)") == null && oMap.getString("YATAN", index, "SEKERCOUNT") != null) {
                        oMap.put("COLOR_DATA_YATAN", index, "SEKERCOUNT", colorChanged);
                    }
                }
                index++;
            }
            
            index = 0;
            while (index < oMap.getSize("CEKILEN")) {
                if (oMap.getString("CEKILEN", index, "SUM(S.TUTAR)") != null && oMap.getString("CEKILEN", index, "SUM(AMOUNT)") != null) {
                    if (!oMap.getString("CEKILEN", index, "SUM(S.TUTAR)").equals(oMap.getString("CEKILEN", index, "SUM(AMOUNT)"))) {
                        oMap.put("COLOR_DATA_CEKILEN", index, "SUM(S.TUTAR)", colorChanged);
                        oMap.put("COLOR_DATA_CEKILEN", index, "SUM(AMOUNT)", colorChanged);
                    }
                    else {
                        oMap.put("COLOR_DATA_CEKILEN", index, "SUM(S.TUTAR)", colorNotChanged);
                        oMap.put("COLOR_DATA_CEKILEN", index, "SUM(AMOUNT)", colorNotChanged);
                    }
                }
                else {
                    if (oMap.getString("CEKILEN", index, "SUM(S.TUTAR)") != null && oMap.getString("CEKILEN", index, "SUM(AMOUNT)") == null) {
                        oMap.put("COLOR_DATA_CEKILEN", index, "SUM(S.TUTAR)", colorChanged);
                    }
                    if (oMap.getString("CEKILEN", index, "SUM(S.TUTAR)") == null && oMap.getString("CEKILEN", index, "SUM(AMOUNT)") != null) {
                        oMap.put("COLOR_DATA_CEKILEN", index, "SUM(AMOUNT)", colorChanged);
                    }
                }
                if (oMap.getString("CEKILEN", index, "COUNT(*)") != null && oMap.getString("CEKILEN", index, "SEKERCOUNT") != null) {
                    if (!oMap.getString("CEKILEN", index, "COUNT(*)").equals(oMap.getString("CEKILEN", index, "SEKERCOUNT"))) {
                        oMap.put("COLOR_DATA_CEKILEN", index, "COUNT(*)", colorChanged);
                        oMap.put("COLOR_DATA_CEKILEN", index, "SEKERCOUNT", colorChanged);
                    }
                    
                    else {
                        oMap.put("COLOR_DATA_CEKILEN", index, "SUM(S.TUTAR)", colorNotChanged);
                        oMap.put("COLOR_DATA_CEKILEN", index, "SUM(AMOUNT)", colorNotChanged);
                        
                    }
                }
                else {
                    if (oMap.getString("CEKILEN", index, "COUNT(*)") != null && oMap.getString("CEKILEN", index, "SEKERCOUNT") == null) {
                        oMap.put("COLOR_DATA_CEKILEN", index, "COUNT(*)", colorChanged);
                    }
                    if (oMap.getString("CEKILEN", index, "COUNT(*)") == null && oMap.getString("CEKILEN", index, "SEKERCOUNT") != null) {
                        oMap.put("COLOR_DATA_CEKILEN", index, "SEKERCOUNT", colorChanged);
                    }
                    
                }
                index++;
            }
            return oMap;
            
        }
        
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
            
        }
        
    }
    
    
    @GraymoundService("BNSPR_QRY2084_IZLEME_SORGULA")
    public static GMMap izlemeSorgula (GMMap iMap) {
        
        GMMap oMap = new GMMap();
        String proc = "{call PKG_SEKER.islemIzleme(?,?)}";
        
        
        try {
            Object[] inputValues =  new Object[]{ BnsprType.DATE, iMap.getDate("TARIH")};
            Object[] outputValues = new Object[]{ BnsprType.REFCURSOR, "MUTABAKAT"};
            oMap = (GMMap) DALUtil.callOracleProcedure(proc ,inputValues ,outputValues );
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    
}
