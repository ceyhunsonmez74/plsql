package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ClksMutabakatNetOff;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ClksHavaleGirisTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsQRY2052Services {

	private static Logger logger = Logger.getLogger(CurrentAccountsQRY2056Services.class);

	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_1ST_LEVEL")
	public static GMMap getFirstLevel(GMMap iMap){
		
		GMMap oMap = new GMMap();
		
		BigDecimal PTTYT1 =  new BigDecimal(0);
		BigDecimal AKTIFBANKYT1 =new BigDecimal(0);
		BigDecimal pttbankYT2 =new BigDecimal(0);
		BigDecimal YATAN_AKT_EUR =new BigDecimal(0);
		BigDecimal pttbankYT3  = new BigDecimal(0);
	    BigDecimal AKTIFBANKYT3 = new BigDecimal(0);
	       
	    BigDecimal MASRAFYATANPTTTRY =  new BigDecimal(0);
	    BigDecimal MASRAFYATANAKTIFBANKTRY =  new BigDecimal(0);
	    BigDecimal MASRAFYATANPTTEUR =  new BigDecimal(0);
	    BigDecimal MASRAFYATANAKTIFBANKEUR =  new BigDecimal(0);
	    BigDecimal MASRAFYATANPTTUSD =  new BigDecimal(0);
	    BigDecimal MASRAFYATANAKTIFBANKUSD =  new BigDecimal(0);
	    
	    BigDecimal PPTYATANADETTRY =  new BigDecimal(0);
	    BigDecimal AKTIFBANKYATANADETTRY =  new BigDecimal(0);
	    BigDecimal PTTYATANADETEUR =  new BigDecimal(0);
	    BigDecimal AKTIFBANKYATANADETEUR =  new BigDecimal(0);
	    BigDecimal PTTYATANADETUSD =  new BigDecimal(0);
	    BigDecimal AKTIFBANKYATANADETUSD =  new BigDecimal(0);
	    
	    BigDecimal pttbankCT1 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT1 =  new BigDecimal(0);
	    BigDecimal pttbankCT2 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT2 =  new BigDecimal(0);
	    BigDecimal pttbankCT3 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT3 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT1_BORC =  new BigDecimal(0); // Iade PCH
	 
	    BigDecimal MASRAFCEKILENPTTTRY =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENAKTIFBANKTRY =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENPTTEUR =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENAKTIFBANKEUR =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENPTTUSD =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENAKTIFBANKUSD =  new BigDecimal(0);
	    
	    BigDecimal PPTCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal PTTCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal PTTCEKILENADETUSD =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCEKILENADETUSD =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANEUR =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENUSD =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENUSD =  new BigDecimal(0);

	    BigDecimal IPTALMASRAFPTTYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFPTTYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFPTTYATANEUR =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKYATANEUR =  new BigDecimal(0);
	    
	    BigDecimal IPTALMASRAFPTTCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFPTTCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFPTTCEKILENUSD =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKCEKILENUSD =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTYATANADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALBANKAYATANADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANADETUSD =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANADETUSD =  new BigDecimal(0);

	    BigDecimal IPTALPTTCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALBANKACEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENADETUSD =  new BigDecimal(0);
	    BigDecimal IPTALBANKACEKILENADETUSD =  new BigDecimal(0);
	    
	    GMMap oMapOnlyMutabakatsiz = new GMMap();
	    GMMap oMapOnlyMutabakatsizAkt = new GMMap();
	    
	    int i = 1;
   
		try{

			oMap.put("CBS_AKTIFBANK_PTT", GMServiceExecuter.execute("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF", iMap).get("CBS_AKTIFBANK"));
			
			String tableName = "CBS_AKTIFBANK_PTT";
			i =  oMap.getSize(tableName); 
			int j=0;
			
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_MUTABAKATSIZLAR", iMap));

			String tableName2 = "CBS_AKTIFBANK_PTT";
			tableName = "CBS_AKTIFBANK_PTT_MUTABAKATSIZ";
			oMap.put("KAYIT_SAYISI", iMap.getSize(tableName));
			for ( j = 0; j < iMap.getSize(tableName); j++) {
				oMap.put(tableName2, i, "ISLEM_TURU_PTT", iMap.getString(tableName, j, "ISLEM_TURU_PTT"));
				oMap.put(tableName2, i, "PTT_ISLEM_TUTARI", iMap.getString(tableName, j, "PTT_ISLEM_TUTARI"));
				oMap.put(tableName2, i, "PTT_ISLEM_TUTARITL", iMap.getString(tableName, j, "PTT_ISLEM_TUTARITL"));
				oMap.put(tableName2, i, "PTT_MASRAF_TUTARI", iMap.getString(tableName, j, "PTT_MASRAF_TUTARI"));
				oMap.put(tableName2, i, "ISLEM_NO_PTT", iMap.getString(tableName, j, "ISLEM_NO_PTT"));
				oMap.put(tableName2, i, "NUMARA", iMap.getString(tableName, j, "NUMARA"));  // ISLEMNOBANKA				
				oMap.put(tableName2, i, "PTT_DOVIZ_KODU", iMap.getString(tableName, j, "PTT_DOVIZ_KODU"));				
				oMap.put(tableName2, i, "EFT_HESAP_KASA", iMap.getString(tableName, j, "EFT_HESAP_KASA"));				
				oMap.put(tableName2, i, "ISLEM", iMap.getString(tableName, j, "ISLEM"));				
				oMap.put(tableName2, i, "PTT_TOPLAM_TUTAR",iMap.getString(tableName, j, "PTT_TOPLAM_TUTAR"));				
				oMap.put(tableName2, i, "ISLEM_ADI_PTT",iMap.getString(tableName, j, "ISLEM_ADI_PTT"));				
				oMap.put(tableName2, i, "MASRAF_DOVIZ_KODU",iMap.getString(tableName, j, "MASRAF_DOVIZ_KODU"));
				oMap.put(tableName2, i, "AKTIFBANK_DOVIZ_KODU", iMap.getString(tableName, j, "AKTIFBANK_DOVIZ_KODU"));
				oMap.put(tableName2, i, "AKTIFBANK_DOVIZ_TUTARI",iMap.getString(tableName, j, "AKTIFBANK_DOVIZ_TUTARI"));	
				oMap.put(tableName2, i, "PTT_DOVIZ_TUTARI",iMap.getString(tableName, j, "PTT_DOVIZ_TUTARI"));
				oMap.put(tableName2, i, "AKTIFBANK_TL_TUTARI",iMap.getString(tableName, j, "AKTIFBANK_TL_TUTARI"));
				oMap.put(tableName2, i, "PTT_TL_TUTARI",iMap.getString(tableName, j, "PTT_TL_TUTARI"));
				
				/*iMap.getBigDecimal(tableName, j,"PTT_ISLEM_TUTARI").intValue()+ iMap.getBigDecimal(tableName, j,"PTT_MASRAF_TUTARI").intValue());*/
				i++;
			}
			
			iMap.remove(tableName); // e�er BNSPR_QRY2052_RC_MUTABAKATSIZLAR_AKT servisinden d�n�� olmaz ise , bir sonraki d�ng�ye girme.
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_AKT", iMap));
			
			for ( j = 0; j < iMap.getSize(tableName); j++) {
				
				oMap.put(tableName2, i, "ISLEM_TURU_PTT", iMap.getString(tableName, j, "ISLEM_TURU_PTT"));
				oMap.put(tableName2, i, "ISLEM_KOD", iMap.getString(tableName, j, "ISLEM_KOD"));
				oMap.put(tableName2, i, "TOPLAM_TUTAR", iMap.getString(tableName, j, "TOPLAM_TUTAR"));
				oMap.put(tableName2, i, "TUTAR", iMap.getString(tableName, j, "TUTAR"));			
				oMap.put(tableName2, i, "ISLEM_ADI_PTT", iMap.getString(tableName, j, "ISLEM_ADI_PTT"));				
				oMap.put(tableName2, i, "ISLEM", iMap.getString(tableName, j, "ISLEM"));
				oMap.put(tableName2, i, "AKTIFBANK_DOVIZ_KODU", iMap.getString(tableName, j, "AKTIFBANK_DOVIZ_KODU"));
				oMap.put(tableName2, i, "NUMARA", iMap.getString(tableName, j, "NUMARA"));
				oMap.put(tableName2, i, "MASRAF", iMap.getString(tableName, j, "MASRAF"));
				oMap.put(tableName2, i, "TUTARTL", iMap.getString(tableName, j, "TUTARTL"));
				i++;
			}
			
			tableName2 = "CBS_AKTIFBANK_PTT";
			for  ( j = 0; j < oMap.getSize(tableName2); j++) {  // Aktifbank i�lem T�P� null sa demekki banka islemi
					
				// PTT Yatan
				if ("Nakit Yatirma".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) || 
						"Kredi Tahsilati".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
						"UPT Nakit Yatirma".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
					
					if ( oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {
							
							
						if( oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  )  {
							//pft hesaptan ise g�z�n�nde tutulmuyacak...
							if (  oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0 ){
								PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
								
								if( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ) {
									MASRAFYATANPTTTRY =  MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
								}
								PPTYATANADETTRY   = PPTYATANADETTRY.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
								pttbankYT2 = pttbankYT2.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
								
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR")==0 ) {
									MASRAFYATANPTTEUR = MASRAFYATANPTTEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
								}
								if( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ) {
									MASRAFYATANPTTTRY =  MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
								}					
								PTTYATANADETEUR = PTTYATANADETEUR.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
								
								pttbankYT3 = pttbankYT3.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
									
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD")==0 ) {
									MASRAFYATANPTTUSD = MASRAFYATANPTTUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
								}
								if( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ) {
									MASRAFYATANPTTTRY =  MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
								}
								PTTYATANADETUSD = PTTYATANADETUSD.add(new BigDecimal(1));
							}			
						}
					}
				}
				
				// PTT Yatan - TL UPT, PCH
				if("PTT EFT".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
					
					if(!"HESAPTAN".equals(oMap.getString(tableName2, j, "EFT_HESAP_KASA")))  {
						PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						MASRAFYATANPTTTRY =  MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
						PPTYATANADETTRY   = PPTYATANADETTRY.add(new BigDecimal(1));
					}
				}
				
				// PTT Yatan - PCH
				if("PTT PCH".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
					PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
					MASRAFYATANPTTTRY =  MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
					PPTYATANADETTRY   = PPTYATANADETTRY.add(new BigDecimal(1));
				}
	
				// PTT Yatan - Talimatli UPT
				if ("SWIFT_GIDEN".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
					"TU_GIDEN".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
					"TALIMATLI_ISME".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
					"TALIMATLI_SWIFT".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
					"TALIMATLI_EFT".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
					
					if ( oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {
						if( oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  )  {
							//pft hesaptan ise g�z�n�nde tutulmuyacak...
	
							if (oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI").compareTo(new BigDecimal(0)) == 1 && oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI").compareTo(new BigDecimal(0)) == 0){
								PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
								PPTYATANADETTRY   = PPTYATANADETTRY.add(new BigDecimal(1));
							}
							else if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){ 	  
								pttbankYT2 = pttbankYT2.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
								PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
								PTTYATANADETEUR = PTTYATANADETEUR.add(new BigDecimal(1));
							}
							else if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
								pttbankYT3 = pttbankYT3.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
								PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
								PTTYATANADETUSD = PTTYATANADETUSD.add(new BigDecimal(1));
							}
							
							if("TALIMATLI_EFT".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
								MASRAFYATANPTTTRY =  MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							}
						}
					}
				}
				
				 // PTT Yatan - PTT Matik 
				if("Hesaba Nakit Yatirma".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
						"IBAN a Nakit Yatirma".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
						"EUPT Hesabina Nakit Yatirma".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
						"ATM N Kolay Karta Nakit Yat�rma".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
						"ATM Karta Nakit Yatirma".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
					
					PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
					PPTYATANADETTRY   = PPTYATANADETTRY.add(new BigDecimal(1));
					MASRAFYATANPTTTRY =  MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
				}
				
				
				// PTT Yatan - kart islemleri ptt hesabi
				if("TFF Karta Nakit Yat�rma".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) || "N Kolay Karta Nakit Yat�rma".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {

					PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
					PPTYATANADETTRY   = PPTYATANADETTRY.add(new BigDecimal(1));
					MASRAFYATANPTTTRY =  MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
				}
				
				// PTT Cekilen
				if ("Nakit Cekme".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))  ||
						"Kredi Kullandirim".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))  ||   
						"PTT UPT".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
						"SIGORTA".equals(oMap.getString(tableName2, j, "ISLEM"))||
						"UPT Nakit Cekme".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
					
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
							pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
							
							if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
								MASRAFCEKILENPTTTRY =  MASRAFCEKILENPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}
							
							PPTCEKILENADETTRY   = PPTCEKILENADETTRY.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
							pttbankCT2 = pttbankCT2.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
							
							if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR")==0 ) {
								MASRAFCEKILENPTTEUR = MASRAFCEKILENPTTEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}
							if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
								MASRAFCEKILENPTTTRY =  MASRAFCEKILENPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}
							PTTCEKILENADETEUR = PTTCEKILENADETEUR.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
							pttbankCT3 = pttbankCT3.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
							
							if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD")==0 ) {
								MASRAFCEKILENPTTUSD = MASRAFCEKILENPTTUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}
							if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
								MASRAFCEKILENPTTTRY =  MASRAFCEKILENPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}
							PTTCEKILENADETUSD = PTTCEKILENADETUSD.add(new BigDecimal(1));
						}
					}				
					
				}
					
				// PTT Cekilen
				if ("Referansli Odeme".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
						"SWIFT_GELEN".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
						"TU_GELEN".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
						"Iade UPT Odemesi".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
					
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){				
						
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
							pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
							PPTCEKILENADETTRY   = PPTCEKILENADETTRY.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
							pttbankCT2 = pttbankCT2.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
							PTTCEKILENADETEUR = PTTCEKILENADETEUR.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
							pttbankCT3 = pttbankCT3.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
							PTTCEKILENADETUSD = PTTCEKILENADETUSD.add(new BigDecimal(1));
						}
						
						pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARITL") ) ;
					}
				}
				
				// Aktifbank, PTT Cekilen - PCH Iade
				if("IADE PCH".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
					
					// Case: PTT Cekilen (Iade PCH)
					if (oMap.get(tableName2, j, "PTT_ISLEM_TUTARI") != null) {

						pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						PPTCEKILENADETTRY = PPTCEKILENADETTRY.add(new BigDecimal(1));
					}
					
					// Case: Aktifbank Islemler
					if (oMap.getString(tableName2, j, "ISLEM_KOD") != null) {

						// Case: Aktifbank Cekilen
						AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
						AKTIFBANKCEKILENADETTRY = AKTIFBANKCEKILENADETTRY.add(new BigDecimal(1));
						AKTIFBANKCT1_BORC = AKTIFBANKCT1;
					}
				}
	
				// IPTAL YATAN ptt
				if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  &&  
						oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  
						(oMap.getString(tableName2, j, "ISLEM").compareTo("NY") == 0 || 
						oMap.getString(tableName2, j, "ISLEM").compareTo("UPT_NY") == 0
						)) {
					
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
						
						if( oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("PTT EFT") !=0 && 
						  oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  ){
							//pft hesaptan olmayanlar
							
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
								IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
								
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
									IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
								}
								IPTALPTTYATANADETTRY = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
								IPTALPTTYATANEUR = IPTALPTTYATANEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
								
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR")==0 ) {
								IPTALMASRAFPTTYATANEUR = IPTALMASRAFPTTYATANEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
								}
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
									IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
								}						
								IPTALPTTYATANADETEUR = IPTALPTTYATANADETEUR.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
								IPTALPTTYATANUSD = IPTALPTTYATANUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
								
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD")==0 ) {
									IPTALMASRAFPTTYATANUSD = IPTALMASRAFPTTYATANUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
								}
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
									IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
								}						
								IPTALPTTYATANADETUSD = IPTALPTTYATANADETUSD.add(new BigDecimal(1));
							}				
						}
					}
				}
	
				// IPTAL YATAN ptt
				if ("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) && 
						("GIDEN".equals(oMap.getString(tableName2, j, "ISLEM")) ||
						"GIDEN TALIMATLI_ISME".equals(oMap.getString(tableName2, j, "ISLEM")) ||
						"GIDEN TALIMATLI_SWIFT".equals(oMap.getString(tableName2, j, "ISLEM")) ||
						"GIDEN TALIMATLI_EFT".equals(oMap.getString(tableName2, j, "ISLEM")))) {
					
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
		
						if( oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("PTT EFT") !=0 && 
								oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  ){
							//pft hesaptan olmayanlar
		
							if("GIDEN TALIMATLI_ISME".equals(oMap.getString(tableName2, j, "ISLEM")) ||
								"GIDEN TALIMATLI_SWIFT".equals(oMap.getString(tableName2, j, "ISLEM")) ||
								"GIDEN TALIMATLI_EFT".equals(oMap.getString(tableName2, j, "ISLEM"))) {
								
								if (oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI").compareTo(new BigDecimal(0)) == 1 && oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI").compareTo(new BigDecimal(0)) == 0){
									PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
									PPTYATANADETTRY   = PPTYATANADETTRY.add(new BigDecimal(1));
								}
								else if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){ 	  
									pttbankYT2 = pttbankYT2.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
									PTTYATANADETEUR = PTTYATANADETEUR.add(new BigDecimal(1));
								}
								else if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
									pttbankYT3 = pttbankYT3.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
									PTTYATANADETUSD = PTTYATANADETUSD.add(new BigDecimal(1));
								}

								if("GIDEN TALIMATLI_EFT".equals(oMap.getString(tableName2, j, "ISLEM"))) {
									MASRAFYATANPTTTRY =  MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
									IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}
							}
							if (oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI").compareTo(new BigDecimal(0)) == 1 && oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI").compareTo(new BigDecimal(0)) == 0){
								IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
								IPTALPTTYATANADETTRY   = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
							}
							else if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
								IPTALPTTYATANEUR = IPTALPTTYATANEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
								IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
								IPTALPTTYATANADETEUR = IPTALPTTYATANADETEUR.add(new BigDecimal(1));
							}
							else if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
								IPTALPTTYATANUSD = IPTALPTTYATANUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
								IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
								IPTALPTTYATANADETUSD = IPTALPTTYATANADETUSD.add(new BigDecimal(1));
							}
						}
					}
				}
				
				//IPTAL YATAN NAKIT YATIRMA
				if ("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) && "UPT_NY".equals(oMap.getString(tableName2, j, "ISLEM"))) {
                    if ("TRY".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))) {
                        PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
                        PPTYATANADETTRY = PPTYATANADETTRY.add(new BigDecimal(1));
                    }
                    else if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))) {
                        pttbankYT2 = pttbankYT2.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
                        PTTYATANADETEUR = PTTYATANADETEUR.add(new BigDecimal(1));
                    }
                    else if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))) {
                        pttbankYT3 = pttbankYT3.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
                        PTTYATANADETUSD = PTTYATANADETUSD.add(new BigDecimal(1));
                    }
                }
				
				// IPTAL YATAN ptt - PTT EFT
				if("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) && "PTT EFT".equals(oMap.getString(tableName2, j, "ISLEM"))) {
					if(!"HESAPTAN".equals(oMap.getString(tableName2, j, "EFT_HESAP_KASA"))) {
						PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						MASRAFYATANPTTTRY =  MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
						PPTYATANADETTRY   = PPTYATANADETTRY.add(new BigDecimal(1));
						IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI")) ;
						IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
						IPTALPTTYATANADETTRY   = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
					}
				}
				
				// IPTAL YATAN ptt - PTT PCH
				if("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) && "PTT PCH".equals(oMap.getString(tableName2, j, "ISLEM"))) {
					PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
					MASRAFYATANPTTTRY =  MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
					PPTYATANADETTRY   = PPTYATANADETTRY.add(new BigDecimal(1));
					IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
					IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
					IPTALPTTYATANADETTRY   = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
				}
				
				// IPTAL YATAN ptt - pttmatik ptt hesabi iptal olanlar
				if (  oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  &&  
					     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  
					     (oMap.getString(tableName2, j, "ISLEM").compareTo("Hesaba Nakit Yatirma") == 0 || 
					      oMap.getString(tableName2, j, "ISLEM").compareTo("IBAN a Nakit Yatirma") == 0 || 
					      oMap.getString(tableName2, j, "ISLEM").compareTo("EUPT Hesabina Nakit Yatirma") == 0 ||
					      oMap.getString(tableName2, j, "ISLEM").compareTo("ATM Karta Nakit Yatirma") == 0 ||
					      oMap.getString(tableName2, j, "ISLEM").compareTo("ATM N Kolay Karta Nakit Yat�rma") == 0 
					     // oMap.getString(tableName2, j, "ISLEM").compareTo("GIDEN") == 0 ||
					      )
					     ){
					IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
					//IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
					IPTALPTTYATANADETTRY = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
					
				}
				
				// IPTAL YATAN ptt - kart islemleri ptt hesabi iptal olanlar
				if (  oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  &&  
					     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  
					     (oMap.getString(tableName2, j, "ISLEM").compareTo("TFF Karta Nakit Yat�rma") == 0 || oMap.getString(tableName2, j, "ISLEM").compareTo("N Kolay Karta Nakit Yat�rma") == 0)
					     ){
					IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
					IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
					IPTALPTTYATANADETTRY = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
					PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
					MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
				}
		
				
				// IPTAL CEKILEN ptt
				if ( oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  &&  
				    oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  
				     (oMap.getString(tableName2, j, "ISLEM").compareTo("NC") == 0 ||
				      oMap.getString(tableName2, j, "ISLEM").compareTo("UPT_NC") == 0 ||
				      oMap.getString(tableName2, j, "ISLEM").compareTo("GELEN") == 0 || 
				      oMap.getString(tableName2, j, "ISLEM").compareTo("SIGORTA") ==0 )){
					
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
					
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
						IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
						
						if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
							IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
						IPTALPTTCEKILENADETTRY  = IPTALPTTCEKILENADETTRY.add(new BigDecimal(1));
					}
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
						IPTALPTTCEKILENEUR = IPTALPTTCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
						
						if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR")==0 ) {
							IPTALMASRAFPTTCEKILENEUR = IPTALMASRAFPTTCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
						if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
							IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
						IPTALPTTCEKILENADETEUR  = IPTALPTTCEKILENADETEUR.add(new BigDecimal(1));
					}
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
						IPTALPTTCEKILENUSD = IPTALPTTCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
						
						if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD")==0 ) {
							IPTALMASRAFPTTCEKILENUSD = IPTALMASRAFPTTCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
						if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
							IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
						IPTALPTTCEKILENADETUSD  = IPTALPTTCEKILENADETUSD.add(new BigDecimal(1));
					}
					IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARITL") ) ;
					
					}
				}
				
                // IPTAL CEKILEN ptt
                if ("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) && ("UPT_NC".equals(oMap.getString(tableName2, j, "ISLEM")))) {
                    if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
                        pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
                        PPTCEKILENADETTRY = PPTCEKILENADETTRY.add(new BigDecimal(1));
                    }
                    if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0) {
                        pttbankCT2 = pttbankCT2.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
                        PTTCEKILENADETEUR = PTTCEKILENADETEUR.add(new BigDecimal(1));
                    }
                    if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0) {
                        pttbankCT3 = pttbankCT3.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
                        PTTCEKILENADETUSD = PTTCEKILENADETUSD.add(new BigDecimal(1));
                    }
                }
				
				// AKTIFBANKISLEMLERI
				if (oMap.getString(tableName2, j, "ISLEM_KOD") != null) {
					

					//AKTIFBANKYATAN
					if (  oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2050)) ==0
							|| oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(3253)) ==0
							|| oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(1401)) == 0 
							|| oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(10011)) == 0
					        || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2062)) ==0
					        || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2059)) ==0
					        || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(160051)) ==0
					        || oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(3554)) ==0
					   ){
						
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
							
							if(oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0) {
								
								//hesaptan eft olmamali
								if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
									AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
									
									if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
										MASRAFYATANAKTIFBANKTRY =  MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
									}
									AKTIFBANKYATANADETTRY   = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
								}
								if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
									YATAN_AKT_EUR = YATAN_AKT_EUR.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
									
									if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR")==0 ) {
										MASRAFYATANAKTIFBANKEUR = MASRAFYATANAKTIFBANKEUR.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
									}
									if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
										MASRAFYATANAKTIFBANKTRY =  MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
									}
									AKTIFBANKYATANADETEUR = AKTIFBANKYATANADETEUR.add(new BigDecimal(1));
								}
								if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
									AKTIFBANKYT3 = AKTIFBANKYT3.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
									
									if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD")==0 ) {
										MASRAFYATANAKTIFBANKUSD = MASRAFYATANAKTIFBANKUSD.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
									}
									if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
										MASRAFYATANAKTIFBANKTRY =  MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
									}
									AKTIFBANKYATANADETUSD = AKTIFBANKYATANADETUSD.add(new BigDecimal(1));
								}
							} 
						}
					}
					
					//AKTIFBANKYATAN
					if ( oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(2850)) == 0 ||
							oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(2316)) == 0){

						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){

							if( oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  ) {
								
								//hesaptan eft olmamali
								if (oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI").compareTo(new BigDecimal(0)) == 1 && oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI").compareTo(new BigDecimal(0)) == 0){
									AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI"));
									AKTIFBANKYATANADETTRY   = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));					
								}
								
								else if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
									YATAN_AKT_EUR = YATAN_AKT_EUR.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI"));
									AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI"));
									AKTIFBANKYATANADETEUR = AKTIFBANKYATANADETEUR.add(new BigDecimal(1));
								}
								
								else if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
									AKTIFBANKYT3 = AKTIFBANKYT3.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI"));
									AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI"));
									AKTIFBANKYATANADETUSD = AKTIFBANKYATANADETUSD.add(new BigDecimal(1));
								}
								
								if("TALIMATLI_EFT".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
									MASRAFYATANAKTIFBANKTRY =  MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
								}
							} 
						}
					}
					
					//AKTIFBANKYATAN - PTT EFT
					if ( oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(2315)) == 0 && "PTT EFT".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
						if(!"HESAPTAN".equals(oMap.getString(tableName2, j, "EFT_HESAP_KASA"))) {
							AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
							MASRAFYATANAKTIFBANKTRY =  MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
							AKTIFBANKYATANADETTRY   = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
						}
					}
					
					//AKTIFBANKYATAN - PTT EFT
					if ( oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(2315)) == 0 && "PTT PCH".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
							AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
							MASRAFYATANAKTIFBANKTRY =  MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
							AKTIFBANKYATANADETTRY   = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
					}
					
					//AKTIFBANKCEKILEN
					if (oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(2051))  == 0 || 
						oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(2032))  == 0 ||  
						oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(2030))  == 0 || 
						oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(2317))  == 0 || 
						oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(3552))  == 0 ||
						oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(2063))  == 0 || 
						oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(4110)) ==0 ||
						oMap.getBigDecimal(tableName2, j,"ISLEM_KOD").compareTo(new BigDecimal(3555)) ==0 
					    ){
						
						if(oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  &&  
						   !( oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("Referansli Odeme") ==0 ||
						     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("SWIFT_GELEN") ==0 ||
						     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("TU_GELEN") ==0 ||
						     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("Iade UPT Odemesi") ==0 )) {
							
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
	
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
								AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
								
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
									MASRAFCEKILENAKTIFBANKTRY =  MASRAFCEKILENAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
								}
							
								AKTIFBANKCEKILENADETTRY   = AKTIFBANKCEKILENADETTRY.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
								AKTIFBANKCT2 = AKTIFBANKCT2.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
								
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR")==0 ) {
									MASRAFCEKILENAKTIFBANKEUR = MASRAFCEKILENAKTIFBANKEUR.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
								}
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
									MASRAFCEKILENAKTIFBANKTRY =  MASRAFCEKILENAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
								}
								
								AKTIFBANKCEKILENADETEUR = AKTIFBANKCEKILENADETEUR.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
								AKTIFBANKCT3 = AKTIFBANKCT3.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
								
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD")==0 ) {
									MASRAFCEKILENAKTIFBANKUSD = MASRAFCEKILENAKTIFBANKUSD.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
								}
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
									MASRAFCEKILENAKTIFBANKTRY =  MASRAFCEKILENAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
								}
								AKTIFBANKCEKILENADETUSD = AKTIFBANKCEKILENADETUSD.add(new BigDecimal(1));
							}	
							
							}
						}
					}
					
					if ( oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  &&  
							   ( oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("Referansli Odeme") ==0 ||
							     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("SWIFT_GELEN") ==0 ||
							     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("TU_GELEN") ==0 ||
							     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("Iade UPT Odemesi") ==0 ) ){
						
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){				
							
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
								AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
								AKTIFBANKCEKILENADETTRY   = AKTIFBANKCEKILENADETTRY.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
								AKTIFBANKCT2 = AKTIFBANKCT2.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
								AKTIFBANKCEKILENADETEUR = AKTIFBANKCEKILENADETEUR.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
								AKTIFBANKCT3 = AKTIFBANKCT3.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
								AKTIFBANKCEKILENADETUSD = AKTIFBANKCEKILENADETUSD.add(new BigDecimal(1));
							}
							
							AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARITL") ) ;
						}
					}
					
					
	
					//  aktifbank iptal YATAN
					if ( oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  && 
					   oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL")==0&& 
					  (oMap.getString(tableName2, j, "ISLEM").compareTo("NY") == 0 || 
					    oMap.getString(tableName2, j, "ISLEM").compareTo("UPT_NY") == 0)
					   ){
						
						
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
							
						
							if( oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("PTT EFT") !=0 && 
							  oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0){
									//hespatan eft olmamali
								
								
								if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){  
									IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"))  ;
									
									if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
										IPTALMASRAFAKTIFBANKYATANTRY=IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
									}
									IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));
								
								}
								if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
									
									IPTALAKTIFBANKYATANUSD = IPTALAKTIFBANKYATANUSD.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
									
									if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD")==0 ) {
										IPTALMASRAFAKTIFBANKYATANUSD=IPTALMASRAFAKTIFBANKYATANUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
									}
									if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
										IPTALMASRAFAKTIFBANKYATANTRY=IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
									}
									
									IPTALAKTIFBANKYATANADETUSD = IPTALAKTIFBANKYATANADETUSD.add(new BigDecimal(1));
								}
								if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
									IPTALAKTIFBANKYATANEUR = IPTALAKTIFBANKYATANEUR.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
									
									if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR")==0 ) {
										IPTALMASRAFAKTIFBANKYATANEUR=IPTALMASRAFAKTIFBANKYATANEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
									}
									if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
										IPTALMASRAFAKTIFBANKYATANTRY=IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
									}
									IPTALAKTIFBANKYATANADETEUR = IPTALAKTIFBANKYATANADETEUR.add(new BigDecimal(1));
								}
							}
						}
					}
					
					//  aktifbank iptal YATAN
					if ("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) && 
							("GIDEN".equals(oMap.getString(tableName2, j, "ISLEM")) ||
							"GIDEN TALIMATLI_ISME".equals(oMap.getString(tableName2, j, "ISLEM")) ||
							"GIDEN TALIMATLI_SWIFT".equals(oMap.getString(tableName2, j, "ISLEM")) ||
							"GIDEN TALIMATLI_EFT".equals(oMap.getString(tableName2, j, "ISLEM")))) {

						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){

							
							if( oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("PTT EFT") !=0 && 
									oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0){
								//hespatan eft olmamali
								if (oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI").compareTo(new BigDecimal(0)) == 1 && oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI").compareTo(new BigDecimal(0)) == 0){ 
									IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI"));
									IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));								
								}
								else if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
									IPTALAKTIFBANKYATANUSD = IPTALAKTIFBANKYATANUSD.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
									IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI"));
									IPTALAKTIFBANKYATANADETUSD = IPTALAKTIFBANKYATANADETUSD.add(new BigDecimal(1));
								}
								else if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
									IPTALAKTIFBANKYATANEUR = IPTALAKTIFBANKYATANEUR.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
									IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI"));
									IPTALAKTIFBANKYATANADETEUR = IPTALAKTIFBANKYATANADETEUR.add(new BigDecimal(1));
								}
								
								if("GIDEN TALIMATLI_EFT".equals(oMap.getString(tableName2, j, "ISLEM"))) {
									MASRAFYATANAKTIFBANKTRY =  MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
									IPTALMASRAFAKTIFBANKYATANTRY =  IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
								}
							}
						}
					}
					
					//AKTIFBANKYATAN - PTT EFT
					if ("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) && "PTT EFT".equals(oMap.getString(tableName2, j, "ISLEM"))) {
						if(!"HESAPTAN".equals(oMap.getString(tableName2, j, "EFT_HESAP_KASA"))) {
							AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
							MASRAFYATANAKTIFBANKTRY =  MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
							AKTIFBANKYATANADETTRY   = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
							IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
							IPTALMASRAFAKTIFBANKYATANTRY=IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));
						}
					}
					
					//AKTIFBANKYATAN - PTT PCH
					if ("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) && "PTT PCH".equals(oMap.getString(tableName2, j, "ISLEM"))) {
							AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
							MASRAFYATANAKTIFBANKTRY =  MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
							AKTIFBANKYATANADETTRY   = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
							IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
							IPTALMASRAFAKTIFBANKYATANTRY=IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
							IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));
					}

					
					//  aktifbank iptal CEKILEN
					if (  oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  && 
						  oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  
									(oMap.getString(tableName2, j, "ISLEM").compareTo("NC") == 0  ||
									oMap.getString(tableName2, j, "ISLEM").compareTo("UPT_NC") == 0  ||
									oMap.getString(tableName2, j, "ISLEM").compareTo("SIGORTA") ==0 )){
						
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
						

							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
								IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
								
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY")==0 ) {
									IPTALMASRAFAKTIFBANKCEKILENTRY = IPTALMASRAFAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
								}
							     IPTALBANKACEKILENADETTRY = IPTALBANKACEKILENADETTRY.add(new BigDecimal(1));
							
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
								IPTALAKTIFBANKCEKILENEUR = IPTALAKTIFBANKCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
								
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR")==0 ) {
									IPTALMASRAFAKTIFBANKCEKILENEUR = IPTALMASRAFAKTIFBANKCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
								}
								IPTALAKTIFBANKCEKILENADETEUR = IPTALAKTIFBANKCEKILENADETEUR.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
								IPTALAKTIFBANKCEKILENUSD = IPTALAKTIFBANKCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
								if ( oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD")==0 ) {
								IPTALMASRAFAKTIFBANKCEKILENUSD = IPTALMASRAFAKTIFBANKCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
								}
								IPTALBANKACEKILENADETUSD = IPTALBANKACEKILENADETUSD.add(new BigDecimal(1));
							}
							
							IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "TUTARTL") ) ;
						}
					}
					

					 // pttmatik ptt hesabi
					if( oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  &&  
							   ( oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("Hesaba Nakit Yatirma") ==0 ||
							     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IBAN a Nakit Yatirma") ==0 ||
							     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("EUPT Hesabina Nakit Yatirma") ==0 ||
							     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("ATM Karta Nakit Yatirma") ==0 ||
							     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("ATM N Kolay Karta Nakit Yat�rma") ==0)){  // bora
						
						AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
						AKTIFBANKYATANADETTRY   = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
						MASRAFYATANAKTIFBANKTRY =  MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
					}
					// pttmatik ptt hesabi iptal olanlar
					if (  oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  &&  
						     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  
						     (oMap.getString(tableName2, j, "ISLEM").compareTo("Hesaba Nakit Yatirma") == 0 || 
						      oMap.getString(tableName2, j, "ISLEM").compareTo("IBAN a Nakit Yatirma") == 0 || 
						      oMap.getString(tableName2, j, "ISLEM").compareTo("EUPT Hesabina Nakit Yatirma") == 0 ||
						      oMap.getString(tableName2, j, "ISLEM").compareTo("ATM Karta Nakit Yatirma") == 0 ||
						      oMap.getString(tableName2, j, "ISLEM").compareTo("ATM N Kolay Karta Nakit Yatirma") == 0 // bora
						     // oMap.getString(tableName2, j, "ISLEM").compareTo("GIDEN") == 0 ||
						      )
						     ){
						IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"))  ;
						//IPTALMASRAFAKTIFBANKYATANTRY=IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
						IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));
						
					}

					 // kart islemleri ptt hesabi
					if("TFF Karta Nakit Yat�rma".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) || "N Kolay Karta Nakit Yat�rma".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
						
						AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
						AKTIFBANKYATANADETTRY   = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
						MASRAFYATANAKTIFBANKTRY =  MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
					}
					
					// kart islemleri ptt hesabi iptal olanlar
					if (  oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  &&  
						     oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  
						     (oMap.getString(tableName2, j, "ISLEM").compareTo("TFF Karta Nakit Yat�rma") == 0
						      || oMap.getString(tableName2, j, "ISLEM").compareTo("N Kolay Karta Nakit Yat�rma") == 0)
						     ){
						IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"))  ;
						IPTALMASRAFAKTIFBANKYATANTRY=IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
						IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));
						
						AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
						MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
						
					}
				}
			}

		 oMap.put("PTTYT1", PTTYT1)  ;
		 oMap.put("AKTIFBANKYT1", AKTIFBANKYT1)  ;
		 oMap.put("pttbankYT2", pttbankYT2)  ;
		 oMap.put("YATAN_AKT_EUR", YATAN_AKT_EUR)  ;
		 oMap.put("pttbankYT3", pttbankYT3)  ;
		 oMap.put("AKTIFBANKYT3", AKTIFBANKYT3)  ;
		 

		 MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(MASRAFYATANPTTEUR).add(MASRAFYATANPTTUSD);
		 MASRAFYATANPTTEUR= new BigDecimal("0");
		 MASRAFYATANPTTUSD= new BigDecimal("0");
		 
		 MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(MASRAFYATANAKTIFBANKEUR).add(MASRAFYATANAKTIFBANKUSD);
		 MASRAFYATANAKTIFBANKEUR= new BigDecimal("0");
		 MASRAFYATANAKTIFBANKUSD= new BigDecimal("0");		 
		 
		 
		 oMap.put("MASRAFYATANPTTTRY", MASRAFYATANPTTTRY)  ;
		 oMap.put("MASRAFYATANAKTIFBANKTRY", MASRAFYATANAKTIFBANKTRY)  ;
		 oMap.put("MASRAFYATANPTTEUR", MASRAFYATANPTTEUR)  ;
		 oMap.put("MASRAFYATANAKTIFBANKEUR", MASRAFYATANAKTIFBANKEUR)  ;
		 oMap.put("MASRAFYATANPTTUSD", MASRAFYATANPTTUSD)  ;
		 oMap.put("MASRAFYATANAKTIFBANKUSD", MASRAFYATANAKTIFBANKUSD)  ;

		 oMap.put("PPTYATANADETTRY", PPTYATANADETTRY)  ;
		 oMap.put("AKTIFBANKYATANADETTRY", AKTIFBANKYATANADETTRY)  ;
		 oMap.put("PTTYATANADETEUR", PTTYATANADETEUR)  ;
		 oMap.put("AKTIFBANKYATANADETEUR", AKTIFBANKYATANADETEUR)  ;
		 oMap.put("PTTYATANADETUSD", PTTYATANADETUSD)  ;
		 oMap.put("AKTIFBANKYATANADETUSD", AKTIFBANKYATANADETUSD)  ;

		 oMap.put("pttbankCT1", pttbankCT1)  ;
		 oMap.put("AKTIFBANKCT1", AKTIFBANKCT1)  ;
		 oMap.put("pttbankCT2", pttbankCT2)  ;
		 oMap.put("AKTIFBANKCT2", AKTIFBANKCT2)  ;
		 oMap.put("pttbankCT3", pttbankCT3)  ;
		 oMap.put("AKTIFBANKCT3", AKTIFBANKCT3)  ;

		 MASRAFCEKILENPTTTRY = MASRAFCEKILENPTTTRY.add(MASRAFCEKILENPTTEUR).add(MASRAFCEKILENPTTUSD);
		 MASRAFCEKILENPTTEUR = new BigDecimal("0");
		 MASRAFCEKILENPTTUSD = new BigDecimal("0");
		 MASRAFCEKILENAKTIFBANKTRY = MASRAFCEKILENAKTIFBANKTRY.add(MASRAFCEKILENAKTIFBANKEUR).add(MASRAFCEKILENAKTIFBANKUSD);
		 MASRAFCEKILENAKTIFBANKEUR = new BigDecimal("0");
		 MASRAFCEKILENAKTIFBANKUSD = new BigDecimal("0");

		 oMap.put("MASRAFCEKILENPTTTRY", MASRAFCEKILENPTTTRY)  ;
		 oMap.put("MASRAFCEKILENAKTIFBANKTRY", MASRAFCEKILENAKTIFBANKTRY)  ;
		 oMap.put("MASRAFCEKILENPTTEUR", MASRAFCEKILENPTTEUR)  ;
		 oMap.put("MASRAFCEKILENAKTIFBANKEUR", MASRAFCEKILENAKTIFBANKEUR)  ;
		 oMap.put("MASRAFCEKILENPTTUSD", MASRAFCEKILENPTTUSD)  ;
		 oMap.put("MASRAFCEKILENAKTIFBANKUSD", MASRAFCEKILENAKTIFBANKUSD)  ;
		 
		 oMap.put("PPTCEKILENADETTRY", PPTCEKILENADETTRY)  ;
		 oMap.put("AKTIFBANKCEKILENADETTRY", AKTIFBANKCEKILENADETTRY)  ;
		 oMap.put("PTTCEKILENADETEUR", PTTCEKILENADETEUR)  ;
		 oMap.put("AKTIFBANKCEKILENADETEUR", AKTIFBANKCEKILENADETEUR)  ;
		 oMap.put("PTTCEKILENADETUSD", PTTCEKILENADETUSD)  ;
		 oMap.put("AKTIFBANKCEKILENADETUSD", AKTIFBANKCEKILENADETUSD)  ;
		 
		 oMap.put("IPTALPTTYATANTRY", IPTALPTTYATANTRY)  ;
		 oMap.put("IPTALAKTIFBANKYATANTRY", IPTALAKTIFBANKYATANTRY)  ;
		 oMap.put("IPTALPTTYATANUSD", IPTALPTTYATANUSD)  ;
		 oMap.put("IPTALAKTIFBANKYATANUSD", IPTALAKTIFBANKYATANUSD)  ;
		 oMap.put("IPTALPTTYATANEUR", IPTALPTTYATANEUR)  ;
		 oMap.put("IPTALAKTIFBANKYATANEUR", IPTALAKTIFBANKYATANEUR)  ;

		 oMap.put("IPTALPTTCEKILENTRY", IPTALPTTCEKILENTRY)  ;
		 oMap.put("IPTALAKTIFBANKCEKILENTRY", IPTALAKTIFBANKCEKILENTRY)  ;
		 oMap.put("IPTALPTTCEKILENEUR", IPTALPTTCEKILENEUR)  ;
		 oMap.put("IPTALAKTIFBANKCEKILENEUR", IPTALAKTIFBANKCEKILENEUR)  ;
		 oMap.put("IPTALPTTCEKILENUSD", IPTALPTTCEKILENUSD)  ;
		 oMap.put("IPTALAKTIFBANKCEKILENUSD", IPTALAKTIFBANKCEKILENUSD)  ;
		 
		BigDecimal PTT_BORC_TL =  new BigDecimal(0);
		
		BigDecimal PTT_BORC_EUR =  new BigDecimal(0);
		
		BigDecimal PTT_BORC_USD =  new BigDecimal(0);
		
		BigDecimal AKTIFBANK_BORC_TL =  new BigDecimal(0);
		
		BigDecimal AKTIFBANK_BORC_EUR =  new BigDecimal(0);
		
		BigDecimal AKTIFBANK_BORC_USD =  new BigDecimal(0);
		
	
		oMap.put("pttbankYT2", pttbankYT2);

	    BigDecimal TOPLAMYATANPTTTRY =   PTTYT1.add(MASRAFYATANPTTTRY);
	    BigDecimal TOPLAMYATANAKTIFBANKTRY = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY);
	    BigDecimal TOPLAMYATANPTTEUR = pttbankYT2.add(MASRAFYATANPTTEUR);
	    BigDecimal TOPLAMYATANAKTIFBANKEUR =  YATAN_AKT_EUR.add(MASRAFYATANAKTIFBANKEUR);
	    BigDecimal TOPLAMYATANPTTUSD = pttbankYT3.add(MASRAFYATANPTTUSD);
	    BigDecimal TOPLAMYATANAKTIFBANKUSD =  AKTIFBANKYT3.add(MASRAFYATANAKTIFBANKUSD);
	    
	    oMap.put("TOPLAMYATANPTTTRY", TOPLAMYATANPTTTRY)  ;
	    oMap.put("TOPLAMYATANAKTIFBANKTRY", TOPLAMYATANAKTIFBANKTRY)  ;
	    oMap.put("TOPLAMYATANPTTEUR", TOPLAMYATANPTTEUR)  ;
	    oMap.put("TOPLAMYATANAKTIFBANKEUR", TOPLAMYATANAKTIFBANKEUR)  ;
	    oMap.put("TOPLAMYATANPTTUSD", TOPLAMYATANPTTUSD)  ;
	    oMap.put("TOPLAMYATANAKTIFBANKUSD", TOPLAMYATANAKTIFBANKUSD)  ;

	    BigDecimal TOPLAMCEKILENPTTTRY =   pttbankCT1.subtract(MASRAFCEKILENPTTTRY) ; 
	    BigDecimal TOPLAMCEKILENAKTIFBANKTRY =  AKTIFBANKCT1.subtract(MASRAFCEKILENAKTIFBANKTRY)  ;   
	    BigDecimal TOPLAMCEKILENPTTEUR =  pttbankCT2.subtract(MASRAFCEKILENPTTEUR) ; 
	    BigDecimal TOPLAMCEKILENAKTIFBANKEUR =  AKTIFBANKCT2.subtract(MASRAFCEKILENAKTIFBANKEUR)   ; 
	    BigDecimal TOPLAMCEKILENPTTUSD = 		pttbankCT3.subtract(MASRAFCEKILENPTTUSD);
	    BigDecimal TOPLAMCEKILENAKTIFBANKUSD =  AKTIFBANKCT3.subtract(MASRAFCEKILENAKTIFBANKUSD)  ;   
	    
	    oMap.put("TOPLAMCEKILENPTTTRY", TOPLAMCEKILENPTTTRY)  ;
	    oMap.put("TOPLAMCEKILENAKTIFBANKTRY", TOPLAMCEKILENAKTIFBANKTRY)  ;
	    oMap.put("TOPLAMCEKILENPTTEUR", TOPLAMCEKILENPTTEUR)  ;
	    oMap.put("TOPLAMCEKILENAKTIFBANKEUR", TOPLAMCEKILENAKTIFBANKEUR)  ;
	    oMap.put("TOPLAMCEKILENPTTUSD", TOPLAMCEKILENPTTUSD)  ;
	    oMap.put("TOPLAMCEKILENAKTIFBANKUSD", TOPLAMCEKILENAKTIFBANKUSD)  ;

	    IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(IPTALMASRAFPTTYATANUSD).add(IPTALMASRAFPTTYATANEUR);
	    IPTALMASRAFPTTYATANUSD = new BigDecimal(0);
	    IPTALMASRAFPTTYATANEUR = new BigDecimal(0);
	    IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(IPTALMASRAFAKTIFBANKYATANUSD).add(IPTALMASRAFAKTIFBANKYATANEUR);
	    IPTALMASRAFAKTIFBANKYATANUSD = new BigDecimal(0);
	    IPTALMASRAFAKTIFBANKYATANEUR = new BigDecimal(0);

	    oMap.put("IPTALMASRAFPTTYATANTRY", IPTALMASRAFPTTYATANTRY)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKYATANTRY", IPTALMASRAFAKTIFBANKYATANTRY)  ;
	    oMap.put("IPTALMASRAFPTTYATANUSD", IPTALMASRAFPTTYATANUSD)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKYATANUSD", IPTALMASRAFAKTIFBANKYATANUSD)  ;
	    oMap.put("IPTALMASRAFPTTYATANEUR", IPTALMASRAFPTTYATANEUR)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKYATANEUR", IPTALMASRAFAKTIFBANKYATANEUR)  ;

	    IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(IPTALMASRAFPTTCEKILENEUR).add(IPTALMASRAFPTTCEKILENUSD);
	    IPTALMASRAFPTTCEKILENEUR = new BigDecimal(0);
	    IPTALMASRAFPTTCEKILENUSD = new BigDecimal(0); 
	    IPTALMASRAFAKTIFBANKCEKILENTRY = IPTALMASRAFAKTIFBANKCEKILENTRY.add(IPTALMASRAFAKTIFBANKCEKILENEUR).add(IPTALMASRAFAKTIFBANKCEKILENUSD);
	    IPTALMASRAFAKTIFBANKCEKILENEUR = new BigDecimal(0);
	    IPTALMASRAFAKTIFBANKCEKILENUSD = new BigDecimal(0); 	   

	    oMap.put("IPTALMASRAFPTTCEKILENTRY", IPTALMASRAFPTTCEKILENTRY)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKCEKILENTRY", IPTALMASRAFAKTIFBANKCEKILENTRY)  ;
	    oMap.put("IPTALMASRAFPTTCEKILENEUR", IPTALMASRAFPTTCEKILENEUR)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKCEKILENEUR", IPTALMASRAFAKTIFBANKCEKILENEUR)  ;
	    oMap.put("IPTALMASRAFPTTCEKILENUSD", IPTALMASRAFPTTCEKILENUSD)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKCEKILENUSD", IPTALMASRAFAKTIFBANKCEKILENUSD)  ;

	    oMap.put("IPTALPTTYATANADETTRY", IPTALPTTYATANADETTRY)  ;
	    oMap.put("IPTALBANKAYATANADETTRY", IPTALBANKAYATANADETTRY)  ;
	    oMap.put("IPTALPTTYATANADETEUR", IPTALPTTYATANADETEUR)  ;
	    oMap.put("IPTALAKTIFBANKYATANADETEUR", IPTALAKTIFBANKYATANADETEUR)  ;
	    oMap.put("IPTALPTTYATANADETUSD", IPTALPTTYATANADETUSD)  ;
	    oMap.put("IPTALAKTIFBANKYATANADETUSD", IPTALAKTIFBANKYATANADETUSD)  ;

	    oMap.put("IPTALPTTCEKILENADETTRY", IPTALPTTCEKILENADETTRY)  ;
	    oMap.put("IPTALBANKACEKILENADETTRY", IPTALBANKACEKILENADETTRY)  ;
	    oMap.put("IPTALPTTCEKILENADETEUR", IPTALPTTCEKILENADETEUR)  ;
	    oMap.put("IPTALAKTIFBANKCEKILENADETEUR", IPTALAKTIFBANKCEKILENADETEUR)  ;
	    oMap.put("IPTALPTTCEKILENADETUSD", IPTALPTTCEKILENADETUSD)  ;
	    oMap.put("IPTALBANKACEKILENADETUSD", IPTALBANKACEKILENADETUSD)  ;

		PTT_BORC_TL = PTTYT1.add(MASRAFYATANPTTTRY).subtract(IPTALPTTYATANTRY).subtract(IPTALMASRAFPTTYATANTRY)
		.add(MASRAFCEKILENPTTTRY).subtract(pttbankCT1).add(IPTALPTTCEKILENTRY).subtract(IPTALMASRAFPTTCEKILENTRY)
		.add(MASRAFYATANPTTEUR).add(MASRAFCEKILENPTTEUR).subtract(IPTALMASRAFPTTYATANEUR).subtract(IPTALMASRAFPTTCEKILENEUR)
		.add(MASRAFYATANPTTUSD).subtract(IPTALMASRAFPTTYATANUSD).add(MASRAFCEKILENPTTUSD).subtract(IPTALMASRAFPTTCEKILENUSD);
		
		PTT_BORC_EUR = pttbankYT2.subtract(IPTALPTTYATANEUR)
		.subtract(pttbankCT2).add(IPTALPTTCEKILENEUR)  ;	
		
		PTT_BORC_USD = pttbankYT3.subtract(IPTALPTTYATANUSD)
		.subtract(pttbankCT3).add(IPTALPTTCEKILENUSD)  ;	
	
		oMap.put("BORC_TL_PTT", PTT_BORC_TL);
		oMap.put("BORC_USD_PTT", PTT_BORC_USD);
		oMap.put("BORC_EUR_PTT", PTT_BORC_EUR);
		
		oMap.put("BORC_TL_BANKA", "0");
		oMap.put("BORC_EUR_BANKA", "0");
		oMap.put("BORC_USD_BANKA", "0");

		if  (PTT_BORC_TL.intValue() < 0) {
			AKTIFBANK_BORC_TL = PTT_BORC_TL;
			oMap.put("BORC_TL_BANKA", AKTIFBANK_BORC_TL);
			oMap.put("BORC_TL_PTT", "0");
		}
		
		if  (PTT_BORC_EUR.intValue() < 0) {
			AKTIFBANK_BORC_EUR = PTT_BORC_EUR;
			oMap.put("BORC_EUR_BANKA", AKTIFBANK_BORC_EUR);
			oMap.put("BORC_EUR_PTT", "0");
		}
		if  (PTT_BORC_USD.intValue() < 0) {
			AKTIFBANK_BORC_USD = PTT_BORC_USD;
			oMap.put("BORC_USD_BANKA", AKTIFBANK_BORC_USD);
			oMap.put("BORC_USD_PTT", "0");
		}
		
		AKTIFBANK_BORC_TL = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY).subtract(IPTALAKTIFBANKYATANTRY).subtract(IPTALMASRAFAKTIFBANKYATANTRY)
		.add(MASRAFCEKILENAKTIFBANKTRY).subtract(AKTIFBANKCT1).add(IPTALAKTIFBANKCEKILENTRY).subtract(IPTALMASRAFAKTIFBANKCEKILENTRY)
		.add(MASRAFCEKILENAKTIFBANKEUR).subtract(IPTALMASRAFAKTIFBANKCEKILENEUR).add(MASRAFYATANAKTIFBANKEUR).subtract(IPTALMASRAFAKTIFBANKYATANEUR)
		.add(MASRAFYATANAKTIFBANKUSD).subtract(IPTALMASRAFAKTIFBANKYATANUSD).add(MASRAFCEKILENAKTIFBANKUSD).subtract(IPTALMASRAFAKTIFBANKCEKILENUSD);
		
		AKTIFBANK_BORC_EUR = YATAN_AKT_EUR.subtract(IPTALAKTIFBANKYATANEUR)
		.subtract(AKTIFBANKCT2).add(IPTALAKTIFBANKCEKILENEUR)  ;	
		
		AKTIFBANK_BORC_USD = AKTIFBANKYT3.subtract(IPTALAKTIFBANKYATANUSD)
		.subtract(AKTIFBANKCT3).add(IPTALAKTIFBANKCEKILENUSD)  ;	

		
		GMMap sMap = new GMMap();
		
		sMap.put("TARIH", iMap.get("TARIH"));
		
		sMap.put("AKTIFBANK_BORC_TL", AKTIFBANK_BORC_TL);
		sMap.put("AKTIFBANK_BORC_EUR", AKTIFBANK_BORC_EUR);
		sMap.put("AKTIFBANK_BORC_USD", AKTIFBANK_BORC_USD);
		
		sMap.put("PTT_BORC_TL", PTT_BORC_TL);
		sMap.put("PTT_BORC_USD", PTT_BORC_USD);
		sMap.put("PTT_BORC_EUR", PTT_BORC_EUR);
		
		GMServiceExecuter.execute("BNSPR_QRY2052_SET_NET_OFF", sMap);
		
		// BU KONTROL BLOGU KALDIRILIRSA MUTABAKATLILARDA LISTELENECEK
		if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("true")==0){
			
			oMapOnlyMutabakatsiz.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR", iMap));
			oMapOnlyMutabakatsizAkt.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_AKT", iMap));
			i =  oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT"); 
			for (j = 0; j < oMapOnlyMutabakatsizAkt.getSize("CBS_AKTIFBANK_PTT"); j++) {
				
				oMapOnlyMutabakatsiz.put("CBS_AKTIFBANK_PTT", i, "ISLEM_TURU_PTT", oMapOnlyMutabakatsizAkt.getString("CBS_AKTIFBANK_PTT", j, "ISLEM_TURU_PTT"));
				oMapOnlyMutabakatsiz.put("CBS_AKTIFBANK_PTT", i, "ISLEM_KOD", oMapOnlyMutabakatsizAkt.getString("CBS_AKTIFBANK_PTT", j, "ISLEM_KOD"));
				oMapOnlyMutabakatsiz.put("CBS_AKTIFBANK_PTT", i, "TOPLAM_TUTAR", oMapOnlyMutabakatsizAkt.getString("CBS_AKTIFBANK_PTT", j, "TOPLAM_TUTAR"));
				oMapOnlyMutabakatsiz.put("CBS_AKTIFBANK_PTT", i, "TUTAR", oMapOnlyMutabakatsizAkt.getString("CBS_AKTIFBANK_PTT", j, "TUTAR"));			
				oMapOnlyMutabakatsiz.put("CBS_AKTIFBANK_PTT", i, "ISLEM_ADI_PTT", oMapOnlyMutabakatsizAkt.getString("CBS_AKTIFBANK_PTT", j, "ISLEM_ADI_PTT"));				
				oMapOnlyMutabakatsiz.put("CBS_AKTIFBANK_PTT", i, "ISLEM", oMapOnlyMutabakatsizAkt.getString("CBS_AKTIFBANK_PTT", j, "ISLEM"));
				oMapOnlyMutabakatsiz.put("CBS_AKTIFBANK_PTT", i, "AKTIFBANK_DOVIZ_KODU", oMapOnlyMutabakatsizAkt.getString("CBS_AKTIFBANK_PTT", j, "AKTIFBANK_DOVIZ_KODU"));
				oMapOnlyMutabakatsiz.put("CBS_AKTIFBANK_PTT", i, "NUMARA", oMapOnlyMutabakatsizAkt.getString("CBS_AKTIFBANK_PTT", j, "NUMARA"));
				oMapOnlyMutabakatsiz.put("CBS_AKTIFBANK_PTT", i, "MASRAF", oMapOnlyMutabakatsizAkt.getString("CBS_AKTIFBANK_PTT", j, "MASRAF"));
				oMapOnlyMutabakatsiz.put("CBS_AKTIFBANK_PTT", i, "TUTARTL", oMapOnlyMutabakatsizAkt.getString("CBS_AKTIFBANK_PTT", j, "TUTARTL"));

				i++;
			}
			
			oMap.put("KAYIT_SAYISI", oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT"));
			
			if (oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT")>0){
				oMap.putAll(oMapOnlyMutabakatsiz);
			}else{
				oMap.remove("CBS_AKTIFBANK_PTT") ;
			}
		}
		
		// Yetki: "Mutabakat Fis Kes" buton yetki kontrolu
		oMap.put("TRN2052_YETKI", DALUtil.callNoParameterFunction("{? = call pkg_trn2052.islem_yetki_kontrol}", Types.VARCHAR));
		
		return oMap;
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF")
	public static GMMap getSecondLevelAktif(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC_PTT.RC_QRY_GET_2nd_LEVEL_AKT(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_MUTABAKATSIZLAR")
	public static GMMap getMutabakatsizIslemler(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC_PTT.Agreement_Response(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			
			//if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("1")==0){
			//	oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
			//}else{
				oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT_MUTABAKATSIZ");
			//}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_AKT")
	public static GMMap getMutabakatsizIslemlerAkt(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC_PTT.Agreement_Response_Akt(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT_MUTABAKATSIZ");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR")
	public static GMMap getMutabakatOnlyMutabatsiz(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC_PTT.Agreement_Response(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			
				oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
				

			//}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_AKT")
	public static GMMap getMutabakatOnlyMutabatsizAkt(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC_PTT.Agreement_Response_Akt(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			
				oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
				

			//}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_SET_NET_OFF")
	public static GMMap SetNetOff(GMMap iMap){

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksMutabakatNetOff clksMutabakatNetOff = (ClksMutabakatNetOff)session.get(ClksMutabakatNetOff.class, iMap.getDate("TARIH"));
			
			if(clksMutabakatNetOff == null) {
				clksMutabakatNetOff = new ClksMutabakatNetOff();
			}
			
			clksMutabakatNetOff.setBankaTarihi(iMap.getDate("TARIH"));
			
			
			/*
			if  (iMap.getBigDecimal("PTT_BORC_TL").intValue() > 0){
				clksMutabakatNetOff.setPttTryNetOff( iMap.getBigDecimal("PTT_BORC_TL"));
			}else{	
				clksMutabakatNetOff.setBankaTryNetOff(iMap.getBigDecimal("PTT_BORC_TL").abs());	
			}
			if  (iMap.getBigDecimal("PTT_BORC_USD").intValue() > 0){
				clksMutabakatNetOff.setPttTryNetOff( iMap.getBigDecimal("PTT_BORC_USD"));
			}else{	
				clksMutabakatNetOff.setBankaTryNetOff(iMap.getBigDecimal("PTT_BORC_USD").abs());	
			}
			if  (iMap.getBigDecimal("PTT_BORC_EUR").intValue() > 0){
				clksMutabakatNetOff.setPttTryNetOff( iMap.getBigDecimal("PTT_BORC_EUR"));
			}else{	
				clksMutabakatNetOff.setBankaTryNetOff(iMap.getBigDecimal("PTT_BORC_EUR").abs());	
			}
			*/
			
			clksMutabakatNetOff.setPttTryNetOff( iMap.getBigDecimal("PTT_BORC_TL"));
			clksMutabakatNetOff.setBankaTryNetOff(iMap.getBigDecimal("AKTIFBANK_BORC_TL"));
			clksMutabakatNetOff.setPttUsdNetOff(iMap.getBigDecimal("PTT_BORC_USD"));
			clksMutabakatNetOff.setBankaUsdNetOff(iMap.getBigDecimal("AKTIFBANK_BORC_USD"));
			clksMutabakatNetOff.setPttEurNetOff(iMap.getBigDecimal("PTT_BORC_EUR"));
			clksMutabakatNetOff.setBankaEurNetOff(iMap.getBigDecimal("AKTIFBANK_BORC_EUR"));
			
			
		
			session.saveOrUpdate(clksMutabakatNetOff);  //G�D�YOR YUKARIDAKILERI TX TABLOSUNA KAYIT EDIYOR
			session.flush();   //BURADA YUKARIDAKI KOMUTU �CRA ED�YOR.
			
			return iMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2053_GET_NET_OFF")
	public static GMMap GetNetOff(GMMap iMap){
		GMMap oMap = new GMMap();
		

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			if (iMap.get("TARIHBAS") == null || iMap.get("TARIHSON") == null) {
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "��lem Tarih Aral���");
				return  (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			Calendar cal1 = GregorianCalendar.getInstance();
			cal1.setTime(iMap.getDate("TARIHBAS"));
			
			Calendar cal2 = GregorianCalendar.getInstance();
			cal2.setTime(iMap.getDate("TARIHSON"));
			int i=0;
			String cut_off_table ="CUT_OFF_TABLE";
			
			if (cal1.compareTo(cal2) == 1) {
				iMap.put("HATA_NO", new BigDecimal(1601));
				iMap.put("P1", "Baslangic Tarihi");
				iMap.put("P2", "Biti� Tarihi");
				return  (GMMap)GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}	
			
			cal2.add(Calendar.DAY_OF_MONTH, 1);
			
		while(cal1.compareTo(cal2) != 0) {
			
			ClksMutabakatNetOff clksMutabakatNetOff = (ClksMutabakatNetOff)session.createCriteria(ClksMutabakatNetOff.class)
			.add(Restrictions.eq("bankaTarihi",  cal1.getTime() ))
			.uniqueResult(); 
			
			
			if(clksMutabakatNetOff != null) {
				
			oMap.put(cut_off_table,i, "TARIH", clksMutabakatNetOff.getBankaTarihi()) ;
			
			
			if (clksMutabakatNetOff.getPttTryNetOff().intValue() < 0){
				oMap.put(cut_off_table,i, "BANKATRY", clksMutabakatNetOff.getPttTryNetOff().abs()) ;
			}else{
				oMap.put(cut_off_table,i, "PTTTRY", clksMutabakatNetOff.getPttTryNetOff()) ;
			}
			
			if (clksMutabakatNetOff.getPttUsdNetOff().intValue() < 0){
				oMap.put(cut_off_table,i, "BANKAUSD", clksMutabakatNetOff.getBankaUsdNetOff().abs()) ;
			}else{
				oMap.put(cut_off_table,i, "PTTUSD", clksMutabakatNetOff.getPttUsdNetOff()) ;
			}
			
			if (clksMutabakatNetOff.getPttEurNetOff().intValue() < 0){
				oMap.put(cut_off_table,i, "BANKAEUR", clksMutabakatNetOff.getBankaEurNetOff().abs()) ;
			}else{
				oMap.put(cut_off_table,i, "PTTEUR", clksMutabakatNetOff.getPttEurNetOff()) ;
			}
			
			
			
			/*
			oMap.put(cut_off_table,i, "PTTTRY", clksMutabakatNetOff.getPttTryNetOff()) ;
			oMap.put(cut_off_table,i, "BANKATRY", clksMutabakatNetOff.getBankaTryNetOff()) ;
			oMap.put(cut_off_table,i, "PTTUSD", clksMutabakatNetOff.getPttUsdNetOff()) ;
			oMap.put(cut_off_table,i, "BANKAUSD", clksMutabakatNetOff.getBankaUsdNetOff()) ;
			oMap.put(cut_off_table,i, "PTTEUR", clksMutabakatNetOff.getPttEurNetOff()) ;
			oMap.put(cut_off_table,i, "BANKAEUR", clksMutabakatNetOff.getBankaEurNetOff()) ;
			*/
			
			}else{
				
				oMap.put(cut_off_table,i, "TARIH", cal1.getTime()) ;
				oMap.put(cut_off_table,i, "PTTTRY", 0) ;
				oMap.put(cut_off_table,i, "BANKATRY", 0) ;
				oMap.put(cut_off_table,i, "PTTUSD", 0) ;
				oMap.put(cut_off_table,i, "BANKAUSD", 0) ;
				oMap.put(cut_off_table,i, "PTTEUR", 0) ;
				oMap.put(cut_off_table,i, "BANKAEUR", 0) ;
					
			}
			i++;
			cal1.add(Calendar.DAY_OF_MONTH, 1);
			
			}
			

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_MUTABAKATSIZ_ISLEMLER")
	public static GMMap MutabakatsizList(GMMap iMap){
		GMMap oMap = new GMMap();
		
		
		BigDecimal PTT_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_TRY=new BigDecimal(0);
		
		BigDecimal PTT_ISLEM_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_EUR=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_EUR=new BigDecimal(0);
		
		
		BigDecimal PTT_ISLEM_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_USD=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_USD=new BigDecimal(0);
		
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		

		try{
			int j=0;
			
			if(StringUtils.isBlank(iMap.getString("ISLEM_TIPI"))){
				CurrentAccountsCommonServices.throwGMBusssinessException("Islem Tipi secmelisiniz.");

			}
			
			for (int i=0;i<iMap.getSize("ISLEM_LIST");i++){
				
				if((iMap.getString("ISLEM_TIPI").equals("NKOLAYKARTATM") && iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT").equals("ATM N Kolay Karta Nakit Yat�rma")) 
					|| iMap.getString("ISLEM_TIPI").compareTo(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"))==0 ) {
					
					oMap.put("SONUC_LIST", j, "ANAISLEMDURUM", iMap.getString("ISLEM_LIST", i, "ANAISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "EFT_HESAP_KASA", iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA"));
					oMap.put("SONUC_LIST", j, "IPTALISLEMDURUM", iMap.getString("ISLEM_LIST", i, "IPTALISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "ISLEM_KOD", iMap.getString("ISLEM_LIST", i, "ISLEM_KOD"));
					oMap.put("SONUC_LIST", j, "ISLEM_NO_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_NO_PTT"));
					oMap.put("SONUC_LIST", j, "ISLEM_TURU_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF", iMap.getString("ISLEM_LIST", i, "MASRAF"));
					oMap.put("SONUC_LIST", j, "NUMARA", iMap.getString("ISLEM_LIST", i, "NUMARA"));
					oMap.put("SONUC_LIST", j, "PTT_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "PTT_ISLEM_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_ISLEM_TUTARITL", iMap.getString("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));
					oMap.put("SONUC_LIST", j, "PTT_MASRAF_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "PTT_TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "PTTISLEMNO", iMap.getString("ISLEM_LIST", i, "PTTISLEMNO"));
					oMap.put("SONUC_LIST", j, "REFERANS", iMap.getString("ISLEM_LIST", i, "REFERANS"));
					oMap.put("SONUC_LIST", j, "TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "TUTAR", iMap.getString("ISLEM_LIST", i, "TUTAR"));
					oMap.put("SONUC_LIST", j, "TUTARTL", iMap.getString("ISLEM_LIST", i, "TUTARTL"));
					
					
					oMap.put("SONUC_LIST", j, "ISLEM_ADI_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_ADI_PTT"));
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("TRY")==0){
						
						if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
						
						PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
						PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));	
						PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						PTT_ISLEM_ADET_TRY = PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
						
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							
							BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));
							BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTARTL"));	
							BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
							BANKA_ISLEM_ADET_TRY = BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
							
						}	
						}
						
					}		
					
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("USD")==0){
						
						if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
						
						PTT_ISLEM_TOPLAM_USD = PTT_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
						PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						PTT_ISLEM_ADET_USD = PTT_ISLEM_ADET_USD.add(new BigDecimal("1"));
						
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							
							BANKA_ISLEM_TOPLAM_USD = BANKA_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));	
							BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
							BANKA_ISLEM_ADET_USD = BANKA_ISLEM_ADET_USD.add(new BigDecimal("1"));	
						}	
						
						}
					}		
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("EUR")==0){
						
						if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
						
						PTT_ISLEM_TOPLAM_EUR = PTT_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
						PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						PTT_ISLEM_ADET_EUR = PTT_ISLEM_ADET_EUR.add(new BigDecimal("1"));
						
						
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							BANKA_ISLEM_TOPLAM_EUR = BANKA_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));	
							BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
							BANKA_ISLEM_ADET_EUR = BANKA_ISLEM_ADET_EUR.add(new BigDecimal("1"));
						}	
						
						}
					}	
					
					
					if(iMap.getString("ISLEM_TIPI").compareTo("IPTAL")==0){
						
						conn = DALUtil.getGMConnection();
						stmt = conn.prepareCall("{ ? = call pkg_tx.Islem_kod(?) }");
						
						stmt.registerOutParameter(1, Types.NUMERIC);
						stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_LIST", i, "NUMARA"));
						
						stmt.execute();
						
						iMap.put("ISLEM_KODU", stmt.getBigDecimal(1));
						
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("TRY")==0   ){
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2050")==0 || iMap.getString("ISLEM_KODU").compareTo("2315")==0
									|| iMap.getString("ISLEM_KODU").compareTo("2062")==0 || iMap.getString("ISLEM_KODU").compareTo("3253")==0
							        || iMap.getString("ISLEM_KODU").compareTo("3554")==0 || iMap.getString("ISLEM_KODU").compareTo("3555")==0){
							
								
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
								
								PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
								PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));	
							 	PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							 	PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								
							 	if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
								
								 	BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 	BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));
								 	BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 	BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								}	
							
							}
							
							}
							
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2317")==0 || iMap.getString("ISLEM_KODU").compareTo("2051")==0 
								|| iMap.getString("ISLEM_KODU").compareTo("2032")==0 || iMap.getString("ISLEM_KODU").compareTo("2030")==0 
								|| iMap.getString("ISLEM_KODU").compareTo("2063")==0 || iMap.getString("ISLEM_KODU").compareTo("3554")==0
								|| iMap.getString("ISLEM_KODU").compareTo("3555")==0){

								 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
								 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));	
								 PTT_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								
								if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									
									 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
									 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));	
									 BANKA_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								}		
							}
							//pttmatik
							if (iMap.getString("ISLEM_KODU").compareTo("2048")==0  || iMap.getString("ISLEM_KODU").compareTo("2049")==0 
							   ||iMap.getString("ISLEM_KODU").compareTo("2061")==0 || iMap.getString("ISLEM_KODU").compareTo("3554")==0 
							   || iMap.getString("ISLEM_KODU").compareTo("3555")==0) 
							{
								PTT_MASRAF_TOPLAM_TRY= PTT_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									BANKA_MASRAF_TOPLAM_TRY= BANKA_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
								}
							}
							
						
						}		
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("USD")==0){
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2050")==0 || iMap.getString("ISLEM_KODU").compareTo("2315")==0
									|| iMap.getString("ISLEM_KODU").compareTo("2062")==0 || iMap.getString("ISLEM_KODU").compareTo("3253")==0
									|| iMap.getString("ISLEM_KODU").compareTo("3554")==0 || iMap.getString("ISLEM_KODU").compareTo("3555")==0 )   {
								
								
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
								
								 PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));
								 PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									
								if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									
									 BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
									 BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));	
									 BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								}	
								
								}
								
								}
								
								
								if ( iMap.getString("ISLEM_KODU").compareTo("2317")==0 || iMap.getString("ISLEM_KODU").compareTo("2051")==0 
									|| iMap.getString("ISLEM_KODU").compareTo("2032")==0 || iMap.getString("ISLEM_KODU").compareTo("2030")==0 
									|| iMap.getString("ISLEM_KODU").compareTo("2063")==0 || iMap.getString("ISLEM_KODU").compareTo("3554")==0
									|| iMap.getString("ISLEM_KODU").compareTo("3555")==0){
									
									
									 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
									 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));	
									 PTT_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									
									if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
										
										 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
										 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));	
										 BANKA_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									}		
								}

						}		
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("EUR")==0){
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2050")==0 || iMap.getString("ISLEM_KODU").compareTo("2315")==0 
							        || iMap.getString("ISLEM_KODU").compareTo("2062")==0  || iMap.getString("ISLEM_KODU").compareTo("3253")==0
									|| iMap.getString("ISLEM_KODU").compareTo("3554")==0  || iMap.getString("ISLEM_KODU").compareTo("3555")==0){
								
								
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
									
								 PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
								 PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));	
								 PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									
								if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									
									 BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
									 BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));	
									 BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								}	
								
								}
								
								}
								
								if ( iMap.getString("ISLEM_KODU").compareTo("2317")==0 || iMap.getString("ISLEM_KODU").compareTo("2051")==0 
									|| iMap.getString("ISLEM_KODU").compareTo("2032")==0 || iMap.getString("ISLEM_KODU").compareTo("2030")==0 
									|| iMap.getString("ISLEM_KODU").compareTo("2063")==0
									|| iMap.getString("ISLEM_KODU").compareTo("3554")==0
									|| iMap.getString("ISLEM_KODU").compareTo("3555")==0){
									
									 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
									 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));	
									 PTT_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									
									if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
										
										 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
										 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));
										 BANKA_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
										
									}	
								}
						}
							
					}
					
					j++;	
				}
				
			}	

			if (iMap.getString("ISLEM_TIPI").compareTo("Nakit Yatirma") ==0 
			        || iMap.getString("ISLEM_TIPI").compareTo("UPT Nakit Yatirma") ==0 
					|| iMap.getString("ISLEM_TIPI").compareTo("Kredi Tahsilati") ==0
					|| iMap.getString("ISLEM_TIPI").compareTo("PTT EFT")== 0
			){
			
			PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
			BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
			PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
			BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
			PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
			BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			
			}
			

			if(iMap.getString("ISLEM_TIPI").compareTo("Hesaba Nakit Yatirma")== 0
					|| iMap.getString("ISLEM_TIPI").compareTo("IBAN a Nakit Yatirma")== 0
					|| iMap.getString("ISLEM_TIPI").compareTo("ATM N Kolay Karta Nakit Yat�rma")== 0
					|| iMap.getString("ISLEM_TIPI").compareTo("EUPT Hesabina Nakit Yatirma")== 0
					|| iMap.getString("ISLEM_TIPI").compareTo("ATM Karta Nakit Yatirma")== 0){

				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_ISLEM_TOPLAM_TRY);
				PTT_MASRAF_TOPLAM_TRY = new BigDecimal(0);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_ISLEM_TOPLAM_TRY);
				BANKA_MASRAF_TOPLAM_TRY = new BigDecimal(0);
				
			}
			
			if(iMap.getString("ISLEM_TIPI").compareTo("TFF Karta Nakit Yat�rma") == 0 || iMap.getString("ISLEM_TIPI").compareTo("N Kolay Karta Nakit Yat�rma") == 0){

			    PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
	            BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
	            
	            PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
	            BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
	            
	            PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
	            BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
                
            }
			if (iMap.getString("ISLEM_TIPI").compareTo("PTT UPT") ==0  
					|| iMap.getString("ISLEM_TIPI").compareTo("Nakit Cekme") ==0
					|| iMap.getString("ISLEM_TIPI").compareTo("UPT Nakit Cekme") ==0
					|| iMap.getString("ISLEM_TIPI").compareTo("Referansli Odeme")== 0
					|| iMap.getString("ISLEM_TIPI").compareTo("Kredi Kullandirim")== 0
					){
			
			PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.subtract(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
			BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.subtract(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
			PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.subtract(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
			BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.subtract(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
			PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.subtract(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
			BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.subtract(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}
			
			
			if (iMap.getString("ISLEM_TIPI").compareTo("IPTAL") ==0  ){
				
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
				
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
				
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
				
			}
			
			
							
		
		/*
		if (iMap.getString("ISLEM_TIPI").compareTo("IPTAL")== 0){
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call pkg_tx.Islem_kod(?) }");
			
			
			stmt.setString(2, iMap.getString("TCKN"));
		
		}
		*/
				
			
			oMap.put("PTT_ISLEM_TOPLAM_TRY", PTT_ISLEM_TOPLAM_TRY);
			oMap.put("PTT_MASRAF_TOPLAM_TRY", PTT_MASRAF_TOPLAM_TRY);
			oMap.put("PTT_GENEL_TOPLAM_TRY", PTT_GENEL_TOPLAM_TRY);
			oMap.put("PTT_ISLEM_ADET_TRY", PTT_ISLEM_ADET_TRY);
			
			oMap.put("BANKA_ISLEM_TOPLAM_TRY", BANKA_ISLEM_TOPLAM_TRY);
			oMap.put("BANKA_MASRAF_TOPLAM_TRY", BANKA_MASRAF_TOPLAM_TRY);
			oMap.put("BANKA_GENEL_TOPLAM_TRY", BANKA_GENEL_TOPLAM_TRY);
			oMap.put("BANKA_ISLEM_ADET_TRY", BANKA_ISLEM_ADET_TRY);	
			
			oMap.put("PTT_ISLEM_TOPLAM_EUR", PTT_ISLEM_TOPLAM_EUR);
			oMap.put("PTT_MASRAF_TOPLAM_EUR", PTT_MASRAF_TOPLAM_EUR);
			oMap.put("PTT_GENEL_TOPLAM_EUR", PTT_GENEL_TOPLAM_EUR);
			oMap.put("PTT_ISLEM_ADET_EUR", PTT_ISLEM_ADET_EUR);
			
			oMap.put("BANKA_ISLEM_TOPLAM_EUR", BANKA_ISLEM_TOPLAM_EUR);
			oMap.put("BANKA_MASRAF_TOPLAM_EUR", BANKA_MASRAF_TOPLAM_EUR);
			oMap.put("BANKA_GENEL_TOPLAM_EUR", BANKA_GENEL_TOPLAM_EUR);
			oMap.put("BANKA_ISLEM_ADET_EUR", BANKA_ISLEM_ADET_EUR);	
			
			oMap.put("PTT_ISLEM_TOPLAM_USD", PTT_ISLEM_TOPLAM_USD);
			oMap.put("PTT_MASRAF_TOPLAM_USD", PTT_MASRAF_TOPLAM_USD);
			oMap.put("PTT_GENEL_TOPLAM_USD", PTT_GENEL_TOPLAM_USD);
			oMap.put("PTT_ISLEM_ADET_USD", PTT_ISLEM_ADET_USD);
			
			oMap.put("BANKA_ISLEM_TOPLAM_USD", BANKA_ISLEM_TOPLAM_USD);
			oMap.put("BANKA_MASRAF_TOPLAM_USD", BANKA_MASRAF_TOPLAM_USD);
			oMap.put("BANKA_GENEL_TOPLAM_USD", BANKA_GENEL_TOPLAM_USD);
			oMap.put("BANKA_ISLEM_ADET_USD", BANKA_ISLEM_ADET_USD);	
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_SWIFT_DATA")
	public static GMMap getSwiftData(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		BigDecimal PTTYT1 =  new BigDecimal(0);
		BigDecimal AKTIFBANKYT1 =new BigDecimal(0);
		BigDecimal pttbankYT2 =new BigDecimal(0);
		BigDecimal YATAN_AKT_EUR =new BigDecimal(0);
		BigDecimal pttbankYT3  = new BigDecimal(0);
	    BigDecimal AKTIFBANKYT3 = new BigDecimal(0);
	       
	    BigDecimal MASRAFYATANPTTTRY =  new BigDecimal(0);
	    BigDecimal MASRAFYATANAKTIFBANKTRY =  new BigDecimal(0);
	    BigDecimal MASRAFYATANPTTEUR =  new BigDecimal(0);
	    BigDecimal MASRAFYATANAKTIFBANKEUR =  new BigDecimal(0);
	    BigDecimal MASRAFYATANPTTUSD =  new BigDecimal(0);
	    BigDecimal MASRAFYATANAKTIFBANKUSD =  new BigDecimal(0);
	    
	    BigDecimal PPTYATANADETTRY =  new BigDecimal(0);
	    BigDecimal AKTIFBANKYATANADETTRY =  new BigDecimal(0);
	    BigDecimal PTTYATANADETEUR =  new BigDecimal(0);
	    BigDecimal AKTIFBANKYATANADETEUR =  new BigDecimal(0);
	    BigDecimal PTTYATANADETUSD =  new BigDecimal(0);
	    BigDecimal AKTIFBANKYATANADETUSD =  new BigDecimal(0);
	    
	    BigDecimal pttbankCT1 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT1 =  new BigDecimal(0);
	    BigDecimal pttbankCT2 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT2 =  new BigDecimal(0);
	    BigDecimal pttbankCT3 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT3 =  new BigDecimal(0);
	    
	    BigDecimal MASRAFCEKILENPTTTRY =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENAKTIFBANKTRY =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENPTTEUR =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENAKTIFBANKEUR =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENPTTUSD =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENAKTIFBANKUSD =  new BigDecimal(0);
	    
	    BigDecimal PPTCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal PTTCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal PTTCEKILENADETUSD =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCEKILENADETUSD =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANEUR =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENUSD =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENUSD =  new BigDecimal(0);
	    
	    BigDecimal IPTALMASRAFPTTYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFPTTYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFPTTYATANEUR =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKYATANEUR =  new BigDecimal(0);
	    
	    BigDecimal IPTALMASRAFPTTCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFPTTCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFPTTCEKILENUSD =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKCEKILENUSD =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTYATANADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALBANKAYATANADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANADETUSD =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANADETUSD =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALBANKACEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENADETUSD =  new BigDecimal(0);
	    BigDecimal IPTALBANKACEKILENADETUSD =  new BigDecimal(0);
	        
	    GMMap   oMapOnlyMutabakatsiz = new GMMap();

		try{
			int i = 1;
			/*
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call Pkg_Rc_Ptt_FC.RC_QRY_GET_1ST_LEVEL(?) }");
			stmt.registerOutParameter(i++, -10);

			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			rSet= (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetMap(rSet);
			*/
			
			oMap.put("CBS_AKTIFBANK_PTT", GMServiceExecuter.execute("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_SW", iMap).get("CBS_AKTIFBANK"));
			
			
			String tableName = "CBS_AKTIFBANK_PTT";
			i =  oMap.getSize(tableName); 
			int j=0;
			
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_SW", iMap));

			String tableName2 = "CBS_AKTIFBANK_PTT";
			tableName = "CBS_AKTIFBANK_PTT_MUTABAKATSIZ";
			for ( j = 0; j < iMap.getSize(tableName); j++) {
				
				oMap.put(tableName2, i, "ISLEM_TURU_PTT", iMap.getString(tableName, j,"ISLEM_TURU_PTT"));
				oMap.put(tableName2, i, "PTT_ISLEM_TUTARI", iMap.getString(tableName, j,"PTT_ISLEM_TUTARI"));
				oMap.put(tableName2, i, "PTT_MASRAF_TUTARI", iMap.getString(tableName, j,"PTT_MASRAF_TUTARI"));
				oMap.put(tableName2, i, "ISLEM_NO_PTT", iMap.getString(tableName, j,"ISLEM_NO_PTT"));
				oMap.put(tableName2, i, "NUMARA", iMap.getString(tableName, j,"NUMARA"));  // ISLEMNOBANKA
				oMap.put(tableName2, i, "PTT_DOVIZ_KODU", iMap.getString(tableName, j,"PTT_DOVIZ_KODU"));
				oMap.put(tableName2, i, "EFT_HESAP_KASA", iMap.getString(tableName, j,"EFT_HESAP_KASA"));
				oMap.put(tableName2, i, "ISLEM", iMap.getString(tableName, j,"ISLEM"));
				oMap.put(tableName2, i, "PTT_TOPLAM_TUTAR",iMap.getString(tableName, j,"PTT_TOPLAM_TUTAR"));
				oMap.put(tableName2, i, "ISLEM_ADI_PTT",iMap.getString(tableName, j,"ISLEM_ADI_PTT"));
				oMap.put(tableName2, i, "MASRAF_DOVIZ_KODU",iMap.getString(tableName, j,"MASRAF_DOVIZ_KODU"));
				oMap.put(tableName2, i, "PTT_TL_TUTARI", iMap.getString(tableName, j,"PTT_MASRAF_TUTARI"));
				oMap.put(tableName2, i, "PTT_DOVIZ_TUTARI", iMap.getString(tableName, j,"PTT_MASRAF_TUTARI"));

				i++;
			}
			
			tableName2 = "CBS_AKTIFBANK_PTT";
		for  ( j = 0; j < oMap.getSize(tableName2); j++) {  // Aktifbank i�lem T�P� null sa
															// demekki banka islemi
			// YATAN  ptt
			if ( oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  && 
			   oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("SWIFT_GIDEN") ==0 ){
			
			if ( oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {
							
			if(   oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0)  {
				
				if (oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI").compareTo(new BigDecimal(0)) == 1 && oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI").compareTo(new BigDecimal(0)) == 0){ 	  
					PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
					PPTYATANADETTRY = PPTYATANADETTRY.add(new BigDecimal(1));
				}
				else if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){ 	  
					pttbankYT2 = pttbankYT2.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
					PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
					PTTYATANADETEUR = PTTYATANADETEUR.add(new BigDecimal(1));
				}
				else if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
					pttbankYT3 = pttbankYT3.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
					PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
					PTTYATANADETUSD = PTTYATANADETUSD.add(new BigDecimal(1));
				}
			   }
			  }
			} 
				// CEKILEN ptt
				if ( oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  && 
				   oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("SWIFT_GELEN") ==0 ){
					
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
						
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
							pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
							PPTCEKILENADETTRY   = PPTCEKILENADETTRY.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
							pttbankCT2 = pttbankCT2.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
							pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
							PTTCEKILENADETEUR = PTTCEKILENADETEUR.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
							pttbankCT3 = pttbankCT3.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
							pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
							PTTCEKILENADETUSD = PTTCEKILENADETUSD.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0  ){
							MASRAFCEKILENPTTTRY =  MASRAFCEKILENPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0  ){
							MASRAFCEKILENPTTEUR = MASRAFCEKILENPTTEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0  ){
							MASRAFCEKILENPTTUSD = MASRAFCEKILENPTTUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}						
					}
				}
				// IPTAL YATAN ptt
				if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null && 
					oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 && 
					 oMap.getString(tableName2, j, "ISLEM").compareTo("GIDEN") == 0){
					
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
								
						if( oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("PTT EFT") !=0 && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  ){
							//pft hesaptan olmayanlar

							
							if (oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI").compareTo(new BigDecimal(0)) == 1 && oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI").compareTo(new BigDecimal(0)) == 0){ 	  
								IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
								IPTALPTTYATANADETTRY = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
							}
							else if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
								IPTALPTTYATANEUR = IPTALPTTYATANEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
								IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
								IPTALPTTYATANADETEUR = IPTALPTTYATANADETEUR.add(new BigDecimal(1));
							}
							else if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
								IPTALPTTYATANUSD = IPTALPTTYATANUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
								IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
								IPTALPTTYATANADETUSD = IPTALPTTYATANADETUSD.add(new BigDecimal(1));
							}							
					    }
					}
				}
				// IPTAL CEKILEN ptt
				if ( oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  &&  oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  oMap.getString(tableName2, j, "ISLEM").compareTo("GELEN") == 0 ){
					
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
					
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
							IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
							IPTALPTTCEKILENADETTRY  = IPTALPTTCEKILENADETTRY.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
							IPTALPTTCEKILENEUR = IPTALPTTCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
							IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
							IPTALPTTCEKILENADETEUR  = IPTALPTTCEKILENADETEUR.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
							IPTALPTTCEKILENUSD = IPTALPTTCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
							IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
							IPTALPTTCEKILENADETUSD  = IPTALPTTCEKILENADETUSD.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0  ){
							IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0  ){
							IPTALMASRAFPTTCEKILENEUR = IPTALMASRAFPTTCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0  ){
							IPTALMASRAFPTTCEKILENUSD = IPTALMASRAFPTTCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
					}
				}
				// AKTIFBANKISLEMLERI
				if (oMap.getString(tableName2, j, "ISLEM_KOD") != null ){
					//AKTIFBANKYATAN
					if ( oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2850)) ==0  ){
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
							
							if( oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  ){
								//hesaptan eft olmamali

								if ("TRY".equals(oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU"))){
									AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
									AKTIFBANKYATANADETTRY = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
								}
								else if ("EUR".equals(oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU"))){
									YATAN_AKT_EUR = YATAN_AKT_EUR.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
									AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
									AKTIFBANKYATANADETEUR = AKTIFBANKYATANADETEUR.add(new BigDecimal(1));
								}
								else if ("USD".equals(oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU"))){
									AKTIFBANKYT3 = AKTIFBANKYT3.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
									AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
									AKTIFBANKYATANADETUSD = AKTIFBANKYATANADETUSD.add(new BigDecimal(1));
								}								
							}    
						}
					}

					//AKTIFBANKCEKILEN
					if (oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2032)) == 0 ||
						oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(3552)) == 0	
					    )  {
						
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){

							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
								AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
								AKTIFBANKCEKILENADETTRY   = AKTIFBANKCEKILENADETTRY.add(new BigDecimal(1));
							}
							else if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
								AKTIFBANKCT2 = AKTIFBANKCT2.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
								AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
								AKTIFBANKCEKILENADETEUR = AKTIFBANKCEKILENADETEUR.add(new BigDecimal(1));
							}
							else if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
								AKTIFBANKCT3 = AKTIFBANKCT3.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
								AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
								AKTIFBANKCEKILENADETUSD = AKTIFBANKCEKILENADETUSD.add(new BigDecimal(1));
							}
						
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0  ){
								MASRAFCEKILENAKTIFBANKTRY =  MASRAFCEKILENAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
							}	
						
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0  ){
								MASRAFCEKILENAKTIFBANKEUR = MASRAFCEKILENAKTIFBANKEUR.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
							}
						
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0  ){
								MASRAFCEKILENAKTIFBANKUSD = MASRAFCEKILENAKTIFBANKUSD.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
							}						
						}	
					}	
	
					//  aktifbank iptal YATAN
					if (  oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  && oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  oMap.getString(tableName2, j, "ISLEM").compareTo("GIDEN") == 0 ){
						
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
							
							if( oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("SWIFT_GIDEN") !=0 && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  ){
							//hesaptan eft olmamali

								//hesaptan eft olmamali

								if ("TRY".equals(oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU"))){
									IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
									IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));
								}
								else if ("USD".equals(oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU"))){
									IPTALAKTIFBANKYATANUSD = IPTALAKTIFBANKYATANUSD.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
									IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
									IPTALAKTIFBANKYATANADETUSD = IPTALAKTIFBANKYATANADETUSD.add(new BigDecimal(1));
								}
								else if ("EUR".equals(oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU"))){
									IPTALAKTIFBANKYATANEUR = IPTALAKTIFBANKYATANEUR.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
									IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
									IPTALAKTIFBANKYATANADETEUR = IPTALAKTIFBANKYATANADETEUR.add(new BigDecimal(1));
								}									
						     }	
						}
					}
					
					//  aktifbank iptal CEKILEN
					if (  oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  && 
						oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  
						  oMap.getString(tableName2, j, "ISLEM").compareTo("GELEN") == 0 ){
						
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
						
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
								IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
								IPTALBANKACEKILENADETTRY = IPTALBANKACEKILENADETTRY.add(new BigDecimal(1));
							}
							else if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
								IPTALAKTIFBANKCEKILENEUR = IPTALAKTIFBANKCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
								IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
								IPTALAKTIFBANKCEKILENADETEUR = IPTALAKTIFBANKCEKILENADETEUR.add(new BigDecimal(1));
							}
							else if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
								IPTALAKTIFBANKCEKILENUSD = IPTALAKTIFBANKCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
								IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
								IPTALBANKACEKILENADETUSD = IPTALBANKACEKILENADETUSD.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0  ){
								IPTALMASRAFAKTIFBANKCEKILENTRY = IPTALMASRAFAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0  ){
								IPTALMASRAFAKTIFBANKCEKILENEUR = IPTALMASRAFAKTIFBANKCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0  ){
								IPTALMASRAFAKTIFBANKCEKILENUSD = IPTALMASRAFAKTIFBANKCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}								
						}
					}
				}
		}

		 oMap.put("PTTYT1", PTTYT1)  ;
		 oMap.put("AKTIFBANKYT1", AKTIFBANKYT1)  ;
		 oMap.put("pttbankYT2", pttbankYT2)  ;
		 oMap.put("YATAN_AKT_EUR", YATAN_AKT_EUR)  ;
		 oMap.put("pttbankYT3", pttbankYT3)  ;
		 oMap.put("AKTIFBANKYT3", AKTIFBANKYT3)  ;
		 
		 /*
		 MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(MASRAFYATANPTTEUR).add(MASRAFYATANPTTUSD);
		 MASRAFYATANPTTEUR= new BigDecimal("0");
		 MASRAFYATANPTTUSD= new BigDecimal("0");
		 
		 MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(MASRAFYATANAKTIFBANKEUR).add(MASRAFYATANAKTIFBANKUSD);
		 MASRAFYATANAKTIFBANKEUR= new BigDecimal("0");
		 MASRAFYATANAKTIFBANKUSD= new BigDecimal("0");		 
		 */
		 oMap.put("MASRAFYATANPTTTRY", MASRAFYATANPTTTRY)  ;
		 oMap.put("MASRAFYATANAKTIFBANKTRY", MASRAFYATANAKTIFBANKTRY)  ;
		 oMap.put("MASRAFYATANPTTEUR", MASRAFYATANPTTEUR)  ;
		 oMap.put("MASRAFYATANAKTIFBANKEUR", MASRAFYATANAKTIFBANKEUR)  ;
		 oMap.put("MASRAFYATANPTTUSD", MASRAFYATANPTTUSD)  ;
		 oMap.put("MASRAFYATANAKTIFBANKUSD", MASRAFYATANAKTIFBANKUSD)  ;
		 
		 oMap.put("PPTYATANADETTRY", PPTYATANADETTRY)  ;
		 oMap.put("AKTIFBANKYATANADETTRY", AKTIFBANKYATANADETTRY)  ;
		 oMap.put("PTTYATANADETEUR", PTTYATANADETEUR)  ;
		 oMap.put("AKTIFBANKYATANADETEUR", AKTIFBANKYATANADETEUR)  ;
		 oMap.put("PTTYATANADETUSD", PTTYATANADETUSD)  ;
		 oMap.put("AKTIFBANKYATANADETUSD", AKTIFBANKYATANADETUSD)  ;
		 
		 oMap.put("pttbankCT1", pttbankCT1)  ;
		 oMap.put("AKTIFBANKCT1", AKTIFBANKCT1)  ;
		 oMap.put("pttbankCT2", pttbankCT2)  ;
		 oMap.put("AKTIFBANKCT2", AKTIFBANKCT2)  ;
		 oMap.put("pttbankCT3", pttbankCT3)  ;
		 oMap.put("AKTIFBANKCT3", AKTIFBANKCT3)  ;
		 
		 /*
		 MASRAFCEKILENPTTTRY = MASRAFCEKILENPTTTRY.add(MASRAFCEKILENPTTEUR).add(MASRAFCEKILENPTTUSD);
		 
		 MASRAFCEKILENPTTEUR = new BigDecimal("0");
		 MASRAFCEKILENPTTUSD = new BigDecimal("0");
		 
		 MASRAFCEKILENAKTIFBANKTRY = MASRAFCEKILENAKTIFBANKTRY.add(MASRAFCEKILENAKTIFBANKEUR).add(MASRAFCEKILENAKTIFBANKUSD);
		 MASRAFCEKILENAKTIFBANKEUR = new BigDecimal("0");
		 MASRAFCEKILENAKTIFBANKUSD = new BigDecimal("0");
		 */
 
		 oMap.put("MASRAFCEKILENPTTTRY", MASRAFCEKILENPTTTRY)  ;
		 oMap.put("MASRAFCEKILENAKTIFBANKTRY", MASRAFCEKILENAKTIFBANKTRY)  ;
		 oMap.put("MASRAFCEKILENPTTEUR", MASRAFCEKILENPTTEUR)  ;
		 oMap.put("MASRAFCEKILENAKTIFBANKEUR", MASRAFCEKILENAKTIFBANKEUR)  ;
		 oMap.put("MASRAFCEKILENPTTUSD", MASRAFCEKILENPTTUSD)  ;
		 oMap.put("MASRAFCEKILENAKTIFBANKUSD", MASRAFCEKILENAKTIFBANKUSD)  ;
		 
		 oMap.put("PPTCEKILENADETTRY", PPTCEKILENADETTRY)  ;
		 oMap.put("AKTIFBANKCEKILENADETTRY", AKTIFBANKCEKILENADETTRY)  ;
		 oMap.put("PTTCEKILENADETEUR", PTTCEKILENADETEUR)  ;
		 oMap.put("AKTIFBANKCEKILENADETEUR", AKTIFBANKCEKILENADETEUR)  ;
		 oMap.put("PTTCEKILENADETUSD", PTTCEKILENADETUSD)  ;
		 oMap.put("AKTIFBANKCEKILENADETUSD", AKTIFBANKCEKILENADETUSD)  ;
		 
		 oMap.put("IPTALPTTYATANTRY", IPTALPTTYATANTRY)  ;
		 oMap.put("IPTALAKTIFBANKYATANTRY", IPTALAKTIFBANKYATANTRY)  ;
		 oMap.put("IPTALPTTYATANUSD", IPTALPTTYATANUSD)  ;
		 oMap.put("IPTALAKTIFBANKYATANUSD", IPTALAKTIFBANKYATANUSD)  ;
		 oMap.put("IPTALPTTYATANEUR", IPTALPTTYATANEUR)  ;
		 oMap.put("IPTALAKTIFBANKYATANEUR", IPTALAKTIFBANKYATANEUR)  ;
		 
		 oMap.put("IPTALPTTCEKILENTRY", IPTALPTTCEKILENTRY)  ;
		 oMap.put("IPTALAKTIFBANKCEKILENTRY", IPTALAKTIFBANKCEKILENTRY)  ;
		 oMap.put("IPTALPTTCEKILENEUR", IPTALPTTCEKILENEUR)  ;
		 oMap.put("IPTALAKTIFBANKCEKILENEUR", IPTALAKTIFBANKCEKILENEUR)  ;
		 oMap.put("IPTALPTTCEKILENUSD", IPTALPTTCEKILENUSD)  ;
		 oMap.put("IPTALAKTIFBANKCEKILENUSD", IPTALAKTIFBANKCEKILENUSD)  ;
		 
		BigDecimal PTT_BORC_TL =  new BigDecimal(0);
		BigDecimal PTT_BORC_EUR =  new BigDecimal(0);
		BigDecimal PTT_BORC_USD =  new BigDecimal(0);
		BigDecimal AKTIFBANK_BORC_TL =  new BigDecimal(0);
		BigDecimal AKTIFBANK_BORC_EUR =  new BigDecimal(0);
		BigDecimal AKTIFBANK_BORC_USD =  new BigDecimal(0);

		oMap.put("pttbankYT2", pttbankYT2);
		
		
	    BigDecimal TOPLAMYATANPTTTRY =   PTTYT1.add(MASRAFYATANPTTTRY);
	    BigDecimal TOPLAMYATANAKTIFBANKTRY = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY);
	    BigDecimal TOPLAMYATANPTTEUR = pttbankYT2.add(MASRAFYATANPTTEUR);
	    BigDecimal TOPLAMYATANAKTIFBANKEUR =  YATAN_AKT_EUR.add(MASRAFYATANAKTIFBANKEUR);
	    BigDecimal TOPLAMYATANPTTUSD = pttbankYT3.add(MASRAFYATANPTTUSD);
	    BigDecimal TOPLAMYATANAKTIFBANKUSD =  AKTIFBANKYT3.add(MASRAFYATANAKTIFBANKUSD);
	    
	    oMap.put("TOPLAMYATANPTTTRY", TOPLAMYATANPTTTRY)  ;
	    oMap.put("TOPLAMYATANAKTIFBANKTRY", TOPLAMYATANAKTIFBANKTRY)  ;
	    oMap.put("TOPLAMYATANPTTEUR", TOPLAMYATANPTTEUR)  ;
	    oMap.put("TOPLAMYATANAKTIFBANKEUR", TOPLAMYATANAKTIFBANKEUR)  ;
	    oMap.put("TOPLAMYATANPTTUSD", TOPLAMYATANPTTUSD)  ;
	    oMap.put("TOPLAMYATANAKTIFBANKUSD", TOPLAMYATANAKTIFBANKUSD)  ;
    
	    BigDecimal TOPLAMCEKILENPTTTRY =   pttbankCT1.subtract(MASRAFCEKILENPTTTRY) ; 
	    BigDecimal TOPLAMCEKILENAKTIFBANKTRY =  AKTIFBANKCT1.subtract(MASRAFCEKILENAKTIFBANKTRY)  ;   
	    BigDecimal TOPLAMCEKILENPTTEUR =  pttbankCT2.subtract(MASRAFCEKILENPTTEUR) ; 
	    BigDecimal TOPLAMCEKILENAKTIFBANKEUR =  AKTIFBANKCT2.subtract(MASRAFCEKILENAKTIFBANKEUR)   ; 
	    BigDecimal TOPLAMCEKILENPTTUSD = 		pttbankCT3.subtract(MASRAFCEKILENPTTUSD);
	    BigDecimal TOPLAMCEKILENAKTIFBANKUSD =  AKTIFBANKCT3.subtract(MASRAFCEKILENAKTIFBANKUSD)  ;   
	    
	    oMap.put("TOPLAMCEKILENPTTTRY", TOPLAMCEKILENPTTTRY)  ;
	    oMap.put("TOPLAMCEKILENAKTIFBANKTRY", TOPLAMCEKILENAKTIFBANKTRY)  ;
	    oMap.put("TOPLAMCEKILENPTTEUR", TOPLAMCEKILENPTTEUR)  ;
	    oMap.put("TOPLAMCEKILENAKTIFBANKEUR", TOPLAMCEKILENAKTIFBANKEUR)  ;
	    oMap.put("TOPLAMCEKILENPTTUSD", TOPLAMCEKILENPTTUSD)  ;
	    oMap.put("TOPLAMCEKILENAKTIFBANKUSD", TOPLAMCEKILENAKTIFBANKUSD)  ;
	    
	    IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(IPTALMASRAFPTTYATANUSD).add(IPTALMASRAFPTTYATANEUR);
	    IPTALMASRAFPTTYATANUSD = new BigDecimal(0);
	    IPTALMASRAFPTTYATANEUR = new BigDecimal(0);
	    
	    IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(IPTALMASRAFAKTIFBANKYATANUSD).add(IPTALMASRAFAKTIFBANKYATANEUR);
	    IPTALMASRAFAKTIFBANKYATANUSD = new BigDecimal(0);
	    IPTALMASRAFAKTIFBANKYATANEUR = new BigDecimal(0);
	    
	    oMap.put("IPTALMASRAFPTTYATANTRY", IPTALMASRAFPTTYATANTRY)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKYATANTRY", IPTALMASRAFAKTIFBANKYATANTRY)  ;
	    oMap.put("IPTALMASRAFPTTYATANUSD", IPTALMASRAFPTTYATANUSD)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKYATANUSD", IPTALMASRAFAKTIFBANKYATANUSD)  ;
	    oMap.put("IPTALMASRAFPTTYATANEUR", IPTALMASRAFPTTYATANEUR)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKYATANEUR", IPTALMASRAFAKTIFBANKYATANEUR)  ;
	    
	    IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(IPTALMASRAFPTTCEKILENEUR).add(IPTALMASRAFPTTCEKILENUSD);
	    IPTALMASRAFPTTCEKILENEUR = new BigDecimal(0);
	    IPTALMASRAFPTTCEKILENUSD = new BigDecimal(0); 
	    
	    IPTALMASRAFAKTIFBANKCEKILENTRY = IPTALMASRAFAKTIFBANKCEKILENTRY.add(IPTALMASRAFAKTIFBANKCEKILENEUR).add(IPTALMASRAFAKTIFBANKCEKILENUSD);
	    IPTALMASRAFAKTIFBANKCEKILENEUR = new BigDecimal(0);
	    IPTALMASRAFAKTIFBANKCEKILENUSD = new BigDecimal(0); 	    
	    
	    oMap.put("IPTALMASRAFPTTCEKILENTRY", IPTALMASRAFPTTCEKILENTRY)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKCEKILENTRY", IPTALMASRAFAKTIFBANKCEKILENTRY)  ;
	    oMap.put("IPTALMASRAFPTTCEKILENEUR", IPTALMASRAFPTTCEKILENEUR)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKCEKILENEUR", IPTALMASRAFAKTIFBANKCEKILENEUR)  ;
	    oMap.put("IPTALMASRAFPTTCEKILENUSD", IPTALMASRAFPTTCEKILENUSD)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKCEKILENUSD", IPTALMASRAFAKTIFBANKCEKILENUSD)  ;
	    
	    oMap.put("IPTALPTTYATANADETTRY", IPTALPTTYATANADETTRY)  ;
	    oMap.put("IPTALBANKAYATANADETTRY", IPTALBANKAYATANADETTRY)  ;
	    oMap.put("IPTALPTTYATANADETEUR", IPTALPTTYATANADETEUR)  ;
	    oMap.put("IPTALAKTIFBANKYATANADETEUR", IPTALAKTIFBANKYATANADETEUR)  ;
	    oMap.put("IPTALPTTYATANADETUSD", IPTALPTTYATANADETUSD)  ;
	    oMap.put("IPTALAKTIFBANKYATANADETUSD", IPTALAKTIFBANKYATANADETUSD)  ;
	        
	    oMap.put("IPTALPTTCEKILENADETTRY", IPTALPTTCEKILENADETTRY)  ;
	    oMap.put("IPTALBANKACEKILENADETTRY", IPTALBANKACEKILENADETTRY)  ;
	    oMap.put("IPTALPTTCEKILENADETEUR", IPTALPTTCEKILENADETEUR)  ;
	    oMap.put("IPTALAKTIFBANKCEKILENADETEUR", IPTALAKTIFBANKCEKILENADETEUR)  ;
	    oMap.put("IPTALPTTCEKILENADETUSD", IPTALPTTCEKILENADETUSD)  ;
	    oMap.put("IPTALBANKACEKILENADETUSD", IPTALBANKACEKILENADETUSD)  ;
	    
     
		PTT_BORC_TL = PTTYT1.add(MASRAFYATANPTTTRY).subtract(IPTALPTTYATANTRY).subtract(IPTALMASRAFPTTYATANTRY)
		.add(MASRAFCEKILENPTTTRY).subtract(pttbankCT1).add(IPTALPTTCEKILENTRY).subtract(IPTALMASRAFPTTCEKILENTRY)
		;
		
		PTT_BORC_EUR = pttbankYT2.subtract(IPTALPTTYATANEUR).subtract(pttbankCT2).add(IPTALPTTCEKILENEUR)  ;	
		
		PTT_BORC_USD = pttbankYT3.subtract(IPTALPTTYATANUSD).subtract(pttbankCT3).add(IPTALPTTCEKILENUSD)  ;	

		/*Nakit yatan nakit cekilen ptt -aktifbank tan iptal tutarlari dusuldu  */
		//oMap.put("PTTYT1", PTTYT1.intValue()-(IPTALPTTYATANTRY.intValue()))  ;
		//oMap.put("pttbankYT2", pttbankYT2.intValue()-(IPTALPTTYATANEUR.intValue()))  ;
		//oMap.put("pttbankYT3", pttbankYT3.intValue()-(IPTALPTTYATANUSD.intValue()))  ;
		//oMap.put("AKTIFBANKYT1", AKTIFBANKYT1.intValue() - IPTALAKTIFBANKCEKILENTRY.intValue() )  ;
		//oMap.put("YATAN_AKT_EUR", YATAN_AKT_EUR.intValue() - IPTALAKTIFBANKCEKILENEUR.intValue() )  ;
		//oMap.put("IPTALAKTIFBANKCEKILENUSD", IPTALAKTIFBANKCEKILENUSD.intValue() - IPTALAKTIFBANKCEKILENUSD.intValue() )  ;
		 /******************/
	
		oMap.put("BORC_TL_PTT", PTT_BORC_TL);
		oMap.put("BORC_USD_PTT", PTT_BORC_USD);
		oMap.put("BORC_EUR_PTT", PTT_BORC_EUR);
		
		oMap.put("BORC_TL_BANKA", "0");
		oMap.put("BORC_EUR_BANKA", "0");
		oMap.put("BORC_USD_BANKA", "0");
		
		
		if  (PTT_BORC_TL.intValue() < 0) {
			AKTIFBANK_BORC_TL = PTT_BORC_TL;
			oMap.put("BORC_TL_BANKA", AKTIFBANK_BORC_TL);
			oMap.put("BORC_TL_PTT", "0");
		}
		
		if  (PTT_BORC_EUR.intValue() < 0) {
			AKTIFBANK_BORC_EUR = PTT_BORC_EUR;
			oMap.put("BORC_EUR_BANKA", AKTIFBANK_BORC_EUR);
			oMap.put("BORC_EUR_PTT", "0");
		}
		if  (PTT_BORC_USD.intValue() < 0) {
			AKTIFBANK_BORC_USD = PTT_BORC_USD;
			oMap.put("BORC_USD_BANKA", AKTIFBANK_BORC_USD);
			oMap.put("BORC_USD_PTT", "0");
		}
		
		AKTIFBANK_BORC_TL = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY).subtract(IPTALAKTIFBANKYATANTRY).subtract(IPTALMASRAFAKTIFBANKYATANTRY)
		.add(MASRAFCEKILENAKTIFBANKTRY).subtract(AKTIFBANKCT1).add(IPTALAKTIFBANKCEKILENTRY).subtract(IPTALMASRAFAKTIFBANKCEKILENTRY)
		;
		
		AKTIFBANK_BORC_EUR = YATAN_AKT_EUR.subtract(IPTALAKTIFBANKYATANEUR).subtract(AKTIFBANKCT2).add(IPTALAKTIFBANKCEKILENEUR)  ;	
		
		AKTIFBANK_BORC_USD = AKTIFBANKYT3.subtract(IPTALAKTIFBANKYATANUSD).subtract(AKTIFBANKCT3).add(IPTALAKTIFBANKCEKILENUSD)  ;	

		
		GMMap sMap = new GMMap();
		
		sMap.put("TARIH", iMap.get("TARIH"));
		sMap.put("AKTIFBANK_BORC_TL", AKTIFBANK_BORC_TL);
		sMap.put("AKTIFBANK_BORC_EUR", AKTIFBANK_BORC_EUR);
		sMap.put("AKTIFBANK_BORC_USD", AKTIFBANK_BORC_USD);
		sMap.put("PTT_BORC_TL", PTT_BORC_TL);
		sMap.put("PTT_BORC_USD", PTT_BORC_USD);
		sMap.put("PTT_BORC_EUR", PTT_BORC_EUR);
		
		//GMServiceExecuter.execute("BNSPR_QRY2052_SET_NET_OFF", sMap);	  
		oMap.put("KAYIT_SAYISI","1");
		
		// BU KONTROL BLOGU KALDIRILIRSA MUTABAKATLILARDA LISTELENECEK
		if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("true")==0){
			oMapOnlyMutabakatsiz.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_SW", iMap));
			
			oMap.put("KAYIT_SAYISI", oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT"));
			
			if (oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT")>0){
				oMap.putAll(oMapOnlyMutabakatsiz);
			}else{
				oMap.remove("CBS_AKTIFBANK_PTT");
			}	
			//oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR", iMap));
		}
		
		return oMap;
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_ISLEMLER_SWIFT")
	public static GMMap Get_Islemler_SWIFT(GMMap iMap){
		GMMap oMap = new GMMap();
	
		BigDecimal PTT_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_TRY=new BigDecimal(0);
		
		BigDecimal PTT_ISLEM_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_EUR=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_EUR=new BigDecimal(0);
		
		BigDecimal PTT_ISLEM_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_USD=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_USD=new BigDecimal(0);
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try{
			int j=0;
			
			for (int i=0;i<iMap.getSize("ISLEM_LIST");i++){
				
				if(iMap.getString("ISLEM_TIPI").compareTo(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"))==0){
					oMap.put("SONUC_LIST", j, "ANAISLEMDURUM", iMap.getString("ISLEM_LIST", i, "ANAISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "EFT_HESAP_KASA", iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA"));
					oMap.put("SONUC_LIST", j, "IPTALISLEMDURUM", iMap.getString("ISLEM_LIST", i, "IPTALISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "ISLEM_KOD", iMap.getString("ISLEM_LIST", i, "ISLEM_KOD"));
					oMap.put("SONUC_LIST", j, "ISLEM_NO_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_NO_PTT"));
					oMap.put("SONUC_LIST", j, "ISLEM_TURU_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF", iMap.getString("ISLEM_LIST", i, "MASRAF"));
					oMap.put("SONUC_LIST", j, "NUMARA", iMap.getString("ISLEM_LIST", i, "NUMARA"));
					oMap.put("SONUC_LIST", j, "PTT_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "PTT_ISLEM_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_MASRAF_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
					//oMap.put("SONUC_LIST", j, "PTT_TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "PTT_TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "PTTISLEMNO", iMap.getString("ISLEM_LIST", i, "PTTISLEMNO"));
					oMap.put("SONUC_LIST", j, "REFERANS", iMap.getString("ISLEM_LIST", i, "REFERANS"));
					//oMap.put("SONUC_LIST", j, "TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "TUTAR", iMap.getString("ISLEM_LIST", i, "TUTAR"));
					oMap.put("SONUC_LIST", j, "ISLEM_ADI_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_ADI_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"));
					
					oMap.put("SONUC_LIST", j, "AKTIFBANK_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "AKTIFBANK_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "AKTIFBANK_DOVIZ_TUTARI", iMap.getString("ISLEM_LIST", i, "AKTIFBANK_DOVIZ_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_DOVIZ_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));
					oMap.put("SONUC_LIST", j, "AKTIFBANK_TL_TUTARI", iMap.getString("ISLEM_LIST", i, "AKTIFBANK_TL_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_TL_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_TL_TUTARI"));
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("TRY")==0){
						
					  if (iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
						//PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
						  if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD").compareTo("2850")==0){
							  PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));
						  }
						  if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD").compareTo("2032")==0){
							  PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));
						  }						  
						  PTT_ISLEM_ADET_TRY = PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
							
						if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
							PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
						if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
							PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
						if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
							PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}	
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							//BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD").compareTo("2850")==0){
								BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));
							}
							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD").compareTo("2032")==0){
								BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
							}	
							BANKA_ISLEM_ADET_TRY = BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
							
							if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
								BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
							if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
								BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
							if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
								BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}								
							}	
						}
					}		
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("USD")==0){
						
					  if (iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
						  //PTT_IS"HESAPTAN"_TOPLAM_USD = PTT_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
						  if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD").compareTo("2850")==0){
							  PTT_ISLEM_TOPLAM_USD = PTT_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));
						  }
						  if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD").compareTo("2032")==0){
							  PTT_ISLEM_TOPLAM_USD = PTT_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
						  }							  
						  PTT_ISLEM_ADET_USD = PTT_ISLEM_ADET_USD.add(new BigDecimal("1"));
						if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
							PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
							PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
							PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}	
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){	
							//BANKA_ISLEM_TOPLAM_USD = BANKA_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD").compareTo("2850")==0){
								BANKA_ISLEM_TOPLAM_USD = BANKA_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));
							}
							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD").compareTo("2032")==0){
								BANKA_ISLEM_TOPLAM_USD = BANKA_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
							}
							BANKA_ISLEM_ADET_USD = BANKA_ISLEM_ADET_USD.add(new BigDecimal("1"));
						  if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
							  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
						  if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
							  BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
						  if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
							  BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}	
						}
						if (iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI").compareTo(new BigDecimal(0)) !=0){
							PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));	
							BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));
						}
					  }
					}		
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("EUR")==0){
						
					  if (iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
						  //PTT_ISLEM_TOPLAM_EUR = PTT_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
						  if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD").compareTo("2850")==0){
							  PTT_ISLEM_TOPLAM_EUR = PTT_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));
						  }
						  if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD").compareTo("2032")==0){
							  PTT_ISLEM_TOPLAM_EUR = PTT_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
						  }							  
						  PTT_ISLEM_ADET_EUR = PTT_ISLEM_ADET_EUR.add(new BigDecimal("1"));
						if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU")) ){	
							BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU")) ){
							PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
							PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}	
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							//BANKA_ISLEM_TOPLAM_EUR = BANKA_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD").compareTo("2850")==0){
								BANKA_ISLEM_TOPLAM_EUR = BANKA_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));
							}
							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD").compareTo("2032")==0){
								BANKA_ISLEM_TOPLAM_EUR = BANKA_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
							}							
							BANKA_ISLEM_ADET_EUR = BANKA_ISLEM_ADET_EUR.add(new BigDecimal("1"));
							if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))  ){
							   BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
							if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU")) ){
								BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
							if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU")) ){
								BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}		
						}
						if (iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI").compareTo(new BigDecimal(0)) !=0){
							PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));	
							BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));
						}	
					  }
					}	
					
					if(iMap.getString("ISLEM_TIPI").compareTo("IPTAL")==0){
						
						conn = DALUtil.getGMConnection();
						stmt = conn.prepareCall("{ ? = call pkg_tx.Islem_kod(?) }");
						stmt.registerOutParameter(1, Types.NUMERIC);
						stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_LIST", i, "NUMARA"));
						stmt.execute();
						
						iMap.put("ISLEM_KODU", stmt.getBigDecimal(1));
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("TRY")==0   ){
						  if (iMap.getString("ISLEM_KODU").compareTo("2850")==0  )   {
							if (iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
								//PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));
								PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
							 	
							  if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
								  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							  }
							  if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
								  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							  }
							  if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
								  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							  }	
							  if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
								  //BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								  BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));
								  BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
									BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
								if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
									BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
								if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
									BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}	 	
							  }	
							}
						  }
						  if (iMap.getString("ISLEM_KODU").compareTo("2032")==0  ){
							  PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
							  PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
						    if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
							    PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
							if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
								PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
							if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
							    PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}		
							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
								BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));		 
							  if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
								  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							  }
							  if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
								  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							  }
							  if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
								  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							  }	
							  BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
							}		
						  }
						}		
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("USD")==0){
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2850")==0  )   {
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
								
								 //PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									PTT_ISLEM_TOPLAM_USD = PTT_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));	
								 PTT_ISLEM_ADET_USD.add(new BigDecimal("1"));
								 
								  if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
									  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
									  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
									  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 	
								 if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									
									 /*BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));*/
									 BANKA_ISLEM_TOPLAM_USD = BANKA_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));	
									 BANKA_ISLEM_ADET_USD.add(new BigDecimal("1"));									 
									  if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
										  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
										  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
										  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}  
								 }	
								}
						}
								if ( iMap.getString("ISLEM_KODU").compareTo("2032")==0 ){

									 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									 
									  if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
										  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
										  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
										  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										} 

									if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
										
										 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
										 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
										 
										 if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
											  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											}
										 if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
											  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											}
										 if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
											  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											} 
									}		
								}
						}		
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("EUR")==0){
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2850")==0 )   {
								
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
								/*	
								 PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
//								*/
									PTT_ISLEM_TOPLAM_EUR = PTT_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));	
								 PTT_ISLEM_ADET_EUR.add(new BigDecimal("1"));	
								 if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
									 PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
									 PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
									 PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									} 
								if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									
									 /*BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));*/
									BANKA_ISLEM_TOPLAM_EUR = BANKA_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));	
									BANKA_ISLEM_ADET_EUR.add(new BigDecimal("1"));
									 
									 if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
										 BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									 if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
										 BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									 if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
										 BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										} 
								}	
								}
								}
								
								if (  iMap.getString("ISLEM_KODU").compareTo("2032")==0 ){
									
									 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									 
									 if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
										 PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									 if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
										 PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									 if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
										 PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										} 
									
									if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
										
										 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
										 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
										 
										 if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
											 BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											}
										 if ("USD".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
											 BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											}
										 if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))){
											 BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											} 										 
									}	
								}
						}
					}
					j++;	
				}
				
			}	

			if (iMap.getString("ISLEM_TIPI").compareTo("SWIFT_GIDEN") ==0   ){
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}
			if (iMap.getString("ISLEM_TIPI").compareTo("SWIFT_GELEN") ==0  ){
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.subtract(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.subtract(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.subtract(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.subtract(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.subtract(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.subtract(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}
			if (iMap.getString("ISLEM_TIPI").compareTo("IPTAL") ==0  ){
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}
			if (iMap.getString("ISLEM_TIPI").compareTo("IADE_UPT_ODEME'") ==0  ){
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}			
			
			
			oMap.put("PTT_ISLEM_TOPLAM_TRY", PTT_ISLEM_TOPLAM_TRY);
			oMap.put("PTT_MASRAF_TOPLAM_TRY", PTT_MASRAF_TOPLAM_TRY);
			oMap.put("PTT_GENEL_TOPLAM_TRY", PTT_GENEL_TOPLAM_TRY);
			oMap.put("PTT_ISLEM_ADET_TRY", PTT_ISLEM_ADET_TRY);
			
			oMap.put("BANKA_ISLEM_TOPLAM_TRY", BANKA_ISLEM_TOPLAM_TRY);
			oMap.put("BANKA_MASRAF_TOPLAM_TRY", BANKA_MASRAF_TOPLAM_TRY);
			oMap.put("BANKA_GENEL_TOPLAM_TRY", BANKA_GENEL_TOPLAM_TRY);
			oMap.put("BANKA_ISLEM_ADET_TRY", BANKA_ISLEM_ADET_TRY);	
			
			oMap.put("PTT_ISLEM_TOPLAM_EUR", PTT_ISLEM_TOPLAM_EUR);
			oMap.put("PTT_MASRAF_TOPLAM_EUR", PTT_MASRAF_TOPLAM_EUR);
			oMap.put("PTT_GENEL_TOPLAM_EUR", PTT_GENEL_TOPLAM_EUR);
			oMap.put("PTT_ISLEM_ADET_EUR", PTT_ISLEM_ADET_EUR);
			
			oMap.put("BANKA_ISLEM_TOPLAM_EUR", BANKA_ISLEM_TOPLAM_EUR);
			oMap.put("BANKA_MASRAF_TOPLAM_EUR", BANKA_MASRAF_TOPLAM_EUR);
			oMap.put("BANKA_GENEL_TOPLAM_EUR", BANKA_GENEL_TOPLAM_EUR);
			oMap.put("BANKA_ISLEM_ADET_EUR", BANKA_ISLEM_ADET_EUR);	
			
			oMap.put("PTT_ISLEM_TOPLAM_USD", PTT_ISLEM_TOPLAM_USD);
			oMap.put("PTT_MASRAF_TOPLAM_USD", PTT_MASRAF_TOPLAM_USD);
			oMap.put("PTT_GENEL_TOPLAM_USD", PTT_GENEL_TOPLAM_USD);
			oMap.put("PTT_ISLEM_ADET_USD", PTT_ISLEM_ADET_USD);
			
			oMap.put("BANKA_ISLEM_TOPLAM_USD", BANKA_ISLEM_TOPLAM_USD);
			oMap.put("BANKA_MASRAF_TOPLAM_USD", BANKA_MASRAF_TOPLAM_USD);
			oMap.put("BANKA_GENEL_TOPLAM_USD", BANKA_GENEL_TOPLAM_USD);
			oMap.put("BANKA_ISLEM_ADET_USD", BANKA_ISLEM_ADET_USD);	
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_SW")
	public static GMMap getSecondLevelAktifSW(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call Pkg_Rc_Ptt_FC.RC_QRY_GET_2nd_LEVEL_AKT(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_SW")
	public static GMMap getMutabakatsizIslemlerSW(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call Pkg_Rc_Ptt_FC.Agreement_Response(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			rSet= (ResultSet)stmt.getObject(1);

		    oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT_MUTABAKATSIZ");

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_SW")
	public static GMMap getMutabakatOnlyMutabatsizSW(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call Pkg_Rc_Ptt_FC.Agreement_Response(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
				
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_UPT_DATA")
	public static GMMap getUPTData(GMMap iMap){
		
		GMMap oMap = new GMMap();
		GMMap oMapOnlyMutabakatsiz = new GMMap();
		
		BigDecimal PTTYT1 =  new BigDecimal(0);
		BigDecimal AKTIFBANKYT1 =new BigDecimal(0);
	       
	    BigDecimal MASRAFYATANPTTTRY =  new BigDecimal(0);
	    BigDecimal MASRAFYATANAKTIFBANKTRY =  new BigDecimal(0);
	    
	    BigDecimal PPTYATANADETTRY =  new BigDecimal(0);
	    BigDecimal AKTIFBANKYATANADETTRY =  new BigDecimal(0);
	    
	    BigDecimal pttbankCT1 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT1 =  new BigDecimal(0);
	    
	    BigDecimal MASRAFCEKILENPTTTRY =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENAKTIFBANKTRY =  new BigDecimal(0);
	    
	    BigDecimal PPTCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCEKILENADETTRY =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANTRY =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENTRY =  new BigDecimal(0);
	    
	    BigDecimal IPTALMASRAFPTTYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKYATANTRY =  new BigDecimal(0);
	    
	    BigDecimal IPTALMASRAFPTTCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKCEKILENTRY =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTYATANADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALBANKAYATANADETTRY =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALBANKACEKILENADETTRY =  new BigDecimal(0);
	    
	    int i = 1;
		int j = 0;
		String tableName = "CBS_AKTIFBANK_PTT";
		String tableNameMutabakatsiz = "CBS_AKTIFBANK_PTT_MUTABAKATSIZ";

		try {
			
			oMap.put(tableName, GMServiceExecuter.execute("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_UPT", iMap).get("CBS_AKTIFBANK"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_UPT", iMap));
			i = oMap.getSize(tableName);
			
			for (j = 0; j < iMap.getSize(tableNameMutabakatsiz); j++) {
				
				oMap.put(tableName, i, "ISLEM_TURU_PTT", iMap.getString(tableNameMutabakatsiz, j, "ISLEM_TURU_PTT"));
				oMap.put(tableName, i, "PTT_ISLEM_TUTARI", iMap.getString(tableNameMutabakatsiz, j, "PTT_ISLEM_TUTARI"));
				oMap.put(tableName, i, "PTT_MASRAF_TUTARI", iMap.getString(tableNameMutabakatsiz, j, "PTT_MASRAF_TUTARI"));
				oMap.put(tableName, i, "ISLEM_NO_PTT", iMap.getString(tableNameMutabakatsiz, j, "ISLEM_NO_PTT"));
				oMap.put(tableName, i, "NUMARA", iMap.getString(tableNameMutabakatsiz, j, "NUMARA"));
				oMap.put(tableName, i, "PTT_DOVIZ_KODU", iMap.getString(tableNameMutabakatsiz, j, "PTT_DOVIZ_KODU"));
				oMap.put(tableName, i, "EFT_HESAP_KASA", iMap.getString(tableNameMutabakatsiz, j, "EFT_HESAP_KASA"));
				oMap.put(tableName, i, "ISLEM", iMap.getString(tableNameMutabakatsiz, j, "ISLEM"));
				oMap.put(tableName, i, "PTT_TOPLAM_TUTAR", iMap.getString(tableNameMutabakatsiz, j, "PTT_TOPLAM_TUTAR"));
				oMap.put(tableName, i, "ISLEM_ADI_PTT", iMap.getString(tableNameMutabakatsiz, j, "ISLEM_ADI_PTT"));
				oMap.put(tableName, i, "MASRAF_DOVIZ_KODU", iMap.getString(tableNameMutabakatsiz, j, "MASRAF_DOVIZ_KODU"));

				i++;
			}
			
			// Code Review
			for (j = 0; j < oMap.getSize(tableName); j++) {

				// Case: Yatan Islemler
				if ("PTT EFT".equals(oMap.getString(tableName, j, "ISLEM"))) {
					
					// Case: Kasadan Yatan Islemler
					if(oMap.getString(tableName, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0) {
					
						// PTT Yatan
						PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName, j, "PTT_ISLEM_TUTARI"));
						PPTYATANADETTRY = PPTYATANADETTRY.add(new BigDecimal(1));
		
						// PTT Yatan Masraf
						MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName, j, "PTT_MASRAF_TUTARI"));
						
						// Case: PTT Iptal Yatan 
						if ("IPTAL".equals(oMap.getString(tableName, j, "ISLEM_TURU_PTT"))) {

							// PTT Iptal Yatan
							IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName, j, "PTT_ISLEM_TUTARI"));
							IPTALPTTYATANADETTRY = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
							
							// PTT Iptal Yatan Masraf
							IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName, j, "PTT_MASRAF_TUTARI"));

						}
						
						// Case: Aktifbank Yatan Islemler
						if (oMap.getString(tableName, j, "ISLEM_KOD") != null) {
							
							// Aktifbank Yatan
							AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName, j, "TUTAR"));
							AKTIFBANKYATANADETTRY = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));

							// Aktifbank Yatan Masraflar
							MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName, j, "MASRAF"));
							
							// Case: Aktifbank Iptal Yatan 
							if ("IPTAL".equals(oMap.getString(tableName, j, "ISLEM_TURU_PTT"))) {
								
								// Aktifbank Iptal Yatan
								IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName, j, "TUTAR"));
								IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));

								// Aktifbank Iptal Yatan Masraflar
								IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName, j, "PTT_MASRAF_TUTARI"));
							}
						}
					}
				}
				
				// Case: Cekilen Islemler
				else if ("PTT UPT".equals(oMap.getString(tableName, j, "ISLEM"))) {

					// Case: PTT Cekilen
					if("PTT UPT".equals(oMap.getString(tableName, j, "ISLEM_TURU_PTT"))) {
						
						// PTT Cekilen
						pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName, j, "PTT_ISLEM_TUTARI"));
						PPTCEKILENADETTRY   = PPTCEKILENADETTRY.add(new BigDecimal(1));
						
						// PTT Cekilen Masraf
						MASRAFCEKILENPTTTRY =  MASRAFCEKILENPTTTRY.add(oMap.getBigDecimal(tableName, j, "PTT_MASRAF_TUTARI"));
					}
					
					// Case: PTT Iptal Cekilen
					else if ("IPTAL".equals(oMap.getString(tableName, j, "ISLEM_TURU_PTT"))){
						
						if (oMap.getString(tableName, j, "PTT_DOVIZ_KODU") != null){
						
							// PTT Iptal Cekilen
							IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName, j, "PTT_ISLEM_TUTARI"));
							IPTALPTTCEKILENADETTRY  = IPTALPTTCEKILENADETTRY.add(new BigDecimal(1));

							// PTT Iptal Cekilen Masraf
							IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(oMap.getBigDecimal(tableName, j, "PTT_MASRAF_TUTARI"));
						}
					}
					
					// Case: Aktifbank Cekilen Islemler
					if (oMap.getString(tableName, j, "ISLEM_KOD") != null) {
						
						// Case: PTT Cekilen
						if("PTT UPT".equals(oMap.getString(tableName, j, "ISLEM_TURU_PTT"))) {
							// Aktifbank Cekilen
							AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName, j, "TUTAR") ) ;
							AKTIFBANKCEKILENADETTRY   = AKTIFBANKCEKILENADETTRY.add(new BigDecimal(1));
							
							// Aktifbank Cekilen Masraf
							MASRAFCEKILENAKTIFBANKTRY =  MASRAFCEKILENAKTIFBANKTRY.add(oMap.getBigDecimal(tableName, j, "MASRAF"));
						}
						
						// Case: PTT Iptal Cekilen
						else if ("IPTAL".equals(oMap.getString(tableName, j, "ISLEM_TURU_PTT"))){
							
							// Aktifbank Iptal Cekilen
							IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName, j, "TUTAR"));
							IPTALBANKACEKILENADETTRY = IPTALBANKACEKILENADETTRY.add(new BigDecimal(1));
							
							// Aktifbank Iptal Cekilen Masraf
							IPTALMASRAFAKTIFBANKCEKILENTRY = IPTALMASRAFAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName, j, "PTT_MASRAF_TUTARI"));					
						}
					}
				}
			}

			BigDecimal PTT_BORC_TL =  new BigDecimal(0);
			BigDecimal AKTIFBANK_BORC_TL =  new BigDecimal(0);
			BigDecimal TOPLAMYATANPTTTRY =   PTTYT1.add(MASRAFYATANPTTTRY);
			BigDecimal TOPLAMYATANAKTIFBANKTRY = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY);
			BigDecimal TOPLAMCEKILENPTTTRY =   pttbankCT1.subtract(MASRAFCEKILENPTTTRY) ; 
		    BigDecimal TOPLAMCEKILENAKTIFBANKTRY =  AKTIFBANKCT1.subtract(MASRAFCEKILENAKTIFBANKTRY)  ;
			
			oMap.put("PTTYT1", PTTYT1);
			oMap.put("PPTYATANADETTRY", PPTYATANADETTRY);
			oMap.put("MASRAFYATANPTTTRY", MASRAFYATANPTTTRY);
			oMap.put("IPTALPTTYATANTRY", IPTALPTTYATANTRY);
			 
			oMap.put("AKTIFBANKYT1", AKTIFBANKYT1);
			oMap.put("MASRAFYATANAKTIFBANKTRY", MASRAFYATANAKTIFBANKTRY);
			oMap.put("AKTIFBANKYATANADETTRY", AKTIFBANKYATANADETTRY);
			oMap.put("IPTALAKTIFBANKYATANTRY", IPTALAKTIFBANKYATANTRY);
			 
			oMap.put("pttbankCT1", pttbankCT1);
			oMap.put("PPTCEKILENADETTRY", PPTCEKILENADETTRY);
			oMap.put("MASRAFCEKILENPTTTRY", MASRAFCEKILENPTTTRY);
			oMap.put("IPTALPTTCEKILENTRY", IPTALPTTCEKILENTRY)  ;
			
			oMap.put("AKTIFBANKCT1", AKTIFBANKCT1);
			oMap.put("AKTIFBANKCEKILENADETTRY", AKTIFBANKCEKILENADETTRY);
			oMap.put("MASRAFCEKILENAKTIFBANKTRY", MASRAFCEKILENAKTIFBANKTRY);
			oMap.put("IPTALAKTIFBANKCEKILENTRY", IPTALAKTIFBANKCEKILENTRY);
		 
		    oMap.put("TOPLAMYATANPTTTRY", TOPLAMYATANPTTTRY)  ;
		    oMap.put("TOPLAMYATANAKTIFBANKTRY", TOPLAMYATANAKTIFBANKTRY)  ;
		    oMap.put("TOPLAMCEKILENPTTTRY", TOPLAMCEKILENPTTTRY)  ;
		    oMap.put("TOPLAMCEKILENAKTIFBANKTRY", TOPLAMCEKILENAKTIFBANKTRY)  ;
		    
		    oMap.put("IPTALMASRAFPTTYATANTRY", IPTALMASRAFPTTYATANTRY)  ;
		    oMap.put("IPTALMASRAFAKTIFBANKYATANTRY", IPTALMASRAFAKTIFBANKYATANTRY)  ;
		    oMap.put("IPTALMASRAFPTTCEKILENTRY", IPTALMASRAFPTTCEKILENTRY)  ;
		    oMap.put("IPTALMASRAFAKTIFBANKCEKILENTRY", IPTALMASRAFAKTIFBANKCEKILENTRY)  ;
	    
		    oMap.put("IPTALPTTYATANADETTRY", IPTALPTTYATANADETTRY)  ;
		    oMap.put("IPTALBANKAYATANADETTRY", IPTALBANKAYATANADETTRY)  ;
		    oMap.put("IPTALPTTCEKILENADETTRY", IPTALPTTCEKILENADETTRY)  ;
		    oMap.put("IPTALBANKACEKILENADETTRY", IPTALBANKACEKILENADETTRY)  ;
	    
		    PTT_BORC_TL = PTTYT1.add(MASRAFYATANPTTTRY).subtract(IPTALPTTYATANTRY).subtract(IPTALMASRAFPTTYATANTRY).add(MASRAFCEKILENPTTTRY).subtract(pttbankCT1).add(IPTALPTTCEKILENTRY).subtract(IPTALMASRAFPTTCEKILENTRY);
		    AKTIFBANK_BORC_TL = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY).subtract(IPTALAKTIFBANKYATANTRY).subtract(IPTALMASRAFAKTIFBANKYATANTRY).add(MASRAFCEKILENAKTIFBANKTRY).subtract(AKTIFBANKCT1).add(IPTALAKTIFBANKCEKILENTRY).subtract(IPTALMASRAFAKTIFBANKCEKILENTRY);
		    
			oMap.put("BORC_TL_PTT", PTT_BORC_TL);
			oMap.put("BORC_TL_BANKA", "0");
		
			if(PTT_BORC_TL.intValue() < 0) {
				AKTIFBANK_BORC_TL = PTT_BORC_TL;
				oMap.put("BORC_TL_BANKA", AKTIFBANK_BORC_TL);
				oMap.put("BORC_TL_PTT", "0");
			}
		
			GMMap sMap = new GMMap();
			
			sMap.put("TARIH", iMap.get("TARIH"));
			sMap.put("AKTIFBANK_BORC_TL", AKTIFBANK_BORC_TL);
			sMap.put("PTT_BORC_TL", PTT_BORC_TL);
			oMap.put("KAYIT_SAYISI","1");
			
			// BU KONTROL BLOGU KALDIRILIRSA MUTABAKATLILARDA LISTELENECEK
			if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("true")==0){
				oMapOnlyMutabakatsiz.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_UPT", iMap));
				
				oMap.put("KAYIT_SAYISI", oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT"));
				
				if (oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT")>0){
					oMap.putAll(oMapOnlyMutabakatsiz);
				} else{
					oMap.remove("CBS_AKTIFBANK_PTT");
				}
			}
		
		return oMap;
		
		} 
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_ISLEMLER_UPT")
	public static GMMap Get_Islemler_UPT(GMMap iMap){
		GMMap oMap = new GMMap();
		
		BigDecimal PTT_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_TRY=new BigDecimal(0);
		
		BigDecimal PTT_ISLEM_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_EUR=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_EUR=new BigDecimal(0);
		
		BigDecimal PTT_ISLEM_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_USD=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_USD=new BigDecimal(0);
		
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		

		try{
			int j=0;
			
			for (int i=0;i<iMap.getSize("ISLEM_LIST");i++){
				
				
				if(iMap.getString("ISLEM_TIPI").compareTo(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"))==0){
					oMap.put("SONUC_LIST", j, "ANAISLEMDURUM", iMap.getString("ISLEM_LIST", i, "ANAISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "EFT_HESAP_KASA", iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA"));
					oMap.put("SONUC_LIST", j, "IPTALISLEMDURUM", iMap.getString("ISLEM_LIST", i, "IPTALISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "ISLEM_KOD", iMap.getString("ISLEM_LIST", i, "ISLEM_KOD"));
					oMap.put("SONUC_LIST", j, "ISLEM_NO_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_NO_PTT"));
					oMap.put("SONUC_LIST", j, "ISLEM_TURU_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF", iMap.getString("ISLEM_LIST", i, "MASRAF"));
					oMap.put("SONUC_LIST", j, "NUMARA", iMap.getString("ISLEM_LIST", i, "NUMARA"));
					oMap.put("SONUC_LIST", j, "PTT_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "PTT_ISLEM_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_MASRAF_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "PTT_TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "PTTISLEMNO", iMap.getString("ISLEM_LIST", i, "PTTISLEMNO"));
					oMap.put("SONUC_LIST", j, "REFERANS", iMap.getString("ISLEM_LIST", i, "REFERANS"));
					oMap.put("SONUC_LIST", j, "TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "TUTAR", iMap.getString("ISLEM_LIST", i, "TUTAR"));
					oMap.put("SONUC_LIST", j, "ISLEM_ADI_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_ADI_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"));
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("TRY")==0){
						
						if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
						
							PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
							PTT_ISLEM_ADET_TRY = PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
						

							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
								PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
						
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
								PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
						
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
								PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}	
						
						
							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
								BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								//BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								BANKA_ISLEM_ADET_TRY = BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
							
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}								
							
							}	
						}
					}		
					
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("USD")==0){
						
						if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
						
						PTT_ISLEM_TOPLAM_USD = PTT_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
						//PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						PTT_ISLEM_ADET_USD = PTT_ISLEM_ADET_USD.add(new BigDecimal("1"));
						
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
							PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
							PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
							PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						
						
						
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							
							BANKA_ISLEM_TOPLAM_USD = BANKA_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
							BANKA_ISLEM_ADET_USD = BANKA_ISLEM_ADET_USD.add(new BigDecimal("1"));
							
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
								BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
								BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
								BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}	
						}	
						
						}
					}		
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("EUR")==0){
						
						if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
						
						PTT_ISLEM_TOPLAM_EUR = PTT_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
						//PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						PTT_ISLEM_ADET_EUR = PTT_ISLEM_ADET_EUR.add(new BigDecimal("1"));
						
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
							PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
							PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
							PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}	
						
						
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							BANKA_ISLEM_TOPLAM_EUR = BANKA_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
							//BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							BANKA_ISLEM_ADET_EUR = BANKA_ISLEM_ADET_EUR.add(new BigDecimal("1"));
							
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
								BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
								BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
								BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}	
							
						}	
						
						}
					}	
					
					
					if(iMap.getString("ISLEM_TIPI").compareTo("IPTAL")==0){
						
						conn = DALUtil.getGMConnection();
						stmt = conn.prepareCall("{ ? = call pkg_tx.Islem_kod(?) }");
						
						stmt.registerOutParameter(1, Types.NUMERIC);
						stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_LIST", i, "NUMARA"));
						
						stmt.execute();
						
						iMap.put("ISLEM_KODU", stmt.getBigDecimal(1));
						
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("TRY")==0   ){
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2315")==0  )   {
							
								
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
								
								PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
							 	//PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							 	PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
							 	
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}	
							 	
							 	
								
							 	if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
								
								 	BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 	//BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 	BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								 	
								 	
									if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
									if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
									if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}	
								 	
								}	
							
							}
							
							}
							
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2317")==0  ){
								
								
								 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 //PTT_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								 
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									  PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									  PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}	
								 
								 
								
								if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 //BANKA_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										  BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										  BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}	

									 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								}		
							}
						}		
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("USD")==0){
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2315")==0  )   {
								
								
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
								
								 PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								 
								 
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									  PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									  PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 
								 
								 
									
								 if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									
									 BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 //BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									 
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										  BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										  BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										} 
									 
								 }	
								
								}
								
						}
								
								
								if ( iMap.getString("ISLEM_KODU").compareTo("2317")==0 ){
									
									
									 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 //PTT_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									 
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										  PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										  PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										} 
									 
									 
									
									if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
										
										 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
										 //BANKA_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
										 
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
											  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											}
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
											  BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											}
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
											  BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											} 
										 
									}		
								}
						}		
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("EUR")==0){
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2315")==0 )   {
								
								
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
									
								 PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 //PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								 
								 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									 PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									 PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									 PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									} 
								 
								 
								 
									
								if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									
									 BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 // BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									 
									 
									 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										 BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										 BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										 BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										} 

								}	
								
								}
								
								}
								
								if (  iMap.getString("ISLEM_KODU").compareTo("2317")==0 ){
									
									 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 //PTT_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									 
									 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										 PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										 PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										 PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										} 
									 
									 
									
									if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
										
										 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
										 //BANKA_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
										 
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
											 BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											}
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
											 BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											}
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
											 BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											} 										 
										 
									}	
								}
						}
					}
					j++;	
				}
			}	

			if (iMap.getString("ISLEM_TIPI").compareTo("PTT EFT") ==0   ){
			
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}
			
			if (iMap.getString("ISLEM_TIPI").compareTo("PTT UPT") ==0  ){
			
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.subtract(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.subtract(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.subtract(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.subtract(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.subtract(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.subtract(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}
			
			
			if (iMap.getString("ISLEM_TIPI").compareTo("IPTAL") ==0  ){
			
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			
			}
			
			oMap.put("PTT_ISLEM_TOPLAM_TRY", PTT_ISLEM_TOPLAM_TRY);
			oMap.put("PTT_MASRAF_TOPLAM_TRY", PTT_MASRAF_TOPLAM_TRY);
			oMap.put("PTT_GENEL_TOPLAM_TRY", PTT_GENEL_TOPLAM_TRY);
			oMap.put("PTT_ISLEM_ADET_TRY", PTT_ISLEM_ADET_TRY);
			
			oMap.put("BANKA_ISLEM_TOPLAM_TRY", BANKA_ISLEM_TOPLAM_TRY);
			oMap.put("BANKA_MASRAF_TOPLAM_TRY", BANKA_MASRAF_TOPLAM_TRY);
			oMap.put("BANKA_GENEL_TOPLAM_TRY", BANKA_GENEL_TOPLAM_TRY);
			oMap.put("BANKA_ISLEM_ADET_TRY", BANKA_ISLEM_ADET_TRY);	
			
			oMap.put("PTT_ISLEM_TOPLAM_EUR", PTT_ISLEM_TOPLAM_EUR);
			oMap.put("PTT_MASRAF_TOPLAM_EUR", PTT_MASRAF_TOPLAM_EUR);
			oMap.put("PTT_GENEL_TOPLAM_EUR", PTT_GENEL_TOPLAM_EUR);
			oMap.put("PTT_ISLEM_ADET_EUR", PTT_ISLEM_ADET_EUR);
			
			oMap.put("BANKA_ISLEM_TOPLAM_EUR", BANKA_ISLEM_TOPLAM_EUR);
			oMap.put("BANKA_MASRAF_TOPLAM_EUR", BANKA_MASRAF_TOPLAM_EUR);
			oMap.put("BANKA_GENEL_TOPLAM_EUR", BANKA_GENEL_TOPLAM_EUR);
			oMap.put("BANKA_ISLEM_ADET_EUR", BANKA_ISLEM_ADET_EUR);	
			
			oMap.put("PTT_ISLEM_TOPLAM_USD", PTT_ISLEM_TOPLAM_USD);
			oMap.put("PTT_MASRAF_TOPLAM_USD", PTT_MASRAF_TOPLAM_USD);
			oMap.put("PTT_GENEL_TOPLAM_USD", PTT_GENEL_TOPLAM_USD);
			oMap.put("PTT_ISLEM_ADET_USD", PTT_ISLEM_ADET_USD);
			
			oMap.put("BANKA_ISLEM_TOPLAM_USD", BANKA_ISLEM_TOPLAM_USD);
			oMap.put("BANKA_MASRAF_TOPLAM_USD", BANKA_MASRAF_TOPLAM_USD);
			oMap.put("BANKA_GENEL_TOPLAM_USD", BANKA_GENEL_TOPLAM_USD);
			oMap.put("BANKA_ISLEM_ADET_USD", BANKA_ISLEM_ADET_USD);	
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_UPT")
	public static GMMap getSecondLevelAktifUPT(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.RC_QRY_GET_2nd_LEVEL_AKT_UPT(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_UPT")
	public static GMMap getMutabakatsizIslemlerUPT(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.Agreement_Response_UPT(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			
			//if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("1")==0){
			//	oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
			//}else{
				oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT_MUTABAKATSIZ");
			//}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_UPT")
	public static GMMap getMutabakatOnlyMutabatsizUPT(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.Agreement_Response_UPT(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
				
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	
	
	
	
	
	
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_KREDI_DATA")
	public static GMMap getKrediData(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		BigDecimal PTTYT1 =  new BigDecimal(0);
		BigDecimal AKTIFBANKYT1 =new BigDecimal(0);
		BigDecimal pttbankYT2 =new BigDecimal(0);
		BigDecimal YATAN_AKT_EUR =new BigDecimal(0);
		BigDecimal pttbankYT3  = new BigDecimal(0);
	    BigDecimal AKTIFBANKYT3 = new BigDecimal(0);
	       
	    BigDecimal MASRAFYATANPTTTRY =  new BigDecimal(0);
	    BigDecimal MASRAFYATANAKTIFBANKTRY =  new BigDecimal(0);
	    BigDecimal MASRAFYATANPTTEUR =  new BigDecimal(0);
	    BigDecimal MASRAFYATANAKTIFBANKEUR =  new BigDecimal(0);
	    BigDecimal MASRAFYATANPTTUSD =  new BigDecimal(0);
	    BigDecimal MASRAFYATANAKTIFBANKUSD =  new BigDecimal(0);
	    
	    BigDecimal PPTYATANADETTRY =  new BigDecimal(0);
	    BigDecimal AKTIFBANKYATANADETTRY =  new BigDecimal(0);
	    BigDecimal PTTYATANADETEUR =  new BigDecimal(0);
	    BigDecimal AKTIFBANKYATANADETEUR =  new BigDecimal(0);
	    BigDecimal PTTYATANADETUSD =  new BigDecimal(0);
	    BigDecimal AKTIFBANKYATANADETUSD =  new BigDecimal(0);
	    
	    
	    BigDecimal pttbankCT1 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT1 =  new BigDecimal(0);
	    BigDecimal pttbankCT2 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT2 =  new BigDecimal(0);
	    BigDecimal pttbankCT3 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT3 =  new BigDecimal(0);
	    
	    BigDecimal MASRAFCEKILENPTTTRY =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENAKTIFBANKTRY =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENPTTEUR =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENAKTIFBANKEUR =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENPTTUSD =  new BigDecimal(0);
	    BigDecimal MASRAFCEKILENAKTIFBANKUSD =  new BigDecimal(0);
	    
	    
	    BigDecimal PPTCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal PTTCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal PTTCEKILENADETUSD =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCEKILENADETUSD =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANEUR =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENUSD =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENUSD =  new BigDecimal(0);
	    

	    BigDecimal IPTALMASRAFPTTYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFPTTYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFPTTYATANEUR =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKYATANEUR =  new BigDecimal(0);
	    
	    BigDecimal IPTALMASRAFPTTCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFPTTCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFPTTCEKILENUSD =  new BigDecimal(0);
	    BigDecimal IPTALMASRAFAKTIFBANKCEKILENUSD =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTYATANADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALBANKAYATANADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANADETUSD =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANADETUSD =  new BigDecimal(0);
	    
	    
	    BigDecimal IPTALPTTCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALBANKACEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENADETUSD =  new BigDecimal(0);
	    BigDecimal IPTALBANKACEKILENADETUSD =  new BigDecimal(0);
	    
	    
	    GMMap   oMapOnlyMutabakatsiz = new GMMap();
	    
   
	    

		try{
			
			int i = 1;

			oMap.put("CBS_AKTIFBANK_PTT", GMServiceExecuter.execute("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_KREDI", iMap).get("CBS_AKTIFBANK"));

			String tableName = "CBS_AKTIFBANK_PTT";
			 i =  oMap.getSize(tableName); 
			int j=0;
			
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_KREDI", iMap));


			String tableName2 = "CBS_AKTIFBANK_PTT";
			tableName = "CBS_AKTIFBANK_PTT_MUTABAKATSIZ";
			for ( j = 0; j < iMap.getSize(tableName); j++) {
				oMap.put(tableName2, i, "ISLEM_TURU_PTT", iMap.getString(tableName, j,
						"ISLEM_TURU_PTT"));
				oMap.put(tableName2, i, "PTT_ISLEM_TUTARI", iMap.getString(tableName, j,
						"PTT_ISLEM_TUTARI"));
				oMap.put(tableName2, i, "PTT_MASRAF_TUTARI", iMap.getString(tableName, j,
						"PTT_MASRAF_TUTARI"));
				oMap.put(tableName2, i, "ISLEM_NO_PTT", iMap.getString(tableName, j,
						"ISLEM_NO_PTT"));
				oMap.put(tableName2, i, "NUMARA", iMap.getString(tableName, j,
				"NUMARA"));  // ISLEMNOBANKA
				
				oMap.put(tableName2, i, "PTT_DOVIZ_KODU", iMap.getString(tableName, j,
				"PTT_DOVIZ_KODU"));
				
				oMap.put(tableName2, i, "EFT_HESAP_KASA", iMap.getString(tableName, j,
				"EFT_HESAP_KASA"));
				
				oMap.put(tableName2, i, "ISLEM", iMap.getString(tableName, j,
				"ISLEM"));
				
				oMap.put(tableName2, i, "PTT_TOPLAM_TUTAR",iMap.getString(tableName, j,
				"PTT_TOPLAM_TUTAR"));
				
				oMap.put(tableName2, i, "ISLEM_ADI_PTT",iMap.getString(tableName, j,
				"ISLEM_ADI_PTT"));
				
				oMap.put(tableName2, i, "MASRAF_DOVIZ_KODU",iMap.getString(tableName, j,
				"MASRAF_DOVIZ_KODU"));
				
				oMap.put(tableName2, i, "TFS_ISLEMI",iMap.getString(tableName, j,
						"TFS_ISLEMI"));

				i++;
			}
			
			tableName2 = "CBS_AKTIFBANK_PTT";
		for  ( j = 0; j < oMap.getSize(tableName2); j++) {  // Aktifbank i�lem
															// T�P� null sa
															// demekki banka
															// islemi
				
			// YATAN  ptt
			if ( oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  && oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("Kredi Tahsilati") ==0 ){
				
				
			if ( oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {
					
					
			if(   oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0)  {
				//pft hesaptan ise g�z�n�nde tutulmuyacak...
				if (  oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0 ){
					PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
					PPTYATANADETTRY   = PPTYATANADETTRY.add(new BigDecimal(1));
				}
				if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
					pttbankYT2 = pttbankYT2.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
					PTTYATANADETEUR = PTTYATANADETEUR.add(new BigDecimal(1));
				}
				if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
					pttbankYT3 = pttbankYT3.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
					PTTYATANADETUSD = PTTYATANADETUSD.add(new BigDecimal(1));
				}
				
				
				if (  oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
					MASRAFYATANPTTTRY =  MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
				}
				if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0  ){
					MASRAFYATANPTTEUR = MASRAFYATANPTTEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
				}
				if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0  ){
					MASRAFYATANPTTUSD = MASRAFYATANPTTUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
				}
				
			}
			}
			
			} 
				
				// CEKILEN ptt
				if ( oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  && oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("Kredi Kullandirim") ==0 ){
					
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
						
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
							pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
							PPTCEKILENADETTRY   = PPTCEKILENADETTRY.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
							pttbankCT2 = pttbankCT2.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
							PTTCEKILENADETEUR = PTTCEKILENADETEUR.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
							pttbankCT3 = pttbankCT3.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
							PTTCEKILENADETUSD = PTTCEKILENADETUSD.add(new BigDecimal(1));
						}
						
						
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0  ){
							MASRAFCEKILENPTTTRY =  MASRAFCEKILENPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
						
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0  ){
							MASRAFCEKILENPTTEUR = MASRAFCEKILENPTTEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
						
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0  ){
							MASRAFCEKILENPTTUSD = MASRAFCEKILENPTTUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}						
						
					}
				}
				

				// IPTAL YATAN ptt
				if (  oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  &&  oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  oMap.getString(tableName2, j, "ISLEM").compareTo("Kredi Tahsilati") == 0 ){
					
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
						
						
						if( oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("PTT EFT") !=0 && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  ){
							//pft hesaptan olmayanlar
					
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
								IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
								IPTALPTTYATANADETTRY = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
								IPTALPTTYATANEUR = IPTALPTTYATANEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
								IPTALPTTYATANADETEUR = IPTALPTTYATANADETEUR.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
								IPTALPTTYATANUSD = IPTALPTTYATANUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
								IPTALPTTYATANADETUSD = IPTALPTTYATANADETUSD.add(new BigDecimal(1));
							}
					
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0  ){
								IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}
					
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0  ){
								IPTALMASRAFPTTYATANEUR = IPTALMASRAFPTTYATANEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}
					
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0  ){
								IPTALMASRAFPTTYATANUSD = IPTALMASRAFPTTYATANUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}					
					
					}
					}
				}
				
				// IPTAL CEKILEN ptt
				if ( oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  &&  oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  oMap.getString(tableName2, j, "ISLEM").compareTo("Kredi Kullandirim") == 0 ){
					
					if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
					
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
							IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
							IPTALPTTCEKILENADETTRY  = IPTALPTTCEKILENADETTRY.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
							IPTALPTTCEKILENEUR = IPTALPTTCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
							IPTALPTTCEKILENADETEUR  = IPTALPTTCEKILENADETEUR.add(new BigDecimal(1));
						}
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
							IPTALPTTCEKILENUSD = IPTALPTTCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI") ) ;
							IPTALPTTCEKILENADETUSD  = IPTALPTTCEKILENADETUSD.add(new BigDecimal(1));
						}
					
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0  ){
							IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
					
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0  ){
							IPTALMASRAFPTTCEKILENEUR = IPTALMASRAFPTTCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
					
						if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0  ){
							IPTALMASRAFPTTCEKILENUSD = IPTALMASRAFPTTCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						}
	
					}
				}
				
				// AKTIFBANKISLEMLERI
				if (oMap.getString(tableName2, j, "ISLEM_KOD") != null ){
					

					//AKTIFBANKYATAN
					if (  oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2050)) ==0  ||
							oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(3253)) ==0){
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
							
							if( oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  ){
								//hesaptan eft olmamali
								if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
									AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
									AKTIFBANKYATANADETTRY   = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
								}
								if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
									YATAN_AKT_EUR = YATAN_AKT_EUR.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
									AKTIFBANKYATANADETEUR = AKTIFBANKYATANADETEUR.add(new BigDecimal(1));
								}
								if 	(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
									AKTIFBANKYT3 = AKTIFBANKYT3.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
									AKTIFBANKYATANADETUSD = AKTIFBANKYATANADETUSD.add(new BigDecimal(1));
								}

								if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0  ){
									MASRAFYATANAKTIFBANKTRY =  MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
								}

								if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0  ){
									MASRAFYATANAKTIFBANKEUR = MASRAFYATANAKTIFBANKEUR.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
								}

								if 	(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0  ){
									MASRAFYATANAKTIFBANKUSD = MASRAFYATANAKTIFBANKUSD.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
								}							
								
								
							}    
						}
					}

					//AKTIFBANKCEKILEN
					if (oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2030)) == 0 )  {
						
						
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){

							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
								AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
								AKTIFBANKCEKILENADETTRY   = AKTIFBANKCEKILENADETTRY.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
								AKTIFBANKCT2 = AKTIFBANKCT2.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
								AKTIFBANKCEKILENADETEUR = AKTIFBANKCEKILENADETEUR.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
								AKTIFBANKCT3 = AKTIFBANKCT3.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
								AKTIFBANKCEKILENADETUSD = AKTIFBANKCEKILENADETUSD.add(new BigDecimal(1));
							}
						
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0  ){
								MASRAFCEKILENAKTIFBANKTRY =  MASRAFCEKILENAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
							}	
						
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0  ){
								MASRAFCEKILENAKTIFBANKEUR = MASRAFCEKILENAKTIFBANKEUR.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
							}
						
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0  ){
								MASRAFCEKILENAKTIFBANKUSD = MASRAFCEKILENAKTIFBANKUSD.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
							}						
						}
						
					}
					
	
					//  aktifbank iptal YATAN
					if (  oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  && oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  oMap.getString(tableName2, j, "ISLEM").compareTo("Kredi Tahsilati") == 0 ){
						
						
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
							
						
							if( oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("Kredi Tahsilati") !=0 && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  ){
							//hesaptan eft olmamali
						
								if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){  
									IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"))  ;
									IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));
						
								}
								if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
							
									IPTALAKTIFBANKYATANUSD = IPTALAKTIFBANKYATANUSD.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
									IPTALAKTIFBANKYATANADETUSD = IPTALAKTIFBANKYATANADETUSD.add(new BigDecimal(1));
								}
								if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
									IPTALAKTIFBANKYATANEUR = IPTALAKTIFBANKYATANEUR.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
									IPTALAKTIFBANKYATANADETEUR = IPTALAKTIFBANKYATANADETEUR.add(new BigDecimal(1));
								}
							
							
								if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0  ){  
									IPTALMASRAFAKTIFBANKYATANTRY=IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}

								if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0  ){
									IPTALMASRAFAKTIFBANKYATANUSD=IPTALMASRAFAKTIFBANKYATANUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}							
							
								if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0  ){
									IPTALMASRAFAKTIFBANKYATANEUR=IPTALMASRAFAKTIFBANKYATANEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}							
						}
						
						}
					}
					
					//  aktifbank iptal CEKILEN
					if (  oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  && oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  oMap.getString(tableName2, j, "ISLEM").compareTo("Kredi Kullandirim") == 0 ){
						
						if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
						
						
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
								IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
								IPTALBANKACEKILENADETTRY = IPTALBANKACEKILENADETTRY.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
								IPTALAKTIFBANKCEKILENEUR = IPTALAKTIFBANKCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
								IPTALAKTIFBANKCEKILENADETEUR = IPTALAKTIFBANKCEKILENADETEUR.add(new BigDecimal(1));
							}
							if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
								IPTALAKTIFBANKCEKILENUSD = IPTALAKTIFBANKCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "TUTAR") ) ;
								IPTALBANKACEKILENADETUSD = IPTALBANKACEKILENADETUSD.add(new BigDecimal(1));
							}
							
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0  ){
								IPTALMASRAFAKTIFBANKCEKILENTRY = IPTALMASRAFAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}
							
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0  ){
								IPTALMASRAFAKTIFBANKCEKILENEUR = IPTALMASRAFAKTIFBANKCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}
							
							if (oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0  ){
								IPTALMASRAFAKTIFBANKCEKILENUSD = IPTALMASRAFAKTIFBANKCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
							}							
							
						}
					}
		
				}

		}

		 oMap.put("PTTYT1", PTTYT1)  ;
		 oMap.put("AKTIFBANKYT1", AKTIFBANKYT1)  ;
		 oMap.put("pttbankYT2", pttbankYT2)  ;
		 oMap.put("YATAN_AKT_EUR", YATAN_AKT_EUR)  ;
		 oMap.put("pttbankYT3", pttbankYT3)  ;
		 oMap.put("AKTIFBANKYT3", AKTIFBANKYT3)  ;
		 
		 
		 /*
		 MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(MASRAFYATANPTTEUR).add(MASRAFYATANPTTUSD);
		 MASRAFYATANPTTEUR= new BigDecimal("0");
		 MASRAFYATANPTTUSD= new BigDecimal("0");
		 
		 MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(MASRAFYATANAKTIFBANKEUR).add(MASRAFYATANAKTIFBANKUSD);
		 MASRAFYATANAKTIFBANKEUR= new BigDecimal("0");
		 MASRAFYATANAKTIFBANKUSD= new BigDecimal("0");		 
		 */
		 
		 
		 
		 
		 oMap.put("MASRAFYATANPTTTRY", MASRAFYATANPTTTRY)  ;
		 oMap.put("MASRAFYATANAKTIFBANKTRY", MASRAFYATANAKTIFBANKTRY)  ;
		 oMap.put("MASRAFYATANPTTEUR", MASRAFYATANPTTEUR)  ;
		 oMap.put("MASRAFYATANAKTIFBANKEUR", MASRAFYATANAKTIFBANKEUR)  ;
		 oMap.put("MASRAFYATANPTTUSD", MASRAFYATANPTTUSD)  ;
		 oMap.put("MASRAFYATANAKTIFBANKUSD", MASRAFYATANAKTIFBANKUSD)  ;
		 
		 
		 
		 oMap.put("PPTYATANADETTRY", PPTYATANADETTRY)  ;
		 oMap.put("AKTIFBANKYATANADETTRY", AKTIFBANKYATANADETTRY)  ;
		 oMap.put("PTTYATANADETEUR", PTTYATANADETEUR)  ;
		 oMap.put("AKTIFBANKYATANADETEUR", AKTIFBANKYATANADETEUR)  ;
		 oMap.put("PTTYATANADETUSD", PTTYATANADETUSD)  ;
		 oMap.put("AKTIFBANKYATANADETUSD", AKTIFBANKYATANADETUSD)  ;
		 
		 
		 
		 oMap.put("pttbankCT1", pttbankCT1)  ;
		 oMap.put("AKTIFBANKCT1", AKTIFBANKCT1)  ;
		 oMap.put("pttbankCT2", pttbankCT2)  ;
		 oMap.put("AKTIFBANKCT2", AKTIFBANKCT2)  ;
		 oMap.put("pttbankCT3", pttbankCT3)  ;
		 oMap.put("AKTIFBANKCT3", AKTIFBANKCT3)  ;
		 
		 /*
		 MASRAFCEKILENPTTTRY = MASRAFCEKILENPTTTRY.add(MASRAFCEKILENPTTEUR).add(MASRAFCEKILENPTTUSD);
		 
		 MASRAFCEKILENPTTEUR = new BigDecimal("0");
		 MASRAFCEKILENPTTUSD = new BigDecimal("0");
		 
		 MASRAFCEKILENAKTIFBANKTRY = MASRAFCEKILENAKTIFBANKTRY.add(MASRAFCEKILENAKTIFBANKEUR).add(MASRAFCEKILENAKTIFBANKUSD);
		 MASRAFCEKILENAKTIFBANKEUR = new BigDecimal("0");
		 MASRAFCEKILENAKTIFBANKUSD = new BigDecimal("0");
		 */
 
		 oMap.put("MASRAFCEKILENPTTTRY", MASRAFCEKILENPTTTRY)  ;
		 oMap.put("MASRAFCEKILENAKTIFBANKTRY", MASRAFCEKILENAKTIFBANKTRY)  ;
		 oMap.put("MASRAFCEKILENPTTEUR", MASRAFCEKILENPTTEUR)  ;
		 oMap.put("MASRAFCEKILENAKTIFBANKEUR", MASRAFCEKILENAKTIFBANKEUR)  ;
		 oMap.put("MASRAFCEKILENPTTUSD", MASRAFCEKILENPTTUSD)  ;
		 oMap.put("MASRAFCEKILENAKTIFBANKUSD", MASRAFCEKILENAKTIFBANKUSD)  ;
		 
		 oMap.put("PPTCEKILENADETTRY", PPTCEKILENADETTRY)  ;
		 oMap.put("AKTIFBANKCEKILENADETTRY", AKTIFBANKCEKILENADETTRY)  ;
		 oMap.put("PTTCEKILENADETEUR", PTTCEKILENADETEUR)  ;
		 oMap.put("AKTIFBANKCEKILENADETEUR", AKTIFBANKCEKILENADETEUR)  ;
		 oMap.put("PTTCEKILENADETUSD", PTTCEKILENADETUSD)  ;
		 oMap.put("AKTIFBANKCEKILENADETUSD", AKTIFBANKCEKILENADETUSD)  ;
		 
		 oMap.put("IPTALPTTYATANTRY", IPTALPTTYATANTRY)  ;
		 oMap.put("IPTALAKTIFBANKYATANTRY", IPTALAKTIFBANKYATANTRY)  ;
		 oMap.put("IPTALPTTYATANUSD", IPTALPTTYATANUSD)  ;
		 oMap.put("IPTALAKTIFBANKYATANUSD", IPTALAKTIFBANKYATANUSD)  ;
		 oMap.put("IPTALPTTYATANEUR", IPTALPTTYATANEUR)  ;
		 oMap.put("IPTALAKTIFBANKYATANEUR", IPTALAKTIFBANKYATANEUR)  ;
		 
		 
		 
		 oMap.put("IPTALPTTCEKILENTRY", IPTALPTTCEKILENTRY)  ;
		 oMap.put("IPTALAKTIFBANKCEKILENTRY", IPTALAKTIFBANKCEKILENTRY)  ;
		 oMap.put("IPTALPTTCEKILENEUR", IPTALPTTCEKILENEUR)  ;
		 oMap.put("IPTALAKTIFBANKCEKILENEUR", IPTALAKTIFBANKCEKILENEUR)  ;
		 oMap.put("IPTALPTTCEKILENUSD", IPTALPTTCEKILENUSD)  ;
		 oMap.put("IPTALAKTIFBANKCEKILENUSD", IPTALAKTIFBANKCEKILENUSD)  ;
		 
		BigDecimal PTT_BORC_TL =  new BigDecimal(0);
		
		BigDecimal PTT_BORC_EUR =  new BigDecimal(0);
		
		BigDecimal PTT_BORC_USD =  new BigDecimal(0);
		
		BigDecimal AKTIFBANK_BORC_TL =  new BigDecimal(0);
		
		BigDecimal AKTIFBANK_BORC_EUR =  new BigDecimal(0);
		
		BigDecimal AKTIFBANK_BORC_USD =  new BigDecimal(0);
		
	
		oMap.put("pttbankYT2", pttbankYT2);
		
		
		
	    BigDecimal TOPLAMYATANPTTTRY =   PTTYT1.add(MASRAFYATANPTTTRY);
	    BigDecimal TOPLAMYATANAKTIFBANKTRY = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY);
	    BigDecimal TOPLAMYATANPTTEUR = pttbankYT2.add(MASRAFYATANPTTEUR);
	    BigDecimal TOPLAMYATANAKTIFBANKEUR =  YATAN_AKT_EUR.add(MASRAFYATANAKTIFBANKEUR);
	    BigDecimal TOPLAMYATANPTTUSD = pttbankYT3.add(MASRAFYATANPTTUSD);
	    BigDecimal TOPLAMYATANAKTIFBANKUSD =  AKTIFBANKYT3.add(MASRAFYATANAKTIFBANKUSD);
	    
	    oMap.put("TOPLAMYATANPTTTRY", TOPLAMYATANPTTTRY)  ;
	    oMap.put("TOPLAMYATANAKTIFBANKTRY", TOPLAMYATANAKTIFBANKTRY)  ;
	    oMap.put("TOPLAMYATANPTTEUR", TOPLAMYATANPTTEUR)  ;
	    oMap.put("TOPLAMYATANAKTIFBANKEUR", TOPLAMYATANAKTIFBANKEUR)  ;
	    oMap.put("TOPLAMYATANPTTUSD", TOPLAMYATANPTTUSD)  ;
	    oMap.put("TOPLAMYATANAKTIFBANKUSD", TOPLAMYATANAKTIFBANKUSD)  ;
	    
 
    
	    BigDecimal TOPLAMCEKILENPTTTRY =   pttbankCT1.subtract(MASRAFCEKILENPTTTRY) ; 
	    BigDecimal TOPLAMCEKILENAKTIFBANKTRY =  AKTIFBANKCT1.subtract(MASRAFCEKILENAKTIFBANKTRY)  ;   
	    BigDecimal TOPLAMCEKILENPTTEUR =  pttbankCT2.subtract(MASRAFCEKILENPTTEUR) ; 
	    BigDecimal TOPLAMCEKILENAKTIFBANKEUR =  AKTIFBANKCT2.subtract(MASRAFCEKILENAKTIFBANKEUR)   ; 
	    BigDecimal TOPLAMCEKILENPTTUSD = 		pttbankCT3.subtract(MASRAFCEKILENPTTUSD);
	    BigDecimal TOPLAMCEKILENAKTIFBANKUSD =  AKTIFBANKCT3.subtract(MASRAFCEKILENAKTIFBANKUSD)  ;   
	    
	    oMap.put("TOPLAMCEKILENPTTTRY", TOPLAMCEKILENPTTTRY)  ;
	    oMap.put("TOPLAMCEKILENAKTIFBANKTRY", TOPLAMCEKILENAKTIFBANKTRY)  ;
	    oMap.put("TOPLAMCEKILENPTTEUR", TOPLAMCEKILENPTTEUR)  ;
	    oMap.put("TOPLAMCEKILENAKTIFBANKEUR", TOPLAMCEKILENAKTIFBANKEUR)  ;
	    oMap.put("TOPLAMCEKILENPTTUSD", TOPLAMCEKILENPTTUSD)  ;
	    oMap.put("TOPLAMCEKILENAKTIFBANKUSD", TOPLAMCEKILENAKTIFBANKUSD)  ;
	    
	    
	    IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(IPTALMASRAFPTTYATANUSD).add(IPTALMASRAFPTTYATANEUR);
	    IPTALMASRAFPTTYATANUSD = new BigDecimal(0);
	    IPTALMASRAFPTTYATANEUR = new BigDecimal(0);
	    
	    IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(IPTALMASRAFAKTIFBANKYATANUSD).add(IPTALMASRAFAKTIFBANKYATANEUR);
	    IPTALMASRAFAKTIFBANKYATANUSD = new BigDecimal(0);
	    IPTALMASRAFAKTIFBANKYATANEUR = new BigDecimal(0);
	    
	    
	    oMap.put("IPTALMASRAFPTTYATANTRY", IPTALMASRAFPTTYATANTRY)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKYATANTRY", IPTALMASRAFAKTIFBANKYATANTRY)  ;
	    oMap.put("IPTALMASRAFPTTYATANUSD", IPTALMASRAFPTTYATANUSD)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKYATANUSD", IPTALMASRAFAKTIFBANKYATANUSD)  ;
	    oMap.put("IPTALMASRAFPTTYATANEUR", IPTALMASRAFPTTYATANEUR)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKYATANEUR", IPTALMASRAFAKTIFBANKYATANEUR)  ;
	    
	    
	    IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(IPTALMASRAFPTTCEKILENEUR).add(IPTALMASRAFPTTCEKILENUSD);
	    IPTALMASRAFPTTCEKILENEUR = new BigDecimal(0);
	    IPTALMASRAFPTTCEKILENUSD = new BigDecimal(0); 
	    
	    IPTALMASRAFAKTIFBANKCEKILENTRY = IPTALMASRAFAKTIFBANKCEKILENTRY.add(IPTALMASRAFAKTIFBANKCEKILENEUR).add(IPTALMASRAFAKTIFBANKCEKILENUSD);
	    IPTALMASRAFAKTIFBANKCEKILENEUR = new BigDecimal(0);
	    IPTALMASRAFAKTIFBANKCEKILENUSD = new BigDecimal(0); 	    
	    
	    oMap.put("IPTALMASRAFPTTCEKILENTRY", IPTALMASRAFPTTCEKILENTRY)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKCEKILENTRY", IPTALMASRAFAKTIFBANKCEKILENTRY)  ;
	    oMap.put("IPTALMASRAFPTTCEKILENEUR", IPTALMASRAFPTTCEKILENEUR)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKCEKILENEUR", IPTALMASRAFAKTIFBANKCEKILENEUR)  ;
	    oMap.put("IPTALMASRAFPTTCEKILENUSD", IPTALMASRAFPTTCEKILENUSD)  ;
	    oMap.put("IPTALMASRAFAKTIFBANKCEKILENUSD", IPTALMASRAFAKTIFBANKCEKILENUSD)  ;
	    
	    
	    
	    
	    oMap.put("IPTALPTTYATANADETTRY", IPTALPTTYATANADETTRY)  ;
	    oMap.put("IPTALBANKAYATANADETTRY", IPTALBANKAYATANADETTRY)  ;
	    oMap.put("IPTALPTTYATANADETEUR", IPTALPTTYATANADETEUR)  ;
	    oMap.put("IPTALAKTIFBANKYATANADETEUR", IPTALAKTIFBANKYATANADETEUR)  ;
	    oMap.put("IPTALPTTYATANADETUSD", IPTALPTTYATANADETUSD)  ;
	    oMap.put("IPTALAKTIFBANKYATANADETUSD", IPTALAKTIFBANKYATANADETUSD)  ;
	    
	    
	    oMap.put("IPTALPTTCEKILENADETTRY", IPTALPTTCEKILENADETTRY)  ;
	    oMap.put("IPTALBANKACEKILENADETTRY", IPTALBANKACEKILENADETTRY)  ;
	    oMap.put("IPTALPTTCEKILENADETEUR", IPTALPTTCEKILENADETEUR)  ;
	    oMap.put("IPTALAKTIFBANKCEKILENADETEUR", IPTALAKTIFBANKCEKILENADETEUR)  ;
	    oMap.put("IPTALPTTCEKILENADETUSD", IPTALPTTCEKILENADETUSD)  ;
	    oMap.put("IPTALBANKACEKILENADETUSD", IPTALBANKACEKILENADETUSD)  ;
	    
     
		PTT_BORC_TL = PTTYT1.add(MASRAFYATANPTTTRY).subtract(IPTALPTTYATANTRY).subtract(IPTALMASRAFPTTYATANTRY)
		.add(MASRAFCEKILENPTTTRY).subtract(pttbankCT1).add(IPTALPTTCEKILENTRY).subtract(IPTALMASRAFPTTCEKILENTRY)
		;
		
		PTT_BORC_EUR = pttbankYT2.subtract(IPTALPTTYATANEUR)
		.subtract(pttbankCT2).add(IPTALPTTCEKILENEUR)  ;	
		
		PTT_BORC_USD = pttbankYT3.subtract(IPTALPTTYATANUSD)
		.subtract(pttbankCT3).add(IPTALPTTCEKILENUSD)  ;	

		/*Nakit yatan nakit cekilen ptt -aktifbank tan iptal tutarlari dusuldu  */
		//oMap.put("PTTYT1", PTTYT1.intValue()-(IPTALPTTYATANTRY.intValue()))  ;
		//oMap.put("pttbankYT2", pttbankYT2.intValue()-(IPTALPTTYATANEUR.intValue()))  ;
		//oMap.put("pttbankYT3", pttbankYT3.intValue()-(IPTALPTTYATANUSD.intValue()))  ;
		//oMap.put("AKTIFBANKYT1", AKTIFBANKYT1.intValue() - IPTALAKTIFBANKCEKILENTRY.intValue() )  ;
		//oMap.put("YATAN_AKT_EUR", YATAN_AKT_EUR.intValue() - IPTALAKTIFBANKCEKILENEUR.intValue() )  ;
		//oMap.put("IPTALAKTIFBANKCEKILENUSD", IPTALAKTIFBANKCEKILENUSD.intValue() - IPTALAKTIFBANKCEKILENUSD.intValue() )  ;
		 /******************/
	
		oMap.put("BORC_TL_PTT", PTT_BORC_TL);
		oMap.put("BORC_USD_PTT", PTT_BORC_USD);
		oMap.put("BORC_EUR_PTT", PTT_BORC_EUR);
		
		oMap.put("BORC_TL_BANKA", "0");
		oMap.put("BORC_EUR_BANKA", "0");
		oMap.put("BORC_USD_BANKA", "0");
		
		
		if  (PTT_BORC_TL.intValue() < 0) {
			AKTIFBANK_BORC_TL = PTT_BORC_TL;
			oMap.put("BORC_TL_BANKA", AKTIFBANK_BORC_TL);
			oMap.put("BORC_TL_PTT", "0");
		}
		
		if  (PTT_BORC_EUR.intValue() < 0) {
			AKTIFBANK_BORC_EUR = PTT_BORC_EUR;
			oMap.put("BORC_EUR_BANKA", AKTIFBANK_BORC_EUR);
			oMap.put("BORC_EUR_PTT", "0");
		}
		if  (PTT_BORC_USD.intValue() < 0) {
			AKTIFBANK_BORC_USD = PTT_BORC_USD;
			oMap.put("BORC_USD_BANKA", AKTIFBANK_BORC_USD);
			oMap.put("BORC_USD_PTT", "0");
		}
		
		AKTIFBANK_BORC_TL = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY).subtract(IPTALAKTIFBANKYATANTRY).subtract(IPTALMASRAFAKTIFBANKYATANTRY)
		.add(MASRAFCEKILENAKTIFBANKTRY).subtract(AKTIFBANKCT1).add(IPTALAKTIFBANKCEKILENTRY).subtract(IPTALMASRAFAKTIFBANKCEKILENTRY)
		;
		
		AKTIFBANK_BORC_EUR = YATAN_AKT_EUR.subtract(IPTALAKTIFBANKYATANEUR)
		.subtract(AKTIFBANKCT2).add(IPTALAKTIFBANKCEKILENEUR)  ;	
		
		AKTIFBANK_BORC_USD = AKTIFBANKYT3.subtract(IPTALAKTIFBANKYATANUSD)
		.subtract(AKTIFBANKCT3).add(IPTALAKTIFBANKCEKILENUSD)  ;	

		
		GMMap sMap = new GMMap();
		
		sMap.put("TARIH", iMap.get("TARIH"));
		
		sMap.put("AKTIFBANK_BORC_TL", AKTIFBANK_BORC_TL);
		sMap.put("AKTIFBANK_BORC_EUR", AKTIFBANK_BORC_EUR);
		sMap.put("AKTIFBANK_BORC_USD", AKTIFBANK_BORC_USD);
		
		sMap.put("PTT_BORC_TL", PTT_BORC_TL);
		sMap.put("PTT_BORC_USD", PTT_BORC_USD);
		sMap.put("PTT_BORC_EUR", PTT_BORC_EUR);
		
		
		//GMServiceExecuter.execute("BNSPR_QRY2052_SET_NET_OFF", sMap);	  
		oMap.put("KAYIT_SAYISI","1");
		
		// BU KONTROL BLOGU KALDIRILIRSA MUTABAKATLILARDA LISTELENECEK
		if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("true")==0){
			oMapOnlyMutabakatsiz.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_KREDI", iMap));
			
			oMap.put("KAYIT_SAYISI", oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT"));
			
			if (oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT")>0){
				oMap.putAll(oMapOnlyMutabakatsiz);
			}else{
				oMap.remove("CBS_AKTIFBANK_PTT") ; //SONUC_LIST
			}
			
			//oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR", iMap));
		}
		


		return oMap;
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_ISLEMLER_KREDI")
	public static GMMap Get_Islemler_Kredi(GMMap iMap){
		GMMap oMap = new GMMap();
		
		BigDecimal PTT_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_TRY=new BigDecimal(0);
		
		BigDecimal PTT_ISLEM_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_EUR=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_EUR=new BigDecimal(0);
		
		BigDecimal PTT_ISLEM_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_USD=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_USD=new BigDecimal(0);
		
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		

		try{
			int j=0;
			
			for (int i=0;i<iMap.getSize("ISLEM_LIST");i++){
				
				
				if(iMap.getString("ISLEM_TIPI").compareTo(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"))==0){
					oMap.put("SONUC_LIST", j, "ANAISLEMDURUM", iMap.getString("ISLEM_LIST", i, "ANAISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "EFT_HESAP_KASA", iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA"));
					oMap.put("SONUC_LIST", j, "IPTALISLEMDURUM", iMap.getString("ISLEM_LIST", i, "IPTALISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "ISLEM_KOD", iMap.getString("ISLEM_LIST", i, "ISLEM_KOD"));
					oMap.put("SONUC_LIST", j, "ISLEM_NO_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_NO_PTT"));
					oMap.put("SONUC_LIST", j, "ISLEM_TURU_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF", iMap.getString("ISLEM_LIST", i, "MASRAF"));
					oMap.put("SONUC_LIST", j, "NUMARA", iMap.getString("ISLEM_LIST", i, "NUMARA"));
					oMap.put("SONUC_LIST", j, "PTT_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "PTT_ISLEM_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_MASRAF_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "PTT_TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "PTTISLEMNO", iMap.getString("ISLEM_LIST", i, "PTTISLEMNO"));
					oMap.put("SONUC_LIST", j, "REFERANS", iMap.getString("ISLEM_LIST", i, "REFERANS"));
					oMap.put("SONUC_LIST", j, "TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "TUTAR", iMap.getString("ISLEM_LIST", i, "TUTAR"));
					oMap.put("SONUC_LIST", j, "ISLEM_ADI_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_ADI_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "TFS_ISLEMI", iMap.getString("ISLEM_LIST", i, "TFS_ISLEMI"));
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("TRY")==0){
						
						if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
						
							PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
							PTT_ISLEM_ADET_TRY = PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
						

							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
								PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
						
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
								PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
						
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
								PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}	
						
						
							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
								BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								//BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								BANKA_ISLEM_ADET_TRY = BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
							
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}								
							
							}	
						}
					}		
					
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("USD")==0){
						
						if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
						
						PTT_ISLEM_TOPLAM_USD = PTT_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
						//PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						PTT_ISLEM_ADET_USD = PTT_ISLEM_ADET_USD.add(new BigDecimal("1"));
						
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
							PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
							PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
							PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						
						
						
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							
							BANKA_ISLEM_TOPLAM_USD = BANKA_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
							BANKA_ISLEM_ADET_USD = BANKA_ISLEM_ADET_USD.add(new BigDecimal("1"));
							
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
								BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
								BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
								BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}	
						}	
						
						}
					}		
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("EUR")==0){
						
						if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
						
						PTT_ISLEM_TOPLAM_EUR = PTT_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
						//PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						PTT_ISLEM_ADET_EUR = PTT_ISLEM_ADET_EUR.add(new BigDecimal("1"));
						
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
							PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
							PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
							PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}	
						
						
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							BANKA_ISLEM_TOPLAM_EUR = BANKA_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
							//BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							BANKA_ISLEM_ADET_EUR = BANKA_ISLEM_ADET_EUR.add(new BigDecimal("1"));
							
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
								BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
								BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
								BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}	
							
						}	
						
						}
					}	
					
					
					if(iMap.getString("ISLEM_TIPI").compareTo("IPTAL")==0){
						
						conn = DALUtil.getGMConnection();
						stmt = conn.prepareCall("{ ? = call pkg_tx.Islem_kod(?) }");
						
						stmt.registerOutParameter(1, Types.NUMERIC);
						stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_LIST", i, "NUMARA"));
						
						stmt.execute();
						
						iMap.put("ISLEM_KODU", stmt.getBigDecimal(1));
						
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("TRY")==0   ){
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2050")==0 ||
									iMap.getString("ISLEM_KODU").compareTo("3253")==0)   {
							
								
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
								
								PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
							 	//PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							 	PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
							 	
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}	
							 	
							 	
								
							 	if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
								
								 	BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 	//BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 	BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								 	
								 	
									if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
									if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
									if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}	
								 	
								}	
							
							}
							
							}
							
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2030")==0  ){
								
								
								 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 //PTT_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								 
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									  PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									  PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}	
								 
								 
								
								if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 //BANKA_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										  BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										  BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}	

									 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								}		
							}
						}		
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("USD")==0){
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2050")==0 ||
									iMap.getString("ISLEM_KODU").compareTo("3253")==0 )   {
								
								
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
								
								 PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								 
								 
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									  PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									  PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 
								 
								 
									
								 if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									
									 BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 //BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									 
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										  BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										  BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										} 
									 
								 }	
								
								}
								
						}
								
								
								if ( iMap.getString("ISLEM_KODU").compareTo("2030")==0 ){
									
									
									 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 //PTT_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									 
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										  PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										  PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										} 
									 
									 
									
									if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
										
										 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
										 //BANKA_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
										 
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
											  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											}
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
											  BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											}
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
											  BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											} 
										 
									}		
								}
						}		
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("EUR")==0){
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2050")==0 ||
									iMap.getString("ISLEM_KODU").compareTo("3253")==0)   {
								
								
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
									
								 PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 //PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								 
								 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									 PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									 PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									 PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									} 
								 
								 
								 
									
								if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									
									 BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 // BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									 
									 
									 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										 BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										 BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										 BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										} 

								}	
								
								}
								
								}
								
								if (  iMap.getString("ISLEM_KODU").compareTo("2030")==0 ){
									
									 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 //PTT_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									 
									 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										 PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										 PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										 PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										} 
									 
									 
									
									if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
										
										 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
										 //BANKA_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
										 
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
											 BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											}
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
											 BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											}
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
											 BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
											} 										 
										 
									}	
								}
						}
					}
					j++;	
				}
			}	

			if (iMap.getString("ISLEM_TIPI").compareTo("Kredi Tahsilati") ==0   ){
			
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}
			
			if (iMap.getString("ISLEM_TIPI").compareTo("Kredi Kullandirim") ==0  ){
			
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.subtract(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.subtract(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.subtract(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.subtract(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.subtract(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.subtract(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}
			
			
			if (iMap.getString("ISLEM_TIPI").compareTo("IPTAL") ==0  ){
			
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			
			}
			
			oMap.put("PTT_ISLEM_TOPLAM_TRY", PTT_ISLEM_TOPLAM_TRY);
			oMap.put("PTT_MASRAF_TOPLAM_TRY", PTT_MASRAF_TOPLAM_TRY);
			oMap.put("PTT_GENEL_TOPLAM_TRY", PTT_GENEL_TOPLAM_TRY);
			oMap.put("PTT_ISLEM_ADET_TRY", PTT_ISLEM_ADET_TRY);
			
			oMap.put("BANKA_ISLEM_TOPLAM_TRY", BANKA_ISLEM_TOPLAM_TRY);
			oMap.put("BANKA_MASRAF_TOPLAM_TRY", BANKA_MASRAF_TOPLAM_TRY);
			oMap.put("BANKA_GENEL_TOPLAM_TRY", BANKA_GENEL_TOPLAM_TRY);
			oMap.put("BANKA_ISLEM_ADET_TRY", BANKA_ISLEM_ADET_TRY);	
			
			oMap.put("PTT_ISLEM_TOPLAM_EUR", PTT_ISLEM_TOPLAM_EUR);
			oMap.put("PTT_MASRAF_TOPLAM_EUR", PTT_MASRAF_TOPLAM_EUR);
			oMap.put("PTT_GENEL_TOPLAM_EUR", PTT_GENEL_TOPLAM_EUR);
			oMap.put("PTT_ISLEM_ADET_EUR", PTT_ISLEM_ADET_EUR);
			
			oMap.put("BANKA_ISLEM_TOPLAM_EUR", BANKA_ISLEM_TOPLAM_EUR);
			oMap.put("BANKA_MASRAF_TOPLAM_EUR", BANKA_MASRAF_TOPLAM_EUR);
			oMap.put("BANKA_GENEL_TOPLAM_EUR", BANKA_GENEL_TOPLAM_EUR);
			oMap.put("BANKA_ISLEM_ADET_EUR", BANKA_ISLEM_ADET_EUR);	
			
			oMap.put("PTT_ISLEM_TOPLAM_USD", PTT_ISLEM_TOPLAM_USD);
			oMap.put("PTT_MASRAF_TOPLAM_USD", PTT_MASRAF_TOPLAM_USD);
			oMap.put("PTT_GENEL_TOPLAM_USD", PTT_GENEL_TOPLAM_USD);
			oMap.put("PTT_ISLEM_ADET_USD", PTT_ISLEM_ADET_USD);
			
			oMap.put("BANKA_ISLEM_TOPLAM_USD", BANKA_ISLEM_TOPLAM_USD);
			oMap.put("BANKA_MASRAF_TOPLAM_USD", BANKA_MASRAF_TOPLAM_USD);
			oMap.put("BANKA_GENEL_TOPLAM_USD", BANKA_GENEL_TOPLAM_USD);
			oMap.put("BANKA_ISLEM_ADET_USD", BANKA_ISLEM_ADET_USD);	
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_KREDI")
	public static GMMap getSecondLevelAktifKredi(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.RC_QRY_GET_2nd_LEVEL_AKT_KREDI(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_KREDI")
	public static GMMap getMutabakatsizIslemlerKredi(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.Agreement_Response_Kredi(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			
			//if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("1")==0){
			//	oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
			//}else{
				oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT_MUTABAKATSIZ");
			//}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_KREDI")
	public static GMMap getMutabakatOnlyMutabatsizKredi(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.Agreement_Response_Kredi(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
				
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	
	
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_NC_NY_REF_DATA")
	public static GMMap get_NC_NY_REF_Data(GMMap iMap) {
		GMMap oMap = new GMMap();


		BigDecimal PTTYT1 = new BigDecimal(0);
		BigDecimal AKTIFBANKYT1 = new BigDecimal(0);
		BigDecimal pttbankYT2 = new BigDecimal(0);
		BigDecimal YATAN_AKT_EUR = new BigDecimal(0);
		BigDecimal pttbankYT3 = new BigDecimal(0);
		BigDecimal AKTIFBANKYT3 = new BigDecimal(0);

		BigDecimal MASRAFYATANPTTTRY = new BigDecimal(0);
		BigDecimal MASRAFYATANAKTIFBANKTRY = new BigDecimal(0);
		BigDecimal MASRAFYATANPTTEUR = new BigDecimal(0);
		BigDecimal MASRAFYATANAKTIFBANKEUR = new BigDecimal(0);
		BigDecimal MASRAFYATANPTTUSD = new BigDecimal(0);
		BigDecimal MASRAFYATANAKTIFBANKUSD = new BigDecimal(0);

		BigDecimal PPTYATANADETTRY = new BigDecimal(0);
		BigDecimal AKTIFBANKYATANADETTRY = new BigDecimal(0);
		BigDecimal PTTYATANADETEUR = new BigDecimal(0);
		BigDecimal AKTIFBANKYATANADETEUR = new BigDecimal(0);
		BigDecimal PTTYATANADETUSD = new BigDecimal(0);
		BigDecimal AKTIFBANKYATANADETUSD = new BigDecimal(0);

		BigDecimal pttbankCT1 = new BigDecimal(0);
		BigDecimal AKTIFBANKCT1 = new BigDecimal(0);
		BigDecimal pttbankCT2 = new BigDecimal(0);
		BigDecimal AKTIFBANKCT2 = new BigDecimal(0);
		BigDecimal pttbankCT3 = new BigDecimal(0);
		BigDecimal AKTIFBANKCT3 = new BigDecimal(0);

		BigDecimal MASRAFCEKILENPTTTRY = new BigDecimal(0);
		BigDecimal MASRAFCEKILENAKTIFBANKTRY = new BigDecimal(0);
		BigDecimal MASRAFCEKILENPTTEUR = new BigDecimal(0);
		BigDecimal MASRAFCEKILENAKTIFBANKEUR = new BigDecimal(0);
		BigDecimal MASRAFCEKILENPTTUSD = new BigDecimal(0);
		BigDecimal MASRAFCEKILENAKTIFBANKUSD = new BigDecimal(0);

		BigDecimal PPTCEKILENADETTRY = new BigDecimal(0);
		BigDecimal AKTIFBANKCEKILENADETTRY = new BigDecimal(0);
		BigDecimal PTTCEKILENADETEUR = new BigDecimal(0);
		BigDecimal AKTIFBANKCEKILENADETEUR = new BigDecimal(0);
		BigDecimal PTTCEKILENADETUSD = new BigDecimal(0);
		BigDecimal AKTIFBANKCEKILENADETUSD = new BigDecimal(0);

		BigDecimal IPTALPTTYATANTRY = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANTRY = new BigDecimal(0);
		BigDecimal IPTALPTTYATANUSD = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANUSD = new BigDecimal(0);
		BigDecimal IPTALPTTYATANEUR = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANEUR = new BigDecimal(0);

		BigDecimal IPTALPTTCEKILENTRY = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKCEKILENTRY = new BigDecimal(0);
		BigDecimal IPTALPTTCEKILENEUR = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKCEKILENEUR = new BigDecimal(0);
		BigDecimal IPTALPTTCEKILENUSD = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKCEKILENUSD = new BigDecimal(0);

		BigDecimal IPTALMASRAFPTTYATANTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKYATANTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFPTTYATANUSD = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKYATANUSD = new BigDecimal(0);
		BigDecimal IPTALMASRAFPTTYATANEUR = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKYATANEUR = new BigDecimal(0);

		BigDecimal IPTALMASRAFPTTCEKILENTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKCEKILENTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFPTTCEKILENEUR = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKCEKILENEUR = new BigDecimal(0);
		BigDecimal IPTALMASRAFPTTCEKILENUSD = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKCEKILENUSD = new BigDecimal(0);

		BigDecimal IPTALPTTYATANADETTRY = new BigDecimal(0);
		BigDecimal IPTALBANKAYATANADETTRY = new BigDecimal(0);
		BigDecimal IPTALPTTYATANADETEUR = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANADETEUR = new BigDecimal(0);
		BigDecimal IPTALPTTYATANADETUSD = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANADETUSD = new BigDecimal(0);

		BigDecimal IPTALPTTCEKILENADETTRY = new BigDecimal(0);
		BigDecimal IPTALBANKACEKILENADETTRY = new BigDecimal(0);
		BigDecimal IPTALPTTCEKILENADETEUR = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKCEKILENADETEUR = new BigDecimal(0);
		BigDecimal IPTALPTTCEKILENADETUSD = new BigDecimal(0);
		BigDecimal IPTALBANKACEKILENADETUSD = new BigDecimal(0);
		GMMap oMapOnlyMutabakatsiz = new GMMap();

		try {
			int i = 1;

			oMap.put("CBS_AKTIFBANK_PTT", GMServiceExecuter.execute("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_NC_NY_REF", iMap).get("CBS_AKTIFBANK"));
			String tableName = "CBS_AKTIFBANK_PTT";
			i = oMap.getSize(tableName);
			int j = 0;

			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_NC_NY_REF", iMap));


			String tableName2 = "CBS_AKTIFBANK_PTT";
			tableName = "CBS_AKTIFBANK_PTT_MUTABAKATSIZ";
			
			for (j = 0; j < iMap.getSize(tableName); j++) {
				oMap.put(tableName2, i, "ISLEM_TURU_PTT", iMap.getString(tableName, j, "ISLEM_TURU_PTT"));
				oMap.put(tableName2, i, "PTT_ISLEM_TUTARI", iMap.getString(tableName, j, "PTT_ISLEM_TUTARI"));
				oMap.put(tableName2, i, "PTT_ISLEM_TUTARITL", iMap.getString(tableName, j, "PTT_ISLEM_TUTARITL"));
				oMap.put(tableName2, i, "PTT_MASRAF_TUTARI", iMap.getString(tableName, j, "PTT_MASRAF_TUTARI"));
				oMap.put(tableName2, i, "ISLEM_NO_PTT", iMap.getString(tableName, j, "ISLEM_NO_PTT"));
				oMap.put(tableName2, i, "NUMARA", iMap.getString(tableName, j, "NUMARA")); // ISLEMNOBANKA
				oMap.put(tableName2, i, "PTT_DOVIZ_KODU", iMap.getString(tableName, j, "PTT_DOVIZ_KODU"));
				oMap.put(tableName2, i, "ISLEM", iMap.getString(tableName, j, "ISLEM"));
				oMap.put(tableName2, i, "PTT_TOPLAM_TUTAR", iMap.getString(tableName, j, "PTT_TOPLAM_TUTAR"));
				oMap.put(tableName2, i, "ISLEM_ADI_PTT", iMap.getString(tableName, j, "ISLEM_ADI_PTT"));
				oMap.put(tableName2, i, "MASRAF_DOVIZ_KODU", iMap.getString(tableName, j, "MASRAF_DOVIZ_KODU"));

				i++;
			}
			
			for(j = 0; j < oMap.getSize(tableName2); j++) {

				// Case: PTT Yatan
				if("Nakit Yatirma".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))
					|| "UPT Nakit Yatirma".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {

					if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {

						if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
							PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
							PPTYATANADETTRY = PPTYATANADETTRY.add(new BigDecimal(1));
						} else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0) {
							pttbankYT2 = pttbankYT2.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
							PTTYATANADETEUR = PTTYATANADETEUR.add(new BigDecimal(1));
						} else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0) {
							pttbankYT3 = pttbankYT3.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
							PTTYATANADETUSD = PTTYATANADETUSD.add(new BigDecimal(1));
						}

						if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
							MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j,
								"PTT_MASRAF_TUTARI"));
						} else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0) {
							MASRAFYATANPTTEUR = MASRAFYATANPTTEUR.add(oMap.getBigDecimal(tableName2, j,
								"PTT_MASRAF_TUTARI"));
						} else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0) {
							MASRAFYATANPTTUSD = MASRAFYATANPTTUSD.add(oMap.getBigDecimal(tableName2, j,
								"PTT_MASRAF_TUTARI"));
						}
					}
				}

				// Case: PTT Cekilen
				else if("Nakit Cekme".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))
					|| "UPT Nakit Cekme".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))
					|| "Referansli Odeme".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))
					|| "Iade UPT Odemesi".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {

					if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {

						if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
							pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
							PPTCEKILENADETTRY = PPTCEKILENADETTRY.add(new BigDecimal(1));
						}

						else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0) {
							pttbankCT2 = pttbankCT2.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
							PTTCEKILENADETEUR = PTTCEKILENADETEUR.add(new BigDecimal(1));
						}

						else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0) {
							pttbankCT3 = pttbankCT3.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
							PTTCEKILENADETUSD = PTTCEKILENADETUSD.add(new BigDecimal(1));
						}

						// Case: Odeme islemi ise masraf yansitma
						if(!"Referansli Odeme".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))
							&& !"Iade UPT Odemesi".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {

							if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
								MASRAFCEKILENPTTTRY = MASRAFCEKILENPTTTRY.add(oMap.getBigDecimal(tableName2, j,
									"PTT_MASRAF_TUTARI"));
							}

							else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0) {
								MASRAFCEKILENPTTEUR = MASRAFCEKILENPTTEUR.add(oMap.getBigDecimal(tableName2, j,
									"PTT_MASRAF_TUTARI"));
							}

							else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0) {
								MASRAFCEKILENPTTUSD = MASRAFCEKILENPTTUSD.add(oMap.getBigDecimal(tableName2, j,
									"PTT_MASRAF_TUTARI"));
							}
						}

						// Case: Odeme islemi ise odeme_tutari_tl alanini yansit
						else {
							pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARITL"));
						}

					}
				}

				// Case: PTT Iptal Yatan
				else if("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))
					&& ("Nakit Yatirma".equals(oMap.getString(tableName2, j, "ISLEM")) || "UPT Nakit Yatirma"
						.equals(oMap.getString(tableName2, j, "ISLEM")))) {

					if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {

						if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
							IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j,
								"PTT_ISLEM_TUTARI"));
							IPTALPTTYATANADETTRY = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
						}

						else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0) {
							IPTALPTTYATANEUR = IPTALPTTYATANEUR.add(oMap.getBigDecimal(tableName2, j,
								"PTT_ISLEM_TUTARI"));
							IPTALPTTYATANADETEUR = IPTALPTTYATANADETEUR.add(new BigDecimal(1));
						}

						else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0) {
							IPTALPTTYATANUSD = IPTALPTTYATANUSD.add(oMap.getBigDecimal(tableName2, j,
								"PTT_ISLEM_TUTARI"));
							IPTALPTTYATANADETUSD = IPTALPTTYATANADETUSD.add(new BigDecimal(1));
						}

						if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
							IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j,
								"PTT_MASRAF_TUTARI"));
						}

						else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0) {
							IPTALMASRAFPTTYATANEUR = IPTALMASRAFPTTYATANEUR.add(oMap.getBigDecimal(tableName2, j,
								"PTT_MASRAF_TUTARI"));
						}

						else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0) {
							IPTALMASRAFPTTYATANUSD = IPTALMASRAFPTTYATANUSD.add(oMap.getBigDecimal(tableName2, j,
								"PTT_MASRAF_TUTARI"));
						}
						if("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))
							&& ("UPT Nakit Yatirma".equals(oMap.getString(tableName2, j, "ISLEM")))) {
							if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
								PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
								PPTYATANADETTRY = PPTYATANADETTRY.add(new BigDecimal(1));
							} else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0) {
								pttbankYT2 = pttbankYT2.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
								PTTYATANADETEUR = PTTYATANADETEUR.add(new BigDecimal(1));
							} else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0) {
								pttbankYT3 = pttbankYT3.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
								PTTYATANADETUSD = PTTYATANADETUSD.add(new BigDecimal(1));
							}
						}
					}
				}

				// Case: PTT Iptal Cekilen
				else if("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))
					&& ("Nakit Cekme".equals(oMap.getString(tableName2, j, "ISLEM"))
						|| "UPT Nakit Cekme".equals(oMap.getString(tableName2, j, "ISLEM"))
						|| "Referansli Odeme".equals(oMap.getString(tableName2, j, "ISLEM")) || "Iade UPT Odemesi"
							.equals(oMap.getString(tableName2, j, "ISLEM")))) {

					if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {

						if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
							IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j,
								"PTT_ISLEM_TUTARI"));
							IPTALPTTCEKILENADETTRY = IPTALPTTCEKILENADETTRY.add(new BigDecimal(1));
						}

						else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0) {
							IPTALPTTCEKILENEUR = IPTALPTTCEKILENEUR.add(oMap.getBigDecimal(tableName2, j,
								"PTT_ISLEM_TUTARI"));
							IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j,
								"PTT_ISLEM_TUTARITL"));
							IPTALPTTCEKILENADETEUR = IPTALPTTCEKILENADETEUR.add(new BigDecimal(1));
						}

						else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0) {
							IPTALPTTCEKILENUSD = IPTALPTTCEKILENUSD.add(oMap.getBigDecimal(tableName2, j,
								"PTT_ISLEM_TUTARI"));
							IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j,
								"PTT_ISLEM_TUTARITL"));
							IPTALPTTCEKILENADETUSD = IPTALPTTCEKILENADETUSD.add(new BigDecimal(1));
						}

						// Case: Odeme islemi ise masraf yansitma
						if(!"Referansli Odeme".equals(oMap.getString(tableName2, j, "ISLEM"))
							&& !"Iade UPT Odemesi".equals(oMap.getString(tableName2, j, "ISLEM"))) {

							if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
								IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2,
									j, "PTT_MASRAF_TUTARI"));
							}

							else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0) {
								IPTALMASRAFPTTCEKILENEUR = IPTALMASRAFPTTCEKILENEUR.add(oMap.getBigDecimal(tableName2,
									j, "PTT_MASRAF_TUTARI"));
							}

							else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0) {
								IPTALMASRAFPTTCEKILENUSD = IPTALMASRAFPTTCEKILENUSD.add(oMap.getBigDecimal(tableName2,
									j, "PTT_MASRAF_TUTARI"));
							}
						}

						// Case: Odeme islemi ise odeme_tutari_tl alanini yansit
						else {
							IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j,
								"PTT_ISLEM_TUTARITL"));
						}
						if("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))
							&& ("UPT Nakit Cekme".equals(oMap.getString(tableName2, j, "ISLEM")))) {
							if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
								pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
								PPTCEKILENADETTRY = PPTCEKILENADETTRY.add(new BigDecimal(1));
							}

							else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0) {
								pttbankCT2 = pttbankCT2.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
								PTTCEKILENADETEUR = PTTCEKILENADETEUR.add(new BigDecimal(1));
							}

							else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0) {
								pttbankCT3 = pttbankCT3.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
								PTTCEKILENADETUSD = PTTCEKILENADETUSD.add(new BigDecimal(1));
							}
						}
					}
				}

				// Case: Banka islemleri
				if(oMap.getString(tableName2, j, "ISLEM_KOD") != null) {

					// Case: Banka Yatan
					if(oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2050)) == 0
						|| oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(3554)) == 0) {

						if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {

							if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
								AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
								AKTIFBANKYATANADETTRY = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
							}

							else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0) {
								YATAN_AKT_EUR = YATAN_AKT_EUR.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
								AKTIFBANKYATANADETEUR = AKTIFBANKYATANADETEUR.add(new BigDecimal(1));
							}

							else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0) {
								AKTIFBANKYT3 = AKTIFBANKYT3.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
								AKTIFBANKYATANADETUSD = AKTIFBANKYATANADETUSD.add(new BigDecimal(1));
							}

							if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
								MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j,
									"MASRAF"));
							}

							else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0) {
								MASRAFYATANAKTIFBANKEUR = MASRAFYATANAKTIFBANKEUR.add(oMap.getBigDecimal(tableName2, j,
									"MASRAF"));
							}

							else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0) {
								MASRAFYATANAKTIFBANKUSD = MASRAFYATANAKTIFBANKUSD.add(oMap.getBigDecimal(tableName2, j,
									"MASRAF"));
							}
						}
					}

					// Case: Banka Cekilen
					else if(oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2032)) == 0
						|| oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2051)) == 0
						|| oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(3552)) == 0
						|| oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(3555)) == 0) {

						if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {

							if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
								AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
								AKTIFBANKCEKILENADETTRY = AKTIFBANKCEKILENADETTRY.add(new BigDecimal(1));
							} else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0) {
								AKTIFBANKCT2 = AKTIFBANKCT2.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
								AKTIFBANKCEKILENADETEUR = AKTIFBANKCEKILENADETEUR.add(new BigDecimal(1));
							} else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0) {
								AKTIFBANKCT3 = AKTIFBANKCT3.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
								AKTIFBANKCEKILENADETUSD = AKTIFBANKCEKILENADETUSD.add(new BigDecimal(1));
							}

							// Case: Odeme islemi ise masraf yansitma
							if(!"Referansli Odeme".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))
								&& !"Iade UPT Odemesi".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {

								if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
									MASRAFCEKILENAKTIFBANKTRY = MASRAFCEKILENAKTIFBANKTRY.add(oMap.getBigDecimal(
										tableName2, j, "MASRAF"));
								}

								else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0) {
									MASRAFCEKILENAKTIFBANKEUR = MASRAFCEKILENAKTIFBANKEUR.add(oMap.getBigDecimal(
										tableName2, j, "MASRAF"));
								}

								else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0) {
									MASRAFCEKILENAKTIFBANKUSD = MASRAFCEKILENAKTIFBANKUSD.add(oMap.getBigDecimal(
										tableName2, j, "MASRAF"));
								}
							}

							// Case: Odeme islemi ise odeme_tutari_tl alanini da yansit
							else {
								AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "TUTARTL"));
							}
						}

					}
					// Case: Banka Iptal Yatan
					if("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))
						&& ("Nakit Yatirma".equals(oMap.getString(tableName2, j, "ISLEM")) || "UPT Nakit Yatirma"
							.equals(oMap.getString(tableName2, j, "ISLEM")))) {

						if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {

							if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
								IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j,
									"TUTAR"));
								IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));

							} else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0) {

								IPTALAKTIFBANKYATANUSD = IPTALAKTIFBANKYATANUSD.add(oMap.getBigDecimal(tableName2, j,
									"TUTAR"));
								IPTALAKTIFBANKYATANADETUSD = IPTALAKTIFBANKYATANADETUSD.add(new BigDecimal(1));
							} else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0) {
								IPTALAKTIFBANKYATANEUR = IPTALAKTIFBANKYATANEUR.add(oMap.getBigDecimal(tableName2, j,
									"TUTAR"));
								IPTALAKTIFBANKYATANADETEUR = IPTALAKTIFBANKYATANADETEUR.add(new BigDecimal(1));
							}

							if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
								IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(
									tableName2, j, "PTT_MASRAF_TUTARI"));
							}

							else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0) {
								IPTALMASRAFAKTIFBANKYATANUSD = IPTALMASRAFAKTIFBANKYATANUSD.add(oMap.getBigDecimal(
									tableName2, j, "PTT_MASRAF_TUTARI"));
							}

							else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0) {
								IPTALMASRAFAKTIFBANKYATANEUR = IPTALMASRAFAKTIFBANKYATANEUR.add(oMap.getBigDecimal(
									tableName2, j, "PTT_MASRAF_TUTARI"));
							}
						}
					}

					// Case: Banka Iptal Cekilen
					if("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))
						&& ("Nakit Cekme".equals(oMap.getString(tableName2, j, "ISLEM"))
							|| "UPT Nakit Cekme".equals(oMap.getString(tableName2, j, "ISLEM"))
							|| "Referansli Odeme".equals(oMap.getString(tableName2, j, "ISLEM")) || "Iade UPT Odemesi"
								.equals(oMap.getString(tableName2, j, "ISLEM")))) {

						if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null) {

							if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0) {
								IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2,
									j, "TUTAR"));
								IPTALBANKACEKILENADETTRY = IPTALBANKACEKILENADETTRY.add(new BigDecimal(1));
							}

							else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0) {
								IPTALAKTIFBANKCEKILENEUR = IPTALAKTIFBANKCEKILENEUR.add(oMap.getBigDecimal(tableName2,
									j, "TUTAR"));
								IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2,
									j, "TUTARTL"));
								IPTALAKTIFBANKCEKILENADETEUR = IPTALAKTIFBANKCEKILENADETEUR.add(new BigDecimal(1));
							}

							else if(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0) {
								IPTALAKTIFBANKCEKILENUSD = IPTALAKTIFBANKCEKILENUSD.add(oMap.getBigDecimal(tableName2,
									j, "TUTAR"));
								IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2,
									j, "TUTARTL"));
								IPTALBANKACEKILENADETUSD = IPTALBANKACEKILENADETUSD.add(new BigDecimal(1));
							}

							// Case: Odeme islemi ise masraf yansitma
							if(!"Referansli Odeme".equals(oMap.getString(tableName2, j, "ISLEM"))
								&& !"Iade UPT Odemesi".equals(oMap.getString(tableName2, j, "ISLEM"))) {

								if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
									IPTALMASRAFAKTIFBANKCEKILENTRY = IPTALMASRAFAKTIFBANKCEKILENTRY.add(oMap
										.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}

								else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0) {
									IPTALMASRAFAKTIFBANKCEKILENEUR = IPTALMASRAFAKTIFBANKCEKILENEUR.add(oMap
										.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}

								else if(oMap.getString(tableName2, j, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0) {
									IPTALMASRAFAKTIFBANKCEKILENUSD = IPTALMASRAFAKTIFBANKCEKILENUSD.add(oMap
										.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
								}
							}

							// Case: Odeme islemi ise odeme_tutari_tl alanini yansit
							else {
								IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2,
									j, "TUTARTL"));
							}
						}
					}

				}

			}
			

			oMap.put("PTTYT1", PTTYT1);
			oMap.put("AKTIFBANKYT1", AKTIFBANKYT1);
			oMap.put("pttbankYT2", pttbankYT2);
			oMap.put("YATAN_AKT_EUR", YATAN_AKT_EUR);
			oMap.put("pttbankYT3", pttbankYT3);
			oMap.put("AKTIFBANKYT3", AKTIFBANKYT3);

			oMap.put("MASRAFYATANPTTTRY", MASRAFYATANPTTTRY);
			oMap.put("MASRAFYATANAKTIFBANKTRY", MASRAFYATANAKTIFBANKTRY);
			oMap.put("MASRAFYATANPTTEUR", MASRAFYATANPTTEUR);
			oMap.put("MASRAFYATANAKTIFBANKEUR", MASRAFYATANAKTIFBANKEUR);
			oMap.put("MASRAFYATANPTTUSD", MASRAFYATANPTTUSD);
			oMap.put("MASRAFYATANAKTIFBANKUSD", MASRAFYATANAKTIFBANKUSD);

			oMap.put("PPTYATANADETTRY", PPTYATANADETTRY);
			oMap.put("AKTIFBANKYATANADETTRY", AKTIFBANKYATANADETTRY);
			oMap.put("PTTYATANADETEUR", PTTYATANADETEUR);
			oMap.put("AKTIFBANKYATANADETEUR", AKTIFBANKYATANADETEUR);
			oMap.put("PTTYATANADETUSD", PTTYATANADETUSD);
			oMap.put("AKTIFBANKYATANADETUSD", AKTIFBANKYATANADETUSD);

			oMap.put("pttbankCT1", pttbankCT1);
			oMap.put("AKTIFBANKCT1", AKTIFBANKCT1);
			oMap.put("pttbankCT2", pttbankCT2);
			oMap.put("AKTIFBANKCT2", AKTIFBANKCT2);
			oMap.put("pttbankCT3", pttbankCT3);
			oMap.put("AKTIFBANKCT3", AKTIFBANKCT3);

			oMap.put("MASRAFCEKILENPTTTRY", MASRAFCEKILENPTTTRY);
			oMap.put("MASRAFCEKILENAKTIFBANKTRY", MASRAFCEKILENAKTIFBANKTRY);
			oMap.put("MASRAFCEKILENPTTEUR", MASRAFCEKILENPTTEUR);
			oMap.put("MASRAFCEKILENAKTIFBANKEUR", MASRAFCEKILENAKTIFBANKEUR);
			oMap.put("MASRAFCEKILENPTTUSD", MASRAFCEKILENPTTUSD);
			oMap.put("MASRAFCEKILENAKTIFBANKUSD", MASRAFCEKILENAKTIFBANKUSD);

			oMap.put("PPTCEKILENADETTRY", PPTCEKILENADETTRY);
			oMap.put("AKTIFBANKCEKILENADETTRY", AKTIFBANKCEKILENADETTRY);
			oMap.put("PTTCEKILENADETEUR", PTTCEKILENADETEUR);
			oMap.put("AKTIFBANKCEKILENADETEUR", AKTIFBANKCEKILENADETEUR);
			oMap.put("PTTCEKILENADETUSD", PTTCEKILENADETUSD);
			oMap.put("AKTIFBANKCEKILENADETUSD", AKTIFBANKCEKILENADETUSD);

			oMap.put("IPTALPTTYATANTRY", IPTALPTTYATANTRY);
			oMap.put("IPTALAKTIFBANKYATANTRY", IPTALAKTIFBANKYATANTRY);
			oMap.put("IPTALPTTYATANUSD", IPTALPTTYATANUSD);
			oMap.put("IPTALAKTIFBANKYATANUSD", IPTALAKTIFBANKYATANUSD);
			oMap.put("IPTALPTTYATANEUR", IPTALPTTYATANEUR);
			oMap.put("IPTALAKTIFBANKYATANEUR", IPTALAKTIFBANKYATANEUR);

			oMap.put("IPTALPTTCEKILENTRY", IPTALPTTCEKILENTRY);
			oMap.put("IPTALAKTIFBANKCEKILENTRY", IPTALAKTIFBANKCEKILENTRY);
			oMap.put("IPTALPTTCEKILENEUR", IPTALPTTCEKILENEUR);
			oMap.put("IPTALAKTIFBANKCEKILENEUR", IPTALAKTIFBANKCEKILENEUR);
			oMap.put("IPTALPTTCEKILENUSD", IPTALPTTCEKILENUSD);
			oMap.put("IPTALAKTIFBANKCEKILENUSD", IPTALAKTIFBANKCEKILENUSD);

			BigDecimal PTT_BORC_TL = new BigDecimal(0);
			BigDecimal PTT_BORC_EUR = new BigDecimal(0);
			BigDecimal PTT_BORC_USD = new BigDecimal(0);

			BigDecimal AKTIFBANK_BORC_TL = new BigDecimal(0);
			BigDecimal AKTIFBANK_BORC_EUR = new BigDecimal(0);
			BigDecimal AKTIFBANK_BORC_USD = new BigDecimal(0);

			oMap.put("pttbankYT2", pttbankYT2);

			BigDecimal TOPLAMYATANPTTTRY = PTTYT1.add(MASRAFYATANPTTTRY);
			BigDecimal TOPLAMYATANAKTIFBANKTRY = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY);
			BigDecimal TOPLAMYATANPTTEUR = pttbankYT2.add(MASRAFYATANPTTEUR);
			BigDecimal TOPLAMYATANAKTIFBANKEUR = YATAN_AKT_EUR.add(MASRAFYATANAKTIFBANKEUR);
			BigDecimal TOPLAMYATANPTTUSD = pttbankYT3.add(MASRAFYATANPTTUSD);
			BigDecimal TOPLAMYATANAKTIFBANKUSD = AKTIFBANKYT3.add(MASRAFYATANAKTIFBANKUSD);

			oMap.put("TOPLAMYATANPTTTRY", TOPLAMYATANPTTTRY);
			oMap.put("TOPLAMYATANAKTIFBANKTRY", TOPLAMYATANAKTIFBANKTRY);
			oMap.put("TOPLAMYATANPTTEUR", TOPLAMYATANPTTEUR);
			oMap.put("TOPLAMYATANAKTIFBANKEUR", TOPLAMYATANAKTIFBANKEUR);
			oMap.put("TOPLAMYATANPTTUSD", TOPLAMYATANPTTUSD);
			oMap.put("TOPLAMYATANAKTIFBANKUSD", TOPLAMYATANAKTIFBANKUSD);

			BigDecimal TOPLAMCEKILENPTTTRY = pttbankCT1.subtract(MASRAFCEKILENPTTTRY);
			BigDecimal TOPLAMCEKILENAKTIFBANKTRY = AKTIFBANKCT1.subtract(MASRAFCEKILENAKTIFBANKTRY);
			BigDecimal TOPLAMCEKILENPTTEUR = pttbankCT2.subtract(MASRAFCEKILENPTTEUR);
			BigDecimal TOPLAMCEKILENAKTIFBANKEUR = AKTIFBANKCT2.subtract(MASRAFCEKILENAKTIFBANKEUR);
			BigDecimal TOPLAMCEKILENPTTUSD = pttbankCT3.subtract(MASRAFCEKILENPTTUSD);
			BigDecimal TOPLAMCEKILENAKTIFBANKUSD = AKTIFBANKCT3.subtract(MASRAFCEKILENAKTIFBANKUSD);

			oMap.put("TOPLAMCEKILENPTTTRY", TOPLAMCEKILENPTTTRY);
			oMap.put("TOPLAMCEKILENAKTIFBANKTRY", TOPLAMCEKILENAKTIFBANKTRY);
			oMap.put("TOPLAMCEKILENPTTEUR", TOPLAMCEKILENPTTEUR);
			oMap.put("TOPLAMCEKILENAKTIFBANKEUR", TOPLAMCEKILENAKTIFBANKEUR);
			oMap.put("TOPLAMCEKILENPTTUSD", TOPLAMCEKILENPTTUSD);
			oMap.put("TOPLAMCEKILENAKTIFBANKUSD", TOPLAMCEKILENAKTIFBANKUSD);

			IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(IPTALMASRAFPTTYATANUSD).add(IPTALMASRAFPTTYATANEUR);
			IPTALMASRAFPTTYATANUSD = new BigDecimal(0);
			IPTALMASRAFPTTYATANEUR = new BigDecimal(0);

			IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(IPTALMASRAFAKTIFBANKYATANUSD).add(IPTALMASRAFAKTIFBANKYATANEUR);
			IPTALMASRAFAKTIFBANKYATANUSD = new BigDecimal(0);
			IPTALMASRAFAKTIFBANKYATANEUR = new BigDecimal(0);

			oMap.put("IPTALMASRAFPTTYATANTRY", IPTALMASRAFPTTYATANTRY);
			oMap.put("IPTALMASRAFAKTIFBANKYATANTRY", IPTALMASRAFAKTIFBANKYATANTRY);
			oMap.put("IPTALMASRAFPTTYATANUSD", IPTALMASRAFPTTYATANUSD);
			oMap.put("IPTALMASRAFAKTIFBANKYATANUSD", IPTALMASRAFAKTIFBANKYATANUSD);
			oMap.put("IPTALMASRAFPTTYATANEUR", IPTALMASRAFPTTYATANEUR);
			oMap.put("IPTALMASRAFAKTIFBANKYATANEUR", IPTALMASRAFAKTIFBANKYATANEUR);

			IPTALMASRAFPTTCEKILENTRY = IPTALMASRAFPTTCEKILENTRY.add(IPTALMASRAFPTTCEKILENEUR).add(IPTALMASRAFPTTCEKILENUSD);
			IPTALMASRAFPTTCEKILENEUR = new BigDecimal(0);
			IPTALMASRAFPTTCEKILENUSD = new BigDecimal(0);

			IPTALMASRAFAKTIFBANKCEKILENTRY = IPTALMASRAFAKTIFBANKCEKILENTRY.add(IPTALMASRAFAKTIFBANKCEKILENEUR).add(IPTALMASRAFAKTIFBANKCEKILENUSD);
			IPTALMASRAFAKTIFBANKCEKILENEUR = new BigDecimal(0);
			IPTALMASRAFAKTIFBANKCEKILENUSD = new BigDecimal(0);

			oMap.put("IPTALMASRAFPTTCEKILENTRY", IPTALMASRAFPTTCEKILENTRY);
			oMap.put("IPTALMASRAFAKTIFBANKCEKILENTRY", IPTALMASRAFAKTIFBANKCEKILENTRY);
			oMap.put("IPTALMASRAFPTTCEKILENEUR", IPTALMASRAFPTTCEKILENEUR);
			oMap.put("IPTALMASRAFAKTIFBANKCEKILENEUR", IPTALMASRAFAKTIFBANKCEKILENEUR);
			oMap.put("IPTALMASRAFPTTCEKILENUSD", IPTALMASRAFPTTCEKILENUSD);
			oMap.put("IPTALMASRAFAKTIFBANKCEKILENUSD", IPTALMASRAFAKTIFBANKCEKILENUSD);

			oMap.put("IPTALPTTYATANADETTRY", IPTALPTTYATANADETTRY);
			oMap.put("IPTALBANKAYATANADETTRY", IPTALBANKAYATANADETTRY);
			oMap.put("IPTALPTTYATANADETEUR", IPTALPTTYATANADETEUR);
			oMap.put("IPTALAKTIFBANKYATANADETEUR", IPTALAKTIFBANKYATANADETEUR);
			oMap.put("IPTALPTTYATANADETUSD", IPTALPTTYATANADETUSD);
			oMap.put("IPTALAKTIFBANKYATANADETUSD", IPTALAKTIFBANKYATANADETUSD);

			oMap.put("IPTALPTTCEKILENADETTRY", IPTALPTTCEKILENADETTRY);
			oMap.put("IPTALBANKACEKILENADETTRY", IPTALBANKACEKILENADETTRY);
			oMap.put("IPTALPTTCEKILENADETEUR", IPTALPTTCEKILENADETEUR);
			oMap.put("IPTALAKTIFBANKCEKILENADETEUR", IPTALAKTIFBANKCEKILENADETEUR);
			oMap.put("IPTALPTTCEKILENADETUSD", IPTALPTTCEKILENADETUSD);
			oMap.put("IPTALBANKACEKILENADETUSD", IPTALBANKACEKILENADETUSD);

			PTT_BORC_TL = PTTYT1.add(MASRAFYATANPTTTRY).subtract(IPTALPTTYATANTRY).subtract(IPTALMASRAFPTTYATANTRY).add(MASRAFCEKILENPTTTRY).subtract(pttbankCT1).add(IPTALPTTCEKILENTRY).subtract(IPTALMASRAFPTTCEKILENTRY);
			PTT_BORC_EUR = pttbankYT2.subtract(IPTALPTTYATANEUR).subtract(pttbankCT2).add(IPTALPTTCEKILENEUR);
			PTT_BORC_USD = pttbankYT3.subtract(IPTALPTTYATANUSD).subtract(pttbankCT3).add(IPTALPTTCEKILENUSD);

			
			/******************/

			oMap.put("BORC_TL_PTT", PTT_BORC_TL);
			oMap.put("BORC_USD_PTT", PTT_BORC_USD);
			oMap.put("BORC_EUR_PTT", PTT_BORC_EUR);

			oMap.put("BORC_TL_BANKA", "0");
			oMap.put("BORC_EUR_BANKA", "0");
			oMap.put("BORC_USD_BANKA", "0");

			BigDecimal katSayi = new BigDecimal(-1);/*PY-431 deki talep icin eklendi*/

			if (PTT_BORC_TL.intValue() < 0) {
				AKTIFBANK_BORC_TL = PTT_BORC_TL;
				oMap.put("BORC_TL_BANKA", AKTIFBANK_BORC_TL.multiply(katSayi));
				oMap.put("BORC_TL_PTT", "0");
			}

			if (PTT_BORC_EUR.intValue() < 0) {
				AKTIFBANK_BORC_EUR = PTT_BORC_EUR;
				oMap.put("BORC_EUR_BANKA", AKTIFBANK_BORC_EUR.multiply(katSayi));
				oMap.put("BORC_EUR_PTT", "0");
			}
			if (PTT_BORC_USD.intValue() < 0) {
				AKTIFBANK_BORC_USD = PTT_BORC_USD;
				oMap.put("BORC_USD_BANKA", AKTIFBANK_BORC_USD.multiply(katSayi));
				oMap.put("BORC_USD_PTT", "0");
			}

			AKTIFBANK_BORC_TL = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY).subtract(IPTALAKTIFBANKYATANTRY).subtract(IPTALMASRAFAKTIFBANKYATANTRY).add(MASRAFCEKILENAKTIFBANKTRY).subtract(AKTIFBANKCT1).add(IPTALAKTIFBANKCEKILENTRY).subtract(IPTALMASRAFAKTIFBANKCEKILENTRY);
			AKTIFBANK_BORC_EUR = YATAN_AKT_EUR.subtract(IPTALAKTIFBANKYATANEUR).subtract(AKTIFBANKCT2).add(IPTALAKTIFBANKCEKILENEUR);
			AKTIFBANK_BORC_USD = AKTIFBANKYT3.subtract(IPTALAKTIFBANKYATANUSD).subtract(AKTIFBANKCT3).add(IPTALAKTIFBANKCEKILENUSD);

			GMMap sMap = new GMMap();

			sMap.put("TARIH", iMap.get("TARIH"));

			sMap.put("AKTIFBANK_BORC_TL", AKTIFBANK_BORC_TL);
			sMap.put("AKTIFBANK_BORC_EUR", AKTIFBANK_BORC_EUR);
			sMap.put("AKTIFBANK_BORC_USD", AKTIFBANK_BORC_USD);

			sMap.put("PTT_BORC_TL", PTT_BORC_TL);
			sMap.put("PTT_BORC_USD", PTT_BORC_USD);
			sMap.put("PTT_BORC_EUR", PTT_BORC_EUR);
			oMap.put("KAYIT_SAYISI", "1");

			// BU KONTROL BLOGU KALDIRILIRSA MUTABAKATLILARDA LISTELENECEK
			if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("true") == 0) {
				oMapOnlyMutabakatsiz.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_NC_NY_REF", iMap));

				oMap.put("KAYIT_SAYISI", oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT"));

				if (oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT") > 0) {
					oMap.putAll(oMapOnlyMutabakatsiz);
				}
				else {
					oMap.remove("CBS_AKTIFBANK_PTT"); // SONUC_LIST
				}
			}

		}
		catch (Exception e) {
			logger.error(" err: " + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_ISLEMLER_NC_NY_REF")
	public static GMMap Get_Islemler_NC_NY_REF(GMMap iMap){
		GMMap oMap = new GMMap();
		
		BigDecimal PTT_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_TRY=new BigDecimal(0);
		
		BigDecimal PTT_ISLEM_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_EUR=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_EUR=new BigDecimal(0);
		
		BigDecimal PTT_ISLEM_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_USD=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_USD=new BigDecimal(0);
		
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		

		try{
			int j=0;
			
			for (int i=0;i<iMap.getSize("ISLEM_LIST");i++){
				
				if(iMap.getString("ISLEM_TIPI").compareTo(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"))==0 &&  
						"Referansli Odeme".equals(iMap.getString("ISLEM_LIST", i, "ISLEM"))){
					oMap.put("SONUC_LIST", j, "ANAISLEMDURUM", iMap.getString("ISLEM_LIST", i, "ANAISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "EFT_HESAP_KASA", iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA"));
					oMap.put("SONUC_LIST", j, "IPTALISLEMDURUM", iMap.getString("ISLEM_LIST", i, "IPTALISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "ISLEM_KOD", iMap.getString("ISLEM_LIST", i, "ISLEM_KOD"));
					oMap.put("SONUC_LIST", j, "ISLEM_NO_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_NO_PTT"));
					oMap.put("SONUC_LIST", j, "ISLEM_TURU_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF", iMap.getString("ISLEM_LIST", i, "MASRAF"));
					oMap.put("SONUC_LIST", j, "NUMARA", iMap.getString("ISLEM_LIST", i, "NUMARA"));
					oMap.put("SONUC_LIST", j, "PTT_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "PTT_ISLEM_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_ISLEM_TUTARITL", iMap.getString("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));
					oMap.put("SONUC_LIST", j, "PTT_MASRAF_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "PTT_TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "PTTISLEMNO", iMap.getString("ISLEM_LIST", i, "PTTISLEMNO"));
					oMap.put("SONUC_LIST", j, "REFERANS", iMap.getString("ISLEM_LIST", i, "REFERANS"));
					oMap.put("SONUC_LIST", j, "TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "TUTAR", iMap.getString("ISLEM_LIST", i, "TUTAR"));
					oMap.put("SONUC_LIST", j, "TUTARTL", iMap.getString("ISLEM_LIST", i, "TUTARTL"));
					oMap.put("SONUC_LIST", j, "ISLEM_ADI_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_ADI_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"));
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("TRY")==0){
						
						PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));
						PTT_ISLEM_ADET_TRY = PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
						
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTARTL"));	
							BANKA_ISLEM_ADET_TRY = BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
						}
					}
					
					else if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("USD")==0){
						
						PTT_ISLEM_TOPLAM_USD = PTT_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
						PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));
						PTT_ISLEM_ADET_USD = PTT_ISLEM_ADET_USD.add(new BigDecimal("1"));
						
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							
							BANKA_ISLEM_TOPLAM_USD = BANKA_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));
							BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTARTL"));
							BANKA_ISLEM_ADET_USD = BANKA_ISLEM_ADET_USD.add(new BigDecimal("1"));
						}
					}		
					
					else if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("EUR")==0){
						
						
						PTT_ISLEM_TOPLAM_EUR = PTT_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
						PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));
						PTT_ISLEM_ADET_EUR = PTT_ISLEM_ADET_EUR.add(new BigDecimal("1"));
						
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							BANKA_ISLEM_TOPLAM_EUR = BANKA_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));
							BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTARTL"));
							BANKA_ISLEM_ADET_EUR = BANKA_ISLEM_ADET_EUR.add(new BigDecimal("1"));
						}
					}	
					j++;
				}
				else if(iMap.getString("ISLEM_TIPI").compareTo(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"))==0){
					oMap.put("SONUC_LIST", j, "ANAISLEMDURUM", iMap.getString("ISLEM_LIST", i, "ANAISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "EFT_HESAP_KASA", iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA"));
					oMap.put("SONUC_LIST", j, "IPTALISLEMDURUM", iMap.getString("ISLEM_LIST", i, "IPTALISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "ISLEM_KOD", iMap.getString("ISLEM_LIST", i, "ISLEM_KOD"));
					oMap.put("SONUC_LIST", j, "ISLEM_NO_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_NO_PTT"));
					oMap.put("SONUC_LIST", j, "ISLEM_TURU_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF", iMap.getString("ISLEM_LIST", i, "MASRAF"));
					oMap.put("SONUC_LIST", j, "NUMARA", iMap.getString("ISLEM_LIST", i, "NUMARA"));
					oMap.put("SONUC_LIST", j, "PTT_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "PTT_ISLEM_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_ISLEM_TUTARITL", iMap.getString("ISLEM_LIST", i, "PTT_ISLEM_TUTARITL"));
					oMap.put("SONUC_LIST", j, "PTT_MASRAF_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "PTT_TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "PTTISLEMNO", iMap.getString("ISLEM_LIST", i, "PTTISLEMNO"));
					oMap.put("SONUC_LIST", j, "REFERANS", iMap.getString("ISLEM_LIST", i, "REFERANS"));
					oMap.put("SONUC_LIST", j, "TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "TUTAR", iMap.getString("ISLEM_LIST", i, "TUTAR"));
					oMap.put("SONUC_LIST", j, "TUTARTL", iMap.getString("ISLEM_LIST", i, "TUTARTL"));
					oMap.put("SONUC_LIST", j, "ISLEM_ADI_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_ADI_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"));
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("TRY")==0){
						
						
						
							PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
							PTT_ISLEM_ADET_TRY = PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
						

							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
								PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
						
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
								PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}
						
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
								PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}	
						
						
							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
								BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));	
								BANKA_ISLEM_ADET_TRY = BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
							
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
								}
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
								}
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
								}								
							
							}	
					}		
					
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("USD")==0){
						
						
						
						PTT_ISLEM_TOPLAM_USD = PTT_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
						PTT_ISLEM_ADET_USD = PTT_ISLEM_ADET_USD.add(new BigDecimal("1"));
						
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
							PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
							PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
							PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						
						
						
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							
							BANKA_ISLEM_TOPLAM_USD = BANKA_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));
							BANKA_ISLEM_ADET_USD = BANKA_ISLEM_ADET_USD.add(new BigDecimal("1"));
							
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
								BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
							}
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
								BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
							}
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
								BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
							}	
							
						
						}
					}		
					
					if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("EUR")==0){
						
						
						PTT_ISLEM_TOPLAM_EUR = PTT_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
						PTT_ISLEM_ADET_EUR = PTT_ISLEM_ADET_EUR.add(new BigDecimal("1"));
						
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
							PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
							PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
						if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
							PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}	
						
						
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							BANKA_ISLEM_TOPLAM_EUR = BANKA_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));	
							BANKA_ISLEM_ADET_EUR = BANKA_ISLEM_ADET_EUR.add(new BigDecimal("1"));
							
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
								BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
							}
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
								BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
							}
							if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
								BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
							}		
						
						}
					}	
					
					if(iMap.getString("ISLEM_TIPI").compareTo("IPTAL")==0){
						
						conn = DALUtil.getGMConnection();
						stmt = conn.prepareCall("{ ? = call pkg_tx.Islem_kod(?) }");
						
						stmt.registerOutParameter(1, Types.NUMERIC);
						stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_LIST", i, "NUMARA"));
						
						stmt.execute();
						
						iMap.put("ISLEM_KODU", stmt.getBigDecimal(1));
						
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("TRY")==0   ){
							
							if (iMap.getString("ISLEM_KODU").compareTo("2050")==0 || iMap.getString("ISLEM_KODU").compareTo("2062")==0
									|| iMap.getString("ISLEM_KODU").compareTo("3253")==0 || iMap.getString("ISLEM_KODU").compareTo("3554")==0
									|| iMap.getString("ISLEM_KODU").compareTo("3555")==0 ){
							
								
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
								
								PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
							 	PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
							 	
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}
								if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								}	
							 	
							 	
								
							 	if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
								
								 	BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));	
								 	BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								 	
								 	
									if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
									}
									if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
									}
									if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
									}	
								}	
							}
							
							}
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2051")==0 || 
							     iMap.getString("ISLEM_KODU").compareTo("2032")==0 ||
							     iMap.getString("ISLEM_KODU").compareTo("2063")==0 ||
							     iMap.getString("ISLEM_KODU").compareTo("3552")==0||
							     iMap.getString("ISLEM_KODU").compareTo("3554")==0||
							     iMap.getString("ISLEM_KODU").compareTo("3555")==0 )
							     {
								
								 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								 
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									  PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									  PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}	
								 
								
								if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));	
									 
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										  BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										  BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
										}	

									 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								}		
							}
						}		
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("USD")==0){
							
							if (iMap.getString("ISLEM_KODU").compareTo("2050")==0 || iMap.getString("ISLEM_KODU").compareTo("2062")==0
						     || iMap.getString("ISLEM_KODU").compareTo("3253")==0 || iMap.getString("ISLEM_KODU").compareTo("3554")==0 
						     || iMap.getString("ISLEM_KODU").compareTo("3555")==0)   {
								
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
								
								 PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								 
								 
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									  PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									  PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 
								 if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
									
									 BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));	
									 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									 
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
                                        }
                                    }
                                }
                            }
								
					if ( iMap.getString("ISLEM_KODU").compareTo("2051")==0 || iMap.getString("ISLEM_KODU").compareTo("2032")==0
						 || iMap.getString("ISLEM_KODU").compareTo("2063")==0 || iMap.getString("ISLEM_KODU").compareTo("3552")==0
						 || iMap.getString("ISLEM_KODU").compareTo("3554")==0 || iMap.getString("ISLEM_KODU").compareTo("3555")==0){
									
									 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
									 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
									 
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
										  PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
										  PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										}
									  if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
										  PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
										} 
									
									if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
										
										 BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));	
										 BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
										 
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
											  BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
											}
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
											  BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
											}
										 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
											  BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
                                    }
                                }
                            }
                        }
						
						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("EUR")==0){
							
							if ( iMap.getString("ISLEM_KODU").compareTo("2050")==0 || iMap.getString("ISLEM_KODU").compareTo("2062")==0 
							  || iMap.getString("ISLEM_KODU").compareTo("3253")==0 || iMap.getString("ISLEM_KODU").compareTo("3554")==0 
							  || iMap.getString("ISLEM_KODU").compareTo("3555")==0)   {
								
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
									
								 PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								 
								 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									 PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									 PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									 PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									} 
								 
                                    if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null) {

                                        BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));
                                        BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));

                                        if (iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
                                            BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
                                        }
                                        if (iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0) {
                                            BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
                                        }
                                        if (iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0) {
                                            BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
                                        }
                                    }
                                }
                            }
								
							if (  iMap.getString("ISLEM_KODU").compareTo("2032")==0 || iMap.getString("ISLEM_KODU").compareTo("2051")==0
							   || iMap.getString("ISLEM_KODU").compareTo("2063")==0 || iMap.getString("ISLEM_KODU").compareTo("3552")==0
							   || iMap.getString("ISLEM_KODU").compareTo("3554")==0 || iMap.getString("ISLEM_KODU").compareTo("3555")==0){
								
								 PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
								 //PTT_MASRAF_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
								 PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								 
								 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0 ){
									 PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0 ){
									 PTT_MASRAF_TOPLAM_USD = PTT_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									}
								 if (  iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0 ){
									 PTT_MASRAF_TOPLAM_EUR = PTT_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
									} 
									 
                                if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null) {

                                    BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));
                                    BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));

                                    if (iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("TRY") == 0) {
                                        BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
                                    }
                                    if (iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("USD") == 0) {
                                        BANKA_MASRAF_TOPLAM_USD = BANKA_MASRAF_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
                                    }
                                    if (iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU").compareTo("EUR") == 0) {
                                        BANKA_MASRAF_TOPLAM_EUR = BANKA_MASRAF_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
                                    }

                                }
                            }
                        }
                    }
					j++;
				}
			}	

			if (iMap.getString("ISLEM_TIPI").compareTo("Kredi Tahsilati") ==0   ){
			
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}
			
			if (iMap.getString("ISLEM_TIPI").compareTo("Kredi Kullandirim") ==0  ){
			
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.subtract(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.subtract(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.subtract(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.subtract(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.subtract(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.subtract(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}
			
			
			if (iMap.getString("ISLEM_TIPI").compareTo("IPTAL") ==0  ){
			
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			
			}
			
			oMap.put("PTT_ISLEM_TOPLAM_TRY", PTT_ISLEM_TOPLAM_TRY);
			oMap.put("PTT_MASRAF_TOPLAM_TRY", PTT_MASRAF_TOPLAM_TRY);
			oMap.put("PTT_GENEL_TOPLAM_TRY", PTT_GENEL_TOPLAM_TRY);
			oMap.put("PTT_ISLEM_ADET_TRY", PTT_ISLEM_ADET_TRY);
			
			oMap.put("BANKA_ISLEM_TOPLAM_TRY", BANKA_ISLEM_TOPLAM_TRY);
			oMap.put("BANKA_MASRAF_TOPLAM_TRY", BANKA_MASRAF_TOPLAM_TRY);
			oMap.put("BANKA_GENEL_TOPLAM_TRY", BANKA_GENEL_TOPLAM_TRY);
			oMap.put("BANKA_ISLEM_ADET_TRY", BANKA_ISLEM_ADET_TRY);	
			
			oMap.put("PTT_ISLEM_TOPLAM_EUR", PTT_ISLEM_TOPLAM_EUR);
			oMap.put("PTT_MASRAF_TOPLAM_EUR", PTT_MASRAF_TOPLAM_EUR);
			oMap.put("PTT_GENEL_TOPLAM_EUR", PTT_GENEL_TOPLAM_EUR);
			oMap.put("PTT_ISLEM_ADET_EUR", PTT_ISLEM_ADET_EUR);
			
			oMap.put("BANKA_ISLEM_TOPLAM_EUR", BANKA_ISLEM_TOPLAM_EUR);
			oMap.put("BANKA_MASRAF_TOPLAM_EUR", BANKA_MASRAF_TOPLAM_EUR);
			oMap.put("BANKA_GENEL_TOPLAM_EUR", BANKA_GENEL_TOPLAM_EUR);
			oMap.put("BANKA_ISLEM_ADET_EUR", BANKA_ISLEM_ADET_EUR);	
			
			oMap.put("PTT_ISLEM_TOPLAM_USD", PTT_ISLEM_TOPLAM_USD);
			oMap.put("PTT_MASRAF_TOPLAM_USD", PTT_MASRAF_TOPLAM_USD);
			oMap.put("PTT_GENEL_TOPLAM_USD", PTT_GENEL_TOPLAM_USD);
			oMap.put("PTT_ISLEM_ADET_USD", PTT_ISLEM_ADET_USD);
			
			oMap.put("BANKA_ISLEM_TOPLAM_USD", BANKA_ISLEM_TOPLAM_USD);
			oMap.put("BANKA_MASRAF_TOPLAM_USD", BANKA_MASRAF_TOPLAM_USD);
			oMap.put("BANKA_GENEL_TOPLAM_USD", BANKA_GENEL_TOPLAM_USD);
			oMap.put("BANKA_ISLEM_ADET_USD", BANKA_ISLEM_ADET_USD);	
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_NC_NY_REF")
	public static GMMap getSecondLevelAktif_NC_NY_REF(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.Rc_2nd_Level_Akt_NC_NY_RefOde(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_NC_NY_REF")
	public static GMMap getMutabakatsizIslemler_NC_NY_REF(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.Agreement_Res_NC_NY_RefOde(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			
			//if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("1")==0){
			//	oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
			//}else{
				oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT_MUTABAKATSIZ");
			//}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_NC_NY_REF")
	public static GMMap getMutabakatOnlyMutabatsiz_NC_NY_REF(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.Agreement_Res_NC_NY_RefOde(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
				
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_TAHSILAT_DOSYA")
	public static GMMap getSTahsilatDosya(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
	        
		try{
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call Pkg_Rc_Ptt.Rc_Qry_Get_Tahsilat_Dosya_Adet(?,?,?) }");
			int i = 1;
			
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i++, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i++, null);
			
			stmt.registerOutParameter(i++, Types.DECIMAL);
			stmt.registerOutParameter(i++, Types.DECIMAL);
			
			
			stmt.execute();
			
			oMap.put("AKTIFBANK_TAHSIL_TOPLAM", stmt.getBigDecimal(2));
			oMap.put("AKTIFBANK_TAHSIL_ADET", stmt.getBigDecimal(3));
			oMap.put("PTT_TAHSIL_TOPLAM", stmt.getBigDecimal(2));
			oMap.put("PTT_TAHSIL_ADET", stmt.getBigDecimal(3));

			oMap.put("CBS_AKTIFBANK_PTT", GMServiceExecuter.execute("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_TAHSILAT_DOSYA", iMap).get("CBS_AKTIFBANK"));
			
		
		return oMap;
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_TAHSILAT_DOSYA")
	public static GMMap getSecondLevelTahsilDosya(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call Pkg_Rc_Ptt.Rc_Qry_Get_Tahsilat_Dosya(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_MUTABAKAT_TAMAMLA")
	public static GMMap MutabakatTamamla(GMMap iMap){
		
		GMMap oMap = new GMMap();
		
		try {
			
			oMap = (GMMap) DALUtil.callOracleProcedure("{call PKG_RC2052.Mutabakatsiz_SorunluYap(?)}", 
				new Object[]{ BnsprType.NUMBER, iMap.getBigDecimal("ISLEM_NO") },
				new Object[]{});
			
		} catch(Exception e){
			
			logger.error("BNSPR_QRY2052_MUTABAKAT_TAMAMLA err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY2052_GECICI_HESABA_AL")
	public static GMMap geciciHesabaAl(GMMap iMap){
		
		GMMap oMap = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			ClksHavaleGirisTx clksHavaleGirisTx = (ClksHavaleGirisTx) session.get(ClksHavaleGirisTx.class, iMap.getBigDecimal("ISLEM_NO"));
			clksHavaleGirisTx.setFGeciciHesap("E");
			session.saveOrUpdate(clksHavaleGirisTx);
			session.flush();
			
		} catch(Exception e){
			
			logger.error("BNSPR_QRY2052_GECICI_HESABA_AL err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY2052_PFT_DUZELT")
	public static GMMap PftTarihDuzenle(GMMap iMap){
		
		GMMap oMap= new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_RC2052.PFT_Tarih_Duzelt(?) }");
			stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_NO") );
			stmt.execute();
			
		}catch(Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{	
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);		
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_TU")
	public static GMMap getSecondLevelAktifTU(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call Pkg_Rc_Ptt_FC.RC_QRY_GET_2nd_LEVEL_AKT_TU(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_TU")
	public static GMMap getMutabakatsizIslemlerTU(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call Pkg_Rc_Ptt_FC.Agreement_Response_TU(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			rSet= (ResultSet)stmt.getObject(1);

		    oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT_MUTABAKATSIZ");

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_TU")
	public static GMMap getMutabakatOnlyMutabatsizTU(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call Pkg_Rc_Ptt_FC.Agreement_Response_TU(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
				
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_TU_DATA")
	public static GMMap getTUData(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		BigDecimal PTTYT1 =  new BigDecimal(0);
		BigDecimal AKTIFBANKYT1 =new BigDecimal(0);
		BigDecimal pttbankYT2 =new BigDecimal(0);
		BigDecimal YATAN_AKT_EUR =new BigDecimal(0);
		BigDecimal pttbankYT3  = new BigDecimal(0);
	    BigDecimal AKTIFBANKYT3 = new BigDecimal(0);
	    
	    BigDecimal PPTYATANADETTRY =  new BigDecimal(0);
	    BigDecimal AKTIFBANKYATANADETTRY =  new BigDecimal(0);
	    BigDecimal PTTYATANADETEUR =  new BigDecimal(0);
	    BigDecimal AKTIFBANKYATANADETEUR =  new BigDecimal(0);
	    BigDecimal PTTYATANADETUSD =  new BigDecimal(0);
	    BigDecimal AKTIFBANKYATANADETUSD =  new BigDecimal(0);
	    
	    BigDecimal pttbankCT1 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT1 =  new BigDecimal(0);
	    BigDecimal pttbankCT2 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT2 =  new BigDecimal(0);
	    BigDecimal pttbankCT3 =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCT3 =  new BigDecimal(0);
	    
	    BigDecimal PPTCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal PTTCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal PTTCEKILENADETUSD =  new BigDecimal(0);
	    BigDecimal AKTIFBANKCEKILENADETUSD =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANUSD =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANEUR =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENEUR =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENUSD =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENUSD =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTYATANADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALBANKAYATANADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALPTTYATANADETUSD =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKYATANADETUSD =  new BigDecimal(0);
	    
	    BigDecimal IPTALPTTCEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALBANKACEKILENADETTRY =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALAKTIFBANKCEKILENADETEUR =  new BigDecimal(0);
	    BigDecimal IPTALPTTCEKILENADETUSD =  new BigDecimal(0);
	    BigDecimal IPTALBANKACEKILENADETUSD =  new BigDecimal(0);
	        
	    GMMap   oMapOnlyMutabakatsiz = new GMMap();

		try{
			int i = 1;
			
			oMap.put("CBS_AKTIFBANK_PTT", GMServiceExecuter.execute("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_TU", iMap).get("CBS_AKTIFBANK"));
						
			String tableName = "CBS_AKTIFBANK_PTT";
			 i =  oMap.getSize(tableName); 
			int j=0;
			
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_TU", iMap));

			String tableName2 = "CBS_AKTIFBANK_PTT";
			tableName = "CBS_AKTIFBANK_PTT_MUTABAKATSIZ";
			for (j = 0; j < iMap.getSize(tableName); j++) {
				oMap.put(tableName2, i, "ISLEM_TURU_PTT", iMap.getString(tableName, j,"ISLEM_TURU_PTT"));
				oMap.put(tableName2, i, "PTT_TL_TUTARI", iMap.getString(tableName, j,"PTT_TL_TUTARI"));
				oMap.put(tableName2, i, "PTT_DOVIZ_TUTARI", iMap.getString(tableName, j,"PTT_DOVIZ_TUTARI"));
				oMap.put(tableName2, i, "PTT_MASRAF_TUTARI", iMap.getString(tableName, j,"PTT_MASRAF_TUTARI"));
				oMap.put(tableName2, i, "ISLEM_NO_PTT", iMap.getString(tableName, j,"ISLEM_NO_PTT"));
				oMap.put(tableName2, i, "NUMARA", iMap.getString(tableName, j,"NUMARA"));  // ISLEMNOBANKA
				oMap.put(tableName2, i, "PTT_DOVIZ_KODU", iMap.getString(tableName, j,"PTT_DOVIZ_KODU"));
				oMap.put(tableName2, i, "EFT_HESAP_KASA", iMap.getString(tableName, j,"EFT_HESAP_KASA"));
				oMap.put(tableName2, i, "ISLEM", iMap.getString(tableName, j,"ISLEM"));
				oMap.put(tableName2, i, "ISLEM_ADI_PTT",iMap.getString(tableName, j,"ISLEM_ADI_PTT"));
				oMap.put(tableName2, i, "REFERANS",iMap.getString(tableName, j,"REFERANS"));
				i++;
			}
			
			tableName2 = "CBS_AKTIFBANK_PTT";
		for  (j = 0; j < oMap.getSize(tableName2); j++) {  // Aktifbank i�lem T�P� null sa
															// demekki banka islemi
			// YATAN  ptt
			if ("TU_GIDEN".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
				"TALIMATLI_ISME".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
				"TALIMATLI_SWIFT".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) ||
				"TALIMATLI_EFT".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
			
			    if (oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0)  {
					 //pft hesaptan ise g�z�n�nde tutulmuyacak...
					
					  if (oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI").compareTo(new BigDecimal(0)) == 1 && oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI").compareTo(new BigDecimal(0)) == 0){
						  PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
						  PPTYATANADETTRY   = PPTYATANADETTRY.add(new BigDecimal(1));
					  }
					  else if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){ 	  
						  pttbankYT2 = pttbankYT2.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
						  PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
						  PTTYATANADETEUR = PTTYATANADETEUR.add(new BigDecimal(1));
					  }
					  else if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
						  pttbankYT3 = pttbankYT3.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
						  PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
						  PTTYATANADETUSD = PTTYATANADETUSD.add(new BigDecimal(1));
					  }
			    }
		    } 
			
			// CEKILEN ptt
			if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  && 
			   oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("TU_GELEN") ==0 ){

					if ("TRY".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
						pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
						PPTCEKILENADETTRY   = PPTCEKILENADETTRY.add(new BigDecimal(1));
					}
					if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
						pttbankCT2 = pttbankCT2.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
						pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
						PTTCEKILENADETEUR = PTTCEKILENADETEUR.add(new BigDecimal(1));
					}
					if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
						pttbankCT3 = pttbankCT3.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
						pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
						PTTCEKILENADETUSD = PTTCEKILENADETUSD.add(new BigDecimal(1));
					}
			}
			// IPTAL YATAN ptt
			if ("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) &&  
			    ("GIDEN".equals(oMap.getString(tableName2, j, "ISLEM"))  || 
			    "GIDEN TALIMAT".equals(oMap.getString(tableName2, j, "ISLEM")))) {
				
				if ("GIDEN TALIMAT".equals(oMap.getString(tableName2, j, "ISLEM")))  {
					
					  if (oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI").compareTo(new BigDecimal(0)) == 1 && oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI").compareTo(new BigDecimal(0)) == 0){
						  PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
						  PPTYATANADETTRY   = PPTYATANADETTRY.add(new BigDecimal(1));
					  }
					  else if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){ 	  
						  pttbankYT2 = pttbankYT2.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
						  PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
						  PTTYATANADETEUR = PTTYATANADETEUR.add(new BigDecimal(1));
					  }
					  else if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
						  pttbankYT3 = pttbankYT3.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
						  PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
						  PTTYATANADETUSD = PTTYATANADETUSD.add(new BigDecimal(1));
					  }
			    }
				
				if(oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("PTT EFT") !=0 && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  ){
					//pft hesaptan olmayanlar

					if (oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI").compareTo(new BigDecimal(0)) == 1 && oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI").compareTo(new BigDecimal(0)) == 0){
						IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
						IPTALPTTYATANADETTRY   = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
					}
					else if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
						IPTALPTTYATANEUR = IPTALPTTYATANEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
						IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
						IPTALPTTYATANADETEUR = IPTALPTTYATANADETEUR.add(new BigDecimal(1));
					}
					else if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
						IPTALPTTYATANUSD = IPTALPTTYATANUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
						IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
						IPTALPTTYATANADETUSD = IPTALPTTYATANADETUSD.add(new BigDecimal(1));
					}					
				}
			}
			// IPTAL CEKILEN ptt
			if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  &&  oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  oMap.getString(tableName2, j, "ISLEM").compareTo("GELEN") == 0 ){

				
				if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("TRY") == 0  ){
					IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
					IPTALPTTCEKILENADETTRY  = IPTALPTTCEKILENADETTRY.add(new BigDecimal(1));
				}
				if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("EUR") == 0  ){
					IPTALPTTCEKILENEUR = IPTALPTTCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
					IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
					IPTALPTTCEKILENADETEUR  = IPTALPTTCEKILENADETEUR.add(new BigDecimal(1));
				}
				if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU").compareTo("USD") == 0  ){
					IPTALPTTCEKILENUSD = IPTALPTTCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "PTT_DOVIZ_TUTARI") ) ;
					IPTALPTTCEKILENTRY = IPTALPTTCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_TL_TUTARI") ) ;
					IPTALPTTCEKILENADETUSD  = IPTALPTTCEKILENADETUSD.add(new BigDecimal(1));
				}
			}
			
			// AKTIFBANKISLEMLERI
			if (oMap.getString(tableName2, j, "ISLEM_KOD") != null ){
				//AKTIFBANKYATAN
				if (oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2850)) ==0 ||
						oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2316)) ==0 ){
					//if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
						if( oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  ){
							//hesaptan eft olmamali
							if("TRY".equals(oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU"))){
								AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
								AKTIFBANKYATANADETTRY   = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));								
							}
							else if ("EUR".equals(oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU"))){
								YATAN_AKT_EUR = YATAN_AKT_EUR.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
								AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
								AKTIFBANKYATANADETEUR = AKTIFBANKYATANADETEUR.add(new BigDecimal(1));
							}
							else if ("USD".equals(oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU"))){
								AKTIFBANKYT3 = AKTIFBANKYT3.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
								AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
								AKTIFBANKYATANADETUSD = AKTIFBANKYATANADETUSD.add(new BigDecimal(1));
							}							
						}   
				}

				//AKTIFBANKCEKILEN
				if (/*oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(2032)) == 0 ||*/
						oMap.getBigDecimal(tableName2, j, "ISLEM_KOD").compareTo(new BigDecimal(3552)) == 0)  {
				
					if ("TRY".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
						AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
						AKTIFBANKCEKILENADETTRY   = AKTIFBANKCEKILENADETTRY.add(new BigDecimal(1));
					}
					if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
						AKTIFBANKCT2 = AKTIFBANKCT2.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
						AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
						AKTIFBANKCEKILENADETEUR = AKTIFBANKCEKILENADETEUR.add(new BigDecimal(1));
					}
					if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
						AKTIFBANKCT3 = AKTIFBANKCT3.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
						AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
						AKTIFBANKCEKILENADETUSD = AKTIFBANKCEKILENADETUSD.add(new BigDecimal(1));
					}	
				}	
	
				//  aktifbank iptal YATAN
				if ("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT")) &&  
					    ("GIDEN".equals(oMap.getString(tableName2, j, "ISLEM"))  || 
					    "GIDEN TALIMAT".equals(oMap.getString(tableName2, j, "ISLEM")))) {
					
					//if (oMap.getString(tableName2, j, "PTT_DOVIZ_KODU") != null){
					if( oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("TU_GIDEN") !=0 && oMap.getString(tableName2, j, "EFT_HESAP_KASA").compareTo("HESAPTAN") !=0  ){
						//hesaptan eft olmamali

						if("TRY".equals(oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU"))){
							IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI"))  ;
							IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));
						}
						else if ("USD".equals(oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU"))){
							IPTALAKTIFBANKYATANUSD = IPTALAKTIFBANKYATANUSD.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
							IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI"))  ;
							IPTALAKTIFBANKYATANADETUSD = IPTALAKTIFBANKYATANADETUSD.add(new BigDecimal(1));
						}
						else if ("EUR".equals(oMap.getString(tableName2, j, "AKTIFBANK_DOVIZ_KODU"))){
							IPTALAKTIFBANKYATANEUR = IPTALAKTIFBANKYATANEUR.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
							IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI"))  ;
							IPTALAKTIFBANKYATANADETEUR = IPTALAKTIFBANKYATANADETEUR.add(new BigDecimal(1));
						}							
					}	
					//}
				}
					
					//  aktifbank iptal CEKILEN
					if (  oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null  && 
						oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") ==0 &&  
						  oMap.getString(tableName2, j, "ISLEM").compareTo("GELEN") == 0 ){
						
						if ("TRY".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
							IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
							IPTALBANKACEKILENADETTRY = IPTALBANKACEKILENADETTRY.add(new BigDecimal(1));
						}
						if ("EUR".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
							IPTALAKTIFBANKCEKILENEUR = IPTALAKTIFBANKCEKILENEUR.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
							IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
							IPTALAKTIFBANKCEKILENADETEUR = IPTALAKTIFBANKCEKILENADETEUR.add(new BigDecimal(1));
						}
						if ("USD".equals(oMap.getString(tableName2, j, "PTT_DOVIZ_KODU"))){
							IPTALAKTIFBANKCEKILENUSD = IPTALAKTIFBANKCEKILENUSD.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_DOVIZ_TUTARI") ) ;
							IPTALAKTIFBANKCEKILENTRY = IPTALAKTIFBANKCEKILENTRY.add(oMap.getBigDecimal(tableName2, j, "AKTIFBANK_TL_TUTARI") ) ;
							IPTALBANKACEKILENADETUSD = IPTALBANKACEKILENADETUSD.add(new BigDecimal(1));
						}
					}
				}
		}

		 oMap.put("PTTYT1", PTTYT1)  ;
		 oMap.put("AKTIFBANKYT1", AKTIFBANKYT1)  ;
		 oMap.put("pttbankYT2", pttbankYT2)  ;
		 oMap.put("YATAN_AKT_EUR", YATAN_AKT_EUR)  ;
		 oMap.put("pttbankYT3", pttbankYT3)  ;
		 oMap.put("AKTIFBANKYT3", AKTIFBANKYT3)  ;
		 
		 oMap.put("PPTYATANADETTRY", PPTYATANADETTRY)  ;
		 oMap.put("AKTIFBANKYATANADETTRY", AKTIFBANKYATANADETTRY)  ;
		 oMap.put("PTTYATANADETEUR", PTTYATANADETEUR)  ;
		 oMap.put("AKTIFBANKYATANADETEUR", AKTIFBANKYATANADETEUR)  ;
		 oMap.put("PTTYATANADETUSD", PTTYATANADETUSD)  ;
		 oMap.put("AKTIFBANKYATANADETUSD", AKTIFBANKYATANADETUSD)  ;
		 
		 oMap.put("pttbankCT1", pttbankCT1)  ;
		 oMap.put("AKTIFBANKCT1", AKTIFBANKCT1)  ;
		 oMap.put("pttbankCT2", pttbankCT2)  ;
		 oMap.put("AKTIFBANKCT2", AKTIFBANKCT2)  ;
		 oMap.put("pttbankCT3", pttbankCT3)  ;
		 oMap.put("AKTIFBANKCT3", AKTIFBANKCT3)  ;
		 
		 oMap.put("PPTCEKILENADETTRY", PPTCEKILENADETTRY)  ;
		 oMap.put("AKTIFBANKCEKILENADETTRY", AKTIFBANKCEKILENADETTRY)  ;
		 oMap.put("PTTCEKILENADETEUR", PTTCEKILENADETEUR)  ;
		 oMap.put("AKTIFBANKCEKILENADETEUR", AKTIFBANKCEKILENADETEUR)  ;
		 oMap.put("PTTCEKILENADETUSD", PTTCEKILENADETUSD)  ;
		 oMap.put("AKTIFBANKCEKILENADETUSD", AKTIFBANKCEKILENADETUSD)  ;
		 
		 oMap.put("IPTALPTTYATANTRY", IPTALPTTYATANTRY)  ;
		 oMap.put("IPTALAKTIFBANKYATANTRY", IPTALAKTIFBANKYATANTRY)  ;
		 oMap.put("IPTALPTTYATANUSD", IPTALPTTYATANUSD)  ;
		 oMap.put("IPTALAKTIFBANKYATANUSD", IPTALAKTIFBANKYATANUSD)  ;
		 oMap.put("IPTALPTTYATANEUR", IPTALPTTYATANEUR)  ;
		 oMap.put("IPTALAKTIFBANKYATANEUR", IPTALAKTIFBANKYATANEUR)  ;
		 
		 oMap.put("IPTALPTTCEKILENTRY", IPTALPTTCEKILENTRY)  ;
		 oMap.put("IPTALAKTIFBANKCEKILENTRY", IPTALAKTIFBANKCEKILENTRY)  ;
		 oMap.put("IPTALPTTCEKILENEUR", IPTALPTTCEKILENEUR)  ;
		 oMap.put("IPTALAKTIFBANKCEKILENEUR", IPTALAKTIFBANKCEKILENEUR)  ;
		 oMap.put("IPTALPTTCEKILENUSD", IPTALPTTCEKILENUSD)  ;
		 oMap.put("IPTALAKTIFBANKCEKILENUSD", IPTALAKTIFBANKCEKILENUSD)  ;
		 
		BigDecimal PTT_BORC_TL =  new BigDecimal(0);
		BigDecimal PTT_BORC_EUR =  new BigDecimal(0);
		BigDecimal PTT_BORC_USD =  new BigDecimal(0);
		BigDecimal AKTIFBANK_BORC_TL =  new BigDecimal(0);
		BigDecimal AKTIFBANK_BORC_EUR =  new BigDecimal(0);
		BigDecimal AKTIFBANK_BORC_USD =  new BigDecimal(0);

		oMap.put("pttbankYT2", pttbankYT2);
		
		
	    BigDecimal TOPLAMYATANPTTTRY =   PTTYT1/*.add(MASRAFYATANPTTTRY)*/;
	    BigDecimal TOPLAMYATANAKTIFBANKTRY = AKTIFBANKYT1/*.add(MASRAFYATANAKTIFBANKTRY)*/;
	    BigDecimal TOPLAMYATANPTTEUR = pttbankYT2/*.add(MASRAFYATANPTTEUR)*/;
	    BigDecimal TOPLAMYATANAKTIFBANKEUR =  YATAN_AKT_EUR/*.add(MASRAFYATANAKTIFBANKEUR)*/;
	    BigDecimal TOPLAMYATANPTTUSD = pttbankYT3/*.add(MASRAFYATANPTTUSD)*/;
	    BigDecimal TOPLAMYATANAKTIFBANKUSD =  AKTIFBANKYT3/*.add(MASRAFYATANAKTIFBANKUSD)*/;
	    
	    oMap.put("TOPLAMYATANPTTTRY", TOPLAMYATANPTTTRY)  ;
	    oMap.put("TOPLAMYATANAKTIFBANKTRY", TOPLAMYATANAKTIFBANKTRY)  ;
	    oMap.put("TOPLAMYATANPTTEUR", TOPLAMYATANPTTEUR)  ;
	    oMap.put("TOPLAMYATANAKTIFBANKEUR", TOPLAMYATANAKTIFBANKEUR)  ;
	    oMap.put("TOPLAMYATANPTTUSD", TOPLAMYATANPTTUSD)  ;
	    oMap.put("TOPLAMYATANAKTIFBANKUSD", TOPLAMYATANAKTIFBANKUSD)  ;
    
	    BigDecimal TOPLAMCEKILENPTTTRY =   pttbankCT1/*.subtract(MASRAFCEKILENPTTTRY)*/ ; 
	    BigDecimal TOPLAMCEKILENAKTIFBANKTRY =  AKTIFBANKCT1/*.subtract(MASRAFCEKILENAKTIFBANKTRY)*/  ;   
	    BigDecimal TOPLAMCEKILENPTTEUR =  pttbankCT2/*.subtract(MASRAFCEKILENPTTEUR)*/ ; 
	    BigDecimal TOPLAMCEKILENAKTIFBANKEUR =  AKTIFBANKCT2/*.subtract(MASRAFCEKILENAKTIFBANKEUR)*/   ; 
	    BigDecimal TOPLAMCEKILENPTTUSD = 		pttbankCT3/*.subtract(MASRAFCEKILENPTTUSD)*/;
	    BigDecimal TOPLAMCEKILENAKTIFBANKUSD =  AKTIFBANKCT3/*.subtract(MASRAFCEKILENAKTIFBANKUSD)*/  ;   
	    
	    oMap.put("TOPLAMCEKILENPTTTRY", TOPLAMCEKILENPTTTRY)  ;
	    oMap.put("TOPLAMCEKILENAKTIFBANKTRY", TOPLAMCEKILENAKTIFBANKTRY)  ;
	    oMap.put("TOPLAMCEKILENPTTEUR", TOPLAMCEKILENPTTEUR)  ;
	    oMap.put("TOPLAMCEKILENAKTIFBANKEUR", TOPLAMCEKILENAKTIFBANKEUR)  ;
	    oMap.put("TOPLAMCEKILENPTTUSD", TOPLAMCEKILENPTTUSD)  ;
	    oMap.put("TOPLAMCEKILENAKTIFBANKUSD", TOPLAMCEKILENAKTIFBANKUSD)  ;	    
	    
	    oMap.put("IPTALPTTYATANADETTRY", IPTALPTTYATANADETTRY)  ;
	    oMap.put("IPTALBANKAYATANADETTRY", IPTALBANKAYATANADETTRY)  ;
	    oMap.put("IPTALPTTYATANADETEUR", IPTALPTTYATANADETEUR)  ;
	    oMap.put("IPTALAKTIFBANKYATANADETEUR", IPTALAKTIFBANKYATANADETEUR)  ;
	    oMap.put("IPTALPTTYATANADETUSD", IPTALPTTYATANADETUSD)  ;
	    oMap.put("IPTALAKTIFBANKYATANADETUSD", IPTALAKTIFBANKYATANADETUSD)  ;
	        
	    oMap.put("IPTALPTTCEKILENADETTRY", IPTALPTTCEKILENADETTRY)  ;
	    oMap.put("IPTALBANKACEKILENADETTRY", IPTALBANKACEKILENADETTRY)  ;
	    oMap.put("IPTALPTTCEKILENADETEUR", IPTALPTTCEKILENADETEUR)  ;
	    oMap.put("IPTALAKTIFBANKCEKILENADETEUR", IPTALAKTIFBANKCEKILENADETEUR)  ;
	    oMap.put("IPTALPTTCEKILENADETUSD", IPTALPTTCEKILENADETUSD)  ;
	    oMap.put("IPTALBANKACEKILENADETUSD", IPTALBANKACEKILENADETUSD)  ;
	    
     
		PTT_BORC_TL = PTTYT1/*.add(MASRAFYATANPTTTRY)*/.subtract(IPTALPTTYATANTRY)/*.subtract(IPTALMASRAFPTTYATANTRY)
		.add(MASRAFCEKILENPTTTRY)*/.subtract(pttbankCT1).add(IPTALPTTCEKILENTRY)/*.subtract(IPTALMASRAFPTTCEKILENTRY)*/
		;
		
		PTT_BORC_EUR = pttbankYT2.subtract(IPTALPTTYATANEUR).subtract(pttbankCT2).add(IPTALPTTCEKILENEUR)  ;	
		
		PTT_BORC_USD = pttbankYT3.subtract(IPTALPTTYATANUSD).subtract(pttbankCT3).add(IPTALPTTCEKILENUSD)  ;	
		 /******************/
	
		oMap.put("BORC_TL_PTT", PTT_BORC_TL);
		oMap.put("BORC_USD_PTT", PTT_BORC_USD);
		oMap.put("BORC_EUR_PTT", PTT_BORC_EUR);
		
		oMap.put("BORC_TL_BANKA", "0");
		oMap.put("BORC_EUR_BANKA", "0");
		oMap.put("BORC_USD_BANKA", "0");
		
		
		if  (PTT_BORC_TL.intValue() < 0) {
			AKTIFBANK_BORC_TL = PTT_BORC_TL;
			oMap.put("BORC_TL_BANKA", AKTIFBANK_BORC_TL);
			oMap.put("BORC_TL_PTT", "0");
		}
		
		if  (PTT_BORC_EUR.intValue() < 0) {
			AKTIFBANK_BORC_EUR = PTT_BORC_EUR;
			oMap.put("BORC_EUR_BANKA", AKTIFBANK_BORC_EUR);
			oMap.put("BORC_EUR_PTT", "0");
		}
		if  (PTT_BORC_USD.intValue() < 0) {
			AKTIFBANK_BORC_USD = PTT_BORC_USD;
			oMap.put("BORC_USD_BANKA", AKTIFBANK_BORC_USD);
			oMap.put("BORC_USD_PTT", "0");
		}
		
		AKTIFBANK_BORC_TL = AKTIFBANKYT1/*.add(MASRAFYATANAKTIFBANKTRY)*/.subtract(IPTALAKTIFBANKYATANTRY)/*.subtract(IPTALMASRAFAKTIFBANKYATANTRY)
		.add(MASRAFCEKILENAKTIFBANKTRY)*/.subtract(AKTIFBANKCT1).add(IPTALAKTIFBANKCEKILENTRY)/*.subtract(IPTALMASRAFAKTIFBANKCEKILENTRY)*/
		;
		
		AKTIFBANK_BORC_EUR = YATAN_AKT_EUR.subtract(IPTALAKTIFBANKYATANEUR).subtract(AKTIFBANKCT2).add(IPTALAKTIFBANKCEKILENEUR)  ;	
		
		AKTIFBANK_BORC_USD = AKTIFBANKYT3.subtract(IPTALAKTIFBANKYATANUSD).subtract(AKTIFBANKCT3).add(IPTALAKTIFBANKCEKILENUSD)  ;	

		
		GMMap sMap = new GMMap();
		
		sMap.put("TARIH", iMap.get("TARIH"));
		sMap.put("AKTIFBANK_BORC_TL", AKTIFBANK_BORC_TL);
		sMap.put("AKTIFBANK_BORC_EUR", AKTIFBANK_BORC_EUR);
		sMap.put("AKTIFBANK_BORC_USD", AKTIFBANK_BORC_USD);
		sMap.put("PTT_BORC_TL", PTT_BORC_TL);
		sMap.put("PTT_BORC_USD", PTT_BORC_USD);
		sMap.put("PTT_BORC_EUR", PTT_BORC_EUR);
		
		oMap.put("KAYIT_SAYISI","1");
		
		// BU KONTROL BLOGU KALDIRILIRSA MUTABAKATLILARDA LISTELENECEK
		if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("true")==0){
			oMapOnlyMutabakatsiz.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_TU", iMap));
			
			oMap.put("KAYIT_SAYISI", oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT"));
			
			if (oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT")>0){
				oMap.putAll(oMapOnlyMutabakatsiz);
			}else{
				oMap.remove("CBS_AKTIFBANK_PTT");
			}	
			//oMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR", iMap));
		}
		
		return oMap;
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_ISLEMLER_TU")
	public static GMMap Get_Islemler_TU(GMMap iMap){
		GMMap oMap = new GMMap();
	
		BigDecimal PTT_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_TRY=new BigDecimal(0);
		
		BigDecimal PTT_ISLEM_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_EUR=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_EUR=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_EUR=new BigDecimal(0);
		
		BigDecimal PTT_ISLEM_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_USD=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_USD=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_USD=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_USD=new BigDecimal(0);
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;

		try{
			int j=0;
			
			for (int i=0;i<iMap.getSize("ISLEM_LIST");i++){
				
				if(iMap.getString("ISLEM_TIPI").equals(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT")) || 
						("TOPLAM_YP".equals(iMap.getString("ISLEM_TIPI")) && ("TU_GIDEN".equals(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT")) || 
																			"TALIMATLI_EFT".equals(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT")) ||
																			"TALIMATLI_ISME".equals(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT")) || 
																			"TALIMATLI_SWIFT".equals(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"))))) {
					
					oMap.put("SONUC_LIST", j, "ANAISLEMDURUM", iMap.getString("ISLEM_LIST", i, "ANAISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "EFT_HESAP_KASA", iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA"));
					oMap.put("SONUC_LIST", j, "IPTALISLEMDURUM", iMap.getString("ISLEM_LIST", i, "IPTALISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "ISLEM_KOD", iMap.getString("ISLEM_LIST", i, "ISLEM_KOD"));
					oMap.put("SONUC_LIST", j, "ISLEM_NO_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_NO_PTT"));
					oMap.put("SONUC_LIST", j, "ISLEM_TURU_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF", iMap.getString("ISLEM_LIST", i, "MASRAF"));
					oMap.put("SONUC_LIST", j, "NUMARA", iMap.getString("ISLEM_LIST", i, "NUMARA"));
					oMap.put("SONUC_LIST", j, "PTT_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "PTT_MASRAF_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTTISLEMNO", iMap.getString("ISLEM_LIST", i, "PTTISLEMNO"));
					oMap.put("SONUC_LIST", j, "REFERANS", iMap.getString("ISLEM_LIST", i, "REFERANS"));
					oMap.put("SONUC_LIST", j, "TUTAR", iMap.getString("ISLEM_LIST", i, "TUTAR"));
					oMap.put("SONUC_LIST", j, "ISLEM_ADI_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_ADI_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "AKTIFBANK_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "AKTIFBANK_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "AKTIFBANK_DOVIZ_TUTARI", iMap.getString("ISLEM_LIST", i, "AKTIFBANK_DOVIZ_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_DOVIZ_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));
					oMap.put("SONUC_LIST", j, "AKTIFBANK_TL_TUTARI", iMap.getString("ISLEM_LIST", i, "AKTIFBANK_TL_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_TL_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_TL_TUTARI"));

					if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU"))) {

						if (iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
								
							if ("TALIMATLI_EFT".equals(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"))) {
								PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI").subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI")));
								PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							} else {
								PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));
							}

							PTT_ISLEM_ADET_TRY = PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
							
							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
								
								if ("TALIMATLI_EFT".equals(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"))) {
									BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_TL_TUTARI").subtract(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_MASRAF_TUTARI")));
								} else {
									BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_TL_TUTARI"));
								}
								
								BANKA_ISLEM_ADET_TRY = BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								
								if ("TALIMATLI_EFT".equals(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"))) {
									BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_MASRAF_TUTARI"));
								}
							}
						}
					}		

					if ("USD".equals(iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU"))) {

						if (iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){

							PTT_ISLEM_TOPLAM_USD = PTT_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));
							PTT_ISLEM_ADET_USD = PTT_ISLEM_ADET_USD.add(new BigDecimal("1"));

							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){	
								BANKA_ISLEM_TOPLAM_USD = BANKA_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_DOVIZ_TUTARI"));
								BANKA_ISLEM_ADET_USD = BANKA_ISLEM_ADET_USD.add(new BigDecimal("1"));	
							}
								
							if (iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI").compareTo(new BigDecimal(0)) !=0){
								PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));	
								BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_TL_TUTARI"));
							}
						}
					}		

					if ("EUR".equals(iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU"))) {

						if (iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){
		
							PTT_ISLEM_TOPLAM_EUR = PTT_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));
							PTT_ISLEM_ADET_EUR = PTT_ISLEM_ADET_EUR.add(new BigDecimal("1"));

							if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){

								BANKA_ISLEM_TOPLAM_EUR = BANKA_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_DOVIZ_TUTARI"));
								BANKA_ISLEM_ADET_EUR = BANKA_ISLEM_ADET_EUR.add(new BigDecimal("1"));	
							}
								
							if (iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI").compareTo(new BigDecimal(0)) !=0){
								PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));	
								BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_TL_TUTARI"));
							}
						}
					}	

					if("IPTAL".equals(iMap.getString("ISLEM_TIPI"))) {

						conn = DALUtil.getGMConnection();
						stmt = conn.prepareCall("{ ? = call pkg_tx.Islem_kod(?) }");
						stmt.registerOutParameter(1, Types.NUMERIC);
						stmt.setBigDecimal(2, iMap.getBigDecimal("ISLEM_LIST", i, "NUMARA"));
						stmt.execute();

						iMap.put("ISLEM_KODU", stmt.getBigDecimal(1));

						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("TRY")==0   ){
							if (iMap.getString("ISLEM_KODU").compareTo("2850")==0  )   {
								if (iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){

									PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));
									PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));

									if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){

										BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_TL_TUTARI"));
										BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));	 	
									}	
								}
							}
							if (iMap.getString("ISLEM_KODU").compareTo("3552")==0  ){
	
								PTT_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_TL_TUTARI"));
								PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));

								if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){

									BANKA_ISLEM_TOPLAM_TRY.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_TL_TUTARI"));	
									BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
								}		
							}
						}		

						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("USD")==0){

							if ( iMap.getString("ISLEM_KODU").compareTo("2850")==0  )   {
								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){

									PTT_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));	
									PTT_ISLEM_ADET_USD.add(new BigDecimal("1"));

									if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){

										BANKA_ISLEM_TOPLAM_USD.add(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_DOVIZ_TUTARI"));	
										BANKA_ISLEM_ADET_USD.add(new BigDecimal("1"));
									}	
								}
							}
							if ( iMap.getString("ISLEM_KODU").compareTo("3552")==0 ){

								PTT_ISLEM_TOPLAM_USD.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));	
								PTT_ISLEM_ADET_USD.add(new BigDecimal("1"));

								if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){			
									BANKA_ISLEM_TOPLAM_USD.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_DOVIZ_TUTARI"));	
									BANKA_ISLEM_ADET_USD.add(new BigDecimal("1"));
								}
							}
						}		

						if (iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU").compareTo("EUR")==0){

							if ( iMap.getString("ISLEM_KODU").compareTo("2850")==0 )   {

								if ( iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA").compareTo("HESAPTAN")!=0 ){

									PTT_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));	
									PTT_ISLEM_ADET_EUR.add(new BigDecimal("1")); 
									if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){

										BANKA_ISLEM_TOPLAM_EUR.add(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_DOVIZ_TUTARI"));	
										BANKA_ISLEM_ADET_EUR.add(new BigDecimal("1"));
									}
								}
							}

							if (  iMap.getString("ISLEM_KODU").compareTo("3552")==0 ){

								PTT_ISLEM_TOPLAM_EUR.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));	
								PTT_ISLEM_ADET_EUR.add(new BigDecimal("1")); 

								if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){

									BANKA_ISLEM_TOPLAM_EUR.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_DOVIZ_TUTARI"));	
									BANKA_ISLEM_ADET_EUR.add(new BigDecimal("1"));										 
								}
							}
							
							if (  iMap.getString("ISLEM_KODU").compareTo("3554")==0 ){
							    
							    PTT_ISLEM_TOPLAM_EUR.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));	
							    PTT_ISLEM_ADET_EUR.add(new BigDecimal("1")); 
							    
							    if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							        
							        BANKA_ISLEM_TOPLAM_EUR.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_DOVIZ_TUTARI"));	
							        BANKA_ISLEM_ADET_EUR.add(new BigDecimal("1"));										 
							    }
							}
							
							if (  iMap.getString("ISLEM_KODU").compareTo("3555")==0 ){
							    
							    PTT_ISLEM_TOPLAM_EUR.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_DOVIZ_TUTARI"));	
							    PTT_ISLEM_ADET_EUR.add(new BigDecimal("1")); 
							    
							    if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
							        
							        BANKA_ISLEM_TOPLAM_EUR.subtract(iMap.getBigDecimal("ISLEM_LIST", i, "AKTIFBANK_DOVIZ_TUTARI"));	
							        BANKA_ISLEM_ADET_EUR.add(new BigDecimal("1"));										 
							    }
							}
						}
					}
					j++;	
				}
			}	

			if ("TU_GIDEN".equals(iMap.getString("ISLEM_TIPI")) ||
				"TALIMATLI_EFT".equals(iMap.getString("ISLEM_TIPI")) ||
				"TALIMATLI_ISME".equals(iMap.getString("ISLEM_TIPI")) ||
				"TALIMATLI_SWIFT".equals(iMap.getString("ISLEM_TIPI")) ||
				"TOPLAM_YP".equals(iMap.getString("ISLEM_TIPI"))) {
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}
			if (iMap.getString("ISLEM_TIPI").compareTo("TU_GELEN") ==0  ){
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.subtract(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.subtract(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.subtract(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.subtract(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.subtract(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.subtract(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}
			if (iMap.getString("ISLEM_TIPI").compareTo("IPTAL") ==0  ){
				PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
				BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
				PTT_GENEL_TOPLAM_USD = PTT_GENEL_TOPLAM_USD.add(PTT_MASRAF_TOPLAM_USD).add(PTT_ISLEM_TOPLAM_USD);
				BANKA_GENEL_TOPLAM_USD = BANKA_GENEL_TOPLAM_USD.add(BANKA_MASRAF_TOPLAM_USD).add(BANKA_ISLEM_TOPLAM_USD);
			
				PTT_GENEL_TOPLAM_EUR = PTT_GENEL_TOPLAM_EUR.add(PTT_MASRAF_TOPLAM_EUR).add(PTT_ISLEM_TOPLAM_EUR);
				BANKA_GENEL_TOPLAM_EUR = BANKA_GENEL_TOPLAM_EUR.add(BANKA_MASRAF_TOPLAM_EUR).add(BANKA_ISLEM_TOPLAM_EUR);
			}
			
			
			oMap.put("PTT_ISLEM_TOPLAM_TRY", PTT_ISLEM_TOPLAM_TRY);
			oMap.put("PTT_MASRAF_TOPLAM_TRY", PTT_MASRAF_TOPLAM_TRY);
			oMap.put("PTT_GENEL_TOPLAM_TRY", PTT_GENEL_TOPLAM_TRY);
			oMap.put("PTT_ISLEM_ADET_TRY", PTT_ISLEM_ADET_TRY);
			
			oMap.put("BANKA_ISLEM_TOPLAM_TRY", BANKA_ISLEM_TOPLAM_TRY);
			oMap.put("BANKA_MASRAF_TOPLAM_TRY", BANKA_MASRAF_TOPLAM_TRY);
			oMap.put("BANKA_GENEL_TOPLAM_TRY", BANKA_GENEL_TOPLAM_TRY);
			oMap.put("BANKA_ISLEM_ADET_TRY", BANKA_ISLEM_ADET_TRY);	
			
			oMap.put("PTT_ISLEM_TOPLAM_EUR", PTT_ISLEM_TOPLAM_EUR);
			oMap.put("PTT_MASRAF_TOPLAM_EUR", PTT_MASRAF_TOPLAM_EUR);
			oMap.put("PTT_GENEL_TOPLAM_EUR", PTT_GENEL_TOPLAM_EUR);
			oMap.put("PTT_ISLEM_ADET_EUR", PTT_ISLEM_ADET_EUR);
			
			oMap.put("BANKA_ISLEM_TOPLAM_EUR", BANKA_ISLEM_TOPLAM_EUR);
			oMap.put("BANKA_MASRAF_TOPLAM_EUR", BANKA_MASRAF_TOPLAM_EUR);
			oMap.put("BANKA_GENEL_TOPLAM_EUR", BANKA_GENEL_TOPLAM_EUR);
			oMap.put("BANKA_ISLEM_ADET_EUR", BANKA_ISLEM_ADET_EUR);	
			
			oMap.put("PTT_ISLEM_TOPLAM_USD", PTT_ISLEM_TOPLAM_USD);
			oMap.put("PTT_MASRAF_TOPLAM_USD", PTT_MASRAF_TOPLAM_USD);
			oMap.put("PTT_GENEL_TOPLAM_USD", PTT_GENEL_TOPLAM_USD);
			oMap.put("PTT_ISLEM_ADET_USD", PTT_ISLEM_ADET_USD);
			
			oMap.put("BANKA_ISLEM_TOPLAM_USD", BANKA_ISLEM_TOPLAM_USD);
			oMap.put("BANKA_MASRAF_TOPLAM_USD", BANKA_MASRAF_TOPLAM_USD);
			oMap.put("BANKA_GENEL_TOPLAM_USD", BANKA_GENEL_TOPLAM_USD);
			oMap.put("BANKA_ISLEM_ADET_USD", BANKA_ISLEM_ADET_USD);	
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_PTTMATIK_REF_DATA")
	public static GMMap getPttmatikRefData(GMMap iMap) {
		
		GMMap oMap = new GMMap();

		BigDecimal PTTYT1 = new BigDecimal(0);
		BigDecimal AKTIFBANKYT1 = new BigDecimal(0);

		BigDecimal MASRAFYATANPTTTRY = new BigDecimal(0);
		BigDecimal MASRAFYATANAKTIFBANKTRY = new BigDecimal(0);

		BigDecimal PTTYATANADETTRY = new BigDecimal(0);
		BigDecimal AKTIFBANKYATANADETTRY = new BigDecimal(0);

		BigDecimal IPTALPTTYATANTRY = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANTRY = new BigDecimal(0);

		BigDecimal IPTALMASRAFPTTYATANTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKYATANTRY = new BigDecimal(0);

		BigDecimal IPTALPTTYATANADETTRY = new BigDecimal(0);
		BigDecimal IPTALBANKAYATANADETTRY = new BigDecimal(0);

		GMMap oMapOnlyMutabakatsiz = new GMMap();

		try {
			
			int i = 1;

			oMap.put("CBS_AKTIFBANK_PTT", GMServiceExecuter.execute("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_PTTMATIK_REF", iMap).get("CBS_AKTIFBANK"));
			String tableName = "CBS_AKTIFBANK_PTT";
			i = oMap.getSize(tableName);
			int j = 0;

			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_PTTMATIK_REF", iMap));

			// mutabakats�zlarla mutabakatl� olanlar� merge ediyor, tablo listesini olusturuyor
			String tableName2 = "CBS_AKTIFBANK_PTT";
			tableName = "CBS_AKTIFBANK_PTT_MUTABAKATSIZ";
			for (j = 0; j < iMap.getSize(tableName); j++) {
				
				oMap.put(tableName2, i, "ISLEM_TURU_PTT", iMap.getString(tableName, j, "ISLEM_TURU_PTT"));
				oMap.put(tableName2, i, "PTT_ISLEM_TUTARI", iMap.getString(tableName, j, "PTT_ISLEM_TUTARI"));
				oMap.put(tableName2, i, "PTT_MASRAF_TUTARI", iMap.getString(tableName, j, "PTT_MASRAF_TUTARI"));
				oMap.put(tableName2, i, "ISLEM_NO_PTT", iMap.getString(tableName, j, "ISLEM_NO_PTT"));
				oMap.put(tableName2, i, "PTT_TOPLAM_TUTAR", iMap.getString(tableName, j, "PTT_TOPLAM_TUTAR"));
				oMap.put(tableName2, i, "NUMARA", iMap.getString(tableName, j, "NUMARA")); // ISLEMNOBANKA
				oMap.put(tableName2, i, "ISLEM_KOD", iMap.getString(tableName, j, "ISLEM_KOD"));
				oMap.put(tableName2, i, "MASRAF", iMap.getString(tableName, j, "MASRAF"));
				oMap.put(tableName2, i, "TUTAR", iMap.getString(tableName, j, "TUTAR"));
				oMap.put(tableName2, i, "TOPLAM_TUTAR", iMap.getString(tableName, j, "TOPLAM_TUTAR"));

				i++;
			}

			for (j = 0; j < oMap.getSize(tableName2); j++) {
				
				// ptt islemi ise ptt hesapla
				if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null) {
					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("Hesaba Nakit Yatirma") == 0 || oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IBAN a Nakit Yatirma") == 0 || oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("EUPT Hesabina Nakit Yatirma") == 0 || oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("ATM N Kolay Karta Nakit Yat�rma") == 0 || // bora
					oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("ATM Karta Nakit Yatirma") == 0) {
						PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						PTTYATANADETTRY = PTTYATANADETTRY.add(new BigDecimal(1));
						MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
					}
					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") == 0) {
						IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI") ) ;
						IPTALPTTYATANADETTRY = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
					}

				}

				// AKTIFBANKISLEMLERI, aktifbank islem bilgileri hesapla
				if (oMap.getString(tableName2, j, "ISLEM_TIP") != null) {
					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null && (oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("Hesaba Nakit Yatirma") == 0 || oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IBAN a Nakit Yatirma") == 0 || oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("EUPT Hesabina Nakit Yatirma") == 0 || oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("ATM N Kolay Karta Nakit Yat�rma") == 0 || // bora
					oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("ATM Karta Nakit Yatirma") == 0)) {
						AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
						AKTIFBANKYATANADETTRY = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
						MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF") ) ;
					}
					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null && oMap.getString(tableName2, j, "ISLEM_TURU_PTT").compareTo("IPTAL") == 0) {
						IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
						IPTALMASRAFAKTIFBANKYATANTRY=IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
						IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));
					}

				}

			}

			oMap.put("PTTYT1", PTTYT1);
			oMap.put("AKTIFBANKYT1", AKTIFBANKYT1);

			oMap.put("MASRAFYATANPTTTRY", MASRAFYATANPTTTRY);
			oMap.put("MASRAFYATANAKTIFBANKTRY", MASRAFYATANAKTIFBANKTRY);

			oMap.put("PTTYATANADETTRY", PTTYATANADETTRY);
			oMap.put("AKTIFBANKYATANADETTRY", AKTIFBANKYATANADETTRY);

			oMap.put("IPTALPTTYATANTRY", IPTALPTTYATANTRY);
			oMap.put("IPTALAKTIFBANKYATANTRY", IPTALAKTIFBANKYATANTRY);

			oMap.put("IPTALMASRAFPTTYATANTRY", IPTALMASRAFPTTYATANTRY);
			oMap.put("IPTALMASRAFAKTIFBANKYATANTRY", IPTALMASRAFAKTIFBANKYATANTRY);

			oMap.put("IPTALPTTYATANADETTRY", IPTALPTTYATANADETTRY);
			oMap.put("IPTALBANKAYATANADETTRY", IPTALBANKAYATANADETTRY);

			BigDecimal PTT_BORC_TL = new BigDecimal(0);
			BigDecimal BANKA_BORC_TL = new BigDecimal(0);

			BigDecimal TOPLAMYATANPTTTRY = PTTYT1.add(MASRAFYATANPTTTRY);
			BigDecimal TOPLAMYATANAKTIFBANKTRY = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY);

			BigDecimal TOPLAMYATANIPTALPTTTRY = IPTALPTTYATANTRY.add(IPTALMASRAFPTTYATANTRY);
			BigDecimal TOPLAMYATANAKTIFBANKIPTALTRY = IPTALAKTIFBANKYATANTRY.add(IPTALMASRAFAKTIFBANKYATANTRY);

			oMap.put("TOPLAMYATANPTTTRY", TOPLAMYATANPTTTRY);
			oMap.put("TOPLAMYATANAKTIFBANKTRY", TOPLAMYATANAKTIFBANKTRY);

			oMap.put("TOPLAMYATANIPTALPTTTRY", TOPLAMYATANIPTALPTTTRY);
			oMap.put("TOPLAMYATANAKTIFBANKIPTALTRY", TOPLAMYATANAKTIFBANKIPTALTRY);

			PTT_BORC_TL = PTTYT1.subtract(IPTALPTTYATANTRY).add(MASRAFYATANPTTTRY).subtract(IPTALMASRAFPTTYATANTRY);

			oMap.put("BORC_TL_PTT", PTT_BORC_TL);
			oMap.put("BORC_TL_BANKA", BANKA_BORC_TL);

			// BU KONTROL BLOGU KALDIRILIRSA MUTABAKATLILARDA LISTELENECEK
			if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("true") == 0) {
				
				iMap.put("ONLY_MUTABAKATSIZ", "Y");
				oMapOnlyMutabakatsiz.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_PTTMATIK_REF", iMap));

				if (oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT") > 0) {
					oMap.putAll(oMapOnlyMutabakatsiz);
				}
				else {
					oMap.remove("CBS_AKTIFBANK_PTT"); // SONUC_LIST
				}
			}

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_KART_ISLEMLER_REF_DATA")
	public static GMMap getKartIslemlerRefData(GMMap iMap) {
		
		GMMap oMap = new GMMap();

		BigDecimal PTTYT1 = new BigDecimal(0);
		BigDecimal AKTIFBANKYT1 = new BigDecimal(0);

		BigDecimal MASRAFYATANPTTTRY = new BigDecimal(0);
		BigDecimal MASRAFYATANAKTIFBANKTRY = new BigDecimal(0);

		BigDecimal PPTYATANADETTRY = new BigDecimal(0);
		BigDecimal AKTIFBANKYATANADETTRY = new BigDecimal(0);

		BigDecimal IPTALPTTYATANTRY = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANTRY = new BigDecimal(0);

		BigDecimal IPTALMASRAFPTTYATANTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFAKTIFBANKYATANTRY = new BigDecimal(0);

		BigDecimal IPTALPTTYATANADETTRY = new BigDecimal(0);
		BigDecimal IPTALBANKAYATANADETTRY = new BigDecimal(0);

		GMMap oMapOnlyMutabakatsiz = new GMMap();

		try {
			int i = 1;

			oMap.put("CBS_AKTIFBANK_PTT", GMServiceExecuter.execute("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_KART_ISLEMLER_REF", iMap).get("CBS_AKTIFBANK"));
			String tableName = "CBS_AKTIFBANK_PTT";
			i = oMap.getSize(tableName);
			int j = 0;

			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_KART_ISLEMLER_REF", iMap));

			// mutabakats�zlarla mutabakatl� olanlar� merge ediyor, tablo listesini olusturuyor
			String tableName2 = "CBS_AKTIFBANK_PTT";
			tableName = "CBS_AKTIFBANK_PTT_MUTABAKATSIZ";
			for (j = 0; j < iMap.getSize(tableName); j++) {
				
				oMap.put(tableName2, i, "ISLEM_TURU_PTT", iMap.getString(tableName, j, "ISLEM_TURU_PTT"));
				oMap.put(tableName2, i, "PTT_ISLEM_TUTARI", iMap.getString(tableName, j, "PTT_ISLEM_TUTARI"));
				oMap.put(tableName2, i, "PTT_MASRAF_TUTARI", iMap.getString(tableName, j, "PTT_MASRAF_TUTARI"));
				oMap.put(tableName2, i, "ISLEM_NO_PTT", iMap.getString(tableName, j, "ISLEM_NO_PTT"));
				oMap.put(tableName2, i, "PTT_TOPLAM_TUTAR", iMap.getString(tableName, j, "PTT_TOPLAM_TUTAR"));
				oMap.put(tableName2, i, "NUMARA", iMap.getString(tableName, j, "NUMARA")); // ISLEMNOBANKA
				oMap.put(tableName2, i, "ISLEM_KOD", iMap.getString(tableName, j, "ISLEM_KOD"));
				oMap.put(tableName2, i, "MASRAF", iMap.getString(tableName, j, "MASRAF"));
				oMap.put(tableName2, i, "TUTAR", iMap.getString(tableName, j, "TUTAR"));
				oMap.put(tableName2, i, "TOPLAM_TUTAR", iMap.getString(tableName, j, "TOPLAM_TUTAR"));

				i++;
			}

			for (j = 0; j < oMap.getSize(tableName2); j++) {
				// ptt islemi ise ptt hesapla
				if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null) {

					if (!"IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
						PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						PPTYATANADETTRY = PPTYATANADETTRY.add(new BigDecimal(1));
						MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
					}

					if ("IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
						IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_ISLEM_TUTARI"));
						IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName2, j, "PTT_MASRAF_TUTARI"));
						IPTALPTTYATANADETTRY = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
					}
				}

				// AKTIFBANKISLEMLERI, aktifbank islem bilgileri hesapla
				if (oMap.getString(tableName2, j, "ISLEM_TIP") != null) {

					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null && !"IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
						AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
						AKTIFBANKYATANADETTRY = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
						MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
					}

					if (oMap.getString(tableName2, j, "ISLEM_TURU_PTT") != null && "IPTAL".equals(oMap.getString(tableName2, j, "ISLEM_TURU_PTT"))) {
						IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "TUTAR"));
						IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName2, j, "MASRAF"));
						IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));
					}
				}
			}

			oMap.put("MASRAFYATANPTTTRY", MASRAFYATANPTTTRY);
			oMap.put("MASRAFYATANAKTIFBANKTRY", MASRAFYATANAKTIFBANKTRY);
			oMap.put("PPTYATANADETTRY", PPTYATANADETTRY);
			oMap.put("AKTIFBANKYATANADETTRY", AKTIFBANKYATANADETTRY);
			oMap.put("IPTALPTTYATANTRY", IPTALPTTYATANTRY);
			oMap.put("IPTALAKTIFBANKYATANTRY", IPTALAKTIFBANKYATANTRY);
			oMap.put("IPTALMASRAFPTTYATANTRY", IPTALMASRAFPTTYATANTRY);
			oMap.put("IPTALMASRAFAKTIFBANKYATANTRY", IPTALMASRAFAKTIFBANKYATANTRY);
			oMap.put("IPTALPTTYATANADETTRY", IPTALPTTYATANADETTRY);
			oMap.put("IPTALBANKAYATANADETTRY", IPTALBANKAYATANADETTRY);

			BigDecimal PTT_BORC_TL = new BigDecimal(0);
			BigDecimal BANKA_BORC_TL = new BigDecimal(0);
			BigDecimal TOPLAMYATANIPTALPTTTRY = IPTALPTTYATANTRY.add(IPTALMASRAFPTTYATANTRY);
			BigDecimal TOPLAMYATANAKTIFBANKIPTALTRY = IPTALAKTIFBANKYATANTRY.add(IPTALMASRAFAKTIFBANKYATANTRY);

			// iptaller eklendi
			PTTYT1 = PTTYT1.add(TOPLAMYATANIPTALPTTTRY);
			AKTIFBANKYT1 = AKTIFBANKYT1.add(TOPLAMYATANAKTIFBANKIPTALTRY);

			oMap.put("PTTYT1", PTTYT1);
			oMap.put("AKTIFBANKYT1", AKTIFBANKYT1);

			BigDecimal TOPLAMYATANPTTTRY = PTTYT1.add(MASRAFYATANPTTTRY);
			BigDecimal TOPLAMYATANAKTIFBANKTRY = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY);

			oMap.put("TOPLAMYATANPTTTRY", TOPLAMYATANPTTTRY);
			oMap.put("TOPLAMYATANAKTIFBANKTRY", TOPLAMYATANAKTIFBANKTRY);

			oMap.put("TOPLAMYATANIPTALPTTTRY", TOPLAMYATANIPTALPTTTRY);
			oMap.put("TOPLAMYATANAKTIFBANKIPTALTRY", TOPLAMYATANAKTIFBANKIPTALTRY);

			PTT_BORC_TL = PTTYT1.subtract(IPTALPTTYATANTRY).add(MASRAFYATANPTTTRY).subtract(IPTALMASRAFPTTYATANTRY);

			oMap.put("BORC_TL_PTT", PTT_BORC_TL);
			oMap.put("BORC_TL_BANKA", BANKA_BORC_TL);

			// BU KONTROL BLOGU KALDIRILIRSA MUTABAKATLILARDA LISTELENECEK
			if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("true") == 0) {
				iMap.put("ONLY_MUTABAKATSIZ", "Y");
				oMapOnlyMutabakatsiz.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_KART_ISLEMLER_REF", iMap));

				if (oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT") > 0) {
					oMap.putAll(oMapOnlyMutabakatsiz);
				}
				else {
					oMap.remove("CBS_AKTIFBANK_PTT"); // SONUC_LIST
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_PTTMATIK_REF")
	public static GMMap getSecondLevelAktifPttMatikRef(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			String func = "{ ? = call PKG_RC2052.Rc_2nd_Lvl_Akt_ATM_NY(?) }";
			Object[] inputValues = new Object[2];
			int i = 0;
			inputValues[i++] = BnsprType.DATE;
			if(iMap.get("TARIH")!=null)
				inputValues[i++] = new Date(iMap.getDate("TARIH").getTime());
			else 
				inputValues[i++] = null;
			oMap = DALUtil.callOracleRefCursorFunction(func, "CBS_AKTIFBANK", inputValues);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_KART_ISLEMLER_REF")
	public static GMMap getSecondLevelAktifKartIslemlerRef(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			String func = "{ ? = call PKG_RC2052.Rc_2nd_Lvl_Akt_TFF_NY(?) }";
			Object[] inputValues = new Object[2];
			int i = 0;
			inputValues[i++] = BnsprType.DATE;
			if(iMap.get("TARIH")!=null)
				inputValues[i++] = new Date(iMap.getDate("TARIH").getTime());
			else 
				inputValues[i++] = null;
			oMap = DALUtil.callOracleRefCursorFunction(func, "CBS_AKTIFBANK", inputValues);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_PTTMATIK_REF")
	public static GMMap getMutabakatsizIslemlerPttMatikRef(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			String func = "{ ? = call PKG_RC2052.Agreement_Res_ATM_NY(?) }";
			Object[] inputValues = new Object[2];
			int i = 0;
			inputValues[i++] = BnsprType.DATE;
			if(iMap.get("TARIH")!=null)
				inputValues[i++] = new Date(iMap.getDate("TARIH").getTime());
			else 
				inputValues[i++] = null;
			if("Y".equals(iMap.getString("ONLY_MUTABAKATSIZ"))){
				oMap = DALUtil.callOracleRefCursorFunction(func, "CBS_AKTIFBANK_PTT", inputValues);
			}
			else
				oMap = DALUtil.callOracleRefCursorFunction(func, "CBS_AKTIFBANK_PTT_MUTABAKATSIZ", inputValues);  // default 

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_KART_ISLEMLER_REF")
	public static GMMap getMutabakatsizIslemlerKartIslemlerRef(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			String func = "{ ? = call PKG_RC2052.Agreement_Res_TFF_NY(?) }";
			Object[] inputValues = new Object[2];
			int i = 0;
			inputValues[i++] = BnsprType.DATE;
			if(iMap.get("TARIH")!=null)
				inputValues[i++] = new Date(iMap.getDate("TARIH").getTime());
			else 
				inputValues[i++] = null;
			if("Y".equals(iMap.getString("ONLY_MUTABAKATSIZ"))){
				oMap = DALUtil.callOracleRefCursorFunction(func, "CBS_AKTIFBANK_PTT", inputValues);
			}
			else
				oMap = DALUtil.callOracleRefCursorFunction(func, "CBS_AKTIFBANK_PTT_MUTABAKATSIZ", inputValues);  // default 

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_ISLEMLER_PTTMATIK_REF")
	public static GMMap getIslemlerPttMatikRef(GMMap iMap){
		GMMap oMap = new GMMap();
		
		BigDecimal PTT_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_TRY=new BigDecimal(0);
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		

		try{
			int j=0;
			
				
			for (int i=0;i<iMap.getSize("ISLEM_LIST");i++){

				if((iMap.getString("ISLEM_TIP").equals("2048") && iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT").equals("ATM Karta Nakit Yatirma"))
					|| (iMap.getString("ISLEM_TIP").equals(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT")))) {
					
					oMap.put("SONUC_LIST", j, "ISLEM_TIP", iMap.getString("ISLEM_LIST", i, "ISLEM_KOD"));
					oMap.put("SONUC_LIST", j, "ISLEM_NO_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_NO_PTT"));
					oMap.put("SONUC_LIST", j, "ISLEM_TURU_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF", iMap.getString("ISLEM_LIST", i, "MASRAF"));
					oMap.put("SONUC_LIST", j, "NUMARA", iMap.getString("ISLEM_LIST", i, "NUMARA"));
					oMap.put("SONUC_LIST", j, "PTT_ISLEM_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_MASRAF_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "PTT_TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "TUTAR", iMap.getString("ISLEM_LIST", i, "TUTAR"));
					
					if ( iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT") != null ){
						PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
						PTT_ISLEM_ADET_TRY = PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
					    PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							
					}	
					if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
						BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));	
						BANKA_ISLEM_ADET_TRY = BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
						BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
					}
						
					j++;
				
				}	
			}

			PTT_GENEL_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY);
			BANKA_GENEL_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY);
			
			oMap.put("PTT_ISLEM_TOPLAM_TRY", PTT_ISLEM_TOPLAM_TRY);
			oMap.put("PTT_MASRAF_TOPLAM_TRY", PTT_MASRAF_TOPLAM_TRY);
			oMap.put("PTT_GENEL_TOPLAM_TRY", PTT_GENEL_TOPLAM_TRY);
			oMap.put("PTT_ISLEM_ADET_TRY", PTT_ISLEM_ADET_TRY);
			
			oMap.put("BANKA_ISLEM_TOPLAM_TRY", BANKA_ISLEM_TOPLAM_TRY);
			oMap.put("BANKA_MASRAF_TOPLAM_TRY", BANKA_MASRAF_TOPLAM_TRY);
			oMap.put("BANKA_GENEL_TOPLAM_TRY", BANKA_GENEL_TOPLAM_TRY);
			oMap.put("BANKA_ISLEM_ADET_TRY", BANKA_ISLEM_ADET_TRY);	

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_ISLEMLER_KART_ISLEMLER_REF")
	public static GMMap getIslemlerKartIslemlerRef(GMMap iMap){
		GMMap oMap = new GMMap();
		
		BigDecimal PTT_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_TRY=new BigDecimal(0);
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		

		try{
			int j=0;
			
				
			for (int i=0;i<iMap.getSize("ISLEM_LIST");i++){

				if(iMap.getString("ISLEM_TIP").equals(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"))) {
					
					oMap.put("SONUC_LIST", j, "ISLEM_TIP", iMap.getString("ISLEM_LIST", i, "ISLEM_KOD"));
					oMap.put("SONUC_LIST", j, "ISLEM_NO_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_NO_PTT"));
					oMap.put("SONUC_LIST", j, "ISLEM_TURU_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF", iMap.getString("ISLEM_LIST", i, "MASRAF"));
					oMap.put("SONUC_LIST", j, "NUMARA", iMap.getString("ISLEM_LIST", i, "NUMARA"));
					oMap.put("SONUC_LIST", j, "PTT_ISLEM_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_MASRAF_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "PTT_TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "TUTAR", iMap.getString("ISLEM_LIST", i, "TUTAR"));
					
					if ( iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT") != null ){
						PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
						PTT_ISLEM_ADET_TRY = PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
						PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							
					}	
					if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null){
						BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "TUTAR"));	
						BANKA_ISLEM_ADET_TRY = BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
						BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "MASRAF"));
					}
						
					j++;
				
				}	
			}

			PTT_GENEL_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY);
			BANKA_GENEL_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY);
			
			oMap.put("PTT_ISLEM_TOPLAM_TRY", PTT_ISLEM_TOPLAM_TRY);
			oMap.put("PTT_MASRAF_TOPLAM_TRY", PTT_MASRAF_TOPLAM_TRY);
			oMap.put("PTT_GENEL_TOPLAM_TRY", PTT_GENEL_TOPLAM_TRY);
			oMap.put("PTT_ISLEM_ADET_TRY", PTT_ISLEM_ADET_TRY);
			
			oMap.put("BANKA_ISLEM_TOPLAM_TRY", BANKA_ISLEM_TOPLAM_TRY);
			oMap.put("BANKA_MASRAF_TOPLAM_TRY", BANKA_MASRAF_TOPLAM_TRY);
			oMap.put("BANKA_GENEL_TOPLAM_TRY", BANKA_GENEL_TOPLAM_TRY);
			oMap.put("BANKA_ISLEM_ADET_TRY", BANKA_ISLEM_ADET_TRY);	

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}


	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_PCH_DATA")
	public static GMMap getPCHData(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		GMMap oMapOnlyMutabakatsiz = new GMMap();
		
		BigDecimal PTTYT1 = new BigDecimal(0);
		BigDecimal MASRAFYATANPTTTRY = new BigDecimal(0);
		BigDecimal PPTYATANADETTRY = new BigDecimal(0);
		BigDecimal IPTALPTTYATANTRY = new BigDecimal(0);
		BigDecimal IPTALMASRAFPTTYATANTRY = new BigDecimal(0);
		BigDecimal IPTALPTTYATANADETTRY = new BigDecimal(0);
		
		BigDecimal AKTIFBANKYT1 = new BigDecimal(0);
		BigDecimal MASRAFYATANAKTIFBANKTRY = new BigDecimal(0);
		BigDecimal AKTIFBANKYATANADETTRY = new BigDecimal(0);
		BigDecimal IPTALAKTIFBANKYATANTRY = new BigDecimal(0);		
		BigDecimal IPTALMASRAFAKTIFBANKYATANTRY = new BigDecimal(0);
		BigDecimal IPTALBANKAYATANADETTRY = new BigDecimal(0);
		
		int i = 1;
		int j = 0;
		String tableName = "CBS_AKTIFBANK_PTT";
		String tableNameMutabakatsiz = "CBS_AKTIFBANK_PTT_MUTABAKATSIZ";

		try {
			
			oMap.put(tableName, GMServiceExecuter.execute("BNSPR_QRY2052_RC_QRY_GET_2ST_LVL_AKTIF_PCH", iMap).get("CBS_AKTIFBANK"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_PCH", iMap));
			i = oMap.getSize(tableName);
			
			for (j = 0; j < iMap.getSize(tableNameMutabakatsiz); j++) {
				
				oMap.put(tableName, i, "ISLEM_TURU_PTT", iMap.getString(tableNameMutabakatsiz, j, "ISLEM_TURU_PTT"));
				oMap.put(tableName, i, "PTT_ISLEM_TUTARI", iMap.getString(tableNameMutabakatsiz, j, "PTT_ISLEM_TUTARI"));
				oMap.put(tableName, i, "PTT_MASRAF_TUTARI", iMap.getString(tableNameMutabakatsiz, j, "PTT_MASRAF_TUTARI"));
				oMap.put(tableName, i, "ISLEM_NO_PTT", iMap.getString(tableNameMutabakatsiz, j, "ISLEM_NO_PTT"));
				oMap.put(tableName, i, "NUMARA", iMap.getString(tableNameMutabakatsiz, j, "NUMARA"));
				oMap.put(tableName, i, "PTT_DOVIZ_KODU", iMap.getString(tableNameMutabakatsiz, j, "PTT_DOVIZ_KODU"));
				oMap.put(tableName, i, "EFT_HESAP_KASA", iMap.getString(tableNameMutabakatsiz, j, "EFT_HESAP_KASA"));
				oMap.put(tableName, i, "ISLEM", iMap.getString(tableNameMutabakatsiz, j, "ISLEM"));
				oMap.put(tableName, i, "PTT_TOPLAM_TUTAR", iMap.getString(tableNameMutabakatsiz, j, "PTT_TOPLAM_TUTAR"));
				oMap.put(tableName, i, "ISLEM_ADI_PTT", iMap.getString(tableNameMutabakatsiz, j, "ISLEM_ADI_PTT"));
				oMap.put(tableName, i, "MASRAF_DOVIZ_KODU", iMap.getString(tableNameMutabakatsiz, j, "MASRAF_DOVIZ_KODU"));
				oMap.put(tableName, i, "KAYNAK_KANAL", iMap.getString(tableNameMutabakatsiz, j, "KAYNAK_KANAL"));
				i++;
			}

			for (j = 0; j < oMap.getSize(tableName); j++) {

				// Case: PTT Yatan
				if ("TRY".equals(oMap.getString(tableName, j, "PTT_DOVIZ_KODU"))) {
					PTTYT1 = PTTYT1.add(oMap.getBigDecimal(tableName, j, "PTT_ISLEM_TUTARI"));
					PPTYATANADETTRY = PPTYATANADETTRY.add(new BigDecimal(1));
				}

				// Case: PTT Yatan Masraf
				if ("TRY".equals(oMap.getString(tableName, j, "MASRAF_DOVIZ_KODU"))) {
					MASRAFYATANPTTTRY = MASRAFYATANPTTTRY.add(oMap.getBigDecimal(tableName, j, "PTT_MASRAF_TUTARI"));
				}

				// Case: PTT Iptal Yatan 
				if ("IPTAL".equals(oMap.getString(tableName, j, "ISLEM_TURU_PTT"))) {

					if (oMap.getString(tableName, j, "PTT_DOVIZ_KODU") != null) {

						if ("TRY".equals(oMap.getString(tableName, j, "PTT_DOVIZ_KODU"))) {
							IPTALPTTYATANTRY = IPTALPTTYATANTRY.add(oMap.getBigDecimal(tableName, j, "PTT_ISLEM_TUTARI"));
							IPTALPTTYATANADETTRY = IPTALPTTYATANADETTRY.add(new BigDecimal(1));
						}

						if ("TRY".equals(oMap.getString(tableName, j, "MASRAF_DOVIZ_KODU"))) {
							IPTALMASRAFPTTYATANTRY = IPTALMASRAFPTTYATANTRY.add(oMap.getBigDecimal(tableName, j, "PTT_MASRAF_TUTARI"));
						}
					}
				}

				// Case: Aktifbank Islemler
				if (oMap.getString(tableName, j, "ISLEM_KOD") != null) {

					// Case: Aktifbank Yatan
					if ("TRY".equals(oMap.getString(tableName, j, "PTT_DOVIZ_KODU"))) {
						AKTIFBANKYT1 = AKTIFBANKYT1.add(oMap.getBigDecimal(tableName, j, "TUTAR"));
						AKTIFBANKYATANADETTRY = AKTIFBANKYATANADETTRY.add(new BigDecimal(1));
					}

					// Case: Aktifbank Yatan Masraflar
					if ("TRY".equals(oMap.getString(tableName, j, "MASRAF_DOVIZ_KODU"))) {
						MASRAFYATANAKTIFBANKTRY = MASRAFYATANAKTIFBANKTRY.add(oMap.getBigDecimal(tableName, j, "MASRAF"));
					}
					
					// Case: Aktifbank Iptal Yatan 
					if ("IPTAL".equals(oMap.getString(tableName, j, "ISLEM_TURU_PTT"))) {
						
						if ("TRY".equals(oMap.getString(tableName, j, "PTT_DOVIZ_KODU"))) {
							IPTALAKTIFBANKYATANTRY = IPTALAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName, j, "TUTAR"));
							IPTALBANKAYATANADETTRY = IPTALBANKAYATANADETTRY.add(new BigDecimal(1));
						}

						if ("TRY".equals(oMap.getString(tableName, j, "MASRAF_DOVIZ_KODU"))) {
							IPTALMASRAFAKTIFBANKYATANTRY = IPTALMASRAFAKTIFBANKYATANTRY.add(oMap.getBigDecimal(tableName, j, "PTT_MASRAF_TUTARI"));
						}
					}
				}
			}
			
			BigDecimal TOPLAMYATANPTTTRY =   PTTYT1.add(MASRAFYATANPTTTRY);
		    BigDecimal TOPLAMYATANAKTIFBANKTRY = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY);
		    BigDecimal PTT_BORC_TL =  new BigDecimal(0);
			BigDecimal AKTIFBANK_BORC_TL =  new BigDecimal(0);
			
			oMap.put("PTTYT1", PTTYT1);
			oMap.put("MASRAFYATANPTTTRY", MASRAFYATANPTTTRY);
			oMap.put("PPTYATANADETTRY", PPTYATANADETTRY);
			oMap.put("IPTALPTTYATANTRY", IPTALPTTYATANTRY)  ;
			oMap.put("TOPLAMYATANPTTTRY", TOPLAMYATANPTTTRY)  ;
			
			oMap.put("AKTIFBANKYT1", AKTIFBANKYT1);
			oMap.put("MASRAFYATANAKTIFBANKTRY", MASRAFYATANAKTIFBANKTRY);
			oMap.put("AKTIFBANKYATANADETTRY", AKTIFBANKYATANADETTRY);
			oMap.put("IPTALAKTIFBANKYATANTRY", IPTALAKTIFBANKYATANTRY);
			oMap.put("TOPLAMYATANAKTIFBANKTRY", TOPLAMYATANAKTIFBANKTRY);
		    
		    oMap.put("IPTALMASRAFPTTYATANTRY", IPTALMASRAFPTTYATANTRY);
		    oMap.put("IPTALMASRAFAKTIFBANKYATANTRY", IPTALMASRAFAKTIFBANKYATANTRY) ;
		    oMap.put("IPTALPTTYATANADETTRY", IPTALPTTYATANADETTRY);
		    oMap.put("IPTALBANKAYATANADETTRY", IPTALBANKAYATANADETTRY);
			
			PTT_BORC_TL = PTTYT1.add(MASRAFYATANPTTTRY).subtract(IPTALPTTYATANTRY).subtract(IPTALMASRAFPTTYATANTRY);
			 
			oMap.put("BORC_TL_PTT", PTT_BORC_TL);
			oMap.put("BORC_TL_BANKA", 0);
			
			if  (PTT_BORC_TL.intValue() < 0) {
				AKTIFBANK_BORC_TL = PTT_BORC_TL;
				oMap.put("BORC_TL_BANKA", AKTIFBANK_BORC_TL);
				oMap.put("BORC_TL_PTT", "0");
			}
			
			AKTIFBANK_BORC_TL = AKTIFBANKYT1.add(MASRAFYATANAKTIFBANKTRY).subtract(IPTALAKTIFBANKYATANTRY).subtract(IPTALMASRAFAKTIFBANKYATANTRY);	
			
			GMMap sMap = new GMMap();
			
			sMap.put("TARIH", iMap.get("TARIH"));
			sMap.put("AKTIFBANK_BORC_TL", AKTIFBANK_BORC_TL);
			sMap.put("PTT_BORC_TL", PTT_BORC_TL);
			
			if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("true")==0){
				oMapOnlyMutabakatsiz.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_PCH", iMap));
				
				oMap.put("KAYIT_SAYISI", oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT"));
				
				if (oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT")>0){
					oMap.putAll(oMapOnlyMutabakatsiz);
				} else {
					oMap.remove("CBS_AKTIFBANK_PTT");
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}

	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_2ST_LVL_AKTIF_PCH")
	public static GMMap getSecondLevelAktifPCH(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.Rc_Qry_Get_2nd_Lvl_Akt_PCH(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.get("TARIH") != null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_PCH")
	public static GMMap getMutabakatsizIslemlerPCH(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.Agreement_Response_PCH(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.get("TARIH") != null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			// if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("1")==0){
			// oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
			// }else{
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT_MUTABAKATSIZ");
			// }
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_PCH")
	public static GMMap getMutabakatOnlyMutabatsizPCH(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.Agreement_Response_PCH(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
						
			if(iMap.get("TARIH")!=null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else 
				stmt.setDate(i, null);
			
			stmt.execute();
			
			rSet= (ResultSet)stmt.getObject(1);
			
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");
				
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	/**
	 * DESC : PCH (Posta �eki Hesabi) Iade Mutabakatinda, banka kayitlari esas alinir. 
	 *
	 * @param iMap (GMMap)
	 *
	 * @return oMap (GMMap)
	 */
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_PCH_REF_DATA")
	public static GMMap get_PCH_REF_Data(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		GMMap oMapOnlyMutabakatsiz = new GMMap();

		BigDecimal pttbankCT1 = new BigDecimal(0);
		BigDecimal PTTCEKILENADETTRY = new BigDecimal(0);
		
		BigDecimal AKTIFBANKCT1 = new BigDecimal(0);
		BigDecimal AKTIFBANKCEKILENADETTRY = new BigDecimal(0);
	
		
		int i = 1;
		int j = 0;
		String tableName = "CBS_AKTIFBANK_PTT";
		String tableNameMutabakatsiz = "CBS_AKTIFBANK_PTT_MUTABAKATSIZ";

		try {
			
			oMap.put(tableName, GMServiceExecuter.execute("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_PCH_REF", iMap).get("CBS_AKTIFBANK"));
			iMap.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_PCH_REF", iMap));
			i = oMap.getSize(tableName);
			
			for (j = 0; j < iMap.getSize(tableNameMutabakatsiz); j++) {

				oMap.put(tableName, i, "ISLEM_TURU_PTT", iMap.getString(tableNameMutabakatsiz, j, "ISLEM_TURU_PTT"));
				oMap.put(tableName, i, "ISLEM_KOD", iMap.getString(tableNameMutabakatsiz, j, "ISLEM_KOD"));
				oMap.put(tableName, i, "NUMARA", iMap.getString(tableNameMutabakatsiz, j, "NUMARA"));
				oMap.put(tableName, i, "TUTAR", iMap.getString(tableNameMutabakatsiz, j, "TUTAR"));
				oMap.put(tableName, i, "EFT_HESAP_KASA", iMap.getString(tableNameMutabakatsiz, j, "EFT_HESAP_KASA"));
				oMap.put(tableName, i, "ISLEM", iMap.getString(tableNameMutabakatsiz, j, "ISLEM"));
				oMap.put(tableName, i, "ISLEM_ADI_PTT", iMap.getString(tableNameMutabakatsiz, j, "ISLEM_ADI_PTT"));

				i++;
			}
			
			for (j = 0; j < oMap.getSize(tableName); j++) { 

				// Case: PTT Cekilen (Iade PCH)
				if (oMap.get(tableName, j, "PTT_ISLEM_TUTARI") != null) {

						pttbankCT1 = pttbankCT1.add(oMap.getBigDecimal(tableName, j, "PTT_ISLEM_TUTARI"));
						PTTCEKILENADETTRY = PTTCEKILENADETTRY.add(new BigDecimal(1));
				}
				
				// Case: Aktifbank Islemler
				if (oMap.getString(tableName, j, "ISLEM_KOD") != null) {

					// Case: Aktifbank Cekilen
					AKTIFBANKCT1 = AKTIFBANKCT1.add(oMap.getBigDecimal(tableName, j, "TUTAR"));
					AKTIFBANKCEKILENADETTRY = AKTIFBANKCEKILENADETTRY.add(new BigDecimal(1));
				}
			}
			
			BigDecimal PTT_BORC_TL = new BigDecimal(0);
			BigDecimal AKTIFBANK_BORC_TL = new BigDecimal(0);
			BigDecimal TOPLAMCEKILENPTTTRY = pttbankCT1;
			BigDecimal TOPLAMCEKILENAKTIFBANKTRY = AKTIFBANKCT1;
			AKTIFBANK_BORC_TL = AKTIFBANKCT1;
			
			oMap.put("pttbankCT1", pttbankCT1);
			oMap.put("PTTCEKILENADETTRY", PTTCEKILENADETTRY);
			oMap.put("TOPLAMCEKILENPTTTRY", TOPLAMCEKILENPTTTRY);
			
			oMap.put("AKTIFBANKCT1", AKTIFBANKCT1);
			oMap.put("AKTIFBANKCEKILENADETTRY", AKTIFBANKCEKILENADETTRY);
			oMap.put("TOPLAMCEKILENAKTIFBANKTRY", TOPLAMCEKILENAKTIFBANKTRY);

			oMap.put("BORC_TL_PTT", PTT_BORC_TL);
			oMap.put("BORC_TL_BANKA", AKTIFBANK_BORC_TL);

			if (iMap.getString("MUTABAKATSIZ") != null && iMap.getString("MUTABAKATSIZ").compareTo("true") == 0) {
				oMapOnlyMutabakatsiz.putAll(GMServiceExecuter.execute("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_PCH_REF", iMap));

				oMap.put("KAYIT_SAYISI", oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT"));

				if (oMapOnlyMutabakatsiz.getSize("CBS_AKTIFBANK_PTT") > 0) {
					oMap.putAll(oMapOnlyMutabakatsiz);
				}
				
				else {
					oMap.remove("CBS_AKTIFBANK_PTT"); // SONUC_LIST
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_2ST_LEVEL_AKTIF_PCH_REF")
	public static GMMap getSecondLevelAktif_PCH_REF(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.Rc_2nd_Level_Akt_PCH_Iade(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.get("TARIH") != null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_QRY2052_RC_MUTABAKATSIZLAR_PCH_REF")
	public static GMMap getMutabakatsizIslemler_PCH_REF(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052. Agreement_Res_PCH_Iade(?) }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.get("TARIH") != null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i, null);

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT_MUTABAKATSIZ");
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2052_RC_ONLY_MUTABAKATSIZLAR_PCH_REF")
	public static GMMap getMutabakatOnlyMutabatsiz_PCH_REF(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC2052.Agreement_Res_PCH_Iade(?)  }");
			int i = 1;
			stmt.registerOutParameter(i++, -10);

			if (iMap.get("TARIH") != null)
				stmt.setDate(i, new Date(iMap.getDate("TARIH").getTime()));
			else
				stmt.setDate(i, null);

			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);

			oMap = DALUtil.rSetResults(rSet, "CBS_AKTIFBANK_PTT");

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	@GraymoundService("BNSPR_QRY2052_RC_QRY_GET_ISLEMLER_PCH")
	public static GMMap Get_Islemler_PCH(GMMap iMap){
		GMMap oMap = new GMMap();
		
		BigDecimal PTT_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal PTT_ISLEM_ADET_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_MASRAF_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_GENEL_TOPLAM_TRY=new BigDecimal(0);
		BigDecimal BANKA_ISLEM_ADET_TRY=new BigDecimal(0);
		
		try{
			int j=0;
			
			for (int i=0; i<iMap.getSize("ISLEM_LIST"); i++){
				
				if(iMap.getString("ISLEM_TIPI").compareTo(iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"))==0) {
					
					oMap.put("SONUC_LIST", j, "ANAISLEMDURUM", iMap.getString("ISLEM_LIST", i, "ANAISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "EFT_HESAP_KASA", iMap.getString("ISLEM_LIST", i, "EFT_HESAP_KASA"));
					oMap.put("SONUC_LIST", j, "IPTALISLEMDURUM", iMap.getString("ISLEM_LIST", i, "IPTALISLEMDURUM"));
					oMap.put("SONUC_LIST", j, "ISLEM_KOD", iMap.getString("ISLEM_LIST", i, "ISLEM_KOD"));
					oMap.put("SONUC_LIST", j, "ISLEM_NO_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_NO_PTT"));
					oMap.put("SONUC_LIST", j, "ISLEM_TURU_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_TURU_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF", iMap.getString("ISLEM_LIST", i, "MASRAF"));
					oMap.put("SONUC_LIST", j, "NUMARA", iMap.getString("ISLEM_LIST", i, "NUMARA"));
					oMap.put("SONUC_LIST", j, "PTT_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "PTT_ISLEM_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_MASRAF_TUTARI", iMap.getString("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
					oMap.put("SONUC_LIST", j, "PTT_TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "PTT_TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "PTTISLEMNO", iMap.getString("ISLEM_LIST", i, "PTTISLEMNO"));
					oMap.put("SONUC_LIST", j, "REFERANS", iMap.getString("ISLEM_LIST", i, "REFERANS"));
					oMap.put("SONUC_LIST", j, "TOPLAM_TUTAR", iMap.getString("ISLEM_LIST", i, "TOPLAM_TUTAR"));
					oMap.put("SONUC_LIST", j, "TUTAR", iMap.getString("ISLEM_LIST", i, "TUTAR"));
					oMap.put("SONUC_LIST", j, "ISLEM_ADI_PTT", iMap.getString("ISLEM_LIST", i, "ISLEM_ADI_PTT"));
					oMap.put("SONUC_LIST", j, "MASRAF_DOVIZ_KODU", iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"));
					oMap.put("SONUC_LIST", j, "KAYNAK_KANAL", iMap.getString("ISLEM_LIST", i, "KAYNAK_KANAL"));
					
					if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "PTT_DOVIZ_KODU"))) {

						PTT_ISLEM_TOPLAM_TRY = PTT_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));
						PTT_ISLEM_ADET_TRY = PTT_ISLEM_ADET_TRY.add(new BigDecimal("1"));
					
						if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))) {
							
							PTT_MASRAF_TOPLAM_TRY = PTT_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
						}
					
						if (iMap.getString("ISLEM_LIST", i, "ISLEM_KOD") != null) {
							
							BANKA_ISLEM_TOPLAM_TRY = BANKA_ISLEM_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_ISLEM_TUTARI"));	
							BANKA_ISLEM_ADET_TRY = BANKA_ISLEM_ADET_TRY.add(new BigDecimal("1"));
						
							if ("TRY".equals(iMap.getString("ISLEM_LIST", i, "MASRAF_DOVIZ_KODU"))) {
								
								BANKA_MASRAF_TOPLAM_TRY = BANKA_MASRAF_TOPLAM_TRY.add(iMap.getBigDecimal("ISLEM_LIST", i, "PTT_MASRAF_TUTARI"));
							}							
						}
					}
					
					j++;	
				}
			}	

			PTT_GENEL_TOPLAM_TRY = PTT_GENEL_TOPLAM_TRY.add(PTT_MASRAF_TOPLAM_TRY).add(PTT_ISLEM_TOPLAM_TRY);
			BANKA_GENEL_TOPLAM_TRY = BANKA_GENEL_TOPLAM_TRY.add(BANKA_MASRAF_TOPLAM_TRY).add(BANKA_ISLEM_TOPLAM_TRY);
			
			oMap.put("PTT_ISLEM_TOPLAM_TRY", PTT_ISLEM_TOPLAM_TRY);
			oMap.put("PTT_MASRAF_TOPLAM_TRY", PTT_MASRAF_TOPLAM_TRY);
			oMap.put("PTT_GENEL_TOPLAM_TRY", PTT_GENEL_TOPLAM_TRY);
			oMap.put("PTT_ISLEM_ADET_TRY", PTT_ISLEM_ADET_TRY);
			
			oMap.put("BANKA_ISLEM_TOPLAM_TRY", BANKA_ISLEM_TOPLAM_TRY);
			oMap.put("BANKA_MASRAF_TOPLAM_TRY", BANKA_MASRAF_TOPLAM_TRY);
			oMap.put("BANKA_GENEL_TOPLAM_TRY", BANKA_GENEL_TOPLAM_TRY);
			oMap.put("BANKA_ISLEM_ADET_TRY", BANKA_ISLEM_ADET_TRY);	
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/*
	@GraymoundService("BNSPR_RC_QRY2052_HAVALE_GIRIS")
	public static GMMap bnsprRcQry2052HavaleGiris(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		Object [] inputValues = new Object[4];
		String list = "RESULTSET";
		
		try {
			
			inputValues[0] = BnsprType.DATE;
			inputValues[1] = iMap.getDate("TARIH");
			inputValues[2] = BnsprType.NUMBER;
			inputValues[3] = iMap.getBigDecimal("LISTELEME_TIPI");
			
			oMap = DALUtil.callOracleRefCursorFunction("{? = call pkg_rc2052.rc_qry2052_havale_giris(?,?)}", list, inputValues);
		}
		
		catch(Exception e) {
			
			logger.error("BNSPR_RC_QRY2052_HAVALE_GIRIS err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_RC_QRY2052_HAVALE_ODEME")
	public static GMMap bnsprRcQry2052HavaleOdeme(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		Object [] inputValues = new Object[4];
		String list = "RESULTSET";
		
		try {
			
			inputValues[0] = BnsprType.DATE;
			inputValues[1] = iMap.getDate("TARIH");
			inputValues[2] = BnsprType.NUMBER;
			inputValues[3] = iMap.getBigDecimal("LISTELEME_TIPI");
			
			oMap = DALUtil.callOracleRefCursorFunction("{call pkg_rc2052.rc_qry2052_havale_odeme(?,?)}", list, inputValues);
		}
		
		catch(Exception e) {
			
			logger.error("BNSPR_RC_QRY2052_HAVALE_ODEME err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_RC_QRY2052_PFT")
	public static GMMap bnsprRcQry2052Pft(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		Object [] inputValues = new Object[4];
		String list = "RESULTSET";
		
		try {
			
			inputValues[0] = BnsprType.DATE;
			inputValues[1] = iMap.getDate("TARIH");
			inputValues[2] = BnsprType.NUMBER;
			inputValues[3] = iMap.getDate("LISTELEME_TIPI");
			
			oMap = DALUtil.callOracleRefCursorFunction("{call pkg_rc2052.rc_qry2052_pft(?,?)}", list, inputValues);
		}
		
		catch(Exception e) {
			
			logger.error("BNSPR_RC_QRY2052_PFT err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_RC_QRY2052_YP_HAVALE_GIDEN")
	public static GMMap bnsprRcQry2052YpHavaleGiden(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		Object [] inputValues = new Object[4];
		String list = "RESULTSET";
		
		try {
			
			inputValues[0] = BnsprType.DATE;
			inputValues[1] = iMap.getDate("TARIH");
			inputValues[2] = BnsprType.NUMBER;
			inputValues[3] = iMap.getBigDecimal("LISTELEME_TIPI");
			
			oMap = DALUtil.callOracleRefCursorFunction("{call pkg_rc2052.rc_qry2052_yp_havale_giden(?,?)}", list, inputValues);
		}
		
		catch(Exception e) {
			
			logger.error("BNSPR_RC_QRY2052_YP_HAVALE_GIDEN err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_RC_QRY2052_MUTABAKAT")
	public static GMMap bnsprRcQry2052_Mutabakatn(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		GMMap sumMap = new GMMap();
		
		try {
			
			iMap.put("LISTELEME_TIPI", 0);
			oMap.putAll(GMServiceExecuter.call("BNSPR_RC_QRY2052_HAVALE_GIRIS", iMap));
			
			iMap.put("LISTELEME_TIPI", 1);
			sumMap.putAll(GMServiceExecuter.call("BNSPR_RC_QRY2052_HAVALE_GIRIS", iMap));
			
		}
		
		catch(Exception e) {
			
			logger.error("BNSPR_RC_QRY2052_MUTABAKAT err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}*/
}
     