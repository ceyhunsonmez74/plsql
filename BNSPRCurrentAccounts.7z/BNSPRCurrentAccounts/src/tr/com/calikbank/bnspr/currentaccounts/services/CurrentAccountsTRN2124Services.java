package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ClksFonislemOnayTx;
import tr.com.aktifbank.bnspr.dao.ClksFonislemOnayTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2124Services {

	@GraymoundService("BNSPR_TRN2124_GET_QUERY")
	public static GMMap getAltinIslemler(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			String tableName = "ONAY_TABLO";
			int i = 0;

			String func = "{? = call  pkg_trn2124.Islem_Kayitlari_Getir(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}";
			Object[] inputValues = new Object[34];

			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("KANAL");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("MUSTERI_NO");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("PTT_ISLEM_NO");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEM");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("DURUM");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("UNVAN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("TCKN");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PTT_MERKEZ");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PTT_SUBE");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("PTT_SICIL");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("MIN_TUTAR");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("MAX_TUTAR");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("MIN_GRAM");
			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("MAX_GRAM");
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("BASTAR");
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("BITTAR");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("DOVIZ");

			GMMap resultMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
			oMap.put("ONAY_TABLO", resultMap.get("ONAY_TABLO"));

			BigDecimal toplamKayit = BigDecimal.ZERO;
			BigDecimal toplamTutar = BigDecimal.ZERO;

			int row = oMap.getSize("ONAY_TABLO");
			for (int j = 0; j < row; j++) {
				toplamKayit = toplamKayit.add(BigDecimal.ONE);
				toplamTutar = toplamTutar.add(oMap.getBigDecimal("ONAY_TABLO", j, "ALTIN_FONU_GRAMI"));
			}
			oMap.put("TOPLAM_KAYIT", toplamKayit);
			oMap.put("TOPLAM_TUTAR", toplamTutar);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN2124_SAVE")
	public static Map<?, ?> save(GMMap iMap) {

		int row = 0;
		String durum = "";

		if (iMap.getString("BUTTON").equals("ONAY"))
			durum = "HAZINE";
		else if (iMap.getString("BUTTON").equals("IPTAL"))
			durum = "HAZINE-IPTAL";
		else if (iMap.getString("BUTTON").equals("RED"))
			durum = "HAZINE-RED";

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			ClksFonislemOnayTx clksFonislemOnayTx = (ClksFonislemOnayTx) session.createCriteria(ClksFonislemOnayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			if (clksFonislemOnayTx == null)
				clksFonislemOnayTx = new ClksFonislemOnayTx();

			ClksFonislemOnayTxId clksFonislemOnayTxId = new ClksFonislemOnayTxId();

			while (row < iMap.getSize("TABLE")) {
				clksFonislemOnayTx = new ClksFonislemOnayTx();
				clksFonislemOnayTxId = new ClksFonislemOnayTxId();
				clksFonislemOnayTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				clksFonislemOnayTxId.setAlimSatimTxNo(iMap.getBigDecimal("TABLE", row, "AKUSTIK_ISLEM_NUMARASI"));
				clksFonislemOnayTx.setId(clksFonislemOnayTxId);
				clksFonislemOnayTx.setDurum(durum);
				clksFonislemOnayTx.setSecili(iMap.getBoolean("TABLE", row, "ONAY") == true ? "E" : "H");
				if(iMap.getString("BUTTON").equals("IPTAL"))
				clksFonislemOnayTx.setAciklama(iMap.getString("TABLE", row, "ACIKLAMA"));
				session.saveOrUpdate(clksFonislemOnayTx);
				row++;

			}

			session.flush();
			
			iMap.put("TRX_NAME", "2124");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN2124_SELECT_TUM_ONAY")
	public static GMMap selectTumOnay(GMMap iMap) {

		int size = iMap.getSize("TABLE");

		for (int row = 0; row < size; row++) {
			iMap.put("TABLE", row, "ONAY", iMap.getBoolean("TUM_ONAY"));
		}

		return iMap;

	}

	@GraymoundService("BNSPR_TRN2124_TARIHCE")
	public static GMMap getTarihce(GMMap iMap) {



		try {

			String tableName = "TARIHCE";
			int i = 0;

			String func = "{? = call  pkg_trn2124.Tarihce(?)}";
			Object[] inputValues = new Object[2];

			inputValues[i++] = BnsprType.NUMBER;
			inputValues[i++] = iMap.getBigDecimal("TX_NO");
			
			return  DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);
		
	
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN2124_GET_QUERY_INITIALIZE")
	public static GMMap getInitialize(GMMap iMap) {

		GMMap oMap = new GMMap();

		int size = iMap.getSize("TABLE");
		int colSize = iMap.getSize("COLUMN_LIST");

		for (int row = 0; row < size; row++) {
			
			for (int colIndex = 0; colIndex < colSize; colIndex++) {
				oMap.put("TABLE", row, iMap.getString("COLUMN_LIST", colIndex, "NAME"), iMap.getString("TABLE", row, iMap.getString("COLUMN_LIST", colIndex, "NAME")));
			}
		}

		return oMap;

	}

}
