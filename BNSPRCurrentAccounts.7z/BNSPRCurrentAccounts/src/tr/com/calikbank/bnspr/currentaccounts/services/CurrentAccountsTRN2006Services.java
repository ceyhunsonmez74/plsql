package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.List;

import org.apache.axis.utils.StringUtils;
import org.datacontract.schemas._2004._07.VeriBranch_Common_MessageDefinitions.RetailCustomerInfoRequest;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhBloke;
import tr.com.calikbank.bnspr.dao.MuhBlokeTx;
import tr.com.calikbank.bnspr.dao.MuhBlokeTxId;
import tr.com.calikbank.bnspr.util.AkustikConstants;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2006Services {

	@GraymoundService("BNSPR_TRN2006_GET_TUTAR")
	public static GMMap getTutar(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN2006.BAKIYE_BILGILERI(?,?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("HESAP_NO"));

			stmt.registerOutParameter(2, Types.DECIMAL);
			stmt.registerOutParameter(3, Types.DECIMAL);
			stmt.registerOutParameter(4, Types.DECIMAL);
			stmt.registerOutParameter(5, Types.DECIMAL);

			stmt.execute();

			GMMap oMap = new GMMap();

			oMap.put("BAKIYE", stmt.getBigDecimal(2));
			oMap.put("KUL_BAKIYE", stmt.getBigDecimal(3));
			oMap.put("TOP_BLOKE", stmt.getBigDecimal(4));
			oMap.put("GORUNSUN", stmt.getBigDecimal(5));

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN2006_GET_TRX_NO")
	public static GMMap getTrxNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN2006.BLOKE_TX_BILGI_AKTAR(?)}");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setString(2, iMap.getString("BLOKE_REF_NO"));
			stmt.execute();
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN2006_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			MuhBlokeTx muhBlokeTx = (MuhBlokeTx) session.createCriteria(MuhBlokeTx.class).add(Restrictions.eq("id.txNo", new BigDecimal((String) iMap.getString("TRX_NO")))).uniqueResult();
			session.refresh(muhBlokeTx);
			oMap.put("ACIKLAMA", muhBlokeTx.getAciklama());
			oMap.put("BLOKE_BITIS_TARIHI", muhBlokeTx.getBlokeBitisTarihi());
			oMap.put("REF_TX_NO", muhBlokeTx.getRefTxNo());
			oMap.put("BLOKE_TARIHI", muhBlokeTx.getBlokeTarihi());
			oMap.put("ISLEM_TANIM_KOD", muhBlokeTx.getIslemTanimKod());
			oMap.put("BLOKEYI_KOYAN", muhBlokeTx.getKayitKullaniciKodu());

			oMap.put("MUSTERI_NO", muhBlokeTx.getMusteriNo());
			oMap.put("DI_MUSTERI_ADI", LovHelper.diLov(muhBlokeTx.getMusteriNo(), "2006/LOV_MUSTERI", "UNVAN"));
			oMap.put("HESAP_NO", muhBlokeTx.getHesapNo());
			oMap.put("DOVIZ_KODU", muhBlokeTx.getDovizKodu());
			oMap.put("ESKI_BLOKE_REFERANS", muhBlokeTx.getEskiBlokeReferans());
			oMap.put("BLOKE_NEDEN_KODU", muhBlokeTx.getBlokeNedenKodu());
			oMap.put("DI_BLOKE_NEDEN_KODU", LovHelper.diLov(muhBlokeTx.getBlokeNedenKodu(), "2006/LOV_BLOKE", "ACIKLAMA"));
			oMap.put("DURUM_KODU", muhBlokeTx.getDurumKodu());
			oMap.put("INTERNAL_REF_NO", muhBlokeTx.getId().getInternalRefNo());
			oMap.put("DI_ESKI_BLOKE_TUTARI", muhBlokeTx.getOncekiBlokeTutari());
			oMap.put("BLOKE_TUTARI", muhBlokeTx.getBlokeTutari());
			String nullStr = null;
			oMap.put("BLOKE_REFERANS", nullStr);
			oMap.put("YENI_BLOKE_REFERANS", muhBlokeTx.getBlokeReferans());

			oMap.put("TOPLAM_BLOKE_TUTARI", muhBlokeTx.getToplamBlokeTutari());
			oMap.put("TOPLAM_BLOKE_TUTARI_X", muhBlokeTx.getToplamBlokeTutari());
			oMap.put("KULL_BAKIYE", muhBlokeTx.getKullBakiye());
			oMap.put("KULL_BAKIYE_X", muhBlokeTx.getKullBakiye());
			oMap.put("BAKIYE", muhBlokeTx.getBakiye());
			oMap.put("BAKIYE_X", muhBlokeTx.getBakiye());

			iMap.put("HESAP_NO", muhBlokeTx.getHesapNo());
			oMap.put("GORUNSUN", GMServiceExecuter.execute("BNSPR_COMMON_BAKIYE_GORUNSUN_MU", iMap).get("GORUNSUN"));

			oMap.put("HBN", muhBlokeTx.getHbn());
			oMap.put("VDKOD", muhBlokeTx.getVdkod());
			oMap.put("DI_VDKOD", LovHelper.diLov(muhBlokeTx.getVdkod(), "2005/LOV_VDKOD", "VERGI_D_ADI"));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN2006_SAVE")
	public static GMMap save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			MuhBlokeTxId id = new MuhBlokeTxId();

			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setInternalRefNo(iMap.getBigDecimal("INTERNAL_REF_NO"));

			MuhBlokeTx muhBlokeTx = (MuhBlokeTx) session.createCriteria(MuhBlokeTx.class).add(Restrictions.eq("id", id)).uniqueResult();

			muhBlokeTx.setBlokeNedenKodu(iMap.getString("BLOKE_NEDEN_KODU"));
			muhBlokeTx.setAciklama(iMap.getString("ACIKLAMA"));
			muhBlokeTx.setBlokeTutari(iMap.getBigDecimal("BLOKE_TUTARI"));
			muhBlokeTx.setBlokeBitisTarihi(iMap.getDate("BLOKE_BITIS_TARIHI"));

			muhBlokeTx.setDurumKodu("BG");
			muhBlokeTx.setIslemTanimKod(new BigDecimal("2006"));
			muhBlokeTx.setToplamBlokeTutari(iMap.getBigDecimal("TOPLAM_BLOKE_TUTARI"));
			muhBlokeTx.setKullBakiye(iMap.getBigDecimal("KULL_BAKIYE"));
			muhBlokeTx.setBakiye(iMap.getBigDecimal("BAKIYE"));

			muhBlokeTx.setHbn(iMap.getString("HBN"));
			muhBlokeTx.setVdkod(iMap.getString("VDKOD"));

			session.saveOrUpdate(muhBlokeTx);
			session.flush();

			iMap.put("TRX_NAME", "2006");

			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	/**
	 * 
	 * @param iMap
	 *            -BLOKE_REF_NO
	 *            -BLOKE_TUTARI
	 *            -BLOKE_NEDEN_KODU
	 *            -ACIKLAMA
	 * @return
	 */
	@GraymoundService("BNSPR_TRN2006_EXTERNAL_SAVE")
	public static GMMap externalSave(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GMMap sMap = new GMMap();

			Session session = DAOSession.getSession("BNSPRDal");
			MuhBloke muhBloke = (MuhBloke) session.createCriteria(MuhBloke.class).add(Restrictions.eq("internalRefNo", iMap.getBigDecimal("BLOKE_REF_NO"))).uniqueResult();

			sMap.put("BLOKE_REF_NO", muhBloke.getBlokeReferans());
			GMMap rMap = GMServiceExecuter.call("BNSPR_TRN2006_GET_TRX_NO", sMap);

			sMap.clear();
			sMap.put("TRX_NO", rMap.getString("TRX_NO"));

			rMap = GMServiceExecuter.call("BNSPR_TRN2006_GET_INFO", rMap);

			sMap.put("INTERNAL_REF_NO", rMap.getString("INTERNAL_REF_NO"));
			sMap.put("BLOKE_TUTARI", iMap.getBigDecimal("BLOKE_TUTARI"));
			sMap.put("BLOKE_NEDEN_KODU", iMap.getString("BLOKE_NEDEN_KODU"));
			sMap.put("ACIKLAMA", iMap.getString("ACIKLAMA"));

			rMap = GMServiceExecuter.call("BNSPR_TRN2006_SAVE", sMap);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_BLOKE_COZME")
	public static GMMap blokeCoz(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String vdKod = iMap.getString("VDKOD");
			BigDecimal tutar = StringUtils.isEmpty(iMap.getString("TUTAR")) ? BigDecimal.ZERO : iMap.getBigDecimal("TUTAR");
			BigDecimal hesapNo = StringUtils.isEmpty(iMap.getString("HESAP_NO")) ? BigDecimal.ZERO : iMap.getBigDecimal("HESAP_NO");
			if (vdKod.length() > 5) {
				vdKod = vdKod.substring(vdKod.length() - 5);
			}
			GMMap rMap = new GMMap();
			GMMap sMap = new GMMap();
			int a = 0;
			int b = 0;
			String blokeRef = "";
			String blokeRefHatali = "";
			BigDecimal musteriNo = BigDecimal.ZERO;
			List<?> muhBlokeList = session.createCriteria(MuhBloke.class).add(Restrictions.eq("hbn", iMap.getString("HBN"))).add(Restrictions.like("vdkod", "%"+vdKod)).list();
			for (Object name : muhBlokeList) {
				MuhBloke muhBloke = (MuhBloke) name;
				try {
					if (!StringUtils.isEmpty(iMap.getString("TUTAR")) && hesapNo.compareTo(BigDecimal.ZERO) > 0) {
						if (b==0){
						if ((muhBloke.getBlokeTutari().compareTo(tutar) == 0) && muhBloke.getHesapNo().compareTo(hesapNo) == 0 && (muhBloke.getBlokeNedenKodu().equals("26")||muhBloke.getBlokeNedenKodu().equals("27")||muhBloke.getBlokeNedenKodu().equals("28"))) {
							sMap.clear();
							rMap.clear();
							sMap.put("BLOKE_REF_NO", muhBloke.getBlokeReferans());
							rMap = GMServiceExecuter.call("BNSPR_TRN2006_GET_TRX_NO", sMap);
							sMap.clear();
							sMap.put("TRX_NO", rMap.getString("TRX_NO"));
							rMap = GMServiceExecuter.call("BNSPR_TRN2006_GET_INFO", rMap);

							sMap.put("INTERNAL_REF_NO", rMap.getString("INTERNAL_REF_NO"));
							sMap.put("BLOKE_TUTARI", BigDecimal.ZERO);
							sMap.put("BLOKE_NEDEN_KODU", rMap.getString("BLOKE_NEDEN_KODU"));
							sMap.put("ACIKLAMA", iMap.getString("ACIKLAMA"));
							sMap.put("HBN", iMap.getString("HBN"));
							sMap.put("VDKOD", vdKod);
							if (b<1){
							rMap = GMServiceExecuter.call("BNSPR_TRN2006_SAVE", sMap);
							blokeRef = blokeRef.trim() + (blokeRef == "" ? "" : ",") + muhBloke.getBlokeReferans();
							musteriNo = muhBloke.getMusteriNo();
							}
							a = a + 1;
							b=1;
						}
							
						}else{
							if (muhBloke.getHesapNo().compareTo(hesapNo) == 0 && (muhBloke.getBlokeNedenKodu().equals("26")||muhBloke.getBlokeNedenKodu().equals("27")||muhBloke.getBlokeNedenKodu().equals("28"))) {
								a = a + 1;
							}
						}
						
					}
					else {
						sMap.clear();
						rMap.clear();
						sMap.put("BLOKE_REF_NO", muhBloke.getBlokeReferans());
						rMap = GMServiceExecuter.call("BNSPR_TRN2006_GET_TRX_NO", sMap);
						sMap.clear();
						sMap.put("TRX_NO", rMap.getString("TRX_NO"));
						rMap = GMServiceExecuter.call("BNSPR_TRN2006_GET_INFO", rMap);

						sMap.put("INTERNAL_REF_NO", rMap.getString("INTERNAL_REF_NO"));
						sMap.put("BLOKE_TUTARI", BigDecimal.ZERO);
						sMap.put("BLOKE_NEDEN_KODU", rMap.getString("BLOKE_NEDEN_KODU"));
						sMap.put("ACIKLAMA", iMap.getString("ACIKLAMA"));
						sMap.put("HBN", iMap.getString("HBN"));
						sMap.put("VDKOD", vdKod);
						rMap = GMServiceExecuter.call("BNSPR_TRN2006_SAVE", sMap);
						blokeRef = blokeRef.trim() + (blokeRef == "" ? "" : ",") + muhBloke.getBlokeReferans();
						musteriNo = muhBloke.getMusteriNo();
						a = a + 1;
					}

				}
				catch (Exception e) {
					blokeRefHatali = blokeRefHatali.trim() + (blokeRefHatali == "" ? "" : ",") + muhBloke.getBlokeReferans();
					continue;
				}
			}

			if (a>0 && a==b && muhBlokeList.size()>0) {
				if(!StringUtils.isEmpty(iMap.getString("TUTAR")) && hesapNo.compareTo(BigDecimal.ZERO) > 0){
				List<?> muhBlokeListK = session.createCriteria(MuhBloke.class).add(Restrictions.eq("hbn", iMap.getString("HBN"))).add(Restrictions.like("vdkod", "%"+vdKod)).add(Restrictions.eq("hesapNo", hesapNo)).add(Restrictions.ne("blokeTutari", tutar)).list();
				for (Object name : muhBlokeListK) {
					MuhBloke muhBloke = (MuhBloke) name;
					try {
						sMap.clear();
						rMap.clear();
						sMap.put("BLOKE_REF_NO", muhBloke.getBlokeReferans());
						rMap = GMServiceExecuter.call("BNSPR_TRN2006_GET_TRX_NO", sMap);
						sMap.clear();
						sMap.put("TRX_NO", rMap.getString("TRX_NO"));
						rMap = GMServiceExecuter.call("BNSPR_TRN2006_GET_INFO", rMap);

						sMap.put("INTERNAL_REF_NO", rMap.getString("INTERNAL_REF_NO"));
						sMap.put("BLOKE_TUTARI", BigDecimal.ZERO);
						sMap.put("BLOKE_NEDEN_KODU", rMap.getString("BLOKE_NEDEN_KODU"));
						sMap.put("ACIKLAMA", iMap.getString("ACIKLAMA"));
						sMap.put("HBN", iMap.getString("HBN"));
						sMap.put("VDKOD", vdKod);
						rMap = GMServiceExecuter.call("BNSPR_TRN2006_SAVE", sMap);
						blokeRef = blokeRef.trim() + (blokeRef == "" ? "" : ",") + muhBloke.getBlokeReferans();
						musteriNo = muhBloke.getMusteriNo();
					}
					catch (Exception e) {
						blokeRefHatali = blokeRefHatali.trim() + (blokeRefHatali == "" ? "" : ",") + muhBloke.getBlokeReferans();
						continue;
					}
				}
				}
				
				oMap.put("BLOKE_REF_NO", blokeRef);
				oMap.put("BLOKE_REF_NO_HATALI", blokeRefHatali);
				oMap.put("MUSTERI_NO", musteriNo);
				oMap.put("RESPONSE_CODE", "1");
			}else if(a!=b && muhBlokeList.size()>0){
				oMap.put("BLOKE_REF_NO", blokeRef);
				oMap.put("BLOKE_REF_NO_HATALI", blokeRefHatali);
				oMap.put("MUSTERI_NO", musteriNo);
				oMap.put("RESPONSE_CODE", "1");
			}else {
				oMap.put("RESPONSE_CODE", "0");
			}

		}
		catch (Exception e) {
			oMap.put("RESPONSE_CODE", "2");
		}
		return oMap;
	}
	
	
	/**
	 * @param iMap (GMMap)
	 *          MUSTERI_NO
	 *          HESAP_NO
	 * @return oMap (GMMap)
	 * 		HESAP_EHCZ_BLOKE(ACIKLAMA, BAKIYE,...)	
	 *      TOPLAM_BLOKE_TUTAR

	 *
	 */
	@GraymoundService("BNSPR_GET_HESAP_EHCZ_BLOKELERI")
	public static GMMap getEhczHesapBlokeTutar(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> muhBlokeList = session.createCriteria(MuhBloke.class).add(Restrictions.eq("musteriNo", iMap.getBigDecimal("MUSTERI_NO")))
																		 .add(Restrictions.eq("hesapNo",   iMap.getBigDecimal("HESAP_NO")))
																		 .add(Restrictions.eq("durumKodu", "A"))
																		 .add(Restrictions.in("blokeNedenKodu", new String[]{AkustikConstants.MUH_BLOKE_NEDEN_KOD_MEVDUAT_HACZI,
																				 											 AkustikConstants.MUH_BLOKE_NEDEN_KOD_IHTIYATI_TEDBIR,
																				 											 AkustikConstants.MUH_BLOKE_NEDEN_KOD_TEMINAT,
																				 											 AkustikConstants.MUH_BLOKE_NEDEN_KOD_GIB_EHCZ,
																				 											 AkustikConstants.MUH_BLOKE_NEDEN_KOD_SGK_EHCZ,
																				 											 AkustikConstants.MUH_BLOKE_NEDEN_KOD_GTB_EHCZ,
																				 											 AkustikConstants.MUH_BLOKE_NEDEN_KOD_GIB_EHCZ_REZERV,
																				 											 AkustikConstants.MUH_BLOKE_NEDEN_KOD_SGK_EHCZ_REZERV,
																				 											 AkustikConstants.MUH_BLOKE_NEDEN_KOD_GTB_EHCZ_REZERV,
																				 											 AkustikConstants.MUH_BLOKE_NEDEN_KOD_KIRALIK_KASA}))
																		 .list();
			BigDecimal toplamBlokeTutari = new BigDecimal(0);
			String tableName = "HESAP_EHCZ_BLOKE";
			
			for (int i=0; i<muhBlokeList.size(); i++) {
				MuhBloke muhBloke = (MuhBloke)muhBlokeList.get(i);
				toplamBlokeTutari = toplamBlokeTutari.add(muhBloke.getBlokeTutari());
				oMap.put(tableName, i, "ACIKLAMA", muhBloke.getAciklama());
				oMap.put(tableName, i, "BAKIYE", muhBloke.getBakiye());
				oMap.put(tableName, i, "BLOKE_BITIS_TARIHI", muhBloke.getBlokeBitisTarihi());
				oMap.put(tableName, i, "BLOKE_NEDEN_KODU", muhBloke.getBlokeNedenKodu());
				oMap.put(tableName, i, "BLOKE_REFERANS", muhBloke.getBlokeReferans());
				oMap.put(tableName, i, "BLOKE_TARIHI", muhBloke.getBlokeTarihi());
				oMap.put(tableName, i, "BLOKE_TUTARI", muhBloke.getBlokeTutari());
				oMap.put(tableName, i, "DOVIZ_KODU", muhBloke.getDovizKodu());
				oMap.put(tableName, i, "HBN", muhBloke.getHbn());
				oMap.put(tableName, i, "INTERNAL_REF_NO", muhBloke.getInternalRefNo());
				oMap.put(tableName, i, "VDKOD", muhBloke.getVdkod());
			}

			oMap.put("TOPLAM_BLOKE_TUTAR", toplamBlokeTutari);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}


}