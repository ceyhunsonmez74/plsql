package tr.com.calikbank.bnspr.currentaccounts.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.CariDthDovizSatisTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.module.custom.services.LOVExecuter;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2013Services { 

	@GraymoundService("BNSPR_TRN2013_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			CariDthDovizSatisTx cariDthDovizSatisTx = (CariDthDovizSatisTx)session.get(CariDthDovizSatisTx.class, iMap.getBigDecimal("TRX_NO"));
			if(cariDthDovizSatisTx == null) cariDthDovizSatisTx = new CariDthDovizSatisTx();
			
			cariDthDovizSatisTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			cariDthDovizSatisTx.setAciklama(iMap.getString("ACIKLAMA"));
			cariDthDovizSatisTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			cariDthDovizSatisTx.setDovizTutari(iMap.getBigDecimal("DOVIZ_TUTARI"));
			cariDthDovizSatisTx.setDthMusteriHesapNo(iMap.getBigDecimal("DTH_MUSTERI_HESAP_NO"));
			cariDthDovizSatisTx.setDthMusteriNo(iMap.getBigDecimal("DTH_MUSTERI_NO"));
			cariDthDovizSatisTx.setSatisSekli(iMap.getBigDecimal("SATIS_SEKLI"));
			cariDthDovizSatisTx.setIslemTarihi(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH", new GMMap()).getDate("BANKA_TARIH"));
			cariDthDovizSatisTx.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
			cariDthDovizSatisTx.setKur(iMap.getBigDecimal("KUR"));
			cariDthDovizSatisTx.setMusteriHesapNo(iMap.getBigDecimal("MUSTERI_HESAP_NO"));
			cariDthDovizSatisTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			cariDthDovizSatisTx.setRezervasyonNo(iMap.getBigDecimal("REZERVASYON_NO"));
			cariDthDovizSatisTx.setTahsilAdilenToplamTutar(iMap.getBigDecimal("TAHSIL_ADILEN_TOPLAM_TUTAR"));
			cariDthDovizSatisTx.setKasaKimlikTipi(iMap.getBigDecimal("KIMLIK_TIPI"));
			cariDthDovizSatisTx.setLcTutar(iMap.getBigDecimal("LC_TUTAR"));
			cariDthDovizSatisTx.setEuptKur(iMap.getBigDecimal("EUPT_KUR"));
			cariDthDovizSatisTx.setEuptTutar(iMap.getBigDecimal("EUPT_TUTAR"));
			cariDthDovizSatisTx.setEuptAbTutar(iMap.getBigDecimal("EUPT_AB_TUTAR"));
			cariDthDovizSatisTx.setEuptKurFarki(iMap.getBigDecimal("EUPT_KUR_FARKI"));
			cariDthDovizSatisTx.setEuptKurFarkiTl(iMap.getBigDecimal("EUPT_KUR_FARKI_TL"));
			cariDthDovizSatisTx.setEuptMasrafTutar(iMap.getBigDecimal("EUPT_MASRAF_TUTAR"));
			cariDthDovizSatisTx.setEuptDovizKodu(iMap.getString("EUPT_DOVIZ_KODU"));
			cariDthDovizSatisTx.setOnayEh(iMap.getString("ONAY_EH")!=null?iMap.getString("ONAY_EH"):"H");
			cariDthDovizSatisTx.setPlatformNo(iMap.getBigDecimal("PLATFORM_NO"));
			
			session.saveOrUpdate(cariDthDovizSatisTx);
			session.flush();

			iMap.put("TRX_NAME", "2013");
			return GMServiceExecuter
					.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN2013_GET_KUR_INFO")
	public static GMMap getKur(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call pkg_kur.EAK_to_LC(?,1)}");
			
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setString(2, iMap.getString("DOVIZ_KODU"));
			
			stmt.execute();
			Object obj = stmt.getObject(1);
			oMap.put("KUR", obj.toString());
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2013_GET_GLOBAL_DOVIZ_KODU")
	public static GMMap getGlobalDovizKodu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_global.WBaseCurr }");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();

			oMap.put("DOVIZ_KODU", stmt.getString(1));
			oMap.putAll(getDIDovizKodu(stmt.getString(1)));
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	private static GMMap getDIDovizKodu(String kod) {
		List<Object> list = new ArrayList<Object>();
		GMMap oMap=new GMMap();
		
		List<?> listKod = new ArrayList<Object>();
		listKod = LOVExecuter.execute("2013/LOV_DOVIZ",kod+ "%", list);
		if (listKod.size() != 0) {
			oMap.put("DOVIZ_ACIKLAMA", ((HashMap<?, ?>) listKod.get(0)).get("ACIKLAMA"));
		}
		list.clear();
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN2013_GET_ISTATISTIK_KODU_ACIKLAMA")
	public static GMMap getIstatistikKoduAciklama(GMMap iMap) {
		List<Object> list = new ArrayList<Object>();
		GMMap oMap=new GMMap();
		
		List<?> listKod = new ArrayList<Object>();
		listKod = LOVExecuter.execute("2013/LOV_ISTATISTIK",iMap.getString("ISTATISTIK_KODU")+ "%", list);
		if (listKod.size() != 0) {
			oMap.put("ISTATISTIK_KODU_ACIKLAMA", ((HashMap<?, ?>) listKod.get(0)).get("ACIKLAMA"));
		}
		list.clear();
		
		return oMap;
	}
	@GraymoundService("BNSPR_TRN2013_GET_DOVIZ_SATIS_BILGI")
	public static GMMap getDovizSatisBilgi(GMMap iMap) {
		try{	
		      Session session = DAOSession.getSession("BNSPRDal");
	            GMMap oMap = new GMMap();                                                          
	            CariDthDovizSatisTx cariDthDovizSatisTx = (CariDthDovizSatisTx) session.load(CariDthDovizSatisTx.class, iMap.getBigDecimal("TRX_NO"));
	                                                                       
	            oMap.put("MUSTERI_NO" , cariDthDovizSatisTx.getMusteriNo());
	            oMap.put("MUSTERI_ISIM_UNVAN" , LovHelper.diLov(cariDthDovizSatisTx.getMusteriNo(),cariDthDovizSatisTx.getDovizKodu(), "2013/LOV_MUSTERI", "UNVAN"));
	            oMap.put("MUSTERI_HESAP_NO" , cariDthDovizSatisTx.getMusteriHesapNo());
	            oMap.put("MUSTERI_HESAP_ACIKLAMA" , LovHelper.diLov(cariDthDovizSatisTx.getMusteriHesapNo(),null, "2013/LOV_HESAP_NO", "KISA_ISIM"));
	            oMap.put("DOVIZ_KODU" , cariDthDovizSatisTx.getDovizKodu());
	            oMap.put("DOVIZ_ACIKLAMA" , LovHelper.diLov(cariDthDovizSatisTx.getDovizKodu(), "2013/LOV_DOVIZ", "ACIKLAMA"));
	            oMap.put("REZERVASYON_NO" , cariDthDovizSatisTx.getRezervasyonNo());
	            oMap.put("KUR" , cariDthDovizSatisTx.getKur());
	            oMap.put("DOVIZ_TUTARI" , cariDthDovizSatisTx.getDovizTutari());
	            oMap.put("DTH_MUSTERI_NO" , cariDthDovizSatisTx.getDthMusteriNo());
	            oMap.put("DTH_MUSTERI_ISIM_UNVAN" , LovHelper.diLov(cariDthDovizSatisTx.getDthMusteriNo(), "2013/LOV_DTH_MUSTERI", "ISIM_UNVAN"));
	            oMap.put("DTH_MUSTERI_HESAP_NO" , cariDthDovizSatisTx.getDthMusteriHesapNo());
	            oMap.put("DTH_MUSTERI_HESAP_ACIKLAMA" , LovHelper.diLov(cariDthDovizSatisTx.getDthMusteriHesapNo(),null,null,cariDthDovizSatisTx.getDovizKodu(),"2013/LOV_DTH_HESAP_NO", "KISA_ISIM"));
	            oMap.put("ISTATISTIK_KODU" , cariDthDovizSatisTx.getIstatistikKodu());
	            
	            oMap.put("ACIKLAMA" , cariDthDovizSatisTx.getAciklama());
	            oMap.put("TAHSIL_ADILEN_TOPLAM_TUTAR" , cariDthDovizSatisTx.getTahsilAdilenToplamTutar());
	            oMap.put("TRX_NO" , cariDthDovizSatisTx.getTxNo());
	            oMap.put("SATIS_SEKLI" , cariDthDovizSatisTx.getSatisSekli().toString());
	            oMap.put("KIMLIK_TIPI" , cariDthDovizSatisTx.getKasaKimlikTipi().toString());
	            
	            oMap.put("EUPT_KUR" , cariDthDovizSatisTx.getEuptKur());
	            oMap.put("EUPT_TUTAR" , cariDthDovizSatisTx.getEuptTutar());
	            oMap.put("EUPT_AB_TUTAR" , cariDthDovizSatisTx.getEuptAbTutar());
	            oMap.put("EUPT_KUR_FARKI" , cariDthDovizSatisTx.getEuptKurFarki());
	            oMap.put("EUPT_KUR_FARKI_TL" , cariDthDovizSatisTx.getEuptKurFarkiTl());
	            oMap.put("EUPT_MASRAF_TUTAR" , cariDthDovizSatisTx.getEuptMasrafTutar());
	            oMap.put("EUPT_DOVIZ_KODU" , cariDthDovizSatisTx.getEuptDovizKodu());   
	        
	        if (cariDthDovizSatisTx.getMusteriHesapNo()!= null) {
	        iMap.put("HESAP_NO", cariDthDovizSatisTx.getMusteriHesapNo());
	        oMap.put("KULLANILABILIR_BAKIYE" , CurrentAccountsCommonServices.getKullanilabilirBakiye(iMap).get("KULLANILABILIR_BAKIYE"));
	        oMap.put("DEFTER_BAKIYE" , GMServiceExecuter.execute("BNSPR_GET_DEFTER_BAKIYESI",iMap).get("DEFTER_BAKIYE"));
	        }	                                                                  
	        return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}

