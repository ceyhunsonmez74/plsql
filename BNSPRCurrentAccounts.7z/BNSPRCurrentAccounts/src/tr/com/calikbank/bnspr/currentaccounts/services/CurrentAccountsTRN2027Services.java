package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MuhAutoKasaFarkiDetayTx;
import tr.com.aktifbank.bnspr.dao.MuhAutoKasaFarkiDetayTxId;
import tr.com.aktifbank.bnspr.dao.MuhAutoKasaFarkiMainTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.currentaccounts.utils.KasaFarkEnum;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsTRN2027Services {

	public static SimpleDateFormat formatter = new SimpleDateFormat("dd.MM.yyyy");

	@GraymoundService("BNSPR_TRN2027_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		Session session = DAOSession.getSession("BNSPRDal");
		BigDecimal listRow = BigDecimal.ZERO;

		int i = 0;
		try {

			String localCurrnecy = iMap.getString("DOVIZ_KODU_LOCAL");

			MuhAutoKasaFarkiMainTx kasaFarkiMain = new MuhAutoKasaFarkiMainTx();
			kasaFarkiMain.setTxNo(iMap.getBigDecimal("TRX_NO"));
			kasaFarkiMain.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			kasaFarkiMain.setKasaKodu(iMap.getString("KASA_KODU"));
			kasaFarkiMain.setSubeKodu(iMap.getString("SUBE_KODU"));
			kasaFarkiMain.setSayimTarihi(iMap.getDate("TARIH"));
			kasaFarkiMain.setToplamMadeniPara(iMap.getBigDecimal("TOPLAM_MADENI_PARA"));
			kasaFarkiMain.setTuzakPara(iMap.getBigDecimal("TUZAK_PARA"));
			kasaFarkiMain.setGenelFizikiToplam(iMap.getBigDecimal("GENEL_FIZIKI_TOPLAM"));
			kasaFarkiMain.setSistemBakiyesi(iMap.getBigDecimal("SISTEM_BAKIYESI"));
			kasaFarkiMain.setFarkTutar(iMap.getBigDecimal("FARK_TUTAR"));
			kasaFarkiMain.setAciklama(iMap.getString("ACIKLAMA"));
			kasaFarkiMain.setRecId(getGeneralId(KasaFarkEnum.MAIN_SEQ.getKeyValue()));
			
			if (kasaFarkiMain.getFarkTutar().compareTo(BigDecimal.ZERO) > 0) {
				if (kasaFarkiMain.getDovizKodu().equals(localCurrnecy)) {
					kasaFarkiMain.setAlacakHesapNo(getMuhAccountFromParam(KasaFarkEnum.TL_KASA_FAZLA.getKeyValue()));
					kasaFarkiMain.setFarkTipi(KasaFarkEnum.FARK_TIPI_TL_KASA_FAZLA.getKeyValue());
				}
				else {
					kasaFarkiMain.setAlacakHesapNo(getMuhAccountFromParam(KasaFarkEnum.YP_KASA_FAZLA.getKeyValue()));
					kasaFarkiMain.setFarkTipi( KasaFarkEnum.FARK_TIPI_YP_KASA_FAZLA.getKeyValue());
				}
			}

			if (kasaFarkiMain.getFarkTutar().compareTo(BigDecimal.ZERO) < 0) {
				if (kasaFarkiMain.getDovizKodu().equals(localCurrnecy)) {
					kasaFarkiMain.setAlacakHesapNo(getMuhAccountFromParam(KasaFarkEnum.TL_KASA_NOKSAN.getKeyValue()));
					kasaFarkiMain.setFarkTipi(KasaFarkEnum.FARK_TIPI_TL_KASA_NOKSAN.getKeyValue());
				}
				else {
					kasaFarkiMain.setAlacakHesapNo(getMuhAccountFromParam(KasaFarkEnum.YP_KASA_NOKSAN.getKeyValue()));
					kasaFarkiMain.setFarkTipi(KasaFarkEnum.FARK_TIPI_YP_KASA_NOKSAN.getKeyValue());
				}
			}
			
			if(StringUtils.isBlank(kasaFarkiMain.getFarkTipi()))
				kasaFarkiMain.setFarkTipi(KasaFarkEnum.FARK_TIPI_DEFAULT.getKeyValue());

			session.saveOrUpdate(kasaFarkiMain);
			String tblName = KasaFarkEnum.TBL_GML.getKeyValue();

			while (i < iMap.getSize(tblName)) {
				listRow = listRow.add(BigDecimal.ONE);
				MuhAutoKasaFarkiDetayTx kasaFarkiDetay = new MuhAutoKasaFarkiDetayTx();
				MuhAutoKasaFarkiDetayTxId detayId = new MuhAutoKasaFarkiDetayTxId();
				detayId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				detayId.setListId(listRow);

				kasaFarkiDetay.setMevcutAdet(setBlankToZero(iMap.getBigDecimal(tblName, i, "MEVCUT_KUPUR_ADET")));
				kasaFarkiDetay.setKupurTutar(setBlankToZero(iMap.getBigDecimal(tblName, i, "KUPUR_TUTAR")));
				kasaFarkiDetay.setToplamTutar(setBlankToZero(iMap.getBigDecimal(tblName, i, "TOPLAM_TUTAR")));

				kasaFarkiDetay.setId(detayId);
				kasaFarkiDetay.setRecId(getGeneralId(KasaFarkEnum.DET_SEQ.getKeyValue()));
				session.saveOrUpdate(kasaFarkiDetay);

				i++;
			}
			session.flush();
			iMap.put("TRX_NAME", KasaFarkEnum.EKRAN_KODU.getKeyValue());
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static BigDecimal setBlankToZero(BigDecimal value) {
		BigDecimal newValue;
		if (value == null) {
			newValue = BigDecimal.ZERO;
		}
		else {
			if (StringUtils.isBlank(value.toString()))
				newValue = BigDecimal.ZERO;
			else
				newValue = value;
		}
		return newValue;
	}

		public static String getMuhAccountFromParam(String key) {
		GMMap iMap = new GMMap();
		GMMap oMap = new GMMap();
		int i = 0;
		try {

			iMap.put("KOD", KasaFarkEnum.HESAP_KEY.getKeyValue());
			iMap.put("KEY1", key);
			iMap.put("KEY2", KasaFarkEnum.ACIK.getKeyValue());
			oMap.put(key, GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

			while (i < oMap.getSize(key)) {

				if (oMap.getString(key, i, "VALUE").equals(key)) {
					oMap.put(key, oMap.getString(key, i, "NAME"));
				}
				i++;
			}

			return oMap.getString(key);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN2027_CALC")
	public static GMMap calc(GMMap iMap) {
		GMMap oMap = new GMMap();
		BigDecimal mevcutAdet = BigDecimal.ZERO;
		BigDecimal kupurTutar = BigDecimal.ZERO;
		BigDecimal toplamTutar = BigDecimal.ZERO;
		BigDecimal kupurToplam = BigDecimal.ZERO;
		BigDecimal tuzakPara = BigDecimal.ZERO;
		BigDecimal madeniPara = BigDecimal.ZERO;
		BigDecimal sumFizikiTutar = BigDecimal.ZERO;
		BigDecimal farkTutar = BigDecimal.ZERO;
		BigDecimal systemBakiye = BigDecimal.ZERO;

		int i = 0;

		try {
			oMap.putAll(iMap);
			String tblName = KasaFarkEnum.TBL_GML.getKeyValue();

			while (i < iMap.getSize(tblName)) {
				mevcutAdet = setBlankToZero(iMap.getBigDecimal(tblName, i, "MEVCUT_KUPUR_ADET"));
				kupurTutar = setBlankToZero(iMap.getBigDecimal(tblName, i, "KUPUR_TUTAR"));

				if ((mevcutAdet instanceof BigDecimal) && (kupurTutar instanceof BigDecimal))
					toplamTutar = mevcutAdet.multiply(kupurTutar);

				if ((kupurToplam instanceof BigDecimal) && (toplamTutar instanceof BigDecimal))
					kupurToplam = kupurToplam.add(toplamTutar);

				oMap.put(tblName, i, "TOPLAM_TUTAR", toplamTutar);
				i++;
			}

			tuzakPara = setBlankToZero(iMap.getBigDecimal("TUZAK_PARA"));
			madeniPara = setBlankToZero(iMap.getBigDecimal("TOPLAM_MADENI_PARA"));
			systemBakiye = setBlankToZero(iMap.getBigDecimal("SISTEM_BAKIYE"));

			if ((kupurToplam instanceof BigDecimal) && (tuzakPara instanceof BigDecimal) && (madeniPara instanceof BigDecimal))
				sumFizikiTutar = kupurToplam.add(tuzakPara).add(madeniPara);

			if ((systemBakiye instanceof BigDecimal) && (sumFizikiTutar instanceof BigDecimal))
				farkTutar = sumFizikiTutar.subtract(systemBakiye);

			oMap.put("FARK_TUTAR", farkTutar);
			oMap.put("FIZIKI_TOPLAM", sumFizikiTutar);

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN2027_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			Session session = DAOSession.getSession("BNSPRDal");
			List<?> recordMainList = (List<?>) session.createCriteria(MuhAutoKasaFarkiMainTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();

			for (int i = 0; i < recordMainList.size(); i++) {
				MuhAutoKasaFarkiMainTx muhFarkMainTx = (MuhAutoKasaFarkiMainTx) recordMainList.get(i);
				oMap.put("DOVIZ_KODU", muhFarkMainTx.getDovizKodu());
				oMap.put("DOVIZ_KODU_ACIKLAMA", LovHelper.diLov(muhFarkMainTx.getDovizKodu(), "2016/LOV_DOVIZ_KODU", "ACIKLAMA"));
				oMap.put("KASA_KODU", muhFarkMainTx.getKasaKodu());
				oMap.put("SUBE_KODU", muhFarkMainTx.getSubeKodu());
				oMap.put("SUBE_ADI", LovHelper.diLov(muhFarkMainTx.getSubeKodu(), "2017/LOV_SUBE", "ADI"));
				oMap.put("TARIH", muhFarkMainTx.getSayimTarihi());
				oMap.put("TOPLAM_MADENI_PARA", muhFarkMainTx.getToplamMadeniPara());
				oMap.put("TUZAK_PARA", muhFarkMainTx.getTuzakPara());
				oMap.put("GENEL_FIZIKI_TOPLAM", muhFarkMainTx.getGenelFizikiToplam());
				oMap.put("SISTEM_BAKIYESI", muhFarkMainTx.getSistemBakiyesi());
				oMap.put("FARK_TUTAR", muhFarkMainTx.getFarkTutar());
				oMap.put("ACIKLAMA", muhFarkMainTx.getAciklama());
				oMap.put("FARK_TIPI", muhFarkMainTx.getFarkTipi());
				oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));

			}

			String tblName = KasaFarkEnum.TBL_GML.getKeyValue();
			List<?> recordDetList = (List<?>) session.createCriteria(MuhAutoKasaFarkiDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			for (int i = 0; i < recordDetList.size(); i++) {
				MuhAutoKasaFarkiDetayTx muhFarkDetTx = (MuhAutoKasaFarkiDetayTx) recordDetList.get(i);
				oMap.put(tblName, i, "MEVCUT_KUPUR_ADET", muhFarkDetTx.getMevcutAdet());
				oMap.put(tblName, i, "KUPUR_TUTAR", muhFarkDetTx.getKupurTutar());
				oMap.put(tblName, i, "TOPLAM_TUTAR", muhFarkDetTx.getToplamTutar());
				oMap.put(tblName, i, "DOVIZ_KODU", oMap.getString("DOVIZ_KODU"));

			}

			return oMap;

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static String getErrorText(BigDecimal errorCode) {
		GMMap errorIMap = new GMMap();
		String errorDescription;

		errorIMap.put("MESSAGE_NO", errorCode);
		errorDescription = GMServiceExecuter.call("BNSPR_COMMON_GET_KODSUZ_MESSAGE", errorIMap).getString("ERROR_MESSAGE");

		return errorDescription;

	}

	public static BigDecimal getGeneralId(String tableName) {
		BigDecimal recId = null;
		try {
			if (!StringUtils.isBlank(tableName)) {
				GMMap xMap = new GMMap().put(KasaFarkEnum.TABLE_NAME.getKeyValue(), tableName);
				recId = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_ID", xMap).getBigDecimal("ID");
			}
			else {
				BigDecimal H1 = new BigDecimal(KasaFarkEnum.H1.getKeyValue());
				throw new GMRuntimeException(H1.intValue(), getErrorText(H1));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return recId;
	}

	@GraymoundService("BNSPR_TRN2027_SISTEM_BAKIYE")
	public static GMMap getSystemBakiye(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		BigDecimal systemBakiye = BigDecimal.ZERO;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN2027.getSystemBakiye(?,?,?)}");
			stmt.registerOutParameter(1, -10);
			stmt.setString(2, iMap.getString("KASA_KODU"));
			stmt.setString(3, iMap.getString("SUBE_KODU"));
			stmt.setString(4, iMap.getString("DOVIZ_KODU"));

			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			int i = 0;
			while (rSet.next()) {
				BigDecimal sysItemBakiye = setBlankToZero(rSet.getBigDecimal(2));
				if (sysItemBakiye instanceof BigDecimal) {
					systemBakiye = systemBakiye.add(sysItemBakiye);
				}
				i++;
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap.put("SYSTEM_BAKIYE", systemBakiye);
	}

	@GraymoundService("BNSPR_TRN2027_GET_BANK_DATE")
	public static GMMap getBankDate(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			oMap.put("BANKA_TARIH", (Date) DALUtil.callNoParameterFunction("{? = call pkg_global.GET_BANKATARIH}", Types.DATE));

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}

	@GraymoundService("BNSPR_TRN2027_QUERY_KASA")
	public static GMMap getKasaKodAndTanimNo(GMMap iMap) {
		 Connection conn = null;
         CallableStatement stmt = null;
         ResultSet rSet = null;
         GMMap oMap = new GMMap();
         try {
                 conn = DALUtil.getGMConnection();
                 stmt = conn.prepareCall("{? = call pkg_rc_current_accounts.RC_QRY2037_KUPUR_DURUMU(?,?,?,?)}");
                 stmt.registerOutParameter(1, -10);
                 stmt.setString(2, iMap.getString("KASA_KODU"));
                 stmt.setString(3, iMap.getString("SUBE_KODU"));
                 stmt.setString(4, iMap.getString("DOVIZ_KODU"));
                 if (iMap.getDate("TARIH") != null)
                         stmt.setDate(5, new java.sql.Date(iMap.getDate("TARIH").getTime()));
                 else
                         stmt.setDate(5, null);
                 stmt.execute();
                 rSet = (ResultSet) stmt.getObject(1);
                 String tableName = "KUPUR_DURUMU";
                 int j = 0;
                 while (rSet.next()) {
                         oMap.put(tableName, j, "DOVIZ_KODU", rSet.getString(1));
                         oMap.put(tableName, j, "KUPUR_TUTAR", rSet.getString(2));
                         oMap.put(tableName, j, "MEVCUT_KUPUR_ADET", BigDecimal.ZERO);
                         oMap.put(tableName, j, "TOPLAM_TUTAR", BigDecimal.ZERO);
                         j++;
                 }

         }
         catch (Exception e) {
                 throw ExceptionHandler.convertException(e);
         }
         finally {
                 GMServerDatasource.close(rSet);
                 GMServerDatasource.close(stmt);
                 GMServerDatasource.close(conn);
         }
         return oMap;
	}

	@GraymoundService("BNSPR_TRN2027_KASA_BAKIYE_GORUNSUNMU")
    public static GMMap kasaBakiyeGorunsunmu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN2027.f_kasa_bakiye_goruntulensinmi(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("TRX_NO"));

			stmt.execute();

			oMap.put("SONUC", stmt.getString(1));
			return oMap;
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {

			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	

}
