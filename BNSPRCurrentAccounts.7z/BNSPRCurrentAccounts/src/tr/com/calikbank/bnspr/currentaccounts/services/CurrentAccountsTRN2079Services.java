package tr.com.calikbank.bnspr.currentaccounts.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.io.InputStreamReader;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.aktifbank.bnspr.dao.ClksPttAcenteTx;
import tr.com.aktifbank.bnspr.dao.ClksPttAcenteTxId;
import tr.com.calikbank.bnspr.util.FileUtil;


import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsTRN2079Services {
	@GraymoundService("BNSPR_TRN2079_LOAD_EXCEL")
	public static GMMap merkezSubeList(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {			
			String tableName = "ACENTE_LISTESI";
			File file = FileUtil.createTempDirFile("csvread");
			OutputStream writer = new FileOutputStream(file);
			writer.write((byte[])iMap.get("DOSYA"));
			writer.flush();


		   //t�rk�e karakter problemi i�in yap�lm��t�r.
			InputStreamReader reader = new InputStreamReader(new FileInputStream(file),"UTF-8");

			BufferedReader br = new BufferedReader(reader);



			//ilk sat�r header oldugu i�in atland�.
			br.readLine();
			String strLine = "";
			int i = 0;
			while((strLine = br.readLine()) != null){
				String[] list = strLine.split(";");

			
				oMap.put(tableName, i, "MERKEZ_NO",list[0].trim());
				oMap.put(tableName, i, "SUBE_NO", list[1].trim());
				oMap.put(tableName, i, "GISE_NO", list[2].trim());
				oMap.put(tableName, i, "SICIL", list[3].trim());
				oMap.put(tableName, i, "AD", list[4].trim());
				oMap.put(tableName, i, "SOYAD", list[5].trim());
				oMap.put(tableName, i, "KULLANICI_ADI", list[6].trim());
				oMap.put(tableName, i, "KILIT", list[7].trim());
				oMap.put(tableName, i, "MERKEZ_ID",list[8].trim());
				oMap.put(tableName, i, "SUBE_ID", list[9].trim());
			   
				i++;
			}

			return oMap;
			}	  catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
		
	
	@GraymoundService("BNSPR_TRN2079_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		GMMap oMap = new GMMap();

		try{
			Session session = DAOSession.getSession("BNSPRDal"); 
            String tableName = "ACENTE_LISTESI";
			List<?> guiList = (List<?>)iMap.get(tableName);
			if(guiList.size()==0){
				iMap.put("HATA_NO", new BigDecimal(1064));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if(iMap.getString("DOSYA_ADI")==null || iMap.getString("DOSYA_ADI").length()==0){
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "DOSYA_ADI");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			for (int i = 0; i < guiList.size(); i++) {
				
				ClksPttAcenteTx clksPttAcenteTx = new ClksPttAcenteTx();
				ClksPttAcenteTxId id=new ClksPttAcenteTxId();
				
				oMap.put(
						"ACENTE_ID",
						GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO",
								iMap).get("SIRA_NO"));
				
				
				id.setAcenteId(oMap.getBigDecimal("ACENTE_ID"));	
				
			    id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			  
			    clksPttAcenteTx.setId(id);
			    clksPttAcenteTx.setSicilNo(iMap.getString(tableName, i, "SICIL"));
			    clksPttAcenteTx.setMerkezNo(iMap.getString(tableName, i, "MERKEZ_NO"));
			    clksPttAcenteTx.setSubeNo(iMap.getString(tableName, i, "SUBE_NO"));
			    clksPttAcenteTx.setGiseNo(iMap.getString(tableName, i, "GISE_NO"));
			    clksPttAcenteTx.setMerkezId(iMap.getString(tableName, i, "MERKEZ_ID"));
			    clksPttAcenteTx.setSubeId(iMap.getString(tableName, i, "SUBE_ID"));
			    
			    clksPttAcenteTx.setAd(iMap.getString(tableName, i, "AD"));
			    clksPttAcenteTx.setSoyad(iMap.getString(tableName, i, "SOYAD"));
			    clksPttAcenteTx.setKullaniciAdi(iMap.getString(tableName, i, "KULLANICI_ADI"));
			    clksPttAcenteTx.setKilit(iMap.getString(tableName, i, "KILIT"));
			    clksPttAcenteTx.setDosyaAdi(iMap.getString("DOSYA_ADI"));
				session.save(clksPttAcenteTx);
				
			}
			session.flush();  
			iMap.put("TRX_NAME", "2079");
			return   GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	
	@GraymoundService("BNSPR_TRN2079_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> list = (List<?>)session.createCriteria(ClksPttAcenteTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	
		String tableName = "ACENTE_LISTESI";
		int row = 0;
		for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
			ClksPttAcenteTx clksPttAcenteTx = (ClksPttAcenteTx) iterator.next();
			oMap.put("TRX_NO", clksPttAcenteTx.getId().getTxNo());
			oMap.put(tableName, row, "ACENTE_ID", clksPttAcenteTx.getId().getAcenteId());
			oMap.put(tableName, row, "MERKEZ_ID", clksPttAcenteTx.getMerkezId());
			oMap.put(tableName, row, "SUBE_ID", clksPttAcenteTx.getSubeId());
			oMap.put(tableName, row, "MERKEZ_NO", clksPttAcenteTx.getMerkezNo());
			oMap.put(tableName, row, "SUBE_NO", clksPttAcenteTx.getSubeNo());
			oMap.put(tableName, row, "GISE_NO", clksPttAcenteTx.getGiseNo());
			oMap.put(tableName, row, "SICIL", clksPttAcenteTx.getSicilNo());
			oMap.put(tableName, row, "AD", clksPttAcenteTx.getAd());
			oMap.put(tableName, row, "SOYAD", clksPttAcenteTx.getSoyad());
			oMap.put(tableName, row, "KULLANICI_ADI", clksPttAcenteTx.getKullaniciAdi());
			oMap.put(tableName, row, "KILIT", clksPttAcenteTx.getKilit());
			oMap.put("DOSYA_ADI", clksPttAcenteTx.getDosyaAdi());
			
         row++;
		}
        	return oMap;
        	
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
