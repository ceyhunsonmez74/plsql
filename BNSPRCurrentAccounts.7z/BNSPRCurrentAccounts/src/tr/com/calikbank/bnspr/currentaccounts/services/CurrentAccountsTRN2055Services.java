package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.ClksKomisyonFisHavuz;
import tr.com.aktifbank.bnspr.dao.ClksKomisyonFisTx;
import tr.com.aktifbank.bnspr.dao.ClksKomisyonSatirTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2055Services {
	
	private static Logger logger = Logger.getLogger(CurrentAccountsTRN2055Services.class);
	private static String tableName = "FIS_DETAY"; 
	
	private static String DURUM_KOD_ACIK = "A";
	private static String DURUM_KOD_RED = "R";
	
	@GraymoundService("BNSPR_TRN2055_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		
		GMMap oMap = new GMMap();   
		Calendar calendar = Calendar.getInstance();
		
		try {
			
			// Case: Tarih yok ise, onceki ayin ilk ve son gunu alinsin
			if(iMap.get("TARIH") == null) {
				
				calendar.set(Calendar.DAY_OF_MONTH, 1);
				calendar.add(Calendar.DATE, -1); 
				oMap.put("AYIN_SON_GUNU", calendar.getTime());
				
				calendar.set(Calendar.DAY_OF_MONTH, 1);
				oMap.put("AYIN_ILK_GUNU", calendar.getTime());
			}
			
			// Case: Tarih bilgisi var ise tarih ayinin ilk ve son gunu alinsin
			else {
				
				calendar.setTime(iMap.getDate("TARIH"));
				calendar.set(Calendar.DAY_OF_MONTH, 1);
				calendar.add(Calendar.MONTH, 1);
				calendar.add(Calendar.DATE, -1); 
				oMap.put("AYIN_SON_GUNU", calendar.getTime());
				
				calendar.setTime(iMap.getDate("TARIH"));
				calendar.set(Calendar.DAY_OF_MONTH, 1);
				oMap.put("AYIN_ILK_GUNU", calendar.getTime());
			}
			
		} catch (Exception e) {
			
			logger.error("BNSPR_QRY2062_INITIALIZE err: " + e);
			throw ExceptionHandler.convertException(e);
		}	
			
		return oMap;
	}
	
	/**
	 * 
	 * Description : "SAVE" butonu arkasinda cagirilir, 2055 transaction'inin baslatilabilmesi icin ekrandan alinan girdiler dogrultusunda 
	 * bnspr.clks_komisyon_fis_tx ve bnspr.clks_komisyon_satir_tx tablolar� beslenir.
	 *
	 * @param iMap (GMMap)
	 *		{TRX_NO, TARIH, ACIKLAMA, DOVIZ_KOD, ALACAK_TOPLAM, BORC_TOPLAM, BALANS, 
	 *      FIS_DETAY=[{KOD, B_A, HESAP_NO, TUTAR, DOVIZ_KOD, ISLEM_TARIHI}]}
	 *
	 * @return oMap (GMMap)
	 *      {MESSAGE}
	 * 
	 */
	@GraymoundService("BNSPR_TRN2055_SAVE")
	public static GMMap save(GMMap iMap) {

		GMMap oMap = new GMMap();
		boolean contains = false;
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksKomisyonFisTx clksKomisyonFisTx = (ClksKomisyonFisTx) session.get(ClksKomisyonFisTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if(clksKomisyonFisTx == null) {
				clksKomisyonFisTx = new ClksKomisyonFisTx();
			}
			
			clksKomisyonFisTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			clksKomisyonFisTx.setValorTarihi(iMap.getDate("BANKA_TARIH"));
			clksKomisyonFisTx.setKomisyonTarihi(iMap.getDate("TARIH"));
			clksKomisyonFisTx.setAmountLcCr(iMap.getBigDecimal("ALACAK_TOPLAM"));
			clksKomisyonFisTx.setAmountLcDb(iMap.getBigDecimal("BORC_TOPLAM"));
			session.saveOrUpdate(clksKomisyonFisTx);
			
			// Silinen satirlari, tablodan da ucurualim
			List<?> list = session.createCriteria(ClksKomisyonSatirTx.class)
					.add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO")))
					.list();
				
			Iterator<?> iterator = list.iterator();
			
			while(iterator.hasNext()) {
				
				contains = false;
				ClksKomisyonSatirTx clksKomisyonSatirTx = (ClksKomisyonSatirTx) iterator.next();
			
				for(int i = 0; i < iMap.getSize(tableName); i++) {
					
					if(clksKomisyonSatirTx.getTxNo().equals(iMap.getBigDecimal("TRX_NO")) && clksKomisyonSatirTx.getKod().equals(iMap.getBigDecimal(tableName, i, "KOD"))) {
						contains = true;
					}
				}
				
				if(!contains) {
					
					// Case: Ekrandan girilmis ise silelim
					if ("H".equals(clksKomisyonSatirTx.getFJob())) {
						session.delete(clksKomisyonSatirTx);
					} 
					
					// Case: Scheduler yaratmis ise once havuzda red'e cekelim, sonra silelim
					else {
						ClksKomisyonFisHavuz clksKomisyonFisHavuz = (ClksKomisyonFisHavuz) session.get(ClksKomisyonFisHavuz.class, clksKomisyonSatirTx.getKod());
						clksKomisyonFisHavuz.setDurumKod(DURUM_KOD_RED);
						session.saveOrUpdate(clksKomisyonFisHavuz);
						session.delete(clksKomisyonSatirTx);
					}
					
				}
			}
			
			for(int i = 0; i < iMap.getSize(tableName); i++) {

				// Yeni satir ekle
				ClksKomisyonSatirTx clksKomisyonSatirTx = (ClksKomisyonSatirTx) session.get(ClksKomisyonSatirTx.class, iMap.getBigDecimal(tableName, i, "KOD"));
				
				if(clksKomisyonSatirTx == null) {
					clksKomisyonSatirTx = new ClksKomisyonSatirTx();
				}
				
				clksKomisyonSatirTx.setBA(iMap.getString(tableName, i, "B_A"));
				clksKomisyonSatirTx.setDovizKod(iMap.getString(tableName, i, "DOVIZ_KOD"));
				clksKomisyonSatirTx.setFJob((clksKomisyonSatirTx.getFJob() != null) ? clksKomisyonSatirTx.getFJob() : BigDecimal.ZERO.equals(iMap.getBigDecimal(tableName, i, "KOD")) ? "H" : "E");
				clksKomisyonSatirTx.setLcTutar(iMap.getBigDecimal(tableName, i, "TUTAR"));
				clksKomisyonSatirTx.setDvTutar(iMap.getBigDecimal(tableName, i, "TUTAR"));
				clksKomisyonSatirTx.setKur(BigDecimal.ONE);
				clksKomisyonSatirTx.setHesapNo(iMap.getString(tableName, i, "HESAP_NO"));
				clksKomisyonSatirTx.setHesapSubeKod(iMap.getBigDecimal(tableName, i, "HESAP_SUBE_KOD"));
				clksKomisyonSatirTx.setHesapTurKodu(iMap.getString(tableName, i, "HESAP_TUR_KODU"));
				clksKomisyonSatirTx.setValorTarihi(iMap.getDate(tableName, i, "ISLEM_TARIHI"));
				clksKomisyonSatirTx.setKod(BigDecimal.ZERO.equals(iMap.getBigDecimal(tableName, i, "KOD")) ? 
					new BigDecimal(DALUtil.getResult("select seq_clks_komisyon_fis.nextval from dual")) : 
					iMap.getBigDecimal(tableName, i, "KOD"));
				clksKomisyonSatirTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				clksKomisyonSatirTx.setBankaAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
				clksKomisyonSatirTx.setMusteriAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
				session.saveOrUpdate(clksKomisyonSatirTx);
			}
			session.flush();
			
			iMap.put("TRX_NAME", "2055");
			oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			
		} catch (Exception e) {
			
			logger.error("BNSPR_TRN2055_SAVE err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	
	/**
	 * 
	 * Description : Mesaj Kutusu araciligi ile BNSPR_TRN2055.guiml ekrani acildiginda cagirilir, 
	 * baslatilan transaction'a ait bilgileri getirir.
	 *
	 * @param iMap (GMMap)
	 *		{TRX_NO}
	 *
	 * @return oMap (GMMap)
	 *      {TRX_NO, TARIH, ACIKLAMA, DOVIZ_KOD, ALACAK_TOPLAM, BORC_TOPLAM, BALANS, 
	 *      FIS_DETAY=[{KOD, B_A, HESAP_NO, TUTAR, DOVIZ_KOD, ISLEM_TARIHI}]}
	 *
	 */
	@GraymoundService("BNSPR_TRN2055_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		Calendar calendar = Calendar.getInstance();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			ClksKomisyonFisTx clksKomisyonFisTx = (ClksKomisyonFisTx)session.get(ClksKomisyonFisTx.class, iMap.getBigDecimal("TRX_NO"));
		
			calendar.setTime(clksKomisyonFisTx.getKomisyonTarihi());
			calendar.set(Calendar.DAY_OF_MONTH, 1);
			
			oMap.put("TRX_NO", clksKomisyonFisTx.getTxNo());
			oMap.put("TARIH_SON", clksKomisyonFisTx.getKomisyonTarihi());
			oMap.put("TARIH", calendar.getTime());
			oMap.put("DOVIZ_KOD", "TRY");
			oMap.put("ALACAK_TOPLAM", clksKomisyonFisTx.getAmountLcCr());
			oMap.put("BORC_TOPLAM", clksKomisyonFisTx.getAmountLcDb());
			oMap.put("BALANS", clksKomisyonFisTx.getAmountLcDb().subtract(clksKomisyonFisTx.getAmountLcCr()));

			List<?> list = session.createCriteria(ClksKomisyonSatirTx.class)
				.add(Restrictions.eq("txNo", oMap.getBigDecimal("TRX_NO")))
				.list();
			
			Iterator<?> iterator = list.iterator();
			int i = 0;
			
			while(iterator.hasNext()) {
				
				ClksKomisyonSatirTx clksKomisyonSatirTx = (ClksKomisyonSatirTx) iterator.next();
				
				oMap.put(tableName, i, "KOD", clksKomisyonSatirTx.getKod());
				oMap.put(tableName, i, "B_A", clksKomisyonSatirTx.getBA());
				oMap.put(tableName, i, "HESAP_NO", clksKomisyonSatirTx.getHesapNo());
				oMap.put(tableName, i, "HESAP_SUBE_KOD", clksKomisyonSatirTx.getHesapSubeKod());
				oMap.put(tableName, i, "HESAP_TUR_KODU", clksKomisyonSatirTx.getHesapTurKodu());
				oMap.put(tableName, i, "TUTAR", clksKomisyonSatirTx.getDvTutar());
				oMap.put(tableName, i, "DOVIZ_KOD", clksKomisyonSatirTx.getDovizKod());
				oMap.put(tableName, i, "ISLEM_TARIHI", clksKomisyonSatirTx.getValorTarihi());
				oMap.put(tableName, i, "ACIKLAMA", clksKomisyonSatirTx.getBankaAciklama());
				
				i++;
			}
			
		} catch (Exception e) {
			
			logger.error("BNSPR_TRN2055_GET_INFO err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	
	/**
	 * 
	 * Description : "Fis Getir" butonu arkasinda cagirilir, bnspr.clks_komisyon_fis_havuz tablosundan
	 * durum_kod'u "A" olan kayitlari getirir.
	 *
	 * @param iMap (GMMap)
	 *		{TARIH, DOVIZ_KOD}
	 *
	 * @return oMap (GMMap)
	 *      {FIS_DETAY=[{KOD, B_A, HESAP_NO, TUTAR, DOVIZ_KOD, ISLEM_TARIHI}]}
	 *
	 */
	@GraymoundService("BNSPR_TRN2055_FIS_GETIR")
	public static GMMap fisGetir(GMMap iMap) {
		
		GMMap oMap = new GMMap();

		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			

			List<?> list = session.createCriteria(ClksKomisyonFisHavuz.class)
				.add(Restrictions.conjunction()
					.add(Restrictions.eq("islemTarihi", iMap.getDate("TARIH")))
					.add(Restrictions.eq("durumKod", DURUM_KOD_ACIK)))
				.list();
			
			Iterator<?> iterator = list.iterator();
			
			int i = 0;
			
			while(iterator.hasNext()) {
				
				ClksKomisyonFisHavuz clksKomisyonFisHavuz = (ClksKomisyonFisHavuz) iterator.next();

				oMap.put(tableName, i, "KOD", clksKomisyonFisHavuz.getKod());
				oMap.put(tableName, i, "B_A", clksKomisyonFisHavuz.getBA());
				oMap.put(tableName, i, "HESAP_NO", clksKomisyonFisHavuz.getHesapNo());
				oMap.put(tableName, i, "HESAP_TUR_KODU", clksKomisyonFisHavuz.getHesapTurKodu());
				oMap.put(tableName, i, "HESAP_SUBE_KOD", clksKomisyonFisHavuz.getHesapSubeKod());
				oMap.put(tableName, i, "TUTAR", clksKomisyonFisHavuz.getDvTutar());
				oMap.put(tableName, i, "DOVIZ_KOD", clksKomisyonFisHavuz.getDovizKod());
				oMap.put(tableName, i, "ISLEM_TARIHI", iMap.getDate("BANKA_TARIH"));
				oMap.put(tableName, i, "ACIKLAMA", clksKomisyonFisHavuz.getAciklama());
				
				i++;
			}
			
		} catch (Exception e) {
			
			logger.error("BNSPR_TRN2055_FIS_GETIR err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	/**
	 * 
	 * Description : BNSPR_TRN2055.guiml ekrani fis detay tablosunda bir degisiklik oldugu zaman cagirilir,
	 * yeni alacak / borc toplamlarini ve balansi hesaplar. 
	 *
	 * @param iMap (GMMap)
	 *		{FIS_DETAY=[{KOD, B_A, HESAP_NO, TUTAR, DOVIZ_KOD, ISLEM_TARIHI}]}
	 *
	 * @return oMap (GMMap)
	 *      {ALACAK_TOPLAM, BORC_TOPLAM, BALANS}
	 *
	 */
	@GraymoundService("BNSPR_TRN2055_TOPLAM_HESAPLA")
	public static GMMap toplamHesapla(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		
		BigDecimal borcToplam = BigDecimal.ZERO;
		BigDecimal alacakToplam = BigDecimal.ZERO;
		
		try {
			
			for(int i = 0; i < iMap.getSize(tableName); i++) {
				
				// Case: Borc
				if("B".equals(iMap.getString(tableName, i, "B_A"))) {
					
					borcToplam = borcToplam.add(iMap.getBigDecimal(tableName, i, "TUTAR") != null ? iMap.getBigDecimal(tableName, i, "TUTAR") : BigDecimal.ZERO);
				}
				
				// Case: Alacak
				else if("A".equals(iMap.getString(tableName, i, "B_A"))) {
					
					alacakToplam = alacakToplam.add(iMap.getBigDecimal(tableName, i, "TUTAR") != null ? iMap.getBigDecimal(tableName, i, "TUTAR") : BigDecimal.ZERO);
				}
			}
			
			oMap.put("BORC_TOPLAM", borcToplam);
			oMap.put("ALACAK_TOPLAM", alacakToplam);
			oMap.put("BALANS", borcToplam.subtract(alacakToplam));
			
		} catch (Exception e) {
			
			logger.error("BNSPR_TRN2055_TOPLAM_HESAPLA err: " + e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}	
	
    /**
     * Komisyon i�lem toplamlar�n� mutabakat fi� havuz tablosuna kaydeder.
     * 
     * @param iMap
     */
    @GraymoundService("BNSPR_TRN2055_KOM_FIS_HAVUZ_JOB")
    public static GMMap mutFisHavuzJob(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        
        try{
            
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_TRN2055.Kom_Fis_Havuz_Ekle_Job}");
            stmt.execute();
            
        } catch (Exception ex){
            logger.error("BNSPR_TRN2055_KOM_FIS_HAVUZ_JOB err: " + ex);
            throw ExceptionHandler.convertException(ex);
        } finally{
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        return oMap;
    }
}
