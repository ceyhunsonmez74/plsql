package tr.com.calikbank.bnspr.currentaccounts.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EftOtomatikHesapTanimTx;
import tr.com.aktifbank.bnspr.dao.EftOtomatikHesapTanimTxId;
import tr.com.aktifbank.bnspr.dao.KrlKasaTipPrTx;
import tr.com.aktifbank.bnspr.dao.KrlKasaTipPrTxId;
import tr.com.aktifbank.bnspr.dao.MkkKimlikEslestirme;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2150Services {

		@GraymoundService("BNSPR_TRN2150_GET_KASA_TIP_LIST")
			public static GMMap getKasaTipList(GMMap iMap) {
			    Connection conn = null;
			    CallableStatement stmt = null;
			    ResultSet rSet = null;
			    
			    try{
			        conn = DALUtil.getGMConnection();	            
			        stmt = conn.prepareCall("{? = call pkg_trn2150.RC_2150 }");
			        int i = 1;
			        stmt.registerOutParameter(i++, -10);
			        stmt.execute();            
			       rSet = (ResultSet) stmt.getObject(1);
			        
			       return DALUtil.rSetResults(rSet, "RECORD_LIST");
			    }catch (Exception e) {
			        throw ExceptionHandler.convertException(e);
			    }finally{
			        GMServerDatasource.close(rSet);
			        GMServerDatasource.close(stmt);
			        GMServerDatasource.close(conn);
			    }
			}
		
		@GraymoundService("BNSPR_TRN2150_SAVE_RECORDS")
		public static Map<?, ?> save(GMMap iMap) {
		
		    try {
		        Session session = DAOSession.getSession("BNSPRDal");	         
		        
		        String tableName = "KASA_TIPLERI_LIST";
		        List<?>  kasaTipList = (List<?>)iMap.get(tableName);
		        for (int i = 0; i < kasaTipList.size(); i++) {
		                   
		            KrlKasaTipPrTx krlKasaTipPrTx = new KrlKasaTipPrTx();
		            KrlKasaTipPrTxId krlKasaTipPrTxId = new KrlKasaTipPrTxId();
		            krlKasaTipPrTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
		            krlKasaTipPrTxId.setKasaTip(iMap.getString(tableName, i, "KASA_TIP"));
		            krlKasaTipPrTxId.setYil(iMap.getBigDecimal(tableName, i, "YIL"));
		            krlKasaTipPrTx.setId(krlKasaTipPrTxId);
		            krlKasaTipPrTx.setDepozitoBdl(iMap.getBigDecimal(tableName, i, "DEPOZITO_BDL"));
		            krlKasaTipPrTx.setKiraBdl(iMap.getBigDecimal(tableName, i, "KIRA_BDL"));
		            krlKasaTipPrTx.setAnahtarBdl(iMap.getBigDecimal(tableName, i, "ANAHTAR_BDL"));
		            krlKasaTipPrTx.setGDS(iMap.getString(tableName, i , "DURUM"));
		            
		            session.saveOrUpdate(krlKasaTipPrTx);
		        }
		        session.flush();
		
		        iMap.put("TRX_NAME", "2150");
		
		        return GMServiceExecuter
		                .execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		    } catch (Exception e) {
		        throw ExceptionHandler.convertException(e);
		    }
		  }
		
		@GraymoundService("BNSPR_TRN2150_GET_KRL_KASA_BILGI")
		public static GMMap getKrlKasaTipBilgi(GMMap iMap) {
		 //  Connection conn = null;
		   //CallableStatement stmt = null;;
		                  
		    try {
		        Session session = DAOSession.getSession("BNSPRDal");
		        GMMap oMap = new GMMap();
		        List<?> krlKasaTipPrTxList =  session
		                .createCriteria(KrlKasaTipPrTx.class).add(Restrictions.eq("id.txNo",  iMap.getBigDecimal("TRX_NO"))).addOrder(Order.desc("id.yil")).list();
		        
		        String tableName = "KIRALIK_KASA_TIP_LIST";
		        //conn = DALUtil.getGMConnection();       
		        int row = 0;
		        if(krlKasaTipPrTxList != null){
		            
		            for(Iterator<?> iterator = krlKasaTipPrTxList.iterator() ; iterator!=null ? iterator.hasNext() : false; row++ ){
		                            
		                KrlKasaTipPrTx  krlKasaTipPrTx =  (KrlKasaTipPrTx) iterator.next();    	
		                GMMap mMap = new GMMap();
		                mMap.put("KASA_TIP", krlKasaTipPrTx.getId().getKasaTip());
		                mMap.put("YIL", krlKasaTipPrTx.getId().getYil());
		                mMap.put("DEPOZIT_BDL", krlKasaTipPrTx.getDepozitoBdl());
		                
		                oMap.put(tableName, row , "KASA_TIP", krlKasaTipPrTx.getId().getKasaTip());
		                oMap.put(tableName, row , "YIL", krlKasaTipPrTx.getId().getYil());
		                oMap.put(tableName, row , "DEPOZITO_BDL", krlKasaTipPrTx.getDepozitoBdl());
		                oMap.put(tableName, row , "KIRA_BDL", krlKasaTipPrTx.getKiraBdl());
		                oMap.put(tableName, row , "ANAHTAR_BDL", krlKasaTipPrTx.getAnahtarBdl());
		                oMap.put(tableName, row,  "DURUM", krlKasaTipPrTx.getGDS());
		                
		                   if( "I".equals(krlKasaTipPrTx.getGDS()))
		                       oMap.put(tableName, row , "SIL", true);
		                   else
		                       oMap.put(tableName, row , "SIL", false);
		            }
		        }
		        return oMap;
			    } catch (Exception e) {
			        throw ExceptionHandler.convertException(e);
			    }
		
		   }
}