package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhHesapBasvuruGunTx;

import tr.com.aktifbank.bnspr.dao.MuhHesapRezervId;
import tr.com.aktifbank.bnspr.dao.MuhHesapRezerv;
import tr.com.aktifbank.bnspr.dao.MuhHesapRezervTx;
import tr.com.calikbank.bnspr.util.CustomerSettings;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class CurrentAccountsTRN2004Services {

	@GraymoundService("BNSPR_TRN2004_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			
			MuhHesapRezervTx muhHesapRezervTx = (MuhHesapRezervTx) session.get(MuhHesapRezervTx.class, iMap.getBigDecimal("TRX_NO"));

			if (muhHesapRezervTx == null)
				muhHesapRezervTx = new MuhHesapRezervTx();
			
			
			
			muhHesapRezervTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			muhHesapRezervTx.setHesapNo(getAccountNo());
			muhHesapRezervTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			muhHesapRezervTx.setIban(getIbanNo(muhHesapRezervTx.getHesapNo()));
			muhHesapRezervTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			muhHesapRezervTx.setAciklama(iMap.getString("ACIKLAMA"));
			
			
			session.save(muhHesapRezervTx);
			session.flush(); 

			iMap.put("TRX_NAME", "2004");

			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	

	
	@GraymoundService("BNSPR_TRN2004_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			MuhHesapRezervTx muhHesapRezervTx = (MuhHesapRezervTx) session.get(MuhHesapRezervTx.class, iMap.getBigDecimal("TRX_NO"));
			oMap.put("TRX_NO", muhHesapRezervTx.getTxNo());
			oMap.put("HESAP_NO", muhHesapRezervTx.getHesapNo());
			oMap.put("MUSTERI_NO", muhHesapRezervTx.getMusteriNo());
			oMap.put("IBAN", muhHesapRezervTx.getIban());
			oMap.put("DOVIZ_KODU", muhHesapRezervTx.getDovizKodu());
			oMap.put("ACIKLAMA", muhHesapRezervTx.getAciklama());
			oMap.put("UNVAN", LovHelper.diLov(muhHesapRezervTx.getMusteriNo(), 
					"2004/LOV_MUSTERI_NO", "UNVAN" ));
			
			
		    return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	public static BigDecimal getAccountNo() {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_GENEL_PR.genel_kod_al('HESAP.VDSZ')}");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.execute();
			return stmt.getBigDecimal(1);
			
			

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}   
	
	public static String getIbanNo(BigDecimal hesapNo) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call Pkg_Iban.sp_IBAN_al(?)}");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setBigDecimal(2,hesapNo);
			stmt.execute();
			return stmt.getString(1);
			
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
