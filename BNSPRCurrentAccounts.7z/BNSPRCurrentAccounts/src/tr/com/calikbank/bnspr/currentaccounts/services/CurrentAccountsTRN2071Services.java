package tr.com.calikbank.bnspr.currentaccounts.services;

import java.io.BufferedWriter;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.lang.reflect.Field;
import java.math.BigDecimal;
import tr.com.aktifbank.bnspr.dao.ClksKreTahsilGelenDosyaTx;
import tr.com.aktifbank.bnspr.dao.ClksKreTahsilGelenDosyaTxId;
import tr.com.aktifbank.bnspr.dao.ClksKreTahsilGelenMainTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.TakasCekGirisAnaTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.graymound.util.GMToolkit;

import java.text.SimpleDateFormat;

import jxl.Sheet;
import jxl.Workbook;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;

public class CurrentAccountsTRN2071Services {
	private static String ROOT 		= GMServer.getProperty("graymound.home",null)	+
																	File.separator 	+
																	"Server"		+
																	File.separator 	+
																	"Content"		+
																	File.separator	+
																	"Root"			;

	
	@GraymoundService("BNSPR_TRN2071_DOSYA_OLUSTUR")
	public static GMMap dosyaOlustur(GMMap iMap){
		GMMap 				oMap 	= new GMMap();
		Connection 			conn 	= null;
		PreparedStatement   stmt2    = null;
		CallableStatement 	stmt 	= null;
		ResultSet 			rSet 	= null;
		BigDecimal  dosya_no = null;
		try{
			conn = DALUtil.getGMConnection();
			StringBuffer query = new StringBuffer();
			FileOutputStream fout;
			BufferedWriter bw;
			
			String kullaniciKod = GMServiceExecuter.call("BNSPR_COMMON_GET_KULLANICI_KOD", 
					iMap).getString("KULLANICI_KOD");
			String dosyaAdi = iMap.getString("DOSYA_ADI") + "_" + kullaniciKod + ".txt";
			
			fout = new FileOutputStream(ROOT + File.separator + "files" + File.separator + dosyaAdi);
			bw = new BufferedWriter(new OutputStreamWriter(fout,"ISO-8859-9"));
			
			stmt = conn.prepareCall("{? = call PKG_PTT_DOSYA.PTT_KREDI_TAHSIL_DOSYA_URET(?) }");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setString(2,iMap.getString("GUN_SONU_GECMEDI").equals("true") ? "Y" : null);
			
			stmt.execute();
			
			dosya_no = stmt.getBigDecimal(1);
			query.append("SELECT DATA FROM CLKS_PTT_DOSYA T ");
			query.append("WHERE DOSYA_NO = ? ");
			query.append("ORDER BY SIRA ");
			
		    stmt2 = conn.prepareStatement(query.toString());
		    stmt2.setBigDecimal(1, dosya_no);
			rSet = stmt2.executeQuery();
			
				
			while(rSet.next())
			   bw.write(new String(rSet.getString(1).getBytes("ISO-8859-9"),"ISO-8859-9")+((char)13) + ((char)10));
			
			bw.close();
			fout.close();
		
			
			stmt = conn.prepareCall("{? = call pkg_hata.mesajOlustur(1184) }");
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();
			
			String message = stmt.getString(1);
			
			oMap.put("TEMP_DOSYA_ADI", dosyaAdi);
			//oMap.put("MESSAGE", message);
			return oMap;
	
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2071_DELETE_TMP_FILE")
	public static GMMap deleteTmFile(GMMap iMap) {
		try {
			File file = new File(ROOT + File.separator + "files" + File.separator + iMap.getString("TEMP_DOSYA_ADI"));
			file.delete();
			
			
			GMMap oMap = new GMMap();
			oMap.put("MESSAGE_NO", new BigDecimal(1184));
			oMap.put("MESSAGE", GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", oMap).get("ERROR_MESSAGE"));
		
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN2071_GET_BANKA_TARIHI")
	public static GMMap getBankaTarihi(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn
					.prepareCall("{? = call PKG_MUHASEBE.BANKA_TARIHI_BUL()}");

			stmt.registerOutParameter(1, Types.DATE);
			stmt.execute();

			Date bankaTarihi = stmt.getDate(1);
			SimpleDateFormat sdf = new SimpleDateFormat("ddMMyy");


			
			oMap.put("BANKA_TARIHI", sdf.format(bankaTarihi));

			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN2071_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal"); 
			GMMap oMap = new GMMap();
			
			// Header & Footer
			String strDesenHeader	= new String(GMToolkit.getFileContent(new File(ROOT+
																	File.separator	+
																	"files"			+
																	File.separator	+
																	"PTT_TAHSILAT_HEADER.TXT")));
			
			String strDesenFooter	= new String(GMToolkit.getFileContent(new File(ROOT+
					File.separator	+
					"files"			+
					File.separator	+
					"PTT_TAHSILAT_FOOTER.TXT")));
		
			
			StringTokenizer fileTok = new StringTokenizer(new String((byte[])iMap.get("FILE"),"ISO-8859-9"), "\n");

			String header = "";
			String footer = "";
			int rowCount = fileTok.countTokens();
			//Class<?> pojo = Class.forName("ClksKreTahsilGelenMainTx");
			ClksKreTahsilGelenMainTx mainTx = new ClksKreTahsilGelenMainTx();
			mainTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			String dosya = iMap.getString("DOSYA_ADI");
			String d = dosya.substring(dosya.lastIndexOf('\\')+1);
			mainTx.setDosyaAdi(d);
			for (int row=0;row<rowCount;row++){
				String file = fileTok.nextToken();
				
				if(row==0) {
					
					StringTokenizer desenTok = new StringTokenizer(strDesenHeader, "\r\n");
					header = file;
					
					while (desenTok.hasMoreTokens()) {
						String style = desenTok.nextToken();
										
						StringTokenizer dT = new StringTokenizer(style, "-");
						int toIndex = new Integer(dT.nextToken()) - 1;
						int fromIndex = new Integer(dT.nextToken());
						String columnName = dT.nextToken();
						
						String value = header.substring(toIndex, toIndex + fromIndex);
						
						if(columnName.equals("PTT_KODU")){
							mainTx.setPttKodu(value);
						}
						if(columnName.equals("TAHSIL_TARIHI")) {
							mainTx.setTahsilTarihi(value);
						}
					
					}
				}
			//	session.save(mainTx);
	
				
				//StringTokenizer fileTok = new StringTokenizer(new String((byte[])iMap.get("FILE"),"ISO-8859-9"), "\n");
				
				if(row == rowCount-1) {
					StringTokenizer desenTok = new StringTokenizer(strDesenFooter, "\r\n");
					footer = file;
					
					while (desenTok.hasMoreTokens()) {
						String style = desenTok.nextToken();
										
						StringTokenizer dT = new StringTokenizer(style, "-");
						int toIndex = new Integer(dT.nextToken()) - 1;
						int fromIndex = new Integer(dT.nextToken());
						String columnName = dT.nextToken();
						
						String value = footer.substring(toIndex, toIndex + fromIndex);
						
						if(columnName.equals("TOPLAM_ADET")) {
							mainTx.setToplamAdet(new BigDecimal(value));
						}
						if(columnName.equals("TOPLAM_TUTAR")) {
							mainTx.setToplamTutar(new BigDecimal(value));
						}
						
						
					}
				}
			}
			session.save(mainTx);
			// end
			
			
			String tableName = "KREDI_TAHSILAT_DOSYA_KAYITLARI";
			List<?> guiList = (List<?>)iMap.get(tableName);
			for (int i = 0; i < guiList.size(); i++) {
				ClksKreTahsilGelenDosyaTx dosyaTx = new ClksKreTahsilGelenDosyaTx();
				ClksKreTahsilGelenDosyaTxId clksKreTahsilGelenDosyaTxId = new ClksKreTahsilGelenDosyaTxId();
				
				
				stmt = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al('CLKS_KRE_TAHSIL_GELEN_DOSYA_TX')}");
				stmt.registerOutParameter(1, Types.NUMERIC);

				

				
				stmt.execute();
				
			//	BigDecimal code = stmt.getBigDecimal(1);
			
				
				
				clksKreTahsilGelenDosyaTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				clksKreTahsilGelenDosyaTxId.setSiraNo(new BigDecimal(i));
				dosyaTx.setId(clksKreTahsilGelenDosyaTxId);
				
			//	clksKreTahsilGelenDosyaTxId.setsetId(code);
				dosyaTx.setKurumKodu(iMap.getString(tableName, i, "KURUM_KODU"));
				dosyaTx.setAd(iMap.getString(tableName, i,"AD"));
				dosyaTx.setSoyad(iMap.getString(tableName, i,"SOYAD"));
				dosyaTx.setKrediTuru(iMap.getString(tableName, i,"KREDI_TURU"));
				dosyaTx.setKimlikNo(iMap.getString(tableName, i,"KIMLIK_NO"));
				dosyaTx.setTahsilTarihi(iMap.getDate(tableName, i,"TAHSIL_TARIHI"));
				dosyaTx.setOdemeTuru(iMap.getString(tableName, i,"ODEME_TURU"));
				dosyaTx.setTaksitSayisi(iMap.getString(tableName, i,"TAKSIT_SAYISI"));
				dosyaTx.setTaksitTutari(iMap.getBigDecimal(tableName, i,"TAKSIT_TUTARI"));
				dosyaTx.setBasvuruNo(iMap.getBigDecimal(tableName, i,"BASVURU_NO"));

				
				
				session.save(dosyaTx);
				GMServerDatasource.close(stmt);
			}
			
			session.flush();  
			
			iMap.put("TRX_NAME", "2071");
			return   GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	} 


	
	@GraymoundService("BNSPR_TRN2071_LOAD_FILE")
	public static GMMap loadFile(GMMap iMap) {
		

		try{
			GMMap oMap 			= new GMMap();
			String strDesen		= new String(GMToolkit.getFileContent(new File(
																	GMServer.getProperty("graymound.home",null)+
																	File.separator	+
																	"Server"		+
																	File.separator	+
																	"Content"		+
																	File.separator	+
																	"Root"			+
																	File.separator	+
																	"files"			+
																	File.separator	+
																	"PTT_TAHSILAT.TXT")));
			
			StringTokenizer fileTok = new StringTokenizer(new String((byte[])iMap.get("FILE"),"ISO-8859-9"), "\n");
			
			String tableName 	= "KREDI_TAHSILAT_DOSYA_KAYITLARI";
			
			int rowCount = fileTok.countTokens();
			for (int row=0;row<rowCount;row++){
				
				String header = "";
				String footer = "";
				
				StringTokenizer desenTok = new StringTokenizer(strDesen, "\r\n");
				
				if(row==0) {
					header = fileTok.nextToken();
					
					continue;
				}
				if(row == rowCount-1) {
					footer = fileTok.nextToken();
//					oMap.put("", value)
					continue;
				}
							
				String file = fileTok.nextToken();
				while (desenTok.hasMoreTokens()) {
					String style = desenTok.nextToken();
									
					StringTokenizer dT = new StringTokenizer(style, "-");
					int toIndex = new Integer(dT.nextToken()) - 1;
					int fromIndex = new Integer(dT.nextToken());
					String columnName = dT.nextToken();
					
					String value = file.substring(toIndex, toIndex + fromIndex);

					// ilk sat�r header
					oMap.put(tableName,row-1,columnName,value);
				}
			}
			return oMap;
		} 
		catch (NonUniqueObjectException e) {
			GMMap myMap = new GMMap ();
			myMap.put("MESSAGE_NO", new BigDecimal(1743));
			return CurrentAccountsCommonServices.throwGMBusssinessException(GMServiceExecuter.call("BNSPR_COMMON_GET_ERROR_MESSAGE", myMap).getString("ERROR_MESSAGE"));
		}
	    catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
} 
