package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.GnlDokumanKodPr;
import tr.com.aktifbank.bnspr.dao.GnlMusteriimajDetay;
import tr.com.aktifbank.bnspr.dao.GnlParamText;
import tr.com.aktifbank.bnspr.pdfViewerPanelBean.ByteArrayType;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.CariNakitYatanTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2016Services {
    @GraymoundService("BNSPR_TRN2016_SAVE")
    public static Map<?, ?> save(GMMap iMap) {
        try{
            
            Session session = DAOSession.getSession("BNSPRDal");
            CariNakitYatanTx cariNakitYatanTx = (CariNakitYatanTx) session.get(CariNakitYatanTx.class , iMap.getBigDecimal("TRX_NO"));
            if (cariNakitYatanTx == null)
                cariNakitYatanTx = new CariNakitYatanTx();
            cariNakitYatanTx.setAciklama(iMap.getString("ACIKLAMA"));
            cariNakitYatanTx.setDkNo(iMap.getString("DK_NO"));
            cariNakitYatanTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
            cariNakitYatanTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
            cariNakitYatanTx.setIslemSekli(iMap.getString("ISLEM_SEKLI"));
            cariNakitYatanTx.setIslemTarihi(GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH" , new GMMap()).getDate("BANKA_TARIH"));
            cariNakitYatanTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
            cariNakitYatanTx.setReferansNo(iMap.getString("REFERANS_NO"));
            cariNakitYatanTx.setTutar(iMap.getBigDecimal("TUTAR"));
            cariNakitYatanTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            cariNakitYatanTx.setValorTarihi(iMap.getDate("VALOR_TARIHI"));
            cariNakitYatanTx.setKasaKimlikTipi(iMap.getBigDecimal("KIMLIK_TIPI"));
            cariNakitYatanTx.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
            cariNakitYatanTx.setSubeKodu(iMap.getString("SUBE_KODU"));
            
            cariNakitYatanTx.setMasrafTahsilDoviz(iMap.getString("MASRAF_TAHSIL_DOVIZ"));
            cariNakitYatanTx.setMasrafTahsilSekli(iMap.getString("MASRAF_TAHSIL_SEKLI"));
            cariNakitYatanTx.setMasrafHesapNo(iMap.getBigDecimal("MASRAF_HESABI"));
            cariNakitYatanTx.setMasrafTutari(iMap.getBigDecimal("MASRAF_TUTARI"));
            cariNakitYatanTx.setMasrafTutariMasDvz(iMap.getBigDecimal("MASRAF_TUTARI_MAS_DVZ"));
            cariNakitYatanTx.setOdemeTuru(iMap.getBigDecimal("ODEME_TURU"));
            
            session.saveOrUpdate(cariNakitYatanTx);
            session.flush();
            
            iMap.put("TRX_NAME" , "2016");
            return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN2016_CHECK_DOVIZ_TUTAR")
    public static GMMap checkDovizTutar(GMMap iMap) {
        GMMap oMap = new GMMap();
        String tutar = iMap.getBigDecimal("TUTAR").toString();
        Integer index = tutar.indexOf(".");
        String newTutar = String.copyValueOf(tutar.toCharArray() , index + 1 , tutar.length() - (index + 1));
        
        if (newTutar.equals("00")){
            oMap.put("FLAG" , 1);
        } else{
            oMap.put("FLAG" , 0);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN2016_GET_REFERANCE_NO")
    public static GMMap getReferanceNo(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call Pkg_TRN2016.Nakit_Yatan_Referansi_Al}");
            
            stmt.registerOutParameter(1 , Types.VARCHAR);
            
            stmt.execute();
            oMap.put("REFERANS_NO" , stmt.getString(1));
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN2016_SAVE_MASRAF")
    public static GMMap saveMasraf(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            int i = 1;
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call PKG_MASRAF_YENI.MASRAF_YARAT(?,?,?,?,?,?,?)}");
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("TRX_NO"));
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("ISLEM_KODU"));
            stmt.setBigDecimal(i++ , iMap.getBigDecimal("TUTAR"));
            stmt.setString(i++ , iMap.getString("DOVIZ_KODU"));
            String hesapNo = iMap.getString("HESAP_NO");
            if (hesapNo == null || hesapNo.equals("")){
                stmt.setBigDecimal(i++ , null);
                stmt.setString(i++ , null);
                stmt.setString(i++ , null);
            } else{
                stmt.setBigDecimal(i++ , (BigDecimal) GMServiceExecuter.execute("BNSPR_COMMON_GET_MUSTERI_NO" , iMap).get("MUSTERI_NO"));
                stmt.setString(i++ , iMap.getString("HESAP_NO"));
                stmt.setString(i++ , iMap.getString("KARSI_HESAP"));
            }
            stmt.execute();
            return new GMMap();
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN2016_GET_MASRAF_DOVIZ_KARSILIGI")
    public static GMMap getMasrafDovizKarsiligi(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call Pkg_Kur.YUVARLA(?, Pkg_Kur.DOVIZ_CEVIR (?, ?, NULL,?,1,NULL,NULL,'O','A'))}");
            stmt.registerOutParameter(1 , Types.NUMERIC);
            stmt.setString(2 , iMap.getString("MASRAF_DOVIZ"));
            stmt.setString(3 , iMap.getString("ISLEM_DOVIZ"));
            stmt.setString(4 , iMap.getString("MASRAF_DOVIZ"));
            stmt.setBigDecimal(5 , iMap.getBigDecimal("HESAPLANAN_MASRAF_TUTAR"));
            stmt.execute();
            oMap.put("MASRAF_DOVIZ_SONUC" , stmt.getString(1));
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_TRN2016_GET_INFO")
    public static GMMap getTRN2016Info(GMMap iMap) {
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            
            GMMap oMap = new GMMap();
            
            CariNakitYatanTx cariNakitYatanTx = (CariNakitYatanTx) session.load(CariNakitYatanTx.class , iMap.getBigDecimal("TRX_NO"));
            
            ArrayList<Object> lovInputList = new ArrayList<Object>();
            
            oMap.put("REFERANS_NO" , cariNakitYatanTx.getReferansNo());
            oMap.put("ISLEM_SEKLI" , cariNakitYatanTx.getIslemSekli());
            oMap.put("DOVIZ_KODU" , cariNakitYatanTx.getDovizKodu());
            oMap.put("SUBE_KODU" , cariNakitYatanTx.getSubeKodu());
            oMap.put("SUBE_ADI" , LovHelper.diLov(cariNakitYatanTx.getSubeKodu() , "2016/LOV_SUBE" , "ADI"));
            oMap.put("MUSTERI_NO" , cariNakitYatanTx.getMusteriNo());
            oMap.put("UNVAN" , LovHelper.diLov(cariNakitYatanTx.getMusteriNo() , cariNakitYatanTx.getDovizKodu() , null , cariNakitYatanTx.getSubeKodu() , "2016/LOV_MUSTERI" , "UNVAN"));
            oMap.put("HESAP_NO" , cariNakitYatanTx.getHesapNo());
            oMap.put("SUBE" , LovHelper.diLov(cariNakitYatanTx.getHesapNo() , cariNakitYatanTx.getDovizKodu() , cariNakitYatanTx.getMusteriNo() , cariNakitYatanTx.getSubeKodu() ,
                    "2016/LOV_MUSTERI_HESAP" , "SUBE_KODU"));
            oMap.put("KISA_ISIM" , LovHelper.diLov(cariNakitYatanTx.getHesapNo() , cariNakitYatanTx.getDovizKodu() , cariNakitYatanTx.getMusteriNo() , cariNakitYatanTx.getSubeKodu() ,
                    "2016/LOV_MUSTERI_HESAP" , "KISA_ISIM"));
            oMap.put("DK_NO" , cariNakitYatanTx.getDkNo());
            oMap.put("DK_ACIKLAMA" , LovHelper.diLov(cariNakitYatanTx.getDkNo() , cariNakitYatanTx.getSubeKodu() , "2016/LOV_DK" , "ACIKLAMA"));
            oMap.put("TUTAR" , cariNakitYatanTx.getTutar());
            oMap.put("VALOR_TARIHI" , cariNakitYatanTx.getValorTarihi());
            oMap.put("ACIKLAMA" , cariNakitYatanTx.getAciklama());
            oMap.put("KIMLIK_TIPI" , cariNakitYatanTx.getKasaKimlikTipi().toString());
            oMap.put("ISTATISTIK_KODU" , cariNakitYatanTx.getIstatistikKodu());
            
            if (cariNakitYatanTx.getIslemSekli().compareTo("DK") == 0){ // DK
                oMap.put("ISTATISTIK_ADI" , LovHelper.diLov(cariNakitYatanTx.getIstatistikKodu() , "2016/LOV_ISTATISTIK_DK" , "ACIKLAMA"));
            } else{// MUSTERI
                lovInputList.clear();
                lovInputList.add(cariNakitYatanTx.getMusteriNo().toString());
 //               lovInputList.add(cariNakitYatanTx.getHesapNo().toString());
                
                oMap.put("ISTATISTIK_ADI" , LovHelper.diLov(cariNakitYatanTx.getIstatistikKodu() , "2016/LOV_ISTATISTIK_MUSTERI" , "ACIKLAMA" , lovInputList));
            }
            
            oMap.put("MASRAF_TAHSIL_SEKLI" , cariNakitYatanTx.getMasrafTahsilSekli());
            oMap.put("MASRAF_HESAP_NO" , cariNakitYatanTx.getMasrafHesapNo());
            oMap.put("MASRAF_TUTARI" , cariNakitYatanTx.getMasrafTutari());
            oMap.put("MASRAF_TUTARI_MAS_DVZ" , cariNakitYatanTx.getMasrafTutariMasDvz());
            oMap.put("MASRAF_TAHSIL_DOVIZ" , cariNakitYatanTx.getMasrafTahsilDoviz());
            oMap.put("ODEME_TURU" , cariNakitYatanTx.getOdemeTuru());
            oMap.put("MASRAF_THSL_DVZ_ADI" , LovHelper.diLov(cariNakitYatanTx.getMasrafTahsilDoviz() , cariNakitYatanTx.getDovizKodu() , "2016/LOV_MASRAF_THSL_DVZ" , "ACIKLAMA"));
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_TRN2016_CHECK_FARKLILIK")
    public static GMMap checkFarklilik(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call Pkg_TRN2016.Farklilik_Kaydi_Varmi(?)}");
            
            stmt.registerOutParameter(1 , Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
            
            stmt.execute();
            oMap.put("SONUC" , stmt.getString(1));
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }   
     
    @GraymoundService("BNSPR_TRN2016_MUSHESAP_KONTROL")
    public static GMMap MUSHESAP_KONTROL(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{? = call Pkg_TRN2016.MUSHESAP_KONTROL(?)}");
            
            stmt.registerOutParameter(1 , Types.VARCHAR);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
            
            stmt.execute();
            oMap.put("MESSAGE_FOR_HESAP" , stmt.getString(1));
            
            return oMap;
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }  
    
    @GraymoundService("BNSPR_MUS_CALISMASEKLI_MESLEK_KONTROL")
    public static GMMap MUS_CALISMASEKLI_MESLEK_KONTROL(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{ call Pkg_Musteri_Ek.Calismasekli_Meslek_Kontrol(?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));
           
            stmt.execute();
            return new GMMap();
            //oMap.put("MESSAGE_FOR_MUSTERI" , stmt.getString(1));
            
           
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }  
	
    
    @GraymoundService("BNSPR_KASA_MUS_CALISMASEKLI_MESLEK_KONTROL")
    public static GMMap KASA_MUS_CALISMASEKLI_MESLEK_KONTROL(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        try{
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();
            
            stmt = conn.prepareCall("{call Pkg_kasa.Calismasekli_Meslek_Kontrol(?)}");
             
			stmt.setBigDecimal(1, iMap.getBigDecimal("TX_NO"));
            
            stmt.execute(); 
            
            return new GMMap();
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        } finally{
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }  
	
   
    
}
