package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;

public class CurrentAccountsQRY8101Services {

	@GraymoundService("BNSPR_QRY8101_FOM_RECONCILIATION")
	public static GMMap getFomReconciliation(GMMap iMap) {

		GMMap oMap = new GMMap();

		String procStr = "{ call PKG_RC8101.getSumOfProcess(?,?,?,?,?)}";

		BigDecimal AKTIFBANK_ISLEM_TUTAR = new BigDecimal(0);
		BigDecimal YIM_ISLEM_TUTAR = new BigDecimal(0);
		BigDecimal AKTIFBANK_ISLEM_TUTAR_IPTAL = new BigDecimal(0);
		BigDecimal YIM_ISLEM_TUTAR_IPTAL = new BigDecimal(0);
		BigDecimal AKTIFBANK_ISLEM_TUTARI_EFT = new BigDecimal(0);
		BigDecimal YIM_ISLEM_TUTAR_EFT = new BigDecimal(0);
		BigDecimal AKTIFBANK_ISLEM_TUTAR_HAVALE = new BigDecimal(0);
		BigDecimal YIM_ISLEM_TUTAR_HAVALE = new BigDecimal(0);
		BigDecimal AKTIFBANK_ISLEM_TUTAR_IPTAL_HAVALE = new BigDecimal(0);
		BigDecimal YIM_ISLEM_TUTAR_IPTAL_HAVALE = new BigDecimal(0);
		BigDecimal AKTIFBANK_ISLEM_TUTAR_TAKSIT_TAHSILATI = new BigDecimal(0);
		BigDecimal AKTIFBANK_ISLEM_TUTAR_IPTAL_TAKSIT_TAHSILATI = new BigDecimal(0);
		BigDecimal YIM_ISLEM_TUTAR_TAKSIT_TAHSILATI = new BigDecimal(0);
		BigDecimal YIM_ISLEM_TUTAR_IPTAL_TAKSIT_TAHSILATI = new BigDecimal(0);
		BigDecimal AKTIFBANK_ISLEM_TUTARI_EFT_IPTAL = new BigDecimal(0);
		BigDecimal YIM_ISLEM_TUTAR_EFT_IPTAL = new BigDecimal(0);
		BigDecimal AKTIFBANK_ISLEM_TUTAR_TOPLAM_TTAHSILATI = new BigDecimal(0);
		BigDecimal YIM_ISLEM_TUTAR_TOPLAM_TTAHSILATI = new BigDecimal(0);
		BigDecimal AKTIFBANK_ISLEM_TUTAR_TOPLAM_HAVALE = new BigDecimal(0);
		BigDecimal YIM_ISLEM_TUTAR_TOPLAM_HAVALE = new BigDecimal(0);
		BigDecimal AKTIFBANK_ISLEM_TUTAR_TOPLAM_EFT = new BigDecimal(0);
		BigDecimal YIM_ISLEM_TUTAR_TOPLAM_EFT = new BigDecimal(0);
		BigDecimal BORC = new BigDecimal(0);
		BigDecimal BORC_EFT = new BigDecimal(0);
		BigDecimal BORC_HAVALE = new BigDecimal(0);
		BigDecimal BORC_TAKSIT_TAHSILATI = new BigDecimal(0);

		int i = 0;

		Object[] inputValues = new Object[6];
		Object[] outputValues = new Object[4];

		try {
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("ISLEM_TIP");
			inputValues[i++] = BnsprType.DATE;
			inputValues[i++] = iMap.getDate("ISLEM_TARIHI");
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("MUTABAKATSIZ");

			i = 0;
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "RC_LIST";
			outputValues[i++] = BnsprType.REFCURSOR;
			outputValues[i++] = "RC_RECONCILIATION_LIST";

			GMMap resultMap = (GMMap) DALUtil.callOracleProcedure(procStr, inputValues, outputValues);

			String tableName = "RC_LIST";
			String sumTableName = "RC_OZET_TABLO";
			String grandTotalTableNameTaksitTahsilati = "RC_LIST_GENEL_TOPLAM_TAKSIT_TAHSILATI";
			String grandTotalTableNameHavale = "RC_LIST_GENEL_TOPLAM_HAVALE";
			String grandTotalTableNameEft = "RC_LIST_GENEL_TOPLAM_EFT";
			String eftTableName = "RC_LIST_EFT";
			String havaleTableName = "RC_LIST_HAVALE";
			String taksitTahsilatiTableName = "RC_LIST_TAKSIT_TAHSILATI";

			oMap.putAll(resultMap);

			int j = 0;
			int AKTIFBANK_ISLEM_ADET = 0;
			int AKTIFBANK_ISLEM_ADET_EFT_IPTAL = 0;
			int YIM_ISLEM_ADET_EFT_IPTAL = 0;
			int YIM_ISLEM_ADET = 0;
			int AKTIFBANK_ISLEM_ADET_IPTAL = 0;
			int YIM_ISLEM_ADET_IPTAL = 0;
			int AKTIFBANK_ISLEM_ADET_EFT = 0;
			int YIM_ISLEM_ADET_EFT = 0;
			int AKTIFBANK_ISLEM_ADET_HAVALE = 0;
			int YIM_ISLEM_ADET_HAVALE = 0;
			int AKTIFBANK_ISLEM_ADET_IPTAL_HAVALE = 0;
			int YIM_ISLEM_ADET_IPTAL_HAVALE = 0;
			int AKTIFBANK_ISLEM_ADET_TAKSIT_TAHSILATI = 0;
			int YIM_ISLEM_ADET_TAKSIT_TAHSILATI = 0;
			int AKTIFBANK_ISLEM_ADET_IPTAL_TAKSIT_TAHSILATI = 0;
			int YIM_ISLEM_ADET_IPTAL_TAKSIT_TAHSILATI = 0;

			for (j = 0; j < oMap.getSize(tableName); j++) {

				if ("P".equals(oMap.getString(tableName, j, "AKTIFBANK_DURUM")) || "2".equals(oMap.getString(tableName, j, "AKTIFBANK_DURUM"))) {
					if (oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI") != null) {
						AKTIFBANK_ISLEM_TUTAR = AKTIFBANK_ISLEM_TUTAR.add(oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI"));
						AKTIFBANK_ISLEM_ADET++;

					}
				}
				if ("P".equals(oMap.getString(tableName, j, "YIM_DURUM")) || "2".equals(oMap.getString(tableName, j, "YIM_DURUM"))) {
					if (oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI") != null) {
						YIM_ISLEM_TUTAR = YIM_ISLEM_TUTAR.add(oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI"));
						YIM_ISLEM_ADET++;

					}
				}

				if ("2".equals(oMap.getString(tableName, j, "AKTIFBANK_DURUM"))) {
					if (oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI") != null) {
						AKTIFBANK_ISLEM_TUTAR_IPTAL = AKTIFBANK_ISLEM_TUTAR_IPTAL.add(oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI"));
						AKTIFBANK_ISLEM_ADET_IPTAL++;

					}
				}
				if ("2".equals(oMap.getString(tableName, j, "YIM_DURUM"))) {
					if (oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI") != null) {
						YIM_ISLEM_TUTAR_IPTAL = YIM_ISLEM_TUTAR_IPTAL.add(oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI"));
						YIM_ISLEM_ADET_IPTAL++;

					}
				}
				BORC = (YIM_ISLEM_TUTAR.subtract(YIM_ISLEM_TUTAR_IPTAL));

			}

			oMap.put(sumTableName, 0, "DEGER_ADI", "YATAN ��LEM TOPLAMI");
			oMap.put(sumTableName, 0, "AKTIFBANK", AKTIFBANK_ISLEM_TUTAR);
			oMap.put(sumTableName, 0, "YIM", YIM_ISLEM_TUTAR);
			oMap.put(sumTableName, 1, "DEGER_ADI", "YATAN ��LEM ADED�");
			oMap.put(sumTableName, 1, "AKTIFBANK", AKTIFBANK_ISLEM_ADET);
			oMap.put(sumTableName, 1, "YIM", YIM_ISLEM_ADET);
			oMap.put(sumTableName, 2, "DEGER_ADI", "�PTAL YATAN ��LEM TOPLAMI");
			oMap.put(sumTableName, 2, "AKTIFBANK", AKTIFBANK_ISLEM_TUTAR_IPTAL);
			oMap.put(sumTableName, 2, "YIM", YIM_ISLEM_TUTAR_IPTAL);
			oMap.put(sumTableName, 3, "DEGER_ADI", "�PTAL YATAN ��LEM ADED�");
			oMap.put(sumTableName, 3, "AKTIFBANK", AKTIFBANK_ISLEM_ADET_IPTAL);
			oMap.put(sumTableName, 3, "YIM", YIM_ISLEM_ADET_IPTAL);
			oMap.put(sumTableName, 4, "DEGER_ADI", "BOR�");
			oMap.put(sumTableName, 4, "AKTIFBANK", "0.00");
			oMap.put(sumTableName, 4, "YIM", BORC);

			for (j = 0; j < oMap.getSize(tableName); j++) {

				// Case: EFT
				if ("2315".equals(oMap.getString(tableName, j, "ISLEM_TIPI"))) {
					if (oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI") != null && ("P".equals(oMap.getString(tableName, j, "AKTIFBANK_DURUM")) || "2".equals(oMap.getString(tableName, j, "AKTIFBANK_DURUM")))) {
						AKTIFBANK_ISLEM_TUTARI_EFT = AKTIFBANK_ISLEM_TUTARI_EFT.add(oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI"));
						AKTIFBANK_ISLEM_ADET_EFT = AKTIFBANK_ISLEM_ADET_EFT + 1;

					}

					if (oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI") != null && "2".equals(oMap.getString(tableName, j, "AKTIFBANK_DURUM"))) {
						AKTIFBANK_ISLEM_TUTARI_EFT_IPTAL = AKTIFBANK_ISLEM_TUTARI_EFT_IPTAL.add(oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI"));
						AKTIFBANK_ISLEM_ADET_EFT_IPTAL = AKTIFBANK_ISLEM_ADET_EFT_IPTAL + 1;

					}

					if (oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI") != null && ("P".equals(oMap.getString(tableName, j, "YIM_DURUM")) || "2".equals(oMap.getString(tableName, j, "YIM_DURUM")))) {
						YIM_ISLEM_TUTAR_EFT = YIM_ISLEM_TUTAR_EFT.add(oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI"));
						YIM_ISLEM_ADET_EFT = YIM_ISLEM_ADET_EFT + 1;

					}
					if (oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI") != null && "2".equals(oMap.getString(tableName, j, "YIM_DURUM"))) {
						YIM_ISLEM_TUTAR_EFT_IPTAL = YIM_ISLEM_TUTAR_EFT_IPTAL.add(oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI"));
						YIM_ISLEM_ADET_EFT_IPTAL = YIM_ISLEM_ADET_EFT_IPTAL + 1;

					}
				}
				BORC_EFT = YIM_ISLEM_TUTAR_EFT.subtract(YIM_ISLEM_TUTAR_EFT_IPTAL);
			}
			oMap.put(eftTableName, 0, "DEGER_ADI", "YATAN ��LEM TOPLAMI");
			oMap.put(eftTableName, 0, "AKTIFBANK", AKTIFBANK_ISLEM_TUTARI_EFT);
			oMap.put(eftTableName, 0, "YIM", YIM_ISLEM_TUTAR_EFT);
			oMap.put(eftTableName, 1, "DEGER_ADI", "YATAN ��LEM ADED�");
			oMap.put(eftTableName, 1, "AKTIFBANK", AKTIFBANK_ISLEM_ADET_EFT);
			oMap.put(eftTableName, 1, "YIM", YIM_ISLEM_ADET_EFT);
			oMap.put(eftTableName, 2, "DEGER_ADI", "�PTAL YATAN ��LEM TOPLAMI");
			oMap.put(eftTableName, 2, "AKTIFBANK", AKTIFBANK_ISLEM_TUTARI_EFT_IPTAL);
			oMap.put(eftTableName, 2, "YIM", YIM_ISLEM_TUTAR_EFT_IPTAL);
			oMap.put(eftTableName, 3, "DEGER_ADI", "�PTAL YATAN ��LEM ADED�");
			oMap.put(eftTableName, 3, "AKTIFBANK", AKTIFBANK_ISLEM_ADET_EFT_IPTAL);
			oMap.put(eftTableName, 3, "YIM", YIM_ISLEM_ADET_EFT_IPTAL);
			oMap.put(eftTableName, 4, "DEGER_ADI", "BOR�");
			oMap.put(eftTableName, 4, "AKTIFBANK", "0.00");
			oMap.put(eftTableName, 4, "YIM", BORC_EFT);

			// Case:HAVALE
			for (j = 0; j < oMap.getSize(tableName); j++) {

				if ("2030".equals(oMap.getString(tableName, j, "ISLEM_TIPI"))) {

					if ("2".equals(oMap.getString(tableName, j, "AKTIFBANK_DURUM")) || "P".equals(oMap.getString(tableName, j, "AKTIFBANK_DURUM"))) {
						if (oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI") != null) {
							AKTIFBANK_ISLEM_TUTAR_HAVALE = AKTIFBANK_ISLEM_TUTAR_HAVALE.add(oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI"));
							AKTIFBANK_ISLEM_ADET_HAVALE = AKTIFBANK_ISLEM_ADET_HAVALE + 1;

						}
					}
					if ("2".equals(oMap.getString(tableName, j, "YIM_DURUM")) || "P".equals(oMap.getString(tableName, j, "YIM_DURUM"))) {
						if (oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI") != null) {
							YIM_ISLEM_TUTAR_HAVALE = YIM_ISLEM_TUTAR_HAVALE.add(oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI"));
							YIM_ISLEM_ADET_HAVALE = YIM_ISLEM_ADET_HAVALE + 1;

						}
					}

					if ("2".equals(oMap.getString(tableName, j, "AKTIFBANK_DURUM"))) {
						if (oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI") != null) {
							AKTIFBANK_ISLEM_TUTAR_IPTAL_HAVALE = AKTIFBANK_ISLEM_TUTAR_IPTAL_HAVALE.add(oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI"));
							AKTIFBANK_ISLEM_ADET_IPTAL_HAVALE = AKTIFBANK_ISLEM_ADET_IPTAL_HAVALE + 1;

						}
					}
					if ("2".equals(oMap.getString(tableName, j, "YIM_DURUM"))) {
						if (oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI") != null) {
							YIM_ISLEM_TUTAR_IPTAL_HAVALE = YIM_ISLEM_TUTAR_IPTAL_HAVALE.add(oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI"));
							YIM_ISLEM_ADET_IPTAL_HAVALE = YIM_ISLEM_ADET_IPTAL_HAVALE + 1;

						}
					}
				}
				BORC_HAVALE = YIM_ISLEM_TUTAR_HAVALE.subtract(YIM_ISLEM_TUTAR_IPTAL_HAVALE);
			}

			oMap.put(havaleTableName, 0, "DEGER_ADI", "YATAN ��LEM TOPLAMI");
			oMap.put(havaleTableName, 0, "AKTIFBANK", AKTIFBANK_ISLEM_TUTAR_HAVALE);
			oMap.put(havaleTableName, 0, "YIM", YIM_ISLEM_TUTAR_HAVALE);
			oMap.put(havaleTableName, 1, "DEGER_ADI", "YATAN ��LEM ADED�");
			oMap.put(havaleTableName, 1, "AKTIFBANK", AKTIFBANK_ISLEM_ADET_HAVALE);
			oMap.put(havaleTableName, 1, "YIM", YIM_ISLEM_ADET_HAVALE);
			oMap.put(havaleTableName, 2, "DEGER_ADI", "�PTAL YATAN ��LEM TOPLAMI");
			oMap.put(havaleTableName, 2, "AKTIFBANK", AKTIFBANK_ISLEM_TUTAR_IPTAL_HAVALE);
			oMap.put(havaleTableName, 2, "YIM", YIM_ISLEM_TUTAR_IPTAL_HAVALE);
			oMap.put(havaleTableName, 3, "DEGER_ADI", "�PTAL YATAN ��LEM ADED�");
			oMap.put(havaleTableName, 3, "AKTIFBANK", AKTIFBANK_ISLEM_ADET_IPTAL_HAVALE);
			oMap.put(havaleTableName, 3, "YIM", YIM_ISLEM_ADET_IPTAL_HAVALE);
			oMap.put(havaleTableName, 4, "DEGER_ADI", "BOR�");
			oMap.put(havaleTableName, 4, "AKTIFBANK", "0.00");
			oMap.put(havaleTableName, 4, "YIM", BORC_HAVALE);

			// Case: TAKSIT TAHSILATI
			for (j = 0; j < oMap.getSize(tableName); j++) {

				if ("3133".equals(oMap.getString(tableName, j, "ISLEM_TIPI"))) {
					if ("2".equals(oMap.getString(tableName, j, "AKTIFBANK_DURUM")) || "P".equals(oMap.getString(tableName, j, "AKTIFBANK_DURUM"))) {
						if (oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI") != null) {
							AKTIFBANK_ISLEM_TUTAR_TAKSIT_TAHSILATI = AKTIFBANK_ISLEM_TUTAR_TAKSIT_TAHSILATI.add(oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI"));
							AKTIFBANK_ISLEM_ADET_TAKSIT_TAHSILATI = AKTIFBANK_ISLEM_ADET_TAKSIT_TAHSILATI + 1;

						}
					}
					if ("P".equals(oMap.getString(tableName, j, "YIM_DURUM")) || "P".equals(oMap.getString(tableName, j, "YIM_DURUM"))) {
						if (oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI") != null) {
							YIM_ISLEM_TUTAR_TAKSIT_TAHSILATI = YIM_ISLEM_TUTAR_TAKSIT_TAHSILATI.add(oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI"));
							YIM_ISLEM_ADET_TAKSIT_TAHSILATI = YIM_ISLEM_ADET_TAKSIT_TAHSILATI + 1;

						}
					}
					if ("2".equals(oMap.getString(tableName, j, "AKTIFBANK_DURUM"))) {
						if (oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI") != null) {
							AKTIFBANK_ISLEM_TUTAR_IPTAL_TAKSIT_TAHSILATI = AKTIFBANK_ISLEM_TUTAR_IPTAL_TAKSIT_TAHSILATI.add(oMap.getBigDecimal(tableName, j, "AKTIFBANK_ISLEM_TUTARI"));
							AKTIFBANK_ISLEM_ADET_IPTAL_TAKSIT_TAHSILATI = AKTIFBANK_ISLEM_ADET_IPTAL_TAKSIT_TAHSILATI + 1;

						}
					}
					if ("2".equals(oMap.getString(tableName, j, "YIM_DURUM"))) {
						if (oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI") != null) {
							YIM_ISLEM_TUTAR_IPTAL_TAKSIT_TAHSILATI = YIM_ISLEM_TUTAR_IPTAL_TAKSIT_TAHSILATI.add(oMap.getBigDecimal(tableName, j, "YIM_ISLEM_TUTARI"));
							YIM_ISLEM_ADET_IPTAL_TAKSIT_TAHSILATI = YIM_ISLEM_ADET_IPTAL_TAKSIT_TAHSILATI + 1;

						}
					}
				}
				BORC_TAKSIT_TAHSILATI = YIM_ISLEM_TUTAR_TAKSIT_TAHSILATI.subtract(YIM_ISLEM_TUTAR_IPTAL_TAKSIT_TAHSILATI);
			}

			oMap.put(taksitTahsilatiTableName, 0, "DEGER_ADI", "YATAN ��LEM TOPLAMI");
			oMap.put(taksitTahsilatiTableName, 0, "AKTIFBANK", AKTIFBANK_ISLEM_TUTAR_TAKSIT_TAHSILATI);
			oMap.put(taksitTahsilatiTableName, 0, "YIM", YIM_ISLEM_TUTAR_TAKSIT_TAHSILATI);
			oMap.put(taksitTahsilatiTableName, 1, "DEGER_ADI", "YATAN ��LEM ADED�");
			oMap.put(taksitTahsilatiTableName, 1, "AKTIFBANK", AKTIFBANK_ISLEM_ADET_TAKSIT_TAHSILATI);
			oMap.put(taksitTahsilatiTableName, 1, "YIM", YIM_ISLEM_ADET_TAKSIT_TAHSILATI);
			oMap.put(taksitTahsilatiTableName, 2, "DEGER_ADI", "�PTAL YATAN ��LEM TOPLAMI");
			oMap.put(taksitTahsilatiTableName, 2, "AKTIFBANK", AKTIFBANK_ISLEM_TUTAR_IPTAL_TAKSIT_TAHSILATI);
			oMap.put(taksitTahsilatiTableName, 2, "YIM", YIM_ISLEM_TUTAR_IPTAL_TAKSIT_TAHSILATI);
			oMap.put(taksitTahsilatiTableName, 3, "DEGER_ADI", "�PTAL YATAN ��LEM ADED�");
			oMap.put(taksitTahsilatiTableName, 3, "AKTIFBANK", AKTIFBANK_ISLEM_ADET_IPTAL_TAKSIT_TAHSILATI);
			oMap.put(taksitTahsilatiTableName, 3, "YIM", YIM_ISLEM_ADET_IPTAL_TAKSIT_TAHSILATI);
			oMap.put(taksitTahsilatiTableName, 4, "DEGER_ADI", "BOR�");
			oMap.put(taksitTahsilatiTableName, 4, "AKTIFBANK", "0.00");
			oMap.put(taksitTahsilatiTableName, 4, "YIM", BORC_TAKSIT_TAHSILATI);

			String tableName2 = "RC_RECONCILIATION_LIST";

			int eftSayisi = 0;
			int havaleSayisi = 0;
			int taksitTahsilatiSayisi = 0;
			int YIM_ISLEM_ADET_TOPLAM_TTAHSILATI = 0;
			int AKTIFBANK_ISLEM_ADET_TOPLAM_TTAHSILATI = 0;
			int AKTIFBANK_ISLEM_ADET_TOPLAM_HAVALE = 0;
			int YIM_ISLEM_ADET_TOPLAM_HAVALE = 0;
			int AKTIFBANK_ISLEM_ADET_TOPLAM_EFT = 0;
			int YIM_ISLEM_ADET_TOPLAM_EFT = 0;
			String eftDetailTableName = "RC_LIST_EFT_DETAY";
			String havaleDetailTableName = "RC_LIST_HAVALE_DETAY";
			String taksitTahsDetailTableName = "RC_LIST_TAKSIT_TAHSILATI_DETAY";

			for (int k = 0; k < oMap.getSize(tableName2); k++) {
				String islemTipi = oMap.getString(tableName2, k, "ISLEM_TIPI");

				if ("2315".equals(islemTipi)) {
					oMap.put(eftDetailTableName, eftSayisi, "ISLEM_TIPI_EFT", oMap.getString(tableName2, k, "ISLEMTIPTEXT"));
					oMap.put(eftDetailTableName, eftSayisi, "AKTIFBANK_ISLEM_NO_EFT", oMap.getString(tableName2, k, "AKTIFBANK_ISLEM_NO"));
					oMap.put(eftDetailTableName, eftSayisi, "AKTIFBANK_ISLEM_TUTARI_EFT", oMap.getBigDecimal(tableName2, k, "AKTIFBANK_ISLEM_TUTARI"));
					oMap.put(eftDetailTableName, eftSayisi, "ALICI_TCKN_EFT", oMap.getString(tableName2, k, "ALICI_TCKN"));
					oMap.put(eftDetailTableName, eftSayisi, "YIM_ISLEM_NO_EFT", oMap.getString(tableName2, k, "YIM_ISLEM_NO"));
					oMap.put(eftDetailTableName, eftSayisi, "YIM_ISLEM_TUTARI_EFT", oMap.getBigDecimal(tableName2, k, "YIM_ISLEM_TUTARI"));
					oMap.put(eftDetailTableName, eftSayisi, "AKTIFBANK_DURUM_ACK_EFT", oMap.getString(tableName2, k, "AKTIFBANK_DURUM_ACK"));
					oMap.put(eftDetailTableName, eftSayisi, "YIM_DURUM_ACK_EFT", oMap.getString(tableName2, k, "YIM_DURUM_ACK"));
					eftSayisi++;

					if (oMap.getBigDecimal(tableName2, k, "AKTIFBANK_ISLEM_TUTARI") != null && (oMap.getBigDecimal(tableName2, k, "AKTIFBANK_ISLEM_NO")) != null) {
						AKTIFBANK_ISLEM_TUTAR_TOPLAM_EFT = AKTIFBANK_ISLEM_TUTAR_TOPLAM_EFT.add(oMap.getBigDecimal(tableName2, k, "AKTIFBANK_ISLEM_TUTARI"));
						AKTIFBANK_ISLEM_ADET_TOPLAM_EFT = AKTIFBANK_ISLEM_ADET_TOPLAM_EFT + 1;

					}
					if (oMap.getBigDecimal(tableName2, k, "YIM_ISLEM_TUTARI") != null && (oMap.getBigDecimal(tableName2, k, "YIM_ISLEM_NO")) != null) {
						YIM_ISLEM_TUTAR_TOPLAM_EFT = YIM_ISLEM_TUTAR_TOPLAM_EFT.add(oMap.getBigDecimal(tableName2, k, "YIM_ISLEM_TUTARI"));
						YIM_ISLEM_ADET_TOPLAM_EFT = YIM_ISLEM_ADET_TOPLAM_EFT + 1;
					}
					oMap.put(grandTotalTableNameEft, 0, "TOPLAM", "TOPLAM ��LEM TUTARI");
					oMap.put(grandTotalTableNameEft, 0, "AKTIFBANK", AKTIFBANK_ISLEM_TUTAR_TOPLAM_EFT);
					oMap.put(grandTotalTableNameEft, 0, "YIM", YIM_ISLEM_TUTAR_TOPLAM_EFT);
					oMap.put(grandTotalTableNameEft, 1, "TOPLAM", "TOPLAM ��LEM ADED�");
					oMap.put(grandTotalTableNameEft, 1, "AKTIFBANK", AKTIFBANK_ISLEM_ADET_TOPLAM_EFT);
					oMap.put(grandTotalTableNameEft, 1, "YIM", YIM_ISLEM_ADET_TOPLAM_EFT);
				}

				if ("2030".equals(islemTipi)) {
					oMap.put(havaleDetailTableName, havaleSayisi, "ISLEM_TIPI_HAVALE", oMap.getString(tableName2, k, "ISLEMTIPTEXT"));
					oMap.put(havaleDetailTableName, havaleSayisi, "AKTIFBANK_ISLEM_NO_HAVALE", oMap.getString(tableName2, k, "AKTIFBANK_ISLEM_NO"));
					oMap.put(havaleDetailTableName, havaleSayisi, "AKTIFBANK_ISLEM_TUTARI_HAVALE", oMap.getBigDecimal(tableName2, k, "AKTIFBANK_ISLEM_TUTARI"));
					oMap.put(havaleDetailTableName, havaleSayisi, "ALICI_TCKN_HAVALE", oMap.getString(tableName2, k, "ALICI_TCKN"));
					oMap.put(havaleDetailTableName, havaleSayisi, "YIM_ISLEM_NO_HAVALE", oMap.getString(tableName2, k, "YIM_ISLEM_NO"));
					oMap.put(havaleDetailTableName, havaleSayisi, "YIM_ISLEM_TUTARI_HAVALE", oMap.getBigDecimal(tableName2, k, "YIM_ISLEM_TUTARI"));
					oMap.put(havaleDetailTableName, havaleSayisi, "AKTIFBANK_DURUM_ACK_HAVALE", oMap.getString(tableName2, k, "AKTIFBANK_DURUM_ACK"));
					oMap.put(havaleDetailTableName, havaleSayisi, "YIM_DURUM_ACK_HAVALE", oMap.getString(tableName2, k, "YIM_DURUM_ACK"));
					havaleSayisi++;

					if (oMap.getBigDecimal(tableName2, k, "AKTIFBANK_ISLEM_TUTARI") != null && (oMap.getBigDecimal(tableName2, k, "AKTIFBANK_ISLEM_NO")) != null) {
						AKTIFBANK_ISLEM_TUTAR_TOPLAM_HAVALE = AKTIFBANK_ISLEM_TUTAR_TOPLAM_HAVALE.add(oMap.getBigDecimal(tableName2, k, "AKTIFBANK_ISLEM_TUTARI"));
						AKTIFBANK_ISLEM_ADET_TOPLAM_HAVALE = AKTIFBANK_ISLEM_ADET_TOPLAM_HAVALE + 1;

					}
					if (oMap.getBigDecimal(tableName2, k, "YIM_ISLEM_TUTARI") != null && (oMap.getBigDecimal(tableName2, k, "YIM_ISLEM_NO")) != null) {
						YIM_ISLEM_TUTAR_TOPLAM_HAVALE = YIM_ISLEM_TUTAR_TOPLAM_HAVALE.add(oMap.getBigDecimal(tableName2, k, "YIM_ISLEM_TUTARI"));
						YIM_ISLEM_ADET_TOPLAM_HAVALE = YIM_ISLEM_ADET_TOPLAM_HAVALE + 1;
					}
					oMap.put(grandTotalTableNameHavale, 0, "TOPLAM", "TOPLAM ��LEM TUTARI");
					oMap.put(grandTotalTableNameHavale, 0, "AKTIFBANK", AKTIFBANK_ISLEM_TUTAR_TOPLAM_HAVALE);
					oMap.put(grandTotalTableNameHavale, 0, "YIM", YIM_ISLEM_TUTAR_TOPLAM_HAVALE);
					oMap.put(grandTotalTableNameHavale, 1, "TOPLAM", "TOPLAM ��LEM ADED�");
					oMap.put(grandTotalTableNameHavale, 1, "AKTIFBANK", AKTIFBANK_ISLEM_ADET_TOPLAM_HAVALE);
					oMap.put(grandTotalTableNameHavale, 1, "YIM", YIM_ISLEM_ADET_TOPLAM_HAVALE);
				}
				if ("3133".equals(islemTipi)) {
					oMap.put(taksitTahsDetailTableName, taksitTahsilatiSayisi, "ISLEM_TIPI_TAKSIT_TAHSILATI", oMap.getString(tableName2, k, "ISLEMTIPTEXT"));
					oMap.put(taksitTahsDetailTableName, taksitTahsilatiSayisi, "AKTIFBANK_ISLEM_NO_TAKSIT_TAHSILATI", oMap.getString(tableName2, k, "AKTIFBANK_ISLEM_NO"));
					oMap.put(taksitTahsDetailTableName, taksitTahsilatiSayisi, "AKTIFBANK_ISLEM_TUTARI_TAKSIT_TAHSILATI", oMap.getBigDecimal(tableName2, k, "AKTIFBANK_ISLEM_TUTARI"));
					oMap.put(taksitTahsDetailTableName, taksitTahsilatiSayisi, "ALICI_TCKN_TAKSIT_TAHSILATI", oMap.getString(tableName2, k, "ALICI_TCKN"));
					oMap.put(taksitTahsDetailTableName, taksitTahsilatiSayisi, "YIM_ISLEM_NO_TAKSIT_TAHSILATI", oMap.getString(tableName2, k, "YIM_ISLEM_NO"));
					oMap.put(taksitTahsDetailTableName, taksitTahsilatiSayisi, "YIM_ISLEM_TUTARI_TAKSIT_TAHSILATI", oMap.getBigDecimal(tableName2, k, "YIM_ISLEM_TUTARI"));
					oMap.put(taksitTahsDetailTableName, taksitTahsilatiSayisi, "AKTIFBANK_DURUM_ACK_TAKSIT_TAHSILATI", oMap.getString(tableName2, k, "AKTIFBANK_DURUM_ACK"));
					oMap.put(taksitTahsDetailTableName, taksitTahsilatiSayisi, "YIM_DURUM_ACK_TAKSIT_TAHSILATI", oMap.getString(tableName2, k, "YIM_DURUM_ACK"));
					taksitTahsilatiSayisi++;

					if (oMap.getBigDecimal(tableName2, k, "AKTIFBANK_ISLEM_TUTARI") != null && (oMap.getBigDecimal(tableName2, k, "AKTIFBANK_ISLEM_NO")) != null) {
						AKTIFBANK_ISLEM_TUTAR_TOPLAM_TTAHSILATI = AKTIFBANK_ISLEM_TUTAR_TOPLAM_TTAHSILATI.add(oMap.getBigDecimal(tableName2, k, "AKTIFBANK_ISLEM_TUTARI"));
						AKTIFBANK_ISLEM_ADET_TOPLAM_TTAHSILATI = AKTIFBANK_ISLEM_ADET_TOPLAM_TTAHSILATI + 1;

					}
					if (oMap.getBigDecimal(tableName2, k, "YIM_ISLEM_TUTARI") != null && (oMap.getBigDecimal(tableName2, k, "YIM_ISLEM_NO")) != null) {
						YIM_ISLEM_TUTAR_TOPLAM_TTAHSILATI = YIM_ISLEM_TUTAR_TOPLAM_TTAHSILATI.add(oMap.getBigDecimal(tableName2, k, "YIM_ISLEM_TUTARI"));
						YIM_ISLEM_ADET_TOPLAM_TTAHSILATI = YIM_ISLEM_ADET_TOPLAM_TTAHSILATI + 1;
					}
					oMap.put(grandTotalTableNameTaksitTahsilati, 0, "TOPLAM", "TOPLAM ��LEM TUTARI");
					oMap.put(grandTotalTableNameTaksitTahsilati, 0, "AKTIFBANK", AKTIFBANK_ISLEM_TUTAR_TOPLAM_TTAHSILATI);
					oMap.put(grandTotalTableNameTaksitTahsilati, 0, "YIM", YIM_ISLEM_TUTAR_TOPLAM_TTAHSILATI);
					oMap.put(grandTotalTableNameTaksitTahsilati, 1, "TOPLAM", "TOPLAM ��LEM ADED�");
					oMap.put(grandTotalTableNameTaksitTahsilati, 1, "AKTIFBANK", AKTIFBANK_ISLEM_ADET_TOPLAM_TTAHSILATI);
					oMap.put(grandTotalTableNameTaksitTahsilati, 1, "YIM", YIM_ISLEM_ADET_TOPLAM_TTAHSILATI);
				}
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		return oMap;

	}

	// Genel Paneli Detay Liste Bolumu
	@GraymoundService("BNSPR_QRY8101_FOM_RECONCILIATION_FILTER")
	public static GMMap getFomReconciliationFilter(GMMap iMap) {

		BigDecimal AKTIFBANK_ISLEM_TUTAR = new BigDecimal(0);
		BigDecimal YIM_ISLEM_TUTAR = new BigDecimal(0);

		String grandTotalTableName = "RC_LIST_GENEL_TOPLAM";

		try {

			int j = 0;
			for (int k = 0; k < iMap.getSize("RC_RECONCILIATION_LIST"); k++) {
				if (iMap.getString("RC_RECONCILIATION_LIST", k, "ISLEM_TIPI").equals(iMap.getString("SECILI_ISLEM_TIPI"))) {
					iMap.put("RC_RECONCILIATION_LIST_FILTER", j, "ISLEM_TIPI", iMap.getString("RC_RECONCILIATION_LIST", k, "ISLEMTIPTEXT"));
					iMap.put("RC_RECONCILIATION_LIST_FILTER", j, "AKTIFBANK_ISLEM_NO", iMap.getBigDecimal("RC_RECONCILIATION_LIST", k, "AKTIFBANK_ISLEM_NO"));
					iMap.put("RC_RECONCILIATION_LIST_FILTER", j, "AKTIFBANK_ISLEM_TUTARI", iMap.getBigDecimal("RC_RECONCILIATION_LIST", k, "AKTIFBANK_ISLEM_TUTARI"));
					iMap.put("RC_RECONCILIATION_LIST_FILTER", j, "YIM_ISLEM_NO", iMap.getBigDecimal("RC_RECONCILIATION_LIST", k, "YIM_ISLEM_NO"));
					iMap.put("RC_RECONCILIATION_LIST_FILTER", j, "YIM_ISLEM_TUTARI", iMap.getBigDecimal("RC_RECONCILIATION_LIST", k, "YIM_ISLEM_TUTARI"));
					iMap.put("RC_RECONCILIATION_LIST_FILTER", j, "ALICI_TCKN", iMap.getString("RC_RECONCILIATION_LIST", k, "ALICI_TCKN"));
					iMap.put("RC_RECONCILIATION_LIST_FILTER", j, "AKTIFBANK_DURUM_ACK", iMap.getString("RC_RECONCILIATION_LIST", k, "AKTIFBANK_DURUM_ACK"));
					iMap.put("RC_RECONCILIATION_LIST_FILTER", j, "YIM_DURUM_ACK", iMap.getString("RC_RECONCILIATION_LIST", k, "YIM_DURUM_ACK"));

					j++;
				}
			}
			int YIM_ISLEM_ADET = 0;
			int AKTIFBANK_ISLEM_ADET = 0;
			int m = 0;
			for (m = 0; m < iMap.getSize("RC_RECONCILIATION_LIST_FILTER"); m++) {
				if (iMap.getBigDecimal("RC_RECONCILIATION_LIST_FILTER", m, "AKTIFBANK_ISLEM_TUTARI") != null && (iMap.getBigDecimal("RC_RECONCILIATION_LIST_FILTER", m, "AKTIFBANK_ISLEM_NO")) != null) {
					AKTIFBANK_ISLEM_TUTAR = AKTIFBANK_ISLEM_TUTAR.add(iMap.getBigDecimal("RC_RECONCILIATION_LIST_FILTER", m, "AKTIFBANK_ISLEM_TUTARI"));
					AKTIFBANK_ISLEM_ADET = AKTIFBANK_ISLEM_ADET + 1;

				}
				if (iMap.getBigDecimal("RC_RECONCILIATION_LIST_FILTER", m, "YIM_ISLEM_TUTARI") != null && (iMap.getBigDecimal("RC_RECONCILIATION_LIST_FILTER", m, "YIM_ISLEM_NO")) != null) {
					YIM_ISLEM_TUTAR = YIM_ISLEM_TUTAR.add(iMap.getBigDecimal("RC_RECONCILIATION_LIST_FILTER", m, "YIM_ISLEM_TUTARI"));
					YIM_ISLEM_ADET = YIM_ISLEM_ADET + 1;

				}
			}

			iMap.put(grandTotalTableName, 0, "TOPLAM", "TOPLAM ��LEM TUTARI");
			iMap.put(grandTotalTableName, 0, "AKTIFBANK", AKTIFBANK_ISLEM_TUTAR);
			iMap.put(grandTotalTableName, 0, "YIM", YIM_ISLEM_TUTAR);
			iMap.put(grandTotalTableName, 1, "TOPLAM", "TOPLAM ��LEM ADED�");
			iMap.put(grandTotalTableName, 1, "AKTIFBANK", AKTIFBANK_ISLEM_ADET);
			iMap.put(grandTotalTableName, 1, "YIM", YIM_ISLEM_ADET);
		}

		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return iMap;
	}
}
