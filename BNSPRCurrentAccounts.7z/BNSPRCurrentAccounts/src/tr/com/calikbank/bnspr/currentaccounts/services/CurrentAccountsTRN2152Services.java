package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.KrlKasaMusteriTanimTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.CariVirmanTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2152Services {

		@GraymoundService("BNSPR_TRN2152_SAVE")
		public static GMMap save(GMMap iMap) {
			Connection conn = null;
			CallableStatement stmt1 = null;
			CallableStatement stmt2 = null;
			try {

				Session session = DAOSession.getSession("BNSPRDal");
				KrlKasaMusteriTanimTx krlKasaMusteriTanimTx = (KrlKasaMusteriTanimTx) session.get(KrlKasaMusteriTanimTx.class, iMap.getBigDecimal("TRX_NO"));
				if (krlKasaMusteriTanimTx==null){
					krlKasaMusteriTanimTx = new KrlKasaMusteriTanimTx();
					krlKasaMusteriTanimTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				}
				
				krlKasaMusteriTanimTx.setKasaNo(iMap.getBigDecimal("KASA_NO"));
	            krlKasaMusteriTanimTx.setSubeKod(iMap.getString("SUBE_KOD"));
				krlKasaMusteriTanimTx.setAnahtarAdet(iMap.getBigDecimal("ANAHTAR_ADET"));
				krlKasaMusteriTanimTx.setDepozitoBdl(iMap.getBigDecimal("DEPOZITO_BDL"));
				krlKasaMusteriTanimTx.setKiraBdl(iMap.getBigDecimal("KIRA_BDL"));
				krlKasaMusteriTanimTx.setDurum(iMap.getString("DURUM"));
				krlKasaMusteriTanimTx.setFMusterek(iMap.getString("F_MUSTEREK"));
				krlKasaMusteriTanimTx.setFTuzel(iMap.getString("F_TUZEL"));
				krlKasaMusteriTanimTx.setKullaniciAdet(iMap.getBigDecimal("KULLANICI_ADET"));
				krlKasaMusteriTanimTx.setMusteriNo1(iMap.getBigDecimal("MUSTERI_NO"));
				krlKasaMusteriTanimTx.setMusteriNo2(iMap.getBigDecimal("MUSTERI_NO2"));
				krlKasaMusteriTanimTx.setMusteriNo3(iMap.getBigDecimal("MUSTERI_NO3"));
				krlKasaMusteriTanimTx.setMusteriNo4(iMap.getBigDecimal("MUSTERI_NO4"));
				krlKasaMusteriTanimTx.setYetkiliMusteriNo1(iMap.getBigDecimal("YETKILI_NO1"));
				krlKasaMusteriTanimTx.setYetkiliMusteriNo2(iMap.getBigDecimal("YETKILI_NO2"));
				krlKasaMusteriTanimTx.setTahsDepozitoBdl(iMap.getBigDecimal("TAH_DEPOZITO_BDL"));
				krlKasaMusteriTanimTx.setTahsKiraBdl(iMap.getBigDecimal("TAH_KIRA_BDL"));
				krlKasaMusteriTanimTx.setTahsilHesapNo(iMap.getBigDecimal("HESAP_NO"));
				krlKasaMusteriTanimTx.setTeslimAnahtarAdet(iMap.getBigDecimal("TESLIM_ANAHTAR_ADET"));
				
				session.saveOrUpdate(krlKasaMusteriTanimTx);
				session.flush();

				iMap.put("TRX_NAME", "2152");

				GMMap oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt1);
				GMServerDatasource.close(stmt2);
				GMServerDatasource.close(conn);
			}
		}

		@GraymoundService("BNSPR_TRN2152_GET_INFO")
		public static GMMap getTRN2152GetInfo(GMMap iMap) {
			try{
				Session session = DAOSession.getSession("BNSPRDal");
		                                                                  
				GMMap oMap=new GMMap();
		        
				KrlKasaMusteriTanimTx krlKasaMusteriTanimTx = (KrlKasaMusteriTanimTx) session.load(KrlKasaMusteriTanimTx.class, iMap.getBigDecimal("TRX_NO"));

				oMap.put("KASA_NO" 	        , krlKasaMusteriTanimTx.getKasaNo());
		        oMap.put("KASA_TIPI"        , LovHelper.diLov(krlKasaMusteriTanimTx.getKasaNo(), krlKasaMusteriTanimTx.getSubeKod(),"E", "2152/LOV_KASA_NO", "KASA_TIP"));
		        oMap.put("SUBE_KOD"         , krlKasaMusteriTanimTx.getSubeKod());
		        oMap.put("SUBE_ADI"         , LovHelper.diLov(krlKasaMusteriTanimTx.getSubeKod(), "2152/LOV_SUBE", "ADI"));
		        oMap.put("MUSTERI_NO"       , krlKasaMusteriTanimTx.getMusteriNo1());
		        oMap.put("MUSTERI_NO2"  	, krlKasaMusteriTanimTx.getMusteriNo2());
		        oMap.put("MUSTERI_NO3"  	, krlKasaMusteriTanimTx.getMusteriNo3());
		        oMap.put("MUSTERI_NO4"  	, krlKasaMusteriTanimTx.getMusteriNo4());
		        oMap.put("YETKILI_NO1"  	, krlKasaMusteriTanimTx.getYetkiliMusteriNo1());
		        oMap.put("YETKILI_NO2"  	, krlKasaMusteriTanimTx.getYetkiliMusteriNo2());
		        oMap.put("ANAHTAR_ADET" 	, krlKasaMusteriTanimTx.getAnahtarAdet());
		        oMap.put("MUSTERI_ADET" 	, krlKasaMusteriTanimTx.getKullaniciAdet());
		        oMap.put("HESAP_NO"     	, krlKasaMusteriTanimTx.getTahsilHesapNo());
		        oMap.put("DEPOZITO_BDL"  	, krlKasaMusteriTanimTx.getDepozitoBdl());
		        oMap.put("TAH_DEPOZITO_BDL" , krlKasaMusteriTanimTx.getTahsDepozitoBdl());
		        oMap.put("KIRA_BDL"			, krlKasaMusteriTanimTx.getKiraBdl());
		        oMap.put("TAH_KIRA_BDL"		, krlKasaMusteriTanimTx.getTahsKiraBdl());

		        if ("E".equals(krlKasaMusteriTanimTx.getFTuzel()))
                    oMap.put("F_TUZEL", true);
                else
                	oMap.put("F_TUZEL", false);  

		        if ("E".equals(krlKasaMusteriTanimTx.getFMusterek()))
                    oMap.put("F_MUSTEREK", true);
                else
                	oMap.put("F_MUSTEREK", false);  

		        oMap.put("GECMIS_KIRA_BORCU"		, krlKasaMusteriTanimTx.getGecmisKiraBorcu());
		        oMap.put("F_GUNCELLE", krlKasaMusteriTanimTx.getFGuncelle());
		        oMap.put("F_YENILE", krlKasaMusteriTanimTx.getFYenile());
		        oMap.put("TESLIM_ANAHTAR_ADET", krlKasaMusteriTanimTx.getTeslimAnahtarAdet());
		        oMap.put("F_KAPAMA", krlKasaMusteriTanimTx.getFKapama());

		        
		        return oMap;
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}

		@GraymoundService("BNSPR_TRN2152_W1_GET_LIST")
		public static GMMap getList(GMMap iMap){
			Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			try{
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{ ? = call pkg_trn2152.GET_Kasa_List(?,?) }");
				
				int i = 1;
				stmt.registerOutParameter(i++, -10);
				stmt.setString(i++, iMap.getString("SUBE_KODU"));
				stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
				
				stmt.execute();
				stmt.getMoreResults();
				rSet = (ResultSet) stmt.getObject(1);
				GMMap oMap = new GMMap();
				oMap.putAll(DALUtil.rSetResults(rSet, "TBL_KASA"));
				
				return oMap;
			}catch (Exception e){
				throw ExceptionHandler.convertException(e);
			}finally{
				GMServerDatasource.close(rSet);
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}		
		
		@GraymoundService("BNSPR_TRN2152_GET_KASA_ISLEM")
		public static GMMap getKasaIslem(GMMap iMap){
			Connection conn = null;
			CallableStatement stmt = null;
			try{
				GMMap oMap = new GMMap();
				conn = DALUtil.getGMConnection();
				
				stmt = conn.prepareCall("{ ? = call pkg_trn2152.Get_Kasa_islem(?,?,?) }");
				
				stmt.registerOutParameter(1, Types.DECIMAL);
				stmt.setString(2, iMap.getString("SUBE_KODU"));
				stmt.setBigDecimal(3, iMap.getBigDecimal("KASA_NO"));
				stmt.setString(4, iMap.getString("P_ISLEM"));

				stmt.execute();
				
				BigDecimal txNo = stmt.getBigDecimal(1);

				oMap.put("TRX_NO", txNo);

				return oMap;
				
			}catch (Exception e){
				throw ExceptionHandler.convertException(e);
			}finally{
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}		
		
		
}