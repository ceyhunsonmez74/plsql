package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Types;
import java.util.Calendar;
import java.util.Collections;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;

import tr.com.aktifbank.bnspr.currentaccounts.accounting.CurrencyType;
import tr.com.aktifbank.bnspr.currentaccounts.clks.transaction.CommissionGroupType;
import tr.com.aktifbank.bnspr.currentaccounts.clks.transaction.PttTransactionType;
import tr.com.aktifbank.bnspr.currentaccounts.clks.transaction.TransactionType;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsQRY2062Services {
	
	private static Logger logger = Logger.getLogger(CurrentAccountsQRY2062Services.class);
	private static final Map<TransactionType, TransactionType> TRANSACTION_TYPE_MAP = initTransactionTypeMap();
	private static final Map<TransactionType, CommissionGroupType> TRANSACTION_COMMISSION_GROUP_MAP = initTransactionCommissionGroupMap();

	private static final Set<TransactionType> TRANSACTION_TYPE_UPT_GROUP = EnumSet.of(TransactionType.REFUND_PAYMENT,
		TransactionType.REFUND_PAYMENT_WITH_EXPENSE, TransactionType.REFERENCE_PAYMENT,
		TransactionType.ELECTRONIC_FUND_TRANSFER_PAYMENT, TransactionType.FOREIGN_CURRENCY_TRANSFER_PAYMENT,
		TransactionType.FOREIGN_CURRENCY_TRANSFER_LOCAL, TransactionType.FOREIGN_CURRENCY_TRANSFER_GLOBAL);
	
	private static final Set<TransactionType> TRANSACTION_TYPE_CONSUMERLOAN_GROUP = EnumSet.of(
		TransactionType.INSTALLMENT_LOAN, TransactionType.CONSUMERLOAN_APPLICATION,
		TransactionType.CONSUMERLOAN_PAYMENT, TransactionType.INSTALLMENT_LOAN_AUTOMATION,
		TransactionType.DEALER_CONSUMERLOAN_PAYMENT, TransactionType.DEALER_INSTALLMENT_LOAN);

	private static Map<TransactionType, TransactionType> initTransactionTypeMap() {
		Map<TransactionType, TransactionType> map = new HashMap<TransactionType, TransactionType>();
		map.put(TransactionType.ELECTRONIC_FUND_TRANSFER_FROM_IPCH, TransactionType.ELECTRONIC_FUND_TRANSFER_FROM_PCH);
		map.put(TransactionType.ELECTRONIC_FUND_TRANSFER_FROM_IPCH_REFUND,
			TransactionType.ELECTRONIC_FUND_TRANSFER_FROM_PCH_REFUND);
		map.put(TransactionType.REFUND_PAYMENT_WITH_EXPENSE, TransactionType.REFUND_PAYMENT);
		map.put(TransactionType.REFERENCE_PAYMENT, TransactionType.FOREIGN_CURRENCY_TRANSFER_PAYMENT);
		map.put(TransactionType.ELECTRONIC_FUND_TRANSFER_PAYMENT, TransactionType.FOREIGN_CURRENCY_TRANSFER_PAYMENT);
		map.put(TransactionType.FOREIGN_CURRENCY_TRANSFER_LOCAL, TransactionType.FOREIGN_CURRENCY_TRANSFER_GLOBAL);
		map.put(TransactionType.UPT_REFERENCE_TRANSFER_LOCAL, TransactionType.UPT_REFERENCE_TRANSFER_EFT);
		map.put(TransactionType.UPT_REFERENCE_TRANSFER_GLOBAL, TransactionType.UPT_REFERENCE_TRANSFER_EFT);
		map.put(TransactionType.ATM_CARD_PAYMENT_PASSO_WITH_ID, TransactionType.ATM_CARD_PAYMENT_PASSO);
		return Collections.unmodifiableMap(map);
	}
	
	private static Map<TransactionType, CommissionGroupType> initTransactionCommissionGroupMap() {
		Map<TransactionType, CommissionGroupType> map = new HashMap<TransactionType, CommissionGroupType>();
		map.put(TransactionType.CASH_DEPOSIT, CommissionGroupType.CASH_DEPOSIT_GROUP);
		map.put(TransactionType.CASH_WITHDRAWAL, CommissionGroupType.CASH_WITHDRAWAL_GROUP);
		map.put(TransactionType.ATM_CASH_DEPOSIT_TO_ACCOUNT, CommissionGroupType.ATM_CASH_DEPOSIT_TO_ACCOUNT_GROUP);
		map.put(TransactionType.ATM_CASH_DEPOSIT_TO_IBAN, CommissionGroupType.ATM_CASH_DEPOSIT_TO_IBAN_GROUP);
		map.put(TransactionType.ATM_CARD_PAYMENT_NKOLAY, CommissionGroupType.ATM_CARD_NKOLAY_GROUP);
		map.put(TransactionType.ATM_CARD_PAYMENT_PASSO, CommissionGroupType.ATM_CARD_PASSO_GROUP);
		map.put(TransactionType.ATM_CARD_PAYMENT_PASSO_WITH_ID, CommissionGroupType.ATM_CARD_PASSO_GROUP);
		map.put(TransactionType.CARD_PAYMENT_NKOLAY, CommissionGroupType.CARD_NKOLAY_GROUP);
		map.put(TransactionType.CARD_PAYMENT_PASSO, CommissionGroupType.CARD_PASSO_GROUP);
		map.put(TransactionType.CONSUMERLOAN_APPLICATION, CommissionGroupType.CONSUMERLOAN_APPLICATION_GROUP);
		map.put(TransactionType.CONSUMERLOAN_PAYMENT, CommissionGroupType.CONSUMERLOAN_PAYMENT_GROUP);
		map.put(TransactionType.ELECTRONIC_FUND_TRANSFER, CommissionGroupType.UPT_EFT_GROUP);
		map.put(TransactionType.ELECTRONIC_FUND_TRANSFER_FROM_IPCH, CommissionGroupType.UPT_EFT_PCH_GROUP);
		map.put(TransactionType.ELECTRONIC_FUND_TRANSFER_FROM_PCH, CommissionGroupType.UPT_EFT_PCH_GROUP);
		map.put(TransactionType.ELECTRONIC_FUND_TRANSFER_FROM_IPCH_REFUND, CommissionGroupType.UPT_EFT_PCH_REFUND_GROUP);
		map.put(TransactionType.ELECTRONIC_FUND_TRANSFER_FROM_PCH_REFUND, CommissionGroupType.UPT_EFT_PCH_REFUND_GROUP);
		map.put(TransactionType.ELECTRONIC_FUND_TRANSFER_PAYMENT, CommissionGroupType.UPT_PAYMENT_GROUP);
		map.put(TransactionType.FOREIGN_CURRENCY_TRANSFER_PAYMENT, CommissionGroupType.UPT_PAYMENT_GROUP);
		map.put(TransactionType.REFERENCE_PAYMENT, CommissionGroupType.UPT_PAYMENT_GROUP);
		map.put(TransactionType.FOREIGN_CURRENCY_TRANSFER_GLOBAL, CommissionGroupType.UPT_FC_TRANSFER_GLOBAL_GROUP);
		map.put(TransactionType.FOREIGN_CURRENCY_TRANSFER_LOCAL, CommissionGroupType.UPT_FC_TRANSFER_LOCAL_GROUP);
		map.put(TransactionType.INSTALLMENT_LOAN, CommissionGroupType.INSTALLMENT_LOAN_GROUP);
		map.put(TransactionType.INSTALLMENT_LOAN_AUTOMATION, CommissionGroupType.INSTALLMENT_LOAN_AUTOMATION_GROUP);
		map.put(TransactionType.REFUND_PAYMENT, CommissionGroupType.UPT_REFUND_PAYMENT_GROUP);
		map.put(TransactionType.REFUND_PAYMENT_WITH_EXPENSE, CommissionGroupType.UPT_REFUND_PAYMENT_WITH_EXPENSE_GROUP);
		map.put(TransactionType.UPT_REFERENCE_TRANSFER_EFT, CommissionGroupType.UPT_EFT_GROUP);
		map.put(TransactionType.UPT_REFERENCE_TRANSFER_LOCAL, CommissionGroupType.UPT_FC_TRANSFER_LOCAL_GROUP);
		map.put(TransactionType.UPT_REFERENCE_TRANSFER_GLOBAL, CommissionGroupType.UPT_FC_TRANSFER_GLOBAL_GROUP);
		map.put(TransactionType.CUSTOMER_ACQUISITION, CommissionGroupType.CUSTOMER_ACQUISITION_GROUP);
		return Collections.unmodifiableMap(map);
	}
	
	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_QRY2062_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {

		GMMap oMap = new GMMap();

		try {

			// Yetki: Fis Kesme
			oMap.put("TRN2055_YETKI", DALUtil.callNoParameterFunction("{? = call pkg_trn2055.islem_yetki_kontrol}",
				Types.VARCHAR));

			oMap.put("END_DATE", DALUtil.callOracleFunction(
				"{? = call pkg_tarih.ayin_son_gunu(add_months(trunc(sysdate), -1))}", BnsprType.DATE, new Object[]{}));
			Calendar cal = Calendar.getInstance();
			cal.setTime(oMap.getDate("END_DATE"));
			cal.set(Calendar.DAY_OF_MONTH, 1);
			oMap.put("START_DATE", cal.getTime());

		} catch(Exception e) {

			logger.error("BNSPR_QRY2062_INITIALIZE err: " + e);
			throw ExceptionHandler.convertException(e);
		}

		return oMap;
	}
	
	
	/**
	 * TODO: Generic bir listeleme servisi ile degisitirilmeli.
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_QRY2062_RC_PTT_ISLEM_LIST")
	public static GMMap getIslemler(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		String listName = "RECORDS";
		BigDecimal totalCommissionAmount = BigDecimal.ZERO;
		BigDecimal totalUptCommissionAmount = BigDecimal.ZERO;
		String azerpostKurumKodu = GMServiceExecuter.call("BNSPR_COMMON_GET_PARAM_TEXT",
				new GMMap().put("KOD", "CLKS_UPT_AZERPOST_BILGILERI").put("KEY", "KURUM_KODU"))
				.getString("TEXT");
		
		BigDecimal usdRate = iMap.getBigDecimal("USD_RATE") != null ? iMap.getBigDecimal("USD_RATE") : null;
		BigDecimal eurRate = iMap.getBigDecimal("EUR_RATE") != null ? iMap.getBigDecimal("EUR_RATE") : null;
		BigDecimal commissionTL = null;
		BigDecimal commissionAmount = null;
		String txCurrencyCode = null;
		Integer counterKonsolide = 0;
		
		try {

			GMMap konMap = new GMMap();
			GMMap dalMap = (GMMap) DALUtil.callOracleProcedure("{call pkg_rc2062.get_commission_records(?,?,?,?)}", 
				new Object[] {
					BnsprType.DATE, iMap.get("START_DATE") != null ? iMap.getDate("START_DATE") : null,
					BnsprType.DATE, iMap.getDate("END_DATE") != null ? iMap.getDate("END_DATE") : null,
					BnsprType.STRING, iMap.getString("ROLE")
				}, new Object[] {
					BnsprType.REFCURSOR, listName
			});
			
			
			TransactionType transactionType;
			CurrencyType currency;
			CommissionGroupType commType;
			
			for(TransactionType transactionTypeValue : TransactionType.values()) {
				for(CurrencyType currencyTypeValue : CurrencyType.values()) {
					
					String tableKey = String.format("%s_%s", transactionTypeValue.toString(), currencyTypeValue.toString());
					String counterKey = String.format("COUNTER_%s", tableKey);
					String commissionAmountKey = String.format("COMMISSION_AMOUNT_%s", tableKey);
					
					oMap.put(counterKey, 0);
					oMap.put(commissionAmountKey, BigDecimal.ZERO);
				}
			}
			
			for(int i = 0; i < dalMap.getSize(listName); i++) {

				transactionType = TransactionType.getEnum(dalMap.getString(listName, i, "ISLEMTURU"));
				commType = TRANSACTION_COMMISSION_GROUP_MAP.get(transactionType);
				
				transactionType = TRANSACTION_TYPE_MAP.get(transactionType) == null ? transactionType
					: TRANSACTION_TYPE_MAP.get(transactionType);
				
				if(TRANSACTION_TYPE_UPT_GROUP.contains(transactionType)) {
					currency = CurrencyType.getEnum(dalMap.getString(listName, i, "TAHSILAT_PARA_BIRIMI"));
				} else {
					currency = CurrencyType.getEnum(dalMap.getString(listName, i, "ISLEMDOVIZKODU"));
				}
				
				String description = commType.getCurrencySet() != null
						&& commType.getCurrencySet().size() > 1 && currency != null ? String.format("%s (%s)",
								commType.toString(), currency.toString()) : commType.toString();

				String tableKey = String.format("%s_%s", transactionType.toString(), currency.toString());
				String counterKey = String.format("COUNTER_%s", tableKey);
				String commissionAmountKey = String.format("COMMISSION_AMOUNT_%s", tableKey);
				
				oMap.put(tableKey, oMap.getInt(counterKey), "ISLEMTARIHI", dalMap.getString(listName, i, "ISLEMTARIHI"));
				oMap.put(tableKey, oMap.getInt(counterKey), "ISLEMTUTARI", dalMap.getBigDecimal(listName, i, "ISLEMTUTARI"));
				oMap.put(tableKey, oMap.getInt(counterKey), "ISLEMDOVIZKODU", dalMap.getString(listName, i, "ISLEMDOVIZKODU"));
				oMap.put(tableKey, oMap.getInt(counterKey), "ISLEM_NO", dalMap.getBigDecimal(listName, i, "ISLEM_NO"));
				oMap.put(tableKey, oMap.getInt(counterKey), "ISLEMNOPTT", dalMap.getString(listName, i, "ISLEMNOPTT"));
				oMap.put(tableKey, oMap.getInt(counterKey), "KOMISYONTUTARI", dalMap.getBigDecimal(listName, i, "KOMISYONTUTARI"));
				oMap.put(tableKey, oMap.getInt(counterKey), "KOMISYONDOVIZKODU", dalMap.getString(listName, i, "KOMISYONDOVIZKODU"));
				oMap.put(tableKey, oMap.getInt(counterKey), "KOMISYONTUTARLC", dalMap.getBigDecimal(listName, i, "KOMISYONTUTARLC"));
				
				//Konsolide
				//oMap.put("KONSOLIDE", i, "ISLEMTARIHI", dalMap.getString(listName, i, "ISLEMTARIHI"));
				
				
				if(TRANSACTION_TYPE_CONSUMERLOAN_GROUP.contains(transactionType)) {
	
					oMap.put(tableKey, oMap.getInt(counterKey), "BASVURU_NO", dalMap.getString(listName, i, "BASVURU_NO"));	
					oMap.put(tableKey, oMap.getInt(counterKey), "KAMP_URUN_ADI", dalMap.getString(listName, i, "KAMP_URUN_ADI"));	
					oMap.put(tableKey, oMap.getInt(counterKey), "TCKN",dalMap.getString(listName, i, "TCKN"));
					oMap.put(tableKey, oMap.getInt(counterKey), "BASVURU_DURUM",dalMap.getString(listName, i, "BASVURU_DURUM"));
					oMap.put(tableKey, oMap.getInt(counterKey), "KAYNAK_KANAL",dalMap.getString(listName, i, "KAYNAK_KANAL"));
                    oMap.put(tableKey, oMap.getInt(counterKey), "TAKSIT_NO",dalMap.getString(listName, i, "TAKSIT_NO")); // TransactionType.INSTALLMENT_LOAN_AUTOMATION, TransactionType.DEALER_INSTALLMENT_LOAN
                    
    				
				} else if(TRANSACTION_TYPE_UPT_GROUP.contains(transactionType)) {
					
					oMap.put(tableKey, oMap.getInt(counterKey), "ISLEMTURU", dalMap.getString(listName, i, "ISLEMTURU"));
					oMap.put(tableKey, oMap.getInt(counterKey), "ISLEM_TIP", dalMap.getString(listName, i, "ISLEM_TIP"));
					oMap.put(tableKey, oMap.getInt(counterKey), "REFERANS", dalMap.getString(listName, i, "REFERANS"));
					oMap.put(tableKey, oMap.getInt(counterKey), "TAHSILAT_TUTAR", dalMap.getString(listName, i, "TAHSILAT_TUTAR"));
					oMap.put(tableKey, oMap.getInt(counterKey), "TAHSILAT_PARA_BIRIMI", dalMap.getString(listName, i, "TAHSILAT_PARA_BIRIMI"));
					oMap.put(tableKey, oMap.getInt(counterKey), "MASRAF_TUTARI", dalMap.getBigDecimal(listName, i, "MASRAF_TUTARI"));
					oMap.put(tableKey, oMap.getInt(counterKey), "MASRAF_DOVIZ_KODU", dalMap.getString(listName, i, "MASRAF_DOVIZ_KODU"));
					totalUptCommissionAmount = totalUptCommissionAmount.add(dalMap.getBigDecimal(listName, i, "KOMISYONTUTARLC"));					
					
					//KomisyonTL
                    txCurrencyCode = dalMap.getString(listName, i, "KOMISYONDOVIZKODU");
                    
                    // Azerpost Kurum Kontrolu
                    Boolean azerpostMu = false;
                    if(dalMap.getString(listName, i, "KURUM_KODU") != "" && dalMap.getString(listName, i, "ISLEMTARIHI") != null){                    	
                    	azerpostMu = IsAzerpostKurum(dalMap.getString(listName, i, "KURUM_KODU"), azerpostKurumKodu);
                    }
                    
    				commissionAmount = dalMap.getBigDecimal(listName, i, "KOMISYONTUTARI"); 
    				BigDecimal commissionAmountN = new BigDecimal(0);
    				String ISLEM_TIP_NAME = GetTransactionName(dalMap.getString(listName, i, "ISLEM_TIP"));
    				
    				BigDecimal masraftTutar = (dalMap.getBigDecimal(listName, i, "MASRAF_TUTARI") != null ) ? dalMap.getBigDecimal(listName, i, "MASRAF_TUTARI") : BigDecimal.ZERO;
    				BigDecimal pttKuru = (dalMap.getBigDecimal(listName, i, "PTTDOVIZKUR") != null ) ? dalMap.getBigDecimal(listName, i, "PTTDOVIZKUR") : BigDecimal.ZERO;
    				BigDecimal bankaKuru = (dalMap.getBigDecimal(listName, i, "PTTKUR") != null ) ? dalMap.getBigDecimal(listName, i, "PTTKUR") : BigDecimal.ZERO;
    				String masrafDoviz = (dalMap.getString(listName, i, "MASRAF_DOVIZ_KODU") != null ) ? dalMap.getString(listName, i, "MASRAF_DOVIZ_KODU") : "";
    				BigDecimal masraf_upt = (dalMap.getBigDecimal(listName, i, "MASRAF_UPT") != null ) ? dalMap.getBigDecimal(listName, i, "MASRAF_UPT") : BigDecimal.ZERO;
    				
    				
    				if(ISLEM_TIP_NAME.equals("G�NDER�M") && !masrafDoviz.contains("TRY")){
    					if(azerpostMu){
    						commissionAmountN = masraftTutar.multiply(new BigDecimal("0.45"));
    					}else{    						
    						commissionAmountN = masraftTutar.multiply(new BigDecimal("0.35"));
    					}
    					
    					if(dalMap.getString(listName, i, "ISLEMDOVIZKODU").equals(dalMap.getString(listName, i, "ODEMESEKLI"))){
    						commissionAmountN = commissionAmountN.multiply(pttKuru);
	    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARI", commissionAmountN);
	    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
    					}else{
    						commissionAmountN = commissionAmountN.multiply(bankaKuru);
	    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARI", commissionAmountN);
	    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
    					}
    				}else{
    					if(azerpostMu){
    						commissionAmountN = masraf_upt.multiply(new BigDecimal("0.45"));
    						if (txCurrencyCode.contains("USD") || txCurrencyCode.contains("EUR")) {
			    				if (txCurrencyCode.contains("USD") && usdRate != null && usdRate.compareTo(BigDecimal.ZERO) > 0 ){
			    					commissionAmountN = commissionAmountN.multiply(usdRate ); //
			    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
			    				}else if (txCurrencyCode.contains("EUR") && eurRate != null &&  eurRate.compareTo(BigDecimal.ZERO) > 0 ){
			    					commissionAmountN = commissionAmountN.multiply(eurRate);
			    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
			    				}
		    				}
		    				else{
		    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
		    				}
    					}else{
	    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmount);
		    				if (txCurrencyCode.contains("USD") || txCurrencyCode.contains("EUR")) {
			    				if (txCurrencyCode.contains("USD") && usdRate != null && usdRate.compareTo(BigDecimal.ZERO) > 0 ){
			    					commissionAmountN = commissionAmount.multiply(usdRate ); //
			    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmount);
			    				}else if (txCurrencyCode.contains("EUR") && eurRate != null &&  eurRate.compareTo(BigDecimal.ZERO) > 0 ){
			    					commissionAmountN = commissionAmount.multiply(eurRate);
			    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmount);
			    				}else{
			    					commissionAmountN = commissionAmount;
			    				}
		    				}
		    				else{
		    					commissionAmountN = commissionAmount;
		    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", dalMap.getBigDecimal(listName, i, "KOMISYONTUTARLC"));
		    				}
    					}
    				}
					
    				commissionAmountN = commissionAmountN.setScale(2, RoundingMode.HALF_UP);
					//BigDecimal commisionAmount = dalMap.getBigDecimal(listName, i, "KOMISYONTUTARI");
					BigDecimal commisionWithoutBSMV = commissionAmountN.divide(new BigDecimal("1.05"), 2, RoundingMode.HALF_EVEN);
					
					String masrafDovizKodu = dalMap.getString(listName, i, "MASRAF_DOVIZ_KODU");
					BigDecimal masrafTL = new BigDecimal(0);
					BigDecimal masrafTutar = dalMap.getBigDecimal(listName, i, "MASRAF_TUTARI");
					
					if(!masrafDovizKodu.contains("TRY") && masrafTutar.compareTo(BigDecimal.ZERO) > 0 && dalMap.getBigDecimal(listName, i, "PTTKUR").compareTo(BigDecimal.ZERO) > 0){
						masrafTL = masrafTutar.multiply(dalMap.getBigDecimal(listName, i, "PTTKUR"));
					}else{
						masrafTL = masrafTutar;
					}
					
					//Konsolidasyon
					
    				oMap.put("KONSOLIDE", counterKonsolide, "ISLEM_TIP_NAME", ISLEM_TIP_NAME);
    				
					//oMap.put("KONSOLIDE", i, oMap.getMap(tableKey));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMTARIHI", dalMap.getString(listName, i, "ISLEMTARIHI"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMTUTARI", dalMap.getBigDecimal(listName, i, "ISLEMTUTARI"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMDOVIZKODU", dalMap.getString(listName, i, "ISLEMDOVIZKODU"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEM_NO", dalMap.getBigDecimal(listName, i, "ISLEM_NO"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMNOPTT", dalMap.getString(listName, i, "ISLEMNOPTT"));
					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONDOVIZKODU", dalMap.getString(listName, i, "KOMISYONDOVIZKODU"));
					
					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARI", commissionAmountN);   
    				oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTL", commissionAmountN);
					
					//oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", dalMap.getBigDecimal(listName, i, "KOMISYONTUTARLC"));
					oMap.put("KONSOLIDE", counterKonsolide, "BSMVSIZKOMISYON", commisionWithoutBSMV);
					oMap.put("KONSOLIDE", counterKonsolide, "BSMV", commissionAmountN.subtract(commisionWithoutBSMV));
					
					oMap.put("KONSOLIDE", counterKonsolide, "PTTKOD", getPttCode(commType, currency));
					oMap.put("KONSOLIDE", counterKonsolide, "PTTACIKLAMA", description);
					
					oMap.put("KONSOLIDE", counterKonsolide, "PTTKUR", dalMap.getBigDecimal(listName, i, "PTTKUR"));
					oMap.put("KONSOLIDE", counterKonsolide, "PTTDOVIZKUR", dalMap.getBigDecimal(listName, i, "PTTDOVIZKUR"));
					oMap.put("KONSOLIDE", counterKonsolide, "MASRAFTL", masrafTL);
					oMap.put("KONSOLIDE", counterKonsolide, "ODEME_SEKLI", dalMap.getString(listName, i, "ODEMESEKLI"));
					    
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMTURU", dalMap.getString(listName, i, "ISLEMTURU"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEM_TIP", dalMap.getString(listName, i, "ISLEM_TIP"));
					oMap.put("KONSOLIDE", counterKonsolide, "REFERANS", dalMap.getString(listName, i, "REFERANS"));
					oMap.put("KONSOLIDE", counterKonsolide, "TAHSILAT_TUTAR", dalMap.getString(listName, i, "TAHSILAT_TUTAR"));
					oMap.put("KONSOLIDE", counterKonsolide, "TAHSILAT_PARA_BIRIMI", dalMap.getString(listName, i, "TAHSILAT_PARA_BIRIMI"));
					oMap.put("KONSOLIDE", counterKonsolide, "MASRAF_TUTARI", dalMap.getBigDecimal(listName, i, "MASRAF_TUTARI"));
					oMap.put("KONSOLIDE", counterKonsolide, "MASRAF_DOVIZ_KODU", dalMap.getString(listName, i, "MASRAF_DOVIZ_KODU"));
    				
    				//oMap.put(tableKey, oMap.getInt(counterKey), "KOMISYONTL", commissionTL);
    				//oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTL", commissionTL);
    				counterKonsolide++;
                    //
				}
				
				else if(transactionType == TransactionType.CUSTOMER_ACQUISITION) {

					oMap.put(tableKey, oMap.getInt(counterKey), "ISLEM_TIP", dalMap.getString(listName, i, "ISLEM_TIP"));
					oMap.put(tableKey, oMap.getInt(counterKey), "MUSTERI_NO", dalMap.getString(listName, i, "MUSTERI_NO"));
					oMap.put(tableKey, oMap.getInt(counterKey), "TCKN", dalMap.getString(listName, i, "TCKN"));
					oMap.put(tableKey, oMap.getInt(counterKey), "MERKEZ_SUBE", dalMap.getString(listName, i, "MERKEZ_SUBE"));
	
				}
				
				else if(EnumSet.of(TransactionType.ELECTRONIC_FUND_TRANSFER,
					TransactionType.ELECTRONIC_FUND_TRANSFER_FROM_PCH,
					TransactionType.ELECTRONIC_FUND_TRANSFER_FROM_PCH_REFUND).contains(transactionType)) {

					oMap.put(tableKey, oMap.getInt(counterKey), "ISLEM_TIP", dalMap.getString(listName, i, "ISLEM_TIP"));
					oMap.put(tableKey, oMap.getInt(counterKey), "KAYNAK_KANAL",dalMap.getString(listName, i, "KAYNAK_KANAL"));
					oMap.put(tableKey, oMap.getInt(counterKey), "MASRAF_TUTARI", dalMap.getBigDecimal(listName, i, "MASRAF_TUTARI"));
					oMap.put(tableKey, oMap.getInt(counterKey), "MASRAF_DOVIZ_KODU", dalMap.getString(listName, i, "MASRAF_DOVIZ_KODU"));
					totalUptCommissionAmount = totalUptCommissionAmount.add(dalMap.getBigDecimal(listName, i, "KOMISYONTUTARLC"));
					
					
					//KomisyonTL
                    txCurrencyCode = dalMap.getString(listName, i, "KOMISYONDOVIZKODU");
                    
                    // Azerpost Kurum Kontrolu
                    Boolean azerpostMu = false;
                    if(dalMap.getString(listName, i, "KURUM_KODU") != "" && dalMap.getString(listName, i, "ISLEMTARIHI") != null){                    	
                    	azerpostMu = IsAzerpostKurum(dalMap.getString(listName, i, "KURUM_KODU"), azerpostKurumKodu);
                    }
                    
    				commissionAmount = dalMap.getBigDecimal(listName, i, "KOMISYONTUTARI"); 
    				BigDecimal commissionAmountN = new BigDecimal(0);
    				String ISLEM_TIP_NAME = GetTransactionName(dalMap.getString(listName, i, "ISLEM_TIP"));
    				
    				BigDecimal masraftTutar = (dalMap.getBigDecimal(listName, i, "MASRAF_TUTARI") != null ) ? dalMap.getBigDecimal(listName, i, "MASRAF_TUTARI") : BigDecimal.ZERO;
    				BigDecimal pttKuru = (dalMap.getBigDecimal(listName, i, "PTTDOVIZKUR") != null ) ? dalMap.getBigDecimal(listName, i, "PTTDOVIZKUR") : BigDecimal.ZERO;
    				BigDecimal bankaKuru = (dalMap.getBigDecimal(listName, i, "PTTKUR") != null ) ? dalMap.getBigDecimal(listName, i, "PTTKUR") : BigDecimal.ZERO;
    				String masrafDoviz = (dalMap.getString(listName, i, "MASRAF_DOVIZ_KODU") != null ) ? dalMap.getString(listName, i, "MASRAF_DOVIZ_KODU") : "";
    				BigDecimal masraf_upt = (dalMap.getBigDecimal(listName, i, "MASRAF_UPT") != null ) ? dalMap.getBigDecimal(listName, i, "MASRAF_UPT") : BigDecimal.ZERO;
    				
    				
    				if(ISLEM_TIP_NAME.equals("G�NDER�M") && !masrafDoviz.contains("TRY")){
    					if(azerpostMu){
    						commissionAmountN = masraftTutar.multiply(new BigDecimal("0.45"));
    					}else{    						
    						commissionAmountN = masraftTutar.multiply(new BigDecimal("0.35"));
    					}
    					
    					if(dalMap.getString(listName, i, "ISLEMDOVIZKODU").equals(dalMap.getString(listName, i, "ODEMESEKLI"))){
    						commissionAmountN = commissionAmountN.multiply(pttKuru);
	    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARI", commissionAmountN);
	    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
    					}else{
    						commissionAmountN = commissionAmountN.multiply(bankaKuru);
	    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARI", commissionAmountN);
	    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
    					}
    				}else{
    					if(azerpostMu){
    						commissionAmountN = masraf_upt.multiply(new BigDecimal("0.45"));
    						if (txCurrencyCode.contains("USD") || txCurrencyCode.contains("EUR")) {
			    				if (txCurrencyCode.contains("USD") && usdRate != null && usdRate.compareTo(BigDecimal.ZERO) > 0 ){
			    					commissionAmountN = commissionAmountN.multiply(usdRate ); //
			    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
			    				}else if (txCurrencyCode.contains("EUR") && eurRate != null &&  eurRate.compareTo(BigDecimal.ZERO) > 0 ){
			    					commissionAmountN = commissionAmountN.multiply(eurRate);
			    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
			    				}
		    				}
		    				else{
		    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
		    				}
    					}else{
		    				oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmount);
		    				if (txCurrencyCode.contains("USD") || txCurrencyCode.contains("EUR")) {
			    				if (txCurrencyCode.contains("USD") && usdRate != null && usdRate.compareTo(BigDecimal.ZERO) > 0 ){
			    					commissionAmountN = commissionAmount.multiply(usdRate ); //
			    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmount);
			    				}else if (txCurrencyCode.contains("EUR") && eurRate != null &&  eurRate.compareTo(BigDecimal.ZERO) > 0 ){
			    					commissionAmountN = commissionAmount.multiply(eurRate);
			    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmount);
			    				}
			    				else{
			    					commissionAmountN = commissionAmount;
			    				}
		    				}
		    				else{
		    					commissionAmountN = commissionAmount;
		    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", dalMap.getBigDecimal(listName, i, "KOMISYONTUTARLC"));
		    				}
    					}
    				}
					
    				commissionAmountN = commissionAmountN.setScale(2, RoundingMode.HALF_UP);
					//BigDecimal commisionAmount = dalMap.getBigDecimal(listName, i, "KOMISYONTUTARI");
					BigDecimal commisionWithoutBSMV = commissionAmountN.divide(new BigDecimal("1.05"), 2, RoundingMode.HALF_EVEN);
					
					//Konsolidasyon
					
    				oMap.put("KONSOLIDE", counterKonsolide, "ISLEM_TIP_NAME", ISLEM_TIP_NAME);
					
					//oMap.put("KONSOLIDE", i, oMap.getMap(tableKey));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMTARIHI", dalMap.getString(listName, i, "ISLEMTARIHI"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMTUTARI", dalMap.getBigDecimal(listName, i, "ISLEMTUTARI"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMDOVIZKODU", dalMap.getString(listName, i, "ISLEMDOVIZKODU"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEM_NO", dalMap.getBigDecimal(listName, i, "ISLEM_NO"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMNOPTT", dalMap.getString(listName, i, "ISLEMNOPTT"));
					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONDOVIZKODU", dalMap.getString(listName, i, "KOMISYONDOVIZKODU"));
					
					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARI", commissionAmountN);   
    				oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTL", commissionAmountN);
					
					//oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", dalMap.getBigDecimal(listName, i, "KOMISYONTUTARLC"));
					oMap.put("KONSOLIDE", counterKonsolide, "BSMVSIZKOMISYON", commisionWithoutBSMV);
					oMap.put("KONSOLIDE", counterKonsolide, "BSMV", commissionAmountN.subtract(commisionWithoutBSMV));
					
					oMap.put("KONSOLIDE", counterKonsolide, "PTTKOD", getPttCode(commType, currency));
					oMap.put("KONSOLIDE", counterKonsolide, "PTTACIKLAMA", description);
					
					oMap.put("KONSOLIDE", counterKonsolide, "PTTKUR", dalMap.getBigDecimal(listName, i, "PTTKUR"));
					oMap.put("KONSOLIDE", counterKonsolide, "PTTDOVIZKUR", dalMap.getBigDecimal(listName, i, "PTTDOVIZKUR"));
					oMap.put("KONSOLIDE", counterKonsolide, "MASRAFTL", dalMap.getBigDecimal(listName, i, "MASRAFTL"));
					oMap.put("KONSOLIDE", counterKonsolide, "ODEME_SEKLI", dalMap.getString(listName, i, "ODEMESEKLI"));					
					
					//KonsOlidasyon       
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMTURU", dalMap.getString(listName, i, "ISLEMTURU"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEM_TIP", dalMap.getString(listName, i, "ISLEM_TIP"));
					oMap.put("KONSOLIDE", counterKonsolide, "REFERANS", dalMap.getString(listName, i, "REFERANS"));
					oMap.put("KONSOLIDE", counterKonsolide, "TAHSILAT_TUTAR", dalMap.getString(listName, i, "TAHSILAT_TUTAR"));
					oMap.put("KONSOLIDE", counterKonsolide, "TAHSILAT_PARA_BIRIMI", dalMap.getString(listName, i, "TAHSILAT_PARA_BIRIMI"));
					oMap.put("KONSOLIDE", counterKonsolide, "MASRAF_TUTARI", dalMap.getBigDecimal(listName, i, "MASRAF_TUTARI"));
					oMap.put("KONSOLIDE", counterKonsolide, "MASRAF_DOVIZ_KODU", dalMap.getString(listName, i, "MASRAF_DOVIZ_KODU"));

    				counterKonsolide++;
				}
				
				else if(transactionType == TransactionType.UPT_REFERENCE_TRANSFER_EFT) {
					
					oMap.put(tableKey, oMap.getInt(counterKey), "YURTICI_DISI",dalMap.getString(listName, i, "KAMP_URUN_ADI"));
					oMap.put(tableKey, oMap.getInt(counterKey), "REFERANS",dalMap.getString(listName, i, "REFERANS"));
					oMap.put(tableKey, oMap.getInt(counterKey), "TALIMAT_TIPI",dalMap.getString(listName, i, "ISLEM_TIP"));
					oMap.put(tableKey, oMap.getInt(counterKey), "MASRAF_TUTARI", dalMap.getBigDecimal(listName, i, "MASRAF_TUTARI"));
					oMap.put(tableKey, oMap.getInt(counterKey), "MASRAF_DOVIZ_KODU", dalMap.getString(listName, i, "MASRAF_DOVIZ_KODU"));
					totalUptCommissionAmount = totalUptCommissionAmount.add(dalMap.getBigDecimal(listName, i, "KOMISYONTUTARLC"));
						
					//KomisyonTL
                    txCurrencyCode = dalMap.getString(listName, i, "KOMISYONDOVIZKODU");
                    
                    // Azerpost Kurum Kontrolu
                    Boolean azerpostMu = false;
                    if(dalMap.getString(listName, i, "KURUM_KODU") != "" && dalMap.getString(listName, i, "ISLEMTARIHI") != null){                    	
                    	azerpostMu = IsAzerpostKurum(dalMap.getString(listName, i, "KURUM_KODU"), azerpostKurumKodu);
                    }
                    
    				commissionAmount = dalMap.getBigDecimal(listName, i, "KOMISYONTUTARI"); 
    				BigDecimal commissionAmountN = new BigDecimal(0);
    				String ISLEM_TIP_NAME = GetTransactionName(dalMap.getString(listName, i, "ISLEM_TIP"));

    				
    				BigDecimal masraftTutar = (dalMap.getBigDecimal(listName, i, "MASRAF_TUTARI") != null ) ? dalMap.getBigDecimal(listName, i, "MASRAF_TUTARI") : BigDecimal.ZERO;
    				BigDecimal pttKuru = (dalMap.getBigDecimal(listName, i, "PTTDOVIZKUR") != null ) ? dalMap.getBigDecimal(listName, i, "PTTDOVIZKUR") : BigDecimal.ZERO;
    				BigDecimal bankaKuru = (dalMap.getBigDecimal(listName, i, "PTTKUR") != null ) ? dalMap.getBigDecimal(listName, i, "PTTKUR") : BigDecimal.ZERO;
    				String masrafDoviz = (dalMap.getString(listName, i, "MASRAF_DOVIZ_KODU") != null ) ? dalMap.getString(listName, i, "MASRAF_DOVIZ_KODU") : "";
    				BigDecimal masraf_upt = (dalMap.getBigDecimal(listName, i, "MASRAF_UPT") != null ) ? dalMap.getBigDecimal(listName, i, "MASRAF_UPT") : BigDecimal.ZERO;
    				
    				
    				if(ISLEM_TIP_NAME.equals("G�NDER�M") && !masrafDoviz.contains("TRY")){
    					if(azerpostMu){
    						commissionAmountN = masraftTutar.multiply(new BigDecimal("0.45"));
    					}else{    						
    						commissionAmountN = masraftTutar.multiply(new BigDecimal("0.35"));
    					}
    					
    					if(dalMap.getString(listName, i, "ISLEMDOVIZKODU").equals(dalMap.getString(listName, i, "ODEMESEKLI"))){
    						commissionAmountN = commissionAmountN.multiply(pttKuru);
	    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARI", commissionAmountN);
	    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
    					}else{
    						commissionAmountN = commissionAmountN.multiply(bankaKuru);
	    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARI", commissionAmountN);
	    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
    					}
    				}else{
    					if(azerpostMu){
    						commissionAmountN = masraf_upt.multiply(new BigDecimal("0.45"));
    						if (txCurrencyCode.contains("USD") || txCurrencyCode.contains("EUR")) {
			    				if (txCurrencyCode.contains("USD") && usdRate != null && usdRate.compareTo(BigDecimal.ZERO) > 0 ){
			    					commissionAmountN = commissionAmountN.multiply(usdRate ); //
			    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
			    				}else if (txCurrencyCode.contains("EUR") && eurRate != null &&  eurRate.compareTo(BigDecimal.ZERO) > 0 ){
			    					commissionAmountN = commissionAmountN.multiply(eurRate);
			    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
			    				}
		    				}
		    				else{
		    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmountN);
		    				}
    					}else{
		    				oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmount);
		    				if (txCurrencyCode.contains("USD") || txCurrencyCode.contains("EUR")) {
			    				if (txCurrencyCode.contains("USD") && usdRate != null && usdRate.compareTo(BigDecimal.ZERO) > 0 ){
			    					commissionAmountN = commissionAmount.multiply(usdRate ); //
			    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmount);
			    				}else if (txCurrencyCode.contains("EUR") && eurRate != null &&  eurRate.compareTo(BigDecimal.ZERO) > 0 ){
			    					commissionAmountN = commissionAmount.multiply(eurRate);
			    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", commissionAmount);
			    				}
			    				else{
			    					commissionAmountN = commissionAmount;
			    				}
		    				}
		    				else{
		    					commissionAmountN = commissionAmount;
		    					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", dalMap.getBigDecimal(listName, i, "KOMISYONTUTARLC"));
		    				}
    					}
    				}
					
    				commissionAmountN = commissionAmountN.setScale(2, RoundingMode.HALF_UP);
					//BigDecimal commisionAmount = dalMap.getBigDecimal(listName, i, "KOMISYONTUTARI");
					BigDecimal commisionWithoutBSMV = commissionAmountN.divide(new BigDecimal("1.05"), 2, RoundingMode.HALF_EVEN);
					
					//Konsolidasyon
					
    				oMap.put("KONSOLIDE", counterKonsolide, "ISLEM_TIP_NAME", ISLEM_TIP_NAME);
					
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMTARIHI", dalMap.getString(listName, i, "ISLEMTARIHI"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMTUTARI", dalMap.getBigDecimal(listName, i, "ISLEMTUTARI"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMDOVIZKODU", dalMap.getString(listName, i, "ISLEMDOVIZKODU"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEM_NO", dalMap.getBigDecimal(listName, i, "ISLEM_NO"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMNOPTT", dalMap.getString(listName, i, "ISLEMNOPTT"));
					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONDOVIZKODU", dalMap.getString(listName, i, "KOMISYONDOVIZKODU"));
					
					oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARI", commissionAmountN);   
    				oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTL", commissionAmountN);
					
					//oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTUTARLC", dalMap.getBigDecimal(listName, i, "KOMISYONTUTARLC"));
					oMap.put("KONSOLIDE", counterKonsolide, "BSMVSIZKOMISYON", commisionWithoutBSMV);
					oMap.put("KONSOLIDE", counterKonsolide, "BSMV", commissionAmountN.subtract(commisionWithoutBSMV));
					
					oMap.put("KONSOLIDE", counterKonsolide, "PTTKOD", getPttCode(commType, currency));
					oMap.put("KONSOLIDE", counterKonsolide, "PTTACIKLAMA", description);
					
					oMap.put("KONSOLIDE", counterKonsolide, "PTTKUR", dalMap.getBigDecimal(listName, i, "PTTKUR"));
					oMap.put("KONSOLIDE", counterKonsolide, "PTTDOVIZKUR", dalMap.getBigDecimal(listName, i, "PTTDOVIZKUR"));
					oMap.put("KONSOLIDE", counterKonsolide, "MASRAFTL", dalMap.getBigDecimal(listName, i, "MASRAFTL"));
					oMap.put("KONSOLIDE", counterKonsolide, "ODEME_SEKLI", dalMap.getString(listName, i, "ODEMESEKLI"));
					     
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEMTURU", dalMap.getString(listName, i, "ISLEMTURU"));
					oMap.put("KONSOLIDE", counterKonsolide, "ISLEM_TIP", dalMap.getString(listName, i, "ISLEM_TIP"));
					oMap.put("KONSOLIDE", counterKonsolide, "REFERANS", dalMap.getString(listName, i, "REFERANS"));
					oMap.put("KONSOLIDE", counterKonsolide, "TAHSILAT_TUTAR", dalMap.getString(listName, i, "TAHSILAT_TUTAR"));
					oMap.put("KONSOLIDE", counterKonsolide, "TAHSILAT_PARA_BIRIMI", dalMap.getString(listName, i, "TAHSILAT_PARA_BIRIMI"));
					oMap.put("KONSOLIDE", counterKonsolide, "MASRAF_TUTARI", dalMap.getBigDecimal(listName, i, "MASRAF_TUTARI"));
					oMap.put("KONSOLIDE", counterKonsolide, "MASRAF_DOVIZ_KODU", dalMap.getString(listName, i, "MASRAF_DOVIZ_KODU"));
    				
    				//oMap.put(tableKey, oMap.getInt(counterKey), "KOMISYONTL", commissionTL);
    				//oMap.put("KONSOLIDE", counterKonsolide, "KOMISYONTL", commissionTL);
    				counterKonsolide++;
				}				
				
				oMap.put(counterKey, oMap.getInt(counterKey) + 1);
				oMap.put(commissionAmountKey, oMap.getBigDecimal(commissionAmountKey).add(dalMap.getBigDecimal(listName, i, "KOMISYONTUTARLC")));
				totalCommissionAmount = totalCommissionAmount.add(dalMap.getBigDecimal(listName, i, "KOMISYONTUTARLC"));
			}
			
			oMap.put("COMMISSION_AMOUNT_UPT_SUM", totalUptCommissionAmount);
			oMap.put("COMMISSION_AMOUNT_SUM", totalCommissionAmount);
			return oMap;
			
		} catch (Exception e) {
			logger.error("BNSPR_QRY2062_RC_PTT_ISLEM_LIST err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static String getPttCode(CommissionGroupType commType, CurrencyType currency) {
		if (commType.equals(CommissionGroupType.UPT_EFT_GROUP)) {
			if (currency.equals(CurrencyType.TRY))
				return PttTransactionType.UPT_EFT_TRY.getPttCode();
			else if (currency.equals(CurrencyType.USD))
				return PttTransactionType.UPT_EFT_USD.getPttCode();
			else if (currency.equals(CurrencyType.EUR))
				return PttTransactionType.UPT_EFT_EUR.getPttCode();
		} else if(commType.equals(CommissionGroupType.UPT_FC_TRANSFER_LOCAL_GROUP)) {
			if (currency.equals(CurrencyType.TRY))
				return PttTransactionType.UPT_FC_LOCAL_TRY.getPttCode();
			else if (currency.equals(CurrencyType.USD))
				return PttTransactionType.UPT_FC_LOCAL_USD.getPttCode();
			else if (currency.equals(CurrencyType.EUR))
				return PttTransactionType.UPT_FC_LOCAL_EUR.getPttCode();
		} else if(commType.equals(CommissionGroupType.UPT_FC_TRANSFER_GLOBAL_GROUP)) {
			if (currency.equals(CurrencyType.TRY))
				return PttTransactionType.UPT_FC_GLOBAL_TRY.getPttCode();
			else if (currency.equals(CurrencyType.USD))
				return PttTransactionType.UPT_FC_GLOBAL_USD.getPttCode();
			else if (currency.equals(CurrencyType.EUR))
				return PttTransactionType.UPT_FC_GLOBAL_EUR.getPttCode();
		} else if(commType.equals(CommissionGroupType.UPT_REFUND_PAYMENT_GROUP)) {
			if (currency.equals(CurrencyType.TRY))
				return PttTransactionType.UPT_REFUND_LOCAL_TRY.getPttCode();
			else if (currency.equals(CurrencyType.USD))
				return PttTransactionType.UPT_REFUND_LOCAL_USD.getPttCode();
			else if (currency.equals(CurrencyType.EUR))
				return PttTransactionType.UPT_REFUND_LOCAL_EUR.getPttCode();
		} else if(commType.equals(CommissionGroupType.UPT_PAYMENT_GROUP)) {
			if (currency.equals(CurrencyType.TRY))
				return PttTransactionType.UPT_PAYMENT_LOCAL_TRY.getPttCode();
			else if (currency.equals(CurrencyType.USD))
				return PttTransactionType.UPT_PAYMENT_LOCAL_USD.getPttCode();
			else if (currency.equals(CurrencyType.EUR))
				return PttTransactionType.UPT_PAYMENT_LOCAL_EUR.getPttCode(); //Daha �nce USD yaz�yordu
		} else if(commType.equals(CommissionGroupType.UPT_EFT_PCH_GROUP)) {
			return PttTransactionType.UPT_EFT_PCH_TRY.getPttCode();
		} else if(commType.equals(CommissionGroupType.UPT_EFT_PCH_REFUND_GROUP)) {
			return PttTransactionType.UPT_EFT_PCH_REFUND_TRY.getPttCode();
		} else if(commType.equals(CommissionGroupType.UPT_REFUND_PAYMENT_WITH_EXPENSE_GROUP)){
			if (currency.equals(CurrencyType.TRY))
				return PttTransactionType.UPT_REFUND_PAYMENT_WITH_EXPENSE_TRY.getPttCode();
			else if (currency.equals(CurrencyType.USD))
				return PttTransactionType.UPT_REFUND_PAYMENT_WITH_EXPENSE_USD.getPttCode();
			else if (currency.equals(CurrencyType.EUR))
				return PttTransactionType.UPT_REFUND_PAYMENT_WITH_EXPENSE_EUR.getPttCode();
		}
		
		return null;
	}

	/**
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_QRY2062_PIVOT_TABLE")
	public static GMMap pivotTable(GMMap iMap) {
	
		GMMap oMap = new GMMap();
		String listName = "PIVOT_TABLE";
		BigDecimal totalCommissionAmount = BigDecimal.ZERO;
		
		try {
			
			GMMap dalMap = DALUtil.callOracleRefCursorFunction("{? = call pkg_rc2062.get_pivot_table(?,?,?)}",
				listName, BnsprType.DATE, iMap.getDate("START_DATE"), BnsprType.DATE, iMap.getDate("END_DATE"),
				BnsprType.STRING, iMap.getString("ROLE"));
			
			CurrencyType currency;
			CommissionGroupType commissionGroup;
			
			Map<String, Map<String, Object>> pivotTable = new HashMap<String, Map<String, Object>>();
			for(int i = 0; i< dalMap.getSize(listName); i++) {
				
				TransactionType transactionType = TransactionType.getEnum(dalMap.getString(listName, i, "ISLEM_TURU"));
				commissionGroup = TRANSACTION_COMMISSION_GROUP_MAP.get(transactionType);
				
				if(dalMap.getString(listName, i, "ISLEM_PARA_BIRIMI") != null) {
					currency = CurrencyType.getEnum(dalMap.getString(listName, i, "ISLEM_PARA_BIRIMI"));
				} else {
					currency = null;
				}
				
				String description = commissionGroup.getCurrencySet() != null
					&& commissionGroup.getCurrencySet().size() > 1 && currency != null ? String.format("%s (%s)",
					commissionGroup.toString(), currency.toString()) : commissionGroup.toString();
				int count = dalMap.getInt(listName, i, "ADET");
				BigDecimal transactionAmount = dalMap.getBigDecimal(listName, i, "ISLEM_TUTARI");
				BigDecimal commissionAmount = dalMap.getBigDecimal(listName, i, "KOMISYON_TUTARI_LC");
				
				Map<String, Object> tempMap = pivotTable.get(description);

				if(tempMap != null) {
					tempMap.put("ADET", ((BigDecimal) tempMap.get("ADET")).add(BigDecimal.valueOf(count)));
					tempMap.put("ISLEM_TUTARI", ((BigDecimal) tempMap.get("ISLEM_TUTARI")).add(transactionAmount));
					tempMap.put("KOMISYON_TUTARI_LC", ((BigDecimal) tempMap.get("KOMISYON_TUTARI_LC")).add(commissionAmount));
				} else {
					tempMap = new HashMap<String, Object>();
					tempMap.put("ADET", BigDecimal.valueOf(count));
					tempMap.put("ISLEM_TUTARI", transactionAmount);
					tempMap.put("KOMISYON_TUTARI_LC", commissionAmount);
					pivotTable.put(description, tempMap);
				}	
			}
			
			int index = 0;
			for(CommissionGroupType gVal : CommissionGroupType.values()) {

				StringBuilder strBuilder = new StringBuilder();
				for (Entry<TransactionType, CommissionGroupType> entry : TRANSACTION_COMMISSION_GROUP_MAP.entrySet()) {
		            
					if (entry.getValue() == gVal) {
						if(strBuilder.length() > 0) strBuilder.append("-");
		            	strBuilder.append(entry.getKey().getCode());
		            }
		        }
				
				if(gVal.getCurrencySet() != null && gVal.getCurrencySet().size() > 1) {
					
					for(CurrencyType cVal : CurrencyType.values()) {
						String key = String.format("%s (%s)", gVal.toString(), cVal.toString());
						oMap.put(listName, index, "ACIKLAMA", key);
						oMap.put(listName, index, "ISLEM_TIPI", strBuilder.toString());
						oMap.put(listName, index, "PTT_KODU", getPttCode(gVal, cVal));
				
						if(pivotTable.get(key) != null) {
							oMap.put(listName, index, "ADET", pivotTable.get(key).get("ADET"));
							oMap.put(listName, index, "ISLEM_TUTARI", pivotTable.get(key).get("ISLEM_TUTARI"));
							oMap.put(listName, index, "KOMISYON_TUTARI", pivotTable.get(key).get("KOMISYON_TUTARI_LC"));
							totalCommissionAmount = totalCommissionAmount.add((BigDecimal) pivotTable.get(key).get(
								"KOMISYON_TUTARI_LC"));
							
							BigDecimal commission = (BigDecimal) pivotTable.get(key).get("KOMISYON_TUTARI_LC");
							BigDecimal commissionWithoutBsmv = commission.divide(new BigDecimal("1.05"), 2, RoundingMode.HALF_EVEN);
							BigDecimal bsmv = commission.subtract(commissionWithoutBsmv);
							oMap.put(listName, index, "BSMV_HARIC_KOMISYON", commissionWithoutBsmv);
							oMap.put(listName, index, "BSMV", bsmv);
							
						} else {
							oMap.put(listName, index, "ADET", 0);
							oMap.put(listName, index, "ISLEM_TUTARI", 0);
							oMap.put(listName, index, "KOMISYON_TUTARI", 0);
							oMap.put(listName, index, "BSMV_HARIC_KOMISYON", 0);
							oMap.put(listName, index, "BSMV", 0);
						}
						index++;
					}
					
				} else {
					
					oMap.put(listName, index, "ACIKLAMA", gVal.toString());
					oMap.put(listName, index, "ISLEM_TIPI", strBuilder.toString());
					oMap.put(listName, index, "PTT_KODU", getPttCode(gVal, null));
					if(pivotTable.get(gVal.toString()) != null) {
						oMap.put(listName, index, "ADET", pivotTable.get(gVal.toString()).get("ADET"));
						oMap.put(listName, index, "ISLEM_TUTARI", pivotTable.get(gVal.toString()).get("ISLEM_TUTARI"));
						oMap.put(listName, index, "KOMISYON_TUTARI", pivotTable.get(gVal.toString()).get(
							"KOMISYON_TUTARI_LC"));
						totalCommissionAmount = totalCommissionAmount.add((BigDecimal) pivotTable.get(gVal.toString())
							.get("KOMISYON_TUTARI_LC"));
						BigDecimal commission = (BigDecimal) pivotTable.get(gVal.toString()).get("KOMISYON_TUTARI_LC");
						BigDecimal commissionWithoutBsmv = commission.divide(new BigDecimal("1.05"), 2, RoundingMode.HALF_EVEN);
						BigDecimal bsmv = commission.subtract(commissionWithoutBsmv);
						oMap.put(listName, index, "BSMV_HARIC_KOMISYON", commissionWithoutBsmv);
						oMap.put(listName, index, "BSMV", bsmv);
		
					} else {
						oMap.put(listName, index, "ADET", 0);
						oMap.put(listName, index, "ISLEM_TUTARI", 0);
						oMap.put(listName, index, "KOMISYON_TUTARI", 0);
						oMap.put(listName, index, "BSMV_HARIC_KOMISYON", 0);
						oMap.put(listName, index, "BSMV", 0);
					}
					index++;
				}
			}
			
			/*index = -1;
			for(Entry<String, Map<String, BigDecimal>> entry : pivotTable.entrySet()) {
				oMap.put(listName, ++index, "ACIKLAMA", entry.getKey());
				for(Entry<String, BigDecimal> innerEntry : entry.getValue().entrySet()) {
					oMap.put(listName, index, innerEntry.getKey(), innerEntry.getValue());
				}
			}*/
			
			oMap.put("COMMISSION_AMOUNT_SUM", totalCommissionAmount);
			return oMap;
			
		} catch (Exception e) {
			logger.error("BNSPR_QRY2062_PIVOT_TABLE err:", e);
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_QRY2062_RC_PTT_FX_LIST")
	public static GMMap getPttFx(GMMap iMap){
		GMMap oMap = new GMMap();
		String listName = "PTTFX";
		try {
			GMMap dalMap = (GMMap) DALUtil.callOracleProcedure("{call pkg_rc2062.get_ptt_fx(?,?,?,?)}",
					new Object[]{
						BnsprType.DATE, iMap.get("START_DATE") != null ? iMap.getDate("START_DATE") : null,
						BnsprType.DATE, iMap.getDate("END_DATE") != null ? iMap.getDate("END_DATE") : null,
						BnsprType.STRING, iMap.getString("ROLE")
			}, new Object[]{
					BnsprType.REFCURSOR, listName
			});
			
			for(int i = 0; i < dalMap.getSize(listName); i++) {
				oMap.put("PTT_FX_TABLE", i, "ODEME_KUR", dalMap.getString(listName, i, "ODEME_KUR"));
				oMap.put("PTT_FX_TABLE", i, "USD_MARJSIZ_KUR", dalMap.getString(listName, i, "USD_MARJSIZ_KUR"));
				oMap.put("PTT_FX_TABLE", i, "EUR_MARJSIZ_KUR", dalMap.getString(listName, i, "EUR_MARJSIZ_KUR"));
				oMap.put("PTT_FX_TABLE", i, "ODEME_TUTARI_TL", dalMap.getString(listName, i, "ODEME_TUTARI_TL"));
				oMap.put("PTT_FX_TABLE", i, "ODEME_TUTARI", dalMap.getString(listName, i, "ODEME_TUTARI"));
				oMap.put("PTT_FX_TABLE", i, "FX_MARJ_GELIRI", dalMap.getString(listName, i, "FX_MARJ_GELIRI"));
				
				oMap.put("PTT_FX_TABLE", i, "REC_DATE", dalMap.getString(listName, i, "REC_DATE"));
				oMap.put("PTT_FX_TABLE", i, "TX_NO", dalMap.getString(listName, i, "TX_NO"));
				oMap.put("PTT_FX_TABLE", i, "ISLEM_SEKLI", dalMap.getString(listName, i, "ISLEM_SEKLI"));
				oMap.put("PTT_FX_TABLE", i, "REFERANS_NO", dalMap.getString(listName, i, "REFERANS_NO"));
				oMap.put("PTT_FX_TABLE", i, "ISLEM_TARIHI", dalMap.getString(listName, i, "ISLEM_TARIHI"));
				oMap.put("PTT_FX_TABLE", i, "DURUM", dalMap.getString(listName, i, "DURUM"));
				oMap.put("PTT_FX_TABLE", i, "TUTAR", dalMap.getString(listName, i, "TUTAR"));
				oMap.put("PTT_FX_TABLE", i, "DOVIZ_KODU", dalMap.getString(listName, i, "DOVIZ_KODU"));
				oMap.put("PTT_FX_TABLE", i, "MASRAF_TUTARI", dalMap.getString(listName, i, "MASRAF_TUTARI"));
				oMap.put("PTT_FX_TABLE", i, "MASRAF_TAHSIL_DOVIZ", dalMap.getString(listName, i, "MASRAF_TAHSIL_DOVIZ"));
				oMap.put("PTT_FX_TABLE", i, "ODEMESEKLI", dalMap.getString(listName, i, "ODEMESEKLI"));
				oMap.put("PTT_FX_TABLE", i, "ODEMENIN_DOVIZ_TURU", dalMap.getString(listName, i, "ODEMENIN_DOVIZ_TURU"));
				oMap.put("PTT_FX_TABLE", i, "TUTAR", dalMap.getString(listName, i, "TUTAR"));
			}
		}
		catch (Exception e) {
			logger.error("BNSPR_QRY2062_RC_PTT_FX_LIST err:", e);
			throw ExceptionHandler.convertException(e);
		}
		
		return oMap;
	}
	
	private static String GetTransactionName(String prm_TransactionType){
		String processName = "";
		
		if(prm_TransactionType.equals("AB - Masraf Dahil �ade") || prm_TransactionType.equals("AB - Masrafs�z �ade") || 
				prm_TransactionType.equals("UPT - Masraf Dahil �ade") || prm_TransactionType.equals("UPT - Masrafs�z �ade")){
			processName = "�ADE";
		}else if(prm_TransactionType.equals("UPT �deme") || prm_TransactionType.equals("EFT �deme") || prm_TransactionType.equals("Referansl� �deme")){
			processName = "�DEME";
		}else if(prm_TransactionType.equals("Swift G�nderim-Yurtd���") || prm_TransactionType.equals("UPT - Hesaba G�nderim") || 
				prm_TransactionType.equals("UPT - �sme G�nderim") || prm_TransactionType.equals("UPT - SEPA G�nderim") ||
				prm_TransactionType.equals("Hesaba EFT") || prm_TransactionType.equals("Kredi Kart�na EFT")){
			processName = "G�NDER�M";
		}
		
		return processName;
	}
	
	private static Boolean IsAzerpostKurum(String prm_kurumKodu, String prm_azerpostKurumKodu){
		if (prm_kurumKodu.equals(prm_azerpostKurumKodu)) {
			return true;
		}else{			
			return false;
		}
	}
}
