package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.currentaccounts.settings.CurrentAccountSettings;
import tr.com.calikbank.bnspr.dao.CariEfektifSatisTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class CurrentAccountsTRN2015Services { 
	@GraymoundService("BNSPR_TRN2015_SAVE_EFEKTIF_SATIS")
	public static Map<?, ?> save(GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			CariEfektifSatisTx cariEfektifSatisTx = new CariEfektifSatisTx();
			cariEfektifSatisTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			cariEfektifSatisTx.setReferansNo(iMap.getString("REFERANS_NO"));
			cariEfektifSatisTx.setSatisSekli(iMap.getBigDecimal("SATIS_SEKLI"));
			cariEfektifSatisTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			cariEfektifSatisTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			
			cariEfektifSatisTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			cariEfektifSatisTx.setSatisTutari(iMap.getBigDecimal("SATIS_TUTARI"));
			cariEfektifSatisTx.setTahsilEdilenToplamTutar(iMap.getBigDecimal("TAHSIL_EDILEN_TOPLAM_TUTAR"));
			cariEfektifSatisTx.setRezervasyonNo(iMap.getBigDecimal("REZERVASYON_NO"));
			cariEfektifSatisTx.setKur(iMap.getBigDecimal("KUR"));
			
			cariEfektifSatisTx.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
			cariEfektifSatisTx.setAciklama(iMap.getString("ACIKLAMA"));
			if(iMap.getString("UNVAN") != null && iMap.getString("UNVAN").length()>90 )
				iMap.put("UNVAN", iMap.getString("UNVAN").substring(0,89));
			cariEfektifSatisTx.setDoviziAlan(iMap.getString("UNVAN"));
			
			cariEfektifSatisTx.setKimlikTipi(iMap.getBigDecimal("KIMLIK_TIPI"));
			
			session.save(cariEfektifSatisTx);
			session.flush();
			
			iMap.put("TRX_NAME", "2015");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2015_GET_REFERANS_NO")
	public static GMMap getReferanceNo(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();			
			stmt = conn.prepareCall(CurrentAccountSettings.TRN2015_ORACLE_FUNC_GET_EFEKTIF_SATIS_REFERANSNO);			
			stmt.registerOutParameter(1, Types.VARCHAR);
			
			stmt.execute();
			Object obj = stmt.getObject(1);
			oMap.put("REFERANS_NO", obj.toString());
			
			return oMap;
		}catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2015_GET_EFEKTIF_SATIS_KURU")
	public static GMMap getKur(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();			
			stmt = conn.prepareCall(CurrentAccountSettings.TRN2015_ORACLE_FUNC_GET_EFEKTIF_SATIS_KURU);			
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.setString(2, iMap.getString("DOVIZ_KODU"));
			
			stmt.execute();
			Object obj = stmt.getObject(1);
			oMap.put("KUR", (BigDecimal)obj);
			
			return oMap;
		}catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2015_GET_REZERVASYON_ACIKMI")
	public static GMMap getRezervasyonAcikmi(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();			
			stmt = conn.prepareCall(CurrentAccountSettings.TRN2015_ORACLE_FUNC_GET_REZERVASYON_ACIKMI);
			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.execute();
			Object obj = stmt.getObject(1);
			oMap.put("REZERVASYON_ACIKMI", obj);
			
			return oMap;
		}catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2015_GET_KMV")
	public static GMMap getKMV(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();			
			stmt = conn.prepareCall(CurrentAccountSettings.TRN2015_ORACLE_FUNC_GET_KMV);
			stmt.registerOutParameter(1, Types.NUMERIC);
			stmt.execute();
			Object obj = stmt.getObject(1);
			oMap.put("KMV", obj);
			
			return oMap;
		}catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN2015_GET_DOVIZ_SATIS_BILGI")
	public static GMMap getDovizSatisBilgi(GMMap iMap) {
		try{	                                                                  
	        Session session = DAOSession.getSession("BNSPRDal");
	        GMMap oMap = new GMMap(); 
	        
	        CariEfektifSatisTx cariEfektifSatisTx = (CariEfektifSatisTx) session.load(CariEfektifSatisTx.class, iMap.getBigDecimal("TRX_NO"));

	        ArrayList<Object> lovInputList = new ArrayList<Object>();
	        
	        oMap.put("TRX_NO" , cariEfektifSatisTx.getTxNo());
	        oMap.put("REFERANS_NO" , cariEfektifSatisTx.getReferansNo());
	        oMap.put("SATIS_SEKLI" , cariEfektifSatisTx.getSatisSekli().toString());
	        oMap.put("MUSTERI_NO" , cariEfektifSatisTx.getMusteriNo());
	        //oMap.put("UNVAN" , CustomerSettings.diLov(cariEfektifSatisTx.getMusteriNo(), "2015/LOV_MUSTERI", "ADI"));
	        oMap.put("HESAP_NO" , cariEfektifSatisTx.getHesapNo());
	        oMap.put("SUBE" , LovHelper.diLov(cariEfektifSatisTx.getHesapNo(),cariEfektifSatisTx.getMusteriNo(), "2015/LOV_MUSTERI_HESAP", "SUBE_KODU"));
	        oMap.put("KISA_ISIM" , LovHelper.diLov(cariEfektifSatisTx.getHesapNo(),cariEfektifSatisTx.getMusteriNo(), "2014/LOV_MUSTERI_HESAP", "KISA_ISIM"));
	        oMap.put("DOVIZ_KODU" , cariEfektifSatisTx.getDovizKodu());
	        oMap.put("SATIS_TUTARI" , cariEfektifSatisTx.getSatisTutari());
	        oMap.put("REZERVASYON_NO" , cariEfektifSatisTx.getRezervasyonNo());
	        oMap.put("TAHSIL_EDILEN_TOPLAM_TUTAR" , cariEfektifSatisTx.getTahsilEdilenToplamTutar());
	        oMap.put("ISTATISTIK_KODU" , cariEfektifSatisTx.getIstatistikKodu());
	        oMap.put("UNVAN" , cariEfektifSatisTx.getDoviziAlan());

	        if (cariEfektifSatisTx.getSatisSekli().compareTo(new BigDecimal(1)) == 0){ //KASADAN
	        	oMap.put("ISTATISTIK_ADI" , LovHelper.diLov(cariEfektifSatisTx.getIstatistikKodu(),"2015/LOV_ISTATISTIK_KASA", "ACIKLAMA"));
	        }
	        else{//HESAPTAN
	        	lovInputList.clear();
				lovInputList.add(cariEfektifSatisTx.getHesapNo().toString());
				lovInputList.add(cariEfektifSatisTx.getHesapNo().toString());
		        
		        oMap.put("ISTATISTIK_ADI" , LovHelper.diLov(cariEfektifSatisTx.getIstatistikKodu(),"2015/LOV_ISTATISTIK_HESAP", "ACIKLAMA",lovInputList));
		    }
	        
	        oMap.put("ACIKLAMA" , cariEfektifSatisTx.getAciklama());
	        oMap.put("KUR" , cariEfektifSatisTx.getKur());
	        oMap.put("KIMLIK_TIPI" , cariEfektifSatisTx.getKimlikTipi().toString());
	        
	        iMap.put("HESAP_NO", cariEfektifSatisTx.getHesapNo());
	        oMap.put("KULLANILABILIR_BAKIYE" , CurrentAccountsCommonServices.getKullanilabilirBakiye(iMap).get("KULLANILABILIR_BAKIYE"));
	        oMap.put("DEFTER_BAKIYE" , CurrentAccountsCommonServices.getDefterBakiyesi(iMap).get("DEFTER_BAKIYE"));   
	        
	        return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}                                                          
	}
	@GraymoundService("BNSPR_TRN2015_VERGI_HESAPLA")
	public static GMMap getVergi(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			GMMap oMap = new GMMap();
			System.out.println(iMap.getBigDecimal("MUSTERI_NO"));
			Object[] inputValues = new Object[] { BnsprType.NUMBER, iMap.getBigDecimal("MUSTERI_NO"),
												  BnsprType.NUMBER, iMap.getBigDecimal("TL_TUTAR"),
												  BnsprType.NUMBER, iMap.getBigDecimal("REZERVASYON_NO"),												  
												  BnsprType.STRING, iMap.getString("DOVIZ_KOD") };
			BigDecimal vergi = (BigDecimal) DALUtil.callOracleFunction("{? = call pkg_trn2013.Vergi_Hesapla(?,?,?,pkg_muhasebe.Banka_Tarihi_Bul,?)}", BnsprType.NUMBER, inputValues);
			oMap.put("VERGI_TUTAR", vergi);
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}			
		finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
