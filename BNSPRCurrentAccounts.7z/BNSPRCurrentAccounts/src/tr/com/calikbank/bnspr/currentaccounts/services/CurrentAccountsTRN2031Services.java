package tr.com.calikbank.bnspr.currentaccounts.services;

import java.util.Date;
import java.util.Map;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CariSubelerarasiHavGiris;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.CariSubelerarasiHavIptalTx;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsTRN2031Services {
	@GraymoundService("BNSPR_TRN2031_GET_SUBELERARASI_HAVALE")
	public static Map<?, ?> getHavale(GMMap iMap){
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			CariSubelerarasiHavGiris cariSubelerarasiHavGiris = (CariSubelerarasiHavGiris)session.createCriteria(CariSubelerarasiHavGiris.class).add(Restrictions.eq("referans", iMap.getString("REFERANS"))).uniqueResult();
			oMap.put("REFERANS", cariSubelerarasiHavGiris.getReferans());
			oMap.put("TARIH", cariSubelerarasiHavGiris.getHavaleTarihi());
			oMap.put("URUN_TUR", cariSubelerarasiHavGiris.getUrunTur());
			oMap.put("URUN_SINIF", cariSubelerarasiHavGiris.getUrunSinif());
			oMap.put("ALICI_SUBE", cariSubelerarasiHavGiris.getGnlSubeKodPr().getKod());
			oMap.put("DOVIZ_KODU", cariSubelerarasiHavGiris.getGnlDovizKodPrByDovizKodu().getKod());
			oMap.put("TUTAR", cariSubelerarasiHavGiris.getOdemeYapilacakTutar());
			if(cariSubelerarasiHavGiris.getGonderimAmaci() != null)
				oMap.put("GONDERIM_AMACI", cariSubelerarasiHavGiris.getGonderimAmaci().toString());
			else
				oMap.put("GONDERIM_AMACI", "");
			oMap.put("GONDEREN_HESAP_NO", cariSubelerarasiHavGiris.getGonderenHesapNo());
			oMap.put("GONDEREN_MUSTERI_NO", cariSubelerarasiHavGiris.getGonderenMusteriNo());
			oMap.put("GONDEREN_ISIM_UNVAN", cariSubelerarasiHavGiris.getGonderenIsimUnvan());
			oMap.put("GONDEREN_ADRES", cariSubelerarasiHavGiris.getGonderenAdres());
			oMap.put("GONDEREN_TEL_NO", cariSubelerarasiHavGiris.getGonderenTelNo());
			oMap.put("ALICI_MUSTERI_NO", cariSubelerarasiHavGiris.getAliciMusteriNo());
			oMap.put("ALICI_HESAP_NO", cariSubelerarasiHavGiris.getAliciHesapNo());
			oMap.put("ALICI_ISIM_UNVAN", cariSubelerarasiHavGiris.getAliciIsimUnvan());
			oMap.put("ALICI_ADRES", cariSubelerarasiHavGiris.getAliciAdres());
			oMap.put("ALICI_TEL_NO", cariSubelerarasiHavGiris.getAliciTelNo());
			oMap.put("ACIKLAMA", cariSubelerarasiHavGiris.getAciklama());
			oMap.put("MASRAF_TAHSIL_SEKLI", cariSubelerarasiHavGiris.getMasrafTahsilSekli());
			oMap.put("MASRAF_TUTARI", cariSubelerarasiHavGiris.getMasrafTutari());
			
			oMap.put("ALICI_SUBE_ADI", cariSubelerarasiHavGiris.getGnlSubeKodPr().getSubeAdi());
			oMap.put("DOVIZ_ADI", cariSubelerarasiHavGiris.getGnlDovizKodPrByDovizKodu().getAciklama());
			if(cariSubelerarasiHavGiris.getGnlDovizKodPrByMasrafTahsilDoviz()!=null){
				oMap.put("MASRAF_TAHSIL_DOVIZ", cariSubelerarasiHavGiris.getGnlDovizKodPrByMasrafTahsilDoviz().getKod());
				oMap.put("MASRAF_THSL_DVZ_ADI", cariSubelerarasiHavGiris.getGnlDovizKodPrByMasrafTahsilDoviz().getAciklama());
			}
			oMap.put("BOLUM_KODU", cariSubelerarasiHavGiris.getBolum().getKod());
			oMap.put("BOLUM_ADI", cariSubelerarasiHavGiris.getBolum().getSubeAdi());
			oMap.put("DURUM_KODU", cariSubelerarasiHavGiris.getDurumKodu());
			
			oMap.put("ALICI_BABA_ADI", cariSubelerarasiHavGiris.getAliciBabaAdi());
			oMap.put("ALICI_DOGUM_TARIHI", cariSubelerarasiHavGiris.getAliciDogumTarihi());
			oMap.put("ALICI_ANA_ADI", cariSubelerarasiHavGiris.getAliciAnneAdi());
			oMap.put("ALICI_TCKN", cariSubelerarasiHavGiris.getAliciTckn());
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2031_SAVE_SUBELERARASI_HAVALE_IPTAL")
	public static Map<?, ?> save(GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			CariSubelerarasiHavIptalTx cariSubelerarasiHavIptal = new CariSubelerarasiHavIptalTx();
			cariSubelerarasiHavIptal.setReferans(iMap.getString("REFERANS"));
			cariSubelerarasiHavIptal.setTarih( GMServiceExecuter.call("BNSPR_COMMON_GET_BANKA_TARIH",iMap).getDate("BANKA_TARIH") );
			cariSubelerarasiHavIptal.setTxNo(iMap.getBigDecimal("TRX_NO"));
			session.save(cariSubelerarasiHavIptal);
			session.flush();
			
			iMap.put("TRX_NAME", "2031");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
