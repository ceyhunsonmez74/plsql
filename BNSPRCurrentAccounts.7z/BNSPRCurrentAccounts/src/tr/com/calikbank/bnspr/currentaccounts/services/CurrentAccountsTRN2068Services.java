package tr.com.calikbank.bnspr.currentaccounts.services;

import java.io.ByteArrayInputStream;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import jxl.Sheet;
import jxl.Workbook;
import jxl.WorkbookSettings;

import tr.com.aktifbank.bnspr.dao.SekerTransferExcel;
import tr.com.aktifbank.bnspr.dao.SekerTransferExcelId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlDuzenliTaksitTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsTRN2068Services {
	
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
	private static final NumberFormat numberFormat = NumberFormat.getNumberInstance(new Locale("TR","tr"));
	private static final String REGEX = "[\\uFFFD]";
	private static final String EMPTY_SPACE = "";
	
	@GraymoundService("BNSPR_TRN2068_UPLOAD_EXCEL")
	public static GMMap uploadExcel(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		try{
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_SEKER_TRANSFER.Hesap_musteri_bilgi(?)}");

			if(iMap.get("EXCEL") == null)
				CurrentAccountsCommonServices.throwGMBusssinessException("Dosya bulunamad�.");
			
			WorkbookSettings setting = new WorkbookSettings();
			setting.setEncoding("UTF-8");
			
			Workbook workbook = Workbook.getWorkbook(new ByteArrayInputStream((byte[]) iMap.get("EXCEL")), setting);
			Sheet sekerSheet = workbook.getSheet(0);

			BigDecimal dosyaNo = GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO", iMap).getBigDecimal("SIRA_NO");
			int row = 0;
			String tableName = "SEKER_TRANSFER_EXCEL";
			for(int i=7; i<sekerSheet.getRows(); i++){
				oMap.put(tableName, row, "SIRA" ,	row+1); 
				oMap.put(tableName, row, "DOSYA_NO",		dosyaNo);
				oMap.put(tableName, row, "REFERANS_NO",		sekerSheet.getCell(2, i).getContents().replaceAll(REGEX, EMPTY_SPACE).trim());
				oMap.put(tableName, row, "TARIH",			dateFormat.parse(sekerSheet.getCell(0, i).getContents().replaceAll(REGEX, EMPTY_SPACE).trim()));
				oMap.put(tableName, row, "ISLEM_TURU",		sekerSheet.getCell(1, i).getContents().replaceAll(REGEX, EMPTY_SPACE).trim());
				oMap.put(tableName, row, "ISLEM_ACIKLAMA",	sekerSheet.getCell(5, i).getContents().replaceAll(REGEX, EMPTY_SPACE).trim());
				oMap.put(tableName, row, "TUTAR",			numberFormat.parse(sekerSheet.getCell(6, i).getContents().replaceAll(REGEX, EMPTY_SPACE).trim()));					
				oMap.put(tableName, row, "HESAP_NO",		sekerSheet.getCell(8, i).getContents().replaceAll(REGEX, EMPTY_SPACE).trim());
				
				int index = 1;
				stmt.registerOutParameter(index++, -10);
				stmt.setBigDecimal(index++, oMap.getBigDecimal(tableName, row, "HESAP_NO"));
				stmt.execute();
				rSet = (ResultSet)stmt.getObject(1);
				
				while(rSet.next()){
					oMap.put(tableName, row, "MUSTERI_NO",		rSet.getString("MUSTERI_NO"));
					oMap.put(tableName, row, "UNVAN",			rSet.getString("UNVAN"));
					oMap.put(tableName, row, "HESAP_KISA_ADI",	rSet.getString("KISA_ISIM"));
				}
				rSet.close();
				
				row++;
			}

			oMap.put("DOSYA_NO", dosyaNo);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2068_SAVE")
	public static GMMap save(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "SEKER_TRANSFER_EXCEL";
			BigDecimal dosyaNo = null;
			
			if(iMap.get(tableName) != null){
				
				for(int i=0;i<iMap.getSize(tableName);i++){
					
					SekerTransferExcelId id = new SekerTransferExcelId();
					dosyaNo = iMap.getBigDecimal(tableName,i,"DOSYA_NO");
					id.setDosyaNo(dosyaNo);
					id.setReferansNo(iMap.getString(tableName,i,"REFERANS_NO"));
					
					SekerTransferExcel excel = (SekerTransferExcel) session.get(SekerTransferExcel.class, id);
					
					if(excel == null){
						excel = new SekerTransferExcel();
					}
					
					excel.setId(id);
					excel.setSira(iMap.getBigDecimal(tableName,i,"SIRA")) ; 
					excel.setTarih(iMap.getDate(tableName,i,"TARIH"));
					excel.setIslemTuru(iMap.getString(tableName,i,"ISLEM_TURU"));
					excel.setIslemAciklama(iMap.getString(tableName,i,"ISLEM_ACIKLAMA"));
					excel.setTutar(iMap.getBigDecimal(tableName,i,"TUTAR"));
					excel.setHesapNo(iMap.getBigDecimal(tableName,i,"HESAP_NO"));
					
					session.saveOrUpdate(excel);
					session.flush();
				}
				
			}
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_SEKER_TRANSFER.transfer(?,?)}");
			stmt.setBigDecimal(1, dosyaNo);
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.execute();
			
			oMap.put("MESSAGE", stmt.getString(2));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN2068_AFTER_SAVE")
	public static GMMap afterSave(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		try{
			
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "SEKER_TRANSFER_EXCEL";
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_SEKER_TRANSFER.Hesap_musteri_bilgi(?)}");
			
			List<SekerTransferExcel> sekerList = (List<SekerTransferExcel>) session.createCriteria(SekerTransferExcel.class).add(Restrictions.eq("id.dosyaNo", iMap.getBigDecimal("DOSYA_NO"))).addOrder(Order.asc("sira")).list()  ;
			 

			int row = 0;
			for(SekerTransferExcel sekerRow : sekerList){
				oMap.put(tableName, row, "SIRA",	    	sekerRow.getSira()); 
				oMap.put(tableName, row, "DOSYA_NO",		sekerRow.getId().getDosyaNo());
				oMap.put(tableName, row, "REFERANS_NO",		sekerRow.getId().getReferansNo());
				oMap.put(tableName, row, "TARIH",			sekerRow.getTarih());
				oMap.put(tableName, row, "ISLEM_TURU",		sekerRow.getIslemTuru());
				oMap.put(tableName, row, "ISLEM_ACIKLAMA",	sekerRow.getIslemAciklama());
				oMap.put(tableName, row, "TUTAR",			sekerRow.getTutar());					
				oMap.put(tableName, row, "HESAP_NO",		sekerRow.getHesapNo());
				oMap.put(tableName, row, "TRANS_TXNO",		sekerRow.getTransTxno());
				oMap.put(tableName, row, "HATA_MESAJI",		sekerRow.getHataMesaji());
				
				int index = 1;
				stmt.registerOutParameter(index++, -10);
				stmt.setBigDecimal(index++, sekerRow.getHesapNo());
				stmt.execute();
				rSet = (ResultSet)stmt.getObject(1);
				
				while(rSet.next()){
					oMap.put(tableName, row, "MUSTERI_NO",		rSet.getString("MUSTERI_NO"));
					oMap.put(tableName, row, "UNVAN",			rSet.getString("UNVAN"));
					oMap.put(tableName, row, "HESAP_KISA_ADI",	rSet.getString("KISA_ISIM"));
				}
				rSet.close();
				
				row++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
