package tr.com.calikbank.bnspr.currentaccounts.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class CurrentAccountsQRY2046Services {
	
	@GraymoundService("BNSPR_QRY2046_GET_AVERAGE_LIST")
	public static GMMap getUrunBasvuruList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_RC2046.RC_QRY2046_Ortalama(?,?,?,?,?,?,?,?,?)}");
			int i =1;
			stmt.registerOutParameter(i++, -10);
			
			if(iMap.getDate("BAS_TARIHI") != null)
				stmt.setDate(i++,  new java.sql.Date(iMap.getDate("BAS_TARIHI").getTime()));
			else
				stmt.setDate(i++, null);
			if(iMap.getDate("BIT_TARIHI") != null)
				stmt.setDate(i++,  new java.sql.Date(iMap.getDate("BIT_TARIHI").getTime()));
			else
				stmt.setDate(i++, null);
			
			stmt.setString(i++, iMap.getString("HESAP_TURU"));
			stmt.setString(i++, iMap.getString("SUBE_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO_ILK"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO_SON"));
			if(iMap.getBoolean("SIFIR_BAKIYELER"))
				stmt.setString(i++, "TRUE");
			else
				stmt.setString(i++, "FALSE");
			
			if(iMap.getBoolean("EVAL_YAPILSIN_MI"))
				stmt.setString(i++, "E");
			else
				stmt.setString(i++, "H");
			
			stmt.setString(i++, iMap.getString("DOVIZ_KODU"));
			
			stmt.execute();
			stmt.getMoreResults();
			rSet = (ResultSet)stmt.getObject(1);

			return DALUtil.rSetResults(rSet,"RESULTS");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}
}
