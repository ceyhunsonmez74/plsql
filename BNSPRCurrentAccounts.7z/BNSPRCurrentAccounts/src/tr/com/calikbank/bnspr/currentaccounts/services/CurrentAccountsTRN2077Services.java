package tr.com.calikbank.bnspr.currentaccounts.services;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ClksPttSubeMerkezKodTx;
import tr.com.calikbank.bnspr.dao.ClksPttSubeMerkezKodTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class CurrentAccountsTRN2077Services {
	@GraymoundService("BNSPR_TRN2077_LOAD_EXCEL")
	public static GMMap merkezSubeList(GMMap iMap) {
		GMMap oMap = new GMMap();
		
		try {			
			String tableName = "MERKEZ_SUBE_DATALARI";
			File file = FileUtil.createTempDirFile("csvread");
			OutputStream writer = new FileOutputStream(file);
			writer.write((byte[])iMap.get("DOSYA"));
			writer.flush();

			//t�rk�e karakter problemi i�in yap�lm��t�r.
			InputStreamReader reader = new InputStreamReader(new FileInputStream(file),"UTF-8");
			BufferedReader br = new BufferedReader(reader);
			
			//ilk sat�r header oldugu i�in atland�.
			br.readLine();
			String strLine = "";
			int i = 0;
			
			while((strLine = br.readLine()) != null){
				String[] list = strLine.split(";");
				if (list.length == 0){
					break;
				}
				oMap.put(tableName, i, "PTT_BASMUDURLUK_ADI",list[0].trim());
				oMap.put(tableName, i, "MERKEZ_NO", list[1].trim());
				oMap.put(tableName, i, "SUBE_NO", list[2].trim());
				oMap.put(tableName, i, "MERKEZ_AD", list[3].trim());
				oMap.put(tableName, i, "SUBE_AD", list[4].trim());
				oMap.put(tableName, i, "MERKEZ_ID", list[5].trim());
				oMap.put(tableName, i, "SUBE_ID", list[6].trim());
				oMap.put(tableName, i, "MERKEZ_PASIF", list[7].trim());
				oMap.put(tableName, i, "SUBE_PASIF", list[8].trim());
				oMap.put(tableName, i, "PTT_BOLGE_AD", list[9].trim());
				oMap.put(tableName, i, "PTT_BASMUDURLUK_KOD",DALUtil.getResult("SELECT PTT_BASMUDURLUK_KOD FROM CLKS_PTT_BASMUDURLUK_KOD_PR WHERE PTT_BASMUDURLUK_ADI = '"+list[0].trim()+"' "));
				i++;
			}

			return oMap;
			}	  catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
		
	
	@GraymoundService("BNSPR_TRN2077_SAVE")
	public static Map<?, ?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal"); 

            String tableName = "MERKEZ_SUBE_DATALARI";
			List<?> guiList = (List<?>)iMap.get(tableName);
			
			if(guiList.size()==0){
				iMap.put("HATA_NO", new BigDecimal(1064));
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			if(iMap.getString("DOSYA_ADI")==null || iMap.getString("DOSYA_ADI").length()==0){
				iMap.put("HATA_NO", new BigDecimal(330));
				iMap.put("P1", "DOSYA_ADI");
				GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			for (int i = 0; i < guiList.size(); i++) {
				
				ClksPttSubeMerkezKodTx clksPttSubeMerkezKodTx = new ClksPttSubeMerkezKodTx();
				ClksPttSubeMerkezKodTxId id = new ClksPttSubeMerkezKodTxId();
				String basmudurluk_adi = iMap.getString(tableName, i, "PTT_BASMUDURLUK_ADI").toUpperCase().replaceAll("�", "C").replaceAll("�", "G").replaceAll("�", "I").
	                replaceAll("�", "O").replaceAll("�", "S").replaceAll("�", "U");
			    id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			    id.setMerkezId(iMap.getString(tableName, i, "MERKEZ_ID"));
			    id.setSubeId(iMap.getString(tableName, i,"SUBE_ID"));
			    if (basmudurluk_adi.equals("ISTANBUL-AND")||basmudurluk_adi.equals("ISTANBUL-AVR")) {
			    	id.setPttBasmudurlukKod("034");
			    }
			    else {
			    	id.setPttBasmudurlukKod(DALUtil.getResult("select ptt_basmudurluk_kod from clks_ptt_basmudurluk_kod_pr where pkg_genel_pr.turkce_char_sil(ptt_basmudurluk_adi) = pkg_genel_pr.turkce_char_sil('"+basmudurluk_adi+"')"));	
			    }	
			    	
			    clksPttSubeMerkezKodTx.setId(id);
			    clksPttSubeMerkezKodTx.setMerkezPasif(iMap.getString(tableName, i, "MERKEZ_PASIF"));
			    clksPttSubeMerkezKodTx.setSubePasif(iMap.getString(tableName, i, "SUBE_PASIF"));
			    clksPttSubeMerkezKodTx.setMerkezNo(iMap.getString(tableName, i, "MERKEZ_NO"));
			    clksPttSubeMerkezKodTx.setSubeNo(iMap.getString(tableName, i, "SUBE_NO"));
			    clksPttSubeMerkezKodTx.setPttBasmudurlukAdi(basmudurluk_adi);
			    clksPttSubeMerkezKodTx.setMerkezAd(iMap.getString(tableName, i, "MERKEZ_AD"));
			    clksPttSubeMerkezKodTx.setSubeAd(iMap.getString(tableName, i, "SUBE_AD"));
			    clksPttSubeMerkezKodTx.setDosyaAdi(iMap.getString("DOSYA_ADI"));
			    clksPttSubeMerkezKodTx.setB�lgeAd(iMap.getString(tableName,i,"PTT_BOLGE_AD"));
				session.save(clksPttSubeMerkezKodTx);
			}
			session.flush();
			iMap.put("TRX_NAME", "2077");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	
	@GraymoundService("BNSPR_TRN2077_GET_INFO")
	public static GMMap getInfo(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		List<?> list = (List<?>)session.createCriteria(ClksPttSubeMerkezKodTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	
		String tableName = "MERKEZ_SUBE_DATALARI";
		int row = 0;
		for (Object name : list) {
			
			ClksPttSubeMerkezKodTx clksPttSubeMerkezKodTx = (ClksPttSubeMerkezKodTx) name;
			oMap.put(tableName, row, "PTT_BASMUDURLUK_KOD", clksPttSubeMerkezKodTx.getId().getPttBasmudurlukKod());
			oMap.put(tableName, row, "MERKEZ_ID", clksPttSubeMerkezKodTx.getId().getMerkezId());
			oMap.put(tableName, row, "SUBE_ID", clksPttSubeMerkezKodTx.getId().getSubeId());
			oMap.put(tableName, row, "MERKEZ_NO", clksPttSubeMerkezKodTx.getMerkezNo());
			oMap.put(tableName, row, "SUBE_NO", clksPttSubeMerkezKodTx.getSubeNo());
			oMap.put(tableName, row, "PTT_BASMUDURLUK_ADI", clksPttSubeMerkezKodTx.getPttBasmudurlukAdi());
			oMap.put(tableName, row, "MERKEZ_AD",clksPttSubeMerkezKodTx.getMerkezAd());
			oMap.put(tableName, row, "SUBE_AD", clksPttSubeMerkezKodTx.getSubeAd());
			oMap.put(tableName, row, "MERKEZ_PASIF", clksPttSubeMerkezKodTx.getMerkezPasif());
			oMap.put(tableName, row, "SUBE_PASIF", clksPttSubeMerkezKodTx.getSubePasif());
			oMap.put(tableName, row, "SUBE_RISK", clksPttSubeMerkezKodTx.getSubeRisk());
			oMap.put("DOSYA_ADI", clksPttSubeMerkezKodTx.getDosyaAdi());
			
			row++;
		}
        	return oMap;
        	
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
