package tr.com.calikbank.bnspr.currentaccounts.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhDabIslem;
import tr.com.calikbank.bnspr.dao.MuhDabIslemId;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.module.custom.services.LOVExecuter;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;


public class CurrentAccountsTRN2036Services {
	@GraymoundService("BNSPR_TRN2036_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			MuhDabIslemId muhDabIslemId = new MuhDabIslemId();
			MuhDabIslem muhDabIslem  = (MuhDabIslem)session.createCriteria(MuhDabIslem.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			boolean	saveOp = false;		
			if(muhDabIslem == null){ 
				muhDabIslem  = new MuhDabIslem();
				saveOp = true;
			}
			muhDabIslemId.setDabno("YENI");
			muhDabIslemId.setTxNo(iMap.getBigDecimal("TRX_NO"));
			muhDabIslem.setId(muhDabIslemId);
			
			muhDabIslem.setSubeKodu(iMap.getString("SUBE_KODU"));
			muhDabIslem.setTarih(iMap.getDate("TARIH"));
			muhDabIslem.setDurumKodu(iMap.getString("DURUM"));
			muhDabIslem.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			muhDabIslem.setDoviziSatan(iMap.getString("DOVIZI_SATAN"));
			muhDabIslem.setUyruk(iMap.getString("UYRUK"));
			muhDabIslem.setIslemTipi(iMap.getString("ISLEM_TIPI"));
			muhDabIslem.setDovizEfektif(iMap.getString("DOVIZ_EFEKTIF"));
			muhDabIslem.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			muhDabIslem.setDovizUlkeKodu(iMap.getString("DOVIZ_ULKE_KODU"));
			muhDabIslem.setTutar(iMap.getBigDecimal("TUTAR"));
			muhDabIslem.setUsdKarsilik(iMap.getBigDecimal("USD_KARSILIK"));
			muhDabIslem.setKur(iMap.getBigDecimal("KUR"));
			muhDabIslem.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
			muhDabIslem.setKesintiler(iMap.getString("KESINTILER"));
			muhDabIslem.setKalanNetTl(iMap.getBigDecimal("KALAN_NET_TL"));
			muhDabIslem.setAciklama(iMap.getString("ACIKLAMA"));
			muhDabIslem.setVergiNo(iMap.getString("VERGI_NO"));
			muhDabIslem.setIhracatSekli(iMap.getBigDecimal("IHRACAT_SEKLI"));
			muhDabIslem.setOdemeSekli(iMap.getBigDecimal("ODEME_SEKLI"));
			muhDabIslem.setTeslimSekli(iMap.getString("TESLIM_SEKLI"));
			muhDabIslem.setCikisKapisi(iMap.getBigDecimal("CIKIS_KAPISI"));
			muhDabIslem.setMalCinsi(iMap.getString("MAL_CINSI"));
			muhDabIslem.setImalatci(iMap.getString("IMALATCI"));
			muhDabIslem.setGumrukBeyannameTarihi(iMap.getDate("GUMRUK_BEYANNAME_TARIHI"));
			muhDabIslem.setGumrukNumarasi(iMap.getBigDecimal("GUMRUK_NUMARASI"));
			muhDabIslem.setTesvikBelge(iMap.getDate("TESVIK_BELGE_TARIHI"));
			muhDabIslem.setTesvikNo(iMap.getBigDecimal("TESVIK_NO"));
			if(saveOp)
				session.save(muhDabIslem);
			else
				session.update(muhDabIslem);
			session.flush();

			iMap.put("TRX_NAME", "2036");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
/*
	private static String getDabNo(String islemTip) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			conn = GMServerDatasource.getConnection("java:/GraymoundDS");
			stmt = conn
					.prepareCall("{? = call Pkg_DAB_DSB.sf_DABNO_Al(?,null)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, islemTip);
			stmt.execute();

			return stmt.getString(1);

		} catch (SQLException e) {
			throw new GMRuntimeException(0, e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
*/
	@GraymoundService("BNSPR_TRN2036_GET_UYRUK_ADI")
	public static HashMap<String, Object> getDIUyruk(GMMap iMap) {
		List<Object> list = new ArrayList<Object>();
		HashMap<String, Object> oMap=new HashMap<String, Object>();
		
		List<?> listUyruk = new ArrayList<Object>();
		listUyruk = LOVExecuter.execute("2014/LOV_UYRUK",iMap.getString("UYRUK")+ "%", list);
		if (listUyruk.size() != 0) {
			oMap.put("UYRUK_ADI", ((HashMap<?, ?>) listUyruk.get(0)).get("ACIKLAMA"));
		}
		list.clear();
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN2036_GET_USD_KARSILIK")
	public static HashMap<String, Object> getUsdKarsilik(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			conn = DALUtil.getGMConnection();
			stmt = conn
					.prepareCall("{? = call pkg_kur.DOVIZ_CEVIR( ?,'USD',null,?,3,null,null,'O','A')}");

			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setString(2, iMap.getString("DOVIZ_KODU"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TUTAR"));
			stmt.execute();
			
			HashMap<String, Object> oMap = new HashMap<String, Object>();
			oMap.put("USD_KARSILIK", stmt.getBigDecimal(1));

			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2036_GET_KUR_INFO")
	public static HashMap<String, Object> getKur(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			HashMap<String, Object> oMap = new HashMap<String, Object>();
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call pkg_kur.EAK_to_LC(?,1)}");
			
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setString(2, iMap.getString("DOVIZ_KODU"));
			
			stmt.execute();
			oMap.put("KUR", stmt.getBigDecimal(1));
			
			return oMap;
		}catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2036_GET_DAB_INFO")
	public static GMMap getDabInfo(GMMap iMap) {
		try{
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			MuhDabIslem muhDabIslem = (MuhDabIslem) session.createCriteria(
					MuhDabIslem.class).add(
					Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
					.uniqueResult();

			oMap.put("TRX_NO", muhDabIslem.getId().getTxNo());
			oMap.put("DAB_NO", muhDabIslem.getId().getDabno());
			oMap.put("IHRACAT_SEKLI", muhDabIslem.getIhracatSekli());
			oMap.put("ODEME_SEKLI", muhDabIslem.getOdemeSekli());
			oMap.put("TESLIM_SEKLI", muhDabIslem.getTeslimSekli());
			oMap.put("CIKIS_KAPISI", muhDabIslem.getCikisKapisi());
			oMap.putAll(CurrentAccountsTRN2037Services
					.getDICikisKapisi(muhDabIslem.getCikisKapisi()));
			oMap.put("MAL_CINSI", muhDabIslem.getMalCinsi());
			oMap.put("IMALATCI", muhDabIslem.getImalatci());
			oMap.put("GUMRUK_BEYANNAME_TARIHI", muhDabIslem
					.getGumrukBeyannameTarihi());
			oMap.put("GUMRUK_NUMARASI", muhDabIslem.getGumrukNumarasi());
			oMap.put("TESVIK_NO", muhDabIslem.getTesvikNo());
			oMap
					.put("TESVIK_BELGE_TARIHI", (Date) muhDabIslem
							.getTesvikBelge());
			oMap.put("TRX_NO", muhDabIslem.getId().getTxNo());
			oMap.put("SUBE_KODU", muhDabIslem.getSubeKodu());

			iMap.put("SUBE_KODU", (String) oMap.get("SUBE_KODU"));
			oMap.putAll(CurrentAccountsCommonServices.getSubeAdi(iMap));
			oMap.put("DURUM_KODU", muhDabIslem.getDurumKodu());
			oMap.put("TARIH", (Date) muhDabIslem.getTarih());
			oMap.put("MUSTERI_NO", muhDabIslem.getMusteriNo());
			oMap.put("DOVIZI_SATAN", muhDabIslem.getDoviziSatan());
			oMap.put("UYRUK", muhDabIslem.getUyruk());
			oMap.putAll(CurrentAccountsTRN2037Services.getDIUyruk((String) oMap
					.get("UYRUK")));
			oMap.put("ISLEM_TIPI", muhDabIslem.getIslemTipi());
			oMap.put("DOVIZ_EFEKTIF", muhDabIslem.getDovizEfektif());
			oMap.put("ISTATISTIK_KODU", muhDabIslem.getIstatistikKodu());
			oMap.putAll(CurrentAccountsTRN2037Services.getDIIstatistikKodu(
					(String) oMap.get("ISTATISTIK_KODU"), (String) oMap
							.get("ISLEM_TIPI"), (String) oMap
							.get("DOVIZ_EFEKTIF")));
			oMap.put("TUTAR", muhDabIslem.getTutar());
			oMap.put("USD_KARSILIK", muhDabIslem.getUsdKarsilik());
			oMap.put("KUR", muhDabIslem.getKur());
			oMap.put("KESINTILER", muhDabIslem.getKesintiler());
			oMap.put("KALAN_NET_TL", muhDabIslem.getKalanNetTl());
			oMap.put("ACIKLAMA", muhDabIslem.getAciklama());
			oMap.put("VERGI_NO", muhDabIslem.getVergiNo());
			oMap.put("DOVIZ_KODU", muhDabIslem.getDovizKodu());
			oMap.putAll(CurrentAccountsTRN2037Services
					.getDIDovizKodu((String) oMap.get("DOVIZ_KODU")));
			oMap.put("DOVIZ_ULKE_KODU", muhDabIslem.getDovizUlkeKodu());
			oMap.putAll(CurrentAccountsTRN2037Services
					.getDIDovizUlkeKodu((String) oMap.get("DOVIZ_ULKE_KODU")));
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
