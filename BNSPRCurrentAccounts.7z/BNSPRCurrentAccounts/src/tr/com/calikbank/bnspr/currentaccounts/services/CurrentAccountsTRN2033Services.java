package tr.com.calikbank.bnspr.currentaccounts.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Types;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.MuhDsbIslem;
import tr.com.calikbank.bnspr.dao.MuhDsbIslemId;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class CurrentAccountsTRN2033Services {
	@GraymoundService("BNSPR_TRN2033_SAVE_DSB_ISLEM")
	public static Map<?, ?> save(GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			MuhDsbIslem muhDsbIslem = new MuhDsbIslem();
			muhDsbIslem.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			muhDsbIslem.setDoviziAlan(iMap.getString("DOVIZI_ALAN"));
			muhDsbIslem.setUyruk(iMap.getString("UYRUK"));
			muhDsbIslem.setAdres(iMap.getString("ADRES"));
			muhDsbIslem.setSemt(iMap.getString("SEMT"));
			muhDsbIslem.setIlKod(iMap.getString("IL_KOD"));
			muhDsbIslem.setPostaKod(iMap.getBigDecimal("POSTA_KOD"));
			muhDsbIslem.setUlkeKod(iMap.getString("ULKE_KOD"));
			muhDsbIslem.setIslemTipi(iMap.getString("ISLEM_TIPI"));
			muhDsbIslem.setDovizEfektif(iMap.getString("DOVIZ_EFEKTIF"));
			muhDsbIslem.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			muhDsbIslem.setIstatistikKodu(iMap.getString("ISTATISTIK_KODU"));
			muhDsbIslem.setTutar(iMap.getBigDecimal("TUTAR"));
			muhDsbIslem.setKur(iMap.getBigDecimal("KUR"));
			muhDsbIslem.setUsdKarsilik(iMap.getBigDecimal("USD_KARSILIK"));
			muhDsbIslem.setSubeKodu(iMap.getString("SUBE_KODU"));
			muhDsbIslem.setAciklama(iMap.getString("ACIKLAMA"));
			
			muhDsbIslem.setTarih(iMap.getDate("TARIH"));
			
			MuhDsbIslemId id = new MuhDsbIslemId();
			id.setTxNo(iMap.getBigDecimal("TRX_NO"));
			id.setDsbno("YENI");
			muhDsbIslem.setId(id);

			session.save(muhDsbIslem);
			session.flush();
			
			iMap.put("TRX_NAME", "2033");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2033_GET_MUSTERI_ADRES")
	public static Map<?, ?> callBekleyenIslemVarmi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		HashMap<String, Object> oMap = new HashMap<String, Object>();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call pkg_musteri.Musteri_Adres(?,?,?,?,?,?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.VARCHAR);
			stmt.registerOutParameter(5, Types.VARCHAR);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.registerOutParameter(7, Types.VARCHAR);
	    	stmt.execute();
	    	oMap.put("ADRES", stmt.getString(2));
	    	oMap.put("SEMT", stmt.getString(3));
	    	oMap.put("IL_KOD", stmt.getString(4));
	    	oMap.put("ILCE_KOD", stmt.getString(5));
	    	oMap.put("POSTA_KOD", stmt.getString(6));
	    	oMap.put("ULKE_KOD", stmt.getString(7));
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
}
