package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsTRN2016Test extends TestCase {
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("TRX_NO", getTransactionNo());
		iMap.put("REFERANS_NO", GetReferansNo());
		iMap.put("ACIKLAMA", "kaydet");
		iMap.put("DK_NO", "11");
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("HESAP_NO",new BigDecimal(624));
		iMap.put("ISLEM_SEKLI", "MH");
		iMap.put("MUSTERI_NO", new BigDecimal(1000100));	
		iMap.put("TUTAR", new BigDecimal(12));
		iMap.put("KIMLIK_TIPI", new BigDecimal(1));	
		iMap.put("ISTATISTIK_KODU","10206");
		
		iMap.put("MASRAF_TAHSIL_DOVIZ","TRY");
		iMap.put("MASRAF_TAHSIL_SEKLI","k");
		iMap.put("MASRAF_HESABI",new BigDecimal(624));
		iMap.put("MASRAF_TUTARI",new BigDecimal(16.30));
		iMap.put("MASRAF_TUTARI_MAS_DVZ",new BigDecimal(21.01));
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("VALOR_TARIHI", (java.util.Date)dateFormat.parse("11-11-2005"));		
		}catch(Exception e){}
		
		return iMap;
	}
	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	public String GetReferansNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2016_GET_REFERANCE_NO", new HashMap<String, Object>());
		return (String)oMap.get("REFERANS_NO");
	}
	public void testAciklamaNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ACIKLAMA", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2016_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testDovizKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DOVIZ_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2016_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testIslemSekliNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISLEM_SEKLI", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2016_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testIstatistikKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISTATISTIK_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2016_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	/*public void testDkNoNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		
		iMap.put("ISLEM_SEKLI","DK");
		iMap.put("DK_NO", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2016_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}	*///dk no not null??m�
	public void testCanGetReferanceNo() {	
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2016_GET_REFERANCE_NO",new HashMap<String, Object>());
		assertNotNull(oMap.get("REFERANS_NO"));
	}
	
	public void testCheckDovizTutarWithKurussuzTutar(){
		HashMap<String,Object> iMap = new HashMap<String, Object>();
		iMap.put("TUTAR", "0.00");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2016_CHECK_DOVIZ_TUTAR",iMap);
		assertEquals(1, oMap.get("FLAG"));
	}
	
	public void testCheckDovizTutarWithKurusluTutar(){
		HashMap<String,Object> iMap = new HashMap<String, Object>();
		iMap.put("TUTAR", "0.03");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2016_CHECK_DOVIZ_TUTAR",iMap);
		assertEquals(0, oMap.get("FLAG"));
	}
	
	public void testOMapInfoAssertEq()
	{
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", "22520");
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2016_GET_INFO", iMap);

		assertEquals(oMap.get("REFERANS_NO")			, "07.200CNY0000662");
		assertEquals(oMap.get("ISLEM_SEKLI")			, "MH");		
		assertEquals(oMap.get("DOVIZ_KODU")				, "TRY");
		assertEquals(oMap.get("SUBE_KODU")				, "200");	
		assertEquals(oMap.get("MUSTERI_NO")				, new BigDecimal(38));
		assertEquals(oMap.get("HESAP_NO")				, new BigDecimal(462));
		assertEquals(oMap.get("DK_NO")					, null);
		assertEquals(oMap.get("TUTAR")					, new BigDecimal(33));
		assertEquals(oMap.get("ACIKLAMA")				, "33333333333");
		assertEquals(oMap.get("KIMLIK_TIPI")			, "1");
		assertEquals(oMap.get("ISTATISTIK_KODU")		, null);
		
		assertEquals(oMap.get("MASRAF_TAHSIL_SEKLI")	, "HAVALEHESP");
		assertEquals(oMap.get("MASRAF_HESAP_NO")		, null);
		assertEquals(oMap.get("MASRAF_TUTARI")			, new BigDecimal(0));
		assertEquals(oMap.get("MASRAF_TUTARI_MAS_DVZ")	, new BigDecimal(0));
		assertEquals(oMap.get("MASRAF_TAHSIL_DOVIZ")	, "TRY");
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			assertEquals(oMap.get("VALOR_TARIHI")			, dateFormat.parseObject("2008-02-05"));
		} catch (ParseException e) {
			e.printStackTrace();
		} 
		
	}
}
