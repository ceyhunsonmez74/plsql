package tr.com.calikbank.bnspr.currentaccount.tests;

import java.io.IOException;

import org.junit.Before;
import org.junit.Test;

import com.graymound.connection.GMConnection;
import com.graymound.util.GMMap;

public class CurrentAccountsPTTKrediTahsilDosyaOkuServices {

	private GMConnection conn;	

	@Before
	public void setup()throws Exception {
		try {
			conn = GMConnection.getConnection("serife"); 
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@Test
	public void testFundServices() {
		try{
			test();
	

		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private void test() {
		GMMap iMap = new GMMap();
		
		try {
			//iMap.put("CLASS_NAME", "tr.com.aktifbank.webext.bnym.BnymServices");
			GMMap oMap = new GMMap(conn.serviceCall("BNSPR_PTT_KREDI_TAHSIL_DOSYA_OKU", iMap));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}


}
