package tr.com.calikbank.bnspr.currentaccount.tests;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class CurrentAccountsQRY2035Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("SUBE_KODU", null);
		iMap.put("HAVALE_TIPI", "HAVALEHESP");
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("MIN_TUTAR", "0.00");
		iMap.put("MAX_TUTAR", "0.00");
		iMap.put("DURUM_KODU", null);
		iMap.put("ALICI_MUSTERI_NO", null);
		iMap.put("GONDEREN_MUSTERI_NO", null);
		iMap.put("GONDERIM_AMACI", null);
	
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("BAS_TARIH",(Date)dateFormat.parse("11-11-2005"));
			iMap.put("SON_TARIH", (Date)dateFormat.parse("11-11-2008"));
		}catch (Exception e) {
		}
		return iMap;
	}
	public void testCanGetCorrectHavaleList(){
		HashMap<String, Object> iMap = setUpIMap();
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2035_GET_GIDEN_HAVALE_HAREKET", iMap);
		List<?> list = (List<?>)oMap.get("CBS_HAVALE_LISTE");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("200",rowData.get("REFERANS")); 
			assertEquals("Ersin  LALBEK", rowData.get("DOVIZ_KODU"));
			assertEquals("4395", rowData.get("TUTAR"));
			assertEquals("USD", rowData.get("GONDEREN_MUSTERI_NO"));
			assertEquals("1000", rowData.get("GONDEREN_ISIM_UNVAN"));
			assertEquals("A", rowData.get("ALICI_MUSTERI_NO"));
			assertEquals("A", rowData.get("ALICI_ISIM_UNVAN"));
			assertEquals("A", rowData.get("DURUM"));
		}
	}

}
