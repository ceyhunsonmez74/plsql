package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsTRN2020Test extends TestCase {
	public void testCanGetKullaniciKasaData(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2020_GET_KASA_KULLANICI_DATA", new HashMap<String, Object>());
		BigDecimal tanimNo = (BigDecimal)oMap.get("TANIM_NO");
		System.out.println("TANIM_NO: " + tanimNo);
		assertNotNull(tanimNo);
		
		String modulTurKod = (String)oMap.get("MODUL_TUR_KOD");
		System.out.println("MODUL_TUR_KOD: " + modulTurKod);
		assertEquals("CARI", modulTurKod);
		
		String urunTurKod = (String)oMap.get("URUN_TUR_KOD");
		System.out.println("URUN_TUR_KOD: " + urunTurKod);
		assertEquals("KASA", urunTurKod);
		
		String urunSinifKod = (String)oMap.get("URUN_SINIF_KOD");
		System.out.println("URUN_SINIF_KOD: " + urunSinifKod);
		assertEquals("GENEL", urunSinifKod);
		
		Date bankaTarihi = (Date)oMap.get("BANKA_TARIHI");
		System.out.println("URUN_SINIF_KOD: " + bankaTarihi);
		assertNotNull(bankaTarihi);
		
		String subeKodu = (String)oMap.get("SUBE_KODU");
		System.out.println("SUBE_KODU: " + subeKodu);
		assertNotNull(subeKodu);
	}
}
