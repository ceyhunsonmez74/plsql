package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountTRN2011Test extends TestCase{
	
	public HashMap<String, Object> setUpIMap(){
		
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("TRX_NO",11111111);
		iMap.put("REZERVASYON_NO",1);
		iMap.put("ALIS_DOVIZ_KODU","USD");
		iMap.put("SATIS_DOVIZ_KODU","EUR");
		iMap.put("KUR_PARITE_SECIM","K");
		iMap.put("ALIS_KURU",1.18);
		iMap.put("SATIS_KURU",1.71);
		iMap.put("PARITE",0.00000);
		iMap.put("CARP_BOL_SECIM","BOS");
		iMap.put("ALIS_TUTARI",10.00);
		iMap.put("SATIS_TUTARI",6.905);
		iMap.put("ALIS_HESAP_NO",110);
		iMap.put("SATIS_HESAP_NO",98);
		iMap.put("MASRAF_HESAP_NO","");
		iMap.put("ACIKLAMA","A��klama");
		
		return iMap;
	}
	
	public HashMap<String, Object> setUpIMapGetTutar(){
		
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("P_OR_K","K");
		iMap.put("ALIS_DOVIZ_KODU","USD");
		iMap.put("SATIS_DOVIZ_KODU","EUR");
		iMap.put("PARITE",0.00000);
		iMap.put("ALIS_KURU",1.18);
		iMap.put("SATIS_KURU",1.71);
		
		return iMap;
	}
	
	public void testAlisDovizKoduNotNull(){
		
		HashMap<String, Object> iMap = setUpIMap();
		
		iMap.put("ALIS_DOVIZ_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2011_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(" HATA " + success.toString());
		}
	}
	public void testSatisDovizKoduNotNull(){
		
		HashMap<String, Object> iMap = setUpIMap();
		
		iMap.put("SATIS_DOVIZ_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2011_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(" HATA " + success.toString());
		}
	}
	public void testAlisKuruNotNull(){
		
		HashMap<String, Object> iMap = setUpIMap();
		
		iMap.put("ALIS_KURU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2011_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(" HATA " + success.toString());
		}
	}
	public void testSatisKuruNotNull(){
		
		HashMap<String, Object> iMap = setUpIMap();
		
		iMap.put("SATIS_KURU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2011_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(" HATA " + success.toString());
		}
	}
	public void testAlisTutariNotNull(){
		
		HashMap<String, Object> iMap = setUpIMap();
		
		iMap.put("ALIS_TUTARI", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2011_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(" HATA " + success.toString());
		}
	}
	public void testSatisTutariNotNull(){
		
		HashMap<String, Object> iMap = setUpIMap();
		
		iMap.put("SATIS_TUTARI", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2011_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(" HATA " + success.toString());
		}
	}
	public void testAlisHesapNoNotNull(){
		
		HashMap<String, Object> iMap = setUpIMap();
		
		iMap.put("ALIS_HESAP_NO", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2011_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(" HATA " + success.toString());
		}
	}
	public void testSatisHesapNoNotNull(){
		
		HashMap<String, Object> iMap = setUpIMap();
		
		iMap.put("SATIS_HESAP_NO", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2011_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(" HATA " + success.toString());
		}
	}
	public void testAciklamaNotNull(){
		
		HashMap<String, Object> iMap = setUpIMap();
		
		iMap.put("ACIKLAMA", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2011_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(" HATA " + success.toString());
		}
	}
	public void testCanGetCorrectAlisKuruValue(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ALIS_DOVIZ_KODU", "USD");
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2011_GET_ALIS_KURU", iMap);
		assertEquals("",new Double(1.18),(Double.parseDouble(oMap.get("ALIS_KURU").toString())) ,new Double(0.2));
		
	}
	public void testCanGetCorrectSatisKuruValue(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("SATIS_DOVIZ_KODU", "EUR");
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2011_GET_SATIS_KURU", iMap);
		assertEquals("",new Double(1.71),(Double.parseDouble(oMap.get("SATIS_KURU").toString())) ,new Double(0.2));
		
	}
	public void testAlisKuruTip(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ALIS_DOVIZ_KODU", "USD");
				
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2011_GET_ALIS_KURU", iMap);
		assertTrue(oMap.get("ALIS_KURU") instanceof BigDecimal);
		
	}
	public void testSatisKuruTip(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("SATIS_DOVIZ_KODU", "USD");
				
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2011_GET_SATIS_KURU", iMap);
		assertTrue(oMap.get("SATIS_KURU") instanceof BigDecimal);
		
	}
	public void testCanGetAlisTutariValue(){
		HashMap<String, Object> iMap = setUpIMapGetTutar();
		iMap.put("SATIS_TUTARI", 690.05);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2011_SATISTAN_ALIS", iMap);
		assertEquals("",new Double(1000.00),(Double.parseDouble(oMap.get("ALIS_TUTARI").toString())) ,new Double(0.2));
		assertEquals("BOS",oMap.get("CARP_BOL_SECIM"));
	}
	public void testAlisTutariTip(){
		HashMap<String, Object> iMap = setUpIMapGetTutar();
		iMap.put("SATIS_TUTARI", 690.05);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2011_SATISTAN_ALIS", iMap);
		assertTrue(oMap.get("ALIS_TUTARI") instanceof BigDecimal);
		assertTrue(oMap.get("CARP_BOL_SECIM") instanceof String);
	}
	public void testCanGetSatisTutariValue(){
		HashMap<String, Object> iMap = setUpIMapGetTutar();
		iMap.put("ALIS_TUTARI", 1000.00);
				
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2011_ALISTAN_SATIS", iMap);
		assertEquals("",new Double(690.05),(Double.parseDouble(oMap.get("SATIS_TUTARI").toString())) ,new Double(0.2));
		assertEquals("BOS",oMap.get("CARP_BOL_SECIM"));
	}
	public void testSatisTutariTip(){
		HashMap<String, Object> iMap = setUpIMapGetTutar();
		iMap.put("ALIS_TUTARI", 1000.00);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2011_ALISTAN_SATIS", iMap);
		assertTrue(oMap.get("SATIS_TUTARI") instanceof BigDecimal);
		assertTrue(oMap.get("CARP_BOL_SECIM") instanceof String);
		
	}
	
	public void testOMapInfoAssertEq()
	{
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", "10436");
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2011_GET_INFO", iMap);
        
		assertEquals(oMap.get("ALIS_DOVIZ_KODU") 			, "USD");        
        assertEquals(oMap.get("SATIS_DOVIZ_KODU") 			, "EUR");
        assertEquals(oMap.get("ALIS_MUSTERI_NO") 			, new BigDecimal(1));
        assertEquals(oMap.get("REZERVASYON_NO") 			, new BigDecimal(1));        
        assertEquals(oMap.get("MASRAF_HESAP_NO") 			, new BigDecimal(104)); 
        //assertEquals(oMap.get("DI_MASRAF_HESAP_DOVIZ_KODU") ,"");
        //assertEquals(oMap.get("DI_MASRAF_TUTARI") 			, "");        
        assertEquals(oMap.get("KUR_PARITE_SECIM") 			, "K");
        assertEquals(oMap.get("CARP_BOL_SECIMI")  			, "BOS");
        assertEquals(oMap.get("ALIS_KURU").toString()		, "1.18"); 
        assertEquals(oMap.get("SATIS_KURU").toString() 		, "1.71");
        assertEquals(oMap.get("PARITE").toString() 			, "0");	        
        assertEquals(oMap.get("ALIS_TUTARI").toString() 	, "55");
        assertEquals(oMap.get("SATIS_TUTARI").toString()	, "37.95");
        assertEquals(oMap.get("ALIS_HESAP_NO") 				, new BigDecimal(110));
        assertEquals(oMap.get("SATIS_HESAP_NO") 			, new BigDecimal(98));
        assertEquals(oMap.get("ACIKLAMA") 					, "hjghjhgjhgj");
        
	}
	
	
}
