package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class CurrentAccountsQRY2038Test extends TestCase {
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("ISLEM_TIPI", "I");
		iMap.put("SUBE_KODU", 200);
		iMap.put("MUSTERI_NO", 1);
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("DURUM_KODU", "T");
		iMap.put("ISTATISTIK_KODU", null);
	
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("BAS_TARIH",(Date)dateFormat.parse("11-11-2005"));
			iMap.put("SON_TARIH", (Date)dateFormat.parse("11-11-2008"));
		}catch (Exception e) {
		}
		return iMap;
	}
	public void testCanGetCorrectDABList(){
		HashMap<String, Object> iMap = setUpIMap();
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_INFO", iMap);
		List<?> list = (List<?>)oMap.get("CBS_DAB_ISLEM");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("200",rowData.get("SUBE_KODU")); 
			assertEquals("Ersin  LALBEK", rowData.get("MUSTERI_ADI"));
			assertEquals("4395", rowData.get("ISTATISTIK_KODU"));
			assertEquals("USD", rowData.get("DOVIZ_KODU"));
			assertEquals("1000", rowData.get("TUTAR"));
			assertEquals("A", rowData.get("DURUM"));
		}
	}
	
	public void testDoviziSatan(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals("ERSIN LALBEK", oMap.get("DOVIZI_SATAN"));
	}
	public void testUyruk(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals("US", oMap.get("UYRUK"));
	}
	public void testVergiNo(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals("59941527114", oMap.get("VERGI_NO"));
	}
	
	public void testDovizUlkeKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals("EU", oMap.get("DOVIZ_ULKE_KODU"));
	}
	public void testDovizKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals("EUR", oMap.get("DOVIZ_KODU"));
	}
	
	public void testTutar(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals(new BigDecimal(1), oMap.get("TUTAR"));
	}
	public void testKur(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals(new Double(1.77),Double.parseDouble(oMap.get("KUR").toString()));
	}
	public void testUSDKarsiligi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals(new Double(1.30),Double.parseDouble(oMap.get("USD_KARSILIK").toString()));
	}
	public void testSubeKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals("200",oMap.get("SUBE_KODU"));
	}
	public void testIhracakSekliAdi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals(new BigDecimal(5),oMap.get("IHRACAT_SEKLI_ADI"));
	}
	public void testTeslimSekliAdi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals("EXW",oMap.get("TESLIM_SEKLI_ADI"));
	}
	public void testOdemeSekliAdi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals(new BigDecimal(6),oMap.get("ODEME_SEKLI_ADI"));
	}
	public void testGumrukNumarasi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals(new BigDecimal(174),oMap.get("GUMRUK_NUMARASI"));
	}
	public void testCikisKapisi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals(new BigDecimal(4),oMap.get("CIKIS_KAPISI_ADI"));
	}
	public void testMalCinsi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals("41",oMap.get("MAL_CINSI"));
	}
	public void testImalatci(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO", "DAB.07.200.A.00025/3");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2038_GET_DAB_DETAY", iMap);
		assertEquals("1",oMap.get("IMALATCI"));
	}
}
