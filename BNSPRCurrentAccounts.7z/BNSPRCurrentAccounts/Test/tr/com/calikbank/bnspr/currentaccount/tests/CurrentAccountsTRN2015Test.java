package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class CurrentAccountsTRN2015Test extends TestCase {
	
	private HashMap<String, Object> getValidEfektifSatisServisMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", GetTransactionNo());
		iMap.put("REFERANS_NO", GetReferansNo());
		iMap.put("SATIS_SEKLI", new BigDecimal(2));
		iMap.put("MUSTERI_NO", new BigDecimal(2));
		iMap.put("HESAP_NO", new BigDecimal(69002));
		iMap.put("DOVIZI_ALAN", "Unit test customer");
		iMap.put("UYRUK", "TR");
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("SATIS_TUTARI", new BigDecimal(1000));
		iMap.put("REZERVASYON_NO", null);
		iMap.put("KUR", new BigDecimal(1.22));
		iMap.put("VERGI_DAIRESI", "ADALAR");
		iMap.put("VERGI_DAIRESI_KODU", "34295");
		iMap.put("VERGI_NO", "111111");
		iMap.put("ISTATISTIK_KODU", "1025");
		iMap.put("ACIKLAMA", "Unit testing cari efektif sat��");
		return iMap;
	}
	
	public String GetTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	
	public String GetReferansNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2015_GET_REFERANS_NO", new HashMap<String, Object>());
		return (String)oMap.get("REFERANS_NO");
	}
	
	public void testCanSaveEfektifSatis() {
		HashMap<String, Object> iMap =  getValidEfektifSatisServisMap(); 
		GMResourceFactory.getInstance().service("BNSPR_TRN2015_SAVE_EFEKTIF_SATIS", iMap);
		 assertTrue(true);
	}
	
	public void testCanGetReferansNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2015_GET_REFERANS_NO", new HashMap<String, Object>());
		String referansNo = (String)oMap.get("REFERANS_NO");
		System.out.println("REFERANS_NO: " + referansNo);
		assertNotNull(referansNo);
	}
	
	public void testCanGetEfektifSatisKuru(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "USD");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2015_GET_EFEKTIF_SATIS_KURU", iMap);
		BigDecimal kur = (BigDecimal)oMap.get("KUR");
		System.out.println("KUR: " + kur);
		assertNotNull(kur);
	}
	
	public void testCannotGetEfektifSatisKuruWithInvalidDovizKod(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "KZT");
		try{
			GMResourceFactory.getInstance().service("BNSPR_TRN2015_GET_EFEKTIF_SATIS_KURU", iMap);
			fail("Sho�ld rise an SQL exception");
		}
		catch(Exception ex){
			assertTrue(true);
			ex.printStackTrace();
		}
	}
	
	public void testCanGetRezervasyonAcikmi(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2015_GET_REZERVASYON_ACIKMI", new HashMap<String, Object>());
		String rezervasyonAcikmi = (String)oMap.get("REZERVASYON_ACIKMI");
		System.out.println("REZERVASYON_ACIKMI: " + rezervasyonAcikmi);
		assertNotNull(rezervasyonAcikmi);
		assertTrue(rezervasyonAcikmi.equals("H") || rezervasyonAcikmi.equals("E"));
	}
	
	public void testCanGetKMV(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2015_GET_KMV", new HashMap<String, Object>());
		BigDecimal kmv = (BigDecimal)oMap.get("KMV");
		System.out.println("KMV: " + kmv);
		assertNotNull(kmv);
	}
}

