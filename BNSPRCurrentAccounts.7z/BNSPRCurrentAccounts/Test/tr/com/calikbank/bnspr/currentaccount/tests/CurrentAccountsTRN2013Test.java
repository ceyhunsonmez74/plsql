package tr.com.calikbank.bnspr.currentaccount.tests;

import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsTRN2013Test extends TestCase {
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", getTransactionNo());
		iMap.put("SATIS_SEKLI", 2);
		iMap.put("ACIKLAMA", "aciklama");
		iMap.put("DOVIZ_KODU", "EUR");
		iMap.put("DOVIZ_TUTARI", 23);
		iMap.put("DTH_MUSTERI_HESAP_NO", 110);
		iMap.put("DTH_MUSTERI_NO", 1);
		iMap.put("ISTATISTIK_KODU", "8443");	
		iMap.put("KUR", 1.71);
		iMap.put("MUSTERI_HESAP_NO", 104);	
		iMap.put("MUSTERI_NO", 1);
		iMap.put("REZERVASYON_NO", 23);
		iMap.put("TAHSIL_ADILEN_TOPLAM_TUTAR", 2.66);
		return iMap;
	}
	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	public void testMuhHesapNoNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("MUSTERI_HESAP_NO", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2013_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testdovizKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DOVIZ_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2013_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testKurNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("KUR", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2013_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testDthMusteriHesapNoNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DTH_MUSTERI_HESAP_NO", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2013_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testIstatistikKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISTATISTIK_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2013_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
	public void testAciklamaNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ACIKLAMA", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2013_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testCanGetCorrectKurValue(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "EUR");
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2013_GET_KUR_INFO", iMap);
		assertEquals("",new Double(1.78),(Double.parseDouble(oMap.get("KUR").toString())) ,new Double(0.01));
		
	}
	public void testKurTip(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "EUR");
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2013_GET_KUR_INFO", iMap);
		assertTrue(oMap.get("KUR") instanceof String);
	}
	public void testDovizUlkeKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2013_GET_GLOBAL_DOVIZ_KODU", iMap);
		assertEquals("USD", oMap.get("DOVIZ_KODU"));
	}
	public void testDIDovizUlkeKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "TR");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2013_GET_GLOBAL_DOVIZ_KODU", iMap);
		assertEquals("Amerikan Dolar�", oMap.get("DOVIZ_ACIKLAMA"));
	}
	
	public void testIstatistikKoduAciklamaNotNull(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("ISTATISTIK_KODU", "8443");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2013_GET_ISTATISTIK_KODU_ACIKLAMA", iMap);
		
		assertNotNull(oMap.get("ISTATISTIK_KODU_ACIKLAMA"));
	}
	
}
