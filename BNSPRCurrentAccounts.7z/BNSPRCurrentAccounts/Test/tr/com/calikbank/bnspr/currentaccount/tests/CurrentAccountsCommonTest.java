package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;
import com.graymound.util.GMMap;

public class CurrentAccountsCommonTest extends TestCase {
	public void testCanGetLCKod(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_LC_KOD", new HashMap<String, Object>());
		System.out.println("LC KOD: " + oMap.get("LC_KOD") );
		assertNotNull(oMap.get("LC_KOD"));
	}
	
	public void testCanGetKullaniciKod(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_KULLANICI_KOD", new HashMap<String, Object>());
		System.out.println("KULLANICI KOD " + oMap.get("KULLANICI_KOD") );
		assertNotNull(oMap.get("KULLANICI_KOD"));
	}
	
	public void testCanGetSubeKodAd(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_SUBE_KOD", new HashMap<String, Object>());
		System.out.println("SUBE_KOD " + oMap.get("SUBE_KOD") );
		assertNotNull(oMap.get("SUBE_KOD"));
		assertNotNull(oMap.get("SUBE_ADI"));
	}

	public void testCanGetSubemiGMmi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("SUBE_KODU", GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_SUBE_KOD", new HashMap<String, Object>()).get("SUBE_KOD"));
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_SUBE_VEYA_GM", iMap);
		System.out.println("SUBE_GM " + oMap.get("SUBE_GM") );
		assertNotNull(oMap.get("SUBE_GM"));
	}
	
	public void testCanGetBankaTarih(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_BANKA_TARIH", new HashMap<String, Object>());
		System.out.println("BANKA_TARIH: " + oMap.get("BANKA_TARIH") );
		assertNotNull(oMap.get("BANKA_TARIH"));
	}
	
	public void testCanGetKur(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("ISLEM_SEKLI", "M");
		iMap.put("ALIS_SATIS", "S");
		iMap.put("DOVIZ_KODU", "USD");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_KUR", iMap);
		System.out.println("KUR: " + oMap.get("KUR") );
		assertNotNull(oMap.get("KUR"));
	}
	
	public void testCanCallDovizCevir(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ1", "EUR");
		iMap.put("DOVIZ2", "USD");
		iMap.put("TARIH", null);
		iMap.put("TUTAR", new BigDecimal(100));
		iMap.put("KUR_TIP", new BigDecimal(3));
		iMap.put("KUR_DEGER1", null);
		iMap.put("KUR_DEGER2", null);
		iMap.put("KUR_TABLO", "O");
		iMap.put("ALIS_SATIS", "A");

		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_DOVIZ_CEVIR", iMap);
		assertNotNull(oMap.get("KARSILIK"));
		System.out.println("KARSILIK: " + oMap.get("KARSILIK") );
	}
	
	public void testCanGetLocalCountry(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_LOCAL_COUNTRY", iMap);
		assertNotNull(oMap.get("ULKE_KODU"));
		System.out.println("ULKE_KODU: " + oMap.get("ULKE_KODU") );
		assertNotNull(oMap.get("ULKE_ADI"));
		System.out.println("ULKE_ADI: " + oMap.get("ULKE_ADI") );
	}
	
	public void testGetLov(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("LOV_NAME", "3161/LOV_BANKA");
		iMap.put("KEY", "1%");
		ArrayList<String> inputParameters = new ArrayList<String>();
		iMap.put("INPUT_PARAMETERS", inputParameters);
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_DAL_GET_LOV", iMap);
		List<?> resList = (List<?>)oMap.get("RESULT");
		assertNotNull(resList);
		System.out.println(resList.size());
	}
	
	public void testVknCheckDigit(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("VERGI_NO", "1000086245");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_VKN_CHECK_DIGIT", iMap);
		assertEquals(oMap.get("SONUC"), "1");
		System.out.println("SONUC " + oMap.get("SONUC") );
		
		iMap.put("VERGI_NO", "11111441541");
		oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_VKN_CHECK_DIGIT", iMap);
		assertEquals(oMap.get("SONUC"), "0");
		System.out.println("SONUC " + oMap.get("SONUC") );
	}
	
	public void testTcknCheckDigit(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TC_KIMLIK_NO", new BigDecimal(24086025108L));
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_TCKN_CHECK_DIGIT", iMap);
		assertNotNull(oMap.get("SONUC").equals("1"));
		System.out.println("SONUC " + oMap.get("SONUC") );
		
		iMap.put("TC_KIMLIK_NO", new BigDecimal(1111111));
		oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_TCKN_CHECK_DIGIT", iMap);
		assertNotNull(oMap.get("SONUC").equals("0"));
		System.out.println("SONUC " + oMap.get("SONUC") );
	}
	public void testCanGetComboBoxValue(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("KOD", "KRD_MUSTERI_TIP_KOD");
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_FILL_COMBOBOX", iMap);
		List<?> comboList = (List<?>)oMap.get("RESULTS");
		assertNotNull(comboList);
		System.out.println(comboList.get(1));
	}
	
	public void testGetMedeniHalKod(){
		
		GMMap iMap = new GMMap();
		iMap.put("MEDENI_HAL", "Evli");
		System.out.println(GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_MEDENI_HAL_KOD", iMap));
	}
	
	public void testGetCinsiyetKod(){
		
		GMMap iMap = new GMMap();
		iMap.put("CINSIYET", "Kad�n");
		System.out.println(GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_CINSIYET_KOD", iMap));
	}
	public void testStringControl(){
		
		GMMap iMap = new GMMap();
		iMap.put("VALUE", "EMIRCAN");
		iMap.put("NAME", "Cinsiyet");
		System.out.println(GMResourceFactory.getInstance().service("BNSPR_COMMON_STRING_KONTROL", iMap));
	}
	public void testSendMail(){
		GMMap iMap = new GMMap();
		iMap.put("MAIL_FROM", "serkan.ilbeyi@obss.com.tr");
		iMap.put("MAIL_TO", "serkan.ilbeyi@obss.com.tr;kenan.aydin@obss.com.tr;bilal.gul@aktifbank.com.tr");
		iMap.put("MAIL_SUBJECT", "Mail G�nderme");
		iMap.put("IS_BODY_HTML", "H");
	    iMap.put("MAIL_BODY", "CommonServices alt�nda BNSPR_COMMON_SEND_MAIL olu�turulan servis ismi BNSPR_COMMON_SEND_ASYNCHRONOUS_MAIL olarak de�i�tirildi");
	    GMResourceFactory.getInstance().service("BNSPR_COMMON_SEND_ASYNCHRONOUS_MAIL", iMap);
	}
}
