package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class CurrentAccountsTRN2021Test extends TestCase{
	private HashMap<String, Object> iMap;
	public void setUp() {
		iMap = new HashMap<String, Object>();
		iMap.put("P_KASA_SORGULA", "H");
		iMap.put("P_ANA_KASA", "E");
		iMap.put("TRX_NO", "999999");
		iMap.put("P_BOLUM_KODU", "200");
		iMap.put("P_KASA_KULLANICI_KODU", "BNSPR");
		iMap.put("P_ISLEM_NO", null);
	}
	
	public void testCanGetKasaKodWithAnaKasa(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2021_GET_KASA_KODU", iMap);
		String kasaKodu = (String)oMap.get("KASA_KODU");
		System.out.println("Kasa Kodu: " + kasaKodu );
		assertEquals("01000000", kasaKodu);
	}
	
	public void testCanGetKasaKodWithoutAnaKasa(){
		iMap.put("P_ANA_KASA", "H");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2021_GET_KASA_KODU", iMap);
		String kasaKodu = (String)oMap.get("KASA_KODU");
		System.out.println("Kasa Kodu: " + kasaKodu );
		assertEquals("01000001", kasaKodu);
		BigDecimal kasaTanimNo = (BigDecimal)oMap.get("P_KASA_TANIM_NO");
		System.out.println("Kasa tan�m no " + kasaTanimNo );
		assertEquals(new BigDecimal(30), kasaTanimNo);
	}
	
	public void testCanCallIslemeAt(){
		iMap = new HashMap<String, Object>();
		iMap.put("P_ISLEM_NO", new BigDecimal(9999998));
		iMap.put("KASA_KODU", "01000001");
		iMap.put("P_BOLUM_KODU", "200");
		iMap.put("P_KASA_KULLANICI_KODU", "BNSPR");
		iMap.put("P_KASA_TANIM_NO", new BigDecimal(1));
		iMap.put("P_ISLEM_KOD", "2015");
		iMap.put("P_KASA_TUTAR1", new BigDecimal(1000));
		iMap.put("P_KASA_DOVIZ1", "TRY");
		iMap.put("P_KASA_ISLEM1", "C");
		iMap.put("P_KASA_TUTAR2", new BigDecimal(2000));
		iMap.put("P_KASA_DOVIZ2", "USD");
		iMap.put("P_KASA_ISLEM2", "Y");
		iMap.put("P_KASA_SIL", "H");
		GMResourceFactory.getInstance().service("BNSPR_TRN2021_GET_KUPUR_KAYIT", iMap);
		assertTrue(true);
	}
}
