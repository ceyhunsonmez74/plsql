package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class CurrentAccountsTRN2010Test extends TestCase {
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", 22);
		iMap.put("TALIMAT_FORMU", "H");
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("BORC_HESAP_NO", 110);
		iMap.put("TUTAR", 20);
		iMap.put("ALACAK_HESAP_NO", 95);	
		iMap.put("ACIKLAMA","xyz");
		iMap.put("DEKONT_BASIM_F", "X");	
		return iMap;
	}
	public void testAciklamaNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ACIKLAMA", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2010_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testDovizKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DOVIZ_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2010_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAlacakHesapNoNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("TALIMAT_FORMU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2010_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testTalimatFormuNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISTATISTIK_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2010_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testTutarNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("TUTAR", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2010_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testBorcHesapNoNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("BORC_HESAP_NO", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2010_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testGetBorcBakiyeValue(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("HESAP_NO", 110);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2010_GET_BORC_BALANCE_INFO", iMap);
		assertEquals(new BigDecimal(11508), oMap.get("BAKIYE"));
	}
	public void testGetKullanilabilirBakiyeValue(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("HESAP_NO", 110);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2010_GET_BORC_BALANCE_INFO", iMap);
		assertEquals(new BigDecimal(11408),(oMap.get("KULLANILABILIR_BAKIYE")));
	}
	public void testGetAlacakBakiyeValue(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("HESAP_NO", 110);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2010_GET_ALACAK_BALANCE_INFO", iMap);
		assertEquals(new BigDecimal(11508), oMap.get("BAKIYE"));
	}
	
	public void testGetLocalDovizKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2010_GET_LOCAL_DOVIZ_KODU", iMap);
		assertEquals("TRY",oMap.get("DOVIZ_KODU"));
	}
	public void testGetLocalDovizKoduType(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2010_GET_LOCAL_DOVIZ_KODU", iMap);
		assertTrue(oMap.get("DOVIZ_KODU") instanceof String);
	}
	public void testGetDIDovizKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "TRY");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2010_GET_DI_DOVIZ_KODU", iMap);
		assertEquals("Yeni T�rk Liras�",oMap.get("DI_DOVIZ_KODU"));
	}
	public void testGetDIDovizKoduType(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "TRY");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2010_GET_DI_DOVIZ_KODU", iMap);
		assertTrue(oMap.get("DI_DOVIZ_KODU") instanceof String);
	}
	
}
