package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsQRY2039Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("ISLEM_TIPI", "I");
		iMap.put("SUBE_KODU", 200);
		iMap.put("MUSTERI_NO", null);
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("DURUM_KODU", "T");
		iMap.put("ISTATISTIK_KODU", null);
	
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("BAS_TARIH",(Date)dateFormat.parse("11-11-2005"));
			iMap.put("SON_TARIH", (Date)dateFormat.parse("11-11-2008"));
		}catch (Exception e) {
		}
		return iMap;
	}
	public void testCanGetCorrectDABList(){
		HashMap<String, Object> iMap = setUpIMap();
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2039_GET_DSB_INFO", iMap);
		List<?> list = (List<?>)oMap.get("CBS_DSB_ISLEM");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("200",rowData.get("SUBE_KODU")); 
			assertEquals("G�L�N  ERDAL", rowData.get("MUSTERI_ADI"));
			assertEquals("5445", rowData.get("ISTATISTIK_KODU"));
			assertEquals("USD", rowData.get("DOVIZ_KODU"));
			assertEquals("100", rowData.get("TUTAR"));
			assertEquals("A", rowData.get("DURUM"));
		}
	}
	public void testTutar(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DSB_NO", "DSB.07.200.I.00005");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2039_GET_DSB_DETAY", iMap);
		assertEquals(new BigDecimal(100), oMap.get("TUTAR"));
	}
	public void testKur(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DSB_NO", "DSB.07.200.I.00005");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2039_GET_DSB_DETAY", iMap);
		assertEquals(new Double(1.33),Double.parseDouble(oMap.get("KUR").toString()));
	}
	public void testUSDKarsiligi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DSB_NO", "DSB.07.200.I.00005");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2039_GET_DSB_DETAY", iMap);
		assertEquals(new Double(133),Double.parseDouble(oMap.get("USD_KARSILIK").toString()));
	}
	public void testSubeKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DSB_NO", "DSB.07.200.I.00005");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2039_GET_DSB_DETAY", iMap);
		assertEquals("200",oMap.get("SUBE_KODU"));
	}
	public void testIstatistikKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DSB_NO", "DSB.07.200.I.00005");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2039_GET_DSB_DETAY", iMap);
		assertEquals("5445",oMap.get("ISTATISTIK_KODU"));
	}
	public void testUyruk(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DSB_NO", "DSB.07.200.I.00005");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2039_GET_DSB_DETAY", iMap);
		assertEquals("AT",oMap.get("UYRUK"));
	}
	public void testSemt(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DSB_NO", "DSB.07.200.I.00005");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2039_GET_DSB_DETAY", iMap);
		assertEquals("G",oMap.get("SEMT"));
	}
	public void testAdres(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DSB_NO", "DSB.07.200.I.00005");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2039_GET_DSB_DETAY", iMap);
		assertEquals("Y",oMap.get("ADRES"));
	}
}
