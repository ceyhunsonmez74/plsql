package tr.com.calikbank.bnspr.currentaccount.tests;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsQRY2034QTest extends TestCase{
	
	public void testCanGetCorrectValue(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("MUSTERI_NO", 1);
		iMap.put("HESAP_NO", 69001);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2034Q_GET_CUSTOMER_DETAIL_INFO", iMap);
		assertEquals("TRY", oMap.get("DOVIZ_KODU"));
		assertEquals("01000000", oMap.get("MUSTERI_DK_NO"));
		assertEquals("1014", oMap.get("DK_GRUP_KOD"));
		assertEquals("VADESIZ", oMap.get("MODUL_TUR_KOD"));
		assertEquals("MUSTAK-TP", oMap.get("URUN_TUR_KOD"));
		assertEquals("SERBEST-V.SIZ", oMap.get("URUN_SINIF_KOD"));
		assertEquals("-890", oMap.get("BAKIYE"));
		assertEquals("A", oMap.get("DURUM_KODU"));
		//HESAP_BILGILERI
		assertEquals("200", oMap.get("SUBE_KODU"));
		assertEquals("2007-10-22", oMap.get("ACILIS_TARIHI").toString());
		assertEquals("HESAP ACIKLAMA", oMap.get("ACIKLAMA"));
		assertEquals("E", oMap.get("CEK_KARNESI"));
		assertEquals("123", oMap.get("MKK_SICIL_NO"));
		assertEquals("1", oMap.get("HESAP_HAREKET_KODU"));
		assertEquals("P", oMap.get("EKSTRE_BASIM_KODU"));
		assertEquals("2", oMap.get("EKSTRE_SIKLIGI"));
		assertEquals("E", oMap.get("DEKONT"));
		assertEquals("1", oMap.get("MIN_IMZA_ADEDI"));
		//fA�Z B�LG�LER�
		assertEquals("360", oMap.get("ESAS_GUN_SAYISI"));
		assertEquals("55", oMap.get("FAIZ_ORANI"));
		//System.out.println("ARA ODEME : " + oMap.get("ARA_ODEME_ISLEM_BILGISI"));
		//assertEquals("1", oMap.get("ARA_ODEME_ISLEM_BILGISI"));
		//bak�lacak
		assertEquals("4", oMap.get("BAKIYE_TURU"));
		assertEquals("109", oMap.get("BIRIKMIS_FAIZ_POZ"));
		
		List<?> list = (List<?>) oMap.get("CBS_HESAP_ORTAK_BILGI");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?, ?> rowData = (HashMap<?, ?>)iter.next();
			assertEquals("3", rowData.get("ORTAK_MUSTERI_NO"));
			assertEquals("RABIA  GEDIK", rowData.get("ORTAK_ADI_SOYADI"));
			assertEquals("OY", rowData.get("ORTAKLIK_TIPI"));
		}				
	}
	
	public void testCanGetCorrectValueOrtalamaBakiye(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("HESAP_NO", 1);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2034Q_GET_CUSTOMER_AVARAGE_ACCOUNT_BALANCE", iMap);
		
		List<?> list = (List<?>) oMap.get("ORTALAMA_HESAP_BAKIYESI");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?, ?> rowData = (HashMap<?, ?>)iter.next();
			assertEquals("2007", rowData.get("YIL"));
			assertEquals("4", rowData.get("AY"));
			assertEquals("69001", rowData.get("HESAP_NUMARA"));
			assertEquals("100000", rowData.get("ORTALAMA_BAKIYE"));		
		}
	}
}
