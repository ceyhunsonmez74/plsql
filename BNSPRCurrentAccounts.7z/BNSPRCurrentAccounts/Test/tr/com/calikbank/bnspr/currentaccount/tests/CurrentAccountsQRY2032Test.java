package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsQRY2032Test extends TestCase {
	public HashMap<String, Object> setUpCustomerInfoIMap() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("MUSTERI_NO", new BigDecimal(1));
		iMap.put("HESAP_NO", new BigDecimal(104));
		iMap.put("DOVIZ_KODU", "TRY");
		return iMap;
	}
	public HashMap<String, Object> setUpCusDetailInfoIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("BAS_TARIH", (Date)dateFormat.parse("11-11-2005"));
			iMap.put("SON_TARIH", (Date)dateFormat.parse("11-11-2008"));
		}catch (Exception e) {}
		iMap.put("MIN_DV_TUTAR", 0);
		iMap.put("MAX_DV_TUTAR", 100000);
		iMap.put("HAREKET_TIPI", "G");
		iMap.put("BORC_ALACAK", "X");
		iMap.put("MUSTERI_NO", new BigDecimal(1));
		iMap.put("HESAP_NO", new BigDecimal(104));
		
		return iMap;
	}

	public void testCanGetCorrectCustomerInfo() {
		HashMap<String, Object> iMap = setUpCustomerInfoIMap();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_QRY2032_GET_CUSTOMER_INFO", iMap);
	
			assertEquals("Ersin  LALBEK", oMap.get("ISIM_UNVAN"));
			assertEquals("200", oMap.get("SUBE_KODU"));
			assertEquals("39099100", oMap.get("MUSTERI_DK_NO"));
			assertEquals("A", oMap.get("DURUM_KODU"));
			assertEquals("MUSTAK-TP", oMap.get("URUN_TUR_KOD"));
			assertEquals("SABIT FAIZ", oMap.get("URUN_SINIF_KOD"));
			assertEquals("10", oMap.get("BAKIYE"));
			assertEquals("0", oMap.get("BLOKE_TUTARI"));
			
	}
	public void testCanGetCustomerDetailInfo() {
		HashMap<String, Object> iMap = setUpCusDetailInfoIMap();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_QRY2032_GET_CUSTOMER_DETAIL_INFO", iMap);

		List<?> list = (List<?>) oMap.get("MUSTERI_DETAY");
		Iterator<?> iter = list.iterator();
		
		Calendar cal =Calendar.getInstance();
		cal.set(2007, 10, 17);
		if (iter.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>)iter.next();
			assertEquals("61", rowData.get("FIS_FIS_NO"));
			assertEquals("200", rowData.get("BOLUM_KODU"));
			assertEquals("16", rowData.get("SATIR_DV_TUTAR_DI"));
			assertEquals(null, rowData.get("SON_BAKIYE_DI"));
			assertEquals("TL KARSILIGI DOVIZ ALIS", rowData.get("SATIR_MUSTERI_ACIKLAMA"));	
			assertEquals("281", rowData.get("FIS_NUMARA"));
		}
		assertEquals(16, oMap.get("TOPLAM"));
	}
	
	public void testCanGetCorrectFonTutarBakiye(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("HESAP_NO", 2);
		
		/*Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_IZL2032_GET_FONTUTAR_BAKIYE", iMap);
		assertEquals(null, oMap.get("OTM_SATILABILIR_FON_TUTARI"));
		assertEquals(null, oMap.get("KULLANILABILIR_BAKIYE"));
		assertEquals(null, oMap.get("DEVIR_BAKIYE"));*/
		//ORA-01403: hi� veri bulunmad�
		//ORA-06512: konum "BNSPR.PKG_HESAP",  sat�r 312 
		//ORA-06512: konum  sat�r 1
		//sonra bak
	}
}
