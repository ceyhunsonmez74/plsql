package tr.com.calikbank.bnspr.currentaccount.tests;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsQRY2031Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("MUSTERI_NO", null);
		iMap.put("DK_GROUP", null);
		iMap.put("MODUL_TUR_KOD", "X");
		iMap.put("URUN_TURU", null);
		iMap.put("URUN_SINIFI", null);
		iMap.put("START_AMOUNT", null);
		iMap.put("END_AMOUNT", null);
		iMap.put("ORTAK_HESAP", "E");	
		iMap.put("DURUM_KODU", "A");
		iMap.put("SUBE_KODU", null);
		iMap.put("DOVIZ_KODU", null);
		iMap.put("ZAMAN_KRITERI","1");
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("BASLANGIC_TARIHI",(Date)dateFormat.parse("11-11-2005"));
			iMap.put("BITIS_TARIHI", (Date)dateFormat.parse("11-11-2008"));
		}catch (Exception e) {
		}

		return iMap;
	}
	public void testCanGetCorrectValueHesapList(){
		HashMap<String, Object> iMap = setUpIMap();
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2031_GET_ACCOUNT_LIST", iMap);
		List<?> list = (List<?>)oMap.get("HESAP_LISTESI");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("200",rowData.get("SUBE")); 
			assertEquals("1", rowData.get("MUSTERI_NO"));
			assertEquals("Ersin  LALBEK", rowData.get("ISIM_UNVAN"));
			assertEquals("deneme", rowData.get("KISA_ISIM_DI"));
			assertEquals("69", rowData.get("HESAP_NO"));
			assertEquals("TRY", rowData.get("DOVIZ_KODU"));
			assertEquals("0", rowData.get("BAKIYE_DI"));
			assertEquals("A", rowData.get("DURUM"));
			assertEquals("AVANS", rowData.get("URUN_TUR_KOD"));
			assertEquals("TP", rowData.get("URUN_SINIF_KOD"));
		}
	}
	
	public void testCanGetCorrectValueBalanceList(){
		HashMap<String, Object> iMap = setUpIMap();
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2031_GET_BALANCE_LIST", iMap);
		List<?> list = (List<?>)oMap.get("TOPLAM_BAKIYE");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("0",rowData.get("BAKIYE_TOPLAMI_DI")); 
			assertEquals("EUR", rowData.get("DOVIZ_KODU"));
			assertEquals("VADELI", rowData.get("MODUL_TUR_KOD"));
		}
	}
}
