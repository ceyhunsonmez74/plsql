package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsTRN2023Test extends TestCase{
	public void testCanCallBekleyenIslemVarmi() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("SUBE_KOD", GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_SUBE_KOD", new HashMap<String, Object>()).get("SUBE_KOD"));
		iMap.put("KULLANICI_KOD", GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_KULLANICI_KOD", new HashMap<String, Object>()).get("KULLANICI_KOD"));		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2022_GET_KASA_KOD_TANIM_NO", iMap);
		iMap.put("KASA_KOD", oMap.get("KASA_KOD"));
		iMap.put("TRX_NO", new BigDecimal((new Random()).nextInt(20000) + 20000));
		GMResourceFactory.getInstance().service("BNSPR_TRN2023_CALL_BEKLEYEN_ISLEM_VARMI", iMap);

		assertTrue(true);
	}
	
	public void testCanCallKasaIslemeAt() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("ISLEM_NO", new BigDecimal(new Random().nextInt(20000) + 20000));
		iMap.put("SUBE_KOD", GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_SUBE_KOD", new HashMap<String, Object>()).get("SUBE_KOD"));
		iMap.put("KULLANICI_KOD", GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_KULLANICI_KOD", new HashMap<String, Object>()).get("KULLANICI_KOD"));
		Map<?, ?> oMap1 =  GMResourceFactory.getInstance().service("BNSPR_TRN2022_GET_KASA_KOD_TANIM_NO", iMap);
		iMap.put("KASA_KODU", oMap1.get("KASA_KOD"));
		iMap.put("TANIM_NO", new BigDecimal(1));
	    GMResourceFactory.getInstance().service("BNSPR_TRN2023_CALL_KASA_ISLEME_AT", iMap);

		assertTrue(true);
	}
}
