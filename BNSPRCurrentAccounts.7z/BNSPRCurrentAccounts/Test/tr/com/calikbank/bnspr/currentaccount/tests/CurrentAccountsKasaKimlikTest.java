package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class CurrentAccountsKasaKimlikTest extends TestCase {
	public void testCanGetKasaKimlikKayitSayisi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(98985457));
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_KASA_KIMLIK_GET_KASA_KIMLIK_SAYISI", iMap);
		BigDecimal kasaKimlikSayisi = (BigDecimal)oMap.get("KASA_KIMLIK_SAYISI");
		System.out.println(kasaKimlikSayisi);
		assertNotNull(kasaKimlikSayisi);
	}
	
	public void testCanGetKontrolTutar(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(98985457));
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_GET_KASA_KIMLIK_KONTROL_TUTAR", iMap);
		BigDecimal tutar1 = (BigDecimal)oMap.get("KONTROL_TUTAR1");
		BigDecimal tutar2 = (BigDecimal)oMap.get("KONTROL_TUTAR2");
		assertNotNull(tutar1);
		System.out.println("Tutar1: " + tutar1);
		assertNotNull(tutar2);
		System.out.println("Tutar2: " + tutar2);
	}
}
