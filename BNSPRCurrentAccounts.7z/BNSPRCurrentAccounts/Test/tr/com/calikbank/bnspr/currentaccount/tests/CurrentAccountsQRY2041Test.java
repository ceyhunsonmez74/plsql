package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class CurrentAccountsQRY2041Test extends TestCase {
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("HESAP_NO", 110);
        iMap.put("MUSTERI_NO", 1);
        iMap.put("SUBE_KODU", 200);
        iMap.put("BLOKE_NEDEN_KOD", 1);
        iMap.put("DOVIZ_KODU", "USD");
        iMap.put("DURUM_KODU", "K");
        iMap.put("K_BLOKE_COZME_TARIHI_1", null);
        iMap.put("K_BLOKE_COZME_TARIHI_2", null);
        iMap.put("BLOKE_TARIHI_1", null);
        iMap.put("BLOKE_TARIHI_2", null);
        iMap.put("TUTAR_1", "0.00");
        iMap.put("TUTAR_2", "0.00");
	
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("BAS_TARIH",(Date)dateFormat.parse("11-11-2005"));
			iMap.put("SON_TARIH", (Date)dateFormat.parse("11-11-2008"));
		}catch (Exception e) {
		}
		return iMap;
	}
	public void testCanGetCorrectBlokeList(){
		HashMap<String, Object> iMap = setUpIMap();
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2041_GET_BLOKE_HAREKET1", iMap);
		List<?> list = (List<?>)oMap.get("CBS_VW_BLOKE_IZLEME");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("110",rowData.get("HESAP_NO")); 
			assertEquals("1", rowData.get("MUSTERI_NO"));
			assertEquals("Ersin  LALBEK", rowData.get("UNVAN"));
			assertEquals("07.200.BLK.00006", rowData.get("BLOKE_REFERANS"));
			assertEquals("USD", rowData.get("DOVIZ_KODU"));
			assertEquals("K", rowData.get("DURUM_KODU"));
			assertEquals("1", rowData.get("BLOKE_TUTARI_DI"));
			assertEquals(new BigDecimal(21248), rowData.get("BAKIYE_DI"));
			assertEquals(new BigDecimal(0), rowData.get("TOPLAM_BLOKE_DI"));
			assertEquals("2007-10-17", rowData.get("BLOKE_TARIHI").toString());
			assertEquals("2007-11-05", rowData.get("BLOKE_BITIS_TARIHI").toString());
			assertEquals("Hay�r", rowData.get("ORTAK_HESAP_F"));
			assertEquals("1", rowData.get("BLOKE_NEDEN_KODU"));
			assertEquals("Mevduat Haczi", rowData.get("BLOKE_NEDEN_ACIKLAMASI"));
		}
	}

}
