package tr.com.calikbank.bnspr.currentaccount.tests;

import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsTRN2014Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", GetTransactionNo());
		iMap.put("REFERANS_NO", GetReferansNo());
		iMap.put("ALIS_SEKLI", 1);
		iMap.put("ALIS_TUTARI",20);
		iMap.put("MUSTERI_NO", 2);
		iMap.put("HESAP_NO", null);
		iMap.put("DOVIZI_SATAN", "osman");
		iMap.put("DOVIZ_ULKE_KODU", "USD");
		iMap.put("UYRUK", "TC");	
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("KUR", 2);
		iMap.put("ODENEN_LC_TUTAR", 4);
		iMap.put("VERGI_MUKELLEFI_MI", "E");
		iMap.put("VERGI_DAIRESI", "Alrunizade");
		iMap.put("VERGI_NO", "2231234");
		iMap.put("ISTATISTIK_KODU", "RTL");
		iMap.put("ACIKLAMA", "Kaydet");
		
		return iMap;
	}
	public String GetTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	public String GetReferansNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2014_GET_REFERANCE_NO", new HashMap<String, Object>());
		return (String)oMap.get("REFERANS_NO");
	}
	public void testCanSaveEfektifAlis() {
		HashMap<String, Object> iMap =  setUpIMap();
		GMResourceFactory.getInstance().service("BNSPR_TRN2014_SAVE", iMap);
		assertTrue(true);
	}
	public void testCanGetReferanceNo() {	
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2014_GET_REFERANCE_NO",new HashMap<String, Object>());
		assertNotNull(oMap.get("REFERANS_NO"));
	}
	
	
	public void testHesapNoNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ALIS_SEKLI", 2);
		iMap.put("HESAP_NO", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2014_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAlisSekliNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ALIS_SEKLI", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2014_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
	public void testVergiDairesiNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ALIS_SEKLI", 1);
		iMap.put("VERGI_MUKELLEFI_MI", "E");
		iMap.put("VERGI_DAIRESI", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2014_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testDoviziSatanNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DOVIZI_SATAN", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2014_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testUyrukNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("UYRUK", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2014_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testDovizKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DOVIZ_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2014_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
	public void testIstatistikKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISTATISTIK_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2014_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testKurNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("KUR", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2014_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAciklamaNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ACIKLAMA", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2014_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	/*
	public void testCanGetCorrectVergiDairesiAd(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("VERGI_DAIRE_KODU", 34170);
		iMap.put("VERGI_IL_KODU", 12);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2014_GET_VERGI_DAIRESI_NAME",iMap);
		assertEquals("Aksayaray",oMap.get("VERGI_DAIRESI"));
		
	}*/ //tablobos kontrol edilmio..sonra yine bak
	public void testCanGetEfektifAlisKuru(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "EUR");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2014_GET_KUR_INFO", iMap);
		assertEquals("1.78", oMap.get("KUR"));
	}
	public void testCanGetEfektifAlisKuruValue(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "EUR");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2014_GET_KUR_INFO", iMap);
		assertNotNull(oMap.get("KUR"));
	}
	
	public void testCanGetCorrectUyrukAdi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("UYRUK","TR");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2014_GET_UYRUK_ADI", iMap);
		assertNotNull(oMap.get("UYRUK_ADI"));
		assertEquals("T�RK�YE", oMap.get("UYRUK_ADI"));
	}
}

