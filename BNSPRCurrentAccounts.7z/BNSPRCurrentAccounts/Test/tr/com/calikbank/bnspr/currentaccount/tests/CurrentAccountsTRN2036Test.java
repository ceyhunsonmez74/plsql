package tr.com.calikbank.bnspr.currentaccount.tests;

import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsTRN2036Test extends TestCase {
	public HashMap<String, Object> setUpIMap() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("TRX_NO", getTransactionNo());

		iMap.put("IHRACAT_SEKLI", 2);
		iMap.put("ODEME_SEKLI", 2);
		iMap.put("TESLIM_SEKLI", "DEQ");
		iMap.put("CIKIS_KAPISI", 2);
		iMap.put("MAL_CINSI", "osman");
		iMap.put("IMALATCI", "hayri");
		iMap.put("GUMRUK_BEYANNAME_TARIHI", null);
		iMap.put("GUMRUK_NUMARASI", 1234);
		iMap.put("TESVIK_NO", 2344);
		iMap.put("TESVIK_BELGE_TARIHI", null);
		iMap.put("SUBE_KODU", 200);
		iMap.put("DURUM", "A");
		iMap.put("TARIH", null);
		iMap.put("MUSTERI_NO", 1);
		iMap.put("DOVIZI_SATAN", "ozman");
		iMap.put("UYRUK", "US");
		iMap.put("ISLEM_TIPI", "I");
		iMap.put("DOVIZ_EFEKTIF", "E");
		iMap.put("ISTATISTIK_KODU", 9064);
		iMap.put("GELIS_NEDENI", "");
		iMap.put("TUTAR", 12);
		iMap.put("USD_KARSILIK", 15);
		iMap.put("KUR", 1);
		iMap.put("TL_KARSILIK", 12);
		iMap.put("KESINTILER", "");
		iMap.put("KALAN_NET_TL", 32);
		iMap.put("ACIKLAMA", "blabla");
		iMap.put("VERGI_NO", "");
		iMap.put("DOVIZ_KODU", "EUR");
		iMap.put("DOVIZ_ULKE_KODU", "DO");

		return iMap;
	}

	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	public void testCanSaveDABGiris() {
		HashMap<String, Object> iMap =  setUpIMap();
		GMResourceFactory.getInstance().service("BNSPR_TRN2036_SAVE", iMap);
		assertTrue(true);
	}
	public void testUyrukNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("UYRUK", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2036_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
	public void testDovizKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DOVIZ_KODU", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2036_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testDovizUlkeKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DOVIZ_ULKE_KODU", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2036_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testTutarNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("TUTAR", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2036_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testUsdKarsilikNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("USD_KARSILIK", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2036_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testKurNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("KUR", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2036_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
	public void testCanGetKurInfo(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "EUR");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2036_GET_KUR_INFO", iMap);
		assertEquals("1.72", oMap.get("KUR").toString());
	}
	public void testCanGetUsdKarsilik(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "EUR");
		iMap.put("TUTAR", 10);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2036_GET_USD_KARSILIK", iMap);

		assertEquals("",new Double(13),(Double.parseDouble(oMap.get("USD_KARSILIK").toString())) ,new Double(0.1));	
	}
	public void testCanGetDIUyrukAdi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("UYRUK", "TR");
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2036_GET_UYRUK_ADI", iMap);

		assertEquals("T�RK�YE", oMap.get("UYRUK_ADI"));
	}
}
