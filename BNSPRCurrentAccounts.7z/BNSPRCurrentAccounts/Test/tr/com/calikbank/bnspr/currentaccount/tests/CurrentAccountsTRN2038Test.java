package tr.com.calikbank.bnspr.currentaccount.tests;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsTRN2038Test extends TestCase{
	public HashMap<String, Object> setUpIMap() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("TRX_NO", getTransactionNo());
		iMap.put("DAB_NO", "DAB.07.200.A.00024");
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("TARIH",(Date)dateFormat.parse("11-11-2007"));
		}catch (Exception e) {}
		iMap.put("SUBE_KODU", 200);
		
		return iMap;
	}

	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	
	public void testCanSaveDABIptal(){
		HashMap<String, Object> iMap =  setUpIMap();
		GMResourceFactory.getInstance().service("BNSPR_TRN2038_SAVE_DAB_IPTAL", iMap);
		assertTrue(true);
	}
}
