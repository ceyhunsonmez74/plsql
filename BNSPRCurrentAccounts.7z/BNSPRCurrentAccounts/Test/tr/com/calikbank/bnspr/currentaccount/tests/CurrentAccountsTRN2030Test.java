package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsTRN2030Test extends TestCase {
	public void testCanGetReferans(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2030_GET_REFERANS", new HashMap<String, Object>());
		String referans = (String)oMap.get("REFERANS");
		assertNotNull(referans);
		System.out.println("REFERANS: " + referans );
	}
	
	public void testCanGetMasrafDovizSonuc(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("MASRAF_DOVIZ", "TRY");
		iMap.put("ISLEM_DOVIZ", "USD");
		iMap.put("HESAPLANAN_MASRAF_TUTAR", new BigDecimal(100));
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2030_GET_MASRAF_DOVIZ_KARSILIGI", iMap);
		
		String sonuc = (String)oMap.get("MASRAF_DOVIZ_SONUC");
		assertNotNull(sonuc);
		System.out.println("MASRAF_DOVIZ_SONUC: " + sonuc );
	}
}
