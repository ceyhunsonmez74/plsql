package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountTRN2006Test extends TestCase{
	
	public HashMap<String, Object> setUpIMap(){
		
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", 4653);
		iMap.put("INTERNAL_REF_NO", 169);
		iMap.put("BLOKE_NEDEN_KODU","8");
		iMap.put("ACIKLAMA","save ediyorum");
		iMap.put("BLOKE_TUTARI",5.00);
		try {
			SimpleDateFormat dateFormat=new SimpleDateFormat("dd-MM-yyyy");
			iMap.put("BLOKE_BITIS_TARIHI",dateFormat.parse("07-11-2007"));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		return iMap;
	}
	public void testBlokeNedenKoduNotNull(){
		
		HashMap<String, Object> iMap = setUpIMap();
		
		iMap.put("BLOKE_NEDEN_KODU",null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2006_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(" HATA " + success.toString());
		}
	}
	public void testAciklamaNotNull(){
		
		HashMap<String, Object> iMap = setUpIMap();
		
		iMap.put("ACIKLAMA", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2006_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(" HATA " + success.toString());
		}
	}
	public void testblokeTutariNotNull(){
		
		HashMap<String, Object> iMap = setUpIMap();
		
		iMap.put("BLOKE_TUTARI", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2006_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(" HATA " + success.toString());
		}
	}
	public void testGetTutarServiceitsTrue(){
		HashMap<String, Object> iMap=new HashMap<String, Object>();
		iMap.put("HESAP_NO",110);
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_TRN2006_GET_TUTAR", iMap);		
		assertTrue(oMap.get("BAKIYE") instanceof BigDecimal);
		assertTrue(oMap.get("KUL_BAKIYE") instanceof BigDecimal);
		assertTrue(oMap.get("TOP_BLOKE") instanceof BigDecimal);
		assertTrue(oMap.get("GORUNSUN") instanceof BigDecimal);
		
	}
	public void testGetTutarServiceValueBakiye(){
		HashMap<String, Object> iMap=new HashMap<String, Object>();
		iMap.put("HESAP_NO",110);
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_TRN2006_GET_TUTAR", iMap);		
		assertEquals("",new Double(13076.00),(Double.parseDouble(oMap.get("BAKIYE").toString())) ,new Double(0.2));
	
	}
	public void testGetTutarServiceValueKulBakiye(){
		HashMap<String, Object> iMap=new HashMap<String, Object>();
		iMap.put("HESAP_NO",110);
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_TRN2006_GET_TUTAR", iMap);		
		assertEquals("",new Double(12976.00),(Double.parseDouble(oMap.get("KUL_BAKIYE").toString())) ,new Double(0.2));
	
	}
	public void testGetTutarServiceValueTopBloke(){
		HashMap<String, Object> iMap=new HashMap<String, Object>();
		iMap.put("HESAP_NO",110);
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_TRN2006_GET_TUTAR", iMap);		
		assertEquals("",new Double(100.00),(Double.parseDouble(oMap.get("TOP_BLOKE").toString())) ,new Double(0.2));
	
	}
	public void testGetTutarServiceValueGorunsun(){
		HashMap<String, Object> iMap=new HashMap<String, Object>();
		iMap.put("HESAP_NO",110);
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_TRN2006_GET_TUTAR", iMap);		
		assertEquals("1", oMap.get("GORUNSUN").toString());
	
	}
	
	public void testGetInfoServiceValueBlokeNedenKodu(){
		HashMap<String, Object> iMap=new HashMap<String, Object>();
		iMap.put("TRX_NO",4653);
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_TRN2006_GET_INFO", iMap);		
		assertEquals("8", oMap.get("BLOKE_NEDEN_KODU"));
	
	}
	
	public void testGetInfoServiceValueAciklama(){
		HashMap<String, Object> iMap=new HashMap<String, Object>();
		iMap.put("TRX_NO",4653);
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_TRN2006_GET_INFO", iMap);		
		assertEquals("aciklama", oMap.get("ACIKLAMA"));
	
	}
	public void testOMapInfoAssertEq(){
		HashMap<String, Object> iMap=new HashMap<String, Object>();
		iMap.put("TRX_NO","22997");
		
		Map<?,?> oMap=GMResourceFactory.getInstance().service("BNSPR_TRN2006_GET_INFO", iMap);		
		
		assertEquals(oMap.get("ACIKLAMA")				, "deneme");
		assertEquals(oMap.get("BLOKE_BITIS_TARIHI")		, null);
		assertEquals(oMap.get("REF_TX_NO")				, null);
		assertEquals(oMap.get("ISLEM_TANIM_KOD")		, new BigDecimal(2005));
		assertEquals(oMap.get("BLOKEYI_KOYAN")			, "BNSPR");
        assertEquals(oMap.get("MUSTERI_NO") 			, new BigDecimal(1000042));
        assertEquals(oMap.get("HESAP_NO") 				, new BigDecimal(589));
        assertEquals(oMap.get("DOVIZ_KODU") 			, "TRY");
        assertEquals(oMap.get("ESKI_BLOKE_REFERANS")    , "07.300.BLK.00012");
        assertEquals(oMap.get("BLOKE_NEDEN_KODU") 		, "4");
        assertEquals(oMap.get("DURUM_KODU")				, "A");
        assertEquals(oMap.get("INTERNAL_REF_NO")		, new BigDecimal(361));
        assertEquals(oMap.get("DI_ESKI_BLOKE_TUTARI")	, new BigDecimal(25));
        assertEquals(oMap.get("BLOKE_REFERANS")			, null);
        assertEquals(oMap.get("BLOKE_TUTARI") 			, null);
		
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy");
		try {
			assertEquals(oMap.get("BLOKE_TARIHI")			, dateFormat.parseObject("22.10.2007"));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
        
        
		
	}
	
}
