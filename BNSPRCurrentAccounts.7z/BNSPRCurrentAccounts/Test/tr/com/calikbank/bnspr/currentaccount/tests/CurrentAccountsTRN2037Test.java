package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsTRN2037Test extends TestCase{
	
	String dabNo = "DAB.07.200.A.00006";
	public void testCanGetSubeKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO",dabNo);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2037_GET_DAB_INFO", iMap);
		assertEquals("200", oMap.get("SUBE_KODU"));
	}
	public void testCanGetMusteriNo(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO",dabNo);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2037_GET_DAB_INFO", iMap);
		assertEquals(new BigDecimal(1), oMap.get("MUSTERI_NO"));
	}
	public void testCanGetDovizSatan(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO",dabNo);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2037_GET_DAB_INFO", iMap);
		assertEquals("ERSIN LALBEK", oMap.get("DOVIZI_SATAN"));
	}
	public void testCanGetUyrukKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO",dabNo);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2037_GET_DAB_INFO", iMap);
		assertEquals("US", oMap.get("UYRUK"));
	}
	public void testCanGetIslemTipi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO",dabNo);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2037_GET_DAB_INFO", iMap);
		assertEquals("A", oMap.get("ISLEM_TIPI"));
	}
	public void testCanGetDovizEfektif(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO",dabNo);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2037_GET_DAB_INFO", iMap);
		assertEquals("D", oMap.get("DOVIZ_EFEKTIF"));
	}
	public void testCanGetDovizKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO",dabNo);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2037_GET_DAB_INFO", iMap);
		assertEquals("USD", oMap.get("DOVIZ_KODU"));
	}
	public void testCanGetDovizGeldigiUlke(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO",dabNo);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2037_GET_DAB_INFO", iMap);
		assertEquals("US", oMap.get("DOVIZ_ULKE_KODU"));
	}
	public void testCanGetIstatistikKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO",dabNo);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2037_GET_DAB_INFO", iMap);
		assertEquals("4395", oMap.get("ISTATISTIK_KODU"));
	}
	public void testCanGetTutar(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO",dabNo);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2037_GET_DAB_INFO", iMap);
		assertEquals(new BigDecimal(1000), oMap.get("TUTAR"));
	}
	public void testCanGetKur(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO",dabNo);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2037_GET_DAB_INFO", iMap);
		
		assertEquals("",new Double(1.33),(Double.parseDouble(oMap.get("KUR").toString())) ,new Double(0.1));
	}
	public void testCanGetAciklama(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO",dabNo);;
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2037_GET_DAB_INFO", iMap);
		assertEquals("merhaba", oMap.get("ACIKLAMA"));
	}
	public void testCanGetVergiNo(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DAB_NO",dabNo);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2037_GET_DAB_INFO", iMap);
		assertEquals("5291277100", oMap.get("VERGI_NO"));
	}
	//diger fieldler bos oldugundan bakilmadi donen degerlere
	
	public HashMap<String, Object> setUpIMap() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("TRX_NO", getTransactionNo());		
		iMap.put("DAB_NO",dabNo);
		
		iMap.put("IHRACAT_SEKLI", 2);
		iMap.put("ODEME_SEKLI", 2);
		iMap.put("TESLIM_SEKLI", "DEQ");
		iMap.put("CIKIS_KAPISI", 2);
		iMap.put("MAL_CINSI", "osman");
		iMap.put("IMALATCI", "hayri");
		iMap.put("GUMRUK_BEYANNAME_TARIHI", null);
		iMap.put("GUMRUK_NUMARASI", 1234);
		iMap.put("TESVIK_NO", 2344);
		iMap.put("TESVIK_BELGE_TARIHI", null);
		iMap.put("SUBE_KODU", 200);
		iMap.put("DURUM_KODU", "A");
		iMap.put("TARIH", null);
		iMap.put("MUSTERI_NO", 1);
		iMap.put("DOVIZI_SATAN", "ozman");
		iMap.put("UYRUK", "US");
		iMap.put("ISLEM_TIPI", "D");
		iMap.put("DOVIZ_EFEKTIF", "E");
		iMap.put("ISTATISTIK_KODU", 9064);
		iMap.put("GELIS_NEDENI", "");
		iMap.put("TUTAR", 12);
		iMap.put("USD_KARSILIK", 15);
		iMap.put("KUR", 1);
		iMap.put("TL_KARSILIK", 12);
		iMap.put("KESINTILER", "");
		iMap.put("KALAN_NET_TL", 32);
		iMap.put("ACIKLAMA", "blabla");
		iMap.put("VERGI_NO", "");
		iMap.put("DOVIZ_KODU", "EUR");
		iMap.put("DOVIZ_ULKE_KODU", "DO");
		
		return iMap;
	}
	
	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	
	public void testCanSaveDABGuncelleme() {
		HashMap<String, Object> iMap =  setUpIMap();
		GMResourceFactory.getInstance().service("BNSPR_TRN2037_SAVE", iMap);
		assertTrue(true);
	}
	
	public void testIhracatSekliNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISLEM_TIPI", "I");
		iMap.put("IHRACAT_SEKLI", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2037_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
	public void testOdemeSekliNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISLEM_TIPI", "I");
		iMap.put("ODEME_SEKLI", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2037_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testTeslimSekliNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISLEM_TIPI", "I");
		iMap.put("TESLIM_SEKLI", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2037_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testCikisKapisiNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISLEM_TIPI", "I");
		iMap.put("CIKIS_KAPISI", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2037_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testMalCinsiNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISLEM_TIPI", "I");
		iMap.put("MAL_CINSI", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2037_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testGumrukNumarasiNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISLEM_TIPI", "I");
		iMap.put("GUMRUK_NUMARASI", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2037_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
	public void testGumrukBeyannameTarihiNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISLEM_TIPI", "I");
		iMap.put("GUMRUK_BEYANNAME_TARIHI", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2037_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
}

