package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsTRN2017Test extends TestCase {
	public HashMap<String, Object> setUpIMap() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO", GetTransactionNo());
		iMap.put("REFERANS_NO", GetReferansNo());
		iMap.put("ISLEM_SEKLI", "MN");
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("SUBE_KODU", 200);
		iMap.put("MUSTERI_NO", 1);
		iMap.put("HESAP_NO", 110);
		iMap.put("DK_NO", null);
		iMap.put("TUTAR", 12);
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try {
			iMap.put("VALOR_TARIHI", (java.util.Date) dateFormat
					.parse("11-11-2007"));
		} catch (Exception e) {}
		iMap.put("ACIKLAMA", "kaydet");

		return iMap;
	}

	public String GetTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	public String GetReferansNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2014_GET_REFERANCE_NO", new HashMap<String, Object>());
		return (String)oMap.get("REFERANS_NO");
	}
	
	public void testCanGetReferanceNo() {	
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2017_GET_REFERANCE_NO",new HashMap<String, Object>());
		assertNotNull(oMap.get("REFERANS_NO"));
	}
	public void testDovizKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DOVIZ_KODU", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2017_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAciklamaNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ACIKLAMA", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2017_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}	
	public void testDKNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISLEM_SEKLI", "DK");
		iMap.put("DK_NO", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2017_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
	public void testHesapNoNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISLEM_SEKLI", "MN");
		iMap.put("HESAP_NO", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2017_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
	public void testGetKullanilabilirBakiye(){
		HashMap<String,Object> iMap = new HashMap<String, Object>();
		iMap.put("HESAP_NO", 104);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2017_GET_KULLANILABILIR_BAKIYE",iMap);
		assertEquals(new BigDecimal(10), oMap.get("KULLANILABILIR_BAKIYE"));
	}
	
	public void testKullanilabilirBakiyeNotNull(){
		HashMap<String,Object> iMap = new HashMap<String, Object>();
		iMap.put("HESAP_NO", 104);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2017_GET_KULLANILABILIR_BAKIYE",iMap);
		assertNotNull(oMap.get("KULLANILABILIR_BAKIYE"));
	}
	public void testKullanilabilirBakiyeType(){
		HashMap<String,Object> iMap = new HashMap<String, Object>();
		iMap.put("HESAP_NO", 104);
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2017_GET_KULLANILABILIR_BAKIYE",iMap);
		assertTrue(oMap.get("KULLANILABILIR_BAKIYE") instanceof BigDecimal);
	}
	
	public void testLocalCur(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_LOCAL_CUR", new HashMap<String, Object>());
		assertEquals("TRY", oMap.get("DOVIZ_KODU"));
	}
	
	public void testCheckDovizTutarWithKurussuzTutar(){
		HashMap<String,Object> iMap = new HashMap<String, Object>();
		iMap.put("TUTAR", "0.00");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2017_CHECK_DOVIZ_TUTAR",iMap);
		assertEquals(1, oMap.get("FLAG"));
	}
	
	public void testCheckDovizTutarWithKurusluTutar(){
		HashMap<String,Object> iMap = new HashMap<String, Object>();
		iMap.put("TUTAR", "0.03");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2017_CHECK_DOVIZ_TUTAR",iMap);
		assertEquals(0, oMap.get("FLAG"));
	}
	public void testOMapInfoAssertEq()
	{
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", "21683");
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2017_GET_INFO", iMap);
		
		assertEquals(oMap.get("REFERANS_NO")			, "07.200CNY0000645");
		assertEquals(oMap.get("ISLEM_SEKLI")			, "MN");		
		assertEquals(oMap.get("DOVIZ_KODU")				, "TRY");
		assertEquals(oMap.get("SUBE_KODU")				, "200");	
		assertEquals(oMap.get("MUSTERI_NO")				, new BigDecimal(38));
		assertEquals(oMap.get("HESAP_NO")				, new BigDecimal(467));
		assertEquals(oMap.get("SUBE")					, "200");
		assertEquals(oMap.get("DK_NO")					, null);
		assertEquals(oMap.get("TUTAR")					, new BigDecimal(12));
		assertEquals(oMap.get("ACIKLAMA")				, "12");
		assertEquals(oMap.get("KIMLIK_TIPI")			, "1");
		assertEquals(oMap.get("ISTATISTIK_KODU")		, null);

		assertEquals(oMap.get("KULL_BAKIYE").toString() , "96153.29");

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		
		try {
			assertEquals(oMap.get("VALOR_TARIHI")			, dateFormat.parseObject("2007-10-22"));
		} catch (ParseException e) {
			e.printStackTrace();
		} 
		
	}
	
}
