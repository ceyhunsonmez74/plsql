package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsTRN2012Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", GetTransactionNo());
		iMap.put("ALIS_SEKLI", 1);
		iMap.put("REZARYASYON_NO", 3);
		iMap.put("ACIKLAMA", "aciklama");
		iMap.put("ALACAK_HESAP_NO", 321);
		iMap.put("BORC_HESAP_NO", 11);
		iMap.put("DEKONT_BASIM_F", "H");
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("DOVIZ_ULKE_KODU", "AI");
		iMap.put("ISTATISTIK_KODU", "1237");	
		iMap.put("KUR", 12);
		iMap.put("TUTAR", 23);
		return iMap;
	}
	
	public String GetTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	public void testBorcHesapNoNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("BORC_HESAP_NO", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2012_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testKurNoNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("KUR", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2012_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
	public void testIstatistikKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISTATISTIK_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2012_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAciklamaNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ACIKLAMA", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2012_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	
	public void testKurNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("TUTAR", 32);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2012_GET_KUR_TO_TL", iMap);
		assertNotNull(oMap.get("KUR"));
		assertNotNull(oMap.get("YTL_KARSILIK"));
	}
	public void testCanGetCorrectKurValue(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("TUTAR", 32);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2012_GET_KUR_TO_TL", iMap);
		assertEquals("",new Double(1.22),(Double.parseDouble(oMap.get("KUR").toString())) ,new Double(0.2));
		assertEquals("",new Double(39.10),(Double.parseDouble(oMap.get("YTL_KARSILIK").toString())) ,new Double(0.2));
		
	}
	
	public void testKurTip(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("DOVIZ_KODU", "USD");
		iMap.put("TUTAR", 32);
		
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2012_GET_KUR_TO_TL", iMap);
		assertTrue(oMap.get("KUR") instanceof BigDecimal);
		assertTrue(oMap.get("YTL_KARSILIK") instanceof BigDecimal);
	}
	public void testDovizUlkeKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2012_GET_DOVIZ_ULKE_KODU", iMap);
		assertEquals("TR", oMap.get("DOVIZ_ULKE_KODU"));
	}
	public void testDIDovizUlkeKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("DOVIZ_KODU", "TR");
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2012_GET_DOVIZ_ULKE_KODU", iMap);
		assertEquals("T�rkiye ", oMap.get("DI_DOVIZ_KODU"));
	}
	
	

}
