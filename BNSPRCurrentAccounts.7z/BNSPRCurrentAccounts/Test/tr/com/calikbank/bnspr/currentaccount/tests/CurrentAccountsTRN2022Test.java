package tr.com.calikbank.bnspr.currentaccount.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class CurrentAccountsTRN2022Test extends TestCase {
	public void testCanGetKasaKodAndTanimNo() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		iMap.put("SUBE_KOD", GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_SUBE_KOD", new HashMap<String, Object>()).get("SUBE_KOD"));
		iMap.put("KULLANICI_KOD", GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_KULLANICI_KOD", new HashMap<String, Object>()).get("KULLANICI_KOD"));		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2022_GET_KASA_KOD_TANIM_NO", iMap);
	
		System.out.println("KASA KODU: " + oMap.get("KASA_KOD"));
		assertNotNull(oMap.get("KASA_KOD"));
		System.out.println("TANIM NO: " + oMap.get("TANIM_NO"));
		assertNotNull(oMap.get("TANIM_NO"));
	}
	
	public void testCanCallKasaIslemeAt() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("ISLEM_NO", new BigDecimal(new Random().nextInt(20000) + 20000));
		iMap.put("SUBE_KOD", GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_SUBE_KOD", new HashMap<String, Object>()).get("SUBE_KOD"));
		iMap.put("KULLANICI_KOD", GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_KULLANICI_KOD", new HashMap<String, Object>()).get("KULLANICI_KOD"));
		Map<?, ?> oMap1 =  GMResourceFactory.getInstance().service("BNSPR_TRN2022_GET_KASA_KOD_TANIM_NO", iMap);
		iMap.put("KASA_KODU", oMap1.get("KASA_KOD"));
		iMap.put("TANIM_NO", new BigDecimal(1));
		iMap.put("URUN_SINIF_KOD", "ANAKASAAL");	
	    GMResourceFactory.getInstance().service("BNSPR_TRN2022_CALL_KASA_ISLEME_AT", iMap);

		assertTrue(true);
	}
}
