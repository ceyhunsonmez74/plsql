package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class EftTRN2306Test extends TestCase {
	static BigDecimal trxNo;
	static BigDecimal eskiTrxNo;

	public HashMap<String, Object> setUpIMap() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO", trxNo);
		iMap.put("EFT_URUN_TUR", "GIDEN");
		iMap.put("MUSTERI_NO", "1000042");
		iMap.put("HESAP_TIPI", null);
		iMap.put("SORGU_NO", null);
		iMap.put("HESAP_NO", "642");
		iMap.put("MESAJ_TIPI", null);
		iMap.put("BANKA_KODU", null);
		iMap.put("BANKA_SUBE_KODU", null);
		iMap.put("TUTAR", null);

		ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
		for (int i = 0; i < 2; i++) {
			HashMap<String, Object> rowData = new HashMap<String, Object>();
			rowData.put("TRX_NO", trxNo);
			rowData.put("ESKI_TRX_NO", eskiTrxNo);
			rowData.put("BANKA_KODU", null);
			rowData.put("BANKA_SUBE_KODU", null);
			rowData.put("DK_NO", null);
			rowData.put("GIREN_KULLANICI", null);
			rowData.put("HESAP_NO", null);
			rowData.put("ISLEM_TARIHI", null);
			rowData.put("MESAJ_TIPI", null);
			rowData.put("SECILDI", "1");
			rowData.put("SORGU_NO", null);
			rowData.put("TUTAR", null);
			list.add(rowData);
		}

		iMap.put("GELGON_EFT_BIRLESTIR_DTYIS", list);

		return iMap;
	}

	public void testCanGetTrxNo() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("MUSTERI_NO", "1000042");
		iMap.put("EFT_URUN_TUR", "GIDEN");

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_TRN2306_GET_TRX_NO", iMap);
		assertNotNull(oMap.get("TRX_NO"));
		trxNo = new BigDecimal(oMap.get("TRX_NO").toString());
	}

	public void testCanGetCorrectEftMesajlari() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", trxNo);

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_TRN2306_GET_EFT_BILGI", iMap);
		List<?> list = (List<?>) oMap.get("GELGON_EFT_BIRLESTIR_DTYIS");
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()) {
			HashMap<?, ?> rowData = (HashMap<?, ?>) iterator.next();
			eskiTrxNo = new BigDecimal(rowData.get("ESKI_TRX_NO").toString());
			assertEquals("046", rowData.get("BANKA_KODU"));
			assertEquals("00434", rowData.get("BANKA_SUBE_KODU"));
			assertEquals(null, rowData.get("DK_NO"));
			assertEquals("BNSPR", rowData.get("GIREN_KULLANICI"));
			assertEquals(new BigDecimal(642), new BigDecimal(rowData.get(
					"HESAP_NO").toString()));
			assertEquals("2007-10-22", rowData.get("ISLEM_TARIHI").toString());
			assertEquals("AKBANK T.A.�.", rowData.get("K_BANKA_ADI"));
			assertEquals("NORM", rowData.get("MESAJ_TIPI"));
			assertEquals(null, rowData.get("SORGU_NO"));
			assertEquals("20.15", rowData.get("TUTAR").toString());
		}
		assertEquals("201.91", oMap.get("TOPLAM_TUTAR").toString());
	}

	public void testTutarNotNull() {
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("TUTAR", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2306_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}

	public void testHesapNoNotNull() {
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("HESAP_NO", null);
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2306_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}

	public void testSelectedColumnNumber() {
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("SECILDI", "0");
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2306_SAVE", iMap);
			fail("en az iki kay�t se�ilmelidir");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}

}
