package tr.com.calikbank.bnspr.system.tests;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class EftQRY2378Test extends TestCase {
	public HashMap<String, Object> setUpIMap() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("K_EFT_TARIH_BAS", null);
		iMap.put("K_EFT_TARIH_BIT", null);
		iMap.put("K_MIN_TUTAR", "0.00");
		iMap.put("K_MAX_TUTAR", "0.00");
		iMap.put("K_BOLUM", null);
		iMap.put("GELEN_GIDEN", null);
		iMap.put("MESAJ_KODU", null);
		iMap.put("K_MUSTERI_NO", null);
		iMap.put("K_EFT_DURUMU", null);
		iMap.put("K_DURUM", null);
		iMap.put("SIRALAMA_KRITERI", "TUTAR ASC");
		return iMap;
	}
	public void testCanGetCorrectEftMesajlari() {
		HashMap<String, Object> iMap = setUpIMap();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2378_GET_EFT_MESAJLARI", iMap);
		List<?> list = (List<?>) oMap.get("EFT_MESAJLARI");
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()) {
			HashMap<?, ?> rowdata = (HashMap<?, ?>) iterator.next();
			System.out.println(rowdata.get("SORGU_NO"));
			assertEquals("68", rowdata.get("SORGU_NO"));
			assertEquals("HABR-GENL", rowdata.get("MESAJ_KODU"));
			
			//ekrandan do�ru �al���yo testcaseden yanl��
			
		}
	}

}
