package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class EftTRN2368Test extends TestCase{
	public HashMap<String, Object> setUpIMap() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("K_ALAN_SUBE", "00300");
		iMap.put("K_MESAJ_KODU", null);
		iMap.put("K_MUSTERI_NO", null);
		iMap.put("K_MUSTERI_HESAP_NO", null);
		iMap.put("K_SORGU_NO", null);
		iMap.put("K_MIN_TUTAR", "0.00");
		iMap.put("K_MAX_TUTAR", "0.00");
		iMap.put("K_GONDEREN_BANKA", null);
		
		return iMap;
	}
	public void testCanGetCorrectEftList() {
		HashMap<String, Object> iMap = setUpIMap();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2362_GET_EFT_MESAJLARI", iMap);

		List<?> list = (List<?>) oMap.get("EFT_MESAJLARI");
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()) {
			HashMap<?, ?> rowdata = (HashMap<?, ?>) iterator.next();
			assertEquals(new BigDecimal(20167), new BigDecimal((String) rowdata.get("TRX_NO")));
			assertEquals("1945598", rowdata.get("SORGU_NO"));
			assertEquals("NORM", rowdata.get("MESAJ_KODU"));
			assertEquals("385", rowdata.get("TUTAR"));
			assertEquals("46", rowdata.get("GONDEREN_BANKA_KODU"));
			assertEquals(null, rowdata.get("ALICI_HESAP_NO"));
			assertEquals("SALIH TAS�I", rowdata.get("ALICI_ADI"));
			assertEquals(null, rowdata.get("MUSTERI_HESAP_NO"));
		}
	}
	
	public void testCanGetEftMerkezMi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("SUBE_KODU", "300");
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2362_GET_EFT_MERKEZ_MI", iMap);
		assertEquals(new BigDecimal(0), oMap.get("EFT_MERKEZ_MI"));
	}
	public void testCanGetAlanSubeKod(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("SUBE_KODU", (String)GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_SUBE_KOD", new HashMap<String, Object>()).get("SUBE_KOD"));
		System.out.println(iMap.get("SUBE_KODU"));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2362_GET_EFT_MERKEZ_MI", iMap);
		//Map<?, ?> oMap = GMServiceExecuter.execute("BNSPR_TRN2362_GET_EFT_MERKEZ_MI", iMap);
		System.out.println(oMap.get("K_ALAN_SUBE"));
		assertEquals("00300", oMap.get("K_ALAN_SUBE"));//ekran ile servis farkl� sonuc �retio
	}
	

}
