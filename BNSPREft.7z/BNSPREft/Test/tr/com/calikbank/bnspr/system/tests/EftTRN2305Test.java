package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;
//Bu test case e yeniden bak�lacak
public class EftTRN2305Test extends TestCase {
	String txNo = null;
	public HashMap<String, Object> setUpIMap() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("EFT_URUN_TUR", "GIDEN");
		iMap.put("MUSTERI_NO", null);
		iMap.put("BANKA_KODU", null);
		iMap.put("MIN_TUTAR", "0.00");
		iMap.put("MESAJ_TIPI", null);
		iMap.put("HESAP_NO", null);
		iMap.put("DK_NO", null);
		iMap.put("BANKA_SUBE_KODU", null);
		iMap.put("MAX_TUTAR", "0.00");
		iMap.put("SIRALAMA_KRITERI", "DESC");

		return iMap;
	}

	public void testCanGetCorrectEftList() {
		HashMap<String, Object> iMap = setUpIMap();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_TRN2305_GET_EFT_LIST", iMap);

		List<?> list = (List<?>) oMap.get("GELGON_EFT_GIRIS");
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()) {
			HashMap<?, ?> rowdata = (HashMap<?, ?>) iterator.next();
			assertEquals(new BigDecimal(1000042), new BigDecimal(
					(String) rowdata.get("MUSTERI_NO")));
			assertEquals(new BigDecimal(12), new BigDecimal((String) rowdata
					.get("TUTAR")));
			txNo = (String)rowdata.get("TRX_NO");
		}
	}

	public void testCanGetCorrectToplamTutarValue() {
		HashMap<String, Object> iMap = setUpIMap();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_TRN2305_GET_EFT_LIST", iMap);
		
		assertEquals(new BigDecimal(12),oMap.get("TOPLAM_TUTAR"));

	}
	public void testCanGetCorrectKullanilanTutar() {
		HashMap<String, Object> iMap = setUpIMap();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_TRN2305_EFT_BILGI_AKTAR", iMap);
		
		assertEquals(new BigDecimal(12),oMap.get("KULLANILAN_TUTAR"));

	}
	public void testCanGetCorrectEftBilgi() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", txNo);

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_TRN2305_GET_EFT_BILGI", iMap);

		assertEquals("GIDEN", oMap.get("EFT_URUN_TUR"));
		assertEquals("KRED", oMap.get("MESAJ_TIPI"));
		assertEquals("", oMap.get("SORGU_NO"));
		assertEquals("015", oMap.get("BANKA_KODU"));
		assertEquals("0007", oMap.get("BANKA_SUBE_KODU"));
		assertEquals("", oMap.get("MUSTERI_NO"));
		assertEquals("M", oMap.get("HESAP_TIPI"));
		assertEquals("", oMap.get("HESAP_NO"));
		assertEquals("", oMap.get("DK_NO"));
		assertEquals("", oMap.get("NDB_DKADI"));
		assertEquals("", oMap.get("TUTAR"));
	}
}
