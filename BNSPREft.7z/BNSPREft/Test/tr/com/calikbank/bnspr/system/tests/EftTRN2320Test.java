package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class EftTRN2320Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("BOLUM_KODU" , null);
        iMap.put("GONDEREN_BANKA" , "143");
        iMap.put("GONDEREN_SUBE" , "00300");
        iMap.put("GONDEREN_SEHIR" , "034");
        iMap.put("ALAN_BANKA_KODU" , "100");
        iMap.put("ALAN_SEHIR_KODU" , "034");
        iMap.put("ALAN_SUBE_KODU" , "00600");
        iMap.put("ACIKLAMA" , "osman");
        iMap.put("ACIKLAMA_2" , null);
        iMap.put("ACIKLAMA_3" , null);
        iMap.put("ACIKLAMA_4" , null);
        iMap.put("ACIKLAMA_5" , null);
        iMap.put("ACIKLAMA_6" , null);
        iMap.put("TRX_NO" , new BigDecimal(20596));
        iMap.put("MESAJ_KODU" , "HABR-GENL");
        iMap.put("SORGU_NO" , "69");
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("EFT_TARIH", (java.util.Date)dateFormat.parse("22-10-2007"));		
		}catch(Exception e){}
		
        iMap.put("ONCELIK" , null);
        iMap.put("GELEN_GIDEN", "GIDEN");
        iMap.put("DURUM" ,"TAMAM");
		
		return iMap;
	}
	public void testCanGetMesaKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20596));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2320_GET_EFT_INFO", iMap);
		assertEquals("HABR-GENL", oMap.get("MESAJ_KODU"));
	}
	public void testCanGetSorgu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20596));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2320_GET_EFT_INFO", iMap);
		assertEquals(new BigDecimal(69), new BigDecimal(oMap.get("SORGU_NO").toString()));
	}
	public void testCanGetEftTarih(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20596));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2320_GET_EFT_INFO", iMap);
		assertEquals("2007-10-22", oMap.get("EFT_TARIH").toString());
	}
	public void testCanGetEftOncelik(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20596));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2320_GET_EFT_INFO", iMap);
		assertEquals("2", oMap.get("ONCELIK"));
	}
	public void testCanGetGonderenBanka(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20596));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2320_GET_EFT_INFO", iMap);
		assertEquals("143", oMap.get("GONDEREN_BANKA"));
	}
	public void testCanGetGonderenSube(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20596));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2320_GET_EFT_INFO", iMap);
		assertEquals("00300", oMap.get("GONDEREN_SUBE"));
	}
	public void testCanGetGonderenSehir(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20596));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2320_GET_EFT_INFO", iMap);
		assertEquals("034", oMap.get("GONDEREN_SEHIR"));
	}
	public void testCanGetAlanBankaKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20596));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2320_GET_EFT_INFO", iMap);
		assertEquals("088", oMap.get("ALAN_BANKA_KODU"));
	}
	public void testCanGetAlanSehirKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20596));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2320_GET_EFT_INFO", iMap);
		assertEquals("034", oMap.get("ALAN_SEHIR_KODU"));
	}
	public void testCanGetAlanSubeKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20596));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2320_GET_EFT_INFO", iMap);
		assertEquals("00001", oMap.get("ALAN_SUBE_KODU"));
	}

	public void testAlanBankaKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("TRX_NO", new BigDecimal(20596));
		iMap.put("ALAN_BANKA_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_EFT_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAlanSehirKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("TRX_NO", new BigDecimal(20596));
		iMap.put("ALAN_SEHIR_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_EFT_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAlanSubeKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("TRX_NO", new BigDecimal(20596));
		iMap.put("ALAN_SUBE_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_EFT_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAciklamaNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("TRX_NO", new BigDecimal(20596));
		iMap.put("ACIKLAMA", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_EFT_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}

}
