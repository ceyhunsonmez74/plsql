package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;


public class EftTRN2373Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("G_BAS_SAAT", "2");
		iMap.put("G_BAS_DAKIKA", "11");
		iMap.put("G_SON_SAAT", "21");
		iMap.put("G_SON_DAKIKA", "12");
		iMap.put("EFT_BAS_SAAT", "10");
		iMap.put("EFT_BAS_DAKIKA", "5");
		iMap.put("EFT_SON_SAAT", "21");
		iMap.put("EFT_SON_DAKIKA", "00");
		
		
		ArrayList<HashMap<String, Object>> list1 = new ArrayList<HashMap<String,Object>>();
		HashMap<String, Object> firstMap = new HashMap<String, Object>();
		
		firstMap.put("BAS_DAKIKA", "1");
		firstMap.put("BAS_SAAT", "8");
		firstMap.put("MARJ_ORAN", new BigDecimal(0));
		firstMap.put("MARJ_TUTAR", new BigDecimal(1));
		firstMap.put("MIN_TUTAR", new BigDecimal(10));
		firstMap.put("SON_DAKIKA", "07");
		firstMap.put("SON_SAAT", "14");
		list1.add(firstMap);
		
		iMap.put("EFT_SAAT_ARALIGI", list1);
		
		ArrayList<HashMap<String, Object>> list2 = new ArrayList<HashMap<String,Object>>();
		HashMap<String, Object> secondMap = new HashMap<String, Object>();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			firstMap.put("GONERIM_SAAT", (Date)dateFormat.parse("09-01-2008"));
		}catch (Exception e) {}
		
		firstMap.put("NUMARA", new BigDecimal(1));
		list2.add(secondMap);
		
		iMap.put("EFT_BAGIMLI_ISLEM", list2);		
		
		return iMap;
	}
	
	/*public void testCanSave() {
		HashMap<String, Object> iMap = setUpIMap();
		GMResourceFactory.getInstance().service("BNSPR_TRN2373_SAVE", iMap);
		assertTrue(true);		
	}*/
	public void testCanGetCorrectEftGirisSaatAraliklariList(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2373_GET_EFT_GIRIS_SAAT_BILGILERI", new HashMap<String, Object>());
		List<?> list = (List<?>)oMap.get("EFT_SAAT_ARALIGI");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("01",rowData.get("BAS_DAKIKA")); 
			assertEquals("08", rowData.get("BAS_SAAT"));
			assertEquals(new BigDecimal(0), rowData.get("MARJ_ORAN"));
			assertEquals(new BigDecimal(1), rowData.get("MARJ_TUTAR"));
			assertEquals(new BigDecimal(10), rowData.get("MIN_TUTAR"));
			assertEquals("07", rowData.get("SON_DAKIKA"));
			assertEquals("14", rowData.get("SON_SAAT"));
		}
	}
	
	public void testCanGetCorrectEftGonderimsSaatAraliklariList(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2373_GET_EFT_GIRIS_SAAT_BILGILERI", new HashMap<String, Object>());
		List<?> list = (List<?>)oMap.get("ILERI_EFT_SAAT");
		Iterator<?> iter = list.iterator();
		if(iter.hasNext()){
			HashMap<?,?> rowData = (HashMap<?, ?>) iter.next();
			assertEquals("14:30",rowData.get("GONDERIM_SAAT"));
		}
	}
	
	public void testCanGetCorrectBasSaat(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2373_GET_EFT_GIRIS_SAAT_BILGILERI", new HashMap<String, Object>());
		assertEquals("05", oMap.get("G_BAS_SAAT"));
	}
	public void testCanGetCorrectBasDakika(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2373_GET_EFT_GIRIS_SAAT_BILGILERI", new HashMap<String, Object>());
		assertEquals("11", oMap.get("G_BAS_DAKIKA"));
	}
	public void testCanGetCorrectSonSaat(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2373_GET_EFT_GIRIS_SAAT_BILGILERI", new HashMap<String, Object>());
		assertEquals("21", oMap.get("G_SON_SAAT"));
	}
	public void testCanGetCorrectSonDakika(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2373_GET_EFT_GIRIS_SAAT_BILGILERI", new HashMap<String, Object>());
		assertEquals("12", oMap.get("G_SON_DAKIKA"));
	}
	public void testCanGetCorrectEftBasSaat(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2373_GET_EFT_GIRIS_SAAT_BILGILERI", new HashMap<String, Object>());
		assertEquals("10", oMap.get("EFT_BAS_SAAT"));
	}
	public void testCanGetCorrectEftBasDakika(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2373_GET_EFT_GIRIS_SAAT_BILGILERI", new HashMap<String, Object>());
		assertEquals("44", oMap.get("EFT_BAS_DAKIKA"));
	}
	public void testCanGetCorrectEftSonSaat(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2373_GET_EFT_GIRIS_SAAT_BILGILERI", new HashMap<String, Object>());
		assertEquals("21", oMap.get("EFT_SON_SAAT"));
	}
	public void testCanGetCorrectEftSonDakika(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2373_GET_EFT_GIRIS_SAAT_BILGILERI", new HashMap<String, Object>());
		assertEquals("00", oMap.get("EFT_SON_DAKIKA"));
	}
}
