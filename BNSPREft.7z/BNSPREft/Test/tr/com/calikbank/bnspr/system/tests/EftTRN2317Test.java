package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class EftTRN2317Test extends TestCase{
	public void testCanGetMesajKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20167));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2317_GET_EFT_ODEME_BILGI", iMap);
		assertEquals("NORM", oMap.get("MESAJ_KODU"));
	}
	
	public void testCanGetSorguNo(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20167));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2317_GET_EFT_ODEME_BILGI", iMap);
		assertEquals(new BigDecimal(1945598), new BigDecimal(oMap.get("SORGU_NO").toString()));
	}
	public void testCanGetDurum(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20167));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2317_GET_EFT_ODEME_BILGI", iMap);
		assertEquals("USER_INT",oMap.get("DURUM"));
	}
	public void testCanGetTutar(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20167));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2317_GET_EFT_ODEME_BILGI", iMap);
		assertEquals(new BigDecimal(385),new BigDecimal(oMap.get("TUTAR").toString()));
	}
	public void testCanGetEftTarih(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20167));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2317_GET_EFT_ODEME_BILGI", iMap);
		System.out.println(oMap.get("EFT_TARIH").toString());
		assertEquals("2007-10-22",oMap.get("EFT_TARIH").toString());
	}
	public void testCanGetOncelik(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20167));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2317_GET_EFT_ODEME_BILGI", iMap);
		System.out.println(oMap.get("ONCELIK").toString());
		assertEquals("4",oMap.get("ONCELIK"));
	}

}
