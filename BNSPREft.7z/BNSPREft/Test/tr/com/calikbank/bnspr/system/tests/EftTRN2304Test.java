package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class EftTRN2304Test extends TestCase {
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO" , getTransactionNo());
        iMap.put("EFT_URUN_TUR" , "GIDEN");
        iMap.put("MESAJ_TIPI" , "AKTR-ISTE");
        iMap.put("HESAP_TIPI" , "M");
        iMap.put("SORGU_NO" , null);
        iMap.put("BANKA_KODU" , "010");
        iMap.put("BANKA_SUBE_KODU" , "00002");
        iMap.put("MUSTERI_NO" , "1000042");
        iMap.put("HESAP_NO" , "589");
        iMap.put("DK_NO" , null);
        iMap.put("TUTAR" , new BigDecimal(4));
		
		return iMap;
	}
	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	public void testCanSaveGelecekGonderilecekEft() {
		HashMap<String, Object> iMap =  setUpIMap();
		GMResourceFactory.getInstance().service("BNSPR_TRN2304_SAVE", iMap);
		assertTrue(true);
	}
	public void testTutarNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("TUTAR",null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_TRN2304_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
}
