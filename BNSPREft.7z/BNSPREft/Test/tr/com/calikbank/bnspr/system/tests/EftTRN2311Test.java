package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class EftTRN2311Test extends TestCase {

	public void testCanGetCorrectInitialValue() {
		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_TRN2311_GET_INITIAL_VALUES",
				new HashMap<String, Object>());
		System.out.println(oMap.get("EFT_TARIH"));
		assertEquals("2007-10-22", oMap.get("EFT_TARIH").toString());
		assertNotNull(oMap.get("TRX_NO"));
	}
	public void testCanGetDkHesapNo(){
		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_TRN2311_GET_DK_HESAP_NO",
				new HashMap<String, Object>());
		assertEquals("39299400", oMap.get("DK_HESAP_NO"));
	}
	public void testCanGetVergiNo(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("MUSTERI_NO","32" );
		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_TRN2311_GET_VERGI_NO",
				iMap);
		assertEquals("24335702422", oMap.get("IADE_VERGI_KIMLIK_NUMARA"));
	}
	
	public void testCanGetSQLDate(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("TARIH",(Date)dateFormat.parse("11-11-2005"));
		}catch (Exception e) {}

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_TRN2311_GET_SQL_DATE",
				iMap);
		assertEquals("11.11.2005", oMap.get("TARIH"));
	}

	public void testCanGetMesajKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(19383));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2311_GET_EFT_BILGI", iMap);
		assertEquals("IADE", oMap.get("MESAJ_KODU"));
	}
	
	public void testCanGetSorguNo(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(19383));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2311_GET_EFT_BILGI", iMap);
		assertEquals(new BigDecimal(51), new BigDecimal(oMap.get("SORGU_NO").toString()));
	}
	public void testCanGetDurum(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(19383));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2311_GET_EFT_BILGI", iMap);
		assertEquals("TAMAM",oMap.get("DURUM"));
	}
	public void testCanGetTutar(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(19383));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2311_GET_EFT_BILGI", iMap);
		assertEquals(new BigDecimal(6600),new BigDecimal(oMap.get("TUTAR").toString()));
	}
	public void testCanGetEftTarih(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(19383));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2311_GET_EFT_BILGI", iMap);
		assertEquals("2007-10-22",oMap.get("EFT_TARIH").toString());
	}
	public void testCanGetOncelik(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(19383));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2311_GET_EFT_BILGI", iMap);
		assertEquals("4",oMap.get("ONCELIK"));
	}
	public void testCanGetDkNo(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(19383));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2311_GET_EFT_BILGI", iMap);
		assertEquals("28099200",oMap.get("DK_HESAP_NO"));
	}
	public void testCanGetIadeEdenBanka(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(19383));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2311_GET_EFT_BILGI", iMap);
		assertEquals("143",oMap.get("GONDEREN_BANKA"));
	}
	public void testCanGetIadeEdenSube(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(19383));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2311_GET_EFT_BILGI", iMap);
		assertEquals("300",oMap.get("GONDEREN_SUBE"));
	}
	public void testCanGetIadeEdenSehir(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(19383));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2311_GET_EFT_BILGI", iMap);
		assertEquals("034",oMap.get("GONDEREN_SEHIR"));
	}
	public void testCanGetAlanBankaKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(19383));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2311_GET_EFT_BILGI", iMap);
		assertEquals("71", oMap.get("ALAN_BANKA_KODU"));
	}
	public void testCanGetAlanSubeKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(19383));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2311_GET_EFT_BILGI", iMap);
		assertEquals("85", oMap.get("ALAN_SUBE_KODU"));
	}
	public void testCanGetAlanSehirKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(19383));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2311_GET_EFT_BILGI", iMap);
		assertEquals("034", oMap.get("ALAN_SEHIR_KODU"));
	}
}
