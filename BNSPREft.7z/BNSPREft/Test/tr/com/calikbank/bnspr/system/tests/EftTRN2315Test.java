package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class EftTRN2315Test extends TestCase {
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("TRX_NO" , getTransactionNo());
		iMap.put("MUSTERI_NO" , "1000042");
        iMap.put("MUSTERI_HESAP_NO" , "642");
        iMap.put("GONDEREN_VERGI_KIMLIK_NUMARASI" , "78512121");
        iMap.put("DK_HESAP_NO" , null);
        iMap.put("ISLEM_TIPI" , "M");
        iMap.put("BOLUM_KODU" , "300");
        iMap.put("GONDEREN_SUBE" , "00300");
        iMap.put("GONDEREN_BANKA" , "143");
        iMap.put("GONDEREN_SEHIR" , "034");
        iMap.put("GONDEREN" , "osman");
        iMap.put("GONDEREN_TELEFON" , "212358");
        iMap.put("GONDEREN_ADRES" , "kojx x�jxj");
        iMap.put("ACIKLAMA" , "j�j�o");
        iMap.put("ALAN_BANKA_KODU" , "100");
        iMap.put("ALAN_SEHIR_KODU" , "100");
        iMap.put("ALAN_SUBE_KODU" , "100");
        iMap.put("ALICI_TELEFON_NO" , "45451ds");
        iMap.put("ALICI_ADRES_1" , null);
        iMap.put("ALICI_ADRES_2" , null);
        iMap.put("ALICI_BABA_ADI" , null);
        iMap.put("ALICININ_DOGUM_TARIHI" , null);
        iMap.put("KART_NO" , null);
        iMap.put("ALICI_HESAP_NO" , null);
        iMap.put("ALICI_IBAN" , null);
        iMap.put("TUTAR" , null);
        iMap.put("MASRAF" , null);
        iMap.put("OTOMATIK_BILDIRIM_OLUSTUR" , null);
        iMap.put("BILDIRIM_NO" , null);
        iMap.put("EFT_TARIH" , null);
        iMap.put("ONCELIK" , null);
        iMap.put("GELEN_GIDEN" , null);
        iMap.put("SORGU_NO" , null);
        iMap.put("DURUM" , null);
        iMap.put("MESAJ_KODU" , null);
		
		return iMap;
	}

	public String getTransactionNo(){
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRX_GET_TRANSACTION_NO", new HashMap<String, Object>());
		return (String)oMap.get("TRX_NO");
	}
	
	/*public void testCanSaveEft() {
		HashMap<String, Object> iMap =  setUpIMap();
		GMResourceFactory.getInstance().service("BNSPR_EFT_SAVE", iMap);
		assertTrue(true);
	}*/
	
	public void testCanGetCorrectEftInitialValue() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service(
				"BNSPR_TRN2315_GET_INITIAL_VALUES", iMap);

		assertEquals("200", oMap.get("SUBE_KODU"));
		assertEquals("12", oMap.get("BANKA_KODU"));
		assertEquals("�ALIK YATIRIM BANKASI TEST", oMap.get("BANKA_ADI"));
		assertEquals("2007-10-17", oMap.get("EFT_TARIH").toString());
		assertEquals("00200", oMap.get("GONDEREN_SUBE_KODU"));
		assertEquals("DENEME SUBESI", oMap.get("DI_GONDEREN_SUBE_KODU"));
		assertEquals("034", oMap.get("GONDEREN_SEHIR"));
		assertEquals("�STANBUL", oMap.get("DI_GONDEREN_SEHIR"));
	}
	
	public void testHesapBakiyesiGoruntulensinMi(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("HESAP_NO", new BigDecimal(642));
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2315_GET_HESAP_BAKIYE_GORUNTULENSIN_MI", iMap);
		assertEquals(new BigDecimal(1), oMap.get("HESAP_BAKIYE_GORUNSUN_MU"));
	}
	public void testMusteriNoNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ISLEM_TIPI", "M");
		iMap.put("MUSTERI_NO", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_EFT_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAlanBankaKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ALAN_BANKA_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_EFT_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAlanSehirKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ALAN_SEHIR_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_EFT_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAlanSubeKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("ALAN_SUBE_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_EFT_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
}
