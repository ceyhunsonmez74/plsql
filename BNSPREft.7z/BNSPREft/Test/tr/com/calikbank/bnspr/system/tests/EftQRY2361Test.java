package tr.com.calikbank.bnspr.system.tests;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class EftQRY2361Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("K_EFT_TARIH_BAS",(Date)dateFormat.parse("11-11-2005"));
			iMap.put("K_EFT_TARIH_BIT", (Date)dateFormat.parse("11-11-2008"));
		}catch (Exception e) {}
        iMap.put("K_MUSTERI_NO" , null);
        iMap.put("K_GONDEREN" , null);
        iMap.put("K_MUSTERI_HESAP_NO" , null);
        iMap.put("K_DK_HESAP_NO" , null);
        iMap.put("K_ALAN_BANKA_KODU" , null);
        iMap.put("K_BANKA_ADI" , null);
        iMap.put("K_ALAN_SEHIR" , null);
        iMap.put("K_ALAN_SUBE" , null);
        iMap.put("K_MIN_TUTAR" , "0.00");
        iMap.put("K_MAX_TUTAR" , "0.00");
        iMap.put("K_BOLUM" , null);
        iMap.put("K_GONDEREN_SUBE" , null);
        iMap.put("K_MESAJ_KODU" , null);
        iMap.put("K_MESAJ_ADI" , null);
        iMap.put("K_SORGU_NO" , null);
        iMap.put("K_DURUM" , null);
        iMap.put("SIRALAMA_KRITERI" , "TUTAR ASC");
		
		return iMap;
	}
	public void testCanGetCorrectGidenEftMesajlari() {
		HashMap<String, Object> iMap = setUpIMap();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2361_GET_GIDEN_EFT_MESAJLARI", iMap);
		List<?> list = (List<?>) oMap.get("GIDEN_EFT_MESAJLARI");
		Iterator<?> iterator = list.iterator();
		System.out.println("osman");
		if (iterator.hasNext()) {
			HashMap<?, ?> rowdata = (HashMap<?, ?>) iterator.next();
			assertEquals("NORM", rowdata.get("MESAJ_KODU"));
			System.out.println(rowdata.get("MESAJ_KODU"));
			System.out.println(rowdata.get("EFT_TARIH"));
			assertEquals("XX", rowdata.get("EFT_TARIH"));
			
		}
	}
}
