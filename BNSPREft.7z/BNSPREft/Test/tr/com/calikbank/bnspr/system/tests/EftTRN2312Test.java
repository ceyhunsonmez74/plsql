package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class EftTRN2312Test extends TestCase{
	public void testCanGetMesajKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20169));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", iMap);
		assertEquals("IADE", oMap.get("MESAJ_KODU"));
	}
	
	public void testCanGetSorguNo(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20169));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", iMap);
		assertEquals(new BigDecimal(570081), new BigDecimal(oMap.get("SORGU_NO").toString()));
	}
	public void testCanGetDurum(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20169));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", iMap);
		assertEquals("USER_INT",oMap.get("DURUM"));
	}
	public void testCanGetTutar(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20169));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", iMap);
		assertEquals("338.99",oMap.get("TUTAR").toString());
	}
	public void testCanGetEftTarih(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20169));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", iMap);
		assertEquals("2007-10-22",oMap.get("EFT_TARIH").toString());
	}
	public void testCanGetOncelik(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20169));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", iMap);
		assertEquals("4",oMap.get("ONCELIK"));
	}
	public void testCanGetDkNo(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20169));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", iMap);
		assertEquals(null,oMap.get("DK_HESAP_NO"));
	}
	public void testCanGetIadeEdenBanka(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20169));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", iMap);
		assertEquals("62",oMap.get("GONDEREN_BANKA"));
	}
	public void testCanGetIadeEdenSube(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20169));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", iMap);
		assertEquals("923",oMap.get("GONDEREN_SUBE"));
	}
	public void testCanGetIadeEdenSehir(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20169));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", iMap);
		assertEquals("6",oMap.get("GONDEREN_SEHIR"));
	}
	public void testCanGetAlanBankaKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20169));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", iMap);
		assertEquals("143", oMap.get("ALAN_BANKA_KODU"));
	}
	public void testCanGetAlanSubeKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20169));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", iMap);
		assertEquals("300", oMap.get("ALAN_SUBE_KODU"));
	}
	public void testCanGetAlanSehirKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20169));
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2312_GET_EFT_ODEME_BILGI", iMap);
		assertEquals("34", oMap.get("ALAN_SEHIR_KODU"));
	}

}
