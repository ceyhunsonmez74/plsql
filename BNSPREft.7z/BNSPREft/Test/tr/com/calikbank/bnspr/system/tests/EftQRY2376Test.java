package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class EftQRY2376Test extends TestCase {
   
	static BigDecimal trx_no;
	public HashMap<String, Object> setUpIMap() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("SUBE_KODU", null);
		iMap.put("EFT_URUN_TUR", null);
		iMap.put("ILK_TARIH", null);
		iMap.put("SON_TARIH", null);
		iMap.put("MIN_TUTAR", "0.00");
		iMap.put("MAX_TUTAR", "0.00");
		iMap.put("MESAJ_TIPI", null);
		iMap.put("MUSTERI_NO", null);
		iMap.put("HESAP_NO", null);
		iMap.put("BANKA_KODU", null);
		iMap.put("BANKA_SUBE_KODU", null);
		iMap.put("SIRALAMA_KRITERI", "TUTAR DESC");
		iMap.put("GERCEKLESME_DURUMU", "Gerceklesmemis");

		return iMap;
	}
	public void testCanGetCorrectGidenEftMesajlari() {
		HashMap<String, Object> iMap = setUpIMap();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2376_GET_EFT_MESAJLARI", iMap);
		List<?> list = (List<?>) oMap.get("GELGON_EFT_GIRIS");
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()) {
			HashMap<?, ?> rowdata = (HashMap<?, ?>) iterator.next();
			trx_no = new BigDecimal(rowdata.get("TRX_NO").toString());
			assertEquals("300", rowdata.get("YARATAN_BOLUM_KODU"));
			assertEquals("GELEN", rowdata.get("EFT_URUN_TUR"));
			assertEquals("1000042",rowdata.get("MUSTERI_NO"));
			assertEquals("ad ikinci ad soyad", rowdata.get("UNVAN"));
			assertEquals("642", rowdata.get("HESAP_NO"));
			assertEquals("6600", rowdata.get("TUTAR"));
			assertEquals("AKBANK T.A.�.", rowdata.get("NDB_BANKA_ADI"));
			assertEquals("0", rowdata.get("NDB_KULL_ORAN"));
			assertEquals("0", rowdata.get("NDB_GER_ORAN"));
			assertEquals("BNSPR", rowdata.get("GIREN_KULLANICI"));
			
		}
	}
	public void testCanGetCorrectEftMasraflari() {
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", trx_no);
		
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2376_GET_EFT_MASRAFLARI", iMap);
		List<?> list = (List<?>) oMap.get("EFT_GELGON_KULANIM");
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()) {
			HashMap<?, ?> rowdata = (HashMap<?, ?>) iterator.next();
			assertEquals("", rowdata.get("BILDIRIM_NO"));
			assertEquals("", rowdata.get("ISLEM_TUTAR"));
			assertEquals("",rowdata.get("TUTAR"));
			assertEquals("", rowdata.get("YARATAN_TX_NO"));
		}
	}
	

}
