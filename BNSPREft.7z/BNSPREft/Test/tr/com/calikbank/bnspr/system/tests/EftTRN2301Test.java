package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import com.graymound.resource.GMResourceFactory;

import junit.framework.TestCase;

public class EftTRN2301Test extends TestCase {
	public void testCanGetGunOzellik(){
		HashMap<String, Object> aMap =  new HashMap<String, Object>();
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.set(2008, 0, 14);
		aMap.put("TARIH", calendar.getTime());
		Map<?,?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2301_GET_GUN_OZELLIK", aMap);
		assertEquals(new BigDecimal(0), oMap.get("RESULT"));
		System.out.println("RESULT: "  + oMap.get("RESULT"));
		
		calendar.set(2008, 0, 13);
		System.out.println(calendar.getTime());
		aMap.put("TARIH", calendar.getTime());
		oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2301_GET_GUN_OZELLIK", aMap);
		assertEquals(new BigDecimal(1), oMap.get("RESULT"));
		System.out.println("RESULT: "  + oMap.get("RESULT"));
	}
}
