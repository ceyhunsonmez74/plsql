package tr.com.calikbank.bnspr.system.tests;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class EftQRY2365Test extends TestCase{
	
	
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		
        iMap.put("K_EFT_TARIH_BAS" , null);
        iMap.put("K_EFT_TARIH_BIT" , null);
        iMap.put("K_MUSTERI_NO" , null);
        iMap.put("K_ALAN" , null);
        iMap.put("K_MUSTERI_HESAP_NO" , null);
        iMap.put("K_DK_HESAP_NO" , null);
        iMap.put("K_GONDEREN_BANKA" , null);
        iMap.put("K_BANKA_ADI" , null);
        iMap.put("K_GONDEREN_SEHIR" , null);
        iMap.put("K_GONDEREN_SUBE" , null);
        iMap.put("K_MIN_TUTAR" , "0.00");
        iMap.put("K_MAX_TUTAR" , "0.00");
        iMap.put("K_BOLUM" , null);
        iMap.put("K_ALAN_SUBE" , null);
        iMap.put("K_MESAJ_KODU" , null);
        iMap.put("K_MESAJ_ADI" , null);
        iMap.put("K_SORGU_NO" , null);
        iMap.put("K_DURUM" , null);
        iMap.put("K_SIRALAMA" , "AZALAN");
		
		return iMap;
	}	
	public void testCanGetCorrectEftMesajlari() {
		HashMap<String, Object> iMap = setUpIMap();

		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_QRY2365_GET_GELEN_EFT_MESAJLARI", iMap);
		List<?> list = (List<?>) oMap.get("EFT_MESAJLARI");
		Iterator<?> iterator = list.iterator();
		if (iterator.hasNext()) {
			HashMap<?, ?> rowdata = (HashMap<?, ?>) iterator.next();
			assertEquals("KRED", rowdata.get("MESAJ_KODU"));
			System.out.println(rowdata.get("MESAJ_KODU"));
			assertEquals("XX", rowdata.get("BANKA_ADI"));
			
		}
	}
	public void testCanGetBankaTarihi(){
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_COMMON_GET_BANKA_TARIH", new HashMap<String, Object>());
		assertEquals("2007-10-22", oMap.get("BANKA_TARIH").toString());
	}
}
