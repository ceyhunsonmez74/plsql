package tr.com.calikbank.bnspr.system.tests;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Map;

import junit.framework.TestCase;

import com.graymound.resource.GMResourceFactory;

public class EftTRN2319Test extends TestCase{
	public HashMap<String, Object> setUpIMap(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();

		iMap.put("BOLUM_KODU" , null);
        iMap.put("GONDEREN_BANKA" , "143");
        iMap.put("GONDEREN_SUBE" , "00300");
        iMap.put("GONDEREN_SEHIR" , "034");
        iMap.put("ALAN_BANKA_KODU" , "100");
        iMap.put("ALAN_SEHIR_KODU" , "034");
        iMap.put("ALAN_SUBE_KODU" , "00600");
        iMap.put("ACIKLAMA" , "osman");
        iMap.put("ACIKLAMA_2" , null);
        iMap.put("ACIKLAMA_3" , null);
        iMap.put("ACIKLAMA_4" , null);
        iMap.put("ACIKLAMA_5" , null);
        iMap.put("ACIKLAMA_6" , null);
        iMap.put("TRX_NO" , new BigDecimal(20560));
        iMap.put("MESAJ_KODU" , "2");
        iMap.put("SORGU_NO" , null);
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		try{
			iMap.put("EFT_TARIH", (java.util.Date)dateFormat.parse("22-10-2007"));		
		}catch(Exception e){}
		
        iMap.put("ONCELIK" , null);
        iMap.put("GELEN_GIDEN", "GIDEN");
        iMap.put("DURUM" ,null);
		
		return iMap;
	}
	
	public void testCanGetCorrectInitialValue(){
		
		/*Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2319_GET_INITIAL_VALUES", new HashMap<String, Object>());
		
		assertEquals("00300", oMap.get("SUBE_KODU"));bnspr kullan�c�s�na g�re gelmio �ube bilgisi
		assertEquals("143", oMap.get("BANKA_KODU"));
		assertEquals("2007-10-22", oMap.get("EFT_TARIH").toString());
		assertEquals("143", oMap.get("BANKA_ADI"));
		
		System.out.println(oMap.get("GONDEREN_SUBE_KODU"));
		assertEquals("00200", oMap.get("GONDEREN_SUBE_KODU"));
		System.out.println(oMap.get("DI_GONDEREN_SUBE_KODU"));
		assertEquals("", oMap.get("DI_GONDEREN_SUBE_KODU"));
		assertEquals("", oMap.get("GONDEREN_SEHIR"));
		assertEquals("", oMap.get("DI_GONDEREN_SEHIR"));*/
	}
	public void testCanGetMesaKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20560));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2319_GET_EFT_INFO", iMap);
		assertEquals("HABR-GENL", oMap.get("MESAJ_KODU"));
	}
	public void testCanGetSorgu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20560));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2319_GET_EFT_INFO", iMap);
		assertEquals(new BigDecimal(68), new BigDecimal(oMap.get("SORGU_NO").toString()));
	}
	public void testCanGetEftTarih(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20560));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2319_GET_EFT_INFO", iMap);
		assertEquals("2007-10-22", oMap.get("EFT_TARIH").toString());
	}
	public void testCanGetEftOncelik(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20560));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2319_GET_EFT_INFO", iMap);
		assertEquals("2", oMap.get("ONCELIK"));
	}
	public void testCanGetGonderenBanka(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20560));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2319_GET_EFT_INFO", iMap);
		assertEquals("143", oMap.get("GONDEREN_BANKA"));
	}
	public void testCanGetGonderenSube(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20560));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2319_GET_EFT_INFO", iMap);
		assertEquals("00300", oMap.get("GONDEREN_SUBE"));
	}
	public void testCanGetGonderenSehir(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20560));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2319_GET_EFT_INFO", iMap);
		assertEquals("034", oMap.get("GONDEREN_SEHIR"));
	}
	public void testCanGetAlanBankaKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20560));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2319_GET_EFT_INFO", iMap);
		assertEquals("100", oMap.get("ALAN_BANKA_KODU"));
	}
	public void testCanGetAlanSehirKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20560));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2319_GET_EFT_INFO", iMap);
		assertEquals("034", oMap.get("ALAN_SEHIR_KODU"));
	}
	public void testCanGetAlanSubeKodu(){
		HashMap<String, Object> iMap = new HashMap<String, Object>();
		iMap.put("TRX_NO", new BigDecimal(20560));
		Map<?, ?> oMap = GMResourceFactory.getInstance().service("BNSPR_TRN2319_GET_EFT_INFO", iMap);
		assertEquals("00600", oMap.get("ALAN_SUBE_KODU"));
	}
	
	
	public void testAlanBankaKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("TRX_NO", new BigDecimal(20560));
		iMap.put("ALAN_BANKA_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_EFT_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAlanSehirKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("TRX_NO", new BigDecimal(20560));
		iMap.put("ALAN_SEHIR_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_EFT_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAlanSubeKoduNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("TRX_NO", new BigDecimal(20560));
		iMap.put("ALAN_SUBE_KODU", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_EFT_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
	public void testAciklamaNotNull(){
		HashMap<String, Object> iMap = setUpIMap();
		iMap.put("TRX_NO", new BigDecimal(20560));
		iMap.put("ACIKLAMA", null);		
		try {
			GMResourceFactory.getInstance().service("BNSPR_EFT_SAVE", iMap);
			fail("Should raise an SQL Exception");
		} catch (Exception success) {
			System.out.println(success.toString());
		}
	}
}
