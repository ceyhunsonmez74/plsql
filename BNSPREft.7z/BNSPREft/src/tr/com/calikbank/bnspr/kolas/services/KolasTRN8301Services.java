package tr.com.calikbank.bnspr.kolas.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.KolasGuncellemeSilmeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class KolasTRN8301Services {

		@GraymoundService("BNSPR_MUSTERI_KOLAS_SORGULA")
		public static GMMap musteriKolasSorgula(GMMap iMap) {
			GMMap oMap = new GMMap();
			Connection conn = null;
			CallableStatement stmt = null;

			try{
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{ ? = call pkg_trn8300.musteri_identity_no(?) }");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));

				stmt.execute();

				iMap.put("IDENTITY_NO", stmt.getObject(1)); 

	            iMap.put("ACCOUNTS", GMServiceExecuter.call("BNSPR_KOLAS_QUERY_ADDRESS", iMap).get("ACCOUNTS"));
	            for (int i = 0; i < iMap.getSize("ACCOUNTS"); i++) {
	                oMap.put("ACCOUNTS", i, "REF_NO", iMap.getString("ACCOUNTS", i, "REF_NO"));
	                oMap.put("ACCOUNTS", i, "ACCOUNT_NO", iMap.getString("ACCOUNTS", i, "ACCOUNT_NO"));
	                oMap.put("ACCOUNTS", i, "ADDRESS_TYPE", iMap.getString("ACCOUNTS", i, "ADDRESS_TYPE"));
	                oMap.put("ACCOUNTS", i, "ADDRESS_VALUE", iMap.getString("ACCOUNTS", i, "ADDRESS_VALUE"));
	                oMap.put("ACCOUNTS", i, "IDENTITY_NO", iMap.getString("ACCOUNTS", i, "IDENTITY_NO"));
	                oMap.put("ACCOUNTS", i, "DESCRIPTION", iMap.getString("ACCOUNTS", i, "DESCRIPTION"));
	                
	            }

			return oMap;

			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}		
		
		@GraymoundService("BNSPR_KOLAS_SORGULA_BY_REFNO")
		public static GMMap kolasSorgulaRefno(GMMap iMap) {
			GMMap oMap = new GMMap();

			try{

		        if (StringUtil.isEmpty(iMap.getString("REF_NO"))){
		            iMap.put("HATA_NO" , new BigDecimal(330));
		            iMap.put("P1" , "Referans No");
		            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
		        }	
		        else {
					oMap = GMServiceExecuter.call("BNSPR_KOLAS_QUERY_ADDRESS", iMap);
		        }

		        return oMap;

			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} 
		}		

		@GraymoundService("BNSPR_KOLAS_GUNCEL_ISLEM")
		public static GMMap kolasGuncelIslem(GMMap iMap) {
			GMMap oMap = new GMMap();
			GMMap kMap = new GMMap();

			try{
                    GMServiceExecuter.call("BNSPR_TRN8301_ONAYDA_BEKLEYEN_ISLEM_VAR_MI", iMap);
				    String tableName = "ACCOUNTS";
					kMap.put(tableName,  GMServiceExecuter.call("BNSPR_KOLAS_SORGULA_BY_REFNO", iMap).get("ACCOUNTS"));
					
					 if (!StringUtil.isEmpty(kMap.getString(tableName, 0, "REF_NO"))){
						 BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");
  						 Session session = DAOSession.getSession("BNSPRDal");
						 KolasGuncellemeSilmeTx kolasGuncellemeSilmeTx = (KolasGuncellemeSilmeTx) session.get(KolasGuncellemeSilmeTx.class, trxNo);
					
						if (kolasGuncellemeSilmeTx == null)
							kolasGuncellemeSilmeTx = new KolasGuncellemeSilmeTx();						 
                           
						kolasGuncellemeSilmeTx.setTxNo(trxNo);
						kolasGuncellemeSilmeTx.setIslem(iMap.getString("ISLEM"));
						kolasGuncellemeSilmeTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
						kolasGuncellemeSilmeTx.setIban(kMap.getString(tableName, 0, "ACCOUNT_NO"));
						GMMap hMap = new GMMap();
						hMap.put("IBAN", kMap.getString(tableName, 0,"ACCOUNT_NO"));
						kolasGuncellemeSilmeTx.setHesapNo(GMServiceExecuter.call("BNSPR_COMMON_GET_ACCOUNT_WITH_IBAN", hMap).getBigDecimal("ACCOUNT_NO"));
						kolasGuncellemeSilmeTx.setKimlikNo(kMap.getString(tableName, 0,"IDENTITY_NO"));
						kolasGuncellemeSilmeTx.setOncekiAdresTipi(kMap.getString(tableName, 0,"ADDRESS_TYPE"));
						kolasGuncellemeSilmeTx.setOncekiAdresDegeri(kMap.getString(tableName, 0,"ADDRESS_VALUE"));
						kolasGuncellemeSilmeTx.setAciklama(kMap.getString(tableName, 0,"DESCRIPTION"));

						session.saveOrUpdate(kolasGuncellemeSilmeTx);
						session.flush();     
						
						oMap.put("TRX_NO", trxNo);
					 }

		        return oMap;

			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} 
		}			

		@GraymoundService("BNSPR_TRN8301_GET_INFO")
		public static GMMap getTRN8301GetInfo(GMMap iMap) {
			try{
				Session session = DAOSession.getSession("BNSPRDal");
		                                                                  
				GMMap oMap=new GMMap();
		        
				KolasGuncellemeSilmeTx kolasGuncellemeSilmeTx = (KolasGuncellemeSilmeTx) session.load(KolasGuncellemeSilmeTx.class, iMap.getBigDecimal("TRX_NO"));	
				oMap.put("ISLEM", kolasGuncellemeSilmeTx.getIslem());
				oMap.put("MUSTERI_NO" 	        , kolasGuncellemeSilmeTx.getMusteriNo());
				oMap.put("IBAN", kolasGuncellemeSilmeTx.getIban());
				oMap.put("HESAP_NO", kolasGuncellemeSilmeTx.getHesapNo());
				oMap.put("ONCEKI_ADRES_TIPI", kolasGuncellemeSilmeTx.getOncekiAdresTipi());
				oMap.put("ONCEKI_ADRES_DEGERI", kolasGuncellemeSilmeTx.getOncekiAdresDegeri());
				oMap.put("ADRES_TIPI", kolasGuncellemeSilmeTx.getAdresTipi());
				oMap.put("ADRES_DEGERI", kolasGuncellemeSilmeTx.getAdresDegeri());
				oMap.put("ACIKLAMA", kolasGuncellemeSilmeTx.getAciklama());
				
		        return oMap;
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}

		@GraymoundService("BNSPR_TRN8301_SAVE")
		public static GMMap save(GMMap iMap) {
			try {

				Session session = DAOSession.getSession("BNSPRDal");
				KolasGuncellemeSilmeTx kolasGuncellemeSilmeTx = (KolasGuncellemeSilmeTx) session.get(KolasGuncellemeSilmeTx.class, iMap.getBigDecimal("TRX_NO"));
				if (kolasGuncellemeSilmeTx==null){
					kolasGuncellemeSilmeTx = new KolasGuncellemeSilmeTx();
					kolasGuncellemeSilmeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				}
				
				kolasGuncellemeSilmeTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				kolasGuncellemeSilmeTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
				kolasGuncellemeSilmeTx.setIban(iMap.getString("IBAN"));
				kolasGuncellemeSilmeTx.setAdresTipi(iMap.getString("ADRES_TIPI"));
				kolasGuncellemeSilmeTx.setAdresDegeri(iMap.getString("ADRES_DEGERI"));
				kolasGuncellemeSilmeTx.setAciklama(iMap.getString("ACIKLAMA"));
				kolasGuncellemeSilmeTx.setDurum("EKLENDI");
				
				session.saveOrUpdate(kolasGuncellemeSilmeTx);
				session.flush();

				iMap.put("TRX_NAME", "8301");

				GMMap oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} 
		}		

		@GraymoundService("BNSPR_TRN8301_AFTER_APPROVAL")
		public static GMMap afterApproval(GMMap iMap) {

			GMMap oMap = new GMMap();
			GMMap iMap2 = new GMMap();
			
			try {
				Session session = DAOSession.getSession("BNSPRDal"); 
				KolasGuncellemeSilmeTx kolasGuncellemeSilmeTx = (KolasGuncellemeSilmeTx) session.get(KolasGuncellemeSilmeTx.class, iMap.getBigDecimal("ISLEM_NO"));
				session.refresh(kolasGuncellemeSilmeTx);

				if ("G".equals(kolasGuncellemeSilmeTx.getIslem())) {
					iMap2.put("IDENTITY_NO", kolasGuncellemeSilmeTx.getKimlikNo());
				    iMap2.put("OLD_ADDRESS_TYPE", kolasGuncellemeSilmeTx.getOncekiAdresTipi());
				    iMap2.put("OLD_ADDRESS_VALUE", kolasGuncellemeSilmeTx.getOncekiAdresDegeri());
					iMap2.put("ADDRESS_TYPE", kolasGuncellemeSilmeTx.getAdresTipi());
					iMap2.put("ADDRESS_VALUE", kolasGuncellemeSilmeTx.getAdresDegeri());
					iMap2.put("ACCOUNT_NO", kolasGuncellemeSilmeTx.getIban());
					iMap2.put("ACCOUNT_TYPE", kolasGuncellemeSilmeTx.getHesapTipi());
					iMap2.put("TRADE_NAME", kolasGuncellemeSilmeTx.getTicariUnvan());
					iMap2.put("INFORM_CHANNEL", kolasGuncellemeSilmeTx.getBildirimKanali());
					iMap2.put("DESCRIPTION", kolasGuncellemeSilmeTx.getAciklama());
				
					oMap = GMServiceExecuter.call("BNSPR_KOLAS_UPDATE_ADDRESS", iMap2);
					
					kolasGuncellemeSilmeTx.setSistemReferansi(oMap.getBigDecimal("REF_NO"));
					kolasGuncellemeSilmeTx.setKayitStatusu(oMap.getBigDecimal("RECORD_STATUS").byteValue());
					kolasGuncellemeSilmeTx.setOlusturmaZamani(oMap.getString("CREATE_DATE"));
					kolasGuncellemeSilmeTx.setSonGuncellemeZamani(oMap.getString("LAST_MODIFIED_DATE"));
					
					session.saveOrUpdate(kolasGuncellemeSilmeTx);
					session.flush();
				}
				else {
					iMap2.put("ADDRESS_TYPE", kolasGuncellemeSilmeTx.getOncekiAdresTipi());
					iMap2.put("ADDRESS_VALUE", kolasGuncellemeSilmeTx.getOncekiAdresDegeri());
					
					oMap = GMServiceExecuter.call("BNSPR_KOLAS_DELETE_ADDRESS", iMap2);
				}
				
				return oMap;

			} 
		     catch(GMRuntimeException e){
		            GMMap iMapExp=new GMMap();
		            iMapExp.put("P1", ((GMRuntimeException)e).getMessage());
		            iMapExp.put("HATA_NO", "6208"); 
		           return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMapExp);
		        } 
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} 
		}		

		@GraymoundService("BNSPR_KOLAS_ALICI_SORGULA")
		public static GMMap kolasAliciSorgula(GMMap iMap) {
			GMMap oMap = new GMMap();
			Connection conn = null;
			CallableStatement stmt = null;

			try{
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{ ? = call pkg_trn8300.musteri_identity_no(?) }");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));

				stmt.execute();

				iMap.put("SENDER_IDENTITY_NO", stmt.getObject(1)); 
				iMap.put("ADDRESS_TYPE", iMap.getString("ADRES_TIPI"));
				iMap.put("ADDRESS_VALUE", iMap.getString("ADRES_DEGERI"));
				
				oMap = GMServiceExecuter.call("BNSPR_KOLAS_QUERY_RECIPIENT", iMap);

			return oMap;

			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}

		@GraymoundService("BNSPR_TRN8301_ONAYDA_BEKLEYEN_ISLEM_VAR_MI")
		public static GMMap onaydaBekleyenIslemVarMi(GMMap iMap) {
			Connection conn = null;
			CallableStatement stmt = null;
			try {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{ call PKG_TRN8301.onayda_bekleyen_kontrol(?)}");
				int i = 0;			
				stmt.setBigDecimal	(++i, iMap.getBigDecimal("MUSTERI_NO"));			
				stmt.execute();
				
				return new GMMap();
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}		
}