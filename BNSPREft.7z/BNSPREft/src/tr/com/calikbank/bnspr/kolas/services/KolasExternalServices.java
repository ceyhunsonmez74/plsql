package tr.com.calikbank.bnspr.kolas.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class KolasExternalServices {

	@GraymoundService("BNSPR_EXT_KOLAS_ADD_ADDRESS")
	public static GMMap extKolasAddAdress(GMMap iMap) {
		GMMap oMap = new GMMap();
		
	    try{
	    	GMMap xMap = new GMMap();

  		    BigDecimal trxNo = GMServiceExecuter.call("BNSPR_TRX_GET_TRANSACTION_NO", new GMMap()).getBigDecimal("TRX_NO");

			xMap.put("TRX_NO", trxNo);	    	
	        xMap.put("MUSTERI_NO", iMap.getBigDecimal("CUSTOMER_NO"));
	        xMap.put("IBAN", iMap.getString("IBAN"));
	        xMap.put("ADRES_TIPI", iMap.getString("ADDRESS_TYPE"));
	        xMap.put("ADRES_DEGERI", iMap.getString("ADDRESS_VALUE"));
	        xMap.put("ACIKLAMA", iMap.getString("DESCRIPTION"));
	        
	        oMap = GMServiceExecuter.call("BNSPR_TRN8300_SAVE", xMap);
	        
	        return oMap;
			
	    }
	     catch(GMRuntimeException e){
            GMMap iMapExp=new GMMap();
            iMapExp.put("P1", ((GMRuntimeException)e).getMessage());
            iMapExp.put("HATA_NO", "6208"); 
           return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMapExp);
        } 
	     catch (Exception e) {
	        throw ExceptionHandler.convertException(e);
	    }
	}	

	@GraymoundService("BNSPR_EXT_KOLAS_ADDRESS_LIST")
	public static GMMap kolasAdressList(GMMap iMap) {
		GMMap oMap = new GMMap();
		
	    try{
	        iMap.put("MUSTERI_NO", iMap.getBigDecimal("CUSTOMER_NO"));
	        
	        oMap = GMServiceExecuter.call("BNSPR_MUSTERI_KOLAS_SORGULA", iMap);
	        return oMap;
			
	    }
	     catch(GMRuntimeException e){
	            GMMap iMapExp=new GMMap();
	            iMapExp.put("P1", ((GMRuntimeException)e).getMessage());
	            iMapExp.put("HATA_NO", "6208"); 
	           return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMapExp);
	        } 
	    catch (Exception e) {
	        throw ExceptionHandler.convertException(e);
	    }
	}	

	@GraymoundService("BNSPR_EXT_KOLAS_UPDATE_ADDRESS")
	public static GMMap extKolasUpdateAdress(GMMap iMap) {
		GMMap oMap = new GMMap();
		
	    try{
	    	GMMap xMap = new GMMap();
	    	GMMap gMap = new GMMap();

	    	xMap.put("MUSTERI_NO", iMap.getBigDecimal("CUSTOMER_NO"));
	    	xMap.put("REF_NO", iMap.getBigDecimal("REF_NO"));
	    	xMap.put("ISLEM", "G");

            xMap = GMServiceExecuter.call("BNSPR_KOLAS_GUNCEL_ISLEM", xMap);
            
            gMap.put("TRX_NO", xMap.getBigDecimal("TRX_NO"));
	    	gMap.put("MUSTERI_NO", iMap.getBigDecimal("CUSTOMER_NO"));
	        gMap.put("IBAN", iMap.getString("IBAN"));
	        gMap.put("ADRES_TIPI", iMap.getString("ADDRESS_TYPE"));
	        gMap.put("ADRES_DEGERI", iMap.getString("ADDRESS_VALUE"));
	        gMap.put("ACIKLAMA", iMap.getString("DESCRIPTION"));
	        
	        oMap = GMServiceExecuter.call("BNSPR_TRN8301_SAVE", gMap);
	        
	        return oMap;
			
	    }
	     catch(GMRuntimeException e){
	            GMMap iMapExp=new GMMap();
	            iMapExp.put("P1", ((GMRuntimeException)e).getMessage());
	            iMapExp.put("HATA_NO", "6208"); 
	           return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMapExp);
	        } 
	    catch (Exception e) {
	        throw ExceptionHandler.convertException(e);
	    }
	}	
	
	@GraymoundService("BNSPR_EXT_KOLAS_DELETE_ADDRESS")
	public static GMMap extKolasDeleteAdress(GMMap iMap) {
		GMMap oMap = new GMMap();
		
	    try{
	    	GMMap xMap = new GMMap();
	    	GMMap gMap = new GMMap();

	    	xMap.put("MUSTERI_NO", iMap.getBigDecimal("CUSTOMER_NO"));
	    	xMap.put("REF_NO", iMap.getBigDecimal("REF_NO"));
	    	xMap.put("ISLEM", "S");

            xMap = GMServiceExecuter.call("BNSPR_KOLAS_GUNCEL_ISLEM", xMap);
            
            gMap = GMServiceExecuter.call("BNSPR_TRN8301_GET_INFO", xMap);
            gMap.put("TRX_NO", xMap.getBigDecimal("TRX_NO"));
	    /*	gMap.put("MUSTERI_NO", iMap.getBigDecimal("CUSTOMER_NO"));
	        gMap.put("IBAN", iMap.getString("IBAN"));
	        gMap.put("ADRES_TIPI", iMap.getString("ADDRESS_TYPE"));
	        gMap.put("ADRES_DEGERI", iMap.getString("ADDRESS_VALUE"));
	        gMap.put("ACIKLAMA", iMap.getString("DESCRIPTION")); */
	        
	        oMap = GMServiceExecuter.call("BNSPR_TRN8301_SAVE", gMap);
	        
	        return oMap;
			
	    }
	     catch(GMRuntimeException e){
	            GMMap iMapExp=new GMMap();
	            iMapExp.put("P1", ((GMRuntimeException)e).getMessage());
	            iMapExp.put("HATA_NO", "6208"); 
	           return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMapExp);
	        } 
	    catch (Exception e) {
	        throw ExceptionHandler.convertException(e);
	    }
	}
	
	@GraymoundService("BNSPR_GET_CUSTOMER_DETAILS_FOR_KOLAS")
	public static GMMap getCustomerForKolas(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN8300.RC_KOLAS_MUSTERI_BILGI(?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
  		    stmt.setBigDecimal(i++, iMap.getBigDecimal("CUSTOMER_NO"));
			stmt.execute();

			GMMap oMap = new GMMap();
			
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "MUSTERI_DETAY";
			
			oMap = DALUtil.rSetResults(rSet, tableName);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
	
	@GraymoundService("BNSPR_EXT_KOLAS_GET_RECIPIENT")
	public static GMMap extKolasGetRecipient(GMMap iMap) {
		GMMap oMap = new GMMap();
		GMMap gMap = new GMMap();
	     try {
	        gMap.put("MUSTERI_NO", iMap.getBigDecimal("CUSTOMER_NO"));
	        gMap.put("ADRES_TIPI", iMap.getString("ADDRESS_TYPE"));
	        gMap.put("ADRES_DEGERI", iMap.getString("ADDRESS_VALUE"));
			
			oMap = GMServiceExecuter.call("BNSPR_KOLAS_ALICI_SORGULA", gMap);	
			return oMap;
		}
	     catch(GMRuntimeException e){
	            GMMap iMapExp=new GMMap();
	            iMapExp.put("P1", ((GMRuntimeException)e).getMessage());
	            iMapExp.put("HATA_NO", "6208"); 
	           return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMapExp);
	        } 
	     catch (Exception e) {
			throw ExceptionHandler.convertException(e);
	      } 
	}
	
	@GraymoundService("BNSPR_EXT_KOLAS_AUTH_REQUIRED")
	public static GMMap extKolasAuthRequired(GMMap iMap) {
	   GMMap oMap = new GMMap();
	   oMap.put("RESULT", DALUtil.callOneParameterFunction("{? = call pkg_trn8300.KOLAS_MUSTERI_BLG_GEREKLIMI(?)}", Types.VARCHAR, iMap.getBigDecimal("CUSTOMER_NO")));
		return oMap;	  
    } 
	
}
