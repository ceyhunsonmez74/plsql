package tr.com.calikbank.bnspr.kolas.services;

import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.log4j.Logger;

import tr.com.aktifbank.integration.KasboxClient;
import tr.com.aktifbank.integration.kasbox.kolas.AccountType;
import tr.com.aktifbank.integration.kasbox.kolas.AddressType;
import tr.com.aktifbank.integration.kasbox.kolas.AdresEkleRequest;
import tr.com.aktifbank.integration.kasbox.kolas.AdresEkleResponse;
import tr.com.aktifbank.integration.kasbox.kolas.AdresGuncelleRequest;
import tr.com.aktifbank.integration.kasbox.kolas.AdresGuncelleResponse;
import tr.com.aktifbank.integration.kasbox.kolas.AdresSilRequest;
import tr.com.aktifbank.integration.kasbox.kolas.AdresSilResponse;
import tr.com.aktifbank.integration.kasbox.kolas.AdresSorgulaRequest;
import tr.com.aktifbank.integration.kasbox.kolas.AdresSorgulaResponse;
import tr.com.aktifbank.integration.kasbox.kolas.AliciSorgulaRequest;
import tr.com.aktifbank.integration.kasbox.kolas.AliciSorgulaResponse;
import tr.com.aktifbank.integration.kasbox.kolas.InformChannel;
import tr.com.aktifbank.integration.kasbox.kolas.ProxyAccount;
import tr.com.aktifbank.integration.kasbox.kolas.TasinanAdresSorgulaRequest;
import tr.com.aktifbank.integration.kasbox.kolas.TasinanAdresSorgulaResponse;
import tr.com.aktifbank.log.util.Constants;
import tr.com.obss.adc.core.services.transaction.ServiceExecutorUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class KolasServices {
	
	private static final Logger logger = Logger.getLogger(KolasServices.class);
	
	@GraymoundService("BNSPR_KOLAS_ADD_ADDRESS")
	public static GMMap adresEkle(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			AdresEkleRequest request=new AdresEkleRequest();
			request.setIdentityNo(iMap.getString(Keys.IDENTITY_NO.name()));
			request.setAddressType(AddressType.fromValue(iMap.getString(Keys.ADDRESS_TYPE.name())));
			request.setAddressValue(iMap.getString(Keys.ADDRESS_VALUE.name()));
			request.setAccountOwner(iMap.getString(Keys.ACCOUNT_OWNER.name()));
			request.setAccountNo(iMap.getString(Keys.ACCOUNT_NO.name()));
			request.setAccountType(AccountType.fromValue(iMap.getString(Keys.ACCOUNT_TYPE.name())));
			request.setTrxId(getCoreTrxId());
			
			if(iMap.containsKey(Keys.TRADE_NAME.name()) || request.getAccountType()==AccountType.T){
				request.setTradeName(iMap.getString(Keys.TRADE_NAME.name()));
			}
			if(iMap.containsKey(Keys.INFORM_CHANNEL.name())){
				request.setInformChannel(InformChannel.fromValue(iMap.getString(Keys.INFORM_CHANNEL.name())));
			}
			if(iMap.containsKey(Keys.DESCRIPTION.name())){
				request.setDescription(iMap.getString(Keys.DESCRIPTION.name()));
			}
			
			AdresEkleResponse response=KasboxClient.getKolasClient().adresEkle(request);
			
			oMap.put(Keys.REF_NO.name(),			response.getSystemRefNo());
			oMap.put(Keys.RECORD_STATUS.name(),		response.getRecordStatus());
			oMap.put(Keys.CREATE_DATE.name(),		toStringFromXMLGreCal(response.getCreatedDate()));
			oMap.put(Keys.LAST_MODIFIED_DATE.name(),toStringFromXMLGreCal(response.getLastModifiedDate()));
		}
		catch (Exception exp) {
			logger.error("Kolas Adres Ekle Exp:",exp);
			throw new GMRuntimeException(0, exp.getMessage());
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_KOLAS_UPDATE_ADDRESS")
	public static GMMap adresGuncelle(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			AdresGuncelleRequest request=new AdresGuncelleRequest();
			request.setOldAddressType(AddressType.fromValue(iMap.getString(Keys.OLD_ADDRESS_TYPE.name())));
			request.setOldAddressValue(iMap.getString(Keys.OLD_ADDRESS_VALUE.name()));
			request.setAddressType(AddressType.fromValue(iMap.getString(Keys.ADDRESS_TYPE.name())));
			request.setAddressValue(iMap.getString(Keys.ADDRESS_VALUE.name()));
			request.setAccountNo(iMap.getString(Keys.ACCOUNT_NO.name()));
			request.setAccountType(AccountType.fromValue(iMap.getString(Keys.ACCOUNT_TYPE.name())));
			request.setTrxId(getCoreTrxId());
			
			if(iMap.containsKey(Keys.TRADE_NAME.name()) || request.getAccountType()==AccountType.T){
				request.setTradeName(iMap.getString(Keys.TRADE_NAME.name()));
			}
			if(iMap.containsKey(Keys.INFORM_CHANNEL.name())){
				request.setInformChannel(InformChannel.fromValue(iMap.getString(Keys.INFORM_CHANNEL.name())));
			}
			if(iMap.containsKey(Keys.DESCRIPTION.name())){
				request.setDescription(iMap.getString(Keys.DESCRIPTION.name()));
			}
			
			AdresGuncelleResponse response=KasboxClient.getKolasClient().adresGuncelle(request);
			
			oMap.put(Keys.REF_NO.name(),			response.getSystemRefNo());
			oMap.put(Keys.RECORD_STATUS.name(),		response.getRecordStatus());
			oMap.put(Keys.CREATE_DATE.name(),		toStringFromXMLGreCal(response.getCreatedDate()));
			oMap.put(Keys.LAST_MODIFIED_DATE.name(),toStringFromXMLGreCal(response.getLastModifiedDate()));
		}
		catch (Exception exp) {
			logger.error("Kolas Adres Guncelleme Exp:",exp);
			throw new GMRuntimeException(0, exp.getMessage());
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_KOLAS_DELETE_ADDRESS")
	public static GMMap adresSil(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			AdresSilRequest request=new AdresSilRequest();
			request.setAddressType(AddressType.fromValue(iMap.getString(Keys.ADDRESS_TYPE.name())));
			request.setAddressValue(iMap.getString(Keys.ADDRESS_VALUE.name()));
			request.setTrxId(getCoreTrxId());
			
			AdresSilResponse response=KasboxClient.getKolasClient().adresSil(request);
			
			oMap.put(Keys.SUCCESS.name(), response.isSuccess());
		}
		catch (Exception exp) {
			logger.error("Kolas Adres Silme Exp:",exp);
			throw new GMRuntimeException(0, exp.getMessage());
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_KOLAS_QUERY_ADDRESS")
	public static GMMap adresSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			AdresSorgulaRequest request=new AdresSorgulaRequest();
			request.setTrxId(getCoreTrxId());
			
			if(iMap.containsKey(Keys.REF_NO.name())){
				request.setSystemRefNo(iMap.getString(Keys.REF_NO.name()));
				
			} else if(iMap.containsKey(Keys.IDENTITY_NO.name())){
				request.setIdentityNo(iMap.getString(Keys.IDENTITY_NO.name()));
				
			} else if(iMap.containsKey(Keys.ADDRESS_TYPE.name()) && iMap.containsKey(Keys.ADDRESS_VALUE.name())){
				request.setAddressType(iMap.getString(Keys.ADDRESS_TYPE.name()));
				request.setAddressValue(iMap.getString(Keys.ADDRESS_VALUE.name()));
			}
			
			AdresSorgulaResponse response=KasboxClient.getKolasClient().adresSorgula(request);
			
			List<ProxyAccount> accounts = response.getProxyAccount();
			int index = 0;
			for (ProxyAccount proxy:accounts) {
				loadAccountInfoToGMMap(oMap,Keys.ACCOUNTS.name(), index++, proxy);
			}
		}
		catch (Exception exp) {
			logger.error("Kolas Adres Sorgu Exp:",exp);
			throw new GMRuntimeException(0, exp.getMessage());
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_KOLAS_QUERY_RECIPIENT")
	public static GMMap aliciSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			AliciSorgulaRequest request=new AliciSorgulaRequest();
			request.setAddressType(AddressType.fromValue(iMap.getString(Keys.ADDRESS_TYPE.name())));
			request.setAddressValue(iMap.getString(Keys.ADDRESS_VALUE.name()));
			request.setSenderIdentityNo(iMap.getString(Keys.SENDER_IDENTITY_NO.name()));
			request.setTrxId(getCoreTrxId());
			
			AliciSorgulaResponse response=KasboxClient.getKolasClient().aliciSorgula(request);
			
			oMap.put(Keys.ACCOUNT_OWNER.name(), 		response.getAccountOwner());
			oMap.put(Keys.ACCOUNT_NO.name(), 			response.getAccountNo());
			oMap.put(Keys.ACCOUNT_TYPE.name(),			response.getAccountType().value());
			oMap.put(Keys.TRADE_NAME.name(), 			response.getTradeName());
			oMap.put(Keys.REF_NO.name(), 				response.getQueryRefNo());
			oMap.put(Keys.ACCOUNT_OWNER_MASKED.name(), 	response.getAccountOwnerMasked());
			oMap.put(Keys.ACCOUNT_NO_MASKED.name(), 	getMaskedAccountNo(response.getAccountNo()));
			oMap.put(Keys.TRADE_NAME_MASKED.name(), 	response.getTradeNameMasked());
		}
		catch (Exception exp) {
			logger.error("Kolas Alici Sorgu Exp:",exp);
			throw new GMRuntimeException(0, exp.getMessage());
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_KOLAS_QUERY_MOVED_ADDRESS")
	public static GMMap tasinanAdresSorgula(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			TasinanAdresSorgulaRequest request=new TasinanAdresSorgulaRequest();
			request.setTransferStartDate(toXMLGregorianCalendar(iMap.getDate(Keys.START_DATE.name())));
			request.setTransferEndDate(toXMLGregorianCalendar(iMap.getDate(Keys.END_DATE.name())));
			request.setTrxId(getCoreTrxId());
			
			if(iMap.containsKey(Keys.SIZE.name())){
				request.setSize(iMap.getString(Keys.SIZE.name()));
			}
			if(iMap.containsKey(Keys.PAGE.name())){
				request.setPage(iMap.getString(Keys.PAGE.name()));
			}
			
			TasinanAdresSorgulaResponse response=KasboxClient.getKolasClient().tasinanAdresSorgula(request);
			List<ProxyAccount> accounts = response.getProxyAccount();
			int index = 0;
			for (ProxyAccount proxy:accounts) {
				loadAccountInfoToGMMap(oMap,Keys.ACCOUNTS.name(), index++, proxy);
			}
		}
		catch (Exception exp) {
			logger.error("Kolas Tasinan Adres Sorgu Exp:",exp);
			throw new GMRuntimeException(0, exp.getMessage());
		}
		return oMap;
	}
	
	private static String getCoreTrxId(){
		HashMap<String, Object> threadTrxInfoMap=ServiceExecutorUtil.getThreadInfo();
		return String.valueOf(ServiceExecutorUtil.getThreadInfoData(threadTrxInfoMap,Constants.CORE_TRX_ID_RESERVED));
	}
	
	private static void loadAccountInfoToGMMap(GMMap oMap, String name, int index, ProxyAccount proxy){
		oMap.put(name, index, Keys.REF_NO.name(), 			proxy.getSystemRefNo());
		oMap.put(name, index, Keys.IDENTITY_NO.name(), 		proxy.getIdentityNo());
		oMap.put(name, index, Keys.ADDRESS_TYPE.name(), 	proxy.getAddressType().value());
		oMap.put(name, index, Keys.ADDRESS_VALUE.name(), 	proxy.getAddressValue());
		oMap.put(name, index, Keys.ACCOUNT_OWNER.name(), 	proxy.getAccountOwner());
		oMap.put(name, index, Keys.ACCOUNT_NO.name(), 		proxy.getAccountNo());
		oMap.put(name, index, Keys.ACCOUNT_TYPE.name(), 	proxy.getAccountType().value());
		oMap.put(name, index, Keys.TRADE_NAME.name(), 		proxy.getTradeName());
		oMap.put(name, index, Keys.INFORM_CHANNEL.name(), 	proxy.getInformChannel().value());
		oMap.put(name, index, Keys.DESCRIPTION.name(), 		proxy.getDescription());
		oMap.put(name, index, Keys.RECORD_STATUS.name(), 	proxy.getRecordStatus());
		oMap.put(name, index, Keys.CREATE_DATE.name(), 		toStringFromXMLGreCal(proxy.getCreatedDate()));
		oMap.put(name, index, Keys.LAST_MODIFIED_DATE.name(), toStringFromXMLGreCal(proxy.getLastModifiedDate()));
	}
	
	private static String toStringFromXMLGreCal(XMLGregorianCalendar calendar){
		return calendar!=null?calendar.toString():null;
	}
	private static XMLGregorianCalendar toXMLGregorianCalendar(Date date) throws DatatypeConfigurationException {
		GregorianCalendar calendar=new GregorianCalendar();
		calendar.setTime(date);
		return  DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar);
	}
	private static String getMaskedAccountNo(String accountNo){
		if(accountNo!=null && accountNo.length()>0){
			return accountNo.replaceAll("(.{4})(.*)(.{4})", "$1******************$3");
		}
		return accountNo;
	}
	
	private enum Keys {
		ACCOUNTS,
		IDENTITY_NO,
		SENDER_IDENTITY_NO,
		ADDRESS_TYPE,
		ADDRESS_VALUE,
		ACCOUNT_OWNER,
		ACCOUNT_OWNER_MASKED,
		ACCOUNT_NO,
		ACCOUNT_NO_MASKED,
		ACCOUNT_TYPE,
		TRADE_NAME,
		TRADE_NAME_MASKED,
		INFORM_CHANNEL,
		DESCRIPTION,
		OLD_ADDRESS_TYPE,
		OLD_ADDRESS_VALUE,
		START_DATE,
		END_DATE,
		SUCCESS,
		REF_NO,
		RECORD_STATUS,
		CREATE_DATE,
		LAST_MODIFIED_DATE,
		SIZE,
		PAGE
	}
	
}

