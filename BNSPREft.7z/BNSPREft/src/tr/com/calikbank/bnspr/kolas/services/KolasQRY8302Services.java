package tr.com.calikbank.bnspr.kolas.services;


import java.text.SimpleDateFormat;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class KolasQRY8302Services {
	@GraymoundService("BNSPR_KOLAS_TASINAN_ADRES_SORGULA")
	public static GMMap getKolasTasinanAdresler(GMMap iMap) {
	                                                                  
		GMMap oMap = new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		try {
        	if (!(iMap.getDate("BAS_TARIH") == null)) {
					iMap.put("START_DATE", new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			} else {
					iMap.put("START_DATE", sdf.format(new java.util.Date()));
			}
			if (!(iMap.getDate("BIT_TARIH") == null)) {
				iMap.put("END_DATE" , new java.sql.Date(iMap.getDate("BIT_TARIH").getTime()));
			} else {
				iMap.put("END_DATE" , sdf.format(new java.util.Date()));
			}
			
            iMap.put("ACCOUNTS", GMServiceExecuter.call("BNSPR_KOLAS_QUERY_MOVED_ADDRESS", iMap).get("ACCOUNTS"));
            for (int i = 0; i < iMap.getSize("ACCOUNTS"); i++) {
                oMap.put("ACCOUNTS", i, "REF_NO", iMap.getString("ACCOUNTS", i, "REF_NO"));
                oMap.put("ACCOUNTS", i, "ACCOUNT_NO", iMap.getString("ACCOUNTS", i, "ACCOUNT_NO"));
                oMap.put("ACCOUNTS", i, "ADDRESS_TYPE", iMap.getString("ACCOUNTS", i, "ADDRESS_TYPE"));
                oMap.put("ACCOUNTS", i, "ADDRESS_VALUE", iMap.getString("ACCOUNTS", i, "ADDRESS_VALUE"));
                oMap.put("ACCOUNTS", i, "IDENTITY_NO", iMap.getString("ACCOUNTS", i, "IDENTITY_NO"));
                oMap.put("ACCOUNTS", i, "DESCRIPTION", iMap.getString("ACCOUNTS", i, "DESCRIPTION"));
                oMap.put("ACCOUNTS", i, "RECORD_STATUS", iMap.getString("ACCOUNTS", i, "RECORD_STATUS"));
                oMap.put("ACCOUNTS", i, "ACCOUNT_OWNER", iMap.getString("ACCOUNTS", i, "ACCOUNT_OWNER"));
                oMap.put("ACCOUNTS", i, "LAST_MODIFIED_DATE", iMap.getString("ACCOUNTS", i, "LAST_MODIFIED_DATE"));
                oMap.put("ACCOUNTS", i, "CREATE_DATE", iMap.getString("ACCOUNTS", i, "CREATE_DATE"));
                oMap.put("ACCOUNTS", i, "INFORM_CHANNEL", iMap.getString("ACCOUNTS", i, "INFORM_CHANNEL"));
                oMap.put("ACCOUNTS", i, "TRADE_NAME", iMap.getString("ACCOUNTS", i, "TRADE_NAME"));
                
                
            }
			

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}


