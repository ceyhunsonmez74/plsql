package tr.com.calikbank.bnspr.kolas.services;


import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class KolasQRY8303Services {
	@GraymoundService("BNSPR_KOLAS_ADRES_ISLEMLERI_SORGULA")
	public static GMMap getKolasTasinanAdresler(GMMap iMap) {
		
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();

		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc8303.RC_QRY1083(?,?,?)}");
			stmt.registerOutParameter(1, -10); //ref cursor
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));		

			if (!(iMap.getDate("BAS_TARIH") == null)) {
				stmt.setDate(3, new java.sql.Date(iMap.getDate("BAS_TARIH").getTime()));
			} else {
				stmt.setDate(3, null);
			}
			if (!(iMap.getDate("BIT_TARIH") == null)) {
				stmt.setDate(4,  new java.sql.Date(iMap.getDate("BIT_TARIH").getTime()));
			} else {
				stmt.setDate(4, null);
			}
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);

			String tableName = "ISLEM_LIST";
			
			oMap = DALUtil.rSetResults(rSet, tableName);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
}


