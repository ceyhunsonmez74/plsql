package tr.com.calikbank.bnspr.kolas.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.KolasTanimTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class KolasTRN8300Services {

		@GraymoundService("BNSPR_TRN8300_SAVE")
		public static GMMap save(GMMap iMap) {
			try {

				Session session = DAOSession.getSession("BNSPRDal");
				KolasTanimTx kolasTanimTx = (KolasTanimTx) session.get(KolasTanimTx.class, iMap.getBigDecimal("TRX_NO"));
				if (kolasTanimTx==null){
					kolasTanimTx = new KolasTanimTx();
					kolasTanimTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				}
				
				kolasTanimTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
				kolasTanimTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
				kolasTanimTx.setIban(iMap.getString("IBAN"));
				kolasTanimTx.setAdresTipi(iMap.getString("ADRES_TIPI"));
				kolasTanimTx.setAdresDegeri(iMap.getString("ADRES_DEGERI"));
				kolasTanimTx.setAciklama(iMap.getString("ACIKLAMA"));
				kolasTanimTx.setDurum("EKLENDI");
				
				session.saveOrUpdate(kolasTanimTx);
				session.flush();

				iMap.put("TRX_NAME", "8300");

				GMMap oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} 
		}
		
		@GraymoundService("BNSPR_TRN8300_GET_INFO")
		public static GMMap getTRN8300GetInfo(GMMap iMap) {
			try{
				Session session = DAOSession.getSession("BNSPRDal");
		                                                                  
				GMMap oMap=new GMMap();
		        
				KolasTanimTx kolasTanimTx = (KolasTanimTx) session.load(KolasTanimTx.class, iMap.getBigDecimal("TRX_NO"));	
				oMap.put("MUSTERI_NO" 	        , kolasTanimTx.getMusteriNo());
				oMap.put("IBAN", kolasTanimTx.getIban());
				BigDecimal accountNo = BigDecimal.ZERO;

				if (iMap.getBigDecimal("HESAP_NO")==null) {
					GMMap hMap = new GMMap();
					hMap.put("IBAN", kolasTanimTx.getIban());
					accountNo = GMServiceExecuter.call("BNSPR_COMMON_GET_ACCOUNT_WITH_IBAN", hMap).getBigDecimal("ACCOUNT_NO");
				}
				else
					accountNo = kolasTanimTx.getHesapNo();
				
				oMap.put("HESAP_NO", accountNo);
				oMap.put("ADRES_TIPI", kolasTanimTx.getAdresTipi());
				oMap.put("ADRES_DEGERI", kolasTanimTx.getAdresDegeri());
				oMap.put("ACIKLAMA", kolasTanimTx.getAciklama());
				
		        return oMap;
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}

		@GraymoundService("BNSPR_TRN8300_AFTER_APPROVAL")
		public static GMMap afterApproval(GMMap iMap) {

			GMMap oMap = new GMMap();
			GMMap iMap2 = new GMMap();
			
			try {
				
				Session session = DAOSession.getSession("BNSPRDal"); 
				KolasTanimTx kolasTanimTx = (KolasTanimTx) session.get(KolasTanimTx.class, iMap.getBigDecimal("ISLEM_NO")); 
				session.refresh(kolasTanimTx);
				iMap2.put("IDENTITY_NO", kolasTanimTx.getKimlikNo());
				iMap2.put("ADDRESS_TYPE", kolasTanimTx.getAdresTipi());
				iMap2.put("ADDRESS_VALUE", kolasTanimTx.getAdresDegeri());
				iMap2.put("ACCOUNT_OWNER", kolasTanimTx.getAdSoyadUnvan());
				iMap2.put("ACCOUNT_NO", kolasTanimTx.getIban());
				iMap2.put("ACCOUNT_TYPE", kolasTanimTx.getHesapTipi());
				iMap2.put("TRADE_NAME", kolasTanimTx.getTicariUnvan());
				iMap2.put("INFORM_CHANNEL", kolasTanimTx.getBildirimKanali());
				iMap2.put("DESCRIPTION", kolasTanimTx.getAciklama());
				
				oMap = GMServiceExecuter.call("BNSPR_KOLAS_ADD_ADDRESS", iMap2);
				
				kolasTanimTx.setSistemReferansi(oMap.getBigDecimal("REF_NO"));
				kolasTanimTx.setKayitStatusu(oMap.getBigDecimal("RECORD_STATUS").byteValue());
				kolasTanimTx.setOlusturmaZamani(oMap.getString("CREATE_DATE"));
				kolasTanimTx.setSonGuncellemeZamani(oMap.getString("LAST_MODIFIED_DATE"));
				
				session.saveOrUpdate(kolasTanimTx);
				session.flush();
				
				return oMap;

			} 
		     catch(GMRuntimeException e){
		            GMMap iMapExp=new GMMap();
		            iMapExp.put("P1", ((GMRuntimeException)e).getMessage());
		            iMapExp.put("HATA_NO", "6208"); 
		           return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", iMapExp);
		        } 
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} 
		}		
		
}