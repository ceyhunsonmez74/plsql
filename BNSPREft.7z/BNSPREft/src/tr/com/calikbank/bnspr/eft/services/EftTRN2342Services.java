package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2342Services {
	@GraymoundService("BNSPR_TRN2342_GET_EFT_INFO")
	public static GMMap getEftInfo(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			EftEftTx eftEftTx = (EftEftTx) session.load(EftEftTx.class, iMap
					.getBigDecimal("TRX_NO"));

			GMMap oMap = new GMMap();

			oMap.put("TRX_NO", eftEftTx.getTxNo());
			oMap.put("MESAJ_KODU", eftEftTx.getMesajKodu());
			oMap.put("GELEN_GIDEN", eftEftTx.getGelenGiden());
			oMap.put("SORGU_NO", eftEftTx.getSorguNo());
			oMap.put("DURUM", eftEftTx.getDurum());
			oMap.put("EFT_TARIH", eftEftTx.getEftTarih());
			oMap.put("ONCELIK", eftEftTx.getOncelik().toString());
			oMap.put("GONDEREN_BANKA", eftEftTx.getGonderenBanka());
			oMap.put("GONDEREN_SUBE", eftEftTx.getGonderenSube());
			oMap.put("GONDEREN_SEHIR", eftEftTx.getGonderenSehir());
			oMap.put("ALAN_BANKA_KODU", eftEftTx.getAlanBankaKodu());
			oMap.put("ALAN_SEHIR_KODU", eftEftTx.getAlanSehirKodu());
			oMap.put("ALAN_SUBE_KODU", eftEftTx.getAlanSubeKodu());
			oMap.put("BANKA_KODU", eftEftTx.getBankaKodu());
			oMap.put("BANKA_ADI", eftEftTx.getBankaAdi());
			oMap.put("KULLANILABILIRLIK_GOSTERGESI", eftEftTx
					.getKullanilabilirlikGostergesi());
			oMap.put("SEHIR_ADI", eftEftTx.getSehirAdi());
			oMap.put("ADRES_SATIRI_ACIKLAMA_1", eftEftTx
					.getAdresSatiriAciklama1());
			oMap.put("ADRES_SATIRI_ACIKLAMA_2", eftEftTx
					.getAdresSatiriAciklama2());
			oMap.put("ADRES_SATIRI_ACIKLAMA_3", eftEftTx
					.getAdresSatiriAciklama3());
			oMap.put("ISLEM_TURU", eftEftTx.getIslemTuru());
			oMap.put("DUZELTME_TURU", eftEftTx.getDuzeltmeTuru());

			oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(),
					eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(),
					eftEftTx.getAlanBankaKodu(), eftEftTx.getAlanSubeKodu(),
					eftEftTx.getAlanSehirKodu()));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}



}
