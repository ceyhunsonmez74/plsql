package tr.com.calikbank.bnspr.eft.services;

import java.awt.Color;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EftOtomatikHesapTanimTx;
import tr.com.aktifbank.bnspr.dao.EftOtomatikHesapTanimTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlDuzenliOdemeSaatPr;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2303Services {
	
	@GraymoundService("BNSPR_TRN2302_GET_DUZENLI_ODEME_SAAT")
	public static GMMap  getOdemeSaatleri(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			ArrayList<?> odemeSaatList = (ArrayList<?>)session.createCriteria(GnlDuzenliOdemeSaatPr.class).addOrder(Order.asc("numara")).list();
			
			String tableName = "ODEME_SAAT_LIST";
			int row = 0;
			for (Iterator<?> iterator = odemeSaatList.iterator(); iterator.hasNext();row++) {
				GnlDuzenliOdemeSaatPr duzenliOdemeSaat = (GnlDuzenliOdemeSaatPr) iterator.next();
				oMap.put(tableName, row, "NUMARA", duzenliOdemeSaat.getNumara());
				oMap.put(tableName, row, "ODEME_SAAT", duzenliOdemeSaat.getOdemeSaat());
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2302_SAVE_DUZENLI_ODEME_SAAT")
	public static Map<?,?> saveOdemeSaatleri(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal");
			
			ArrayList<?> odemeSaatList = (ArrayList<?>)session.createCriteria(GnlDuzenliOdemeSaatPr.class).list();
			for (Iterator<?> iterator = odemeSaatList.iterator(); iterator.hasNext();) {
				GnlDuzenliOdemeSaatPr duzenliOdemeSaat = (GnlDuzenliOdemeSaatPr) iterator.next();
				session.delete(duzenliOdemeSaat);
			}
			session.flush();
			
			String tableName = "DUZENLI_ODEME_SAAT";
			int row = 0;
			ArrayList<?> odemeSaatInList = (ArrayList<?>)iMap.get(tableName);
			for (Iterator<?> iterator = odemeSaatInList.iterator(); iterator.hasNext();row++) {
				GnlDuzenliOdemeSaatPr duzenliOdemeSaat = new GnlDuzenliOdemeSaatPr();
				duzenliOdemeSaat.setNumara(iMap.getBigDecimal(tableName, row, "NUMARA"));
				duzenliOdemeSaat.setOdemeSaat(iMap.getString(tableName, row, "ODEME_SAAT"));
				session.save(duzenliOdemeSaat);
			}
			session.flush();
			
			oMap.put("MESSAGE", "��leminiz Tamamlanm��t�r");
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	   @GraymoundService("BNSPR_TRN2303_GET_RECORDS")
	    public static GMMap getRecords(GMMap iMap){
	        Connection conn = null;
	        CallableStatement stmt = null;
	        ResultSet rSet = null;
	        
	        try{
	            conn = DALUtil.getGMConnection();	            
	            stmt = conn.prepareCall("{? = call pkg_trn2303.RC_2303 }");
	            int i = 1;
	            stmt.registerOutParameter(i++, -10);
	            stmt.execute();            
	           rSet = (ResultSet) stmt.getObject(1);
	            
	           return DALUtil.rSetResults(rSet, "RECORD_LIST");
	        }catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        }finally{
	            GMServerDatasource.close(rSet);
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(conn);
	        }
	    }
	   
	   @GraymoundService("BNSPR_TRN2303_SAVE_RECORDS")
	    public static Map<?, ?> save(GMMap iMap) {

	        try {
	            Session session = DAOSession.getSession("BNSPRDal");	         
                
                String tableName = "OTOMATIK_HESAP_LIST";
                List<?>  otomatikHesapList = (List<?>)iMap.get(tableName);
                for (int i = 0; i < otomatikHesapList.size(); i++) {

                    EftOtomatikHesapTanimTx eftOtomatikHesapTanimTx =  new EftOtomatikHesapTanimTx();         
                    EftOtomatikHesapTanimTxId eftOtomatikHesapTanimTxId = new EftOtomatikHesapTanimTxId();
                    eftOtomatikHesapTanimTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
                    eftOtomatikHesapTanimTxId.setHesapNo(iMap.getBigDecimal(tableName, i, "HESAP_NO"));
                    eftOtomatikHesapTanimTx.setId(eftOtomatikHesapTanimTxId);
                    eftOtomatikHesapTanimTx.setAliciIban(iMap.getString(tableName, i, "ALICI_IBAN"));
                    eftOtomatikHesapTanimTx.setAliciBankaKodu(iMap.getString(tableName, i, "ALICI_BANKA_KODU"));
                    eftOtomatikHesapTanimTx.setAliciAdi(iMap.getString(tableName, i, "ALICI_ADI"));
                    eftOtomatikHesapTanimTx.setAltLimit(iMap.getBigDecimal(tableName, i, "ALT_LIMIT"));
                    eftOtomatikHesapTanimTx.setAciklama(iMap.getString(tableName, i, "ACIKLAMA"));
                                        
                   //if("".equals(iMap.getString(tableName, i, "DURUM"))){
                   //     eftOtomatikHesapTanimTx.setDurum("G");
                   // }
                   // else{
                        eftOtomatikHesapTanimTx.setDurum(iMap.getString(tableName, i, "DURUM"));
                    //}
                    
                    session.saveOrUpdate(eftOtomatikHesapTanimTx);
                }
                session.flush();

	            iMap.put("TRX_NAME", "2303");

	            return GMServiceExecuter
	                    .execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        }

	    }
	   
	   @GraymoundService("BNSPR_TRN2303_GET_OTOMATIK_HESAP_BILGI")
	    public static GMMap getGelgonEftBilgi(GMMap iMap) {
	     //  Connection conn = null;
           //CallableStatement stmt = null;;
                          
	        try {
	            Session session = DAOSession.getSession("BNSPRDal");
	            GMMap oMap = new GMMap();
	            List<?> eftOtomatikHesapTanimTxList =  session
	                    .createCriteria(EftOtomatikHesapTanimTx.class).add(Restrictions.eq("id.txNo",  iMap.getBigDecimal("TRX_NO"))).addOrder(Order.asc("durum")).list();        
	            
	            String tableName = "OTOMATIK_HESAP_LIST";
	            //conn = DALUtil.getGMConnection();       
	            int row = 0;
	            if(eftOtomatikHesapTanimTxList != null){
	                
    	            for(Iterator<?> iterator = eftOtomatikHesapTanimTxList.iterator() ; iterator!=null ? iterator.hasNext() : false; row++ ){
    	                            
    	                EftOtomatikHesapTanimTx  eftOtomatikHesapTanimTx =  (EftOtomatikHesapTanimTx) iterator.next();    	
    	                GMMap mMap = new GMMap();
    	                mMap.put("HESAP_NO", eftOtomatikHesapTanimTx.getId().getHesapNo());
    	                mMap = GMServiceExecuter.call("BNSPR_COMMON_GET_MUSTERI_NO", mMap);
//    	                
//    	                stmt = conn.prepareCall("{? = call pkg_hesap.musteri_no(?,?) }");
//                        int i = 1;
//                        stmt.registerOutParameter(i++, Types.NUMERIC);
//                        stmt.setBigDecimal(i++, eftOtomatikHesapTanimTx.getId().getHesapNo());
//                        stmt.setString(i++, null);
//                        stmt.execute();            
//                      
                        oMap.put(tableName, row , "MUSTERI_NO", mMap.getBigDecimal("MUSTERI_NO"));
    	                oMap.put(tableName, row , "HESAP_NO", eftOtomatikHesapTanimTx.getId().getHesapNo());
    	                oMap.put(tableName, row , "ALICI_IBAN", eftOtomatikHesapTanimTx.getAliciIban());
    	                oMap.put(tableName, row , "ALICI_BANKA_KODU", eftOtomatikHesapTanimTx.getAliciBankaKodu());
    	                oMap.put(tableName, row , "ALICI_ADI", eftOtomatikHesapTanimTx.getAliciAdi());
    	                oMap.put(tableName, row , "ALT_LIMIT", eftOtomatikHesapTanimTx.getAltLimit());
    	                oMap.put(tableName, row , "DURUM", eftOtomatikHesapTanimTx.getDurum());
    	                oMap.put(tableName, row , "ACIKLAMA", eftOtomatikHesapTanimTx.getAciklama());
    	                   if( "I".equals(eftOtomatikHesapTanimTx.getDurum()))
                               oMap.put(tableName, row , "SIL", true);
                           else
                               oMap.put(tableName, row , "SIL", false);
    	            }
    	            GMMap color1 = new GMMap();
    				color1.put("setBackground", Color.LIGHT_GRAY);
    				color1.put("setForeground", Color.BLUE);
    				GMMap color2 = new GMMap();
    				color2.put("setBackground", Color.LIGHT_GRAY);
    				color2.put("setForeground", Color.RED);
    				GMMap colorNotChanged = new GMMap();
    				colorNotChanged.put("setBackground", Color.WHITE);
    				colorNotChanged.put("setForeground", Color.BLACK);
    				
    				for (int i = 0; i < oMap.getSize(tableName); i++) {
    					if ("".equals(oMap.getString(tableName,i,"DURUM"))||((oMap.getString(tableName,i,"DURUM"))==null))
    					    {
    						oMap.put("COLOR",i,"MUSTERI_NO",colorNotChanged);
    						oMap.put("COLOR",i,"HESAP_NO",colorNotChanged);
    						oMap.put("COLOR",i,"ALICI_IBAN",colorNotChanged);
    						oMap.put("COLOR",i,"ALICI_BANKA_KODU",colorNotChanged);
    						oMap.put("COLOR",i,"ALICI_ADI",colorNotChanged);
    						oMap.put("COLOR",i,"ALT_LIMIT",colorNotChanged);
    						oMap.put("COLOR",i,"DURUM",colorNotChanged);
    						oMap.put("COLOR",i,"ACIKLAMA",colorNotChanged);
    						}    							
    				   else if (oMap.getString(tableName,i,"DURUM").equals("G"))
						{	
							oMap.put("COLOR",i,"MUSTERI_NO",color1);
							oMap.put("COLOR",i,"HESAP_NO",color1);
							oMap.put("COLOR",i,"ALICI_IBAN",color1);
							oMap.put("COLOR",i,"ALICI_BANKA_KODU",color1);
							oMap.put("COLOR",i,"ALICI_ADI",color1);
							oMap.put("COLOR",i,"ALT_LIMIT",color1);
							oMap.put("COLOR",i,"DURUM",color1);
							oMap.put("COLOR",i,"ACIKLAMA",color1);
						}
						else if(oMap.getString(tableName,i,"DURUM").equals("D"))
						{
							oMap.put("COLOR",i,"MUSTERI_NO",color1);
							oMap.put("COLOR",i,"HESAP_NO",color1);
							oMap.put("COLOR",i,"ALICI_IBAN",color1);
							oMap.put("COLOR",i,"ALICI_BANKA_KODU",color1);
							oMap.put("COLOR",i,"ALICI_ADI",color1);
							oMap.put("COLOR",i,"ALT_LIMIT",color1);
							oMap.put("COLOR",i,"DURUM",color1);
							oMap.put("COLOR",i,"ACIKLAMA",color1);
						}
						else if(oMap.getString(tableName,i,"DURUM").equals("I"))
						{
							oMap.put("COLOR",i,"MUSTERI_NO",color2);
							oMap.put("COLOR",i,"HESAP_NO",color2);
							oMap.put("COLOR",i,"ALICI_IBAN",color2);
							oMap.put("COLOR",i,"ALICI_BANKA_KODU",color2);
							oMap.put("COLOR",i,"ALICI_ADI",color2);
							oMap.put("COLOR",i,"ALT_LIMIT",color2);
							oMap.put("COLOR",i,"DURUM",color2);
							oMap.put("COLOR",i,"ACIKLAMA",color2);
						}
						else
						{
						oMap.put("COLOR",i,"MUSTERI_NO",colorNotChanged);
						oMap.put("COLOR",i,"HESAP_NO",colorNotChanged);
						oMap.put("COLOR",i,"ALICI_IBAN",colorNotChanged);
						oMap.put("COLOR",i,"ALICI_BANKA_KODU",colorNotChanged);
						oMap.put("COLOR",i,"ALICI_ADI",colorNotChanged);
						oMap.put("COLOR",i,"ALT_LIMIT",colorNotChanged);
						oMap.put("COLOR",i,"DURUM",colorNotChanged);
						oMap.put("COLOR",i,"ACIKLAMA",colorNotChanged);
						}
							
					}
	            }
	            return oMap;
	        } catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        }
	    }

	   
	    @GraymoundService("BNSPR_TRN2303_EFT_GET_IBAN_BILGI")
	    public static GMMap getIbanInfo(GMMap iMap) {
	        Connection conn = null;
	        CallableStatement stmt = null;
	        CallableStatement stmt2 = null;
	        ResultSet rSet = null;
	        GMMap oMap = new GMMap();
	        try {
	            conn = DALUtil.getGMConnection();
	            stmt = conn.prepareCall("{call Pkg_eft.EFT_IBAN_Banka_Sube_Sehir_Al(?,?,?,?,?,?,?)}");
	            int i = 1;
	            stmt.setString(i++, iMap.getString("IBAN"));
	            stmt.registerOutParameter(i++, Types.VARCHAR);
	            stmt.registerOutParameter(i++, Types.VARCHAR);
	            stmt.registerOutParameter(i++, Types.VARCHAR);
	            stmt.registerOutParameter(i++, Types.VARCHAR);
	            stmt.registerOutParameter(i++, Types.VARCHAR);
	            stmt.registerOutParameter(i++, Types.VARCHAR);
	            stmt.execute();
	            
	            String bankaKodu = stmt.getString(2);
	            
	            if(StringUtil.isEmpty(bankaKodu)){
	                iMap.put("MESSAGE_NO", new java.math.BigDecimal(694));
	                String message = (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
	                EftServices.throwGMBusssinessException(message);
	                //throw new GMRuntimeException(0, message);
	            }
	                
	            String bankaAdi =  LovHelper.diLov(bankaKodu, "2303/LOV_ALAN_BANKA", "BANKA_ADI");
	            oMap.put("BANKA_KODU", bankaKodu);
	            oMap.put("SUBE_KODU", stmt.getString(3));
	            oMap.put("SEHIR_KODU", stmt.getString(4));            
	            oMap.put("BANKA_ADI" , bankaAdi );
	            oMap.put("SUBE_ADI", stmt.getString(6));
	            oMap.put("SEHIR_ADI", stmt.getString(7));
	            
            	stmt2 = conn.prepareCall("{? = call pkg_trn2303.Get_Aktif_Musteri(?)}");	

            	if (bankaKodu.equals("143")) {
	    			
	            	stmt2.registerOutParameter(1, Types.VARCHAR);
	    			stmt2.setString(2, iMap.getString("IBAN"));

	    			stmt2.execute();

	    			oMap.put("ALICI_ADI", stmt2.getString(1));
	    			
	    			stmt2.execute();
	            }
	            return oMap;
	        }
	        catch (Exception e) {
	            throw ExceptionHandler.convertException(e);
	        }
	        finally {
	            GMServerDatasource.close(rSet);
	            GMServerDatasource.close(stmt);
	            GMServerDatasource.close(stmt2);
	            GMServerDatasource.close(conn);
	        }
	    }
	
}
