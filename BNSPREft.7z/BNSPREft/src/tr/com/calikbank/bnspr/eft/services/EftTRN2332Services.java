package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2332Services {

@GraymoundService("BNSPR_TRN2332_GET_MESAJ_TURLERI")
public static GMMap getAll(GMMap iMap){
    try{
        GMMap oMap = new GMMap();
        DALUtil.fillComboBox(oMap, "RESULTS", false, "select key1 kod,key1||' '||text as text from v_ml_gnl_param_text where kod = 'EFT_KAS_MESAJ_TIPLERI' and key1 in ('H06','H16') order by 1");
        return oMap;
    }catch (Exception e) {
        throw ExceptionHandler.convertException(e);
    }
}   
@GraymoundService("BNSPR_TRN2332_GET_INITIAL_VALUES")
public static GMMap getInitialValues(GMMap iMap) {
	Connection conn = null;
	CallableStatement stmt = null;
	try {
		GMMap oMap = new GMMap();
		conn = DALUtil.getGMConnection();

		stmt = conn.prepareCall("{call PKG_TRN2323.form_instance(?,?,?,?,?,?,?)}");

		stmt.registerOutParameter(1, Types.VARCHAR);
		stmt.registerOutParameter(2, Types.VARCHAR);
		stmt.registerOutParameter(3, Types.VARCHAR);
		stmt.registerOutParameter(4, Types.DATE);
		stmt.registerOutParameter(5, Types.DECIMAL);
		stmt.registerOutParameter(6, Types.VARCHAR);
		stmt.registerOutParameter(7, Types.VARCHAR);
		
		stmt.execute();

		oMap.put("SUBE_KODU", stmt.getString(1));
		oMap.put("BANKA_KODU", stmt.getString(2));
		oMap.put("BANKA_ADI", stmt.getString(3));
		oMap.put("EFT_TARIH", stmt.getDate(4));
		oMap.put("TRX_NO", stmt.getBigDecimal(5));
		oMap.put("ALAN_BANKA_KODU", stmt.getString(6));
		oMap.put("ALAN_BANKA_ADI", stmt.getString(7));

		oMap.put("GONDEREN_SUBE_KODU", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2323/LOV_BOLUM", "EFT_KODU"));
		oMap.put("DI_GONDEREN_SUBE_KODU", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2323/LOV_BOLUM", "ADI"));
		oMap.put("GONDEREN_SEHIR", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2323/LOV_BOLUM", "IL_KOD"));
		oMap.put("DI_GONDEREN_SEHIR", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2323/LOV_BOLUM", "IL_ADI"));

		oMap.put("ALAN_SEHIR_KODU", "999");
		ArrayList<Object> input = new ArrayList<Object>();
		input.add(stmt.getString(6));
		oMap.put("DI_ALAN_SEHIR_KODU", LovHelper.diLov((String) "999", "2323/LOV_ALAN_SEHIR", "IL_ADI", input));

		oMap.put("ALAN_SUBE_KODU", "90001");
		input = new ArrayList<Object>();
		input.add(stmt.getString(6));
		input.add("999");
		oMap.put("DI_ALAN_SUBE_KODU", LovHelper.diLov((String) "90001", "2323/LOV_ALAN_SUBE", "SUBE_ADI", input));

		return oMap;

	} catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	} finally {
		GMServerDatasource.close(stmt);
		GMServerDatasource.close(conn);
	}
}


}
