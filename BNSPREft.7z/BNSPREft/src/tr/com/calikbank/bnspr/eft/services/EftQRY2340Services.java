package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class EftQRY2340Services {
	
	@GraymoundService("BNSPR_QRY2340_GET_SUPHELI_EFT_ISLEMLERI")
	public static GMMap getEftSupheliList(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_PFT.Get_Supheli_Eft_Islemleri(?,?,?,?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			if ((iMap.get("TARIH_BAS") != null)) stmt.setDate(i++, new Date(iMap.getDate("TARIH_BAS").getTime()));
			else stmt.setDate(i++, null);
			if ((iMap.get("TARIH_SON") != null)) stmt.setDate(i++, new Date(iMap.getDate("TARIH_SON").getTime()));
			else stmt.setDate(i++, null);
			stmt.setString(i++, iMap.getString("AML_SENARYO"));
			if (iMap.getString("EKRAN") == null)
				stmt.setString(i++,"Z");
			else
			   stmt.setString(i++, iMap.getString("EKRAN"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "SUPHELI_EFT_ISLEMLERI";
			GMMap oMap = DALUtil.rSetResults(rSet, tableName);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2340_GET_SUPHELI_EFT_ISLEMLERI_DETAY")
	public static GMMap getEftSupheliListDetay(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_PFT.Get_Supheli_Eft_Islem_D(?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "SUPHELI_EFT_ISLEMLERI";
			GMMap oMap = DALUtil.rSetResults(rSet, tableName);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2340_GET_SUPHELI_EFTLER")
	public static GMMap getEftSupheliEftler(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_PFT.Get_Supheli_Eftler(?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "SUPHELI_EFT_ISLEMLERI";
			GMMap oMap = DALUtil.rSetResults(rSet, tableName);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2340_GET_SUPHELI_SWIFTLER")
	public static GMMap getEftSupheliSwiftler(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_PFT.Get_Supheli_Swiftler(?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "SUPHELI_SWIFT_ISLEMLERI";
			GMMap oMap = DALUtil.rSetResults(rSet, tableName);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2340_GET_SUPHELI_EFT_BILGI")
	public static GMMap getSupheliEftBilgi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_PFT.Get_Supheli_Eft_Bilgi(?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ID"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = DALUtil.rSetMap(rSet);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
