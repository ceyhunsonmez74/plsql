package tr.com.calikbank.bnspr.eft.services;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2322Services {
	@GraymoundService("BNSPR_TRN2322_GET_EFT_INFO")
	public static GMMap getEftInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
			
			oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	    /*    oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("ACIKLAMA_2" , eftEftTx.getAciklama2());
	        oMap.put("ACIKLAMA_3" , eftEftTx.getAciklama3());
	        oMap.put("ACIKLAMA_4" , eftEftTx.getAciklama4());
	        oMap.put("ACIKLAMA_5" , eftEftTx.getAciklama5());
	        oMap.put("ACIKLAMA_6" , eftEftTx.getAciklama6()); */
	        oMap.put("TRX_NO" , eftEftTx.getTxNo());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("DURUM" , eftEftTx.getDurum());
	        oMap.put("TUTAR", eftEftTx.getTutar());
	        oMap.put("ISLEM_TURU", eftEftTx.getIslemTuru());
	        oMap.put("REFERANS_NO", eftEftTx.getReferansNo());
	        oMap.put("FAIZ_ORANI", eftEftTx.getFaizOrani());
	        oMap.put("FAIZ_TUTARI", eftEftTx.getFaizTutari());
	        oMap.put("ANAPARA", eftEftTx.getAnapara());
	        oMap.put("ALICI_HESAP_NO", eftEftTx.getAliciHesapNo());
	        oMap.put("KOMISYON", eftEftTx.getKomisyon());
	        oMap.put("MASRAF", eftEftTx.getMasraf());
	        oMap.put("VERGI", eftEftTx.getVergi());
	        oMap.put("SSDF_BSMV", eftEftTx.getSsdfBsmv());
	        oMap.put("ACIKLAMA", eftEftTx.getAciklama());
	        oMap.put("BASLANGIC_VALOR", eftEftTx.getBaslangicValor());
	        oMap.put("BITIS_VALOR", eftEftTx.getBitisValor());
	        oMap.put("DOVIZ_KODU", eftEftTx.getDovizKodu());
	        oMap.put("DOVIZ_TUTARI", eftEftTx.getDovizTutari());
	        oMap.put("DOVIZ_KURU", eftEftTx.getDovizKuru());
	        oMap.put("AMIR_BANKA_SENET_NO", eftEftTx.getAmirBankaSenetNo());
	        oMap.put("MUH_BANKA_SENET_NO", eftEftTx.getMuhBankaSenetNo());
	        oMap.put("ALICI_ADI", eftEftTx.getAliciAdi());
	        
			
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
