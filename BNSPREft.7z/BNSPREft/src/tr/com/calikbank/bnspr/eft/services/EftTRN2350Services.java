package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import javax.mail.Provider.Type;


import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.EftKaralisteAksiyonTx;
import tr.com.aktifbank.bnspr.dao.EftKaralisteAksiyonTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class EftTRN2350Services {

	@GraymoundService("BNSPR_TRN2350_GET_KARAR")
	public static GMMap getKarar(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			GMMap xMap = new GMMap();

			xMap.put("KOD"		, "EFT_KARALISTE_AKSIYON");
			xMap.put("ADD_EMPTY_KEY"	, "E");
			oMap.put("KARAR"	, GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", xMap).get("RESULTS"));
			
	
			
		} catch (Exception e) {
			EftServices.throwGMBusssinessException(e.getMessage());
			//throw new GMRuntimeException(0, e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN2350_GET_GEREKCE")
	public static GMMap getSonuc(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			GMMap xMap = new GMMap();

			//DALUtil.fillComboBox(oMap, "GEREKCE"	, true, "select key1, text from v_ml_gnl_param_text where kod = 'EFT_KARALISTE_GEREKCE' and key2= ");

			xMap.put("KOD"				, "EFT_KARALISTE_GEREKCE");
			xMap.put("KEY2"	,iMap.getString("KARAR")     );
			oMap.put("GEREKCE"	, GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", xMap).get("RESULTS"));
			
	
			
		} catch (Exception e) {
			EftServices.throwGMBusssinessException(e.getMessage());
			//throw new GMRuntimeException(0, e);
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TRN2350_SELECT_ALL")
	public static GMMap selectAll(GMMap iMap) {
		
		Connection conn = null;
		CallableStatement stmt = null;
		try {
				conn = DALUtil.getGMConnection();
				
				String tableName = "SELECT_ALL";
				List<?> recordList = (List<?>)iMap.get(tableName);
				String check = "0";
				if(iMap.getBoolean("CHECK")){
				check = "1";
				}
				for(int i = 0; i < recordList.size(); i++) {
					
					iMap.put(tableName,i,"ONAY_EH",check);
				}
				
				return iMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	
	}	
	
	
	
	@GraymoundService("BNSPR_TRN2350_SAVE")
	public static GMMap Save (GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			String tableName = "KARALISTE";
			List<?> recordList = (List<?>)iMap.get(tableName);
			
			for(int i = 0; i < recordList.size(); i++) {
				
				if  ( "1".equals(iMap.getString(tableName,i,"ONAY_EH")) )  {
				
				
				EftKaralisteAksiyonTx objEftKaralisteAksiyonTx = new EftKaralisteAksiyonTx();
				EftKaralisteAksiyonTxId objEftKaralisteAksiyonTxId = new EftKaralisteAksiyonTxId();
            	
				objEftKaralisteAksiyonTxId.setTxNo(iMap.getBigDecimal("TRX_NO")) ; 
				objEftKaralisteAksiyonTxId.setKaralisteId(iMap.getBigDecimal(tableName,i,"AML_NO")) ; 
				objEftKaralisteAksiyonTxId.setIslemNo(iMap.getBigDecimal(tableName,i,"ISLEM_NO")) ; 
				objEftKaralisteAksiyonTx.setId(objEftKaralisteAksiyonTxId);
				objEftKaralisteAksiyonTx.setKarar(iMap.getString("KARAR"));
				objEftKaralisteAksiyonTx.setGerekce(iMap.getString("GEREKCE"));
				objEftKaralisteAksiyonTx.setGorus(iMap.getString("GORUS"));
				
				
				session.saveOrUpdate(objEftKaralisteAksiyonTx);
				session.flush();
				}
			}
			
			iMap.put("TRX_NAME", "2350");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		}
	}
	
	
	@GraymoundService("BNSPR_TRN2350_GETINFO")
	public static GMMap getInfo (GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN2350.GETINFO(?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("TRX_NO"));
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			
		
			stmt.execute();	
			
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "KARALISTE";
			GMMap oMap = DALUtil.rSetResults(rSet, tableName);	
			
			oMap.put("KARAR", stmt.getString(3));
			oMap.put("GEREKCE", stmt.getString(4));
			oMap.put("GORUS", stmt.getString(5));
			oMap.put("TRX_NO", iMap.getString("TRX_NO"));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
