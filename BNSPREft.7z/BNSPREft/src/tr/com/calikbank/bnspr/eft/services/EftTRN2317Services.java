package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.aktifbank.bnspr.dao.EftOdemeDetayTx;
import tr.com.aktifbank.bnspr.dao.MuhKimlikKasaislemleriTx;
import tr.com.aktifbank.bnspr.dao.MuhMasrafKomTahsilTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.PaygateConstants;
import tr.com.paygate.ArrayOfInstanceGroup;
import tr.com.paygate.ArrayOfSearchFilter;
import tr.com.paygate.ArrayOfSearchRequest;
import tr.com.paygate.DetailLevel;
import tr.com.paygate.FilterName;
import tr.com.paygate.InstanceGroup;
import tr.com.paygate.SearchEFTData;
import tr.com.paygate.SearchFilter;
import tr.com.paygate.SearchRequest;
import tr.com.paygate.SearchType;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2317Services {
	@GraymoundService("BNSPR_TRN2317_GET_EFT_ODEME_BILGI")
	public static GMMap getEftBilgi(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
			
			oMap.put("ODEME_MUSTERI_NO" , eftEftTx.getOdemeMusteriNo());
	        oMap.put("ODEME_MUSTERI_HESAP" , eftEftTx.getOdemeMusteriHesap());
	        oMap.put("ODEME_SUBE" , eftEftTx.getOdemeSube());
	        oMap.put("ODEME_DK_HESAP" , eftEftTx.getOdemeDkHesap());
	        oMap.put("DISPLAY_ODEME_SUBE" , LovHelper.diLov(eftEftTx.getOdemeSube(), "2317/LOV_BOLUM", "ADI"));
	        oMap.put("DISPLAY_MUSTERI_ADI" , LovHelper.diLov(eftEftTx.getOdemeMusteriNo(), "2317/LOV_MUSTERI", "ADI"));
	        oMap.put("ISLEM_TIPI" , eftEftTx.getIslemTipi());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("GONDEREN" , eftEftTx.getGonderen());
	        oMap.put("GONDEREN_TELEFON" , eftEftTx.getGonderenTelefon());
	        oMap.put("GONDEREN_ADRES" , eftEftTx.getGonderenAdres());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("ALICI_ADI" , eftEftTx.getAliciAdi());
	        oMap.put("ALICI_TC_KIMLIK_NO" , eftEftTx.getAliciTcKimlikno());
	        oMap.put("ALICI_TELEFON_NO" , eftEftTx.getAliciTelefonNo());
	        oMap.put("ALICI_ADRES_1" , eftEftTx.getAliciAdres1());
	        oMap.put("ALICI_ADRES_2" , eftEftTx.getAliciAdres2());
	        oMap.put("ALICI_BABA_ADI" , eftEftTx.getAliciBabaAdi());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALICI_HESAP_NO" , eftEftTx.getAliciHesapNo());
	        oMap.put("KART_NO" , eftEftTx.getKartNo());
	        oMap.put("TUTAR" , eftEftTx.getTutar());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("DURUM" , eftEftTx.getDurum());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("KART_EK_KOD", eftEftTx.getKartEkKod());
	        oMap.put("ODEME_TX_NO", eftEftTx.getOdemeTxNo());
	        oMap.put("OTOMATIK_BILDIRIM_OLUSTUR" , eftEftTx.getOtomatikBildirimOlustur());
	        oMap.put("BILDIRIM_NO" , eftEftTx.getBildirimNo());
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
	        oMap.put("ISLEM_SAAT" ,eftEftTx.getIslemSaat());
	        oMap.put("GIRIS_SAAT" ,eftEftTx.getGirisSaat());
	        oMap.put("ODEME_TURU" ,eftEftTx.getOdemeTuru());
	        oMap.put("ODEME_AYRINTISI" ,eftEftTx.getOdemeAyrintisi());
	        oMap.put("GONDEREN_TCKN_VKN",eftEftTx.getGonderenVergiKimlikNumarasi());
	        oMap.put("GONDEREN_PASAPORT_NO", eftEftTx.getGonderenPasaportNo());
	        oMap.put("GONDEREN_DOGUM_YERI", eftEftTx.getGonderenDogumYeri());
	        oMap.put("GONDEREN_DOGUM_TARIHI", eftEftTx.getGonderenDogumTarihi());
	        oMap.put("GONDEREN_MUSTERI_NUMARASI", eftEftTx.getGonderenMusteriNumarasi());
	        oMap.put("ISL_EK_MUSTERI_ADI", eftEftTx.getIslEkMusteriAdi());
	        oMap.put("ISL_EK_MUSTERI_HESAP", eftEftTx.getIslEkMusteriHesap());
	        oMap.put("ISL_EK_MUSTERI_KIMLIK", eftEftTx.getIslEkMusteriKimlik());
			oMap.put("GONDEREN_HESAP_NUMARASI", eftEftTx.getGonderenHesapNumarasi());

	        return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2317_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftOdemeDetayTx eftEftTx = (EftOdemeDetayTx)session.load(EftOdemeDetayTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
			
			oMap.put("ODEME_MUSTERI_NO" , eftEftTx.getOdemeMusteriNo());
	        oMap.put("ODEME_MUSTERI_HESAP" , eftEftTx.getOdemeMusteriHesap());
	        oMap.put("ODEME_SUBE" , eftEftTx.getOdemeSube());
	        oMap.put("ODEME_DK_HESAP" , eftEftTx.getOdemeDkHesap());
	        oMap.put("DISPLAY_ODEME_SUBE" , LovHelper.diLov(eftEftTx.getOdemeSube(), "2317/LOV_BOLUM", "ADI"));
	        oMap.put("DISPLAY_MUSTERI_ADI" , LovHelper.diLov(eftEftTx.getOdemeMusteriNo(), "2317/LOV_MUSTERI", "ADI"));
	        oMap.put("ISLEM_TIPI" , eftEftTx.getIslemTipi());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("GONDEREN" , eftEftTx.getGonderen());
	        oMap.put("GONDEREN_TELEFON" , eftEftTx.getGonderenTelefon());
	        oMap.put("GONDEREN_ADRES" , eftEftTx.getGonderenAdres());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("ALICI_ADI" , eftEftTx.getAliciAdi());
	        oMap.put("ALICI_TC_KIMLIK_NO" , eftEftTx.getAliciTcKimlikNo());
	        oMap.put("ALICI_TELEFON_NO" , eftEftTx.getAliciTelefonNo());
	        oMap.put("ALICI_ADRES_1" , eftEftTx.getAliciAdres1());
	        oMap.put("ALICI_ADRES_2" , eftEftTx.getAliciAdres2());
	        oMap.put("ALICI_BABA_ADI" , eftEftTx.getAliciBabaAdi());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu()); 
	        
	        oMap.put("ALICI_HESAP_NO" , eftEftTx.getAliciHesapNo());
	        oMap.put("KART_NO" , eftEftTx.getKartNo());
	        oMap.put("TUTAR" , eftEftTx.getTutar());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("DURUM" , eftEftTx.getDurum());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	 //       oMap.put("KART_EK_KOD", eftEftTx.getKartEkKod());
	        oMap.put("ODEME_TX_NO", eftEftTx.getOdemeTxNo());
	        oMap.put("OTOMATIK_BILDIRIM_OLUSTUR" , eftEftTx.getOtomatikBildirimOlustur());
	        oMap.put("BILDIRIM_NO" , eftEftTx.getBildirimNo());
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
	        oMap.put("ISLEM_SAAT" ,eftEftTx.getIslemSaat());
	        oMap.put("GIRIS_SAAT" ,eftEftTx.getGirisSaat());
	        oMap.put("ODEME_TURU" ,eftEftTx.getOdemeTuru());
	        oMap.put("KIMLIK_TIPI",eftEftTx.getKasaKimlikTipi());
	        oMap.put("GONDEREN_TCKN_VKN",eftEftTx.getGonderenVergiKimlikNumarasi());
			oMap.put("GONDEREN_HESAP_NUMARASI", eftEftTx.getGonderenHesapNumarasi());

	        
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2317_GET_ORIGINAL_TRX_NO")
	public static GMMap getHesaBakiyeGoruntulensinmi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_trn2317.get_main_tx_no(?)}");

			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setString(2, iMap.getString("ODEME_TRX_NO"));

			stmt.execute();

			oMap.put("ORJ_TRX_NO", stmt.getBigDecimal(1));
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2317_EFT_ODEME_KONTROL")
	public static GMMap eftOdemeKontrol(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{ call pkg_trn2317.eft_odeme_kontrol(?)}");

			stmt.setString(1, iMap.getString("TRX_NO"));
			stmt.execute();

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN2317_AFTER_CANCELATION")
	public static GMMap afterCancellation(GMMap iMap) {
		Connection conn = null;

		ResultSet rSet = null;
		BigDecimal txNo = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			EftEftTx objEftEftTx = (EftEftTx)session.createCriteria(EftEftTx.class).add(Restrictions.eq("odemeTxNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
			
			
			if(objEftEftTx == null) {
				objEftEftTx = new EftEftTx();
			}
				conn = DALUtil.getGMConnection();
				    txNo = objEftEftTx.getTxNo();  
					if (objEftEftTx.getDurum().startsWith("EUPT_")) {
						
							GMMap sMap = new GMMap();
							
						    sMap.put("TRX_NO", txNo);
						    sMap.put("TYPE", "C");
							sMap = GMServiceExecuter.call(
									"BNSPR_EUPT_EUPT_ISLEM_IPTAL_CHECK", sMap);
						
							GMMap sMap2 = new GMMap();
							
						    sMap2.put("TRX_NO", txNo);
						    sMap2.put("TYPE", "C");
							sMap2 = GMServiceExecuter.call(
									"BNSPR_EUPT_EUPT_ISLEM_IPTAL", sMap2);
								
					}
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
		}

	}	

    /**
     * Gelen EFT lerde kasboxtan yap�lan DB java servis �a�r�lar� i�in BNSPRCore alt�ndaki AmlPaygateEftDbConnection class� kullan�l�yor db taraf�nda.
     * AmlPaygateEftDbConnection class� da bu servisi �a��r�yor.
     * 
      * @see tr.com.aktifbank.bnspr.core.paygate.services.AmlPaygateEftDbConnection#callBulkSearch(String, String, String, String, String, String)
     * 
      * @param iMap
     *           GONDEREN
     *           ALICI
     *           GONDEREN_BANKA
     *           ACIKLAMA
     *           TRX_NO
     *           MUSTERI_NO
     * @return
     *           RESULT
     */
	
	@GraymoundService("BNSPR_TRN2317_EFT_PAYGATE_CHECK")
	public static GMMap eft2317PaygateCheck(GMMap iMap){
			Connection conn = null;
			CallableStatement stmt = null;
			ResultSet rSet = null;
			GMMap oMap = new GMMap();
			try {
	    		DateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
				SearchEFTData searchEftData = new SearchEFTData();
				String ucuncuSahis = null;
	            if (StringUtils.isBlank(iMap.getString("MUSTERI_NO"))) {
	    			Session session = DAOSession.getSession("BNSPRDal");
	            
	    			List<MuhKimlikKasaislemleriTx> muhKimlikKasaIslemleriTxList = session.createCriteria(MuhKimlikKasaislemleriTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.talimatVekalet", "H")).add(Restrictions.eq("kimlikTipi", new BigDecimal(5))).list();

	    			if (muhKimlikKasaIslemleriTxList != null) {
		    			for (MuhKimlikKasaislemleriTx muhKimlikKasaislemleriTx : muhKimlikKasaIslemleriTxList) {

						if (StringUtils.isNotBlank(muhKimlikKasaislemleriTx.getUnvan()))
							ucuncuSahis = muhKimlikKasaislemleriTx.getUnvan();
						else {
							if (StringUtils.isNotBlank(muhKimlikKasaislemleriTx.getIkinciIsim()))
								ucuncuSahis = (muhKimlikKasaislemleriTx.getIsim() + " " + muhKimlikKasaislemleriTx.getIkinciIsim() + " " + muhKimlikKasaislemleriTx.getSoyad());
							else
								ucuncuSahis= (muhKimlikKasaislemleriTx.getIsim() + " " + muhKimlikKasaislemleriTx.getSoyad());
						}
					}
	    		  }
	            }	
	            if (StringUtils.isNotBlank(ucuncuSahis)){
	            	searchEftData.setComment(iMap.getString("ACIKLAMA")+ " 3. �ah�s EFT - ��lemi Yapan "+ucuncuSahis); 
	            }else{
	            	searchEftData.setComment(StringUtils.isBlank(iMap.getString("ACIKLAMA")) ? "":iMap.getString("ACIKLAMA")); 
	            }
	            searchEftData.setBeneficiaryName(iMap.getString("ALICI"));
	            searchEftData.setCustomerName(iMap.getString("GONDEREN"));
	            searchEftData.setCustomerIdentificationNo(iMap.getString("MUSTERI_NO"));
	            searchEftData.setAmount(iMap.getBigDecimal("TUTAR"));
	            searchEftData.setReceiverBankCode((StringUtils.isBlank(iMap.getString("ALAN_BANKA"))?"AKTIF YATIRIM BANKASI A.S.":iMap.getString("ALAN_BANKA")));
	            searchEftData.setSenderBankCode(iMap.getString("GONDEREN_BANKA"));
	            searchEftData.setValueDate(getXmlGregorianCalendar(iMap.getDate("EFT_TARIH")));
	            searchEftData.setBeneficiaryIdentificationNo(iMap.getString("ALICI_TCKN"));
	            searchEftData.setApplicationName(iMap.getString("TRX_NAME","2317"));
	            searchEftData.setDetailLevel(DetailLevel.FULL);
	            searchEftData.setExternalId(iMap.getString("TRX_NO"));
	            searchEftData.setInstanceId(PaygateConstants.LIST_GROUP_AKUSTIK_4);
	            searchEftData.setDirection("I");
	            ArrayOfSearchFilter arrOfSearchFilter = new ArrayOfSearchFilter();
	            if (StringUtils.isNotBlank(iMap.getString("MUSTERI_NO"))) {
		            SearchFilter sf = new SearchFilter();
		            sf.setKey(FilterName.CUSTOMER_NUMBER);
		            sf.setValue(iMap.getString("MUSTERI_NO"));
		            sf.setLogicalOperator("AND");
		            sf.setIsFeatureFilter(false);
		            arrOfSearchFilter.getSearchFilter().add(sf);
	            }    
	            //ALICI_TCKN paygate search filter
	            if (StringUtils.isNotBlank(iMap.getString("ALICI_TCKN"))) {
		            SearchFilter sfAliciTckn = new SearchFilter();
		            sfAliciTckn.setKey(FilterName.BENEFICIARY_NATIOANAL_ID);
		            sfAliciTckn.setValue(iMap.getString("ALICI_TCKN"));
		            sfAliciTckn.setLogicalOperator("AND");
		            sfAliciTckn.setIsFeatureFilter(false);
		            arrOfSearchFilter.getSearchFilter().add(sfAliciTckn);
	            }
	            //ALICI_DTARIH paygate search filter
	            if (StringUtils.isNotBlank(iMap.getString("ALICI_DTARIH"))) {
		            SearchFilter sfAliciDtarih = new SearchFilter();
		            sfAliciDtarih.setKey(FilterName.BENEFICIARY_DATE_OF_BIRTH);
		            sfAliciDtarih.setValue(sdf.format(iMap.getDate("ALICI_DTARIH")));
		            sfAliciDtarih.setLogicalOperator("AND");
		            sfAliciDtarih.setIsFeatureFilter(false);
		            arrOfSearchFilter.getSearchFilter().add(sfAliciDtarih);
	            }
	            //GONDEREN_TCKN paygate search filter
	            if (StringUtils.isNotBlank(iMap.getString("GONDEREN_TCKN"))) {
		            SearchFilter sfGonderenTckn = new SearchFilter();
		            sfGonderenTckn.setKey(FilterName.CUSTOMER_NATIONAL_ID);
		            sfGonderenTckn.setValue(iMap.getString("GONDEREN_TCKN"));
		            sfGonderenTckn.setLogicalOperator("AND");
		            sfGonderenTckn.setIsFeatureFilter(false);
		            arrOfSearchFilter.getSearchFilter().add(sfGonderenTckn);
	            }
	            //GONDEREN_DTARIH paygate search filter
	            if (StringUtils.isNotBlank(iMap.getString("GONDEREN_DTARIH"))) {
		            SearchFilter sfGonderenDtarih = new SearchFilter();
		            sfGonderenDtarih.setKey(FilterName.CUSTOMER_DATE_OF_BIRTH);
		            sfGonderenDtarih.setValue(sdf.format(iMap.getDate("GONDEREN_DTARIH")));
		            sfGonderenDtarih.setLogicalOperator("AND");
		            sfGonderenDtarih.setIsFeatureFilter(false);
		            arrOfSearchFilter.getSearchFilter().add(sfGonderenDtarih);
	            }

	            searchEftData.setFilters(arrOfSearchFilter);

	            
	            GMMap amlMap = new GMMap(); 
	            amlMap.put("SEARCH_EFT_DATA", searchEftData);             
	            oMap = GMServiceExecuter.call("BNSPR_EXT_FINEKSUS_SEARCH_EFT_DATA", amlMap);
	            return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
				GMServerDatasource.close(rSet);
			}
		}	

	@GraymoundService("BNSPR_TRN2317_EFT_PAYGATE_CHECK_OLD")
	public static GMMap eft2317PaygateCheckOld(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		List<SearchRequest> searchRequestList = new ArrayList<SearchRequest>();
		try {
            ArrayOfSearchRequest arrayOfSearchRequest = new ArrayOfSearchRequest();

			SearchRequest srGonderen = new SearchRequest();
            srGonderen.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_2, SearchType.GENERIC_NAME));
            srGonderen.setValue(iMap.getString("GONDEREN"));
			searchRequestList.add(srGonderen);
			
			SearchRequest srAlici = new SearchRequest();
			srAlici.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_2, SearchType.GENERIC_NAME));
			srAlici.setValue(iMap.getString("ALICI"));
            if (StringUtils.isNotBlank(iMap.getString("MUSTERI_NO"))) {
                ArrayOfSearchFilter arrOfSearchFilter = new ArrayOfSearchFilter();
                SearchFilter sf = new SearchFilter();
                sf.setKey(FilterName.CUSTOMER_NUMBER);
                sf.setValue(iMap.getString("MUSTERI_NO"));
                arrOfSearchFilter.getSearchFilter().add(sf);
                srAlici.setFilters(arrOfSearchFilter);
         }
			searchRequestList.add(srAlici);

//			SearchRequest srGonBanka = new SearchRequest();
//			srGonBanka.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_2, SearchType.GENERIC_NAME));
//			srGonBanka.setValue(iMap.getString("GONDEREN_BANKA"));
//			searchRequestList.add(srGonBanka);

			if (StringUtils.isNotBlank(iMap.getString("ACIKLAMA"))) {
				SearchRequest srAciklama = new SearchRequest();
				srAciklama.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_2, SearchType.TEXT));
				srAciklama.setValue(iMap.getString("ACIKLAMA"));
				searchRequestList.add(srAciklama);				
			}
			
            arrayOfSearchRequest.getSearchRequest().addAll(searchRequestList);
            
            GMMap amlMap = new GMMap(); 
            amlMap.put("TRX_NAME",iMap.getString("TRX_NAME","2317")); 
            amlMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
            amlMap.put("SEARCH_REQUEST_LIST", arrayOfSearchRequest);
             
            oMap = GMServiceExecuter.call("BNSPR_EXT_FINEKSUS_SEARCH_BULK_DATA", amlMap);
            return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}		
	private static ArrayOfInstanceGroup getArrOfInstanceGroupWithTypeAndName(String instanceName, SearchType searchType) {
		ArrayOfInstanceGroup instanceGroupListArray = new ArrayOfInstanceGroup();
		List<InstanceGroup> instanceGroupList = new ArrayList<InstanceGroup>();
		InstanceGroup ig = new InstanceGroup();
		ig.setDetailLevel(DetailLevel.FULL);
		ig.setInstanceName(instanceName);
		ig.setSearchType(searchType);
		instanceGroupList.add(ig);
		instanceGroupListArray.getInstanceGroup().addAll(instanceGroupList);
		return instanceGroupListArray;
	}
	
	public static XMLGregorianCalendar getXmlGregorianCalendar(java.util.Date date) throws DatatypeConfigurationException {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(date);
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(c);	
	}

}
