package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EftKartOdemeTx;
import tr.com.aktifbank.bnspr.dao.EftTopupRrnLog;
import tr.com.aktifbank.bnspr.dao.GnlMusteriSanaliban;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.OceanConstants;
import tr.com.calikbank.bnspr.util.OceanMapKeys;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftToCreditCardOrDebitCard  implements OceanMapKeys {
    
    private static final Logger logger                = Logger.getLogger(EftToCreditCardOrDebitCard.class);
    
    private static final String Eft_Status_Card_OK    = "KART_OK";
    private static final String Eft_Status_Prepaid_OK = "PP_OK";
    private static final String Eft_Status_Ocean_Prepaid_OK = "OPP_OK";
    private static final String Eft_Status_Ocean_Proceed_OK = "PPP_OK";
    private static final String Eft_Status_Card_NO    = "KART_SORUN";
    private static final String Eft_Status_Eupt_OK    = "EUPT_OK";
    private static final String Eft_Status_Eupt_NO    = "EUPT_SORUN";
    private static final String Debit_Main_Account    = "A";
    
    private static final String Channel_INT           = "4";
    private static final String Channel_IVR           = "5";
    private static final String Channel_Branch        = "1";
    

       
    @GraymoundService("BNSPR_EFT_START_EFT_TO_CREDIT_AND_DEBIT_CARD")
    public static GMMap startEftToCreditAndDebitCard(GMMap iMap) throws Exception {
        
        logger.info("BNSPR_EFT_TO_CREDIT_AND_DEBIT_CARD karta EFT BA�LADI......................");
        
        try{
            GMMap eftListMap = new GMMap();
            Object[] outputValues1 = new Object[2];
            outputValues1[0] = BnsprType.REFCURSOR;
            outputValues1[1] = "EFT_LIST";
            
            eftListMap = DALUtil.callOracleRefCursorFunction("{ ?= call PKG_CARD.CARD_EFT_LIST}" , "EFT_LIST" , outputValues1);
            int s = eftListMap.getSize("EFT_LIST");
            
            for (int i = 0; i < s; i++){
                GMMap eftMap = prepareEftMap(eftListMap , i);
                try{
                    // GMServiceExecuter.executeAsync("BNSPR_EFT_DO_EFT_TO_CARD",
                    // eftMap);
                    GMServiceExecuter.executeNT("BNSPR_EFT_DO_EFT_TO_CREDIT_AND_DEBIT_CARD" , eftMap);
                } catch (Exception e){
                    // TODO Auto-generated catch block
                    logger.info("BNSPR_EFT_TO_CREDIT_AND_DEBIT_CARD karta EFT HATA ALDI......................");
                    
                    e.printStackTrace();
                   
                }
            }
            
        } catch (Exception e){
            logger.info("BNSPR_EFT_TO_CREDIT_AND_DEBIT_CARD karta EFT HATA ALDI......................");
            
            // TODO Auto-generated catch block
            e.printStackTrace();
            throw e;
        }
        logger.info("BNSPR_EFT_TO_CREDIT_AND_DEBIT_CARD karta EFT B�TT�......................");
        return iMap;
    }
    
    private static GMMap prepareEftMap(GMMap eftListMap, int i) {
        GMMap eftMap = new GMMap();
        logger.info("============> prepareEftMap ba�alard�.");
        eftMap.put("KART_NO" , eftListMap.get("EFT_LIST" , i , "KART_NO") == null ? "" : eftListMap.getString("EFT_LIST" , i , "KART_NO").trim());
        eftMap.put("TX_NO" , eftListMap.getString("EFT_LIST" , i , "TX_NO"));
        eftMap.put("TUTAR" , eftListMap.getString("EFT_LIST" , i , "TUTAR"));
        eftMap.put("ACIKLAMA" , eftListMap.getString("EFT_LIST" , i , "ACIKLAMA"));
        eftMap.put("ALICI_HESAP_NO" , eftListMap.get("EFT_LIST" , i , "ALICI_HESAP_NO") == null ? "0" : eftListMap.getString("EFT_LIST" , i , "ALICI_HESAP_NO"));
        eftMap.put("ALICI_TCKN" , eftListMap.get("EFT_LIST" , i , "ALICI_TCKN") == null ? "0" : eftListMap.get("EFT_LIST" , i , "ALICI_TCKN"));
        
        if(eftMap.getString("ALICI_HESAP_NO").startsWith("TR") ){
        	String iban = eftMap.getString("ALICI_HESAP_NO");
        	eftMap.put("KART_NO" , getCardNofromIban(iban));
        }
        
        logger.info("============> prepareEftMap kart no " + eftMap.getString("KART_NO"));
        logger.info("============> prepareEftMap bitti.");
        return eftMap;
    }
    
    @GraymoundService("BNSPR_EFT_DO_EFT_TO_CREDIT_AND_DEBIT_CARD")
    public static GMMap doEftToCard(GMMap eftMap) throws Exception {
        
        String cardNo = "";
        String basvuruNo = "";
        String dci = "";
        String hesapNo = "";
        String dest = "";
        BigDecimal txNo = BigDecimal.ZERO;
        cardNo = eftMap.getString("KART_NO").trim();
        txNo = eftMap.getBigDecimal("TX_NO");
        hesapNo = eftMap.getString("ALICI_HESAP_NO").trim();
        String tckn = "";
        boolean isProceedSystem=false;
        
        
        logger.info("BNSPR_EFT_DO_EFT_TO_CREDIT_AND_DEBIT_CARD BA�LADI Karta No : " + cardNo);
        logger.info("Bulunan Karta No : " + cardNo);
        logger.info("Bulunan Tx No : " + txNo);
        
        if ((hesapNo != null && hesapNo.length() == 16) || (cardNo != null && cardNo.length() == 16)){
            // EUPT veya Kart ile EFT
           if (cardNo == null || cardNo.equals("")){
                cardNo = hesapNo;
            }
           if("false".equals(cardNo)){
        	   logger.info("Sanal Kart yok");
               eftMessageLog(cardNo , "Sanal Kart yok" , eftMap.getBigDecimal("TX_NO"));
               updateEftStatus(cardNo , txNo , Eft_Status_Card_NO);
           }
            GMMap cardProperty = new GMMap();
            cardProperty.put("CARD_NO" , cardNo);
            cardProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES" , cardProperty);
            
            logger.info("cardProperty.RETURN_CODE => " + cardProperty.getString("RETURN_CODE"));
            
            if ("0".equals(cardProperty.getString("RETURN_CODE"))){
                
                logger.info("cardProperty.DESTINATION => " + cardProperty.getString("DESTINATION"));
                logger.info("cardProperty.DCI => " + cardProperty.getString("DCI"));
                
                dci = cardProperty.getString("DCI");
                dest = cardProperty.getString("DESTINATION");
                isProceedSystem = cardProperty.getBoolean("IS_PROCEED");
                logger.info("Karta No : " + cardNo + " / kart tipi: " + dci);
                
                // if (dci.equals("E") && dest.equals("E")) {
                // // eupt hesab� ile eft
                // logger.info("===========> EUPT ile eft.");
                // eftToEUP(eftMap, cardNo, txNo, tckn, basvuruNo);
                //
                // } else {
                logger.info("===========> Karta eft.");
                if (!cardNo.equals("")){
                    doEftToCard(eftMap , cardNo , dci , txNo , dest, isProceedSystem);
                    
                } else{
                    logger.info("===========> cardNo bo�.");
                    eftMessageLog(cardNo , "Kart bulunamad�." , eftMap.getBigDecimal("TX_NO"));
                    updateEftStatus(cardNo , txNo , Eft_Status_Card_NO);
                    
                }
                // }
                
            } else{
                logger.info("Kart bini tan�ms�z.");
                eftMessageLog(cardNo , "Kart bini tan�ms�z." , eftMap.getBigDecimal("TX_NO"));
                updateEftStatus(cardNo , txNo , Eft_Status_Card_NO);
                
            }
        } else
            if (hesapNo != null && hesapNo.length() == 11){
                // TCKN ile EFT
                GMMap iMap3 = new GMMap();
                tckn = hesapNo.trim();
                iMap3.put("TCKN" , hesapNo);
                iMap3.put("INPUT_PARAMETER_TYPE" , "TCKN");
                tcknIleEft(tckn , eftMap , txNo);
            }
            // logger.info("===============> TCKN ile kart ve ba�vuru sorgulan�yor.");
            // logger.info("===============> TCKN = " + hesapNo);
            //
            // GMMap cardMap = GMServiceExecuter.call(
            // "BNSPR_GET_FIRST_CARD_NO_FOR_EFT", iMap3);
            //
            // cardNo = cardMap.get("CARD_NO") == null ? "" : cardMap
            // .getString("CARD_NO");
            // basvuruNo = cardMap.get("BASVURU_NO") == null ? "" : cardMap
            // .getString("BASVURU_NO");
            // logger.info("===============> cardNo = " + cardNo);
            // logger.info("===============> basvuruNo = " + basvuruNo);
            // logger.info("===============> TCKN ile kart ve ba�vuru sorgulan�yor B�TT�.");
            
            // if (!cardNo.equals("")) {
            //
            //
            //
            // }
            else{
                if (eftMap.getLong("ALICI_TCKN") > 0){
                    logger.info("Al�c� TCKN var onunla devam ==========>> : " + eftMap.getString("ALICI_TCKN"));
                    
                    tcknIleEft(eftMap.getString("ALICI_TCKN") , eftMap , txNo);
                } else{
                    eftMessageLog(cardNo , "Kart no ya da al�c� hesap numaras� hatal�." , eftMap.getBigDecimal("TX_NO"));
                    updateEftStatus(cardNo , txNo , Eft_Status_Card_NO);
                    
                    
                }
            }
        
        logger.info("BNSPR_EFT_DO_EFT_TO_CREDIT_AND_DEBIT_CARD B�TT� Karta No : " + cardNo);
        
        return eftMap;
        
    }
    
    private static BigDecimal eftToEUP(GMMap eftMap, String euptNo, BigDecimal txNo, String tckn, String basvuruNo, BigDecimal tutar, boolean partial) throws Exception {
        
        BigDecimal kartBedeli = BigDecimal.ZERO;
        BigDecimal kalanTutar = BigDecimal.ZERO;
        BigDecimal yatanTutar = BigDecimal.ZERO;
        try{
            logger.info("===========> eftToEUP Ba�lad�");
            if (basvuruNo.equals("")){
                
                GMMap iMap3 = new GMMap();
                GMMap cardMap = new GMMap();
                iMap3.put("EUPT_HESAP_NO" , euptNo);
                logger.info("===========> EUPT ile ba�vuru listesi al�n�yor. euptNo = " + euptNo);
                
                
                try {
                	cardMap = GMServiceExecuter.call("BNSPR_TFF_GET_AKTIF_BASVURU_LIST" , iMap3);
                	if (cardMap.getSize("BASVURU_BILGILERI") > 0){
                        logger.info("===========> EUPT ile ba�vuru listesi al�nd�. basvuruNo = " + basvuruNo);
                        basvuruNo = cardMap.getString("BASVURU_BILGILERI" , 0 , "BASVURU_NO");
                    }
				}
				catch (Exception e) {
					 	logger.info("===========> eftToEUP hata ald� e.message = " + e.getMessage());
			            
			            eftMessageLog(basvuruNo , e.getMessage() , eftMap.getBigDecimal("TX_NO"));
	                    updateEftStatus(basvuruNo , txNo , Eft_Status_Card_NO);
			            throw e;
				}
                
            }
            
            if (!basvuruNo.equals("")){
                // ba�vurusu var para EUPT hesab�na gider.
                logger.info("===========> ba�vurusu var para EUPT hesab�na gidecek. basvuruNo = " + basvuruNo);
                
                GMMap uMap = new GMMap();
                
                if (partial){
                    uMap.put("BASVURU_NO" , basvuruNo);
                    uMap = GMServiceExecuter.call("BNSPR_TFF_GET_KART_BEDELI" , uMap);
                    kartBedeli =
                            uMap.getBigDecimal("ODEME_BILGILERI" , 0 , "KART_BEDELI").add(
                                    uMap.getBigDecimal("ODEME_BILGILERI" , 0 , "VIZE_BEDELI").add(
                                            uMap.getBigDecimal("ODEME_BILGILERI" , 0 , "LOYALTY_BEDELI").add(uMap.getBigDecimal("ODEME_BILGILERI" , 0 , "KURYE_BEDELI"))));
                    
                    if (tutar.compareTo(kartBedeli) >= 0){
                        yatanTutar = kartBedeli;
                        
                    } else{
                        yatanTutar = tutar;
                    }
                } else{
                    yatanTutar = tutar;
                }
                GMMap inMap = new GMMap();
                inMap.put("TX_NO" , txNo);
                GMMap cMap = new GMMap();
                cMap = GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD" , cMap);
                String kanal = cMap.getString("KANAL_KOD");
                inMap.put("CHANNEL" , kanal);
                inMap.put("APPLICATION_NO" , basvuruNo);
                inMap.put("TXN_AMOUNT" , yatanTutar);
                inMap.put("CUSTOMER_NO" , "");
                inMap.put("TCKN" , tckn);
                inMap.put("EUPT_ACCOUNT_NO" , euptNo);
                
                GMServiceExecuter.call("BNSPR_INTRACARD_CRD_TFF_TOP_UP_APPLICATION_INVEST" , inMap);
                kalanTutar = tutar.subtract(yatanTutar);
                
                // GMMap sMap = new GMMap();
                // sMap.put("KART_NO", euptNo);
                // sMap.put("TUTAR", tutar);
                // sMap.put("ALICI_ADI", eftMap.getString("ALICI_ADI"));
                // sMap.put("MESAJ_KODU", eftMap.getString("MESAJ_KODU"));
                // sMap.put("TRX_NO", txNo);
                // sMap.put("BLOKE_MI", basvuruNo != "" ? "1" : "0");
                // sMap.put("PARTIAL", partial);
                //
                //
                // logger.info("===========> EUPT para aktarma ba�lad�.");
                // sMap.putAll(GMServiceExecuter.execute(
                // "BNSPR_EUPT_LOAD_EFT_MONEY_TO_EUPT", sMap));
                // BnsprCommonFunctions.setUserGlobals2();
                // logger.info("===========> EUPT para aktarma bitti.");
                //
                // boolean result = sMap.getBoolean("RESULT");
                //
                // if (result) {
                //
                //
                // kalanTutar = sMap.getBigDecimal("AMOUNT");
                // logger.info("===========> EUPT para aktarma kalanTutar = "
                // + kalanTutar);
                // if (kalanTutar.compareTo(BigDecimal.ZERO) != 0 && !partial) {
                //
                // GMMap inMap = new GMMap();
                // inMap.put("TX_NO", txNo);
                // GMMap cMap = new GMMap();
                // cMap = GMServiceExecuter.call(
                // "BNSPR_COMMON_GET_KANAL_KOD", cMap);
                // String kanal = cMap.getString("KANAL_KOD");
                // inMap.put("CHANNEL", kanal);
                // inMap.put("APPLICATION_NO", basvuruNo);
                // inMap.put("TXN_AMOUNT", kalanTutar);
                // inMap.put("CUSTOMER_NO", "");
                // inMap.put("TCKN", tckn);
                // inMap.put("EUPT_ACCOUNT_NO", euptNo);
                //
                // logger.info("===========> kalan tutar ba�vuruya aktar�l�yor.");
                //
                // GMServiceExecuter
                // .call("BNSPR_INTRACARD_CRD_TFF_TOP_UP_APPLICATION_INVEST",
                // inMap);
                // logger.info("===========> kalan tutar ba�vuruya aktar�l�yor bitti.");
                // }
                //
                //
                //
                //
                // } else {
                // updateEftEUPTStatus(euptNo, txNo, Eft_Status_Eupt_NO);
                // eftMessageLog(euptNo, "EUPT transfer ba�ar�s�z.", txNo);
                // throw new Exception("EUPT transfer ba�ar�s�z.");
                // }
            }
            logger.info("===========> eftToEUP Bitti");
            
        } catch (Exception e){
            logger.info("===========> eftToEUP hata ald� e.message = " + e.getMessage());
            throw e;
        }
        return kalanTutar;
        // } else {
        // logger.info("===========> ba�vurusu yok ilk kart�na EFT gider..");
        // // ba�vurusu yok ilk kart�na EFT gider.
        // GMMap eMap = new GMMap();
        // eMap.put("EUPT_ACCOUNT_NO", euptNo);
        // eMap = GMServiceExecuter
        // .call("BNSPR_EUPT_GET_CUSTOMER_INFO_WITH_EUPT_ACCOUNTS",
        // eMap);
        // String tcknFromEupt = eMap.getString("GOVID");
        //
        // GMMap cardMap = new GMMap();
        // cardMap.put("TCKN", tcknFromEupt);
        // cardMap.put("INPUT_PARAMETER_TYPE", "TCKN");
        // cardMap = GMServiceExecuter.call(
        // "BNSPR_GET_FIRST_CARD_NO_FOR_EFT", cardMap);
        // String cardNo = cardMap.get("CARD_NO") == null ? "" : cardMap
        // .getString("CARD_NO");
        //
        // if (!cardNo.equals("")) {
        // GMMap cardProperty = new GMMap();
        // cardProperty.put("CARD_NO", cardNo);
        // cardProperty = GMServiceExecuter.call(
        // "BNSPR_GET_CARD_PROPERTIES", cardProperty);
        //
        // doEftToCard(eftMap, cardNo, cardProperty.getString("DCI"),
        // txNo, cardProperty.getString("DESTINATION"));
        //
        // } else {
        // updateEftEUPTStatus(euptNo, txNo, Eft_Status_Eupt_NO);
        // eftMessageLog(euptNo, "Kart bulunamad�.", txNo);
        // }
        // }
        
    }
    
    private static void updateEftEUPTStatus(String cardNo, BigDecimal txNo, String status) throws SQLException {
        
        Object[] inputValues = new Object[4];
        Object[] outputValues = new Object[0];
        inputValues[0] = BnsprType.NUMBER;
        inputValues[1] = txNo;
        inputValues[2] = BnsprType.STRING;
        inputValues[3] = status;
        DALUtil.callOracleProcedure("{call PKG_EUPT.EUPT_CARD_EFT_DURUM_UPDATE(?,?)}" , inputValues , outputValues);
    }
    
    private static void doEftToCard(GMMap eftMap, String cardNo, String dci, BigDecimal txNo, String dest,Boolean isProceedSystem) throws SQLException {
        BigDecimal accountNo;
        logger.info("Karta No : " + cardNo + " / Ocean kart sogulama ba�ar�l�.");
        
        if (dci.equals("D")){
            
            logger.info("Debit Karta No : " + cardNo + " / Debit kart hesab�na eft ba�lad�.......");
            accountNo = getDebitAccountNo(cardNo , dest, txNo);
            
            if (accountNo == BigDecimal.ZERO){
                
                logger.info("Debit Karta No : " + cardNo + " / Debit kart ana hesab� bulunamad�.");
                String desc = "Debit karta ba�l� ana hesap bulunamad�. Debit kart bilgilerini kontrol ediniz.";
                eftMessageLog(cardNo , desc , txNo);
                
                logger.info("Debit Karta No : " + cardNo + " / EFT durumu update ediliyor. Durum :" + Eft_Status_Card_NO);
                updateEftStatus(cardNo , txNo , Eft_Status_Card_NO);
                
            } else{
                logger.info("Debit Karta No : " + cardNo + " / Debit kart ana hesab� : " + accountNo);
                eftDebitCardAccounting(cardNo , accountNo , txNo);
            }
            
        } else
            if (dci.equals("C")){
                
                logger.info("Karta No : " + cardNo + " / Ocean kart �deme yap�l�yor........");
                eftMap.put("KART_NO" , cardNo);
                boolean eftStatusCC = eftToCreditCard(eftMap , cardNo , eftMap.getBigDecimal("TUTAR"));
                
                if (eftStatusCC == true){
                    logger.info("======> Kredi kart� i�in muhasebe.");
                    eftCardAccounting(cardNo , txNo , Eft_Status_Card_OK);
                    
                } else{
                    updateEftStatus(cardNo , txNo , Eft_Status_Card_NO);
                }
                
            } else
                if (dci.equals("P")){
                    
                    logger.info("======> Prepaid karta EFT.");
                    boolean eftStatusPrepaid = eftToPrepaidCard(txNo , cardNo , eftMap , eftMap.getBigDecimal("TUTAR"),dest);
                    
                    if (eftStatusPrepaid == true){
                        logger.info("======> Prepaid kart� i�in muhasebe.");
                        if(dest.equals("I")){
                        	eftCardAccounting(cardNo , txNo , Eft_Status_Prepaid_OK);
                        }else{
                        	if(isProceedSystem){
                        		eftCardAccounting(cardNo , txNo , Eft_Status_Ocean_Proceed_OK);
                        	}else{
                        		eftCardAccounting(cardNo , txNo , Eft_Status_Ocean_Prepaid_OK);
                        	}
                        }
                    } else{
                    	eftMessageLog(cardNo , "Prepaid Card Bulunamad� ya da Hatal�" , eftMap.getBigDecimal("TX_NO"));
                        updateEftStatus(cardNo , txNo , Eft_Status_Card_NO);
                    }
                    
                } else{
                    logger.info("======> Kart Tipi tan�ms�z Dci.");
                    eftMessageLog(cardNo , "Kart Tipi tan�ms�z Dci : " + dci , eftMap.getBigDecimal("TX_NO"));
                    updateEftStatus(cardNo , txNo , Eft_Status_Card_NO);
                    
                }
    }
    
    private static boolean eftToPrepaidCard(BigDecimal txNo, String cardNo, GMMap eftMap, BigDecimal tutar, String dest) {
        
    	 GMMap cardInfoMap = new GMMap();
         cardInfoMap.put("CARD_NO" , cardNo);
         cardInfoMap.put("CARD_DCI" , "A");
         cardInfoMap.put(CARD_BANK_STATUS , "N");
         cardInfoMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARDS", cardInfoMap);
         if(cardInfoMap.getSize(CARD_DETAIL_INFO)==0){
        	 eftMessageLog(cardNo , "Kart Bulunamad�" , eftMap.getBigDecimal("TX_NO"));
         	return false;
         }
        
         
        GMMap tMap = new GMMap();
        logger.info("======> eftToPrepaidCard ba�lad�.");
        tMap.put("TX_NO" , txNo);
        tMap.put("CARD_NO" , cardNo);
        tMap.put("REQUEST_TYPE" , OceanConstants.Request_Normal);
        tMap.put("TERMINAL_ID" , "9999999");
        tMap.put("TXN_AMOUNT" , tutar);
        tMap.put("TXN_CURR" , "TRY");
        tMap.put("PAYMENT_TYPE" , OceanConstants.Payment_EFT);
        tMap.put("REQUEST_TYPE" , "N");
        tMap.put("ACCOUNT_BRANCH_ID" , "0");
        tMap.put("TXN_DESC" , cardNo + " nolu karta EFT ile para y�kleme.");
        
        GMMap otMap = new GMMap();
        
        otMap = GMServiceExecuter.call("BNSPR_GENERAL_PREPAID_TOPUP" , tMap);
        
        
        if (otMap.getInt("RETURN_CODE") == OceanConstants.Result_Succesful){
            
            insertEftRrnLog(otMap.getString("RRN") , eftMap.getBigDecimal("TX_NO"));
            
            logger.info("Karta No : " + cardNo + " / Intra kart �deme ba�ar�l�.");
            eftMessageLog(cardNo , "Intra kart �deme ba�ar�l�." , eftMap.getBigDecimal("TX_NO"));
            logger.info("======> eftToPrepaidCard bitti.");
            return true;
        } else{
            logger.info("Karta No : " + cardNo + " / Intra kart �deme hata ald�. Ocean Hata : " + otMap.getString("RETURN_CODE") + " / " + otMap.getString("RETURN_DESCRIPTION"));
            String desc = "Intra servis hatas�: " + otMap.getString("RETURN_CODE") + " / " + otMap.getString("RETURN_DESCRIPTION");
            eftMessageLog(cardNo , desc , eftMap.getBigDecimal("TX_NO"));
            logger.info("======> eftToPrepaidCard bitti.");
            return false;
        }
    }
    
    private static void updateEftStatus(String cardNo, BigDecimal txNo, String status) throws SQLException {
        
        Object[] inputValues = new Object[4];
        Object[] outputValues = new Object[0];
        inputValues[0] = BnsprType.NUMBER;
        inputValues[1] = txNo;
        inputValues[2] = BnsprType.STRING;
        inputValues[3] = status;
        DALUtil.callOracleProcedure("{call PKG_CARD.EKENT_CARD_EFT_DURUM_UPDATE (?,?)}" , inputValues , outputValues);
    }
    
    private static boolean eftCardAccounting(String cardNo, BigDecimal txNo, String eftStatus) throws SQLException {
        
        try{
            logger.info("Karta No : " + cardNo + " / EFT durumu update ediliyor. Durum :" + eftStatus);
            updateEftStatus(cardNo , txNo , eftStatus);
            
            Object[] inputValues = new Object[2];
            Object[] outputValues = new Object[0];
            inputValues[0] = BnsprType.NUMBER;
            inputValues[1] = txNo;
            DALUtil.callOracleProcedure("{call Pkg_Eft_Mesaj.KRED_KART_MUHASEBE (?)}" , inputValues , outputValues);
            logger.info("Kredi Karta No : " + cardNo + " call Pkg_Eft_Mesaj.KRED_KART_MUHASEBE ba�ar�l�.");
            return true;
            
        } catch (Exception e){
            logger.info("Kredi Karta No : " + cardNo + " call Pkg_Eft_Mesaj.KRED_KART_MUHASEBE hata : " + e.getMessage());
         
            e.printStackTrace();
            
            updateEftStatus(cardNo , txNo , Eft_Status_Card_NO);
            eftMessageLog(cardNo , e.getMessage().toString() , txNo);
            return false;
        }
        
    }
    
    private static boolean eftDebitCardAccounting(String cardNo, BigDecimal accountNo, BigDecimal txNo) throws SQLException {
        
        try{
            
            logger.info("Debit Karta No : " + cardNo + " / EFT durumu update ediliyor. Durum :" + Eft_Status_Card_OK);
            updateEftStatus(cardNo , txNo , Eft_Status_Card_OK);
            
            Object[] inputValues = new Object[4];
            Object[] outputValues = new Object[0];
            inputValues[0] = BnsprType.NUMBER;
            inputValues[1] = txNo;
            inputValues[2] = BnsprType.NUMBER;
            inputValues[3] = accountNo;
            DALUtil.callOracleProcedure("{call Pkg_Eft_Mesaj.KRED_KART_MUHASEBE (?,?)}" , inputValues , outputValues);
            
            logger.info("Debit Karta No : " + cardNo + " call Pkg_Eft_Mesaj.KRED_KART_MUHASEBE ba�ar�l�.");
            return true;
            
        } catch (Exception e){
            
            logger.info("Debit Karta No : " + cardNo + " call Pkg_Eft_Mesaj.KRED_KART_MUHASEBE hata : " + e.getMessage());
            
            updateEftStatus(cardNo , txNo , Eft_Status_Card_NO);
            eftMessageLog(cardNo , e.getMessage().toString() , txNo);
       
            e.printStackTrace();
            return false;
        }
    }
    
    private static boolean eftMessageLog(String cardNo, String desc, BigDecimal txNo) {
        
        try{
            if (desc.length() > 200){
                desc = desc.substring(1 , 200);
            }
            
            Object[] inputValues = new Object[4];
            Object[] outputValues = new Object[0];
            inputValues[0] = BnsprType.NUMBER;
            inputValues[1] = txNo;
            inputValues[2] = BnsprType.STRING;
            inputValues[3] = desc;
            DALUtil.callOracleProcedure("{call pkg_eft.EFT_Hareket_Log (?,?)}" , inputValues , outputValues);
            logger.info("Karta No : " + cardNo + " call pkg_eft.EFT_Hareket_Log ba�ar�l�.");
            return true;
        } catch (Exception e){
            logger.info("Karta No : " + cardNo + " call pkg_eft.EFT_Hareket_Log hata : " + e.getMessage());

            e.printStackTrace();
            return false;
        }
    }
    
    @SuppressWarnings("unchecked")
    private static BigDecimal getDebitAccountNo(String cardNo, String dest, BigDecimal txNo) {
        try{
            GMMap cardInfoMap = new GMMap();
            cardInfoMap.put("CARD_NO" , cardNo);
            cardInfoMap.put("CARD_DCI" , "A");
            cardInfoMap = GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARD_DETAILS", cardInfoMap);
            if (!cardInfoMap.getString(CARD_DETAIL_INFO,0,CARD_STAT_CODE).equals("N") || !cardInfoMap.getString(CARD_DETAIL_INFO,0,CARD_SUB_STAT_CODE).equals("N")){
            	eftMessageLog(cardNo , "Debit Kart Aktif De�il" , txNo );
            	return BigDecimal.ZERO;
            }
            BigDecimal accountNo= cardInfoMap.getBigDecimal(CARD_DETAIL_INFO,0,DEBIT_ACCOUNT_NO);
         
            return accountNo;
        } catch (Exception e){
            return BigDecimal.ZERO;
        }
    }
    
    private static boolean eftToCreditCard(GMMap eftMap, String cardNo, BigDecimal tutar) {
        
        try{
            
            logger.info("======> eftToCreditCard ba�lad�.");
            GMMap iMapx = new GMMap();
            GMMap oMapx = new GMMap();
            GMMap oMapH = new GMMap();
            oMapH = GMServiceExecuter.call("BNSPR_COMMON_GET_SUBE_KOD" , oMapH);
            
            iMapx.put("ACCOUNT_BRANCH" , oMapH.getString("SUBE_KOD"));
            iMapx.put("ACCOUNT_NO" , "");
            
            iMapx.put("BRANCH_CODE" , oMapH.getString("SUBE_KOD"));
            
            iMapx.put("REFERENCE_NO" , eftMap.getString("TX_NO"));
            iMapx.put("CARD_NO" , cardNo);
            iMapx.put("ORIGINAL_RRN" , "");
            iMapx.put("TERMINAL_ID" , "9999999");
            
            GMMap oMapK = new GMMap();
            oMapK = GMServiceExecuter.call("BNSPR_COMMON_GET_KANAL_KOD" , oMapK);
            String channelCode;
            if (oMapK.getString("KANAL_KOD").equals("4") || oMapK.getString("KANAL_KOD").equals("10"))
                channelCode = Channel_INT;
            else
                if (oMapK.getString("KANAL_KOD").equals("5"))
                    channelCode = Channel_IVR;
                else channelCode = Channel_Branch;
            iMapx.put("CHANNEL_CODE" , channelCode);
            
            iMapx.put("PAYMENT_TYPE" , "E");
            iMapx.put("REQUEST_TYPE" , "N");
            iMapx.put("TXN_AMOUNT" , tutar);
            
            iMapx.put("TXN_CURR" , "TRY");
            iMapx.put("TXN_DESC" , eftMap.getString("ACIKLAMA"));
            
            oMapx = GMServiceExecuter.call("BNSPR_GENERAL_MAKE_CARD_PAYMENT" , iMapx);
            
            if (oMapx.getInt("RETURN_CODE") == OceanConstants.Result_Succesful){
                logger.info("Karta No : " + cardNo + " / Ocean kart �deme ba�ar�l�.");
                
                insertEftRrnLog(oMapx.getString("RRN") , eftMap.getBigDecimal("TX_NO"));
                
                eftMessageLog(cardNo , "Ocean kart �deme ba�ar�l�." , eftMap.getBigDecimal("TX_NO"));
                
                logger.info("======> eftToCreditCard bitti.");
                return true;
            } else{
                logger.info("Karta No : " + cardNo + " / Ocean kart �deme hata ald�. Ocean Hata : " + oMapx.getString("RETURN_CODE") + " / " + oMapx.getString("RETURN_DESCRIPTION"));
                String desc = "Ocean servis hatas�: " + oMapx.getString("RETURN_CODE") + " / " + oMapx.getString("RETURN_DESCRIPTION");
                eftMessageLog(cardNo , desc , eftMap.getBigDecimal("TX_NO"));
                logger.info("======> eftToCreditCard bitti.");
                return false;
            }
            
        } catch (Exception e){
            logger.info("Karta No : " + cardNo + " Ocean kart �deme hata ald�. Hata : " + e.getMessage());
            e.printStackTrace();
            eftMessageLog(cardNo , e.getMessage().toString() , eftMap.getBigDecimal("TX_NO"));
            return false;
        }
    }
    
    private static void insertEftRrnLog(String rrn, BigDecimal txNo) {
        Session session = DAOSession.getSession("BNSPRDal");
        EftTopupRrnLog rrnLog = new EftTopupRrnLog();
        
        rrnLog.setRrn(rrn);
        rrnLog.setTxNo(txNo);
        
        session.save(rrnLog);
        session.flush();
    }
    
    private static void tcknIleEft(String tckn, GMMap eftMap, BigDecimal txNo) throws SQLException {
        try{
            BigDecimal accountNo = BigDecimal.ZERO;
            BigDecimal tutarSon = BigDecimal.ZERO;
            String dci = "";
            String durum = "";
            String dest = "";
            boolean isProceedSystem=false;
            String cardNo = "";
            String stmt = "";
            GMMap iMap3 = new GMMap();
            iMap3.put("TC_KIMLIK_NO" , tckn);
            iMap3.put("TCKN" , tckn);
            iMap3.put("INPUT_PARAMETER_TYPE" , "TCKN");
            GMMap cardMap = GMServiceExecuter.call("BNSPR_GET_FIRST_CARD_NO_FOR_EFT" , iMap3);
            stmt = "SELECT SIRA_NO FROM BNSPR.V_ML_GNL_PARAM_TEXT t WHERE t.KOD = 'TFF_BASVURU_DURUM_KOD' and t.KEY1='ODEME_BEKLE'";
            
            durum = DALUtil.getResult(stmt);
            logger.info("�deme durum  => " + durum);
            cardNo = cardMap.get("CARD_NO") == null ? "" : cardMap.getString("CARD_NO");
            if (!cardNo.equals("")){
                GMMap cardProperty = new GMMap();
                cardProperty.put("CARD_NO" , cardNo);
                cardProperty = GMServiceExecuter.call("BNSPR_GET_CARD_PROPERTIES" , cardProperty);
                
                logger.info("cardProperty.RETURN_CODE => " + cardProperty.getString("RETURN_CODE"));
                
                if (cardProperty.getString("RETURN_CODE").equals("0")){
                    
                    logger.info("cardProperty.DESTINATION => " + cardProperty.getString("DESTINATION"));
                    logger.info("cardProperty.DCI => " + cardProperty.getString("DCI"));
                    
                    dci = cardProperty.getString("DCI");
                    dest = cardProperty.getString("DESTINATION");
                    isProceedSystem = cardProperty.getBoolean("IS_PROCEED");
                    
                    logger.info("Karta No : " + cardNo + " / kart tipi: " + dci);
                    
                    // if (dci.equals("E") && dest.equals("E")) {
                    // // eupt hesab� ile eft
                    // logger.info("===========> EUPT ile eft.");
                    // eftToEUP(eftMap, cardNo, txNo, tckn, basvuruNo);
                    //
                    // } else {
                    // logger.info("===========> Karta eft.");
                    // if (!cardNo.equals("")) {
                    // doEftToCard(eftMap, cardNo, dci, txNo, dest);
                    //
                    // }
                    // else {
                    // logger.info("===========> cardNo bo�.");
                    // eftMessageLog(cardNo, "Kart bulunamad�.", eftMap.getBigDecimal("TX_NO"));
                    // updateEftStatus(cardNo, txNo, Eft_Status_Card_NO);
                    // }
                    // }
                    
                } else{
                    logger.info("Kart bini tan�ms�z.");
                    eftMessageLog(cardNo , "Kart bini tan�ms�z." , eftMap.getBigDecimal("TX_NO"));
                    updateEftStatus(cardNo , txNo , Eft_Status_Card_NO);
                }
            }
            BigDecimal tutar = eftMap.getBigDecimal("TUTAR");
            logger.info("toplam tutar ======> " + tutar);
            BigDecimal tutarIlk = tutar;
            GMMap basMap = GMServiceExecuter.call("BNSPR_TFF_GET_AKTIF_BASVURU_LIST" , iMap3);
            
            if (cardNo.equals("") && basMap.getSize("BASVURU_BILGILERI") > 0){
                if (basMap.getSize("BASVURU_BILGILERI") == 1){
                    logger.info("Bir tane ba�vuru var");
                    eftToEUP(eftMap , basMap.getString("BASVURU_BILGILERI" , 0 , "EUPT_HESAP_NO") , txNo , tckn , basMap.getString("BASVURU_BILGILERI" , 0 , "BASVURU_NO") , tutar , false);
                } else{
                    logger.info("Birden fazla ba�vuru var");
                    for (int i = 0; i < basMap.getSize("BASVURU_BILGILERI"); i++){
                        if (basMap.getString("BASVURU_BILGILERI" , i , "DURUM_KODU_SIRA").equals(durum)){
                            tutar =
                                    eftToEUP(eftMap , basMap.getString("BASVURU_BILGILERI" , i , "EUPT_HESAP_NO") , txNo , tckn , basMap.getString("BASVURU_BILGILERI" , i , "BASVURU_NO") , tutar ,
                                            true);
                            logger.info("kalan tutar ======> " + tutar);
                        }
                    }
                    if (tutar.compareTo(BigDecimal.ZERO) == 1){
                        for (int i = 0; i < basMap.getSize("BASVURU_BILGILERI"); i++){
                            if (basMap.getInt("BASVURU_BILGILERI" , i , "DURUM_KODU_SIRA") >= Integer.valueOf(durum)){
                                logger.info("en eski ba�vuru ======> " + basMap.getString("BASVURU_BILGILERI" , i , "BASVURU_NO"));
                                eftToEUP(eftMap , basMap.getString("BASVURU_BILGILERI" , i , "EUPT_HESAP_NO") , txNo , tckn , basMap.getString("BASVURU_BILGILERI" , i , "BASVURU_NO") , tutar , false);
                                break;
                            }
                        }
                    }
                    
                }
                eftMessageLog(basMap.getString("BASVURU_BILGILERI" , 0 , "EUPT_HESAP_NO") , "EUPT transfer ba�ar�l�." , txNo);
                updateEftEUPTStatus(basMap.getString("BASVURU_BILGILERI" , 0 , "EUPT_HESAP_NO") , txNo , Eft_Status_Eupt_OK);
                
                Object[] inputValues = new Object[2];
                Object[] outputValues = new Object[0];
                inputValues[0] = BnsprType.NUMBER;
                inputValues[1] = txNo;
                DALUtil.callOracleProcedure("{call Pkg_Eupt.KRED_KART_MUHASEBE(?)}" , inputValues , outputValues);
            } else
                if (!cardNo.equals("") && basMap.getSize("BASVURU_BILGILERI") == 0){
                    logger.info("ba�vuru yok sadece kart var, kart no =======>" + cardNo);
                    doEftToCard(eftMap , cardNo , dci , txNo , dest,isProceedSystem);
                } else
                    if (!cardNo.equals("") && basMap.getSize("BASVURU_BILGILERI") > 0){
                        for (int i = 0; i < basMap.getSize("BASVURU_BILGILERI"); i++){
                            logger.info("hem kart� hem ba�vurusu var ");
                            logger.info(basMap.getString("BASVURU_BILGILERI" , i , "DURUM_KODU_SIRA"));
                            if (basMap.getString("BASVURU_BILGILERI" , i , "DURUM_KODU_SIRA").equals(durum)){
                                logger.info("ba�lang�� tutar ======> " + tutar);
                                tutar =
                                        eftToEUP(eftMap , basMap.getString("BASVURU_BILGILERI" , i , "EUPT_HESAP_NO") , txNo , tckn , basMap.getString("BASVURU_BILGILERI" , i , "BASVURU_NO") , tutar ,
                                                true);
                                logger.info("kalan tutar ======> " + tutar);
                            }
                        }
                        // eftMessageLog(basMap.getString("BASVURU_BILGILERI", 0, "EUPT_HESAP_NO"),
                        // "EUPT transfer ba�ar�l�.", txNo);
                        if (tutar.compareTo(BigDecimal.ZERO) == 1){
                            logger.info("karta kalan tutar ======> " + tutar);
                            tutarSon = tutar;
                            Session session = DAOSession.getSession("BNSPRDal");
                            EftKartOdemeTx eftKartOdemeTx = new EftKartOdemeTx();
                            
                            if (dci.equals("P")){
                                boolean eftStatusPrepaid = eftToPrepaidCard(txNo , cardNo , eftMap , tutarSon, dest);
                                
                                if (eftStatusPrepaid == true){
                                    logger.info("======> Prepaid kart� i�in muhasebe.");
                                    
                                } else{
                                    throw new Exception("PP Karta EFT Hata Ald� Kart No: " + cardNo);
                                }
                                
                                // logger.info("Karta No : " + cardNo + " / EFT durumu update ediliyor. Durum :" +
                                // Eft_Status_Prepaid_OK+ " " +tutarSon);
                                if (dest.equals("I")){
                                	updateEftStatus(cardNo , txNo , Eft_Status_Prepaid_OK);
                                	eftKartOdemeTx.setTut1HesapNo(getGlobalParam("PREPAID_YUKLEME_HAVUZ"));
                                }else if(dest.equals("O") && !isProceedSystem){
                                	updateEftStatus(cardNo , txNo , Eft_Status_Ocean_Prepaid_OK);
                                	eftKartOdemeTx.setTut1HesapNo(getGlobalParam("OCEAN_PREPAID_TOPUP_HAVUZ"));
                                }else if(dest.equals("O") && isProceedSystem){
                                	updateEftStatus(cardNo , txNo , Eft_Status_Ocean_Proceed_OK);
                                	eftKartOdemeTx.setTut1HesapNo(getGlobalParam("MCHIP_TOPUP_HESAP"));
                                }
                                eftKartOdemeTx.setTut1HesapTur("DK");
                                eftKartOdemeTx.setTutar1(tutarSon);
                            } else
                                if (dci.equals("C")){
                                    boolean eftStatusCC = eftToCreditCard(eftMap , cardNo , tutarSon);
                                    
                                    if (eftStatusCC == true){
                                        logger.info("======> Kredi kart� i�in muhasebe.");
                                        
                                    } else{
                                        
                                       throw new Exception("Kredi Kart�na EFT Hata Ald� Kart No: " + cardNo);
                                    }
                                    // logger.info("Karta No : " + cardNo + " / EFT durumu update ediliyor. Durum :" +
                                    // Eft_Status_Card_OK + " " +tutarSon);
                                    updateEftStatus(cardNo , txNo , Eft_Status_Card_OK);
                                    
                                    eftKartOdemeTx.setTut1HesapNo(getGlobalParam("KKART_ODEME_HAVUZ"));
                                    eftKartOdemeTx.setTut1HesapTur("DK");
                                    eftKartOdemeTx.setTutar1(tutarSon);
                                } else
                                    if (dci.equals("D")){
                                        logger.info("Karta No : " + cardNo + " / EFT durumu update ediliyor. Durum :" + Eft_Status_Card_OK + " " + tutarSon);
                                        updateEftStatus(cardNo , txNo , Eft_Status_Card_OK);
                                        
                                        accountNo = getDebitAccountNo(cardNo , dest, txNo);
                                        eftKartOdemeTx.setTut1HesapNo(accountNo.toString());
                                        eftKartOdemeTx.setTut1HesapTur("VS");
                                        eftKartOdemeTx.setTutar1(tutarSon);
                                    }
                            eftKartOdemeTx.setAciklama("");
                            eftKartOdemeTx.setAlanBankaKodu("");
                            eftKartOdemeTx.setAlanSubeKodu("");
                            eftKartOdemeTx.setAliciAdi("");
                            eftKartOdemeTx.setMesajKodu("");
                            eftKartOdemeTx.setTut2HesapNo(getGlobalParam("TFF_PARA_YUKLEME_BASVURU_HVZ"));
                            eftKartOdemeTx.setTut2HesapTur("DK");
                            eftKartOdemeTx.setTutar2(tutarIlk.subtract(tutarSon));
                            eftKartOdemeTx.setTxNo(txNo);
                            session.saveOrUpdate(eftKartOdemeTx);
                            session.flush();
                            if (dci.equals("D")){
                                Object[] inputValues = new Object[4];
                                Object[] outputValues = new Object[0];
                                inputValues[0] = BnsprType.NUMBER;
                                inputValues[1] = txNo;
                                inputValues[2] = BnsprType.NUMBER;
                                inputValues[3] = accountNo;
                                DALUtil.callOracleProcedure("{call Pkg_Eft_Mesaj.KRED_KART_MUHASEBE (?,?)}" , inputValues , outputValues);
                                
                                logger.info("Debit Karta No : " + cardNo + " call Pkg_Eft_Mesaj.KRED_KART_MUHASEBE ba�ar�l�.");
                                
                            } else{
                                Object[] inputValues = new Object[2];
                                Object[] outputValues = new Object[0];
                                inputValues[0] = BnsprType.NUMBER;
                                inputValues[1] = txNo;
                                DALUtil.callOracleProcedure("{call Pkg_Eft_Mesaj.KRED_KART_MUHASEBE (?)}" , inputValues , outputValues);
                                logger.info("Kredi Karta No : " + cardNo + " call Pkg_Eft_Mesaj.KRED_KART_MUHASEBE ba�ar�l�.");
                            }
                            
                        }else{
                        	eftMessageLog(basMap.getString("BASVURU_BILGILERI" , 0 , "EUPT_HESAP_NO") , "EUPT transfer ba�ar�l�." , txNo);
                            updateEftEUPTStatus(basMap.getString("BASVURU_BILGILERI" , 0 , "EUPT_HESAP_NO") , txNo , Eft_Status_Eupt_OK);
                            
                            Object[] inputValues = new Object[2];
                            Object[] outputValues = new Object[0];
                            inputValues[0] = BnsprType.NUMBER;
                            inputValues[1] = txNo;
                            DALUtil.callOracleProcedure("{call Pkg_Eupt.KRED_KART_MUHASEBE(?)}" , inputValues , outputValues);
                        }
                        
                    } else{
                        logger.info("tckn ile EFT Hesap numaras� hatal�");
                        updateEftStatus(cardNo , txNo , Eft_Status_Card_NO);
                        
                    }
        } catch (Exception e){
        	
            eftMessageLog("" , e.getMessage() , txNo);
            updateEftStatus("" , txNo , Eft_Status_Card_NO);
            logger.info("Karta No : " + " call pkg_eft.EFT_Hareket_Log hata : " + e.getMessage());
            e.printStackTrace();
            
        }
        
    }
    
    /*
     * private static boolean isCardInAvailableStatu(String string) { return true; }
     */
    public static String getGlobalParam(String batchParamCode) {
        GMMap iMapG = new GMMap();
        iMapG.put("KOD" , batchParamCode);
        iMapG.put("TRIM_QUOTES" , true);
        String batchNo = GMServiceExecuter.call("BNSPR_SISTEM_GET_GLOBAL_PARAMETRE" , iMapG).getString("DEGER");
        return batchNo;
    }
    public static String getCardNofromIban (String iban){
    	Session session = DAOSession.getSession("BNSPRDal"); 
    	GnlMusteriSanaliban sanalIban = (GnlMusteriSanaliban) session.createCriteria(GnlMusteriSanaliban.class).add(Restrictions.eq("iban", iban)).uniqueResult();
    	BigDecimal musteriNo = sanalIban.getMusteriNo();
    	String cardNo="false";
    	GMMap iMap = new GMMap();
    	iMap.put("CUSTOMER_NO", musteriNo);
    	iMap.put("CARD_BANK_STATUS", "N");
    	iMap.putAll(GMServiceExecuter.call("BNSPR_GENERAL_GET_CUSTOMER_CARDS", iMap));
    	for (int i = 0; i < iMap.getSize("CARD_DETAIL_INFO"); i++) {
    		if("V".equals(iMap.getString("CARD_DETAIL_INFO",i,"PHYSICAL_TYPE"))&&"914".equals(iMap.getString("CARD_DETAIL_INFO",i,"CARD_PRODUCT_ID"))){
    			cardNo=iMap.getString("CARD_DETAIL_INFO",i,"CARD_NO");
    			break;
    		}
			
		}
    	return cardNo;
    	
    }
}
