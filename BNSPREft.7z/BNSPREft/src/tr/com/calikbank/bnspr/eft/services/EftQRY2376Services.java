package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class EftQRY2376Services {
	@GraymoundService("BNSPR_QRY2376_GET_EFT_MESAJLARI")
	public static GMMap getGidenEftMesajlari(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_eft.RC_QRY2376_GET_EFT_MESAJLARI(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("GERCEKLESME_DURUMU"));
			stmt.setString(i++, iMap.getString("SIRALAMA_KRITERI"));
			stmt.setString(i++, iMap.getString("EFT_URUN_TUR"));
			
			if ((iMap.get("ILK_TARIH") != null)) stmt.setDate(i++, new Date(iMap.getDate("ILK_TARIH").getTime()));
			else stmt.setDate(i++, null);

			if ((iMap.get("SON_TARIH") != null)) stmt.setDate(i++, new Date(iMap.getDate("SON_TARIH").getTime()));
			else stmt.setDate(i++, null);
			
			if (iMap.getBigDecimal("MIN_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_TUTAR"));

			if (iMap.getBigDecimal("MAX_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_TUTAR"));
			
			stmt.setString(i++, iMap.getString("MESAJ_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));
			stmt.setString(i++, iMap.getString("BANKA_KODU"));
			stmt.setString(i++, iMap.getString("BANKA_SUBE_KODU"));
			stmt.setString(i++, iMap.getString("SUBE_KODU"));
			stmt.setString(i++, iMap.getString("K_KANAL"));
			

			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
            String tableName = "GELGON_EFT_GIRIS";
			int row = 0;
			BigDecimal gelenTutar = new BigDecimal(0);
			BigDecimal gidenTutar = new BigDecimal(0);
			BigDecimal gerceklesmemisToplam = new BigDecimal(0);
			while (rSet.next()) {
				oMap.put(tableName, row,"TRX_NO", rSet.getString("tx_no"));
				oMap.put(tableName, row,"YARATAN_BOLUM_KODU", rSet.getString("yaratan_bolum_kodu"));
				oMap.put(tableName, row,"EFT_URUN_TUR", rSet.getString("eft_urun_tur"));
                if(rSet.getString("eft_urun_tur").equals("GELEN")){
    				gelenTutar = gelenTutar.add(rSet.getBigDecimal("tutar"));
                }else if(rSet.getString("eft_urun_tur").equals("GIDEN")){
    				gidenTutar = gidenTutar.add(rSet.getBigDecimal("tutar"));
                }
                oMap.put(tableName, row,"MUSTERI_NO", rSet.getString("musteri_no"));
                oMap.put(tableName, row,"UNVAN", rSet.getString("unvan"));
                oMap.put(tableName, row,"HESAP_NO", rSet.getString("hesap_no"));
                oMap.put(tableName, row,"TUTAR", rSet.getString("tutar"));
                
                oMap.put(tableName, row,"NDB_BANKA_ADI", rSet.getString("ndb_banka_adi"));
                oMap.put(tableName, row,"NDB_KULL_ORAN", rSet.getString("ndb_kull_oran"));
                oMap.put(tableName, row,"NDB_GER_ORAN", rSet.getString("ndb_ger_oran"));
                oMap.put(tableName, row,"GIREN_KULLANICI", rSet.getString("giren_kullanici"));
                oMap.put(tableName, row,"KANAL", rSet.getString("kanal"));
               if  (rSet.getBigDecimal("gerceklesmemis_toplam")!=null)
				gerceklesmemisToplam = gerceklesmemisToplam.add(rSet.getBigDecimal("gerceklesmemis_toplam"));
				row++;
			}

			oMap.put("GELEN_TUTAR", gelenTutar);
			oMap.put("GIDEN_TUTAR", gidenTutar);
			oMap.put("GERCEKLESMEMIS_TOPLAM", gerceklesmemisToplam);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2376_GET_EFT_MASRAFLARI")
	public static GMMap getEftMasraflari(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_eft.RC_QRY2376_GET_EFT_MASRAFLARI(?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TRX_NO"));

			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "EFT_GELGON_KULANIM";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row,"BILDIRIM_NO", rSet.getString("bildirim_no"));
				oMap.put(tableName, row,"ISLEM_TUTAR", rSet.getString("islem_tutar"));
				oMap.put(tableName, row,"TUTAR", rSet.getBigDecimal("tutar"));
				oMap.put(tableName, row,"YARATAN_TX_NO", rSet.getString("yaratan_tx_no"));
				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}


