package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2388Services {

		@GraymoundService("BNSPR_TRN2388_GET_INITIAL_VALUES")
		public static GMMap getInitialValues(GMMap iMap) {
			Connection conn = null;
			CallableStatement stmt = null;
			try {
				GMMap oMap = new GMMap();
				conn = DALUtil.getGMConnection();

				
				stmt = conn.prepareCall("{call PKG_TRN2315.form_instance(?,?,?,?,?,?)}");

				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.registerOutParameter(2, Types.VARCHAR);
				stmt.registerOutParameter(3, Types.VARCHAR);
				
				
				stmt.registerOutParameter(4, Types.DATE);
				stmt.registerOutParameter(5, Types.DECIMAL);
				stmt.registerOutParameter(6, Types.VARCHAR);
				stmt.execute();

				oMap.put("SUBE_KODU", stmt.getString(1));
				oMap.put("BANKA_KODU", stmt.getString(2));
				oMap.put("BANKA_ADI", stmt.getString(3));
				oMap.put("EFT_TARIH", stmt.getDate(4));
				oMap.put("TRX_NO", stmt.getBigDecimal(5));

  
				
				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}
		
		
	
		
		@GraymoundService("BNSPR_TRN2388_GET_EFT_INFO")
		public static GMMap getEftInfo(GMMap iMap) {
			try{
				Session session = DAOSession.getSession("BNSPRDal");
				
				EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
				
				GMMap oMap = new GMMap();
		        
				oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
		        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
		        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
		        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
		        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
		        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
		        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());

		        oMap.put("TRX_NO" , eftEftTx.getTxNo());
		        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
		        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
		        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
		        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
		        oMap.put("DURUM" , eftEftTx.getDurum());	  
		        
		        if((eftEftTx.getIlgiliIslemNumara() != null) & (!StringUtils.isEmpty(eftEftTx.getIlgiliIslemNumara().toString())))
		        oMap.put("SATIS_ISLEM_TX_NO", eftEftTx.getIlgiliIslemNumara());
		        
		        if((eftEftTx.getIlgiliIslemReferansi() != null) & (!StringUtils.isEmpty(eftEftTx.getIlgiliIslemReferansi())))
		        oMap.put("SATIS_ISLEM_NO", eftEftTx.getIlgiliIslemReferansi());
		        
		        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
				
				return oMap;
			}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}	
	
}
