package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;

import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class EftQRY2310Services {
	@GraymoundService("BNSPR_TRN2310_GET_IADE_TALEP")
	public static GMMap getH01EftMesajlari(GMMap iMap) {
	                                                                  
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_eft.RC_QRY2310_M09_IADE_TALEPLERI(?,?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
        	if (!(iMap.getDate("K_EFT_TARIH_BAS") == null)) {
					stmt.setDate(i++,  new java.sql.Date(iMap.getDate("K_EFT_TARIH_BAS").getTime()));
			} else {
					stmt.setDate(i++, null);
			}
			if (!(iMap.getDate("K_EFT_TARIH_BIT") == null)) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("K_EFT_TARIH_BIT").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			String tableName = "EFT_MESAJLARI";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row,"TRX_NO", rSet.getString("TX_NO"));
				oMap.put(tableName, row,"EFT_TARIH", rSet.getDate("EFT_TARIH"));
				oMap.put(tableName, row,"EFT_SORGU_NO", rSet.getString("SORGU_NO"));
				oMap.put(tableName, row,"GON_BANKA_ADI", rSet.getString("GON_BANKA_ADI"));
				oMap.put(tableName, row,"TALEP_TAR", rSet.getDate("TALEP_TAR"));
				oMap.put(tableName, row,"TALEP_SORGU_NO", rSet.getString("TALEP_SN"));
				oMap.put(tableName, row,"TALEP_TXNO", rSet.getString("TALEP_TXNO"));
				oMap.put(tableName, row,"TALEP_MESAJ_KODU", rSet.getString("KAS_MESAJ_KODU"));
				oMap.put(tableName, row,"TALEP_EKRAN_KODU", rSet.getString("ISLEM_KOD"));
				oMap.put(tableName, row,"BILGI", rSet.getString("BILGI"));
				oMap.put(tableName, row,"TALEP_SEBEP", rSet.getString("TALEP_SEBEP"));
				row++;
			}

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}


