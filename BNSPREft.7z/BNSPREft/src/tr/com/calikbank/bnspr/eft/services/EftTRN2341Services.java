package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.aktifbank.bnspr.dao.EftBelgeTx;
import tr.com.aktifbank.bnspr.dao.EftBelgeTxId;
import tr.com.aktifbank.bnspr.dao.EftBelgeKriterTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2341Services {
	
	@GraymoundService("BNSPR_TRN2341_INITIALIZE")
	public static GMMap initialize(GMMap iMap) {
		
		GMMap oMap = new GMMap();
		iMap.put("KOD", "PFT_BELGE_DURUM");
		iMap.put("ADD_EMPTY_KEY", "E");
		oMap.put("PFT_BELGE_DURUM", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
		
		oMap.putAll(DALUtil.fillComboBox(oMap, "GIDEN_EFT_DURUM", true, "SELECT key1,text from gnl_param_text where kod ='GIDEN_EFT_DURUM' and key1 in ('2.ONAY', 'TAMAM', 'RELEASE', 'TCMB', 'IADE', 'IPTAL','RED') order by text"));
		
		oMap.putAll(DALUtil.fillComboBox(oMap, "GIDEN_EFT_DURUM_TABLE", true, "SELECT key1,text from gnl_param_text where kod ='GIDEN_EFT_DURUM' order by text"));
		
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN2341_GET_EFT_LIST")
	public static GMMap getEftList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_PFT.GET_EFT_LIST(?,?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.setString(i++, iMap.getString("EFT_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("REF_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("EFT_ISLEM_NO"));
			if(iMap.getString("AD_SOYAD").isEmpty())
				stmt.setString(i++, null);
			else
				stmt.setString(i++, iMap.getString("AD_SOYAD"));
			
			stmt.setString(i++, iMap.getString("DURUM"));
			if ((iMap.get("TARIH_BAS") != null)) stmt.setDate(i++, new Date(iMap.getDate("TARIH_BAS").getTime()));
			else stmt.setDate(i++, null);
			if ((iMap.get("TARIH_SON") != null)) stmt.setDate(i++, new Date(iMap.getDate("TARIH_SON").getTime()));
			else stmt.setDate(i++, null);
			stmt.setString(i++, iMap.getString("GONDEREN_TCKN"));
			stmt.setString(i++, iMap.getString("GONDEREN_PTT_SUBESI"));
			stmt.setString(i++, iMap.getString("ALICI_BANKA"));
			stmt.setString(i++, iMap.getString("GONDEREN_PTT_KULL_SICIL_KOD"));
			stmt.setString(i++, "H");
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = DALUtil.rSetResults(rSet, "EFT_LIST");
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2341_GET_EFT_BELGE_LIST")
	public static GMMap getEftBelgeList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_PFT.GET_EFT_BELGE_LIST(?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("REF_NO"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			int row =0;
			String tableName = "EVRAK_LIST_TABLE";
			while(rSet.next()){
				oMap.put(tableName, row, "DOKUMAN_KOD", rSet.getString("DOKUMAN_KOD"));
				oMap.put(tableName, row, "DOKUMAN_ADI", rSet.getString("DOKUMAN_ADI"));
				oMap.put(tableName, row, "DURUM", rSet.getString("DURUM"));
				if("E".equals(rSet.getString("ALINDI")))
					oMap.put(tableName, row, "ALINDI", "true");
				else
					oMap.put(tableName, row, "ALINDI", "false");
				oMap.put(tableName, row, "SORGU_NO", iMap.getBigDecimal("REF_NO"));
				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2341_SAVE")
	public static GMMap Save (GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftBelgeKriterTx eftBelgeKriterTx = (EftBelgeKriterTx)session.get(EftBelgeKriterTx.class, iMap.getBigDecimal("TX_NO"));
			
			if(eftBelgeKriterTx == null) {
				eftBelgeKriterTx = new EftBelgeKriterTx();
			}
			eftBelgeKriterTx.setTxNo(iMap.getBigDecimal("TX_NO"));
			eftBelgeKriterTx.setAlanBankaKodu(iMap.getString("ALAN_BANKA_KODU"));
			eftBelgeKriterTx.setBasTarih(iMap.getDate("BAS_TARIH"));
			eftBelgeKriterTx.setBitTarih(iMap.getDate("BIT_TARIH"));
			eftBelgeKriterTx.setDurum(iMap.getString("DURUM"));
			eftBelgeKriterTx.setEftSorguNo(iMap.getBigDecimal("EFT_SORGU_NO"));
			eftBelgeKriterTx.setGonderenAdi(iMap.getString("GONDEREN_ADI"));
			eftBelgeKriterTx.setIsleminYapildigiYer(iMap.getString("ISLEMIN_YAPILDIGI_YER"));
			eftBelgeKriterTx.setIslemiYapanKullanici(iMap.getString("ISLEMI_YAPAN_KULLANICI"));
			eftBelgeKriterTx.setMesajKodu(iMap.getString("MESAJ_KODU"));
			eftBelgeKriterTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			eftBelgeKriterTx.setEftIslemNo(iMap.getBigDecimal("EFT_ISLEM_NO"));
			
			session.saveOrUpdate(eftBelgeKriterTx);
			
			String tableName = "EVRAK_LISTESI";
			List<?> list = (List<?>) iMap.get(tableName);
			for(int i=0; i<list.size();i++) {
				EftBelgeTxId id = new EftBelgeTxId();
				id.setDokumanKod(iMap.getString(tableName,i,"DOKUMAN_KOD"));
				id.setEftSorguNo(iMap.getBigDecimal(tableName,i,"SORGU_NO"));
				id.setTxNo(iMap.getBigDecimal("TX_NO"));
				
				EftBelgeTx eftBelgeTx = new EftBelgeTx();
				eftBelgeTx.setId(id);
				if(iMap.getBoolean(tableName,i,"ALINDI"))
				{
					eftBelgeTx.setAlindi("E");
					eftBelgeTx.setDurum(iMap.getString(tableName,i,"DURUM"));
				}
				else
				{
					eftBelgeTx.setAlindi("H");
					eftBelgeTx.setDurum(null);
				}

				session.saveOrUpdate(eftBelgeTx);
			}
			session.flush();
			
			iMap.put("TRX_NO", iMap.getBigDecimal("TX_NO"));
			iMap.put("TRX_NAME", "2341");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}

	@GraymoundService("BNSPR_TRN2341_GET_INFO")
	public static Map<?, ?> getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftBelgeKriterTx eftBelgeKriterTx = (EftBelgeKriterTx)session.get(EftBelgeKriterTx.class, iMap.getBigDecimal("TRX_NO"));
			oMap.put("ALAN_BANKA_KODU", eftBelgeKriterTx.getAlanBankaKodu());
			oMap.put("BAS_TARIH", eftBelgeKriterTx.getBasTarih());
			oMap.put("BIT_TARIH", eftBelgeKriterTx.getBitTarih());
			oMap.put("DURUM", eftBelgeKriterTx.getDurum());
			oMap.put("EFT_SORGU_NO", eftBelgeKriterTx.getEftSorguNo());
			oMap.put("GONDEREN_ADI", eftBelgeKriterTx.getGonderenAdi());
			oMap.put("ISLEMIN_YAPILDIGI_YER", eftBelgeKriterTx.getIsleminYapildigiYer());
			oMap.put("ISLEMI_YAPAN_KULLANICI", eftBelgeKriterTx.getIslemiYapanKullanici());
			oMap.put("MESAJ_KODU", eftBelgeKriterTx.getMesajKodu());
			oMap.put("TC_KIMLIK_NO", eftBelgeKriterTx.getTcKimlikNo());
			oMap.put("TX_NO", eftBelgeKriterTx.getTxNo());
			oMap.put("EFT_ISLEM_NO", eftBelgeKriterTx.getEftIslemNo());
			
			List<?> recordList 		= (List<?>)session.createCriteria(EftBelgeTx.class)
			.add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO")))
			.list();
			
			GMMap tempMap = new GMMap();
			tempMap.put("REF_NO", eftBelgeKriterTx.getEftSorguNo());
			tempMap = getEftBelgeList (tempMap);
			String tableEvrak = "EVRAK_LIST_TABLE";

			EftBelgeTx eftBelgeTx = null;
			String tableName = "EVRAK_LISTESI";
			for (int i=0; i<recordList.size(); i++){
				eftBelgeTx = (EftBelgeTx)recordList.get(i);
				oMap.put(tableName,i,"DOKUMAN_KOD", eftBelgeTx.getId().getDokumanKod());
				oMap.put(tableName,i,"DOKUMAN_ADI", tempMap.getString(tableEvrak, i, "DOKUMAN_ADI"));
				if("E".equals(eftBelgeTx.getAlindi()))
					oMap.put(tableName,i,"ALINDI", "true");
				else
					oMap.put(tableName,i,"ALINDI", "false");
				oMap.put(tableName,i,"DURUM", eftBelgeTx.getDurum());
			}
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2341_ONAYDA_BEKLEYEN_ISLEM_VAR_MI")
	public static GMMap onaydaBekleyenIslemVarMi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ call PKG_TRN2341.Onay_Bekleyen_Kontrol}");
			stmt.execute();
			
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
