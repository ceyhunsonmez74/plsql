package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;


import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2356Services {
	@GraymoundService("BNSPR_TRN2356_GET_INITIAL_VALUES")
	public static GMMap getInitialValues(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			
			stmt = conn.prepareCall("{call PKG_TRN2356.form_instance(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");

			stmt.setBigDecimal(1, iMap.getBigDecimal("EMKT_TRX_NO"));
			
			stmt.registerOutParameter(2, Types.DATE);
			stmt.registerOutParameter(3, Types.DECIMAL);
			
			stmt.registerOutParameter(4, Types.VARCHAR);
			stmt.registerOutParameter(5, Types.VARCHAR);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.registerOutParameter(7, Types.VARCHAR);
			stmt.registerOutParameter(8, Types.VARCHAR);
			stmt.registerOutParameter(9, Types.VARCHAR);
			
			
			stmt.registerOutParameter(10, Types.VARCHAR);
			stmt.registerOutParameter(11, Types.DECIMAL);
			stmt.registerOutParameter(12, Types.DECIMAL);
			stmt.registerOutParameter(13, Types.DECIMAL);
			stmt.registerOutParameter(14, Types.VARCHAR);
			stmt.registerOutParameter(15, Types.VARCHAR);
			stmt.registerOutParameter(16, Types.VARCHAR);
			stmt.registerOutParameter(17, Types.DECIMAL);
			
			
			stmt.execute();

			oMap.put("EFT_TARIH", stmt.getDate(2));
			oMap.put("TRX_NO", stmt.getBigDecimal(3));
    
			
			oMap.put("GONDEREN_BANKA_KODU", stmt.getString(4));
			oMap.put("GONDEREN_SUBE_KODU", stmt.getString(5));
			oMap.put("GONDEREN_SEHIR", stmt.getString(6));
			oMap.put("DISPLAY_GONDEREN_SEHIR", stmt.getString(15));
			oMap.put("DISPLAY_GONDEREN_SUBE", stmt.getString(16));
			
			oMap.put("ALAN_BANKA_KODU", stmt.getString(7));
			oMap.put("ALAN_SUBE_KODU", stmt.getString(8));
			oMap.put("ALAN_SEHIR_KODU", stmt.getString(9));
			
			oMap.put("KIYMET_KODU", stmt.getString(10));
			
			oMap.put("SATIS_ISLEM_NO", stmt.getBigDecimal(11)); 
	
			oMap.put("MIKTAR", stmt.getBigDecimal(13)); 
			oMap.put("TUTAR", stmt.getBigDecimal(12)); 
			oMap.put("CIKIS_DEPO_KODU", stmt.getString(14));
			oMap.put("GIRIS_DEPO_KODU", "501");
			oMap.put("P_ORAN", stmt.getString(17));

			
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2356_GET_EFT_INFO")
	public static GMMap getEftInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
	        
			oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("TUTAR" , eftEftTx.getTutar());
	        oMap.put("KIYMET_KODU" , eftEftTx.getKiymetKodu());
	        oMap.put("MIKTAR" , eftEftTx.getMiktar());
	        oMap.put("KULLANICI_REFERANSI" , eftEftTx.getKullaniciReferansi());
	        oMap.put("PARCA_TESL_IZIN_GOSTERGE" , eftEftTx.getParcaTeslIzinGosterge());
	        oMap.put("CIKIS_DEPO_KODU" , eftEftTx.getCikisDepoKodu());
	        oMap.put("GIRIS_DEPO_KODU" , eftEftTx.getGirisDepoKodu());
	        oMap.put("GIRIS_DEPO_KODU" , eftEftTx.getGirisDepoKodu());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("ACIKLAMA_2" , eftEftTx.getAciklama2());
	        oMap.put("SATIS_ISLEM_NO" , eftEftTx.getSatisIslemNo());
	        
	        oMap.put("TRX_NO" , eftEftTx.getTxNo());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("DURUM" , eftEftTx.getDurum());	  	        

	        
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY2356_GET_EFT_MESALARI")
	public static GMMap getEftMEsaj(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN2356.Get_EFT_EMKT_MESAJ()}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "EFT_EMKT_ALIS";
			GMMap oMap = DALUtil.rSetResults(rSet, tableName);
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
		
	

	@GraymoundService("BNSPR_TRN2356_TOLERANS_HESAPLA")
	public static GMMap toleransHesapla(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			
			stmt = conn.prepareCall("{call PKG_TRN2356.tolerans_hesapla(?,?,?)}");

			stmt.setString(1, iMap.getString("EMKT_TRX_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("MIKTAR"));
			stmt.setBigDecimal(3, iMap.getBigDecimal("TUTAR"));

			stmt.execute();
			
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
		
	
	
}
