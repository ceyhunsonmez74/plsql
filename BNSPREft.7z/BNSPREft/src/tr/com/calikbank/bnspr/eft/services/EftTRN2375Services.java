package tr.com.calikbank.bnspr.eft.services;


import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EftiadeKoduTx;
import tr.com.aktifbank.bnspr.dao.EftiadeKoduTxId;
import tr.com.aktifbank.bnspr.dao.FacHesapTanim;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;


import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

//

public class EftTRN2375Services {
	

	
	@GraymoundService("BNSPR_TRN2375_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> paremetrePersistentList = session.createCriteria(EftiadeKoduTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			String tableName = "EFT_IADE_KODU";
			int row = 0;
			for (Iterator<?> iterator = paremetrePersistentList.iterator(); iterator.hasNext();row++) {
				EftiadeKoduTx eftiadeKoduTx = (EftiadeKoduTx) iterator.next();
				oMap.put(tableName, row, "KOD",   eftiadeKoduTx.getId().getKod());
				oMap.put(tableName, row, "ACIKLAMA", eftiadeKoduTx.getId().getAciklama());
		    }

			oMap.put("TRX_NO", iMap.get("TRX_NO"));

			
		} catch (Exception e) {
			EftServices.throwGMBusssinessException(e.getMessage());
			//throw new GMRuntimeException(0, e);
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TRN2375_SAVE_PARAMETRE_TANIM")
	public static Map<?, ?> saveParametreTanim(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			
			
			ArrayList<?> eftiadeKoduTxList = (ArrayList<?>) session.createCriteria(
					EftiadeKoduTx.class)
					.add(Restrictions.eq("id.txNo",iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = eftiadeKoduTxList.iterator(); iterator
					.hasNext();) {
				EftiadeKoduTx eftiadeKoduTx2 = (EftiadeKoduTx) iterator.next();
				session.delete(eftiadeKoduTx2);
			}
			session.flush();			
			
			
			
			
			String tableName = "EFT_IADE_KODU";
			List<?> paremetreGuiList = (List<?>)iMap.get(tableName);
			EftiadeKoduTxId id = null ; 
			for (int i = 0; i < paremetreGuiList.size(); i++) {
				EftiadeKoduTx eftiadeKoduTx = (EftiadeKoduTx)session.createCriteria(EftiadeKoduTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.kod",iMap.getString(tableName, i, "kod"))).uniqueResult();
				if(eftiadeKoduTx == null){
					eftiadeKoduTx = new EftiadeKoduTx();
				}
				id = new EftiadeKoduTxId();
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setKod(iMap.getString(tableName, i, "KOD") ) ;
				id.setAciklama(iMap.getString(tableName, i, "ACIKLAMA")) ;
				
				eftiadeKoduTx.setId(id) ; 
				session.saveOrUpdate(eftiadeKoduTx);
			}
			session.flush();
			iMap.put("TRX_NAME", "2375");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);	
		} catch (Exception e) {
			
			throw ExceptionHandler.convertException(e);
		}
		
	}	
	
	@GraymoundService("BNSPR_TRN2375_CREATE_TRX_NO")
	public static GMMap createIadeTRX_NO(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN2375.IadeParamAktar() }");

			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.execute();

			BigDecimal txNo = stmt.getBigDecimal(1);

			oMap.put("TRX_NO", txNo);

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
	
}