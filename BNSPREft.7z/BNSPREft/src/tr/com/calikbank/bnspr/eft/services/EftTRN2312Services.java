package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2312Services {
	@GraymoundService("BNSPR_TRN2312_GET_EFT_ODEME_BILGI")
	public static GMMap getEftBilgi(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			//EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			EftEftTx eftEftTx = (EftEftTx)session.createCriteria(EftEftTx.class).add(Restrictions.eq("txNo",  iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			
			GMMap oMap = new GMMap();
			
			oMap.put("ODEME_SUBE" , eftEftTx.getOdemeSube());
			oMap.put("DISPLAY_ODEME_SUBE" , LovHelper.diLov(eftEftTx.getOdemeSube(), "2312/LOV_BOLUM", "ADI"));
	        oMap.put("ODEME_MUSTERI_NO" , eftEftTx.getOdemeMusteriNo());
	        oMap.put("DISPLAY_MUSTERI_ADI" , LovHelper.diLov(eftEftTx.getOdemeMusteriNo(), "2312/LOV_MUSTERI_NO", "ADI"));
	        oMap.put("ODEME_MUSTERI_HESAP" , eftEftTx.getOdemeMusteriHesap());
	        oMap.put("ODEME_DK_HESAP" , eftEftTx.getOdemeDkHesap());
	        oMap.put("IADE_HESAP_NUMARASI" , eftEftTx.getIadeHesapNumarasi());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("IADE_EDEN" , eftEftTx.getIadeEden());
	        oMap.put("IADE_VERGI_KIMLIK_NUMARA" , eftEftTx.getIadeVergiKimlikNumara());
	        oMap.put("ALICI_HESAP_NO" , eftEftTx.getAliciHesapNo());
	        oMap.put("ALICI_ADI" , eftEftTx.getAliciAdi());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("TUTAR" , eftEftTx.getTutar());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ILGILI_ISLEM_TARIH" , eftEftTx.getIlgiliIslemTarih());
	        oMap.put("ILGILI_ISLEM_NUMARA" , eftEftTx.getIlgiliIslemNumara());
	        oMap.put("IADE_KODU" , eftEftTx.getIadeKodu());
	        oMap.put("IADE_ACIKLAMA" , LovHelper.diLov(eftEftTx.getIadeKodu(), "2311/LOV_IADE_KODU", "ACIKLAMA"));
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("TRX_NO" , eftEftTx.getTxNo());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("ACIKLAMA_2" , eftEftTx.getAciklama2());
	        oMap.put("DURUM" , eftEftTx.getDurum());
	        oMap.put("ISLEM_TIPI",eftEftTx.getIslemTipi());
	        oMap.put("KIMLIK_TIPI",eftEftTx.getKasaKimlikTipi());
	        oMap.putAll(getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
	        oMap.put("ISLEM_SAAT" ,eftEftTx.getIslemSaat());
	        oMap.put("GIRIS_SAAT" ,eftEftTx.getGirisSaat());
	        oMap.put("ODEME_TX_NO" ,eftEftTx.getOdemeTxNo());
	        
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN2312_GET_EFT_ODEME_BILGI_MK")
	public static GMMap getEftBilgiMk(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.createCriteria(EftEftTx.class).add(Restrictions.eq("odemeTxNo",  iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			
			GMMap oMap = new GMMap();
			
			oMap.put("ODEME_SUBE" , eftEftTx.getOdemeSube());
			oMap.put("DISPLAY_ODEME_SUBE" , LovHelper.diLov(eftEftTx.getOdemeSube(), "2312/LOV_BOLUM", "ADI"));
	        oMap.put("ODEME_MUSTERI_NO" , eftEftTx.getOdemeMusteriNo());
	        oMap.put("DISPLAY_MUSTERI_ADI" , LovHelper.diLov(eftEftTx.getOdemeMusteriNo(), "2312/LOV_MUSTERI_NO", "ADI"));
	        oMap.put("ODEME_MUSTERI_HESAP" , eftEftTx.getOdemeMusteriHesap());
	        oMap.put("ODEME_DK_HESAP" , eftEftTx.getOdemeDkHesap());
	        oMap.put("IADE_HESAP_NUMARASI" , eftEftTx.getIadeHesapNumarasi());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("IADE_EDEN" , eftEftTx.getIadeEden());
	        oMap.put("IADE_VERGI_KIMLIK_NUMARA" , eftEftTx.getIadeVergiKimlikNumara());
	        oMap.put("ALICI_HESAP_NO" , eftEftTx.getAliciHesapNo());
	        oMap.put("ALICI_ADI" , eftEftTx.getAliciAdi());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("TUTAR" , eftEftTx.getTutar());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ILGILI_ISLEM_TARIH" , eftEftTx.getIlgiliIslemTarih());
	        oMap.put("ILGILI_ISLEM_NUMARA" , eftEftTx.getIlgiliIslemNumara());
	        oMap.put("IADE_KODU" , eftEftTx.getIadeKodu());
	        oMap.put("IADE_ACIKLAMA" , LovHelper.diLov(eftEftTx.getIadeKodu(), "2311/LOV_IADE_KODU", "ACIKLAMA"));
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("TRX_NO" , eftEftTx.getTxNo());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("ACIKLAMA_2" , eftEftTx.getAciklama2());
	        oMap.put("DURUM" , eftEftTx.getDurum());
	        oMap.put("ISLEM_TIPI",eftEftTx.getIslemTipi());
	        oMap.put("KIMLIK_TIPI",eftEftTx.getKasaKimlikTipi());
	        oMap.putAll(getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
	        oMap.put("ISLEM_SAAT" ,eftEftTx.getIslemSaat());
	        oMap.put("GIRIS_SAAT" ,eftEftTx.getGirisSaat());
	        oMap.put("ODEME_TX_NO" ,eftEftTx.getOdemeTxNo());
	        
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
	
	
	
	private static GMMap getEftDiValues(String gBanka,String gSube,String gSehir,String aBanka,String aSube,String aSehir) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_trn2317.post_query(?,?,?,?,?,?,?,?,?,?,?,?)}");

			stmt.registerOutParameter(7, Types.VARCHAR);
			stmt.registerOutParameter(8, Types.VARCHAR);
			stmt.registerOutParameter(9, Types.VARCHAR);
			stmt.registerOutParameter(10, Types.VARCHAR);
			stmt.registerOutParameter(11, Types.VARCHAR);
			stmt.registerOutParameter(12, Types.VARCHAR);

			stmt.setString(1, gBanka);
			stmt.setString(2, gSube);
			stmt.setString(3, gSehir);
			stmt.setString(4, aBanka);
			stmt.setString(5, aSube);
			stmt.setString(6, aSehir);

			stmt.execute();

			oMap.put("DISPLAY_GONDEREN_BANKA", stmt.getString(7));
			oMap.put("DISPLAY_GONDEREN_SUBE", stmt.getString(8));
			oMap.put("DISPLAY_GONDEREN_SEHIR", stmt.getString(9));
			oMap.put("DISPLAY_ALAN_BANKA_KODU", stmt.getString(10));
			oMap.put("DISPLAY_ALAN_SUBE_KODU", stmt.getString(11));
			oMap.put("DISPLAY_ALAN_SEHIR_KODU", stmt.getString(12));

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN2312_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {

		BigDecimal uptTx;
		String uptReferans = null;
		
		try {
			
			uptTx = (BigDecimal) DALUtil.callOracleFunction("{? = call pkg_tu.iade_eft_txno(?)}", BnsprType.NUMBER, BnsprType.NUMBER, iMap.getBigDecimal("ISLEM_NO"));
			
			if(uptTx != null) {
				
				uptReferans = (String) DALUtil.callOracleFunction("{? = call PKG_tu.f_islem_tu_referans_bul(?)}", BnsprType.STRING, BnsprType.NUMBER, uptTx);
				
				Session session = DAOSession.getSession("BNSPRDal");
				EftEftTx eftEftTx = (EftEftTx)session.createCriteria(EftEftTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
				
				GMServiceExecuter.call("BNSPR_TU_REFUND_TRANSFER_REQUEST", new GMMap()
					.put("TRX_NO", eftEftTx != null ? eftEftTx.getOdemeTxNo() : null)
					.put("TU_REFERANS", uptReferans));
			}
			
			return new GMMap();
		}
		catch(Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2312_AFTER_CANCELATION")
	public static GMMap afterCancellation(GMMap iMap) {
		Connection conn = null;

		ResultSet rSet = null;
		BigDecimal txNo = null;
		BigDecimal tu_tx = null;
		CallableStatement stmt2 = null;
		String tu_referans = null;
		String response ; 
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			EftEftTx objEftEftTx = (EftEftTx)session.createCriteria(EftEftTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO"))).uniqueResult();
				
			if(objEftEftTx == null) {
				objEftEftTx = new EftEftTx();
			}
				conn = DALUtil.getGMConnection();
				
				txNo = objEftEftTx.getTxNo();  
				
				stmt2 = conn.prepareCall("{? = call PKG_tu.Iade_EFT_Txno(?)}");
				stmt2.registerOutParameter(1, Types.DECIMAL);
				stmt2.setBigDecimal(2, txNo);
				stmt2.execute();
				tu_tx = stmt2.getBigDecimal(1);
				
				GMServerDatasource.close(stmt2);				
				
					if (tu_tx != null) {
						conn = DALUtil.getGMConnection();
						stmt2 = conn.prepareCall("{? = call PKG_tu.f_islem_tu_referans_bul(?)}");
						stmt2.registerOutParameter(1, Types.VARCHAR);
						stmt2.setBigDecimal(2, tu_tx);
						stmt2.execute();
						tu_referans = stmt2.getString(1);
						
						GMServerDatasource.close(stmt2);
							GMMap sMap = new GMMap();
							 sMap.put("TU_REFERANS", tu_referans);
						    sMap.put("TRX_NO", tu_tx);
							sMap = GMServiceExecuter.call(
									"BNSPR_TU_CANCEL_REFUND_TRANSFER_REQUEST", sMap);
							response = sMap.getString("RESPONSE"); 
							if ( "2".equals(response) )
							{
								GMMap sMap2 = new GMMap();
								sMap2.put("TU_REFERANS", tu_referans);
							    sMap2.put("TRX_NO", tu_tx);
								sMap2 = GMServiceExecuter.call(
										"BNSPR_TU_CANCEL_REFUND_TRANSFER_CONFIRM", sMap2);
							}	
					}
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt2);
		}

	}			
	
}
