package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class EftQRY2342Services {
	
	@GraymoundService("BNSPR_QRY2342_GET_EFT_LIST")
	public static GMMap getEftList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int i = 1;	 
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_PFT.GET_EFT_LIST(?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.setString(i++, iMap.getString("EFT_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("REF_NO"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("EFT_ISLEM_NO"));
			if(iMap.getString("AD_SOYAD").isEmpty())
				stmt.setString(i++, null);
			else
				stmt.setString(i++, iMap.getString("AD_SOYAD"));
			
			stmt.setString(i++, iMap.getString("DURUM"));
			if ((iMap.get("TARIH_BAS") != null)) stmt.setDate(i++, new Date(iMap.getDate("TARIH_BAS").getTime()));
			else stmt.setDate(i++, null);
			if ((iMap.get("TARIH_SON") != null)) stmt.setDate(i++, new Date(iMap.getDate("TARIH_SON").getTime()));
			else stmt.setDate(i++, null);
			stmt.setString(i++, iMap.getString("GONDEREN_TCKN"));
			stmt.setString(i++, iMap.getString("GONDEREN_PTT_SUBESI"));
			stmt.setString(i++, iMap.getString("ALICI_BANKA"));
			stmt.setString(i++, iMap.getString("GONDEREN_PTT_KULL_SICIL_KOD"));
			stmt.setString(i++, "E");
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR_BAS"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR_SON"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = DALUtil.rSetResults(rSet, "EFT_LIST");
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2342_GET_EFT_BELGE_LIST")
	public static GMMap getEftBelgeList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_PFT.GET_EFT_BELGE_LIST(?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			
			stmt.setBigDecimal(i++, iMap.getBigDecimal("REF_NO"));
			stmt.execute();
			
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			int row =0;
			String tableName = "EVRAK_LIST_TABLE";
			while(rSet.next()){
				oMap.put(tableName, row, "DOKUMAN_KOD", rSet.getString("DOKUMAN_KOD"));
				oMap.put(tableName, row, "DOKUMAN_ADI", rSet.getString("DOKUMAN_ADI"));
				oMap.put(tableName, row, "DURUM", rSet.getString("DURUM"));
				if("E".equals(rSet.getString("ALINDI")))
					oMap.put(tableName, row, "ALINDI", "true");
				else
					oMap.put(tableName, row, "ALINDI", "false");
				oMap.put(tableName, row, "SORGU_NO", iMap.getBigDecimal("REF_NO"));
				row++;
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

}
