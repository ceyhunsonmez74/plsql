package tr.com.calikbank.bnspr.eft.services;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.FileUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServer;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2321Services {
	@GraymoundService("BNSPR_TRN2321_GET_INITIAL_VALUES")
	public static GMMap getInitialValues(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN2321.form_instance(?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.DATE);
			stmt.registerOutParameter(5, Types.DECIMAL);
			stmt.execute();

			oMap.put("SUBE_KODU", stmt.getString(1));
			oMap.put("BANKA_KODU", stmt.getString(2));
			oMap.put("BANKA_ADI", stmt.getString(3));
			oMap.put("EFT_TARIH", stmt.getDate(4));
			oMap.put("TRX_NO", stmt.getBigDecimal(5));

			oMap.put("GONDEREN_SUBE_KODU", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2321/LOV_BOLUM", "EFT_KODU"));
			oMap.put("DI_GONDEREN_SUBE_KODU", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2321/LOV_BOLUM", "ADI"));
			oMap.put("GONDEREN_SEHIR", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2321/LOV_BOLUM", "IL_KODU"));
			oMap.put("DI_GONDEREN_SEHIR", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2321/LOV_BOLUM", "IL_ADI"));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2321_GET_EFT_INFO")
	public static GMMap getEftInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
	        
			oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("ACIKLAMA_2" , eftEftTx.getAciklama2());
	        oMap.put("TRX_NO" , eftEftTx.getTxNo());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("DURUM" , eftEftTx.getDurum());
	        oMap.put("TUTAR" , eftEftTx.getTutar());
	        oMap.put("ISLEM_TURU" , eftEftTx.getIslemTuru());
	        oMap.put("REFERANS_NO" , eftEftTx.getReferansNo());
	        oMap.put("FAIZ_ORANI" , eftEftTx.getFaizOrani());
	        oMap.put("FAIZ_TUTARI" , eftEftTx.getFaizTutari());
	        oMap.put("ANAPARA" , eftEftTx.getAnapara());
	        oMap.put("BASLANGIC_VALOR" , eftEftTx.getBaslangicValor());
	        oMap.put("BITIS_VALOR" , eftEftTx.getBitisValor());
	        oMap.put("ALICI_HESAP_NO" , eftEftTx.getAliciHesapNo());
	        oMap.put("KOMISYON" , eftEftTx.getKomisyon());
	        oMap.put("MASRAF" , eftEftTx.getMasraf());
	        oMap.put("VERGI" , eftEftTx.getVergi());
	        oMap.put("SSDF_BSMV" , eftEftTx.getSsdfBsmv());
	        
	        oMap.put("DOVIZ_KODU" , eftEftTx.getDovizKodu());
	        oMap.put("DOVIZ_KURU" , eftEftTx.getDovizKuru());
	        oMap.put("DOVIZ_TUTARI" , eftEftTx.getDovizTutari());
	        
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TCMB_HAVALE_EFT_DATA_WITH_EXCEL")
	public static GMMap sendTcmbHavaleEftDataWithExcel(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmte = null;
		ResultSet rSet = null;
		ResultSet rSete = null;
		XSSFWorkbook wb = null;
		XSSFWorkbook wbe = null;
		List<?> list;
		String tempDosyaAdi = null;
		String tempDosyaAdiEft = null;

		try {
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");

			iMap.put("PARAMETRE", "TCMB_PATH_FILE");
			String filePath = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();
			iMap.put("PARAMETRE", "TCMB_FILE_NAME");
			String fileName = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();
			iMap.put("PARAMETRE", "TCMB_FILE_WRITE_OPTIONS_PARAM");
			String options = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();

			if (options.equals("0")) {
				tempDosyaAdi = ROOT + File.separator + "files" + File.separator + "YuksekFrekansHavale" + ".xlsx";
			}
			else {
				tempDosyaAdi = filePath + File.separator + fileName + File.separator + "YuksekFrekansHavale" + ".xlsx";
			}
			
				stmt = conn.prepareCall("{? = call PKG_RC_TCMB.RC_HAVALE_DATA()}");
				int i = 1;
				stmt.registerOutParameter(i++, -10); // ref cursor
				stmt.execute();
				rSet = (ResultSet) stmt.getObject(1);
           try {
				wb = new XSSFWorkbook();
				XSSFSheet sheet1 = wb.createSheet("YuksekFrekansHavale");
				FileOutputStream fileOut = new FileOutputStream(tempDosyaAdi);
				//Baslik satiri.
				int columnCount = 0;
				 {
					Row row = sheet1.createRow(0);
					Cell cell = row.createCell(columnCount);
					cell.setCellValue("SiraNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("KayitID");
					cell = row.createCell(++columnCount);
					cell.setCellValue("kayitTuru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("tarih");
					cell = row.createCell(++columnCount);
					cell.setCellValue("IslemZamani");
					cell = row.createCell(++columnCount);
					cell.setCellValue("katilimciKod");
					cell = row.createCell(++columnCount);
					cell.setCellValue("referansNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderenAd");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderenKimlikTuru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderenKimlikNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderenHesapNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderenHesapYerlesik");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderenHesapTipi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alanAd");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alanKimlikTuru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alanKimlikNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alanHesapNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alanHesapYerlesik");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alanHesapTipi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("odemeAmaciKategorisi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("tutar");
					cell = row.createCell(++columnCount);
					cell.setCellValue("aciklama");
					columnCount = 0;
				}				

					for (int rowNum = 1; rSet.next(); rowNum++) {
						Row row = sheet1.createRow(rowNum);
						 columnCount = 0;

							Cell cell = row.createCell(columnCount);

							cell.setCellValue((rowNum));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("kayitid"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("kayitTuru"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("tarih"));
							cell = row.createCell(++columnCount);

							Date islemZamani = new Date(rSet.getBigDecimal("islemzamani").longValue());
							SimpleDateFormat df2 = new SimpleDateFormat("dd.MM.yyyy HH:mm");
							String dateText = df2.format(islemZamani);
							cell.setCellValue((dateText));
							cell = row.createCell(++columnCount);
							
							//cell.setCellValue(rSet.getString("islemzamani"));
							// cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("katilimcikod"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("referansno"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("gonderenad"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("gonderenKimlikTuru"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("gonderenKimlikNo"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("gonderenhesapno"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("gonderenhesapyerlesik"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("gonderenHesapTipi"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("alanad"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("alanKimlikTuru"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("alanKimlikNo"));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSet.getString("alanhesapno"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("alanhesapyerlesik"));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSet.getString("alanHesapTipi"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("odemeAmaciKategorisi"));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(new DecimalFormat("##.##").format(rSet.getBigDecimal("tutar")));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSet.getString("aciklama"));
							cell = row.createCell(++columnCount);
				}
					wb.write(fileOut);
					fileOut.close();
                 
				if (columnCount > 0) 	 
					sendMail("YuksekFrekansHavale", tempDosyaAdi);

           }	
				catch (Exception e) {
					System.out.println("An error occurred.");
					e.printStackTrace();
				}


			if (options.equals("0")) {
				tempDosyaAdiEft = ROOT + File.separator + "files" + File.separator + "YuksekFrekansEft" + ".xlsx";
			}
			else {
				tempDosyaAdiEft = filePath + File.separator + fileName + File.separator + "YuksekFrekansEft" + ".xlsx";
			}
			
				stmte = conn.prepareCall("{? = call PKG_RC_TCMB.RC_EFT_DATA()}");
				int j = 1;
				stmte.registerOutParameter(j++, -10); // ref cursor
				stmte.execute();
				rSete = (ResultSet) stmte.getObject(1);
           try {
				wbe = new XSSFWorkbook();
				XSSFSheet sheet1 = wbe.createSheet("YuksekFrekansEft");
				FileOutputStream fileOute = new FileOutputStream(tempDosyaAdiEft);

				    
				int columnCount = 0;
				{
					Row row = sheet1.createRow(0);
					Cell cell = row.createCell(columnCount);
					cell.setCellValue("SiraNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("KayitID");
					cell = row.createCell(++columnCount);
					cell.setCellValue("kayitTuru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("mesajYonu");
					cell = row.createCell(++columnCount);
					cell.setCellValue("tarih");
					cell = row.createCell(++columnCount);
					cell.setCellValue("IslemZamani");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderenKatilimciKod");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alanKatilimciKod");
					cell = row.createCell(++columnCount);
					cell.setCellValue("sorguNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemTuru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderenAd");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderenHesapNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderenKimlikTuru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderenKimlikNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderenHesapYerlesik");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderenHesapTipi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alanAd");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alanKimlikTuru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alanKimlikNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alanHesapNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alanHesapYerlesik");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alanHesapTipi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("odemeAmaciKod");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemTaraf");
					cell = row.createCell(++columnCount);
					cell.setCellValue("tutar");
					cell = row.createCell(++columnCount);
					cell.setCellValue("aciklama");
					columnCount = 0;
				}
				
					for (int rowNume = 1; rSete.next(); rowNume++) {
						Row row = sheet1.createRow(rowNume);
					 columnCount = 0;

   						Cell cell = row.createCell(columnCount);

							cell.setCellValue((rowNume));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("kayitid"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("kayitTuru"));
							cell = row.createCell(++columnCount);
							cell.setCellValue(rSete.getString("mesajYonu"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("tarih"));
							cell = row.createCell(++columnCount);

						//	cell.setCellValue(rSete.getString("islemzamani"));
						//	cell = row.createCell(++columnCount);

							Date islemZamani = new Date(rSete.getBigDecimal("islemzamani").longValue());
							SimpleDateFormat df2 = new SimpleDateFormat("dd.MM.yyyy HH:mm");
							String dateText = df2.format(islemZamani);
							cell.setCellValue((dateText));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSete.getString("gonderenKatilimciKod"));
							cell = row.createCell(++columnCount);
							cell.setCellValue(rSete.getString("alanKatilimciKod"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("sorguNo"));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSete.getString("islemturu"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("gonderenad"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("gonderenhesapno"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("gonderenKimlikTuru"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("gonderenKimlikNo"));
							cell = row.createCell(++columnCount);							
							
							cell.setCellValue(rSete.getString("gonderenhesapyerlesik"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("gonderenHesapTipi"));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSete.getString("alanad"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("alanKimlikTuru"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("alanKimlikNo"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("alanhesapno"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("alanhesapyerlesik"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("alanHesapTipi"));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSete.getString("odemeAmaciKod"));
							cell = row.createCell(++columnCount);
							cell.setCellValue(rSete.getString("islemTaraf"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(new DecimalFormat("##.##").format(rSete.getBigDecimal("tutar")));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSete.getString("aciklama"));
							cell = row.createCell(++columnCount);

				}
					wbe.write(fileOute);
					fileOute.close();

					if (columnCount > 0) 	 
  					sendMail("YuksekFrekansEft", tempDosyaAdiEft);

           }	
				catch (Exception e) {
					System.out.println("An error occurred.");
					e.printStackTrace();
				}
           
           
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSete);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmte);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TCMB_SWIFT_DATA_WITH_EXCEL")
	public static GMMap sendTcmbSwiftDataWithExcel(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmte = null;
		ResultSet rSet = null;
		ResultSet rSete = null;
		XSSFWorkbook wb = null;
		XSSFWorkbook wbe = null;
		List<?> list;
		String tempDosyaAdi = null;
		String tempDosyaAdi202 = null;

		try {
			conn = DALUtil.getGMConnection();
			Session session = DAOSession.getSession("BNSPRDal");

			iMap.put("PARAMETRE", "TCMB_PATH_FILE");
			String filePath = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();
			iMap.put("PARAMETRE", "TCMB_FILE_NAME");
			String fileName = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();
			iMap.put("PARAMETRE", "TCMB_FILE_WRITE_OPTIONS_PARAM");
			String options = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", iMap).get("DEGER").toString();

			if (options.equals("0")) {
				tempDosyaAdi = ROOT + File.separator + "files" + File.separator + "YuksekFrekansSwift103" + ".xlsx";
			}
			else {
				tempDosyaAdi = filePath + File.separator + fileName + File.separator + "YuksekFrekansSwift103" + ".xlsx";
			}
			
				stmt = conn.prepareCall("{? = call PKG_RC_TCMB.RC_SWIFT103_DATA()}");
				int i = 1;
				stmt.registerOutParameter(i++, -10); // ref cursor
				stmt.execute();
				rSet = (ResultSet) stmt.getObject(1);
           try {
				wb = new XSSFWorkbook();
				XSSFSheet sheet1 = wb.createSheet("YuksekFrekansSwift103");
				FileOutputStream fileOut = new FileOutputStream(tempDosyaAdi);
				//Baslik satiri.
				int columnCount = 0;
				 {
					Row row = sheet1.createRow(0);
					Cell cell = row.createCell(columnCount);
					cell.setCellValue("SiraNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("KayitID");
					cell = row.createCell(++columnCount);
					cell.setCellValue("kayitTuru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderici");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alici");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gondericiReferansi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("swiftTekilNumarasi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemTuru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemTalimati");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemMahiyeti");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemValoru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemParaBirimi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemTutari");
					cell = row.createCell(++columnCount);
					cell.setCellValue("amirHesapNumarasi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("amirBankaBIC");
					cell = row.createCell(++columnCount);
					cell.setCellValue("amirAdSoyad");
					cell = row.createCell(++columnCount);
					cell.setCellValue("amirAdAdres");
					cell = row.createCell(++columnCount);
					cell.setCellValue("amirKimlikNumarasi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("amirKurumBIC");
					cell = row.createCell(++columnCount);
					cell.setCellValue("amirKurumPI");
					cell = row.createCell(++columnCount);
					cell.setCellValue("amirKurumAdAdres");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gondericiMuhabirBIC");
					cell = row.createCell(++columnCount);
					cell.setCellValue("aliciMuhabirBIC");
					cell = row.createCell(++columnCount);
					cell.setCellValue("araciKurumBIC");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarHesapKurumBIC");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarHesapKurumPI");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarHesapKurumKonum");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarHesapKurumAdAdresBilgisi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarHesapNumarasi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarAdSoyad");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarBIC");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarAdAdres");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarGonderilenBilgi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("odemeAmaciKategorisi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("aciklama");
					
					columnCount = 0;
				}				

					for (int rowNum = 1; rSet.next(); rowNum++) {
						Row row = sheet1.createRow(rowNum);
						 columnCount = 0;

							Cell cell = row.createCell(columnCount);

							cell.setCellValue((rowNum));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("kayitid"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("kayitTuru"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("gonderici"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("alici"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("gondericiReferansi"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("swiftTekilNumarasi"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("islemTuru"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("islemTalimati"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("islemMahiyeti"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("islemValoru"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("islemParaBirimi"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(new DecimalFormat("##.##").format(rSet.getBigDecimal("islemTutari")));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("amirHesapNumarasi"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("amirBankaBIC"));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSet.getString("amirAdSoyad"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("amirAdAdres"));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSet.getString("amirKimlikNumarasi"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("amirKurumBIC"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("amirKurumPI"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("amirKurumAdAdres"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("gondericiMuhabirBIC"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("aliciMuhabirBIC"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("araciKurumBIC"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("lehdarHesapKurumBIC"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("lehdarHesapKurumPI"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("lehdarHesapKurumKonum"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("lehdarHesapKurumAdAdresBilgisi"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("lehdarHesapNumarasi"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("lehdarAdSoyad"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("lehdarBIC"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("lehdarAdAdres"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSet.getString("lehdarGonderilenBilgi"));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSet.getString("odemeAmaciKategorisi"));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSet.getString("aciklama"));
							cell = row.createCell(++columnCount);
							
				}
					wb.write(fileOut);
					fileOut.close();
                 
				if (columnCount > 0) 	 
					sendMail("YuksekFrekansSwift103", tempDosyaAdi);

           }	
				catch (Exception e) {
					System.out.println("An error occurred.");
					e.printStackTrace();
				}


			if (options.equals("0")) {
				tempDosyaAdi202 = ROOT + File.separator + "files" + File.separator + "YuksekFrekansSwift202" + ".xlsx";
			}
			else {
				tempDosyaAdi202 = filePath + File.separator + fileName + File.separator + "YuksekFrekansSwift202" + ".xlsx";
			}
			
				stmte = conn.prepareCall("{? = call PKG_RC_TCMB.RC_SWIFT202_DATA()}");
				int j = 1;
				stmte.registerOutParameter(j++, -10); // ref cursor
				stmte.execute();
				rSete = (ResultSet) stmte.getObject(1);
           try {
				wbe = new XSSFWorkbook();
				XSSFSheet sheet1 = wbe.createSheet("YuksekFrekansSwift202");
				FileOutputStream fileOute = new FileOutputStream(tempDosyaAdi202);


				int columnCount = 0;
				{
					Row row = sheet1.createRow(0);
					Cell cell = row.createCell(columnCount);
					cell.setCellValue("SiraNo");
					cell = row.createCell(++columnCount);
					cell.setCellValue("KayitID");
					cell = row.createCell(++columnCount);
					cell.setCellValue("kayitTuru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gonderici");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alici");
					cell = row.createCell(++columnCount);
					cell.setCellValue("gondericiIslemReferansi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("ilgiliIslemReferansi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("swiftTekilNumarasi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemValoru");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemParaBirimi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("islemTutari");
					cell = row.createCell(++columnCount);
					cell.setCellValue("amirKurumBIC");
					cell = row.createCell(++columnCount);
					cell.setCellValue("amirKurumPI");
					cell = row.createCell(++columnCount);
					cell.setCellValue("amirKurumAdAdres");
					cell = row.createCell(++columnCount);
					cell.setCellValue("g�ndericininMuhabiriBIC");
					cell = row.createCell(++columnCount);
					cell.setCellValue("alicininMuhabiriBIC");
					cell = row.createCell(++columnCount);
					cell.setCellValue("araciKurumBIC");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarHesapKurumBIC");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarHesapKurumPI");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarHesapKurumKonum");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarHesapKurumAdAdres");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarKurumBIC");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarKurumPI");
					cell = row.createCell(++columnCount);
					cell.setCellValue("lehdarKurumAdAdres");
					cell = row.createCell(++columnCount);
					cell.setCellValue("odemeAmaciKategorisi");
					cell = row.createCell(++columnCount);
					cell.setCellValue("aciklama");
					columnCount = 0;
				}
				
					for (int rowNume = 1; rSete.next(); rowNume++) {
						Row row = sheet1.createRow(rowNume);
					 columnCount = 0;

   						Cell cell = row.createCell(columnCount);

							cell.setCellValue((rowNume));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("kayitid"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("kayitTuru"));
							cell = row.createCell(++columnCount);
							cell.setCellValue(rSete.getString("gonderici"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("alici"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("gondericiIslemReferansi"));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSete.getString("ilgiliIslemReferansi"));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSete.getString("swiftTekilNumarasi"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("islemValoru"));
							cell = row.createCell(++columnCount);
							
							cell.setCellValue(rSete.getString("islemParaBirimi"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(new DecimalFormat("##.##").format(rSete.getBigDecimal("islemTutari")));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("amirKurumBIC"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("amirKurumPI"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("amirKurumAdAdres"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("g�ndericininMuhabiriBIC"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("alicininMuhabiriBIC"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("araciKurumBIC"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("lehdarHesapKurumBIC"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("lehdarHesapKurumPI"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("lehdarHesapKurumKonum"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("lehdarHesapKurumAdAdres"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("lehdarKurumBIC"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("lehdarKurumPI"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("lehdarKurumAdAdres"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("odemeAmaciKategorisi"));
							cell = row.createCell(++columnCount);

							cell.setCellValue(rSete.getString("aciklama"));
							cell = row.createCell(++columnCount);
							
				}
					wbe.write(fileOute);
					fileOute.close();

					if (columnCount > 0) 	 
  					sendMail("YuksekFrekansSwift202", tempDosyaAdi202);

           }	
				catch (Exception e) {
					System.out.println("An error occurred.");
					e.printStackTrace();
				}
           
           
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(rSete);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmte);
			GMServerDatasource.close(conn);
		}
	}

	
	private static void sendMail(String fileName, String tempDosyaAdi) throws IOException {
		GMMap mailMap = new GMMap();
		GMMap paramMap = new GMMap();

		mailMap.put("MAIL_FROM", "aktifbank@aktifbank.com.tr");
		paramMap.put("PARAMETRE", "TCMB_EFTHAVALE_MAIL_TO");
		String mailTo = GMServiceExecuter.execute("BNSPR_GET_PARAMETRE_DEGER_AL_K", paramMap).get("DEGER").toString();
		mailMap.put("MAIL_TO", mailTo);
		mailMap.put("MAIL_SUBJECT", "TCMB YUKSEK FREKANS EFT HAVALE SWIFT EXCEL GONDERIM Bilgilendirme");
		mailMap.put("MAIL_BODY", "TCMB i�in haz�rlanan dosya ektedir.");
		mailMap.put("IS_BODY_HTML", "H");
		mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_NAME", fileName + ".xlsx");
		mailMap.put("MAIL_ATTACHMENT_LIST", 0, "FILE_CONTENT", FileUtil.readFileToByteArray(tempDosyaAdi));
		GMServiceExecuter.execute("BNSPR_SYSTEM_SEND_ASYNCHRONOUS_MAIL", mailMap);
	}	

	private static String ROOT = GMServer.getProperty("graymound.home", null) + File.separator + "Server" + File.separator + "Content" + File.separator + "Root";	
}
