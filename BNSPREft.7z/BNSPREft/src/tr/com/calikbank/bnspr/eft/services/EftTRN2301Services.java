package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlDuzenliOdemeTx;
import tr.com.calikbank.bnspr.dao.GnlDuzenliTaksitTx;
import tr.com.calikbank.bnspr.dao.GnlDuzenliTaksitTxId;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2301Services {

	@GraymoundService("BNSPR_TRN2301_GET_ODEME_PLAN")
	public static Map<?, ?>  get(GMMap iMap) {
		try{
			BigDecimal tutar = iMap.getBigDecimal("TUTAR");
			String donemTipi = iMap.getString("DONEM_TIPI"); //GUN, HAFTA, AY, YIL
			String ilkSon = iMap.getString("ILK_SON_ISGUNU"); //0=Bo� 1=�lk ��g�n� 2=Son ��g�n�
			Date ilkOdemeTarihi = iMap.getDate("ILK_ODEME_TARIHI"); 
			String bitisDonemi = iMap.getString("BITIS_DONEMI"); //TARIH, SAYI
			Date bitisTarihi = iMap.getDate("BITIS_TARIHI");
			String onceSonraFlag = iMap.getString("ONCE_SONRA_FLAG"); //S=Sonra, O=Once
			GregorianCalendar bitisTarihiCalendar = null;
			BigDecimal bdDonemSuresi = getTableCellBigDecimal(iMap,"DONEM_SURESI");
			int donemSuresi = bdDonemSuresi.intValue();
			
			if(ilkOdemeTarihi == null)
				EftServices.throwGMBusssinessException("�lk �deme Tarihi Bo� Olamaz!");
				//throw new GMRuntimeException(0, "�lk �deme Tarihi Bo� Olamaz!");
			
			if(bitisTarihi == null && bitisDonemi.equals("TARIH"))
				EftServices.throwGMBusssinessException("Biti� Tarihi Bo� Olamaz!");
				//throw new GMRuntimeException(0, "Biti� Tarihi Bo� Olamaz!");
					
			if(donemSuresi == 0 && bitisDonemi.equals("SAYI"))
				EftServices.throwGMBusssinessException("�deme Say�s� 0 Olamaz!");
				//throw new GMRuntimeException(0, "�deme Say�s� 0 Olamaz!");
			
			if(tutar == null || tutar.compareTo(BigDecimal.ZERO) == 0)
				EftServices.throwGMBusssinessException("L�tfen tutar giriniz!");
				//throw new GMRuntimeException(0, "L�tfen tutar giriniz!");
			
			
			
			GregorianCalendar todayCalender = new GregorianCalendar();
			todayCalender.setTime(iMap.getDate("BANKA_TARIH"));
			todayCalender.set(GregorianCalendar.MINUTE, 0);
			todayCalender.set(GregorianCalendar.SECOND, 0);
			todayCalender.set(GregorianCalendar.HOUR, 0);
			
			if(!isWorkDay(ilkOdemeTarihi))
				EftServices.throwGMBusssinessException("�lk �deme Tarihi tatil g�n�d�r l�tfen ge�erli bir tarih giriniz!");
				//throw new GMRuntimeException(0, "�lk �deme Tarihi tatil g�n�d�r l�tfen ge�erli bir tarih giriniz!");
	
			if(bitisTarihi != null){
				bitisTarihiCalendar = new GregorianCalendar();
				bitisTarihiCalendar.setTime(bitisTarihi);
				if(ilkOdemeTarihi.compareTo(todayCalender.getTime()) < 0)
					EftServices.throwGMBusssinessException("�lk �deme Bug�n�n Tarihinden �nce Olamaz!");
					//throw new GMRuntimeException(0, "�lk �deme Bug�n�n Tarihinden �nce Olamaz!");
				if(bitisTarihiCalendar.compareTo(todayCalender) < 0)
					EftServices.throwGMBusssinessException("Biti� Tarihi Bug�n�n Tarihinden �nce Olamaz!");
					//throw new GMRuntimeException(0, "Biti� Tarihi Bug�n�n Tarihinden �nce Olamaz!");
			}
			
			int taksitCounter = 0;
			
			ArrayList<HashMap<String, Object>> odemePlani = new ArrayList<HashMap<String,Object>>();
			
			GregorianCalendar currentTaksitCalender = new GregorianCalendar();
			currentTaksitCalender.setFirstDayOfWeek(GregorianCalendar.MONDAY);
			currentTaksitCalender.setTime(ilkOdemeTarihi);
			Date lineDate = ilkOdemeTarihi;
			//int i = 1;
			while(true){
				boolean bitti = false;
				if(bitisDonemi.equals("TARIH")){
					if(currentTaksitCalender.after(bitisTarihiCalendar))
						bitti = true;
			
				}
				else if(bitisDonemi.equals("SAYI")){
					if(donemSuresi <= taksitCounter)
						bitti = true;
				}
				
				if(bitti)
					break;
							
				HashMap<String, Object> currentTaksit = new HashMap<String, Object>();
				currentTaksit.put("TAKSIT_TARIHI", currentTaksitCalender.getTime());
				currentTaksit.put("TAKSIT_TUTAR", tutar);
				//put date to odeme plan�
				odemePlani.add(currentTaksit);
				taksitCounter++;
				
				if(!donemTipi.equals("GUN")){
					currentTaksitCalender.setTime(lineDate);
				}
				
				//calculate next taksitDate
				if(donemTipi.equals("GUN"))
					currentTaksitCalender.add(GregorianCalendar.DAY_OF_MONTH, 1);
				else if(donemTipi.equals("HAFTA"))
					currentTaksitCalender.add(GregorianCalendar.WEEK_OF_YEAR, 1);
				else if(donemTipi.equals("AY"))
					currentTaksitCalender.add(GregorianCalendar.MONTH, 1);
				else  if(donemTipi.equals("YIL"))
					currentTaksitCalender.add(GregorianCalendar.YEAR, 1);
	
				if(!donemTipi.equals("GUN")){
					lineDate = currentTaksitCalender.getTime();
					if(ilkSon != null && ilkSon.trim().equals("1")){ //�lk i� g�n�
						if(donemTipi.equals("HAFTA"))
							currentTaksitCalender.set(ConvertToGregorianField(donemTipi), currentTaksitCalender.getActualMinimum(ConvertToGregorianField(donemTipi)) + 1);
						else
							currentTaksitCalender.set(ConvertToGregorianField(donemTipi), currentTaksitCalender.getActualMinimum(ConvertToGregorianField(donemTipi)));
						if(!isWorkDay(currentTaksitCalender.getTime())){
							currentTaksitCalender.setTime(getIleriIsGunu(currentTaksitCalender.getTime()));
						}
					}
					else if(ilkSon != null && ilkSon.trim().equals("2")){ //Son i� g�n�
						currentTaksitCalender.set(ConvertToGregorianField(donemTipi), currentTaksitCalender.getActualMaximum(ConvertToGregorianField(donemTipi)));
						if(!isWorkDay(currentTaksitCalender.getTime())){
							currentTaksitCalender.setTime(getGeriIsGunu(currentTaksitCalender.getTime()));
						}
					} 
					else{
						if(!isWorkDay(currentTaksitCalender.getTime())){
							if(onceSonraFlag.equals("S"))
								currentTaksitCalender.setTime(getIleriIsGunu(currentTaksitCalender.getTime()));
							else
								currentTaksitCalender.setTime(getGeriIsGunu(currentTaksitCalender.getTime()));
						}
					}
				}
				else {
					if(!isWorkDay(currentTaksitCalender.getTime())){
						currentTaksitCalender.setTime(getIleriIsGunu(currentTaksitCalender.getTime()));
					}
				}
			}
	
			GMMap oMap = new GMMap(); 
			oMap.put("ODEME_PLANI", odemePlani);
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	private static BigDecimal getTableCellBigDecimal(HashMap<?, ?> rowData, String key) {
		if (rowData.get(key) == null)
			return null;
		else if (rowData.get(key) instanceof String)
			return new BigDecimal((String) rowData.get(key));
		else if (rowData.get(key) instanceof BigDecimal)
			return (BigDecimal) rowData.get(key);
		return null;
	}
	
	public static int ConvertToGregorianField(String donemTipi){
		if(donemTipi.equals("GUN"))
			return GregorianCalendar.DAY_OF_MONTH;
		else if(donemTipi.equals("HAFTA"))
			return GregorianCalendar.DAY_OF_WEEK;
		else if(donemTipi.equals("AY"))
			return GregorianCalendar.DAY_OF_MONTH;
		else  if(donemTipi.equals("YIL"))
			return GregorianCalendar.YEAR;
		return -1;
	}
	
	public static boolean isWorkDay(Date aDate){
		GMMap oMap = new GMMap();
		oMap.put("TARIH", aDate);
		return GMServiceExecuter.execute("BNSPR_TRN2301_GET_GUN_OZELLIK", oMap).get("RESULT").equals(new BigDecimal(0)) ? true : false;
	}
	
	public static Date getIleriIsGunu(Date aDate){
		GMMap oMap = new GMMap();
		oMap.put("TARIH", aDate);
		return (Date)GMServiceExecuter.execute("BNSPR_TRN2301_GET_ILERI_ISGUNU", oMap).get("SONUC");
	}
	
	public static Date getGeriIsGunu(Date aDate){
		GMMap oMap = new GMMap();
		oMap.put("TARIH", aDate);
		return (Date)GMServiceExecuter.execute("BNSPR_TRN2301_GET_GERI_ISGUNU", oMap).get("SONUC");
	}
	
	@GraymoundService("BNSPR_TRN2301_GET_GUN_OZELLIK")
	public static Map<?, ?>  getGunOzellik(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try{
			conn = DALUtil.getGMConnection();			
			stmt = conn.prepareCall("{? = call pkg_tarih.gun_ozellik(?)}");			
			stmt.registerOutParameter(1, Types.NUMERIC);
			String strDate = iMap.getString("TARIH");
			if(strDate == null){
				EftServices.throwGMBusssinessException("Tarih alan� bo� olamaz");
				//throw new GMRuntimeException(0, "Tarih alan� bo� olamaz");
			}
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			stmt.setDate(2, new java.sql.Date(sdf.parse(strDate).getTime()));
			stmt.execute();
			oMap.put("RESULT", stmt.getObject(1));
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN2301_GET_ILERI_ISGUNU")
	public static Map<?, ?>  getIleriIsGunu(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("SONUC", callOneParameterDateFunction("{? = call pkg_tarih.ileri_is_gunu(?)}", Types.DATE, iMap.getDate("TARIH")));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN2301_GET_GERI_ISGUNU")
	public static Map<?, ?>  getGeriIsGunu(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("SONUC", callOneParameterDateFunction("{? = call pkg_tarih.geri_is_gunu(?)}", Types.DATE, iMap.getDate("TARIH")));
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	public static Object callOneParameterDateFunction(String func, int retType, Date tarih){
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			conn = DALUtil.getGMConnection();			
			stmt = conn.prepareCall(func);			
			stmt.registerOutParameter(1, retType);
			stmt.setDate(2, new java.sql.Date(tarih.getTime()));
			stmt.execute();
			return stmt.getObject(1);
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	/*
	 *
	 */
	@GraymoundService("BNSPR_TRN2301_SAVE_DUZENLI_ODEME")
	public static Map<?, ?>  saveDuzenliOdeme(GMMap iMap) {
		try {
			if(((ArrayList<?>)iMap.get("DUZENLI_TAKSIT_ISLEM")).size() == 0)
				EftServices.throwGMBusssinessException("�deme Plan�n� Olu�turunuz");
				//throw new GMRuntimeException(0, "�deme Plan�n� Olu�turunuz");
			Session session = DAOSession.getSession("BNSPRDal");
			GnlDuzenliOdemeTx gnlDuzenliOdemeTx = (GnlDuzenliOdemeTx)session.get(GnlDuzenliOdemeTx.class, iMap.getBigDecimal("TRX_NO"));
			if(gnlDuzenliOdemeTx == null){
				gnlDuzenliOdemeTx = new GnlDuzenliOdemeTx();
				gnlDuzenliOdemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));	
			}
			gnlDuzenliOdemeTx.setOdemeTipi(iMap.getString("ODEME_TIPI"));
			gnlDuzenliOdemeTx.setIlkOdemeTarihi(iMap.getDate("ILK_ODEME_TARIHI"));
			gnlDuzenliOdemeTx.setBitisDonemi(iMap.getString("BITIS_DONEMI"));
			gnlDuzenliOdemeTx.setBitisTarihi(iMap.getDate("BITIS_TARIHI"));
			gnlDuzenliOdemeTx.setDonemTipi(iMap.getString("DONEM_TIPI"));
			gnlDuzenliOdemeTx.setDonemSuresi(iMap.getBigDecimal("DONEM_SURESI"));
			gnlDuzenliOdemeTx.setOnceSonraFlag(iMap.getString("ONCE_SONRA_FLAG"));
			gnlDuzenliOdemeTx.setTutar(iMap.getBigDecimal("TUTAR"));
			gnlDuzenliOdemeTx.setBilgilendirmeKodu(iMap.getString("BILGILENDIRME_KODU"));
			gnlDuzenliOdemeTx.setDenenecekSayi(iMap.getBigDecimal("DENENECEK_SAYI"));
			gnlDuzenliOdemeTx.setOdemeSekli(iMap.getString("ODEME_SEKLI"));
			gnlDuzenliOdemeTx.setDovizKodu(iMap.getString("DOVIZ_KODU"));
			gnlDuzenliOdemeTx.setGonMusteriNo(iMap.getBigDecimal("GON_MUSTERI_NO"));
			gnlDuzenliOdemeTx.setGonHesapNo(iMap.getBigDecimal("GON_HESAP_NO"));
			gnlDuzenliOdemeTx.setGonEkHesapNo(iMap.getBigDecimal("GON_EK_HESAP_NO"));
			gnlDuzenliOdemeTx.setSwMasrafSecenek(iMap.getString("SW_MASRAF_SECENEK"));
			gnlDuzenliOdemeTx.setMuhMasrafHesapNo(iMap.getBigDecimal("MUH_MASRAF_HESAP_NO"));

			gnlDuzenliOdemeTx.setKolasReferansi(iMap.getString("KOLAS_REFERANSI"));
			gnlDuzenliOdemeTx.setKolayAdresTipi(iMap.getString("KOLAY_ADRES_TIPI"));
			gnlDuzenliOdemeTx.setKolayAdresDegeri(iMap.getString("KOLAY_ADRES_DEGERI"));
			
			gnlDuzenliOdemeTx.setHavAliciIbanNo(iMap.getString("HAV_IBAN_NO"));
			gnlDuzenliOdemeTx.setSubeKodu(iMap.getString("HAV_SUBE_KODU"));
			gnlDuzenliOdemeTx.setHavMusteriNo(iMap.getBigDecimal("HAV_MUSTERI_NO"));
			gnlDuzenliOdemeTx.setHavHesapNo(iMap.getBigDecimal("HAV_HESAP_NO"));
			gnlDuzenliOdemeTx.setHavAliciAdi(iMap.getString("HAV_ALICI_ADI"));
			gnlDuzenliOdemeTx.setHavAciklama(iMap.getString("HAV_ACIKLAMA"));
			gnlDuzenliOdemeTx.setEftMesajTipi(iMap.getString("EFT_MESAJ_TIPI"));
			gnlDuzenliOdemeTx.setEftAliciHesapNo(iMap.getString("EFT_ALICI_HESAP_NO"));
			gnlDuzenliOdemeTx.setEftAliciAdi(iMap.getString("EFT_ALICI_ADI"));
			gnlDuzenliOdemeTx.setAliciTcKimlikNo(iMap.getString("EFT_ALICI_TC_KIMLIK_NO"));
			gnlDuzenliOdemeTx.setEftAlanBankaKodu(iMap.getString("EFT_ALAN_BANKA_KODU"));
			gnlDuzenliOdemeTx.setEftAlanSehirKodu(iMap.getString("EFT_ALAN_SEHIR_KODU"));
			gnlDuzenliOdemeTx.setEftAlanSubeKodu(iMap.getString("EFT_ALAN_SUBE_KODU"));
			gnlDuzenliOdemeTx.setEftKartNo(iMap.getString("EFT_KART_NO"));
			gnlDuzenliOdemeTx.setEftAciklama1(iMap.getString("EFT_ACIKLAMA_1"));
			gnlDuzenliOdemeTx.setEftAciklama2(iMap.getString("EFT_ACIKLAMA_2"));
			gnlDuzenliOdemeTx.setSwUlkeKodu(iMap.getString("SW_ULKE_KODU"));
			gnlDuzenliOdemeTx.setSwBankaKodu(iMap.getString("SW_BANKA_KODU"));
			gnlDuzenliOdemeTx.setSwSehirKodu(iMap.getString("SW_SEHIR_KODU"));
			gnlDuzenliOdemeTx.setSwSubeKodu(iMap.getString("SW_SUBE_KODU"));
			gnlDuzenliOdemeTx.setSwAliciAdi(iMap.getString("SW_ALICI_ADI"));
			gnlDuzenliOdemeTx.setSwAliciHesapNo(iMap.getString("SW_ALICI_HESAP_NO"));
			gnlDuzenliOdemeTx.setSwAliciAdres1(iMap.getString("SW_ALICI_ADRES_1"));
			gnlDuzenliOdemeTx.setSwAliciAdres2(iMap.getString("SW_ALICI_ADRES_2"));
			gnlDuzenliOdemeTx.setSwAliciAdres3(iMap.getString("SW_ALICI_ADRES_3"));
			gnlDuzenliOdemeTx.setSwAliciTelNo(iMap.getBigDecimal("SW_ALICI_TEL_NO"));
			gnlDuzenliOdemeTx.setSwGonTelNo(iMap.getBigDecimal("SW_GON_TEL_NO"));
			gnlDuzenliOdemeTx.setSwAciklama1(iMap.getString("SW_ACIKLAMA_1"));
			gnlDuzenliOdemeTx.setSwAciklama2(iMap.getString("SW_ACIKLAMA_2"));
			gnlDuzenliOdemeTx.setSwAciklama3(iMap.getString("SW_ACIKLAMA_3"));
			gnlDuzenliOdemeTx.setSwAciklama4(iMap.getString("SW_ACIKLAMA_4"));
			gnlDuzenliOdemeTx.setSwBicKodu(iMap.getString("SW_BIC_KODU"));
			gnlDuzenliOdemeTx.setKmhKullanilsinmi(iMap.getString("KMH_KULLANILSINMI"));
			gnlDuzenliOdemeTx.setIlkSonIsgunu(iMap.getString("ILK_SON_ISGUNU"));
			gnlDuzenliOdemeTx.setEftAliciIbanNo(iMap.getString("EFT_ALICI_IBAN_NO"));
			gnlDuzenliOdemeTx.setEftAliciTelNo(iMap.getBigDecimal("EFT_ALICI_TELEFON_NO"));
			gnlDuzenliOdemeTx.setEftAliciBabaAdi(iMap.getString("EFT_ALICI_BABA_ADI"));
			gnlDuzenliOdemeTx.setEftAliciAdresi(iMap.getString("EFT_ALICI_ADRESI"));
			gnlDuzenliOdemeTx.setHavAliciTelNo(iMap.getBigDecimal("HAV_ALICI_TEL_NO"));
			gnlDuzenliOdemeTx.setHavAnaAdi(iMap.getString("HVL_ALICI_ANNE_ADI"));
			gnlDuzenliOdemeTx.setHavBabaAdi(iMap.getString("HVL_ALICI_BABA_ADI"));
			gnlDuzenliOdemeTx.setHavAdres(iMap.getString("HVL_ALICI_ADRES"));
			gnlDuzenliOdemeTx.setHavDogumTarihi(iMap.getDate("HVL_ALICI_DOGUM_TARIHI"));
			gnlDuzenliOdemeTx.setHavTipi(iMap.getString("HVL_TIPI"));
			gnlDuzenliOdemeTx.setEftAliciAnneAdi(iMap.getString("EFT_ALICI_ANNE_ADI"));
			gnlDuzenliOdemeTx.setEftOdemeTuru(iMap.getString("EFT_ODEME_TURU"));
			gnlDuzenliOdemeTx.setFIbanBilinmiyor(iMap.getString("FIBAN_BILINMIYOR"));
			gnlDuzenliOdemeTx.setHvlOdemeTuru(iMap.getBigDecimal("GONDERIM_AMACI",new BigDecimal(99)));
			if(iMap.getBoolean("BILGILENDIRME_EMAIL")){
				gnlDuzenliOdemeTx.setEmailEh("E");
			}else{
				gnlDuzenliOdemeTx.setEmailEh("H");
			}
			if(iMap.getBoolean("BILGILENDIRME_SMS")){
				gnlDuzenliOdemeTx.setSmsEh("E");
			}else{
				gnlDuzenliOdemeTx.setSmsEh("H");
			}
			if(iMap.containsKey("BILGILENDIRME_AJANDA")){
				if(iMap.getBoolean("BILGILENDIRME_AJANDA")){
					gnlDuzenliOdemeTx.setAjandaEh("E");
				}else{
					gnlDuzenliOdemeTx.setAjandaEh("H");
				}
			}

			gnlDuzenliOdemeTx.setCepTelSirano(iMap.getBigDecimal("SMS_TELEFON_SIRA"));
			gnlDuzenliOdemeTx.setEmailTip(iMap.getString("BILGILENDIRME_EMAIL_TIP"));
			if(iMap.containsKey("ALICI_TC_KIMLIK_NO")){
				gnlDuzenliOdemeTx.setAliciTcKimlikNo(iMap.getString("ALICI_TC_KIMLIK_NO"));
			}
			if(iMap.containsKey("ALICI_VERGI_NO")){
				gnlDuzenliOdemeTx.setAliciVergiNo(iMap.getString("ALICI_VERGI_NO"));
			}
			
			session.saveOrUpdate(gnlDuzenliOdemeTx);
			
			List<?>	taksitPersistentList = session.createCriteria(GnlDuzenliTaksitTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = taksitPersistentList.iterator(); iterator.hasNext();) {
				GnlDuzenliTaksitTx gnlDuzenliTaksitTx = (GnlDuzenliTaksitTx) iterator.next();
				session.delete(gnlDuzenliTaksitTx);
			}
			
			int i = 1;
			String tableName = "DUZENLI_TAKSIT_ISLEM";
			List<?> taksitList = (List<?>) iMap.get(tableName);
			for (int j = 0; j < taksitList.size(); j++) {
				GnlDuzenliTaksitTx duzenliTaksitTx = new GnlDuzenliTaksitTx();
				duzenliTaksitTx.setTaksitTarihi(iMap.getDate(tableName, j, "TAKSIT_TARIHI"));
				duzenliTaksitTx.setTaksitTutar(iMap.getBigDecimal(tableName, j, "TAKSIT_TUTAR"));
				GnlDuzenliTaksitTxId id = new GnlDuzenliTaksitTxId();
				
				duzenliTaksitTx.setDenenecekSayi(iMap.getBigDecimal( "DENENECEK_SAYI"));
				id.setTxNo(iMap.getBigDecimal("TRX_NO"));
				id.setSiraNo(new BigDecimal(i++));
				duzenliTaksitTx.setId(id);
				session.save(duzenliTaksitTx);

			}
			session.flush();
			
			iMap.put("TRX_NAME", "2301");
			GMMap oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			session.refresh(gnlDuzenliOdemeTx);
			oMap.put("REC_ID", gnlDuzenliOdemeTx.getSiraNo());
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2301_GET_TELEFON_LIST")
	public static GMMap getTelefonList(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("select sira_no,alan_kod||' '||tel_no  from gnl_musteri_telefon  where musteri_no=? and tel_tip=3");
			stmt.setBigDecimal(1, iMap.getBigDecimal("MUSTERI_NO"));
			rSet = stmt.executeQuery();
			String listName = "RESULTS";
			while (rSet.next()) {
				GuimlUtil.wrapMyCombo(oMap, listName, rSet.getString(1), rSet.getString(2));
			}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
}
