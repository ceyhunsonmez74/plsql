

package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class EftQRY2380Services {
	@GraymoundService("BNSPR_QRY2380_GET_EFT_MESAJLARI")
	public static GMMap getEftList(GMMap iMap) {
		   
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		int i=1;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_eft.RC_QRY2380_GET_EFT_MESAJLARI(?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("GELEN_GIDEN"));
			stmt.setString(i++, iMap.getString("MESAJ_KODU"));
			if(iMap.getString("K_DURUM")!=null && !iMap.getString("K_DURUM").equals(""))				
				stmt.setString(i++, iMap.getString("K_DURUM"));
			else
				stmt.setString(i++, null);
					
			if(iMap.getString("K_BOLUM")!=null && !iMap.getString("K_BOLUM").equals(""))
				{stmt.setString(i++, iMap.getString("K_BOLUM"));} 
			else stmt.setDate(i++, null);
			
			if ((iMap.get("K_EFT_TARIH_BAS") != null)) stmt.setDate(i++, new Date( iMap.getDate("K_EFT_TARIH_BAS").getTime()));
			else stmt.setDate(i++, null);

			if ((iMap.get("K_EFT_TARIH_BIT") != null)) stmt.setDate(i++, new Date(iMap.getDate("K_EFT_TARIH_BIT").getTime()));
			else stmt.setDate(i++, null);
			
			stmt.setString(i++, iMap.getString("K_MUSTERI_NO"));
			
			if (iMap.getBigDecimal("K_MIN_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("K_MIN_TUTAR"));

			if (iMap.getBigDecimal("K_MAX_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("K_MAX_TUTAR"));

			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "EFT_MESAJLARI";
			int row = 0;
			BigDecimal gelenTutar = new BigDecimal(0);
			BigDecimal gidenTutar = new BigDecimal(0);
			int gidenSayi = 0;
			int gelenSayi = 0;
			while (rSet.next()) {
                oMap.put(tableName, row,"MTRN", rSet.getString("mtrn"));
                oMap.put(tableName, row,"MESAJ_KODU", rSet.getString("mstype"));
                oMap.put(tableName, row,"BANKA_ADI", rSet.getString("alan_banka_adi"));
                oMap.put(tableName, row,"EFT_TARIH", rSet.getDate("eft_tarih"));
                oMap.put(tableName, row,"DURUM", rSet.getString("durum"));
                oMap.put(tableName, row,"TRX_NO", rSet.getString("tx_no"));
                oMap.put(tableName, row,"EFT_TUTAR", rSet.getString("eft_tutar"));	
				if (iMap.getString("GELEN_GIDEN").equals("GELEN")){
 				try {
					gelenTutar = gelenTutar.add(rSet.getBigDecimal("eft_tutar"));
					gelenSayi++;
				} catch (Exception e) {}				
				} else
				if (iMap.getString("GELEN_GIDEN").equals("GIDEN")){
	 				try {
	 					gidenTutar = gidenTutar.add(rSet.getBigDecimal("eft_tutar"));
						gidenSayi++;
					} catch (Exception e) {}				
				}
				row++;
			}
			oMap.put("GELEN_TOPLAM", gelenTutar);
			oMap.put("GIDEN_TOPLAM", gidenTutar);
			oMap.put("GELEN_KAYIT_SAYISI", gelenSayi);
			oMap.put("GIDEN_KAYIT_SAYISI", gidenSayi);
			
			String listName = "EFT_TIPLERI";
			GuimlUtil.wrapMyCombo(oMap, listName, "GELEN", "Gelen");
			GuimlUtil.wrapMyCombo(oMap, listName, "GIDEN", "Giden");
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY2380_INITIALIZE")
	public static GMMap getGidenEftMesajlari(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			GMMap xMap = new GMMap();
          
			if ( "GIDEN".equals(iMap.getString("GELEN_GIDEN")) ) { 
   
			xMap.put("KOD"				, "GIDEN_EFT_DURUM");
			xMap.put("ADD_EMPTY_KEY"	, "E");
			oMap.put("EFT_DURUM"	, GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", xMap).get("RESULTS"));
			}
			else
			{	
			xMap.put("KOD"				, "GELEN_EFT_DURUM");
			xMap.put("ADD_EMPTY_KEY"	, "E");
			oMap.put("EFT_DURUM"	, GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", xMap).get("RESULTS"));
			}			
			
			
		} catch (Exception e) {
			EftServices.throwGMBusssinessException(e.getMessage());
			//throw new GMRuntimeException(0, e);
		}
		return oMap;
	}	
	
	
}



