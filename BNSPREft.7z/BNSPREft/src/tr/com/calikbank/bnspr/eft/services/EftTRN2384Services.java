package tr.com.calikbank.bnspr.eft.services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftDetayTx;
import tr.com.calikbank.bnspr.dao.EftEftTx;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2384Services {
    
    @GraymoundService("BNSPR_TRN2384_GET_EFT_INFO")
    public static GMMap getInfo(GMMap iMap) {
        
        try{
            
            Session session = DAOSession.getSession("BNSPRDal");
            
          
            EftEftTx eftEftTx = (EftEftTx) session.createCriteria(EftEftTx.class).add(Restrictions.eq("txNo" , iMap.getBigDecimal("TRX_NO"))).uniqueResult();
            GMMap oMap = new GMMap();
            
            oMap.put("TRX_NO" , eftEftTx.getTxNo());
            oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
            oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
            oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
            oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
            oMap.put("DURUM" , eftEftTx.getDurum());
            oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
            oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
            oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
            oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
            oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
            oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
            oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
            oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
            oMap.put("TUTAR" , eftEftTx.getTutar());
            oMap.put("GELEN_GIDEN" , eftEftTx.getGelenGiden());
            oMap.put("KIYMET_KODU" , eftEftTx.getKiymetKodu());
            oMap.put("MIKTAR" , eftEftTx.getMiktar());
            oMap.put("KULLANICI_REFERANSI" , eftEftTx.getKullaniciReferansi());
            oMap.put("CIKIS_DEPO_KODU" , eftEftTx.getCikisDepoKodu());
            oMap.put("PARCALI_TESLIMAT_IZIN_GOSTERGESI" , eftEftTx.getParcaTeslIzinGosterge());
            oMap.put("DONUS_TARIHI" , eftEftTx.getDonusTarihi());
            oMap.put("DONUS_TUTARI" , eftEftTx.getDonusTutari());
            oMap.put("SATIS_TURU" , eftEftTx.getSatisTuru());
            oMap.put("ALIS_TARIHI" , eftEftTx.getAlisTarihi());
            oMap.put("ALICININ_ADI_SOYADI" , eftEftTx.getAlicininAdiSoyadi());
            oMap.put("ALIS_BEDELI" , eftEftTx.getAlisBedeli());
            oMap.put("ALICI_HESAP_NO" , eftEftTx.getAliciHesapNo());
            oMap.put("MESAJ_GRUBU" , eftEftTx.getMesajGrubu());
            oMap.put("GUNBASI_BAKIYE" , eftEftTx.getGunbasiBakiye());
            oMap.put("BORCLANDIRAN_MESAJ_ADEDI" , eftEftTx.getBorcMesajAdet());
            oMap.put("BORCLANDIRAN_TUTAR" , eftEftTx.getBorcTutar());
            oMap.put("ALACAKLANDIRAN_MESAJ_ADEDI" , eftEftTx.getAlacMesajAdet());
            oMap.put("ALACAKLANDIRAN_TUTAR" , eftEftTx.getAlacTutar());
            oMap.put("KIYMET_ADET" , eftEftTx.getKiymetAdet());
            
            
            
            List<?> eftDetayList = session.createCriteria(EftEftDetayTx.class).add(Restrictions.eq("id.txNo" , iMap.getBigDecimal("TRX_NO"))).list();
            int i = 0;
            for (Object name : eftDetayList){
                EftEftDetayTx eftEftDetayTx = (EftEftDetayTx) name;
                oMap.put("EFTDETAY" , i , "KIYMET_KODU" , eftEftDetayTx.getKiymetKodu());
                oMap.put("EFTDETAY" , i , "ALAC_MIKTAR" , eftEftDetayTx.getAlacMiktar());
                oMap.put("EFTDETAY" , i , "BORC_MIKTAR" , eftEftDetayTx.getBorcMiktar());
                oMap.put("EFTDETAY" , i , "DEPO_KODU" , eftEftDetayTx.getDepoKodu());
                oMap.put("EFTDETAY" , i , "DONDURULMUS_MIKTAR" , eftEftDetayTx.getDondurulmusMiktar());
                oMap.put("EFTDETAY" , i , "GUNBASI_MIKTAR" , eftEftDetayTx.getGunbasiMiktar());
                oMap.put("EFTDETAY" , i , "KALAN_MIKTAR" , eftEftDetayTx.getKalanMiktar());
                i++;
            }
            
            oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka() , eftEftTx.getGonderenSube() , eftEftTx.getGonderenSehir() , eftEftTx.getAlanBankaKodu() , eftEftTx.getAlanSubeKodu() ,
                    eftEftTx.getAlanSehirKodu()));
            
            return oMap;
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        
    }
    
}
