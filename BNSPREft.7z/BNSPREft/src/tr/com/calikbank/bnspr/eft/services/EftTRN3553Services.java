package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.CsReverseAccountingTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN3553Services {
    @GraymoundService("BNSPR_TRN3553_SAVE")
    public static Map<?, ?> save(GMMap iMap) {
        
        Session session = DAOSession.getSession("BNSPRDal");
  
        CsReverseAccountingTx csReverseAccountingTx = new CsReverseAccountingTx();
        
        saveOrNot(iMap , session);
        
    
        csReverseAccountingTx.setFisAciklamasi(iMap.getString("REFERANS"));
        csReverseAccountingTx.setIslemAciklamasi1(iMap.getString("GONDEREN_AD_SOYAD"));
        csReverseAccountingTx.setIslemAciklamasi2(iMap.getString("ALICI_AD_SOYAD"));
        csReverseAccountingTx.setRevTxNo(iMap.getBigDecimal("REV_TX_NO"));
        csReverseAccountingTx.setTutar(iMap.getBigDecimal("TUTAR"));
        csReverseAccountingTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
        csReverseAccountingTx.setUserCode("TU001");
        
        session.saveOrUpdate(csReverseAccountingTx);
        session.flush();
        
        iMap.put("TRX_NAME" , "3553");
        return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION" , iMap);
    }
    
    private static void saveOrNot(GMMap iMap, Session hibSession) {
        
        BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
        
        if (txNo == null){
            iMap.put("HATA_NO" , new BigDecimal(660));
            iMap.put("P1" , "Trx No alan� bo� girilemez!");
            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
        }
        
        
        
        if (iMap.getBigDecimal("REV_TX_NO") == null){
            iMap.put("HATA_NO" , new BigDecimal(660));
            iMap.put("P1" , "��lem Numaras� alan� bo� girilemez!");
            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
        }
        if (iMap.getBigDecimal("TUTAR") == null){
            iMap.put("HATA_NO" , new BigDecimal(660));
            iMap.put("P1" , "Tutar alan� bo� girilemez!");
            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
        }
        if (StringUtil.isEmpty(iMap.getString("REFERANS"))){
            iMap.put("HATA_NO" , new BigDecimal(660));
            iMap.put("P1" , "Referans alan� bo� girilemez!");
            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
        }
        if (StringUtil.isEmpty(iMap.getString("GONDEREN_AD_SOYAD"))){
            iMap.put("HATA_NO" , new BigDecimal(660));
            iMap.put("P1" , "G�nderen ad� bo� girilemez!");
            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
        }
        if (StringUtil.isEmpty(iMap.getString("ALICI_AD_SOYAD"))){
            iMap.put("HATA_NO" , new BigDecimal(660));
            iMap.put("P1" , "Al�c� ad� bo� girilemez!");
            GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ" , iMap);
        }
      
    }
    
    public static String getShortDateTimeString(Date date) {
        DateFormat shortDateTimeFormat = new SimpleDateFormat("yyyyMMdd");
        return shortDateTimeFormat.format(date);
    }
    
    @GraymoundService("BNSPR_TRN3553_GET_INFO")
    public static GMMap getInfo(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        
        try{
            Session session = DAOSession.getSession("BNSPRDal");
            BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
        
            
            CsReverseAccountingTx csReverseAccountingTx = (CsReverseAccountingTx) session.createCriteria(CsReverseAccountingTx.class).add(Restrictions.eq("txNo" , txNo)).uniqueResult();
            session.flush();
            
            oMap.put("REFERANS" , csReverseAccountingTx.getFisAciklamasi());
            oMap.put("GONDEREN_AD_SOYAD" , csReverseAccountingTx.getIslemAciklamasi1());
            oMap.put("ALICI_AD_SOYAD" , csReverseAccountingTx.getIslemAciklamasi2());
            oMap.put("REV_TX_NO" , csReverseAccountingTx.getRevTxNo());
            oMap.put("TUTAR" , csReverseAccountingTx.getTutar());
            oMap.put("TRX_NO" , csReverseAccountingTx.getTxNo());
            oMap.put("KULLANICI_KODU" , csReverseAccountingTx.getUserCode());
            
            csReverseAccountingTx.setFisAciklamasi(iMap.getString("REFERANS"));
            csReverseAccountingTx.setIslemAciklamasi1(iMap.getString("GONDEREN_AD_SOYAD"));
            csReverseAccountingTx.setIslemAciklamasi2(iMap.getString("ALICI_AD_SOYAD"));
            csReverseAccountingTx.setIslemAciklamasi3(iMap.getString("ISLEM_ACIKLAMA3"));
            csReverseAccountingTx.setRevTxNo(iMap.getBigDecimal("REV_TX_NO"));
            csReverseAccountingTx.setTutar(iMap.getBigDecimal("TUTAR"));
            csReverseAccountingTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
            csReverseAccountingTx.setUserCode("TU001");
            
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
    
    @GraymoundService("BNSPR_TRN3553_FILL")
    public static GMMap fill(GMMap iMap) {
        
        GMMap oMap = new GMMap();
        
        try{
            
            Object[] values = new Object[2];
            values[0] = BnsprType.NUMBER;
            values[1] = iMap.getBigDecimal("REV_TRX_NO");
            String func = "{? = call pkg_trn3553.get3552list(?) }";
            GMMap funtionReturnMap = new GMMap();
            funtionReturnMap = DALUtil.callOracleRefCursorFunction(func , "APP_LIST" , values);
            
            
            if (funtionReturnMap.getSize("APP_LIST") == 0){
                throwGMBusssinessException("�ptal edilecek muhasebe kayd� yok.");
            }
           oMap.put("GONDEREN_AD_SOYAD" , funtionReturnMap.getString("APP_LIST" , 0 , "GONDEREN_AD_SOYAD"));
           oMap.put("ALICI_AD_SOYAD" , funtionReturnMap.getString("APP_LIST" , 0 , "ALICI_AD_SOYAD"));
           oMap.put("TUTAR" , funtionReturnMap.getBigDecimal("APP_LIST" , 0 , "TUTAR")); 
           oMap.put("REFERANS" , funtionReturnMap.getString("APP_LIST" , 0 , "REFERANS"));
           oMap.put("REV_TRX_NO" , funtionReturnMap.getString("APP_LIST" , 0 , "REV_TRX_NO"));
        } catch (Exception e){
           
             throwGMBusssinessException("Bu i�lem numaras�yla muhasebe i�lemi yok!");
        }
        return oMap;
    }
    
    public static GMMap throwGMBusssinessException(String string) {             
        GMMap exMap = new GMMap();
        exMap.put("P1", string);
        exMap.put("HATA_NO", "660");
        return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", exMap);
    }
}
