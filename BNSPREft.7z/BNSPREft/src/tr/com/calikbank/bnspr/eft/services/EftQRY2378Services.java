package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class EftQRY2378Services {
	@GraymoundService("BNSPR_QRY2378_GET_EFT_MESAJLARI")
	public static GMMap getEftList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		int i = 1;	  
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_eft.RC_QRY2378_GET_EFT_MESAJLARI(?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("GELEN_GIDEN"));
			stmt.setString(i++, iMap.getString("MESAJ_KODU"));
			if(iMap.getString("K_DURUM")!=null && !iMap.getString("K_DURUM").equals(""))				
				stmt.setString(i++, iMap.getString("K_DURUM"));
			else
				stmt.setString(i++, null);
			stmt.setString(i++, iMap.getString("K_EFT_DURUMU"));
					
			if(iMap.getString("K_BOLUM")!=null && !iMap.getString("K_BOLUM").equals(""))
				{stmt.setString(i++, iMap.getString("K_BOLUM"));} 
			else stmt.setDate(i++, null);
			
			if ((iMap.get("K_EFT_TARIH_BAS") != null)) stmt.setDate(i++, new Date( iMap.getDate("K_EFT_TARIH_BAS").getTime()));
			else stmt.setDate(i++, null);

			if ((iMap.get("K_EFT_TARIH_BIT") != null)) stmt.setDate(i++, new Date(iMap.getDate("K_EFT_TARIH_BIT").getTime()));
			else stmt.setDate(i++, null);
			
			stmt.setString(i++, iMap.getString("K_MUSTERI_NO"));
			
			if (iMap.getBigDecimal("K_MIN_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("K_MIN_TUTAR"));

			if (iMap.getBigDecimal("K_MAX_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("K_MAX_TUTAR"));
            
			stmt.setString(i++, iMap.getString("SIRALAMA_KRITERI"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
	
			String tableName = "EFT_MESAJLARI";
			int row = 0;
			BigDecimal gelenTutar = new BigDecimal(0);
			BigDecimal gidenTutar = new BigDecimal(0);
			int gidenSayi = 0;
			int gelenSayi = 0;
			while (rSet.next()) {
				oMap.put(tableName, row,"EKRAN_NO", rSet.getString("ekran_no"));
                if (rSet.getString("gelen_giden").equals("GELEN"))
                	oMap.put(tableName, row,"GELEN_GIDEN",  "Gelen");
                else
                	oMap.put(tableName, row,"GELEN_GIDEN",  "Giden");
                oMap.put(tableName, row,"SORGU_NO", rSet.getString("sorgu_no"));
                oMap.put(tableName, row,"MESAJ_KODU", rSet.getString("mesaj_kodu"));
                oMap.put(tableName, row,"BANKA_ADI", rSet.getString("banka_adi"));
                oMap.put(tableName, row,"SUBE_ADI", rSet.getString("sube_adi"));
                oMap.put(tableName, row,"EFT_TARIH", rSet.getDate("eft_tarih"));
                oMap.put(tableName, row,"HATA_KODU", rSet.getString("hata_kodu"));
                oMap.put(tableName, row,"DURUM", rSet.getString("durum"));
                oMap.put(tableName, row,"TRX_NO", rSet.getString("tx_no"));
                oMap.put(tableName, row,"KANAL_ADI", rSet.getString("kanal_adi"));
                oMap.put(tableName, row,"ISLEM_SAAT", rSet.getString("islem_saati"));
                oMap.put(tableName, row,"ODEME_ACIK", rSet.getString("odeme_acik"));
                oMap.put(tableName, row,"TUTAR", rSet.getString("TUTAR"));	
                oMap.put(tableName, row,"ACIKLAMA", rSet.getString("ACIKLAMA"));	
                oMap.put(tableName, row,"KAS_MESAJ_KODU", rSet.getString("KAS_MESAJ_KODU"));
                oMap.put(tableName, row,"ODEME_TRX_NO", rSet.getString("ODEME_TX_NO"));
                oMap.put(tableName, row,"YARATILDIGI_TARIH", rSet.getString("yaratildigi_tarih"));
				if (rSet.getString("gelen_giden").equals("GELEN")){
 				try {
					gelenTutar = gelenTutar.add(rSet.getBigDecimal("tutar"));
					gelenSayi++;
				} catch (Exception e) {}				
				} else
				if (rSet.getString("gelen_giden").equals("GIDEN")){
	 				try {
	 					gidenTutar = gidenTutar.add(rSet.getBigDecimal("tutar"));
						gidenSayi++;
					} catch (Exception e) {}				
				}
				oMap.put(tableName, row,"TU_REFERANS", rSet.getString("TU_referans"));
				row++;  
			}
			oMap.put("GELEN_TOPLAM", gelenTutar);
			oMap.put("GIDEN_TOPLAM", gidenTutar);
			oMap.put("GELEN_KAYIT_SAYISI", gelenSayi);
			oMap.put("GIDEN_KAYIT_SAYISI", gidenSayi);
			
			String listName = "EFT_TIPLERI";
			GuimlUtil.wrapMyCombo(oMap, listName, "GELEN", "Gelen");
			GuimlUtil.wrapMyCombo(oMap, listName, "GIDEN", "Giden");
			
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2378_GET_DURUM_KODLARI")
	public static GMMap getEFTDurumKodlari(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			if("GELEN".equals(iMap.getString("GELEN_GIDEN")))
				DALUtil.fillComboBox(oMap, "DURUM_KODU", true, "select key1 kod,text from v_ml_gnl_param_text t where t.KOD = 'GELEN_EFT_DURUM' and key1 not in ('EKLENDI') order by text");
			else if("GIDEN".equals(iMap.getString("GELEN_GIDEN")))
				DALUtil.fillComboBox(oMap, "DURUM_KODU", true, "select key1 kod,text from v_ml_gnl_param_text t where t.KOD = 'GIDEN_EFT_DURUM' and key1 not in ('RELEASE') order by text");
			else
				DALUtil.fillComboBox(oMap, "DURUM_KODU", true, "select distinct key1 kod, text from v_ml_gnl_param_text t where t.KOD in ('GELEN_EFT_DURUM', 'GIDEN_EFT_DURUM') and key1 not in ('RELEASE') order by text");
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	
}
 



