package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

@SuppressWarnings("deprecation")
public class EftTRN2370Services {
	@GraymoundService("BNSPR_TRN2370_GET_INITIAL_VALUES")
	public static GMMap getInitialValues(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN2370.form_instance(?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.DATE);
			stmt.registerOutParameter(5, Types.DECIMAL);
			stmt.execute();

			oMap.put("SUBE_KODU", stmt.getString(1));
			oMap.put("BANKA_KODU", stmt.getString(2));
			oMap.put("BANKA_ADI", stmt.getString(3));
			oMap.put("EFT_TARIH", stmt.getDate(4));
			oMap.put("TRX_NO", stmt.getBigDecimal(5));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	@GraymoundService("BNSPR_TRN2370_GET_EFT_BILGI")
	public static GMMap getEftBilgi(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			// EftEftTx eftEftTx = (EftEftTx) session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			EftEftTx eftEftTx = (EftEftTx)session.createCriteria(EftEftTx.class).add(Restrictions.or(Restrictions.eq("txNo",  iMap.getBigDecimal("TRX_NO")),Restrictions.eq("odemeTxNo",  iMap.getBigDecimal("TRX_NO")))).uniqueResult();

			GMMap oMap = new GMMap();

			oMap.put("MUSTERI_NO", eftEftTx.getMusteriNo());
			oMap.put("DISPLAY_MUSTERI_ADI", LovHelper.diLov(eftEftTx.getMusteriNo(), "2315/LOV_MUSTERI", "UNVAN"));
			oMap.put("IADE_HESAP_NUMARASI", eftEftTx.getIadeHesapNumarasi());
			oMap.put("DK_HESAP_NO", eftEftTx.getDkHesapNo());
			oMap.put("IADE_VERGI_KIMLIK_NUMARA", eftEftTx.getIadeVergiKimlikNumara());
			
			if (eftEftTx.getIadeHesapNumarasi() != null) {
				iMap.put("HESAP_NO", eftEftTx.getIadeHesapNumarasi());
				oMap.put("KULLANILABILIR_BAKIYE", GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", iMap).get(
						"KULLANILABILIR_BAKIYE"));
				oMap.put("DEFTER_BAKIYE", GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_DEFTER_BAKIYE", iMap).get(
						"DEFTER_BAKIYE"));
			}
			oMap.put("GONDEREN_BANKA", eftEftTx.getGonderenBanka());
			oMap.put("GONDEREN_SUBE", eftEftTx.getGonderenSube());
			oMap.put("GONDEREN_SEHIR", eftEftTx.getGonderenSehir());
			oMap.put("IADE_EDEN", eftEftTx.getIadeEden());
			oMap.put("GONDEREN_TELEFON", eftEftTx.getGonderenTelefon());
			oMap.put("GONDEREN_ADRES", eftEftTx.getGonderenAdres());
			oMap.put("ALICI_HESAP_NO", eftEftTx.getAliciHesapNo());
			oMap.put("ALICI_ADI", eftEftTx.getAliciAdi());
			oMap.put("ALAN_BANKA_KODU", eftEftTx.getAlanBankaKodu());
			oMap.put("ALAN_SEHIR_KODU", eftEftTx.getAlanSehirKodu());
			oMap.put("ALAN_SUBE_KODU", eftEftTx.getAlanSubeKodu());
			oMap.put("ALICI_IBAN", eftEftTx.getAliciIban());
			oMap.put("IADE_KODU", eftEftTx.getIadeKodu());
			oMap.put("IADE_ACIKLAMA" , LovHelper.diLov(eftEftTx.getIadeKodu(), "2311/LOV_IADE_KODU", "ACIKLAMA"));
			oMap.put("TUTAR", eftEftTx.getTutar());
			oMap.put("EFT_TARIH", eftEftTx.getEftTarih());
			oMap.put("ONCELIK", eftEftTx.getOncelik().toString());
			oMap.put("ILGILI_ISLEM_TARIH", eftEftTx.getIlgiliIslemTarih());
			oMap.put("ILGILI_ISLEM_NUMARA", eftEftTx.getIlgiliIslemNumara());
			oMap.put("ILGILI_SORGU_NUMARA", eftEftTx.getIlgiliIslemReferansi());
			oMap.put("TRX_NO", eftEftTx.getTxNo());
			oMap.put("MESAJ_KODU", eftEftTx.getMesajKodu());
			oMap.put("SORGU_NO", eftEftTx.getSorguNo());
			oMap.put("ACIKLAMA", eftEftTx.getAciklama());
			oMap.put("ACIKLAMA_2", eftEftTx.getAciklama2());
			oMap.put("DURUM", eftEftTx.getDurum());
			oMap.putAll(EftServices.getEftDiValues(eftEftTx
					.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx
					.getGonderenSehir(), eftEftTx.getAlanBankaKodu(), eftEftTx
					.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
	        oMap.put("ODEME_TX_NO" ,eftEftTx.getOdemeTxNo());

	        oMap.put("ISLEM_TIPI" , eftEftTx.getIslemTipi());
	        oMap.put("ODEME_SUBE" , eftEftTx.getOdemeSube());
	        oMap.put("ODEME_DK_HESAP" , eftEftTx.getOdemeDkHesap());
	        oMap.put("ODEME_MUSTERI_NO" , eftEftTx.getOdemeMusteriNo());
	        oMap.put("ODEME_MUSTERI_HESAP" , eftEftTx.getOdemeMusteriHesap());
	        oMap.put("ALICI_IBAN" , eftEftTx.getAliciIban());	  
	        oMap.put("MASRAF", eftEftTx.getMasraf());

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
