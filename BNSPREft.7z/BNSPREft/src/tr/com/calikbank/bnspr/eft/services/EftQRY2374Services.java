package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.HashMap;
import java.util.List;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftQRY2374Services {
	
	@GraymoundService("BNSPR_QRY2374_INITIALIZE")
	public static GMMap getGidenEftMesajlari(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			GMMap xMap = new GMMap();

			DALUtil.fillComboBox(oMap, "KANAL_LIST"			, true, "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr where KOD in ('7') ");
			DALUtil.fillComboBox(oMap, "KANAL_LIST2"			, false, "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr where KOD in ('7','21') ");
			DALUtil.fillComboBox(oMap, "DURUM_KODU_LIST"	, true, "select key1, text from v_ml_gnl_param_text where KOD = 'GELEN_EFT_DURUM' and KEY1 in ('PTT_OK','PTT_ODNCK','PTT_SORUN') ");
			DALUtil.fillComboBox(oMap, "TBL_DURUM_KODU_LIST", true, "select key1, text from v_ml_gnl_param_text where KOD = 'GELEN_EFT_DURUM' and KEY1 in ('PTT_ODNCK','PTT_SORUN') ");
			DALUtil.fillComboBox(oMap, "GIDEN_DURUM_KODU"	, true, "select key1, text from v_ml_gnl_param_text where kod = 'GIDEN_EFT_DURUM' and key1 in ('TAMAM','IPTAL','2.ONAY','TCMB')");
			DALUtil.fillComboBox(oMap, "GIDEN_ISLEM_TIPI"	, true, "select key1, text from v_ml_gnl_param_text where kod = 'GIDEN_EFT_ISLEM_TIPI'");

			/*xMap.put("KOD"				, "PFT_TOPLU_ONAY_KRITER");
			xMap.put("ADD_EMPTY_KEY"	, "E");
			oMap.put("ISLEM_DURUM_LIST"	, GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", xMap).get("RESULTS"));*/
			
			xMap.put("KOD"				, "EFT_GUNCELLEME_SEBEP");
			xMap.put("ADD_EMPTY_KEY"	, "E");
			oMap.put("ACIKLAMA_LIST"	, GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", xMap).get("RESULTS"));
			
			/*
			iMap.put("ADD_EMPTY_KEY"	, "E");
			iMap.put("KOD"				, "CLKS_IZLEME_ISLEM_TIPI");
			oMap.put("ISLEM_TIPI"		, GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			*/
			
			DALUtil.fillComboBox(oMap, "ISLEM_TIPI"	, true, "select key1, text from v_ml_gnl_param_text where kod = 'CLKS_IZLEME_ISLEM_TIPI' union all  select 'E'||key1, text from v_ml_gnl_param_text where kod = 'CLKS_IZLEME_ISLEM_TIPI_EUPT' ");

			DALUtil.fillComboBox(oMap, "ISLEM_TIPI_TBL"	, true, "select key1, text from v_ml_gnl_param_text where kod = 'CLKS_IZLEME_ISLEM_TIPI_EXCEL' union all  select key1, text from v_ml_gnl_param_text where kod = 'CLKS_IZLEME_ISLEM_TIPI_EXCEL_EUPT' ");

			/*iMap.put("ADD_EMPTY_KEY"	, "E");
			iMap.put("KOD"				, "CLKS_IZLEME_ISLEM_TIPI_EXCEL");
			oMap.put("ISLEM_TIPI_TBL"	, GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            */
			
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_BANKA_TARIH", iMap));
			
		} catch (Exception e) {
			EftServices.throwGMBusssinessException(e.getMessage());
			//throw new GMRuntimeException(0, e);
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_QRY2374_INITIALIZE_ISLEM_TIPI")
	public static GMMap getIslem_tipi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			iMap.put("ADD_EMPTY_KEY"	, "E");
			iMap.put("KOD"				, "CLKS_IZLEME_ISLEM_TIPI_EXCEL_EUPT");
			oMap.put("ISLEM_TIPI_TBL"	, GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            
			
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_BANKA_TARIH", iMap));
			
		} catch (Exception e) {
			EftServices.throwGMBusssinessException(e.getMessage());
			//throw new GMRuntimeException(0, e);
		}
		return oMap;
	}	
    
    @GraymoundService("BNSPR_QRY2374_GET_UNVAN")
    public static GMMap getMusteriUnvan(GMMap iMap) {
        GMMap oMap = new GMMap();
        try
        {              
            oMap.put("UNVAN" , LovHelper.diLov(iMap.getBigDecimal("MUSTERI_NO") , "2056Q/LOV_MUSTERI_NO" , "UNVAN"));

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
	
	@GraymoundService("BNSPR_QRY2374_INITIALIZE_ISLEM_TIPI_ALL")
	public static GMMap getIslem_tipiall(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			DALUtil.fillComboBox(oMap, "ISLEM_TIPI_TBL"	, true, "select key1, text from v_ml_gnl_param_text where kod = 'CLKS_IZLEME_ISLEM_TIPI_EXCEL' union all  select 'E'||key1, text from v_ml_gnl_param_text where kod = 'CLKS_IZLEME_ISLEM_TIPI_EXCEL_EUPT' ");

		} catch (Exception e) {
			EftServices.throwGMBusssinessException(e.getMessage());
		}
		return oMap;
	}		
	
	@GraymoundService("BNSPR_QRY2374_GET_GELEN_UPT")
	public static GMMap getGidenUpt(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		int i = 1;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2374.RC_TRN2374_GELEN_EFT_MESAJLARI(?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("KANAL"));
			stmt.setString(i++, iMap.getString("SORGU_NO"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			stmt.setString(i++, iMap.getString("ISLEM_DURUMU"));
			stmt.setString(i++, iMap.getString("GONDEREN_BANKA"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_TUTAR"));
			if(iMap.getDate("BAS_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("BAS_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			
			if(iMap.getDate("BIT_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("BIT_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			
			stmt.setString(i++, iMap.getBoolean("30_GUNU_DOLAN") ? "E" : "H");
			stmt.setString(i++, iMap.getBoolean("IADE_GIDEN") ? "E" : "H");
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			GMMap oMap = new GMMap();
			oMap.putAll(DALUtil.rSetResults(rSet, "GELEN_UPT")); 
			if(!oMap.containsKey("GELEN_UPT"))
			{
				iMap.put("HATA_NO", new BigDecimal(1614));
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2374_GET_GIDEN_UPT")
	public static GMMap getGelenUpt(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		int i = 1;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2374.RC_TRN2374_GIDEN_EFT_MESAJLARI(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("KANAL"));
			stmt.setString(i++, iMap.getString("SORGU_NO"));
			stmt.setString(i++, iMap.getString("UPT_TIPI"));
			stmt.setString(i++, iMap.getString("ISLEM_TIPI"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("UPT_ISLEM_NO"));
			stmt.setString(i++, iMap.getString("GON_AD_SOYAD"));
			stmt.setString(i++, iMap.getString("GON_TCKN"));
			stmt.setString(i++, iMap.getString("GON_PTT_SUBE"));
			stmt.setString(i++, iMap.getString("GON_PTT_SICIL_KODU"));
			stmt.setString(i++, iMap.getString("ALICI_BANKA"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			
			if (iMap.getBigDecimal("MIN_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_TUTAR"));

			if (iMap.getBigDecimal("MAX_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_TUTAR"));			
			
			
			if(iMap.getDate("BAS_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("BAS_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			
			if(iMap.getDate("BIT_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("BIT_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			stmt.setString(i++, iMap.getBoolean("IADE_GELEN") ? "E" : "H");
			stmt.setString(i++, iMap.getBoolean("CHK_TAMAMLANANLAR") ? "E" : "H");
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			GMMap oMap = new GMMap();
			oMap.putAll(DALUtil.rSetResults(rSet, "GIDEN_UPT")); 
			/*if(!oMap.containsKey("GIDEN_UPT"))
			{
				iMap.put("HATA_NO", new BigDecimal(1614));
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}*/
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2374_DURUM_KODLARI_GUNCELLE")
	public static GMMap durumKodlariGuncelle(GMMap iMap) {
		boolean flagChanged = false;
		String tableName = "UPT_LIST";
		for (int i = 0; i < iMap.getSize(tableName); i++) {
			List<?> uptList = (List<?>)iMap.get(tableName);
			HashMap<?, ?> map = (HashMap<?, ?>)uptList.get(i);
			GMMap xMap = new GMMap(map);
			if(xMap.getString("YENI_DURUM") != null && !"".equals(xMap.getString("YENI_DURUM"))) {
				if(!xMap.getString("YENI_DURUM").equals(xMap.getString("DURUM")) && 
						!xMap.getString("YENI_DURUM").equals(xMap.getString("MEVCUT_DURUM"))) {
					flagChanged = true;
					durumGuncelle(xMap);
				}
			}
		}
		if(!flagChanged) {
			iMap.put("HATA_NO"	, "1159");
			iMap.put("P1"		, "Yeni Durum");
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
		}
		return new GMMap();
	}
	
	private static void durumGuncelle(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{call pkg_eft.UPT_EFT_Statu_Degistir(?,?)}");
			stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_NO"));
			stmt.setString(2, iMap.getString("ACIKLAMA"));
			stmt.execute();
		}
		catch (Exception e){
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2374_GET_TARIHCE")
	public static GMMap getTarihce(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		GMMap				oMap = null;
		
		String tableName 	= "TARIHCE_LIST";
		String islemGoster[]= {"2345", "2319", "2311", "2317", "2312", "2030","2315","2320"};
		int i = 1;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2374.GET_EFT_TARIHCE(?)}");
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("ISLEM_NO"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			oMap = DALUtil.rSetResultsPutStr(rSet, tableName);
			
            for (int row = 0; row < oMap.getSize(tableName); row++){
                String islemNo = oMap.getString(tableName , row , "ISLEM_KODU");
                for (int n = 0; n < islemGoster.length; n++){
                    if (islemGoster[n].equals(islemNo)){
                        if (!StringUtil.isEmpty(oMap.getString(tableName , row , "ISLEM_NO"))){
                            oMap.put(tableName , row , "ISLEM_GOSTER" , true);
                            break;
                        }
                    }
                }
            }
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2374_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA")
	public static GMMap islemDogrulaOnayIptal(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		String islemTuru = iMap.getString("ISLEM_TURU");
		List<?> list = (List<?>)iMap.get("ISLEM_LIST");
		try {
			conn = DALUtil.getGMConnection();
			String mesajNo = null;
			for(int i = 0; i<list.size(); i++)
			{
				if(iMap.getBoolean("ISLEM_LIST", i, "SEC"))
				{
					if ("O".equals(islemTuru)) {
						if("H".equals(iMap.getString("ISLEM_LIST", i, "ONAYLANABILIR_MI")) || iMap.getString("ISLEM_LIST", i, "ONAYLANABILIR_MI") == null)
							mesajNo = "253";
					} else if ("IO".equals(islemTuru)) {
						if("H".equals(iMap.getString("ISLEM_LIST", i, "IPTAL_ONAYLANABILIR_MI")) || iMap.getString("ISLEM_LIST", i, "IPTAL_ONAYLANABILIR_MI") == null)
							mesajNo = "257";
					} else if ("DR".equals(islemTuru)) {
						if("H".equals(iMap.getString("ISLEM_LIST", i, "DOGRULANABILIR_MI")) || iMap.getString("ISLEM_LIST", i, "DOGRULANABILIR_MI") == null)
							mesajNo = "252";
					} else if ("OR".equals(islemTuru)) {
						if("H".equals(iMap.getString("ISLEM_LIST", i, "ONAYLANABILIR_MI")) || iMap.getString("ISLEM_LIST", i, "ONAYLANABILIR_MI") == null)
							mesajNo = "253";
					} else if ("IOR".equals(islemTuru)) {
						if("H".equals(iMap.getString("ISLEM_LIST", i, "IPTAL_ONAYLANABILIR_MI")) || iMap.getString("ISLEM_LIST", i, "IPTAL_ONAYLANABILIR_MI") == null)
							mesajNo = "257";
					}
					
					if(mesajNo != null)
					{
						iMap.put("HATA_NO", mesajNo);
						iMap.put("P1", iMap.getBigDecimal("ISLEM_LIST", i, "NO"));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						return oMap;
					}
				}
			}
			
			for(int i = 0; i<list.size(); i++)
			{
				if(iMap.getBoolean("ISLEM_LIST", i, "SEC"))
				{
                    GMMap tmpMap = new GMMap();
                    tmpMap.put("ISLEM_NO" , iMap.getBigDecimal("ISLEM_LIST", i, "NO"));
                    tmpMap.put("ACIKLAMA" , iMap.getString("ACIKLAMA"));
                    tmpMap.put("ISLEM_TURU" , islemTuru);
                    
                    oMap = GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", tmpMap);
				}
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			if(iMap.getString("ANA_SUBE")!= null && !iMap.getString("ANA_SUBE").isEmpty())
			{
				GMMap tempMap = new GMMap();
				tempMap.put("BRANCH_ID", iMap.getString("ANA_SUBE"));
				tempMap.put("GUIML_NAME", iMap.getString("GUIML_NAME"));
				GMServiceExecuter.execute("BNSPR_CORE_SET_USER_BRANCH", tempMap);
			}
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY2374_GET_ISLEM_YETKI_KONTROL")
	public static GMMap getIslemYetkiKontrol(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		GMMap oMap = new GMMap();
		int i = 1;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2374.islem_yetki_kontrol(?)}");
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_KOD"));
			stmt.execute();
			
			oMap.put("YETKI_KONTROL", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	
	@GraymoundService("BNSPR_QRY2374_IZLEME")
	public static GMMap getIslemIzleme(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		GMMap oMap = new GMMap();
		GMMap oMap1 = new GMMap();
		GMMap oMap2 = new GMMap();
		BigDecimal islem_sayi ;
		try {
            
			GMMap tmpMap = new GMMap();
            tmpMap.put("TARIHBAS" , iMap.getDate("TARIHBAS"));
            tmpMap.put("TARIHSON" , iMap.getDate("TARIHSON"));
            tmpMap.put("ISLEMTIPI" , iMap.getString("ISLEMTIPI"));
            tmpMap.put("DOVIZKODU" , iMap.getString("DOVIZKODU"));
            tmpMap.put("MUSTERINO" , iMap.getString("MUSTERINO"));
            tmpMap.put("PTTISLEMNO" , iMap.getString("PTTISLEMNO"));
            tmpMap.put("DURUMKODU" , iMap.getString("DURUMKODU"));
            tmpMap.put("UNVAN" , iMap.getString("UNVAN"));
            
            oMap1 = GMServiceExecuter.call("BNSPR_QRY2056_ISLEM_IZLEME", tmpMap);
            
            int k=0;
            int row = 0;
            String tableName = "IZLEMETABLOSU";
            for  ( k = 0; k < oMap1.getSize(tableName); k++) {            

				oMap.put(tableName, row, "ISLEMNO", oMap1.getBigDecimal(tableName, k, "ISLEMNO"));
				oMap.put(tableName, row, "PTTISLEMNO", oMap1.getBigDecimal(tableName, k, "PTTISLEMNO"));
				oMap.put(tableName, row, "ISLEM_TIPI", oMap1.getString(tableName, k, "ISLEM_TIPI"));
				oMap.put(tableName, row, "ISLEMTARIHI", oMap1.getDate(tableName, k, "ISLEMTARIHI"));
				oMap.put(tableName, row, "ISLEMSAATI", oMap1.getString(tableName, k, "ISLEMSAATI"));
				oMap.put(tableName, row, "EKRANADI",  oMap1.getBigDecimal(tableName, k, "EKRANADI"));
				oMap.put(tableName, row, "DURUM", oMap1.getString(tableName, k, "DURUM"));
				oMap.put(tableName, row, "ISLEMTUTARI", oMap1.getBigDecimal(tableName, k, "ISLEMTUTARI"));
				oMap.put(tableName, row, "DOVIZKODU", oMap1.getString(tableName, k, "DOVIZKODU"));
				oMap.put(tableName, row, "MASRAF_TAHSIL_DOVIZ",  oMap1.getString(tableName, k, "MASRAF_TAHSIL_DOVIZ"));
				oMap.put(tableName, row, "MASRAFTUTARI", oMap1.getBigDecimal(tableName, k, "MASRAFTUTARI"));
				oMap.put(tableName, row, "MUSTERINO",  oMap1.getBigDecimal(tableName, k, "MUSTERINO"));
				oMap.put(tableName, row, "MUSTERIUNVAN",  oMap1.getString(tableName, k, "MUSTERIUNVAN"));
				oMap.put(tableName, row, "TCKN", oMap1.getBigDecimal(tableName, k, "TCKN"));
				oMap.put(tableName, row, "HESAPNO",  oMap1.getBigDecimal(tableName, k, "HESAPNO"));
				oMap.put(tableName, row, "HESAPISIM", oMap1.getString(tableName, k, "HESAPISIM"));
				oMap.put(tableName, row, "ACIKLAMA", oMap1.getString(tableName, k, "ACIKLAMA"));
				oMap.put(tableName, row, "ISLEMIYAPANADSOYAD",  oMap1.getString(tableName, k, "ISLEMIYAPANADSOYAD"));
				oMap.put(tableName, row, "ISLEMIYAPANTCKNO", oMap1.getBigDecimal(tableName, k, "ISLEMIYAPANTCKNO"));
				oMap.put(tableName, row, "ISLEMITAMKULLOKASYONU", oMap1.getString(tableName, k, "ISLEMITAMKULLOKASYONU"));
				oMap.put(tableName, row, "ISLEMYAPANKULLANICIKOD", oMap1.getString(tableName, k, "ISLEMYAPANKULLANICIKOD"));
				oMap.put(tableName, row, "IPTALYAPANKULKOD", oMap1.getString(tableName, k, "IPTALYAPANKULKOD"));
				oMap.put(tableName, row, "IPTALKULLOKASYONU", oMap1.getString(tableName, k, "IPTALKULLOKASYONU"));
				oMap.put(tableName, row, "IPTALONAYKULKOD", oMap1.getString(tableName, k, "IPTALONAYKULKOD"));
				oMap.put(tableName, row, "IPTALONAYKULLOKASYONU", oMap1.getString(tableName, k, "IPTALONAYKULLOKASYONU"));            	
				oMap.put(tableName, row, "SORUNLUMU", oMap1.getString(tableName, k, "SORUNLUMU"));   
				oMap.put(tableName, row, "EUPT_EH", "H");            	
				row++;
			} 

            islem_sayi  =  oMap1.getBigDecimal("ISLEMADEDI_TL")  ;
            
            GMMap tmpMap2 = new GMMap();
            tmpMap2.put("TARIHBAS" , iMap.getDate("TARIHBAS"));
            tmpMap2.put("TARIHSON" , iMap.getDate("TARIHSON"));
            tmpMap2.put("ISLEMTIPI" , iMap.getString("ISLEMTIPI"));
            tmpMap2.put("DOVIZKODU" , iMap.getString("DOVIZKODU"));
            tmpMap2.put("PTTISLEMNO" , iMap.getString("PTTISLEMNO"));
            tmpMap2.put("DURUMKODU" , iMap.getString("DURUMKODU"));
            tmpMap2.put("EUPT_HESAPNO" , iMap.getString("EUPT_HESAPNO"));
            
            oMap2 = GMServiceExecuter.call("BNSPR_QRY2056_EUPT_IZLEME", tmpMap2);
            
            
            k=0;
            
            for  ( k = 0; k < oMap2.getSize(tableName); k++) {            

				oMap.put(tableName, row, "ISLEMNO", oMap2.getBigDecimal(tableName, k, "ISLEMNO"));
				oMap.put(tableName, row, "PTTISLEMNO", oMap2.getBigDecimal(tableName, k, "PTTISLEMNO"));
				oMap.put(tableName, row, "ISLEM_TIPI", oMap2.getString(tableName, k, "ISLEM_TIPI") );
				oMap.put(tableName, row, "ISLEMTARIHI", oMap2.getDate(tableName, k, "ISLEMTARIHI"));
				oMap.put(tableName, row, "ISLEMSAATI", oMap2.getString(tableName, k, "ISLEMSAATI"));
				oMap.put(tableName, row, "EKRANADI",  oMap2.getBigDecimal(tableName, k, "EKRANADI"));
				oMap.put(tableName, row, "DURUM", oMap2.getString(tableName, k, "DURUM"));
				oMap.put(tableName, row, "ISLEMTUTARI", oMap2.getBigDecimal(tableName, k, "ISLEMTUTARI"));
				oMap.put(tableName, row, "DOVIZKODU", oMap2.getString(tableName, k, "DOVIZKODU"));
				oMap.put(tableName, row, "MASRAF_TAHSIL_DOVIZ",  oMap2.getString(tableName, k, "MASRAF_TAHSIL_DOVIZ"));
				oMap.put(tableName, row, "MASRAFTUTARI", oMap2.getBigDecimal(tableName, k, "MASRAFTUTARI"));
				oMap.put(tableName, row, "MUSTERINO",  oMap2.getBigDecimal(tableName, k, "MUSTERINO"));
				oMap.put(tableName, row, "MUSTERIUNVAN",  oMap2.getString(tableName, k, "MUSTERIUNVAN"));
				oMap.put(tableName, row, "TCKN", oMap2.getBigDecimal(tableName, k, "TCKN"));
				oMap.put(tableName, row, "HESAPNO",  oMap2.getBigDecimal(tableName, k, "HESAPNO"));
				oMap.put(tableName, row, "HESAPISIM", oMap2.getString(tableName, k, "HESAPISIM"));
				oMap.put(tableName, row, "ACIKLAMA", oMap2.getString(tableName, k, "ACIKLAMA"));
				oMap.put(tableName, row, "ISLEMIYAPANADSOYAD",  oMap2.getString(tableName, k, "ISLEMIYAPANADSOYAD"));
				oMap.put(tableName, row, "ISLEMIYAPANTCKNO", oMap2.getBigDecimal(tableName, k, "ISLEMIYAPANTCKNO"));
				oMap.put(tableName, row, "ISLEMITAMKULLOKASYONU", oMap2.getString(tableName, k, "ISLEMITAMKULLOKASYONU"));
				oMap.put(tableName, row, "ISLEMYAPANKULLANICIKOD", oMap2.getString(tableName, k, "ISLEMYAPANKULLANICIKOD"));
				oMap.put(tableName, row, "IPTALYAPANKULKOD", oMap2.getString(tableName, k, "IPTALYAPANKULKOD"));
				oMap.put(tableName, row, "IPTALKULLOKASYONU", oMap2.getString(tableName, k, "IPTALKULLOKASYONU"));
				oMap.put(tableName, row, "IPTALONAYKULKOD", oMap2.getString(tableName, k, "IPTALONAYKULKOD"));
				oMap.put(tableName, row, "IPTALONAYKULLOKASYONU", oMap2.getString(tableName, k, "IPTALONAYKULLOKASYONU"));            	
				oMap.put(tableName, row, "SORUNLUMU", oMap2.getString(tableName, k, "SORUNLUMU"));            	
				oMap.put(tableName, row, "EUPT_EH", "E"); 
				row++;
			} 
            


            
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
	
	
	
}


