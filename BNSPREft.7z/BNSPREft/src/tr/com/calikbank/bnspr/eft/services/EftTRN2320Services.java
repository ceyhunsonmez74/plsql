package tr.com.calikbank.bnspr.eft.services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EftHabrgenlEtiketTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2320Services {
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN2320_GET_EFT_INFO")
	public static GMMap getEftInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
			
			oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("ACIKLAMA_2" , eftEftTx.getAciklama2());
	        oMap.put("ACIKLAMA_3" , eftEftTx.getAciklama3());
	        oMap.put("ACIKLAMA_4" , eftEftTx.getAciklama4());
	        oMap.put("ACIKLAMA_5" , eftEftTx.getAciklama5());
	        oMap.put("ACIKLAMA_6" , eftEftTx.getAciklama6());
	        oMap.put("TRX_NO" , eftEftTx.getTxNo());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("DURUM" , eftEftTx.getDurum());
	        oMap.put("ILGILI_ISLEM_NUMARA" , eftEftTx.getIlgiliIslemNumara());
	        oMap.put("HATA_KODU", eftEftTx.getHataKodu());
	        oMap.put("BILGI", eftEftTx.getBilgi());
	        oMap.put("ILGILI_ISLEM_REFERANSI", eftEftTx.getIlgiliIslemReferansi());
	        oMap.put("IADE_KODU", eftEftTx.getIadeKodu());
	        	        
	        oMap.put("IADE_TALEBI", false);
	        oMap.put("AYRINTI_TALEBI", false);
	        oMap.put("AYRINTI_GONDERIMI", false);

	        if(eftEftTx.getIslemTipi() != null)
	        {
	        
		        if(eftEftTx.getIslemTipi().equals("I"))
		        {
		        	oMap.put("IADE_TALEBI", true);
		        }
		        else if(eftEftTx.getIslemTipi().equals("A"))
		        {
		        	oMap.put("AYRINTI_TALEBI", true);
		        }
		        else if(eftEftTx.getIslemTipi().equals("G"))
		        {
		        	oMap.put("AYRINTI_GONDERIMI", true);
		        }
	        
	        }
	        
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
			
	        List<EftHabrgenlEtiketTx> islemTuruTablo = session.createCriteria(EftHabrgenlEtiketTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        
	        if(islemTuruTablo != null)
	        {
	        String tableName = "ISLEM_TURU_TABLO";
	        
	        int row = 0;
	        
	        for(EftHabrgenlEtiketTx birEftHabrgenlEtiketTx : islemTuruTablo)
	        {
	        	oMap.put(tableName, row, "SIRA_NO", birEftHabrgenlEtiketTx.getId().getSiraNo());
	        	oMap.put(tableName, row, "ETIKET", birEftHabrgenlEtiketTx.getEtiket());
	        	oMap.put(tableName, row, "DEGER", birEftHabrgenlEtiketTx.getDeger());
	        	row++;
	        }
	        
	        }
	        
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
