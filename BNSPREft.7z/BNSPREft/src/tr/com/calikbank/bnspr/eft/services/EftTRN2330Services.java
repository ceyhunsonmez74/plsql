package tr.com.calikbank.bnspr.eft.services;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2330Services {
@GraymoundService("BNSPR_TRN2330_GET_EFT_INFO")
public static GMMap getEftInfo(GMMap iMap) {
	try{
		Session session = DAOSession.getSession("BNSPRDal");
		EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
		GMMap oMap = new GMMap();
		oMap.put("ONCELIK", eftEftTx.getOncelik());
		oMap.put("DURUM", eftEftTx.getDurum());
		oMap.put("EFT_TARIH", eftEftTx.getEftTarih());
		oMap.put("SORGU_NO", eftEftTx.getSorguNo());
		oMap.put("GELEN_GIDEN", eftEftTx.getGelenGiden());
		oMap.put("MESAJ_KODU", eftEftTx.getMesajKodu());
		oMap.put("TUTAR", eftEftTx.getTutar());
		oMap.put("ACIKLAMA", eftEftTx.getAciklama());
		oMap.put("REFERANS_NO", eftEftTx.getReferansNo());
		oMap.put("ALAN_SUBE_KODU", eftEftTx.getAlanSubeKodu());
		oMap.put("ALAN_SEHIR_KODU", eftEftTx.getAlanSehirKodu());
		oMap.put("ALAN_BANKA_KODU", eftEftTx.getAlanBankaKodu());
		oMap.put("GONDEREN_SEHIR", eftEftTx.getGonderenSehir());
		oMap.put("GONDEREN_SUBE", eftEftTx.getGonderenSube());
		oMap.put("GONDEREN_BANKA", eftEftTx.getGonderenBanka());
		oMap.put("BOLUM_KODU", eftEftTx.getBolumKodu());
		oMap.put("ALICI_HESAP_NO", eftEftTx.getAliciHesapNo());
		oMap.put("ALICI_ADI", eftEftTx.getAliciAdi());
		oMap.put("KAS_MESAJ_KODU", eftEftTx.getKasMesajKodu());
		if("E".equals(eftEftTx.getIslemTipi()))
        	oMap.put("EFTYE_AKTAR", "true");
        else
        	oMap.put("EFTYE_AKTAR", "false");
        
        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
		
		return oMap;
	}catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	}
}
@GraymoundService("BNSPR_TRN2330_GET_MESAJ_TURLERI")
public static GMMap getAll(GMMap iMap){
    try{
        GMMap oMap = new GMMap();
        DALUtil.fillComboBox(oMap, "RESULTS", false, "select key1 kod,key1||' '||text as text from v_ml_gnl_param_text where kod = 'EFT_KAS_MESAJ_TIPLERI' and key1 in ('K02','K08','K18','K28') order by 1");
        return oMap;
    }catch (Exception e) {
        throw ExceptionHandler.convertException(e);
    }
}   

}
