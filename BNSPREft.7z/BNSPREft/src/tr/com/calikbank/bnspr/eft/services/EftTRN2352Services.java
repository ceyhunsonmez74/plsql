package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.Types;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2352Services {

		@GraymoundService("BNSPR_TRN2352_GET_INITIAL_VALUES")
		public static GMMap getInitialValues(GMMap iMap) {
			Connection conn = null;
			CallableStatement stmt = null;
			try {
				GMMap oMap = new GMMap();
				conn = DALUtil.getGMConnection();

				
				stmt = conn.prepareCall("{call PKG_TRN2315.form_instance(?,?,?,?,?,?)}");

				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.registerOutParameter(2, Types.VARCHAR);
				stmt.registerOutParameter(3, Types.VARCHAR);
				
				
				stmt.registerOutParameter(4, Types.DATE);
				stmt.registerOutParameter(5, Types.DECIMAL);
				stmt.registerOutParameter(6, Types.VARCHAR);
				stmt.execute();

				oMap.put("SUBE_KODU", stmt.getString(1));
				oMap.put("BANKA_KODU", stmt.getString(2));
				oMap.put("BANKA_ADI", stmt.getString(3));
				oMap.put("EFT_TARIH", stmt.getDate(4));
				oMap.put("TRX_NO", stmt.getBigDecimal(5));

  
				
				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}
		
		
		@GraymoundService("BNSPR_TRN2352_GET_COMBO_VALUES")
		public static GMMap getComboValues(GMMap iMap) {
			Connection conn = null;
			CallableStatement stmt = null;
			try {
				GMMap oMap = new GMMap();
				conn = DALUtil.getGMConnection();

				

				iMap.put("KOD", "EFT_IHALE_KOD");
				oMap.put("IHALE_KOD", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
				    
				iMap.put("KOD", "EFT_IHALE_TEKLIF_TUR");
				oMap.put("TEKLIF_TUR", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
				    
				   
				
				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}		
		
		@GraymoundService("BNSPR_TRN2352_GET_EFT_INFO")
		public static GMMap getEftInfo(GMMap iMap) {
			try{
				Session session = DAOSession.getSession("BNSPRDal");
				
				EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
				
				GMMap oMap = new GMMap();
		        
				oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
		        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
		        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
		        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
		        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
		        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
		        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
		        oMap.put("SENET_TUTAR" , eftEftTx.getSenetTutar());
		        oMap.put("KIYMET_KODU" , eftEftTx.getKiymetKodu());
		        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
		        oMap.put("IHALE_TUR" , eftEftTx.getIhaleTur());
		        oMap.put("IHALE_NO" , eftEftTx.getIhaleNo());
		        oMap.put("TEKLIF_TURU" , eftEftTx.getTeklifTur());
		        oMap.put("TEKLIF_FIYAT" , eftEftTx.getTeklifFiyat());
		        oMap.put("FAIZ_ORANI" , eftEftTx.getFaizOrani());
		        
		        oMap.put("TRX_NO" , eftEftTx.getTxNo());
		        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
		        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
		        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
		        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
		        oMap.put("DURUM" , eftEftTx.getDurum());	
		        oMap.put("ILGILI_ISLEM_NO", eftEftTx.getIlgiliIslemNumara());

		        
		        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
				
				return oMap;
			}catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}	

		@GraymoundService("BNSPR_TRN2352_EFT_TEKLIF_ONCEDEN_GIRILMIS_MI")
		public static GMMap eftTeklifOncedenGirilmisMi(GMMap iMap) {

			Connection conn = null;
			CallableStatement stmt = null;
			GMMap oMap = new GMMap();
			try {
				conn = DALUtil.getGMConnection();

				stmt = conn	.prepareCall("{? = call pkg_trn2352.oncedenGirilmisMi(?,?,?,?,?,?)}");
				stmt.registerOutParameter(1, java.sql.Types.NUMERIC);
				stmt.setString(2, iMap.getString("IHALE_TUR"));
				stmt.setBigDecimal(3, iMap.getBigDecimal("IHALE_NO"));
				stmt.setBigDecimal(4, iMap.getBigDecimal("FAIZ_ORAN"));
				stmt.setBigDecimal(5, iMap.getBigDecimal("TUTAR"));
				
				if ((iMap.get("EFT_TARIHI") != null)) 
					stmt.setDate(6, new Date( iMap.getDate("EFT_TARIHI").getTime()));
				else 
					stmt.setDate(6, null);
				stmt.setBigDecimal(7, iMap.getBigDecimal("TEKLIF_FIYAT"));
				
				stmt.execute();
				oMap.put("SORGU_NO", stmt.getBigDecimal(1));
				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}
		
		@GraymoundService("BNSPR_TRN2352_EFT_KUR_CHECK")
		public static GMMap eftKurCheck(GMMap iMap) {

			Connection conn = null;
			CallableStatement stmt = null;
			GMMap oMap = new GMMap();
			try {
				conn = DALUtil.getGMConnection();

				stmt = conn	.prepareCall("{? = call pkg_trn2352.kur_check(?)}");
				stmt.registerOutParameter(1, java.sql.Types.VARCHAR);
				stmt.setBigDecimal(2, iMap.getBigDecimal("KUR"));
				
				stmt.execute();
				oMap.put("CHECK_EH", stmt.getString(1));
				return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
		}

}
