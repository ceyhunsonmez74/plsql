package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftHazineOnayDTx;
import tr.com.calikbank.bnspr.dao.EftHazineOnayDTxId;
import tr.com.calikbank.bnspr.dao.EftHazineOnayMTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;
import com.lowagie.text.Table;

public class EftTRN2380Services { 
	@GraymoundService("BNSPR_TRN2380_GET_ONAYLANMIS_EFT")
	public static GMMap getOnaylanmisEft(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_trn2380.RC_Get_Onaylanmis_EFT}");
			stmt.registerOutParameter(1, -10); //ref cursor
			stmt.execute();

			/*StringBuilder query = new StringBuilder();
			query.append("select mtrn,mstype,a.tx_no,v.eft_tarih,v.tutar,decode(a.islem_tipi,'M','M��teri','K','Kasadan','D','Dk Hesap') islemTipi, a.islem_tipi islem_tipi_kod, " );
			query.append("  v.musteri_no, NVL(a.iade_hesap_numarasi,a.musteri_hesap_no) as musteri_hesap_no, v.sube,a.alan_banka_kodu,v.banka_adi,a.alan_sube_kodu,v.sube_adi,a.alici_adi,a.alici_hesap_no,  ");
			query.append(" a.alici_telefon_no,a.aciklama,a.gonderen,a.gonderen_telefon, ");
			query.append("decode(a.islem_tipi,'K',1,'M',2,3) eftsekli,a.alici_adres_1||a.alici_adres_2 lehdaradres,a.gonderen_adres,a.oncelik, ");
			query.append("pkg_hesap.IBAN(a.musteri_hesap_no) GonHesapNo,a.vergi_no,e.text1||e.text2||e.text3 text, ");
			query.append("decode(a.islem_tipi,'M',PKG_BINS_TO_WB.wb_musteri_no(NVL(a.iade_hesap_numarasi,a.musteri_hesap_no)),0) wb_musteri_no,");
			query.append("decode(a.islem_tipi,'M',PKG_BINS_TO_WB.wb_musteri_ekno(NVL(a.iade_hesap_numarasi,a.musteri_hesap_no)),0) wb_musteri_ekno,");
			query.append("decode(a.islem_tipi,'M',2,'K',1,'D',3) wb_eftsekli,");
			query.append("decode(a.islem_tipi,'M',11,'K',11,'D',99,99) wb_asube ,");
			query.append("a.eft_ref ,a.sorgu_no,a.alici_adres_1||a.alici_adres_2 as alici_adres,a.sorgu_no,pkg_bins_to_wb.wb_sube(a.bolum_kodu) as wb_bolum_kodu ");
			query.append("  from efthsrc e,v_eft_gelen_giden_izleme v,eft_eft_tx a ");
			query.append(" where rtrim(e.mtrn) = lpad(ltrim(rtrim(a.gonderen_banka)),4,'0')||lpad(ltrim(rtrim(a.gonderen_sube)),5,'0')||lpad(ltrim(rtrim(to_char(a.sorgu_no))),7,'0') ");
			query.append("   and v.tx_no = a.tx_no and status <> 'R' and v.durum='TAMAM'");
			stmt = conn.prepareCall(query.toString());*/
			
			rSet = (ResultSet)stmt.getObject(1);
			
			BigDecimal toplamTutar = new BigDecimal(0);
			String tableName = "ONAYLANMIS_EFT";
			int row = 0; 
			while (rSet.next()) {
				oMap.put(tableName, row, "MTRN", rSet.getString("mtrn"));
				oMap.put(tableName, row, "MSTYPE", rSet.getString("mstype"));
				oMap.put(tableName, row, "TRX_NO", rSet.getString("tx_no"));
				oMap.put(tableName, row, "EFT_TARIH", rSet.getDate("eft_tarih"));
				oMap.put(tableName, row, "TUTAR", rSet.getBigDecimal("tutar"));
				toplamTutar = toplamTutar.add(rSet.getBigDecimal("tutar"));
				oMap.put(tableName, row, "SORGU_NO", rSet.getBigDecimal("sorgu_no"));
				oMap.put(tableName, row, "ISLEM_TIPI", rSet.getString("islemTipi"));
				oMap.put(tableName, row, "ISLEM_TIPI_KOD", rSet.getString("islem_tipi_kod"));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getString("musteri_no"));
				oMap.put(tableName, row, "HESAP_NO", rSet.getString("musteri_hesap_no"));
				oMap.put(tableName, row, "SUBE", rSet.getString("sube"));
				
				oMap.put(tableName, row, "GONDEREN_SUBE", rSet.getString("sube"));
				oMap.put(tableName, row, "BANKA_KODU", rSet.getString("alan_banka_kodu"));
				oMap.put(tableName, row, "BANKA_ADI", rSet.getString("banka_adi"));
				oMap.put(tableName, row, "ALAN_SUBE_KODU", rSet.getString("alan_sube_kodu"));
				oMap.put(tableName, row, "ALAN_SUBE_ADI", rSet.getString("sube_adi"));
				
				oMap.put(tableName, row, "ALICI_HESAP_NO", rSet.getString("alici_hesap_no"));
				oMap.put(tableName, row, "ALICI_TELEFON_NO", rSet.getString("alici_telefon_no"));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString("aciklama"));
				oMap.put(tableName, row, "GONDEREN", rSet.getString("gonderen"));
				oMap.put(tableName, row, "GONDEREN_TELEFON", rSet.getString("gonderen_telefon"));
				oMap.put(tableName, row, "ALICI_ADI", rSet.getString("alici_adi"));
				
				oMap.put(tableName, row, "EFTSEKLI", rSet.getString("eftsekli"));
				oMap.put(tableName, row, "LEHDARADRES", rSet.getString("lehdaradres"));
				oMap.put(tableName, row, "GONDEREN_ADRES", rSet.getString("gonderen_adres"));
				oMap.put(tableName, row, "ONCELIK", rSet.getString("oncelik"));
				oMap.put(tableName, row, "GON_HESAP_NO", rSet.getString("GonHesapNo"));
				oMap.put(tableName, row, "VERGI_NO", rSet.getString("vergi_no"));
				oMap.put(tableName, row, "TEXT", rSet.getString("text"));
				
				oMap.put(tableName, row, "WB_MUSTERI_NO", rSet.getString("wb_musteri_no"));
				oMap.put(tableName, row, "WB_MUSTERI_EK_NO", rSet.getString("wb_musteri_ekno"));
				oMap.put(tableName, row, "WB_EFTSEKLI", rSet.getString("wb_eftsekli"));
				oMap.put(tableName, row, "WB_ASUBE", rSet.getInt("wb_asube"));
				oMap.put(tableName, row, "EFT_REF", rSet.getString("eft_ref"));
				oMap.put(tableName, row, "ALICI_ADRES", rSet.getString("alici_adres"));
				oMap.put(tableName, row, "ONAY_EH", "0");
				oMap.put(tableName, row, "WB_BOLUM_KODU", rSet.getInt("wb_bolum_kodu"));
				oMap.put(tableName, row, "KANAL_KODU", rSet.getString("kanal"));
				oMap.put(tableName, row, "KAS_EFT", rSet.getString("kas_eft"));
				oMap.put(tableName, row, "KAS_MESAJ_KODU", rSet.getString("kas_mesaj_kodu"));
				
				row++;
			} 
			oMap.put("KAYIT_SAYISI", row);
			oMap.put("TOPLAM_TUTAR", toplamTutar);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN2380_AKTARIM")
	public static Map<?, ?> saveOnaylanmisEft(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
	    
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call Pkg_Eft.eft_sistem_bilgi}");
			stmt.registerOutParameter(1, java.sql.Types.VARCHAR );
			stmt.execute();
			
			Session session = DAOSession.getSession("BNSPRDal");
				
				EftHazineOnayMTx hazineOnayMTx = new EftHazineOnayMTx();
				hazineOnayMTx.setDrm("G");
				hazineOnayMTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
				session.save(hazineOnayMTx);
				
				String tableName = "ONAYLANMIS_EFT";
				List<?> onaylanmisEftGuiList = (List<?>)iMap.get(tableName);
				for (int i = 0; i < onaylanmisEftGuiList.size(); i++) {
					EftHazineOnayDTx hazineOnayDTx = new EftHazineOnayDTx();
					if(!"1".equals(iMap.getString(tableName, i, "ONAY_EH"))){
						continue;
					}
					hazineOnayDTx.setOnayEh("E");
					EftHazineOnayDTxId id = new EftHazineOnayDTxId();
					id.setMtrn(iMap.getString(tableName, i, "MTRN"));
					id.setTxNo(iMap.getBigDecimal("TRX_NO"));
					hazineOnayDTx.setId(id);
					hazineOnayDTx.setEftTxNo(iMap.getBigDecimal(tableName, i, "TRX_NO"));
					hazineOnayDTx.setMstype(iMap.getString(tableName, i, "MSTYPE"));
					hazineOnayDTx.setEftTutar(iMap.getBigDecimal(tableName, i, "TUTAR"));
					hazineOnayDTx.setIslemTipi(iMap.getString(tableName, i, "ISLEM_TIPI_KOD"));
					hazineOnayDTx.setMusteriNo(iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
					hazineOnayDTx.setHesapNo(iMap.getBigDecimal(tableName, i, "HESAP_NO"));
					hazineOnayDTx.setSubeKod(iMap.getString(tableName, i, "GONDEREN_SUBE"));
					hazineOnayDTx.setAlanBankaAdi(iMap.getString(tableName, i, "BANKA_ADI"));
					hazineOnayDTx.setAlanBankaKod(iMap.getString(tableName, i, "BANKA_KODU"));
					hazineOnayDTx.setAlanBankaSube(iMap.getString(tableName, i, "ALAN_SUBE_KODU"));
					hazineOnayDTx.setAlanBankaSubeadi(iMap.getString(tableName, i, "ALAN_SUBE_ADI"));
					hazineOnayDTx.setAliciAdi(iMap.getString(tableName, i, "ALICI_ADI"));
					hazineOnayDTx.setSubeKod(iMap.getString(tableName, i, "GONDEREN_SUBE"));
					hazineOnayDTx.setKasEft(iMap.getString(tableName, i, "KAS_EFT"));
	
					session.save(hazineOnayDTx);
				}
				session.flush();
				iMap.put("TRX_NAME", "2380");
				GMMap trnMap = new GMMap(GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap));
		if(("W").equals(stmt.getObject(1))){	
			Map<?, ?> winbankResultMap = GMServiceExecuter.execute("BNSPR_TRN2380_SEND_ONAYLANMIS_EFT_TO_WINBANK", iMap);
			String winbankResult = (String)winbankResultMap.get("RESULT");
			if("FAILURE".equals(winbankResult)){
				EftServices.throwGMBusssinessException("Winbankda hata al�nd�");
				//throw new GMRuntimeException(0, "Winbankda hata al�nd�",false);
			}
		    trnMap.put("ERROR_MESSAGE", winbankResultMap.get("ERROR_MESSAGE")==null?"SUCCESS":"FAIL");
	   }
		return trnMap;
	} catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	}finally {
		GMServerDatasource.close(stmt);
		GMServerDatasource.close(conn);
	}

	}
	
	@GraymoundService("BNSPR_TRN2380_SEND_ONAYLANMIS_EFT_TO_WINBANK")
	public static Map<?, ?> sendOnaylanmisEftToWinbank(GMMap iMap) {
			Connection connSql = null;
			CallableStatement stmtSql = null;
			GMMap oMap = new GMMap();
			Connection conn = null;
			CallableStatement stmt = null;
			try {
				String tableName = "ONAYLANMIS_EFT";
				List<?> onaylanmisEftGuiList = (List<?>)iMap.get(tableName);
				conn = DALUtil.getGMConnection();
				connSql = DALUtil.getWinbankConnection();
				for (int i = 0; i < onaylanmisEftGuiList.size(); i++) {
					EftHazineOnayDTx hazineOnayDTx = new EftHazineOnayDTx();
					if(!"1".equals(iMap.getString(tableName, i, "ONAY_EH"))){
						continue;
					}
					else{
						hazineOnayDTx.setOnayEh("E");
					}

					//connSql = GMServerDatasource.getConnection("java:/WinbankDS");
					connSql.setAutoCommit(false);
					StringBuffer sb = new StringBuffer();
					sb.append("{ call dbbanking..bins_up_efteklemain (?,?,?,?,?,?,?,?,?,?,");
					sb.append("?,?,?,?,?,?,?,?,?,?,");
					sb.append("?,?,?,?,?,?,?,?,?,?,");
					sb.append("?,?,?,?,?,?,?,?,?,?) }");
					
					stmtSql = connSql.prepareCall(sb.toString());
					
					int pc = 1;
					if(iMap.getDate(tableName, i,  "EFT_TARIH") != null)  //islemtarihi
						stmtSql.setTimestamp(pc++, new java.sql.Timestamp(iMap.getDate(tableName, i,  "EFT_TARIH").getTime()));
					else
						stmtSql.setNull(pc++, Types.TIMESTAMP);
				
					stmtSql.setObject(pc++, iMap.getInt(tableName, i, "WB_BOLUM_KODU"), Types.SMALLINT); // 11 magic word at�l�yormu� //islemsube
					
					if(iMap.getString(tableName, i, "MSTYPE") != null)
						stmtSql.setString(pc++, iMap.getString(tableName, i, "MSTYPE")); //eftmesajtipi
					else
						stmtSql.setNull(pc++, Types.VARCHAR); //eftmesajtipi
					
					if(iMap.getString(tableName, i, "GONDEREN") != null)
						stmtSql.setString(pc++, iMap.getString(tableName, i, "GONDEREN")); //aadi
					else
						stmtSql.setNull(pc++, Types.VARCHAR); //aadi
					
					if(iMap.getString(tableName, i, "GONDEREN_TELEFON") != null)
						stmtSql.setString(pc++, iMap.getString(tableName, i, "GONDEREN_TELEFON")); //atel
					else
						stmtSql.setNull(pc++, Types.VARCHAR);
					
					stmtSql.setObject(pc++, iMap.getInt(tableName, i, "WB_ASUBE"), Types.TINYINT); //asube
					stmtSql.setObject(pc++, iMap.getString(tableName, i, "WB_MUSTERI_NO"), Types.INTEGER); //amusterino
					stmtSql.setObject(pc++, iMap.getInt(tableName, i, "WB_MUSTERI_EK_NO"), Types.TINYINT);//aekno
					
					if(iMap.getBigDecimal(tableName, i, "TUTAR") != null)
						stmtSql.setBigDecimal(pc++, iMap.getBigDecimal(tableName, i, "TUTAR")); //tutar
					else
						stmtSql.setNull(pc++, Types.DECIMAL);

					stmtSql.setBigDecimal(pc++, BigDecimal.ZERO); // default 0  //komisyonorani
					stmtSql.setObject(pc++, 0, Types.TINYINT); //default 0 //bsmv
					stmtSql.setBigDecimal(pc++, BigDecimal.ZERO); //default 0 //bsmvorani 
					stmtSql.setInt(pc++, 0); //default 0 //komisyonekno
					
					if(iMap.getBigDecimal(tableName, i, "BANKA_KODU") != null)
						stmtSql.setBigDecimal(pc++, iMap.getBigDecimal(tableName, i, "BANKA_KODU")); //karsibanka
					else
						stmtSql.setNull(pc++, Types.DECIMAL);
					
					if(iMap.getBigDecimal(tableName, i, "ALAN_SUBE_KODU") != null)
						stmtSql.setBigDecimal(pc++, iMap.getBigDecimal(tableName, i, "ALAN_SUBE_KODU")); //karsisube
					else
						stmtSql.setNull(pc++, Types.DECIMAL);
					
					
					if(iMap.getString(tableName, i, "ALICI_ADI") != null)
						stmtSql.setString(pc++, iMap.getString(tableName, i, "ALICI_ADI")); //ladi
					else
						stmtSql.setNull(pc++, Types.VARCHAR);
						
					if(iMap.getString(tableName, i, "ALICI_HESAP_NO") != null)
						stmtSql.setString(pc++, iMap.getString(tableName, i, "ALICI_HESAP_NO")); //lhesapno
					else
						stmtSql.setNull(pc++, Types.VARCHAR);
					
					if(iMap.getBigDecimal(tableName, i, "ALAN_SUBE_KODU") != null)
						stmtSql.setBigDecimal(pc++, iMap.getBigDecimal(tableName, i, "ALAN_SUBE_KODU")); //karsisube
					else
						stmtSql.setNull(pc++, Types.DECIMAL);
					
					if(iMap.getString(tableName, i, "ALICI_TELEFON_NO") != null)
						stmtSql.setString(pc++, iMap.getString(tableName, i, "ALICI_TELEFON_NO")); //ltel
					else
						stmtSql.setNull(pc++, Types.VARCHAR);
					
					stmtSql.setString(pc++, "Admin"); //default admin  //kullanici
					
					if(iMap.getString(tableName, i, "ACIKLAMA") != null)
						stmtSql.setString(pc++, iMap.getString(tableName, i, "ACIKLAMA")); //aciklama
					else
						stmtSql.setNull(pc++, Types.VARCHAR);
					
					stmtSql.setObject(pc++, iMap.getInt(tableName, i, "EFTSEKLI"), Types.TINYINT); //ltel
					
					stmtSql.setInt(pc++, 2); //default 2 //eftturu
					String ref = iMap.getString(tableName, i, "EFT_REF");
					stmtSql.setString(pc++, ref); //eftref
					stmtSql.setString(pc++, iMap.getString(tableName, i, "TRX_NO")); //externalRef
					stmtSql.setBigDecimal(pc++, BigDecimal.ZERO); //default 0 //komisyontutari
					String sorguNo = ref.substring(ref.length() - 8,  ref.length());
					stmtSql.setString(pc++, sorguNo); //sorguno
					
					if(iMap.getString(tableName, i, "ALICI_ADRES") != null)
						stmtSql.setString(pc++, iMap.getString("ALICI_ADRES")); //lehdaradres
					else
						stmtSql.setNull(pc++, Types.VARCHAR);
					
					if(iMap.getString(tableName, i, "GONDEREN_ADRES") != null)
						stmtSql.setString(pc++, iMap.getString("GONDEREN_ADRES")); //amiradres
					else
						stmtSql.setNull(pc++, Types.VARCHAR);
						
					stmtSql.setNull(pc++, Types.VARCHAR); //default null //lehdardigerbilgi 
					stmtSql.setNull(pc++, Types.VARCHAR); //default null //amirdigerbilgi
					stmtSql.setString(pc++, "MV"); //Eftmevtip
					stmtSql.setInt(pc++, iMap.getInt(tableName, i, "ONCELIK")); //oncelik
					stmtSql.setString(pc++, iMap.getString(tableName, i, "MTRN")); //mtrn
					
					if(iMap.getString(tableName, i, "GON_HESAP_NO") != null)
						stmtSql.setString(pc++, iMap.getString(tableName, i, "GON_HESAP_NO")); //GonHesapNo
					else
						stmtSql.setNull(pc++, Types.VARCHAR);
					
					if(iMap.getBigDecimal(tableName, i, "VERGI_NO") != null)
						stmtSql.setBigDecimal(pc++, iMap.getBigDecimal(tableName, i, "VERGI_NO")); //GonVergiKimlik
					else
						stmtSql.setNull(pc++, Types.DECIMAL);
					
					stmtSql.setString(pc++,"S"); //default null //OdemeKaynak 
					stmtSql.setNull(pc++, Types.VARCHAR); //default null //muhref
					stmtSql.setString(pc++, iMap.getString(tableName, i, "TEXT")); //default null //Text
					stmtSql.setNull(pc++, Types.VARCHAR); //default null //amirVergNo
			
				try{
					stmtSql.execute();
					
					stmtSql = connSql.prepareCall("select externalref from dbbanking..efthartl where islemtarihi = ? and externalref=? ");
					if(iMap.getDate(tableName, i,  "EFT_TARIH") != null) 
						stmtSql.setTimestamp(1, new java.sql.Timestamp(iMap.getDate(tableName, i,  "EFT_TARIH").getTime()));
					else
						stmtSql.setNull(1, Types.TIMESTAMP);
					
					stmtSql.setString(2, iMap.getString(tableName, i, "TRX_NO")); //externalRef
					if(!stmtSql.executeQuery().next())
						EftServices.throwGMBusssinessException("efthartl tablosunda " + iMap.getDate(tableName, i,  "EFT_TARIH") + " i�lem tarihli ve " + iMap.getString(tableName, i, "TRX_NO") + " externalrefli kay�t bulunamad�");
					
					connSql.commit();
					//conn = GMServerDatasource.getConnection("java:/GraymoundDS");
					stmt = conn.prepareCall("{ call PKG_EFT.Hazine_Eft_Onayla(?) }");
					stmt.setString(1, sorguNo);
					stmt.execute();
					conn.commit();
					
				} catch (Exception e) {
					oMap.put("ERROR_MESSAGE", "ERROR");
				}
			}
			oMap.put("RESULT", "SUCCESS");
		} catch (Exception e) {
			oMap.put("RESULT", "FAILURE");
			e.printStackTrace();
		}
		finally{
			GMServerDatasource.close(stmtSql);
			GMServerDatasource.close(connSql);
		}
		return oMap;
	}
	/*
	@GraymoundService("BNSPR_TRN2380_WINBANK_OK_CONFIRM")
	public static Map<?, ?> winbankOkConfirm(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "ONAYLANMIS_EFT";
			List<?> onaylanmisEftGuiList = (List<?>)iMap.get(tableName);
			for (int i = 0; i < onaylanmisEftGuiList.size(); i++) {
				if(!"1".equals(iMap.getString(tableName, i, "ONAY_EH"))){
					continue;
				}
				EftHazineOnayDTx hazineOnayDTx = (EftHazineOnayDTx)session.get(EftHazineOnayDTx.class, new EftHazineOnayDTxId(iMap.getBigDecimal("TRX_NO"), iMap.getString(tableName, i, "MTRN")));
				hazineOnayDTx.setOnayEh("E");

				hazineOnayDTx.setMstype(iMap.getString(tableName, i, "MSTYPE"));
				hazineOnayDTx.setEftTutar(iMap.getBigDecimal(tableName, i, "TUTAR"));
				hazineOnayDTx.setIslemTipi(iMap.getString(tableName, i, "ISLEM_TIPI_KOD"));
				hazineOnayDTx.setMusteriNo(iMap.getBigDecimal(tableName, i, "MUSTERI_NO"));
				hazineOnayDTx.setHesapNo(iMap.getBigDecimal(tableName, i, "HESAP_NO"));
				hazineOnayDTx.setSubeKod(iMap.getString(tableName, i, "GONDEREN_SUBE"));
				hazineOnayDTx.setAlanBankaAdi(iMap.getString(tableName, i, "BANKA_ADI"));
				hazineOnayDTx.setAlanBankaKod(iMap.getString(tableName, i, "BANKA_KODU"));
				hazineOnayDTx.setAlanBankaSube(iMap.getString(tableName, i, "ALAN_SUBE_KODU"));
				hazineOnayDTx.setAlanBankaSubeadi(iMap.getString(tableName, i, "ALAN_SUBE_ADI"));
				hazineOnayDTx.setAliciAdi(iMap.getString(tableName, i, "ALICI_ADI"));

				session.update(hazineOnayDTx);
			}
			session.flush();
			
			iMap.put("TRX_NAME", "2380");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw new GMRuntimeException(0, e);
		}
	}*/
	
	@GraymoundService("BNSPR_TRN2380_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			String tableName = "ONAYLANMIS_EFT";
			oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			List<?> eftOnayPersistenceList = session.createCriteria(EftHazineOnayDTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			BigDecimal toplamTutar = BigDecimal.ZERO;
			int i;
			for (i = 0; i < eftOnayPersistenceList.size(); i++) {
				EftHazineOnayDTx onayDTx = (EftHazineOnayDTx)eftOnayPersistenceList.get(i);

				oMap.put(tableName, i, "ONAY_EH", "1");
				oMap.put(tableName, i, "MTRN", onayDTx.getId().getMtrn());
				oMap.put(tableName, i, "MSTYPE", onayDTx.getMstype());
				oMap.put(tableName, i, "TRX_NO", onayDTx.getId().getTxNo());
				//oMap.put(tableName, i, "EFT_TARIH", onayDTx.get("eft_tarih"));
				toplamTutar = toplamTutar.add(onayDTx.getEftTutar());
				oMap.put(tableName, i, "TUTAR", onayDTx.getEftTutar());
				oMap.put(tableName, i, "ISLEM_TIPI_KOD", onayDTx.getIslemTipi());
				//oMap.put(tableName, i, "ISLEM_TIPI_KOD", rSet.getString("islem_tipi_kod"));
				oMap.put(tableName, i, "MUSTERI_NO", onayDTx.getMusteriNo());
				oMap.put(tableName, i, "HESAP_NO", onayDTx.getHesapNo());
				oMap.put(tableName, i, "GONDEREN_SUBE", onayDTx.getSubeKod());
				
				oMap.put(tableName, i, "BANKA_KODU", onayDTx.getAlanBankaKod());
				oMap.put(tableName, i, "BANKA_ADI", onayDTx.getAlanBankaAdi());
				oMap.put(tableName, i, "ALAN_SUBE_KODU", onayDTx.getAlanBankaSube());
				oMap.put(tableName, i, "ALAN_SUBE_ADI", onayDTx.getAlanBankaSubeadi());
				
				oMap.put(tableName, i, "ALICI_ADI", onayDTx.getAliciAdi());
				oMap.put(tableName, i, "ALICI_ADRES", onayDTx.getAliciAdi());
				oMap.put(tableName, i, "KAS_EFT", onayDTx.getKasEft());
				
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{? = call pkg_trn2380.Get_Kanal_Aciklama(?)}");
				stmt.registerOutParameter(1, Types.VARCHAR); //ref cursor
				stmt.setBigDecimal(2, onayDTx.getId().getTxNo());
				stmt.execute();
				
				oMap.put(tableName, i, "KANAL_KODU" ,stmt.getString(1));
				
			}
			oMap.put("TOPLAM_TUTAR", toplamTutar);
			oMap.put("TOPLAM_KAYIT", i);
			
			
			
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_TRN2380_SELECT_ALL")
	public static GMMap selectAll(GMMap iMap) {
		
		Connection conn = null;
		CallableStatement stmt = null;
		try {
				conn = DALUtil.getGMConnection();
				
				String tableName = "SELECT_ALL";
				List<?> recordList = (List<?>)iMap.get(tableName);
				String check = "0";
				if(iMap.getBoolean("CHECK")){
				check = "1";
				}
				for(int i = 0; i < recordList.size(); i++) {
					
					iMap.put(tableName,i,"ONAY_EH",check);
				}
				
				return iMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	
	}
	
	
	
	
	
	
}

