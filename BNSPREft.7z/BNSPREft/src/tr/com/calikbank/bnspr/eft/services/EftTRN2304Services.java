package tr.com.calikbank.bnspr.eft.services;

import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftGelgonGirisTx;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2304Services {
	@GraymoundService("BNSPR_TRN2304_SAVE")
	public static Map<?, ?> save(GMMap iMap) {

		try {
			Session session = DAOSession.getSession("BNSPRDal");
			EftGelgonGirisTx eftGelgonGirisTx = (EftGelgonGirisTx)session.get(EftGelgonGirisTx.class, iMap.getBigDecimal("TRX_NO"));
			if(eftGelgonGirisTx == null)eftGelgonGirisTx = new EftGelgonGirisTx();
			
			eftGelgonGirisTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			eftGelgonGirisTx.setEftUrunTur(iMap.getString("EFT_URUN_TUR"));
			eftGelgonGirisTx.setMesajTipi(iMap.getString("MESAJ_TIPI"));
			eftGelgonGirisTx.setHesapTipi(iMap.getString("HESAP_TIPI"));
			eftGelgonGirisTx.setBankaKodu(iMap.getString("BANKA_KODU"));
			eftGelgonGirisTx
					.setBankaSubeKodu(iMap.getString("BANKA_SUBE_KODU"));
			eftGelgonGirisTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			eftGelgonGirisTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			eftGelgonGirisTx.setDkNo(iMap.getString("DK_NO"));
			eftGelgonGirisTx.setTutar(iMap.getBigDecimal("TUTAR"));
			eftGelgonGirisTx.setSorguNo(iMap.getBigDecimal("SORGU_NO"));

			session.saveOrUpdate(eftGelgonGirisTx);
			session.flush();

			iMap.put("TRX_NAME", "2304");

			return GMServiceExecuter
					.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}

	@GraymoundService("BNSPR_TRN2304_GET_GELGON_EFT_BILGI")
	public static GMMap getGelgonEftBilgi(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GMMap oMap = new GMMap();
			EftGelgonGirisTx eftGelgonGirisTx = (EftGelgonGirisTx) session
					.load(EftGelgonGirisTx.class, iMap.getBigDecimal("TRX_NO"));

			oMap.put("TRX_NO", eftGelgonGirisTx.getTxNo());
			oMap.put("EFT_URUN_TUR", eftGelgonGirisTx.getEftUrunTur());
			oMap.put("MESAJ_TIPI", eftGelgonGirisTx.getMesajTipi());
			oMap.put("HESAP_TIPI", eftGelgonGirisTx.getHesapTipi());
			oMap.put("SORGU_NO", eftGelgonGirisTx.getSorguNo());
			oMap.put("BANKA_KODU", eftGelgonGirisTx.getBankaKodu());
			oMap.put("BANKA_ADI", LovHelper.diLov(eftGelgonGirisTx.getBankaKodu(), "2304/LOV_BANKA", "BANKA_ADI"));
			oMap.put("BANKA_SUBE_KODU", eftGelgonGirisTx.getBankaSubeKodu());
			oMap.put("BANKA_SUBE_ADI", LovHelper.diLov(eftGelgonGirisTx.getBankaSubeKodu(),eftGelgonGirisTx.getBankaSubeKodu(), "2304/LOV_SUBE_KODLARI", "SUBE_ADI"));
			oMap.put("MUSTERI_NO", eftGelgonGirisTx.getMusteriNo());
			oMap.put("MUSTERI_ADI", LovHelper.diLov(eftGelgonGirisTx.getMusteriNo(), "2304/LOV_MUSTERI_NO", "ISIM_UNVAN"));
			oMap.put("HESAP_NO", eftGelgonGirisTx.getHesapNo());
			oMap.put("DK_NO", eftGelgonGirisTx.getDkNo());
			oMap.put("TUTAR", eftGelgonGirisTx.getTutar());

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
