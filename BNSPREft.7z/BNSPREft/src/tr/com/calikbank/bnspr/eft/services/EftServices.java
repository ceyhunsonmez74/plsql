package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EftHabrgenlEtiketTx;
import tr.com.aktifbank.bnspr.dao.EftHabrgenlEtiketTxId;
import tr.com.aktifbank.bnspr.dao.EftNysDetayTx;
import tr.com.aktifbank.bnspr.dao.EftNysDetayTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftDetayTx;
import tr.com.calikbank.bnspr.dao.EftEftDetayTxId;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftServices {
	@GraymoundService("BNSPR_EFT_SAVE")
	public static Map<?, ?> eftSave(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			EftEftTx eftEftTx = (EftEftTx) session.get(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			if (eftEftTx == null)
				eftEftTx = new EftEftTx();

 			eftEftTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			eftEftTx.setDborAlacakliHesap(iMap.getString("DBOR_ALACAKLI_HESAP", eftEftTx.getDborAlacakliHesap()));
			eftEftTx.setDborBorclu(iMap.getString("DBOR_BORCLU", eftEftTx.getDborBorclu()));
			eftEftTx.setDborBorcluVno(iMap.getString("DBOR_BORCLU_VNO", eftEftTx.getDborBorcluVno()));
			eftEftTx.setDborAlacakli(iMap.getString("DBOR_ALACAKLI", eftEftTx.getDborAlacakli()));
			eftEftTx.setOdemeDogruOto(iMap.getString("ODEME_DOGRU_OTO", eftEftTx.getOdemeDogruOto()));
			eftEftTx.setOdemeOnayOto(iMap.getString("ODEME_ONAY_OTO", eftEftTx.getOdemeOnayOto()));
			eftEftTx.setOdemeOtomatik(iMap.getString("ODEME_OTOMATIK", eftEftTx.getOdemeOtomatik()));
			eftEftTx.setOdemeDkHesap(iMap.getString("ODEME_DK_HESAP", eftEftTx.getOdemeDkHesap()));
			eftEftTx.setOdemeMusteriHesap(iMap.getBigDecimal("ODEME_MUSTERI_HESAP", eftEftTx.getOdemeMusteriHesap()));
			eftEftTx.setOdemeMusteriNo(iMap.getBigDecimal("ODEME_MUSTERI_NO", eftEftTx.getOdemeMusteriNo()));
			eftEftTx.setOdemeSube(iMap.getString("ODEME_SUBE", eftEftTx.getOdemeSube()));
			eftEftTx.setHataKodu(iMap.getString("HATA_KODU", eftEftTx.getHataKodu()));
			eftEftTx.setBolumKodu(iMap.getString("BOLUM_KODU", eftEftTx.getBolumKodu()));
			eftEftTx.setAlanSubeKodu2(iMap.getBigDecimal("ALAN_SUBE_KODU2", eftEftTx.getAlanSubeKodu2()));
			eftEftTx.setGirisDepoKodu(iMap.getString("GIRIS_DEPO_KODU", eftEftTx.getGirisDepoKodu()));
			eftEftTx.setCikisDepoKodu(iMap.getString("CIKIS_DEPO_KODU", eftEftTx.getCikisDepoKodu()));
			eftEftTx.setTeslimSekli(iMap.getString("TESLIM_SEKLI", eftEftTx.getTeslimSekli()));
			eftEftTx.setTeklifTur(iMap.getBigDecimal("TEKLIF_TUR", eftEftTx.getTeklifTur()));
			eftEftTx.setTeklifFiyat(iMap.getBigDecimal("TEKLIF_FIYAT", eftEftTx.getTeklifFiyat()));
			eftEftTx.setAciklama6(iMap.getString("ACIKLAMA_6", eftEftTx.getAciklama6()));
			eftEftTx.setAciklama5(iMap.getString("ACIKLAMA_5", eftEftTx.getAciklama5()));
			eftEftTx.setAciklama4(iMap.getString("ACIKLAMA_4", eftEftTx.getAciklama4()));
			eftEftTx.setAciklama3(iMap.getString("ACIKLAMA_3", eftEftTx.getAciklama3()));
			eftEftTx.setSenetTutar(iMap.getBigDecimal("SENET_TUTAR", eftEftTx.getSenetTutar()));
			eftEftTx.setKimKurum(iMap.getBigDecimal("KIM_KURUM", eftEftTx.getKimKurum()));
			eftEftTx.setVergiNo(iMap.getString("VERGI_NO", eftEftTx.getVergiNo()));
			eftEftTx.setKimTur(iMap.getString("KIM_TUR", eftEftTx.getKimTur()));
			eftEftTx.setIhaleTur(iMap.getString("IHALE_TUR", eftEftTx.getIhaleTur()));
			eftEftTx.setIhaleNo(iMap.getBigDecimal("IHALE_NO", eftEftTx.getIhaleNo()));
			eftEftTx.setTeslimSube(iMap.getString("TESLIM_SUBE", eftEftTx.getTeslimSube()));
			eftEftTx.setOdemeTuru(iMap.getString("ODEME_TURU", eftEftTx.getOdemeTuru()));
			eftEftTx.setMiktar(iMap.getBigDecimal("MIKTAR", eftEftTx.getMiktar()));
			eftEftTx.setKiymetKodu(iMap.getString("KIYMET_KODU", eftEftTx.getKiymetKodu()));
			eftEftTx.setIhaleTarih(iMap.getDate("IHALE_TARIH", eftEftTx.getIhaleTarih()));
			eftEftTx.setGecikmeCeza(iMap.getBigDecimal("GECIKME_CEZA", eftEftTx.getGecikmeCeza()));
			eftEftTx.setHaberlesmeMasraf(iMap.getBigDecimal("HABERLESME_MASRAF", eftEftTx.getHaberlesmeMasraf()));
			eftEftTx.setProtestoMasraf(iMap.getBigDecimal("PROTESTO_MASRAF", eftEftTx.getProtestoMasraf()));
			eftEftTx.setBorcluAdi(iMap.getString("BORCLU_ADI", eftEftTx.getBorcluAdi()));
			eftEftTx.setMuhBankaSenetNo(iMap.getBigDecimal("MUH_BANKA_SENET_NO", eftEftTx.getMuhBankaSenetNo()));
			eftEftTx.setAmirBankaSenetNo(iMap.getBigDecimal("AMIR_BANKA_SENET_NO", eftEftTx.getAmirBankaSenetNo()));
			eftEftTx.setSsdfBsmv(iMap.getBigDecimal("SSDF_BSMV", eftEftTx.getSsdfBsmv()));
			eftEftTx.setVergi(iMap.getBigDecimal("VERGI", eftEftTx.getVergi()));
			eftEftTx.setMasraf(iMap.getBigDecimal("MASRAF", eftEftTx.getMasraf()));
			eftEftTx.setKomisyon(iMap.getBigDecimal("KOMISYON", eftEftTx.getKomisyon()));
			eftEftTx.setBitisValor(iMap.getDate("BITIS_VALOR", eftEftTx.getBitisValor()));
			eftEftTx.setBaslangicValor(iMap.getDate("BASLANGIC_VALOR", eftEftTx.getBaslangicValor()));
			eftEftTx.setAnapara(iMap.getBigDecimal("ANAPARA", eftEftTx.getAnapara()));
			eftEftTx.setFaizTutari(iMap.getBigDecimal("FAIZ_TUTARI", eftEftTx.getFaizTutari()));
			eftEftTx.setFaizOrani(iMap.getBigDecimal("FAIZ_ORANI", eftEftTx.getFaizOrani()));
			eftEftTx.setReferansNo(iMap.getString("REFERANS_NO", eftEftTx.getReferansNo()));
			eftEftTx.setIslemTuru(iMap.getString("ISLEM_TURU", eftEftTx.getIslemTuru()));
			eftEftTx.setKartEkKod(iMap.getString("KART_EK_KOD", eftEftTx.getKartEkKod()));
			eftEftTx.setKartNo(iMap.getString("KART_NO", eftEftTx.getKartNo()));
			eftEftTx.setAciklama2(iMap.getString("ACIKLAMA_2", eftEftTx.getAciklama2()));
			eftEftTx.setAliciHesapNo(iMap.getString("ALICI_HESAP_NO", eftEftTx.getAliciHesapNo()));
			eftEftTx.setMasrafToplam(iMap.getBigDecimal("MASRAF_TOPLAM", eftEftTx.getMasrafToplam()));
			eftEftTx.setDurum(iMap.getString("DURUM", eftEftTx.getDurum()));
			eftEftTx.setAciklama(iMap.getString("ACIKLAMA", eftEftTx.getAciklama()));
			eftEftTx.setGonderenAdres(iMap.getString("GONDEREN_ADRES", eftEftTx.getGonderenAdres()));
			eftEftTx.setGonderenTelefon(iMap.getString("GONDEREN_TELEFON", eftEftTx.getGonderenTelefon()));
			eftEftTx.setGonderen(iMap.getString("GONDEREN", eftEftTx.getGonderen()));
			eftEftTx.setKulBakiye(iMap.getBigDecimal("KUL_BAKIYE", eftEftTx.getKulBakiye()));
			eftEftTx.setDkHesapNo(iMap.getString("DK_HESAP_NO", eftEftTx.getDkHesapNo()));
			eftEftTx.setMusteriHesapNo(iMap.getBigDecimal("MUSTERI_HESAP_NO", eftEftTx.getMusteriHesapNo()));
			eftEftTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO", eftEftTx.getMusteriNo()));
			eftEftTx.setAliciBabaAdi(iMap.getString("ALICI_BABA_ADI", eftEftTx.getAliciBabaAdi()));
			eftEftTx.setAliciAdres2(iMap.getString("ALICI_ADRES_2", eftEftTx.getAliciAdres2()));
			eftEftTx.setAliciAdres1(iMap.getString("ALICI_ADRES_1", eftEftTx.getAliciAdres1()));
			eftEftTx.setAliciTelefonNo(iMap.getString("ALICI_TELEFON_NO", eftEftTx.getAliciTelefonNo()));
			eftEftTx.setAliciAdi(iMap.getString("ALICI_ADI", eftEftTx.getAliciAdi()));
			eftEftTx.setSonMesajBelirtec(iMap.getString("SON_MESAJ_BELIRTEC", eftEftTx.getSonMesajBelirtec()));
			eftEftTx.setParcaNumarasi(iMap.getString("PARCA_NUMARASI", eftEftTx.getParcaNumarasi()));
			eftEftTx.setObekTuru(iMap.getString("OBEK_TURU", eftEftTx.getObekTuru()));
			eftEftTx.setAlindiGosterge(iMap.getString("ALINDI_GOSTERGE", eftEftTx.getAlindiGosterge()));
			eftEftTx.setSistemKodu(iMap.getString("SISTEM_KODU", eftEftTx.getSistemKodu()));
			eftEftTx.setGirisSaat(iMap.getString("GIRIS_SAAT", eftEftTx.getGirisSaat()));
			eftEftTx.setIslemSaat(iMap.getString("ISLEM_SAAT", eftEftTx.getIslemSaat()));
			eftEftTx.setSiraNumarasi(iMap.getString("SIRA_NUMARASI", eftEftTx.getSiraNumarasi()));
			eftEftTx.setSorguNo(iMap.getBigDecimal("SORGU_NO", eftEftTx.getSorguNo()));
			eftEftTx.setTutar(iMap.getBigDecimal("TUTAR", eftEftTx.getTutar()));
			eftEftTx.setOncelik(iMap.getBigDecimal("ONCELIK", eftEftTx.getOncelik()));
			eftEftTx.setGonderenSehir(iMap.getString("GONDEREN_SEHIR", eftEftTx.getGonderenSehir()));
			eftEftTx.setGonderenSube(iMap.getString("GONDEREN_SUBE", eftEftTx.getGonderenSube()));
			eftEftTx.setGonderenBanka(iMap.getString("GONDEREN_BANKA", eftEftTx.getGonderenBanka()));
			eftEftTx.setAlanSehirKodu(iMap.getString("ALAN_SEHIR_KODU", eftEftTx.getAlanSehirKodu()));
			eftEftTx.setAlanSubeKodu(iMap.getString("ALAN_SUBE_KODU", eftEftTx.getAlanSubeKodu()));
			eftEftTx.setAlanBankaKodu(iMap.getString("ALAN_BANKA_KODU", eftEftTx.getAlanBankaKodu()));
			eftEftTx.setEftTarih(iMap.getDate("EFT_TARIH", eftEftTx.getEftTarih()));
			eftEftTx.setMesajKodu(iMap.getString("MESAJ_KODU", eftEftTx.getMesajKodu()));
			eftEftTx.setGelenGiden(iMap.getString("GELEN_GIDEN", eftEftTx.getGelenGiden()));
			eftEftTx.setGeriOdenecekTutar(iMap.getBigDecimal("GERI_ODENECEK_TUTAR", eftEftTx.getGeriOdenecekTutar()));
			eftEftTx.setGeriDonusFiyati(iMap.getBigDecimal("GERI_DONUS_FIYATI", eftEftTx.getGeriDonusFiyati()));
			eftEftTx.setGeriDonusValoru(iMap.getDate("GERI_DONUS_VALORU", eftEftTx.getGeriDonusValoru()));
			eftEftTx.setFiyat(iMap.getBigDecimal("FIYAT", eftEftTx.getFiyat()));
			eftEftTx.setIslemValor(iMap.getDate("ISLEM_VALOR", eftEftTx.getIslemValor()));
			eftEftTx.setTcmbMuhabirBankaAdi(iMap.getString("TCMB_MUHABIR_BANKA_ADI", eftEftTx.getTcmbMuhabirBankaAdi()));
			eftEftTx.setTcmbMuhabirHesapNo(iMap.getString("TCMB_MUHABIR_HESAP_NO", eftEftTx.getTcmbMuhabirHesapNo()));
			eftEftTx.setDonem(iMap.getString("DONEM", eftEftTx.getDonem()));
			eftEftTx.setVade(iMap.getDate("VADE", eftEftTx.getVade()));
			eftEftTx.setMuhabirBankaAdi(iMap.getString("MUHABIR_BANKA_ADI", eftEftTx.getMuhabirBankaAdi()));
			eftEftTx.setMuhabirHesapNo(iMap.getString("MUHABIR_HESAP_NO", eftEftTx.getMuhabirHesapNo()));
			eftEftTx.setDovizKuru(iMap.getBigDecimal("DOVIZ_KURU", eftEftTx.getDovizKuru()));
			eftEftTx.setValor(iMap.getDate("VALOR", eftEftTx.getValor()));
			eftEftTx.setDovizTutari(iMap.getBigDecimal("DOVIZ_TUTARI", eftEftTx.getDovizTutari()));
			eftEftTx.setDovizKodu(iMap.getString("DOVIZ_KODU", eftEftTx.getDovizKodu()));
			eftEftTx.setIptalTuru(iMap.getString("IPTAL_TURU", eftEftTx.getIptalTuru()));
			eftEftTx.setIptalEdilenMiktar(iMap.getBigDecimal("IPTAL_EDILEN_MIKTAR", eftEftTx.getIptalEdilenMiktar()));
			eftEftTx.setDonusTutari(iMap.getBigDecimal("DONUS_TUTARI", eftEftTx.getDonusTutari()));
			eftEftTx.setDonusTarihi(iMap.getDate("DONUS_TARIHI", eftEftTx.getDonusTarihi()));
			eftEftTx.setGirenMiktar(iMap.getBigDecimal("GIREN_MIKTAR", eftEftTx.getGirenMiktar()));
			eftEftTx.setKalanTutar(iMap.getBigDecimal("KALAN_TUTAR", eftEftTx.getKalanTutar()));
			eftEftTx.setKalanMiktar(iMap.getBigDecimal("KALAN_MIKTAR", eftEftTx.getKalanMiktar()));
			eftEftTx.setSatisIslemNo(iMap.getBigDecimal("SATIS_ISLEM_NO", eftEftTx.getSatisIslemNo()));
			eftEftTx.setCikanMiktar(iMap.getBigDecimal("CIKAN_MIKTAR", eftEftTx.getCikanMiktar()));
			eftEftTx.setAlicininAdiSoyadi(iMap.getString("ALICININ_ADI_SOYADI", eftEftTx.getAlicininAdiSoyadi()));
			eftEftTx.setParcaTeslIzinGosterge(iMap.getString("PARCA_TESL_IZIN_GOSTERGE", eftEftTx.getParcaTeslIzinGosterge()));
			eftEftTx.setKullaniciReferansi(iMap.getString("KULLANICI_REFERANSI", eftEftTx.getKullaniciReferansi()));
			eftEftTx.setSubeAdi(iMap.getString("SUBE_ADI", eftEftTx.getSubeAdi()));
			eftEftTx.setSubeSehirKodu(iMap.getString("SUBE_SEHIR_KODU", eftEftTx.getSubeSehirKodu()));
			eftEftTx.setSubeKodu(iMap.getString("SUBE_KODU", eftEftTx.getSubeKodu()));
			eftEftTx.setDuzeltmeTuru(iMap.getString("DUZELTME_TURU", eftEftTx.getDuzeltmeTuru()));
			eftEftTx.setAdresSatiriAciklama3(iMap.getString("ADRES_SATIRI_ACIKLAMA_3", eftEftTx.getAdresSatiriAciklama3()));
			eftEftTx.setAdresSatiriAciklama2(iMap.getString("ADRES_SATIRI_ACIKLAMA_2", eftEftTx.getAdresSatiriAciklama2()));
			eftEftTx.setAdresSatiriAciklama1(iMap.getString("ADRES_SATIRI_ACIKLAMA_1", eftEftTx.getAdresSatiriAciklama1()));
			eftEftTx.setSehirAdi(iMap.getString("SEHIR_ADI") == null ? eftEftTx.getSehirAdi() : iMap.getString("SEHIR_ADI"));
			eftEftTx.setKullanilabilirlikGostergesi(iMap.getString("KULLANILABILIRLIK_GOSTERGESI", eftEftTx.getKullanilabilirlikGostergesi()));
			eftEftTx.setBankaAdi(iMap.getString("BANKA_ADI", eftEftTx.getBankaAdi()));
			eftEftTx.setBankaKodu(iMap.getString("BANKA_KODU", eftEftTx.getBankaKodu()));
			eftEftTx.setAlicininDogumTarihi(iMap.getDate("ALICININ_DOGUM_TARIHI", eftEftTx.getAlicininDogumTarihi()));
			eftEftTx.setTalimatFormuUretilecek(iMap.getString("TALIMAT_FORMU_URETILECEK", eftEftTx.getTalimatFormuUretilecek()));
			eftEftTx.setOtomatikBildirimOlustur(iMap.getString("OTOMATIK_BILDIRIM_OLUSTUR", eftEftTx.getOtomatikBildirimOlustur()));
			eftEftTx.setGonderenHesapNumarasi(iMap.getString("GONDEREN_HESAP_NUMARASI", eftEftTx.getGonderenHesapNumarasi()));
			eftEftTx.setAktrAliciAdSoyad(iMap.getString("AKTR_ALICI_AD_SOYAD", eftEftTx.getAktrAliciAdSoyad()));
			eftEftTx.setIadeVergiKimlikNumara(iMap.getString("IADE_VERGI_KIMLIK_NUMARA", eftEftTx.getIadeVergiKimlikNumara()));
			eftEftTx.setIlgiliIslemTarih(iMap.getDate("ILGILI_ISLEM_TARIH", eftEftTx.getIlgiliIslemTarih()));
			eftEftTx.setIadeHesapNumarasi(iMap.getString("IADE_HESAP_NUMARASI", eftEftTx.getIadeHesapNumarasi()));
			eftEftTx.setIadeEden(iMap.getString("IADE_EDEN", eftEftTx.getIadeEden()));
			eftEftTx.setIlgiliIslemNumara(iMap.getBigDecimal("ILGILI_ISLEM_NUMARA", eftEftTx.getIlgiliIslemNumara()));
			eftEftTx.setIadeKodu(iMap.getString("IADE_KODU", eftEftTx.getIadeKodu()));
			eftEftTx.setOdemeKaynak(iMap.getString("ODEME_KAYNAK", eftEftTx.getOdemeKaynak()));
			eftEftTx.setGonderenVergiKimlikNumarasi(iMap.getString("GONDEREN_VERGI_KIMLIK_NUMARASI", eftEftTx.getGonderenVergiKimlikNumarasi()));
			eftEftTx.setAlisBedeli(iMap.getBigDecimal("ALIS_BEDELI", eftEftTx.getAlisBedeli()));
			eftEftTx.setAlisTarihi(iMap.getDate("ALIS_TARIHI", eftEftTx.getAlisTarihi()));
			eftEftTx.setBildirimNo(iMap.getBigDecimal("BILDIRIM_NO", eftEftTx.getBildirimNo()));
			eftEftTx.setHesapTuru(iMap.getString("HESAP_TURU", eftEftTx.getHesapTuru()));
			eftEftTx.setDborBankaKodu(iMap.getString("DBOR_BANKA_KODU", eftEftTx.getDborBankaKodu())); 
			eftEftTx.setDborRedKodu(iMap.getString("DBOR_RED_KODU", eftEftTx.getDborRedKodu()));
			eftEftTx.setDborRedAciklama(iMap.getString("DBOR_RED_ACIKLAMA", eftEftTx.getDborRedAciklama()));
			eftEftTx.setDborKabulRed(iMap.getString("DBOR_KABUL_RED", eftEftTx.getDborKabulRed()));
			eftEftTx.setEftIslemNumara(iMap.getString("EFT_ISLEM_NUMARA", eftEftTx.getEftIslemNumara()));
			eftEftTx.setDborReferans(iMap.getString("DBOR_REFERANS", eftEftTx.getDborReferans()));
			eftEftTx.setDborBorcluHesap(iMap.getString("DBOR_BORCLU_HESAP", eftEftTx.getDborBorcluHesap()));
			eftEftTx.setIslemTipi(iMap.getString("EKRAN_NO").equals("2319") || iMap.getString("EKRAN_NO").equals("2320") ? getComboBoxValue(iMap) : iMap.getString("ISLEM_TIPI", eftEftTx.getIslemTipi()));
			eftEftTx.setAliciIban(iMap.getString("ALICI_IBAN", eftEftTx.getAliciIban()));
			eftEftTx.setKasaKimlikTipi(iMap.getBigDecimal("KIMLIK_TIPI", eftEftTx.getKasaKimlikTipi()));
			eftEftTx.setRumuz(iMap.getString("RUMUZ", eftEftTx.getRumuz()));
			eftEftTx.setTutarScr(iMap.getBigDecimal("TUTAR_SCR", eftEftTx.getTutarScr()));
			eftEftTx.setMasrafIcDis(iMap.getString("MASRAF_IC_DIS", eftEftTx.getMasrafIcDis()));
			eftEftTx.setIlgiliIslemReferansi(iMap.getString("ILGILI_ISLEM_REFERANSI", eftEftTx.getIlgiliIslemReferansi()));
			eftEftTx.setMasrafTahsilSekli(iMap.getString("MASRAF_TAHSIL_SEKLI", eftEftTx.getMasrafTahsilSekli()));
			eftEftTx.setMasrafHesapNo(iMap.getBigDecimal("MASRAF_HESAP_NO", eftEftTx.getMasrafHesapNo()));
			eftEftTx.setAliciAnneAdi(iMap.getString("ALICI_ANNE_ADI", eftEftTx.getAliciAnneAdi()));
			eftEftTx.setOdemeTxNo(iMap.getBigDecimal("ODEME_TX_NO", eftEftTx.getOdemeTxNo()));
			eftEftTx.setEftRumuzId(iMap.getBigDecimal("EFT_RUMUZ_ID", eftEftTx.getEftRumuzId()));
			eftEftTx.setEftRef(iMap.getString("EFT_REF", eftEftTx.getEftRef()));
			eftEftTx.setFraudKontrol(iMap.getString("FRAUD_KONTROL", eftEftTx.getFraudKontrol()));
			eftEftTx.setAliciTcKimlikno(iMap.getString("ALICI_TC_KIMLIKNO", eftEftTx.getAliciTcKimlikno()));
			eftEftTx.setAliciHesBulunKurum(iMap.getString("ALICI_HES_BULUN_KURUM", eftEftTx.getAliciHesBulunKurum()));
			eftEftTx.setAliciHesBulunKurumHesapNo(iMap.getString("ALICI_HES_BULUN_KURUM_HESAP_NO", eftEftTx.getAliciHesBulunKurumHesapNo()));
			eftEftTx.setNihaiAlici(iMap.getString("NIHAI_ALICI", eftEftTx.getNihaiAlici()));
			eftEftTx.setNihaiAliciHesapNo(iMap.getString("NIHAI_ALICI_HESAP_NO", eftEftTx.getNihaiAliciHesapNo()));
			eftEftTx.setAmirKurumVkno(iMap.getString("AMIR_KURUM_VKNO", eftEftTx.getAmirKurumVkno()));
			eftEftTx.setAmirKurum(iMap.getString("AMIR_KURUM", eftEftTx.getAmirKurum()));
			eftEftTx.setAmirKurumHesapNo(iMap.getString("AMIR_KURUM_HESAP_NO", eftEftTx.getAmirKurumHesapNo()));
			eftEftTx.setAmir(iMap.getString("AMIR", eftEftTx.getAmir()));
			eftEftTx.setFIbanBilinmiyor(iMap.getString("FIBAN_BILINMIYOR", eftEftTx.getFIbanBilinmiyor()));
			eftEftTx.setOdemeAyrintisi(iMap.getString("ODEME_AYRINTISI", eftEftTx.getOdemeAyrintisi()));
			eftEftTx.setGirisZaman(iMap.getString("GIRIS_ZAMAN", eftEftTx.getGirisZaman()));
			eftEftTx.setIslemZaman(iMap.getString("ISLEM_ZAMAN", eftEftTx.getIslemZaman()));
			eftEftTx.setKasEft(iMap.getString("KAS_EFT", eftEftTx.getKasEft()));
			eftEftTx.setGonderenPasaportNo(iMap.getString("GONDEREN_PASAPORT_NO", eftEftTx.getGonderenPasaportNo()));
			eftEftTx.setGonderenDogumYeri(iMap.getString("GONDEREN_DOGUM_YERI", eftEftTx.getGonderenDogumYeri()));
			eftEftTx.setGonderenDogumTarihi(iMap.getDate("GONDEREN_DOGUM_TARIHI", eftEftTx.getGonderenDogumTarihi()));
			eftEftTx.setGonderenMusteriNumarasi(iMap.getString("GONDEREN_MUSTERI_NUMARASI", eftEftTx.getGonderenMusteriNumarasi()));
			eftEftTx.setKasMesajKodu(iMap.getString("KAS_MESAJ_KODU", eftEftTx.getKasMesajKodu()));
			eftEftTx.setBilgi(iMap.getString("BILGI", eftEftTx.getBilgi()));
			eftEftTx.setGondericidenAliciyaBilgi(iMap.getString("GONDERICIDEN_ALICIYA_BILGI", eftEftTx.getGondericidenAliciyaBilgi()));
			eftEftTx.setAmirHesapNo(iMap.getString("AMIR_HESAP_NO", eftEftTx.getAmirHesapNo()));
			eftEftTx.setAraciKurum(iMap.getString("ARACI_KURUM", eftEftTx.getAraciKurum()));
			eftEftTx.setNihaiAliciKurum(iMap.getString("NIHAI_ALICI_KURUM", eftEftTx.getNihaiAliciKurum()));
			eftEftTx.setNihaiAliciKurumHesapNo(iMap.getString("NIHAI_ALICI_KURUM_HESAP_NO", eftEftTx.getNihaiAliciKurumHesapNo()));
			eftEftTx.setMasrafDetayi(iMap.getString("MASRAF_DETAYI", eftEftTx.getMasrafDetayi()));
			eftEftTx.setMkkAliciReferansi(iMap.getString("MKK_ALICI_REFERANSI", eftEftTx.getMkkAliciReferansi()));
			eftEftTx.setMkkParcaNumarasi(iMap.getBigDecimal("MKK_PARCA_NUMARASI", eftEftTx.getMkkParcaNumarasi()));
			eftEftTx.setMkkSaticiReferansi(iMap.getString("MKK_SATICI_REFERANSI", eftEftTx.getMkkSaticiReferansi()));
			eftEftTx.setMkkSozlesmeNumarasi(iMap.getString("MKK_SOZLESME_NUMARASI", eftEftTx.getMkkSozlesmeNumarasi()));
			eftEftTx.setMkkUyeKodu(iMap.getString("MKK_UYE_KODU", eftEftTx.getMkkUyeKodu()));
			eftEftTx.setSatisTuru(iMap.getString("SATIS_TURU", eftEftTx.getSatisTuru()));
            eftEftTx.setMesajGrubu(iMap.getString("MESAJ_GRUBU", eftEftTx.getMesajGrubu()));
			eftEftTx.setBildirimTuru(iMap.getString("BILDIRIM_TURU", eftEftTx.getBildirimTuru()));
			eftEftTx.setAraciKurumHesapNo(iMap.getString("ARACI_KURUM_HESAP_NO", eftEftTx.getAraciKurumHesapNo()));
            eftEftTx.setFSwiftGonderildimi(iMap.getString("F_SWIFT_GONDERILDIMI", eftEftTx.getFSwiftGonderildimi()));
            eftEftTx.setIlgiliIslemReferansi(iMap.getString("ILGILI_ISLEM_REFERANSI", eftEftTx.getIlgiliIslemReferansi()));
            eftEftTx.setOnBildirimReferansi(iMap.getString("ON_BILDIRIM_REFERANSI", eftEftTx.getOnBildirimReferansi()));
            eftEftTx.setOnBildirimTuru(iMap.getString("ON_BILDIRIM_TURU", eftEftTx.getOnBildirimTuru()));
            
          
            eftEftTx.setIslEkMusteriAdi(iMap.getString("ISL_EK_MUSTERI_ADI", eftEftTx.getIslEkMusteriAdi()));
            eftEftTx.setIslEkMusteriHesap(iMap.getString("ISL_EK_MUSTERI_HESAP", eftEftTx.getIslEkMusteriHesap()));
            eftEftTx.setIslEkMusteriKimlik(iMap.getString("ISL_EK_MUSTERI_KIMLIK", eftEftTx.getIslEkMusteriKimlik()));
            eftEftTx.setAmirUlkeSehir(iMap.getString("AMIR_ULKE_SEHIR", eftEftTx.getAmirUlkeSehir()));
            eftEftTx.setAmirKimlikNo(iMap.getString("AMIR_KIMLIK_NO", eftEftTx.getAmirKimlikNo()));
            eftEftTx.setNihaiAliciAdresi(iMap.getString("NIHAI_ALICI_ADRESI", eftEftTx.getNihaiAliciAdresi()));
            eftEftTx.setNihaiAliciUlkeSehir(iMap.getString("NIHAI_ALICI_ULKE_SEHIR", eftEftTx.getNihaiAliciUlkeSehir()));
            eftEftTx.setAmirBilgiSecim(iMap.getString("AMIR_BILGI_SECIM", eftEftTx.getAmirBilgiSecim()));
            eftEftTx.setNihaiAliciBilgiSecim(iMap.getString("NIHAI_ALICI_BILGI_SECIM", eftEftTx.getNihaiAliciBilgiSecim()));
            
            eftEftTx.setIpNo(iMap.getString("IP_NO",eftEftTx.getIpNo()));
            eftEftTx.setFraudNedeni(iMap.getString("FRAUD_NEDENI",eftEftTx.getFraudNedeni()));
            eftEftTx.setIslemKaynak(iMap.getString("ISLEM_KAYNAK",eftEftTx.getIslemKaynak()));

            eftEftTx.setKolasReferansi(iMap.getString("KOLAS_REFERANSI",eftEftTx.getKolasReferansi()));
            eftEftTx.setKolayAdresTipi(iMap.getString("KOLAY_ADRES_TIPI", eftEftTx.getKolayAdresTipi()));
            eftEftTx.setKolayAdresDegeri(iMap.getString("KOLAY_ADRES_DEGERI", eftEftTx.getKolayAdresDegeri()));

            eftEftTx.setFastMesajTarihi(iMap.getDate("FAST_TARIH", eftEftTx.getFastMesajTarihi()));
            eftEftTx.setFastGonderenKatilimci(iMap.getString("FAST_GONDEREN_KATILIMCI", eftEftTx.getFastGonderenKatilimci()));
            eftEftTx.setFastSorguNumarasi(iMap.getBigDecimal("FAST_SORGU_NO", eftEftTx.getFastSorguNumarasi())); 
            
			session.saveOrUpdate(eftEftTx);
			session.flush();

  			List<?> eftDetayList = session.createCriteria(EftEftDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Object name : eftDetayList) {
				EftEftDetayTx eftEftDetayTx = (EftEftDetayTx) name;
				session.delete(eftEftDetayTx);
			}

 			for (int i = 0; i < iMap.getSize("EFTDETAY"); i++) {
				EftEftDetayTx eftEftDetayTx = new EftEftDetayTx();
				EftEftDetayTxId eftEftDetayTxId = new EftEftDetayTxId();
				
				eftEftDetayTx.setId(eftEftDetayTxId);
				
				eftEftDetayTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				eftEftDetayTxId.setSiraNo(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO",
                        iMap).getBigDecimal("SIRA_NO")); 
				
				
				eftEftDetayTx.setGonderen(iMap.getString("EFTDETAY", i, "GONDEREN"));
				eftEftDetayTx.setGonderenVergiKimlikNumarasi(iMap.getString("EFTDETAY", i, "GONDEREN_VERGI_KIMLIK_NUMARASI"));
				eftEftDetayTx.setKiymetKodu(iMap.getString("EFTDETAY", i, "KIYMET_KODU"));
				eftEftDetayTx.setAlacMiktar(iMap.getBigDecimal("EFTDETAY", i, "ALAC_MIKTAR"));
				eftEftDetayTx.setAmirEkBilgi(iMap.getString("EFTDETAY", i ,"AMIR_EK_BILGI"));
				eftEftDetayTx.setNihaiAliciEkBilgi(iMap.getString("EFTDETAY", i ,"NIHAI_ALICI_EK_BILGI"));
				session.saveOrUpdate(eftEftDetayTx);

			}
 			session.flush();
 		    if (iMap.getString("EKRAN_NO").equals("2391")) {
 	 			
 		    	List<?> eftNysDetayList = session.createCriteria(EftNysDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
 				for (Object name : eftNysDetayList) {
 					EftNysDetayTx eftNysDetayTx = (EftNysDetayTx) name;
 					session.delete(eftNysDetayTx);
 				}
 						String tblName="EFT_NYS_DETAY";
 						for (int i = 0; i < iMap.getSize(tblName); i++) {
 							EftNysDetayTx eftNysDetayTx = new EftNysDetayTx();
 							EftNysDetayTxId eftNysDetayTxId = new EftNysDetayTxId();
 						
 							eftNysDetayTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
 							eftNysDetayTxId.setSiraNo(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO", iMap).getBigDecimal("SIRA_NO")); 
 							eftNysDetayTx.setId(eftNysDetayTxId);
 							
 							
 							eftNysDetayTx.setBarkodNumarasi(iMap.getString(tblName,i,"BARKOD_NO"));
 							eftNysDetayTx.setEmisyonGrubu(iMap.getString(tblName,i,"EMISYON_GRUP"));
 							eftNysDetayTx.setKapTuru(iMap.getString(tblName,i,"KAP_TURU"));
 							eftNysDetayTx.setKupurBilgisi(iMap.getString(tblName,i,"KUPUR_BILGISI"));
 							eftNysDetayTx.setPaketSayisi(iMap.getBigDecimal(tblName,i,"PAKET_SAYISI"));;
 							session.saveOrUpdate(eftNysDetayTx);
 						}
 						
 						String tblNameM="EFT_NYS_DETAY_MONY";
 						for (int i = 0; i < iMap.getSize(tblNameM); i++) {
 							EftNysDetayTx eftNysDetayTx = new EftNysDetayTx();
 							EftNysDetayTxId eftNysDetayTxId = new EftNysDetayTxId();
 						
 							eftNysDetayTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
 							eftNysDetayTxId.setSiraNo(GMServiceExecuter.call("BNSPR_COMMON_GET_GENEL_SIRA_NO", iMap).getBigDecimal("SIRA_NO")); 
 							eftNysDetayTx.setId(eftNysDetayTxId);
 							
 							
 							eftNysDetayTx.setKupurBilgisi(iMap.getString(tblNameM,i,"KUPUR_BILGISI"));
 							eftNysDetayTx.setUygunAdet(iMap.getBigDecimal(tblNameM,i,"UYGUN_ADET"));
                            eftNysDetayTx.setFersudeAdet(iMap.getBigDecimal(tblNameM,i,"FERSUDE_ADET"));
                            eftNysDetayTx.setIadeAdet(iMap.getBigDecimal(tblNameM,i,"IADE_ADET"));
                            eftNysDetayTx.setTahsilatAdet(iMap.getBigDecimal(tblNameM,i,"TAHSILAT_ADET"));
                            eftNysDetayTx.setTediyeAdet(iMap.getBigDecimal(tblNameM,i,"TEDIYE_ADET"));
                            eftNysDetayTx.setTcmbFersudeAdet(iMap.getBigDecimal(tblNameM,i,"TCMB_FERSUDE_ADET"));
                            eftNysDetayTx.setSonrakiVardiyaAdet(iMap.getBigDecimal(tblNameM,i,"VARDIYA_ADET"));
 							session.saveOrUpdate(eftNysDetayTx);
 						}
 						
 					}
 		    
			session.flush();
			if (iMap.getString("EKRAN_NO").equals("2319") || iMap.getString("EKRAN_NO").equals("2320")) {
				if (iMap.getBigDecimal("ILGILI_ISLEM_NUMARA") != null) {

					String tableName = "ISLEM_TURU_TABLO";

					if (iMap.get(tableName) != null) {
						List<?> list = (List<?>) iMap.get(tableName);

						for (int i = 0; i < list.size(); i++) {

							EftHabrgenlEtiketTxId id = new EftHabrgenlEtiketTxId();
							id.setTxNo(iMap.getBigDecimal("TRX_NO"));
							id.setSiraNo(iMap.getBigDecimal(tableName, i, "SIRA_NO"));

							EftHabrgenlEtiketTx birEftHabrgenlEtiketTx = (EftHabrgenlEtiketTx) session.get(EftHabrgenlEtiketTx.class, id);

							if (birEftHabrgenlEtiketTx == null) {
								birEftHabrgenlEtiketTx = new EftHabrgenlEtiketTx();
							}

							birEftHabrgenlEtiketTx.setId(id);
							birEftHabrgenlEtiketTx.setEtiket(iMap.getString(tableName, i, "ETIKET"));
							birEftHabrgenlEtiketTx.setDeger(iMap.getString(tableName, i, "DEGER"));

							session.saveOrUpdate(birEftHabrgenlEtiketTx);
							session.flush();

						}

					}

				}

			}

			iMap.put("TRX_NAME", iMap.getString("EKRAN_NO"));
			iMap.put("CAGIRAN_TRX_NO", iMap.getBigDecimal("CAGIRAN_TRX_NO"));

			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	public static String getComboBoxValue(GMMap iMap) {

		String islemTuru = null;

		if (iMap.getBoolean("IADE_TALEBI")) {
			islemTuru = "I";
		}
		else if (iMap.getBoolean("AYRINTI_TALEBI")) {
			islemTuru = "A";
		}
		else if (iMap.getBoolean("AYRINTI_GONDERIMI")) {
			islemTuru = "G";
		}

		return islemTuru;

	}

	public static GMMap getEftDiValues(String gBanka, String gSube, String gSehir, String aBanka, String aSube, String aSehir) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call pkg_trn2317.post_query(?,?,?,?,?,?,?,?,?,?,?,?)}");

			stmt.registerOutParameter(7, Types.VARCHAR);
			stmt.registerOutParameter(8, Types.VARCHAR);
			stmt.registerOutParameter(9, Types.VARCHAR);
			stmt.registerOutParameter(10, Types.VARCHAR);
			stmt.registerOutParameter(11, Types.VARCHAR);
			stmt.registerOutParameter(12, Types.VARCHAR);

			stmt.setString(1, gBanka);
			stmt.setString(2, gSube);
			stmt.setString(3, gSehir);
			stmt.setString(4, aBanka);
			stmt.setString(5, aSube);
			stmt.setString(6, aSehir);

			stmt.execute();

			oMap.put("DISPLAY_GONDEREN_BANKA", stmt.getString(7));
			oMap.put("DISPLAY_GONDEREN_SUBE", stmt.getString(8));
			oMap.put("DISPLAY_GONDEREN_SEHIR", stmt.getString(9));
			oMap.put("DISPLAY_ALAN_BANKA_KODU", stmt.getString(10));
			oMap.put("DISPLAY_ALAN_SUBE_KODU", stmt.getString(11));
			oMap.put("DISPLAY_ALAN_SEHIR_KODU", stmt.getString(12));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * 
	 * @param iMap
	 * 
	 * @return oMap
	 *         -CUTOFF_PASSED(true/false)
	 */
	@GraymoundService("BNSPR_EFT_CUTOFF_PASSED")
	public static GMMap cutOffPassed(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();

			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_eft_saat.cutoff_gectimi()}");
			stmt.registerOutParameter(1, java.sql.Types.VARCHAR);
			stmt.execute();

			oMap.put("CUTOFF_PASSED", "E".equals(stmt.getString(1)));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * 
	 * @param iMap
	 *            -IBAN
	 * @return oMap
	 *         -BANKA_KODU
	 *         -SUBE_KODU
	 *         -SEHIR_KODU
	 *         -BANKA_ADI
	 *         -SUBE_ADI
	 *         -SEHIR_ADI
	 */
	@GraymoundService("BNSPR_EFT_GET_IBAN_BILGI")
	public static GMMap getIbanInfo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call Pkg_eft.EFT_IBAN_Banka_Sube_Sehir_Al(?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.setString(i++, iMap.getString("IBAN"));
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.execute();

			// Algoritmayi saglamayan iban durumunda paket tarafi dogrudan 694 nolu hatayi firlatiyor, algoritmayi saglayan gecersiz iban durumunu da
			// burada ayrica ele aliyoruz
			String bankaKodu = stmt.getString(2);

			if (StringUtil.isEmpty(bankaKodu)) {
				iMap.put("MESSAGE_NO", new java.math.BigDecimal(694));
				String message = (String) GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", iMap).get("ERROR_MESSAGE");
				EftServices.throwGMBusssinessException(message);
				//throw new GMRuntimeException(0, message);
			}

			oMap.put("BANKA_KODU", bankaKodu);
			oMap.put("SUBE_KODU", stmt.getString(3));
			oMap.put("SEHIR_KODU", stmt.getString(4));
			oMap.put("BANKA_ADI", stmt.getString(5));
			oMap.put("SUBE_ADI", stmt.getString(6));
			oMap.put("SEHIR_ADI", stmt.getString(7));
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

	/**
	 * 
	 * @param iMap
	 *            -MUSTERI_NO
	 *            -HESAP_NO
	 *            -BAS_TARIH
	 *            -BIT_TARIH
	 * @return oMap
	 *         TX_NO
	 *         EFT_TUR
	 *         EFT_TARIH
	 *         GONDEREN_BANKA
	 *         BANKA_ADI
	 *         GONDEREN_SUBE
	 *         GONDEREN
	 *         GONDEREN_HESAP
	 *         GONDEREN_IBAN
	 *         TUTAR
	 *         ALICI_ADI
	 *         ACIKLAMA
	 *         DURUM
	 */

    @GraymoundService("BNSPR_EFT_GET_HESABA_ALINAN_LIST")
    public static GMMap getEftGetHesabaAlinanList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();

            stmt = conn.prepareCall("{? = call PKG_RC_EFT.RC_GET_HESABA_ALINAN_EFTLER(?,?,?,?)}");

            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("HESAP_NO"));

            if(iMap.getDate("BAS_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("BAS_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			
			if(iMap.getDate("BIT_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("BIT_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
            
            stmt.execute();
            stmt.getMoreResults();
            rSet = (ResultSet) stmt.getObject(1);

            String tableName = "ALINAN_EFT_TABLE";
            return DALUtil.rSetResults(rSet, tableName);

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
	public static GMMap throwGMBusssinessException(String string) {				
		GMMap exMap = new GMMap();
		exMap.put("P1", string);
		exMap.put("HATA_NO", "660");
		return GMServiceExecuter.call("BNSPR_COMMON_HATA_YAZ", exMap);
	}
	
    @GraymoundService("BNSPR_EFT_GET_RECORDED_FAST_EFT_LIST")
    public static GMMap getRecordedFastEftList(GMMap iMap) {

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call PKG_EFT.Hizli_EFT_Liste(?,?) }");

            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("RUMUZ_ID"));

            stmt.execute();
            stmt.getMoreResults();
            rSet = (ResultSet) stmt.getObject(1);

            String tableName = "HIZLI_EFT_LIST";

            return DALUtil.rSetResults(rSet, tableName);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    
    @GraymoundService("BNSPR_EFT_GET_EFT_COMMISION")
    public static GMMap getEftCommision(GMMap iMap) {

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            GMMap oMap = new GMMap();
            conn = DALUtil.getGMConnection();

            int i = 1;

            stmt = conn.prepareCall("{? = call pkg_parametre.ParamTextDegerVarMi('UPT_MASRAFSIZ_ILKOD', ?)}");
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.setString(i++, iMap.getString("T_CITY_CODE"));
            stmt.execute();
            if ("E".equals(stmt.getString(1))) {
                oMap.put("TOTAL_COMMISION", new BigDecimal(0));
                oMap.put("TOTAL_TAX", new BigDecimal(0));
                return oMap;
            }
            GMServerDatasource.close(stmt);

            stmt = conn.prepareCall("{call Pkg_masraf_yeni.kanal_masraf_hesapla(?,?,?,?,?,?,?,?)}");
            i = 1;
            stmt.setString(i++, iMap.getString("SCREEN_CODE"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("AMOUNT"));
            stmt.setString(i++, iMap.getString("CURRENCY_CODE"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("CUSTOMER_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("F_ACCOUNT_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("T_ACCOUT_NO"));

            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.registerOutParameter(i++, Types.NUMERIC);

            stmt.execute();

            oMap.put("TOTAL_COMMISION", stmt.getBigDecimal(7));
            oMap.put("TOTAL_TAX", stmt.getBigDecimal(8));

            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_EFT_GET_EFT_DIRECTIVE_LIST")
    public static GMMap getEftDirectiveList(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();

            stmt = conn.prepareCall("{? = call pkg_external.kayitli_eft_talimat_liste(?,?)}");

            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.setBigDecimal(i++, iMap.getBigDecimal("CUSTOMER_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("DIRECTIVE_TYPE"));

            stmt.execute();
            stmt.getMoreResults();
            rSet = (ResultSet) stmt.getObject(1);

            String tableName = "TABLE";
            return DALUtil.rSetResults(rSet, tableName);

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_EFT_SAVE_EFT")
    public static GMMap saveEft(GMMap iMap) {

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            GMMap oMap = new GMMap();
            setBranchCode(iMap.getString("MUSTERI_HESAP_NO"));
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call Pkg_external.EFT_Giris_Initials(?,?,?,?,?,?,?,?,?,?)}");
            int i = 1;
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_HESAP_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("TUTAR_SCR"));
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.execute();
            i = 4;
            iMap.put("TRX_NO", stmt.getBigDecimal(i++));
            iMap.put("GONDEREN_BANKA", stmt.getString(i++));
            iMap.put("GONDEREN_SUBE", stmt.getString(i++));
            iMap.put("GONDEREN_SEHIR", stmt.getString(i++));
            iMap.put("MASRAF", stmt.getBigDecimal(i++));
            if (iMap.get("PASS_VKN") != null && iMap.getBoolean("PASS_VKN")) {
                i++;
            } else {
                iMap.put("GONDEREN_VERGI_KIMLIK_NUMARASI", stmt.getString(i++));
            }
            iMap.put("BOLUM_KODU", stmt.getString(i++));
            iMap.put("OTOMATIK_BILDIRIM_OLUSTUR", "E");
            if (iMap.getBigDecimal("EFT_TIPI").compareTo(new BigDecimal(1)) == 0)
                iMap.put("MESAJ_KODU", "KRED");
            else if (iMap.getBigDecimal("EFT_TIPI").compareTo(new BigDecimal(2)) == 0)
                iMap.put("MESAJ_KODU", "KRED-KART");
            else if (iMap.getBigDecimal("EFT_TIPI").compareTo(new BigDecimal(3)) == 0)
                iMap.put("MESAJ_KODU", "NORM");
            iMap.put("ONCELIK", "2");
            iMap.put("ISLEM_TIPI", "M");
            iMap.put("MASRAF_IC_DIS", "D");
            iMap.put("MASRAF_TAHSIL_SEKLI", "H");
            iMap.put("MASRAF_HESAP_NO", iMap.getBigDecimal("MUSTERI_HESAP_NO"));
            iMap.put("GELEN_GIDEN", "GIDEN");
            iMap.put("EKRAN_NO", "2315");
            iMap.put("KIMLIK_TIPI", "1");
            iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2315_GET_SORGU_NO", iMap));
            iMap.put("EFT_REF", iMap.getString("REF"));
            iMap.put("DURUM", "EKLENDI");
            oMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
            // TODO: Sorgu numaras� eklendi�inde tekrar geri koy
            oMap.put("REC_ID", iMap.getString("SORGU_NO"));
            // Paygate Servisini Cagiralim MHA 09122015
            GMMap amlMap = new GMMap(); 
			amlMap.put("ALAN_BANKA", DALUtil.callOneParameterFunction("{? = call pkg_genel_pr.banka_adi_al_eft_hatasiz(?)}", Types.VARCHAR, 
					iMap.getString("ALAN_BANKA_KODU")));
			amlMap.put("GONDEREN", iMap.getString("GONDEREN"));
			amlMap.put("GONDEREN_TCKN", iMap.getString("GONDEREN_VERGI_KIMLIK_NUMARASI"));
			amlMap.put("MUSTERI_NO", iMap.getString("MUSTERI_NO"));
			GMMap dtMap = new GMMap();
			dtMap.put("CUSTOMER_NO" , iMap.getString("MUSTERI_NO"));
	        iMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_BIRTH_DATE" , dtMap));
	        amlMap.put("GONDEREN_DTARIH" , iMap.getString("BIRTH_DATE"));
	        amlMap.put("ACIKLAMA", iMap.getString("ACIKLAMA"));
			amlMap.put("ALICI", iMap.getString("ALICI_ADI"));
			amlMap.put("ALICI_TCKN", iMap.getString("ALICI_TCKN"));
			amlMap.put("TUTAR", iMap.getBigDecimal("TUTAR"));
			amlMap.put("EFT_TARIH", iMap.getDate("EFT_TARIH"));
			amlMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2315_EFT_PAYGATE_CHECK", amlMap));

            oMap.putAll(GMServiceExecuter.execute("BNSPR_EFT_SAVE", iMap));
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_EFT_SAVE_EFT_DIRECTIVE")
    public static GMMap saveEftDirective(GMMap iMap) {
        try {
            iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
            GMMap oMap = new GMMap();
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2301_SAVE_DUZENLI_ODEME", iMap));
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_EFT_DELETE_EFT_DIRECTIVE")
    public static GMMap deleteEftDirective(GMMap iMap) {
        try {
            iMap.putAll(GMServiceExecuter.execute("BNSPR_TRX_GET_TRANSACTION_NO", iMap));
            GMMap oMap = new GMMap();
            oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN2302_SAVE_DUZENLI_ODEME_IPTAL", iMap));
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }
    
    @GraymoundService("BNSPR_EFT_DELETE_FUTURE_DATE_EFT")
    public static GMMap deleteFutureDateEft(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        GMMap oMap = new GMMap();
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ call PKG_TRN2315.Islem_Iptal(?)}");
            stmt.setBigDecimal(1, iMap.getBigDecimal("ID"));
            stmt.execute();
            return oMap;
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    
    public static void setBranchCode(String accountNo) throws Exception {
        try {
        	BnsprCommonFunctions.setBranchCode(accountNo);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
        }
    }

    @GraymoundService("BNSPR_EFT_EVENT")
    public static GMMap eftEvent(GMMap iMap) {

        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{? = call pkg_rc_eft.rc_eft_event_olusturulacak }");

            int i = 1;
            stmt.registerOutParameter(i++, -10);
            stmt.execute();
            stmt.getMoreResults();
            rSet = (ResultSet) stmt.getObject(1);

            while(rSet.next()){
            	iMap.put("EVENT_TYPE_NO", "91");
                iMap.put("EVENT_REF_NO", rSet.getBigDecimal("ODEME_TX_NO"));
                GMServiceExecuter.executeAsync("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
            }
            
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
        
        return new GMMap();
    }
    
}
