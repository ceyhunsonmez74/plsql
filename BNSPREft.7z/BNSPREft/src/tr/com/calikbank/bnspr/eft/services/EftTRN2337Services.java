package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftDetayTx;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2337Services {
	@GraymoundService("BNSPR_TRN2337_GET_EFT_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			//EftEftTx eftEftTx = (EftEftTx)session.createCriteria(EftEftTx.class).add(Restrictions.eq("odemeTxNo",  iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			EftEftTx eftEftTx = (EftEftTx)session.createCriteria(EftEftTx.class).add(Restrictions.or(Restrictions.eq("txNo",  iMap.getBigDecimal("TRX_NO")),Restrictions.eq("odemeTxNo",  iMap.getBigDecimal("TRX_NO")))).uniqueResult();
			
			GMMap oMap = new GMMap();
			
		    oMap.put("ODEME_TX_NO" , eftEftTx.getOdemeTxNo());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("DURUM" , eftEftTx.getDurum());
			oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("GELEN_GIDEN" , eftEftTx.getGelenGiden());
	        oMap.put("TUTAR" , eftEftTx.getTutar());
	        oMap.put("ALICI_HES_BULUN_KURUM" , eftEftTx.getAliciHesBulunKurum());
	        oMap.put("ALICI_HES_BULUN_KURUM_HESAP_NO" ,eftEftTx.getAliciHesBulunKurumHesapNo());
	        oMap.put("NIHAI_ALICI" , eftEftTx.getNihaiAlici());
	        oMap.put("NIHAI_ALICI_HESAP_NO" , eftEftTx.getNihaiAliciHesapNo());
	        oMap.put("AMIR_KURUM_VKNO" , eftEftTx.getAmirKurumVkno());
	        oMap.put("AMIR_KURUM" , eftEftTx.getAmirKurum());
	        oMap.put("AMIR" , eftEftTx.getAmir());
	        oMap.put("AMIR_KURUM_HESAP_NO" , eftEftTx.getAmirKurumHesapNo());
	        oMap.put("AMIR_HESAP_NO" , eftEftTx.getAmirHesapNo());
	        oMap.put("ARACI_KURUM" , eftEftTx.getAraciKurum());
	        oMap.put("MASRAF_DETAYI" , eftEftTx.getMasrafDetayi());
	        oMap.put("ACIKLAMA_2" , eftEftTx.getAciklama2());
	        oMap.put("GONDERICIDEN_ALICIYA_BILGI" , eftEftTx.getGondericidenAliciyaBilgi());
	        oMap.put("ODEME_TURU" , eftEftTx.getIslemTuru());
	        oMap.put("ODEME_KAYNAK" , eftEftTx.getOdemeKaynak());
	        oMap.put("MASRAF_DETAYI" , eftEftTx.getMasrafDetayi());	        
	        oMap.put("NIHAI_ALICI_KURUM" , eftEftTx.getNihaiAliciKurum());
	        oMap.put("NIHAI_ALICI_KURUM_HESAP_NO" , eftEftTx.getNihaiAliciKurumHesapNo());
	        oMap.put("ACIKLAMA_2" , eftEftTx.getAciklama2());
	        oMap.put("KAS_MESAJ_KODU" , eftEftTx.getKasMesajKodu());
	        oMap.put("GONDEREN" , eftEftTx.getGonderen());
	        oMap.put("GONDEREN_ADRES" , eftEftTx.getGonderenAdres());
	        oMap.put("GONDEREN_PASAPORT_NO", eftEftTx.getGonderenPasaportNo());
	        oMap.put("GONDEREN_DOGUM_YERI", eftEftTx.getGonderenDogumYeri());
	        oMap.put("GONDEREN_DOGUM_TARIHI", eftEftTx.getGonderenDogumTarihi());
	        oMap.put("GONDEREN_MUSTERI_NUMARASI", eftEftTx.getGonderenMusteriNumarasi());
	        
	        oMap.put("REFERANS_NO" , eftEftTx.getReferansNo());
	       
	        oMap.put("ISLEM_TIPI" , eftEftTx.getIslemTipi());
	        oMap.put("ODEME_SUBE" , eftEftTx.getOdemeSube());
	        oMap.put("ODEME_DK_HESAP" , eftEftTx.getOdemeDkHesap());
	        oMap.put("ODEME_MUSTERI_NO" , eftEftTx.getOdemeMusteriNo());
	        oMap.put("ODEME_MUSTERI_HESAP" , eftEftTx.getOdemeMusteriHesap());
	        oMap.put("ALICI_IBAN" , eftEftTx.getAliciIban());
	        oMap.put("F_SWIFT_GONDERILDIMI" , GuimlUtil.convertToCheckBoxSelected(eftEftTx.getFSwiftGonderildimi()));
            oMap.put("ARACI_KURUM_HESAP_NO" , eftEftTx.getAraciKurumHesapNo());
            oMap.put("ILGILI_ISLEM_REFERANSI" , eftEftTx.getIlgiliIslemReferansi());
            oMap.put("GONDEREN_HESAP_NUMARASI", eftEftTx.getGonderenHesapNumarasi());
            oMap.put("ON_BILDIRIM_REFERANSI", eftEftTx.getOnBildirimReferansi());
            oMap.put("SWIFT_TEKIL_NO", eftEftTx.getDborAlacakli());
	              
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));

            oMap.put("AMIR_ULKE_SEHIR", eftEftTx.getAmirUlkeSehir());
            oMap.put("MESAJ_GRUBU", eftEftTx.getMesajGrubu());
            oMap.put("AMIR_KIMLIK_NO", eftEftTx.getAmirKimlikNo());
            oMap.put("NIHAI_ALICI_ADRESI", eftEftTx.getNihaiAliciAdresi());
            oMap.put("NIHAI_ALICI_ULKE_SEHIR", eftEftTx.getNihaiAliciUlkeSehir());
            oMap.put("AMIR_BILGI_SECIM", eftEftTx.getAmirBilgiSecim());
            oMap.put("NIHAI_ALICI_BILGI_SECIM", eftEftTx.getNihaiAliciBilgiSecim());
            
            
	        List<?> eftDetayList = session.createCriteria(EftEftDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        int i=0;
			for (Object name : eftDetayList) {
				EftEftDetayTx eftEftDetayTx = (EftEftDetayTx) name;
				oMap.put("EFTDETAY", i,"AMIR_EK_BILGI", eftEftDetayTx.getAmirEkBilgi());
				oMap.put("EFTDETAY", i,"NIHAI_ALICI_EK_BILGI", eftEftDetayTx.getNihaiAliciEkBilgi());				
				i++;
			}
			oMap.put("MASRAF", eftEftTx.getMasraf());
	        
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2337_GET_DILOV")
	public static GMMap getDiLOV(GMMap iMap){
		GMMap oMap = new GMMap();
		String odemeSube ;
		BigDecimal musteriNo;
		BigDecimal musteriHesap;
		try {
		
			odemeSube = iMap.getString("ODEME_SUBE");
			musteriNo = iMap.getBigDecimal("ODEME_MUSTERI_NO");
			musteriHesap = iMap.getBigDecimal("ODEME_MUSTERI_HESAP");
			
		 if(odemeSube != "" || odemeSube != null)	
		 oMap.put("DISPLAY_ODEME_SUBE", LovHelper.diLov(odemeSube, "2317/LOV_BOLUM","ADI"));	
		 if(musteriNo != null)	
		 oMap.put("DISPLAY_MUSTERI_ADI", LovHelper.diLov(musteriNo, "2317/LOV_MUSTERI","ADI"));
		 if(musteriHesap != null){	
		 //oMap.put("HESAP_KISA_ISIM", LovHelper.diLov(musteriHesap,odemeSube,odemeSube,musteriNo, "2317/LOV_MUSTERI_HESAP_NO","KISA_ISIM"));
		 //oMap.put("IBAN", LovHelper.diLov(musteriHesap,odemeSube,odemeSube,musteriNo, "2317/LOV_MUSTERI_HESAP_NO","IBAN"));
		 }
		 return oMap;	
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	
	
	
}
