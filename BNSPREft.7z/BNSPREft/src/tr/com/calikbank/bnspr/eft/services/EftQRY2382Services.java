package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class EftQRY2382Services {

	@GraymoundService("BNSPR_QRY2382_INITIALIZE")
	public static GMMap getGidenEftMesajlari(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
		    DALUtil.fillComboBox(oMap, "DURUM_KODU"	, true, "select key1, text from v_ml_gnl_param_text where KOD = 'GELEN_EFT_DURUM' and KEY1 like 'EUPT%' ");
		    DALUtil.fillComboBox(oMap, "DURUM_KODU2"	, true, "select key1, text from v_ml_gnl_param_text where kod = 'GIDEN_EFT_DURUM' and key1 in ('TAMAM','TCMB')");

			
		} catch (Exception e) {
			EftServices.throwGMBusssinessException(e.getMessage());
		}
		return oMap;
	}	
	
	
	
	
	
	@GraymoundService("BNSPR_QRY2382_ODEME_EKRANINA_YONLENDIR")
	public static GMMap getOdemeEkraninaYonlendir(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap myMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ?=call PKG_trn2347.Odeme_Ekranina_Yonlendir (?,?,?)}");
			int i = 1;
			
			stmt.registerOutParameter(i++, Types.DECIMAL);
			stmt.setString(i++, iMap.getString("K_ISLEM_NO"));
			stmt.setString(i++, iMap.getString("K_SUBE_KOD"));
			stmt.setString(i++, iMap.getString("K_DURUM_KOD"));
			stmt.execute();
			
			
			GMMap iMap1 = new GMMap();
			
			
			if(stmt.getBigDecimal(1).compareTo(new BigDecimal(1)) == 0){
				
				iMap1.put("MESSAGE_NO", new BigDecimal("2343"));
				iMap1.put("P1",iMap.getString("K_SUBE_KOD"));
				iMap1.put("P2",iMap.getString("K_DURUM_KOD"));
				String mesaj = (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap1).get("ERROR_MESSAGE");
				myMap.put("MESSAGE", mesaj);
				
			}
			else{
		
				iMap1.put("MESSAGE_NO", new BigDecimal("232"));
				String mesaj = (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_KODSUZ_MESSAGE", iMap1).get("ERROR_MESSAGE");
				myMap.put("MESSAGE", mesaj);
			}
				
			return myMap;
		
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	
	
	@GraymoundService("BNSPR_QRY2382_GET_GELEN_UPT")
	public static GMMap getGelenUpt(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		int i = 1;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2382.RC_TRN2382_GELEN_EFT_MESAJLARI(?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("SORGU_NO"));
			stmt.setString(i++, iMap.getString("GONDEREN_BANKA"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_TUTAR"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_TUTAR"));
			if(iMap.getDate("BAS_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("BAS_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			
			if(iMap.getDate("BIT_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("BIT_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			
			stmt.setString(i++, iMap.getBoolean("30_GUNU_DOLAN") ? "E" : "H");
			stmt.setString(i++, iMap.getBoolean("IADE_GIDEN") ? "E" : "H");
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			GMMap oMap = new GMMap();
			oMap.putAll(DALUtil.rSetResults(rSet, "GELEN_UPT")); 
			if(!oMap.containsKey("GELEN_UPT"))
			{
				iMap.put("HATA_NO", new BigDecimal(1614));
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2382_GET_GIDEN_UPT")
	public static GMMap getGidenUpt(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		int i = 1;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2382.RC_TRN2382_GIDEN_EFT_MESAJLARI(?,?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10);			
			
			
			stmt.setString(i++, iMap.getString("SORGU_NO"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			stmt.setString(i++, iMap.getString("MESAJ_KODU"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("UPT_ISLEM_NO"));
			stmt.setString(i++, iMap.getString("GON_UPT_HESAP_NO"));
			stmt.setString(i++, iMap.getString("ALICI_BANKA"));
			
			
			if (iMap.getBigDecimal("MIN_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_TUTAR"));

			if (iMap.getBigDecimal("MAX_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_TUTAR"));			
			
			
			if(iMap.getDate("BAS_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("BAS_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			
			if(iMap.getDate("BIT_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("BIT_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			stmt.setString(i++, iMap.getBoolean("CHK_IADE_GELEN") ? "E" : "H");
			stmt.setString(i++, iMap.getBoolean("CHK_TAMAMLANANLAR") ? "E" : "H");
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			GMMap oMap = new GMMap();
			oMap.putAll(DALUtil.rSetResults(rSet, "GIDEN_UPT")); 
			/*if(!oMap.containsKey("GIDEN_UPT"))
			{
				iMap.put("HATA_NO", new BigDecimal(1614));
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}*/
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2382_GET_TARIHCE")
	public static GMMap getTarihce(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		GMMap				oMap = null;
		
		String tableName 	= "TARIHCE_LIST";
		String islemGoster[]= {"2345", "2319", "2311", "2317", "2312", "2030","2315","2320"};
		int i = 1;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2374.GET_EFT_TARIHCE(?)}");
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("ISLEM_NO"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			oMap = DALUtil.rSetResultsPutStr(rSet, tableName);
			
            for (int row = 0; row < oMap.getSize(tableName); row++){
                String islemNo = oMap.getString(tableName , row , "ISLEM_KODU");
                for (int n = 0; n < islemGoster.length; n++){
                    if (islemGoster[n].equals(islemNo)){
                        if (!StringUtil.isEmpty(oMap.getString(tableName , row , "ISLEM_NO"))){
                            oMap.put(tableName , row , "ISLEM_GOSTER" , true);
                            break;
                        }
                    }
                }
            }
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY2382_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA")
	public static GMMap islemDogrulaOnayIptal(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		String islemTuru = iMap.getString("ISLEM_TURU");
		List<?> list = (List<?>)iMap.get("ISLEM_LIST");
		try {
			conn = DALUtil.getGMConnection();
			String mesajNo = null;
			for(int i = 0; i<list.size(); i++)
			{
				if(iMap.getBoolean("ISLEM_LIST", i, "SEC"))
				{
					if ("O".equals(islemTuru)) {
						if("H".equals(iMap.getString("ISLEM_LIST", i, "ONAYLANABILIR_MI")) || iMap.getString("ISLEM_LIST", i, "ONAYLANABILIR_MI") == null)
							mesajNo = "253";
					} else if ("IO".equals(islemTuru)) {
						if("H".equals(iMap.getString("ISLEM_LIST", i, "IPTAL_ONAYLANABILIR_MI")) || iMap.getString("ISLEM_LIST", i, "IPTAL_ONAYLANABILIR_MI") == null)
							mesajNo = "257";
					} else if ("DR".equals(islemTuru)) {
						if("H".equals(iMap.getString("ISLEM_LIST", i, "DOGRULANABILIR_MI")) || iMap.getString("ISLEM_LIST", i, "DOGRULANABILIR_MI") == null)
							mesajNo = "252";
					} else if ("OR".equals(islemTuru)) {
						if("H".equals(iMap.getString("ISLEM_LIST", i, "ONAYLANABILIR_MI")) || iMap.getString("ISLEM_LIST", i, "ONAYLANABILIR_MI") == null)
							mesajNo = "253";
					} else if ("IOR".equals(islemTuru)) {
						if("H".equals(iMap.getString("ISLEM_LIST", i, "IPTAL_ONAYLANABILIR_MI")) || iMap.getString("ISLEM_LIST", i, "IPTAL_ONAYLANABILIR_MI") == null)
							mesajNo = "257";
					}
					
					if(mesajNo != null)
					{
						iMap.put("HATA_NO", mesajNo);
						iMap.put("P1", iMap.getBigDecimal("ISLEM_LIST", i, "NO"));
						GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
						return oMap;
					}
				}
			}
			
			for(int i = 0; i<list.size(); i++)
			{
				if(iMap.getBoolean("ISLEM_LIST", i, "SEC"))
				{
				    GMMap tmpMap = new GMMap();
				    tmpMap.put("ISLEM_NO" , iMap.getBigDecimal("ISLEM_LIST", i, "NO"));
				    tmpMap.put("ACIKLAMA" , iMap.getString("ACIKLAMA"));
				    tmpMap.put("ISLEM_TURU" , islemTuru);
				    tmpMap.put("GUIML_NAME", iMap.getString("GUIML_NAME"));
				    
				    oMap = GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", tmpMap);
				}
			}

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			if(iMap.getString("ANA_SUBE")!= null && !iMap.getString("ANA_SUBE").isEmpty())
			{
				GMMap tempMap = new GMMap();
				tempMap.put("BRANCH_ID", iMap.getString("ANA_SUBE"));
				GMServiceExecuter.execute("BNSPR_CORE_SET_USER_BRANCH", tempMap);
			}
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY2382_GET_ISLEM_YETKI_KONTROL")
	public static GMMap getIslemYetkiKontrol(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		GMMap oMap = new GMMap();
		int i = 1;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC2374.islem_yetki_kontrol(?)}");
			stmt.registerOutParameter(i++, Types.VARCHAR);
			stmt.setBigDecimal(i++, iMap.getBigDecimal("ISLEM_KOD"));
			stmt.execute();
			
			oMap.put("YETKI_KONTROL", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}


