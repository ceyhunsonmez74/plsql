package tr.com.calikbank.bnspr.eft.services;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2325Services {
@GraymoundService("BNSPR_TRN2325_GET_EFT_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
			
		    oMap.put("TRX_NO" , eftEftTx.getTxNo());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("DURUM" , eftEftTx.getDurum());
			oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("TUTAR" , eftEftTx.getTutar());
	        oMap.put("GELEN_GIDEN" , eftEftTx.getGelenGiden());
	        oMap.put("KAS_MESAJ_KODU", eftEftTx.getKasMesajKodu());
	        oMap.put("KAS_EFT", eftEftTx.getKasEft());
	        oMap.put("ILGILI_SORGU_NO", eftEftTx.getIlgiliIslemReferansi());
	        oMap.put("FAST_TARIH", eftEftTx.getFastMesajTarihi());
	        oMap.put("FAST_GONDEREN_KATILIMCI", eftEftTx.getFastGonderenKatilimci());
	        oMap.put("FAST_SORGU_NO", eftEftTx.getFastSorguNumarasi());
	        
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
@GraymoundService("BNSPR_TRN2325_GET_MESAJ_TURLERI")
public static GMMap getAll(GMMap iMap){
    try{
        GMMap oMap = new GMMap();
        DALUtil.fillComboBox(oMap, "RESULTS", false, "select key1 kod,key1||' '||text as text from v_ml_gnl_param_text where kod = 'EFT_KAS_MESAJ_TIPLERI' and key1 in ('K09','K11','K13','K19','K01','K29') order by 1");
        return oMap;
    }catch (Exception e) {
        throw ExceptionHandler.convertException(e);
    }
}  
 
}
