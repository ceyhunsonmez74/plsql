package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

@SuppressWarnings("deprecation")
public class EftTRN2311Services {
	@GraymoundService("BNSPR_TRN2311_GET_INITIAL_VALUES")
	public static GMMap getInitialValues(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN2311.form_instance(?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.DATE);
			stmt.registerOutParameter(5, Types.DECIMAL);
			stmt.execute();

			oMap.put("SUBE_KODU", stmt.getString(1));
			oMap.put("BANKA_KODU", stmt.getString(2));
			oMap.put("BANKA_ADI", stmt.getString(3));
			oMap.put("EFT_TARIH", stmt.getDate(4));
			oMap.put("TRX_NO", stmt.getBigDecimal(5));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN2311_GET_DK_HESAP_NO")
	public static GMMap getDkVergiNo(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_eft.dk_hesap_al}");

			stmt.registerOutParameter(1, Types.VARCHAR);

			stmt.execute();
			oMap.put("DK_HESAP_NO", stmt.getString(1));

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN2311_GET_VERGI_NO")
	public static GMMap getVergiNo(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_trn2311.iade_musteri_vergi_no(?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("MUSTERI_NO"));
			stmt.execute();

			oMap.put("IADE_VERGI_KIMLIK_NUMARA", stmt.getString(1));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN2311_GET_SQL_DATE")
	public static GMMap getBasDate(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Calendar cal = Calendar.getInstance();
			cal.setTime(iMap.getDate("TARIH"));
			String tarih = "" + cal.get(GregorianCalendar.DAY_OF_MONTH) + "."
					+ (cal.get(GregorianCalendar.MONTH) + 1) + "."
					+ cal.get(GregorianCalendar.YEAR);
			oMap.put("TARIH", tarih);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN2311_GET_EFT_BILGI")
	public static GMMap getEftBilgi(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			EftEftTx eftEftTx = (EftEftTx) session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));

			GMMap oMap = new GMMap();

			oMap.put("MUSTERI_NO", eftEftTx.getMusteriNo());
			oMap.put("DISPLAY_MUSTERI_ADI", LovHelper.diLov(eftEftTx.getMusteriNo(), "2315/LOV_MUSTERI", "UNVAN"));
			oMap.put("IADE_HESAP_NUMARASI", eftEftTx.getIadeHesapNumarasi());
			oMap.put("DK_HESAP_NO", eftEftTx.getDkHesapNo());
			oMap.put("IADE_VERGI_KIMLIK_NUMARA", eftEftTx.getIadeVergiKimlikNumara());
			
			if (eftEftTx.getIadeHesapNumarasi() != null) {
				iMap.put("HESAP_NO", eftEftTx.getIadeHesapNumarasi());
				oMap.put("KULLANILABILIR_BAKIYE", GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", iMap).get(
						"KULLANILABILIR_BAKIYE"));
				oMap.put("DEFTER_BAKIYE", GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_DEFTER_BAKIYE", iMap).get(
						"DEFTER_BAKIYE"));
			}
			oMap.put("GONDEREN_BANKA", eftEftTx.getGonderenBanka());
			oMap.put("GONDEREN_SUBE", eftEftTx.getGonderenSube());
			oMap.put("GONDEREN_SEHIR", eftEftTx.getGonderenSehir());
			oMap.put("IADE_EDEN", eftEftTx.getIadeEden());
			oMap.put("GONDEREN_TELEFON", eftEftTx.getGonderenTelefon());
			oMap.put("GONDEREN_ADRES", eftEftTx.getGonderenAdres());
			oMap.put("ALICI_HESAP_NO", eftEftTx.getAliciHesapNo());
			oMap.put("ALICI_ADI", eftEftTx.getAliciAdi());
			oMap.put("ALAN_BANKA_KODU", eftEftTx.getAlanBankaKodu());
			oMap.put("ALAN_SEHIR_KODU", eftEftTx.getAlanSehirKodu());
			oMap.put("ALAN_SUBE_KODU", eftEftTx.getAlanSubeKodu());
			oMap.put("ALICI_IBAN", eftEftTx.getAliciIban());
			oMap.put("IADE_KODU", eftEftTx.getIadeKodu());
			oMap.put("IADE_ACIKLAMA" , LovHelper.diLov(eftEftTx.getIadeKodu(), "2311/LOV_IADE_KODU", "ACIKLAMA"));
			oMap.put("TUTAR", eftEftTx.getTutar());
			oMap.put("EFT_TARIH", eftEftTx.getEftTarih());
			oMap.put("ONCELIK", eftEftTx.getOncelik().toString());
			oMap.put("ILGILI_ISLEM_TARIH", eftEftTx.getIlgiliIslemTarih());
			oMap.put("ILGILI_ISLEM_NUMARA", eftEftTx.getIlgiliIslemNumara());
			oMap.put("TRX_NO", eftEftTx.getTxNo());
			oMap.put("MESAJ_KODU", eftEftTx.getMesajKodu());
			oMap.put("SORGU_NO", eftEftTx.getSorguNo());
			oMap.put("ACIKLAMA", eftEftTx.getAciklama());
			oMap.put("ACIKLAMA_2", eftEftTx.getAciklama2());
			oMap.put("DURUM", eftEftTx.getDurum());
			oMap.putAll(EftServices.getEftDiValues(eftEftTx
					.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx
					.getGonderenSehir(), eftEftTx.getAlanBankaKodu(), eftEftTx
					.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));

			oMap.put("OTOMATIK_BILDIRIM_OLUSTUR", eftEftTx.getOtomatikBildirimOlustur());
			oMap.put("BILDIRIM_NO", eftEftTx.getBildirimNo());
			oMap.put("ILGILI_ISLEM_TXNO" , LovHelper.diLov(eftEftTx.getIlgiliIslemNumara(),eftEftTx.getIlgiliIslemTarih(), "2311/LOV_ISLEM_NO", "ILGILI_ISLEM_TXNO"));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN2311_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		BigDecimal txNo = null;
		CallableStatement stmt = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			EftEftTx objEftEftTx = (EftEftTx)session.get(EftEftTx.class, iMap.getBigDecimal("ISLEM_NO"));
			if(objEftEftTx == null) {
				objEftEftTx = new EftEftTx();
			}
				    conn = DALUtil.getGMConnection();

					stmt = conn.prepareCall("{? = call PKG_TRN2311.eft_tx_no(?)}");

					stmt.registerOutParameter(1, Types.DECIMAL);
					stmt.setBigDecimal(2,objEftEftTx.getTxNo());
					stmt.execute();

					txNo = stmt.getBigDecimal(1);
				    
				    
					EftEftTx objEftEftTxorj = (EftEftTx)session.get(EftEftTx.class, txNo);
				    
				    if ( objEftEftTxorj.getDurum().startsWith("EUPT_" )) {
						 if (objEftEftTxorj.getDurum().equals("EUPT_SORUN"))
						 {
							    
							    stmt2 = conn
								.prepareCall("{call PKG_eupt.EUPT_CARD_EFT_DURUM_UPDATE(?,?)}");
								stmt2.setBigDecimal(1, txNo);
								stmt2.setString(2, "EUPT_IADE");
								stmt2.execute();
								
						 }	 
						 else
						 { 
							GMMap sMap = new GMMap();
							
						    sMap.put("TRX_NO", txNo);
						    sMap.put("TYPE", "R");
							sMap = GMServiceExecuter.call(
									"BNSPR_EUPT_EUPT_ISLEM_IPTAL_CHECK", sMap);
						
							GMMap sMap2 = new GMMap();
							
						    sMap2.put("TRX_NO", txNo);
						    sMap2.put("TYPE", "R");
							sMap2 = GMServiceExecuter.call(
									"BNSPR_EUPT_EUPT_ISLEM_IPTAL", sMap2);
						 }
								
					}
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			
		}

	}
	
	
}
