package tr.com.calikbank.bnspr.eft.services;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2353Services {

	@GraymoundService("BNSPR_TRN2353_GET_EFT_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
			
			    oMap.put("TRX_NO" , eftEftTx.getTxNo());
		        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
		        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
		        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
		        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
		        oMap.put("DURUM" , eftEftTx.getDurum());
				oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
		        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
		        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
		        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
		        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
		        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
		        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
		        oMap.put("REFERANS_NO",eftEftTx.getReferansNo());
		        oMap.put("KIYMET_KODU" , eftEftTx.getKiymetKodu());
		        oMap.put("MIKTAR" , eftEftTx.getMiktar());
		        oMap.put("ISLEM_VALORU", eftEftTx.getIslemValor());
		        oMap.put("FIYAT", eftEftTx.getFiyat());
		        oMap.put("GERI_DONUS_VALORU", eftEftTx.getGeriDonusValoru());
		        oMap.put("GERI_DONUS_FIYATI", eftEftTx.getGeriDonusFiyati());
		        oMap.put("GERI_ODENECEK_TUTAR", eftEftTx.getGeriOdenecekTutar());
		        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
		        oMap.put("TUTAR", eftEftTx.getTutar());
		        oMap.put("GELEN_GIDEN", eftEftTx.getGelenGiden());
		        
	            oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	
	
}
