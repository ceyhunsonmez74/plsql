package tr.com.calikbank.bnspr.eft.services;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.text.ParseException;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftQRY2381Services {
	
	@GraymoundService("PFT_BASARISIZ_ISLEM_TAMAMLA")
	public static GMMap PftLogAt(GMMap iMap){
		
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		GMMap iMap2 = new GMMap();
		GMMap iMap3 = new GMMap();
		try{
			
			
			
			iMap3.putAll(GMServiceExecuter.call("SET_USER_GLOBALS_CLKS", new GMMap().put("USER_TYPE", "CLKS")));
			iMap3.put("USER_TYPE", "BNSPR");
			
			
			String tableName = "ISLEM_LISTESI";
			int k=0;
			int j=0;
			
			iMap2.put("SERVICE_NAME", "CLKS_BBT_CONFIRM");
			
			for (int i = 0; i < iMap.getSize(tableName); i++) {
				  
				if (iMap.getString(tableName, i,"SEC") != null &&  iMap.getString(tableName, i,"SEC").compareTo("1") ==0  ) {
				iMap2.put("islemNo", iMap.getString(tableName, i,
				"TX_NO"));
				iMap2.put("islemNoPTT", iMap.getString(tableName, i,
				"PTT_ISLEM_NO"));
				j=j+1;
				
				
				
				oMap.putAll(remoteCall("CLKS_BBT_CONFIRM",iMap2));
				
				//oMap.putAll(GMServiceExecuter.call("ADK_CALL_SERVICE", iMap2 ));

				if (oMap.getString("islemSonuc").compareTo("2") == 0){
				
				k = k+1;
				}
				}
			}
			
			if (k>0){
				oMap.put("SONUC", "1");
			}else{
				oMap.put("SONUC", "0");	
			}
			oMap.put("ISLEM_TALEP_SAYISI", j);	
			
			return oMap;
		}catch (Exception e){
			GMServiceExecuter.call("SET_USER_GLOBALS_BNSPR", iMap3);
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServiceExecuter.call("SET_USER_GLOBALS_BNSPR", iMap3);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
		

	}
	
	
	
	@GraymoundService("GET_BASARISIZ_PFT")
	public static GMMap clksPFTList(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{ ? = call PKG_RC_PTT.Pft_Tamamlanmamis_Islemler(?)}");
			int i=1;
			stmt.registerOutParameter(i++, -10);		
			
			if  (iMap.getString("ISLEM_TARIH").compareTo("")!=0)
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("ISLEM_TARIH").getTime()));
			else 
				stmt.setDate(i++, null);   

			stmt.execute();
			
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "ISLEM_LISTESI");
			return oMap;

		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		} catch (ParseException e) {
			throw ExceptionHandler.convertException(e);
		}
		 finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("SET_USER_GLOBALS_CLKS")
	public static GMMap SetUserGlobalsClks(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT.Set_User_Globals_CLKS_User(?,?,?)}");
			int i=1;		
			stmt.setString(1, iMap.getString("USER_TYPE"));
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			
			stmt.execute();
			
			oMap.put("KULLANICI_KOD", stmt.getString(2));
			oMap.put("KULLANICI_SUBE_KOD", stmt.getString(3));
			
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("SET_USER_GLOBALS_BNSPR")
	public static GMMap SetUserGlobalsBnspr(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_PTT.Set_User_Globals_BNSPR_User(?,?,?)}");
			int i=1;	
			stmt.setString(1, iMap.getString("USER_TYPE"));
			stmt.setString(2, iMap.getString("KULLANICI_KOD"));
			stmt.setString(3, iMap.getString("KULLANICI_SUBE_KOD"));
			
			stmt.execute();
			
			
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	public static GMMap remoteCall(String serviceName,GMMap iMap){
		GMConnection connection = null;
		GMMap oMap = new GMMap();
		
		 String BANKING_SERVICE = "DEALER"; 
		
		try {
			connection = GMConnection.getConnection(BANKING_SERVICE);
			
			oMap.putAll(connection.serviceCall(serviceName, iMap));
			
			
		
		} catch (IOException e) {	
			EftServices.throwGMBusssinessException(e.getMessage());
			//throw new com.graymound.util.GMRuntimeException(101, e.getMessage());		
		} finally {			
			if (connection != null) {	try { connection.close(); } catch (IOException e) { e.printStackTrace(); } }
		}
		return oMap;
	}
	

}
