package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.MuhKimlikKasaislemleriTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.ClksPftTx;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.dao.EftRumuz;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.PaygateConstants;
import tr.com.cs.aurora.rc.client.RC;
import tr.com.cs.aurora.rc.client.RCBag;
import tr.com.paygate.ArrayOfInstanceGroup;
import tr.com.paygate.ArrayOfSearchFilter;
import tr.com.paygate.ArrayOfSearchRequest;
import tr.com.paygate.DetailLevel;
import tr.com.paygate.FilterName;
import tr.com.paygate.InstanceGroup;
import tr.com.paygate.SearchFilter;
import tr.com.paygate.SearchRequest;
import tr.com.paygate.SearchType;
import tr.com.paygate.SearchEFTData;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.server.servlet.context.GMContext;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;


public class EftTRN2315Services {

	@GraymoundService("BNSPR_TRN2315_GET_INITIAL_VALUES")
	public static GMMap getInitialValues(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN2315.form_instance(?,?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.DATE);
			stmt.registerOutParameter(5, Types.DECIMAL);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.execute();

			oMap.put("SUBE_KODU", stmt.getString(1));
			oMap.put("BANKA_KODU", stmt.getString(2));
			oMap.put("BANKA_ADI", stmt.getString(3));
			oMap.put("EFT_TARIH", stmt.getDate(4));
			oMap.put("TRX_NO", stmt.getBigDecimal(5));
			oMap.put("OTOMATIK_BILDIRIM_OLUSTUR", stmt.getString(6));

			oMap.put("GONDEREN_SUBE_KODU", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2315/LOV_BOLUM", "EFT_KODU"));
			oMap.put("DI_GONDEREN_SUBE_KODU", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2315/LOV_BOLUM", "ADI"));
			oMap.put("GONDEREN_SEHIR", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2315/LOV_BOLUM", "IL_KODU"));
			oMap.put("DI_GONDEREN_SEHIR", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2315/LOV_BOLUM", "IL_ADI"));
			oMap.put("DURUM", "EKLENDI");

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN2315_GET_HESAP_BAKIYE_GORUNTULENSIN_MI")
	public static GMMap getHesaBakiyeGoruntulensinmi(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_hesap.personel_bakiye_gosterilsin(?)}");

			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setString(2, iMap.getString("HESAP_NO"));

			stmt.execute();

			oMap.put("HESAP_BAKIYE_GORUNSUN_MU", stmt.getBigDecimal(1));
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN2315_SET_MASRAF")
	public static GMMap setMasraf(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn	.prepareCall("{call PKG_TRN2315.MASRAF_OLUSTUR(?,?,?,?,?)}");

			stmt.setString(1, iMap.getString("TRX_NO"));
			stmt.setBigDecimal(2, iMap.getBigDecimal("ALIS_HES_NO"));
			stmt.setString(3, iMap.getString("ALIS_DOVIZ_KODU"));
			stmt.setBigDecimal(4, iMap.getBigDecimal("ALIS_TUTARI"));
			stmt.setBigDecimal(5, iMap.getBigDecimal("MUSTERI_NO"));
			
			stmt.execute();
			
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN2315_GET_EFT_INFO")
	public static GMMap getEftBilgi(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
			
			oMap.put("TRX_NO", eftEftTx.getTxNo());
			oMap.put("MUSTERI_NO" , eftEftTx.getMusteriNo());
	        oMap.put("MUSTERI_HESAP_NO" , eftEftTx.getMusteriHesapNo());
	        oMap.put("GONDEREN_VERGI_KIMLIK_NUMARASI" , eftEftTx.getGonderenVergiKimlikNumarasi());
	        oMap.put("DK_HESAP_NO" , eftEftTx.getDkHesapNo());
	        oMap.put("KUL_BAKIYE" , eftEftTx.getKulBakiye());
	        oMap.put("DISPLAY_MUSTERI_ADI" , LovHelper.diLov(eftEftTx.getMusteriNo(), "2315/LOV_MUSTERI", "UNVAN"));
		      
	        if (eftEftTx.getMusteriHesapNo() != null) {
				iMap.put("HESAP_NO", eftEftTx.getMusteriHesapNo());
				oMap.put("KULLANILABILIR_BAKIYE", GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", iMap).get(
						"KULLANILABILIR_BAKIYE"));
				oMap.put("DEFTER_BAKIYE", GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_DEFTER_BAKIYE", iMap).get(
						"DEFTER_BAKIYE"));
				oMap.put("IBAN" , LovHelper.diLov(eftEftTx.getMusteriHesapNo(),eftEftTx.getMusteriNo(), "2315/LOV_MUSTERI_HESAP_NO", "IBAN"));
			}
	        oMap.put("ISLEM_TIPI" , eftEftTx.getIslemTipi());
	        oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("GONDEREN" , eftEftTx.getGonderen());
	        oMap.put("GONDEREN_TELEFON" , eftEftTx.getGonderenTelefon());
	        oMap.put("GONDEREN_ADRES" , eftEftTx.getGonderenAdres());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("ACIKLAMA_2" , eftEftTx.getAciklama2());
	       // oMap.put("TALIMAT_FORMU_URETILECEK" , eftEftTx.getTalimatFormuUretilecek());
	        oMap.put("F_TALIMAT_ASLI_YOK" , GuimlUtil.convertToCheckBoxSelected(eftEftTx.getTalimatFormuUretilecek()));
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("ALICI_ADI" , eftEftTx.getAliciAdi());
	        oMap.put("ALICI_TELEFON_NO" , eftEftTx.getAliciTelefonNo());
	        oMap.put("ALICI_ADRES_1" , eftEftTx.getAliciAdres1());
	        oMap.put("ALICI_ADRES_2" , eftEftTx.getAliciAdres2());
	        oMap.put("ALICININ_DOGUM_TARIHI" , eftEftTx.getAlicininDogumTarihi());
	        oMap.put("KART_NO" , eftEftTx.getKartNo());
	        oMap.put("ALICI_HESAP_NO" , eftEftTx.getAliciHesapNo());
	        oMap.put("ALICI_IBAN" , eftEftTx.getAliciIban());
	        oMap.put("ALICI_BABA_ADI" , eftEftTx.getAliciBabaAdi());
	        oMap.put("TUTAR_SCR" , eftEftTx.getTutarScr());
	        oMap.put("MASRAF" , eftEftTx.getMasraf());
	        oMap.put("OTOMATIK_BILDIRIM_OLUSTUR" , eftEftTx.getOtomatikBildirimOlustur());
	        oMap.put("BILDIRIM_NO" , eftEftTx.getBildirimNo());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("TRX_NO" , eftEftTx.getTxNo());
	        oMap.put("GELEN_GIDEN" , eftEftTx.getGelenGiden());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("DURUM" , eftEftTx.getDurum());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("MASRAF_IC_DIS", eftEftTx.getMasrafIcDis());
	        oMap.put("ALICI_ANNE_ADI", eftEftTx.getAliciAnneAdi());
	        oMap.put("MASRAF_TAHSIL_SEKLI", eftEftTx.getMasrafTahsilSekli());
	        oMap.put("MASRAF_HESAP_NO", eftEftTx.getMasrafHesapNo());
	        oMap.put("ODEME_TURU", eftEftTx.getOdemeTuru());
	        oMap.put("KIMLIK_TIPI", eftEftTx.getKasaKimlikTipi());
	        oMap.put("ALICI_TC_KIMLIK_NO", eftEftTx.getAliciTcKimlikno());
	        oMap.put("ODEME_AYRINTISI", eftEftTx.getOdemeAyrintisi());
	        oMap.put("ILGILI_ISLEM_NUMARA", eftEftTx.getIlgiliIslemNumara());
	        oMap.put("GONDEREN_PASAPORT_NO", eftEftTx.getGonderenPasaportNo());
	        oMap.put("GONDEREN_DOGUM_YERI", eftEftTx.getGonderenDogumYeri());
	        oMap.put("GONDEREN_DOGUM_TARIHI", eftEftTx.getGonderenDogumTarihi());
	        oMap.put("GONDEREN_MUSTERI_NUMARASI", eftEftTx.getGonderenMusteriNumarasi());
	        if("E".equals(eftEftTx.getFIbanBilinmiyor()))
	        	oMap.put("FIBAN_BILINMIYOR", "true");
	        else
	        	oMap.put("FIBAN_BILINMIYOR", "false");
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
	        oMap.put("KAS_MESAJ_KODU", eftEftTx.getKasMesajKodu());
	        oMap.put("ISL_EK_MUSTERI_ADI", eftEftTx.getIslEkMusteriAdi());
	        oMap.put("ISL_EK_MUSTERI_HESAP", eftEftTx.getIslEkMusteriHesap());
	        oMap.put("ISL_EK_MUSTERI_KIMLIK", eftEftTx.getIslEkMusteriKimlik());
	        oMap.put("BLOKE_REFERANS", eftEftTx.getDborReferans());
			oMap.put("IP_NO", eftEftTx.getIpNo());
			oMap.put("FRAUD_NEDENI", eftEftTx.getFraudNedeni());
			oMap.put("ISLEM_KAYNAK", eftEftTx.getIslemKaynak());
			
			oMap.put("KOLAS_REFERANSI", eftEftTx.getKolasReferansi());
			oMap.put("KOLAY_ADRES_TIPI", eftEftTx.getKolayAdresTipi());
			oMap.put("KOLAY_ADRES_DEGERI", eftEftTx.getKolayAdresDegeri());
	        
	        
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN2315_GET_EFT_INFO_WITH_RUMUZ")
	public static GMMap getEftInfoWithRumuz(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftRumuz eftRumuz = (EftRumuz)session.createCriteria(EftRumuz.class).add(Restrictions.eq("eftRumuzId", iMap.getBigDecimal("ID"))).uniqueResult();
			
			GMMap oMap = new GMMap();
			
			oMap.putAll(getInitialValues(iMap));
			oMap.put("MUSTERI_NO" , eftRumuz.getMusteriNo());
	        oMap.put("MUSTERI_HESAP_NO" , eftRumuz.getMusteriHesapNo());
	        oMap.put("DK_HESAP_NO" , eftRumuz.getDkHesapNo());
	        oMap.put("KUL_BAKIYE" , eftRumuz.getKulBakiye());
	        oMap.put("DISPLAY_MUSTERI_ADI" , LovHelper.diLov(eftRumuz.getMusteriNo(), "2315/LOV_MUSTERI", "UNVAN"));
	        oMap.put("GONDEREN_VERGI_KIMLIK_NUMARASI" , LovHelper.diLov(eftRumuz.getMusteriNo(), "2315/LOV_MUSTERI", "VKN"));
	        oMap.put("IBAN", LovHelper.diLov(eftRumuz.getMusteriHesapNo(),eftRumuz.getMusteriNo(), "2315/LOV_MUSTERI_HESAP_NO", "IBAN"));
		      
	        if (eftRumuz.getMusteriHesapNo() != null) {
				iMap.put("HESAP_NO", eftRumuz.getMusteriHesapNo());
				oMap.put("KULLANILABILIR_BAKIYE", GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_KULLANILABILIR_BAKIYE", iMap).get(
						"KULLANILABILIR_BAKIYE"));
				oMap.put("DEFTER_BAKIYE", GMServiceExecuter.execute(
						"BNSPR_COMMON_GET_DEFTER_BAKIYE", iMap).get(
						"DEFTER_BAKIYE"));
			}
	        oMap.put("ISLEM_TIPI" , eftRumuz.getIslemTipi());
	        oMap.put("GONDEREN_SUBE" , eftRumuz.getGonderenSube());
	        oMap.put("GONDEREN_BANKA" , eftRumuz.getGonderenBanka());
	        oMap.put("GONDEREN_SEHIR" , eftRumuz.getGonderenSehir());
	        oMap.put("GONDEREN" , eftRumuz.getGonderen());
	        oMap.put("GONDEREN_TELEFON" , eftRumuz.getGonderenTelefon());
	        oMap.put("GONDEREN_ADRES" , eftRumuz.getGonderenAdres());
	        oMap.put("ACIKLAMA" , eftRumuz.getAciklama());
	        oMap.put("ALAN_BANKA_KODU" , eftRumuz.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftRumuz.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftRumuz.getAlanSubeKodu());
	        oMap.put("ALICI_ADI" , eftRumuz.getAliciAdi());
	        oMap.put("ALICI_TELEFON_NO" , eftRumuz.getAliciTelefonNo());
	        oMap.put("ALICI_ADRES_1" , eftRumuz.getAliciAdres1());
	        oMap.put("ALICI_ADRES_2" , eftRumuz.getAliciAdres2());
	        oMap.put("KART_NO" , eftRumuz.getKartNo());
	        oMap.put("ALICI_HESAP_NO" , eftRumuz.getAliciHesapNo());
	        oMap.put("ALICI_IBAN" , eftRumuz.getAliciIban());
	        oMap.put("ALICI_BABA_ADI" , eftRumuz.getAliciBabaAdi());

	        oMap.put("MESAJ_KODU" , eftRumuz.getMesajKodu());
	        oMap.put("MASRAF_IC_DIS", eftRumuz.getMasrafIcDis());
	        oMap.put("ALICI_ANNE_ADI", eftRumuz.getAliciAnneAdi());
	        oMap.put("MASRAF_TAHSIL_SEKLI", eftRumuz.getMasrafTahsilSekli());
	        oMap.put("MASRAF_HESAP_NO", eftRumuz.getMasrafHesapNo());
	        oMap.put("ALICININ_DOGUM_TARIHI", eftRumuz.getAliciDogumTarihi());
	        oMap.put("ALICI_TC_KIMLIK_NO" , eftRumuz.getAliciTcKimlikNo());
	        if("E".equals(eftRumuz.getFIbanBilinmiyor()))
	        	oMap.put("FIBAN_BILINMIYOR", "true");
	        else
	        	oMap.put("FIBAN_BILINMIYOR", "false");
	        
	        oMap.putAll(EftServices.getEftDiValues(eftRumuz.getGonderenBanka(), eftRumuz.getGonderenSube(), eftRumuz.getGonderenSehir(), eftRumuz.getAlanBankaKodu(),eftRumuz.getAlanSubeKodu(), eftRumuz.getAlanSehirKodu()));
			
			return oMap;
			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN2315_GET_SORGU_NO") 
	public static GMMap getSorguNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection connSql = null;
		Connection conn = null;
		CallableStatement stmtSql = null;
		try {
			conn = DALUtil.getGMConnection();
			stmtSql = conn.prepareCall("{? = call Pkg_Eft.eft_sistem_bilgi}");
			stmtSql.registerOutParameter(1, java.sql.Types.VARCHAR );
			stmtSql.execute();
			if(("W").equals(stmtSql.getObject(1))){
		    //Map<?, ? > servisMap = GMServiceExecuter.execute("BNSPR_TRN2315_GET_WINBANK_SQL_SERVER_CONNECTION_PARAMETERS", new HashMap<String, Object>());
		    //Class.forName((String)servisMap.get("DRIVER_CLASS"));
			//connSql = DriverManager.getConnection((String)servisMap.get("CONNECTION_STRING"),(String)servisMap.get("USERNAME"),(String)servisMap.get("PASSWORD")); 
			connSql = DALUtil.getWinbankConnection();
			StringBuffer sb = new StringBuffer();
			sb.append("{ call dbbanking..up_EGSEFTSorguRef ('BnkEFT', ?) }");
			stmtSql = connSql.prepareCall(sb.toString());
			stmtSql.registerOutParameter(1, Types.VARCHAR);
			stmtSql.execute();
			//connSql.commit(); hata verdi MHA 050509
			String ref = stmtSql.getString(1);
			String sorguNo = ref.substring(ref.length() - 8,  ref.length());
			oMap.put("SORGU_NO", sorguNo);
			oMap.put("REF", ref);
			//stmtSql.close();
			//connSql.close();
		}else if(("B").equals(stmtSql.getObject(1))){
			stmtSql = conn.prepareCall("{? = call pkg_genel_pr.genel_kod_al(?)}");
			stmtSql.registerOutParameter(1, java.sql.Types.VARCHAR );
			stmtSql.setString(2, "EFT-SORGU");
			stmtSql.execute();
			oMap.put("SORGU_NO",stmtSql.getObject(1));
			//oMap.put("REF", "");
		}
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(stmtSql);
			GMServerDatasource.close(connSql);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN2315_GET_WINBANK_SQL_SERVER_CONNECTION_PARAMETERS")
	public static GMMap serviceMethodName(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			oMap.put("DRIVER_CLASS", "com.microsoft.jdbc.sqlserver.SQLServerDriver");
			oMap.put("CONNECTION_STRING", "jdbc:microsoft:sqlserver://192.168.0.5:1433;databaseName=dbbanking");
			oMap.put("USERNAME", "b-inspire");
			oMap.put("PASSWORD", "b-inspire");
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN2315_EFT_ONCEDEN_GIRILMIS_MI")
	public static GMMap eftOncedenGirilmisMi(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn	.prepareCall("{? = call pkg_trn2315.oncedenGirilmisMi(?,?,?,?,?,?)}");
			stmt.registerOutParameter(1, java.sql.Types.NUMERIC);
			stmt.setString(2, iMap.getString("MUSTERI_NO"));
			stmt.setString(3, iMap.getString("ALICI_BANKA_KODU"));
			stmt.setString(4, iMap.getString("ALICI_SUBE_KODU"));
			stmt.setString(5, iMap.getString("ALICI_HESAP_NO"));
			stmt.setBigDecimal(6, iMap.getBigDecimal("TUTAR"));
			
			if ((iMap.get("EFT_TARIHI") != null)) 
				stmt.setDate(7, new Date( iMap.getDate("EFT_TARIHI").getTime()));
			else 
				stmt.setDate(7, null);
			
			stmt.execute();
			oMap.put("SORGU_NO", stmt.getBigDecimal(1));
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN2315_GET_IBAN_KODU")
	public static GMMap ibanBankaKodu(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn	.prepareCall("{call pkg_eft.EFT_IBAN_Banka_Sube_Sehir_Al(?,?,?,?,?,?,?)}");
			stmt.setString(1, iMap.getString("IBAN"));
			stmt.registerOutParameter(2, java.sql.Types.VARCHAR);
			stmt.registerOutParameter(3, java.sql.Types.VARCHAR);
			stmt.registerOutParameter(4, java.sql.Types.VARCHAR);
			stmt.registerOutParameter(5, java.sql.Types.VARCHAR);
			stmt.registerOutParameter(6, java.sql.Types.VARCHAR);
			stmt.registerOutParameter(7, java.sql.Types.VARCHAR);
			stmt.execute();
			oMap.put("BANKA_KODU", stmt.getString(2));
			oMap.put("BANKA_ADI" , stmt.getString(5));
			oMap.put("SEHIR_KOD", stmt.getString(4));
			oMap.put("SEHIR_ADI" ,  stmt.getString(7));
			oMap.put("SUBE_KODU", stmt.getString(3));
			oMap.put("SUBE_ADI" , stmt.getString(6));
		//	oMap.put("IBAN_RESPONSE" , "2");
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2315_AFTER_CANCELATION")
	public static GMMap afterCancelation(GMMap iMap){
		RCBag bag = new RCBag();

		try{
			Session session = DAOSession.getSession("BNSPRDal");
			EftEftTx eftEftTx = (EftEftTx) session.get(EftEftTx.class, iMap.getBigDecimal("ISLEM_NO"));

			if (("CS").equals(eftEftTx.getEftRef())) {
				bag.put("REFERENCE_ID",eftEftTx.getTxNo());
				bag.setServiceName("AB_EFT_SET_EFT_RESULT "); //CS - EFT Geri Bildirim Servisi
            	RC.execute(bag, "configuration/RemoteCaller.properties"); 
			}
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN2315_TU_REFERANS")
	public static GMMap getTUReferans(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_tu.f_islem_tu_referans_bul(?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.setString(2, iMap.getString("TX_NO"));

			stmt.execute();

			oMap.put("TU_REFERANS", stmt.getString(1));
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_GET_KAS_MESAJ_KODU") 
	public static GMMap getKasMesajKodu(GMMap iMap) {
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmtSql = null;
		try {
			conn = DALUtil.getGMConnection();
			stmtSql = conn.prepareCall("{? = call pkg_kas_eft_mesaj.EFT_KAS_Mesaj_Turu_Al(?,?)}");
			stmtSql.registerOutParameter(1, Types.VARCHAR);
			stmtSql.setString(2, iMap.getString("MESAJ_KODU"));
			stmtSql.setString(3, iMap.getString("ODEME_TURU"));
			stmtSql.execute();
			oMap.put("KAS_MESAJ_KODU", stmtSql.getString(1));
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(stmtSql);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_GET_BILDIRIM_TUTAR")
	public static GMMap getBildirimTutar(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			
			String func="{? = call PKG_TRN2373.BILDIRIMTUTARAL}";
			BigDecimal tutar = BigDecimal.valueOf((Long) DALUtil.callNoParameterFunction(func, Types.BIGINT));
			if (iMap.getBigDecimal("TUTAR").compareTo(tutar)>=0){
				oMap.put("OTO_BILDIRIM", "H");
			}
			else{
				oMap.put("OTO_BILDIRIM", "E");
			}
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN2315_EFT_PAYGATE_CHECK")
	public static GMMap eft2315PaygateCheck(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
    		DateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
			SearchEFTData searchEftData = new SearchEFTData();
			String ucuncuSahis = null;
            if (StringUtils.isBlank(iMap.getString("MUSTERI_NO"))) {
    			Session session = DAOSession.getSession("BNSPRDal");
            
    			List<MuhKimlikKasaislemleriTx> muhKimlikKasaIslemleriTxList = session.createCriteria(MuhKimlikKasaislemleriTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).add(Restrictions.eq("id.talimatVekalet", "H")).add(Restrictions.eq("kimlikTipi", new BigDecimal(5))).list();

    			if (muhKimlikKasaIslemleriTxList != null) {
	    			for (MuhKimlikKasaislemleriTx muhKimlikKasaislemleriTx : muhKimlikKasaIslemleriTxList) {

					if (StringUtils.isNotBlank(muhKimlikKasaislemleriTx.getUnvan()))
						ucuncuSahis = muhKimlikKasaislemleriTx.getUnvan();
					else {
						if (StringUtils.isNotBlank(muhKimlikKasaislemleriTx.getIkinciIsim()))
							ucuncuSahis = (muhKimlikKasaislemleriTx.getIsim() + " " + muhKimlikKasaislemleriTx.getIkinciIsim() + " " + muhKimlikKasaislemleriTx.getSoyad());
						else
							ucuncuSahis= (muhKimlikKasaislemleriTx.getIsim() + " " + muhKimlikKasaislemleriTx.getSoyad());
					}
				}
    		  }
            }	
            if (StringUtils.isNotBlank(ucuncuSahis)){
            	searchEftData.setComment(iMap.getString("ACIKLAMA")+ " 3. �ah�s EFT - ��lemi Yapan "+ucuncuSahis); 
            }else{
            	searchEftData.setComment(StringUtils.isBlank(iMap.getString("ACIKLAMA")) ? "":iMap.getString("ACIKLAMA"));
            }
            searchEftData.setBeneficiaryName(iMap.getString("ALICI"));
            searchEftData.setCustomerName(iMap.getString("GONDEREN"));
            searchEftData.setCustomerIdentificationNo(iMap.getString("MUSTERI_NO"));
            searchEftData.setAmount(iMap.getBigDecimal("TUTAR"));
            searchEftData.setReceiverBankCode(iMap.getString("ALAN_BANKA"));
            searchEftData.setSenderBankCode((StringUtils.isBlank(iMap.getString("GONDEREN_BANKA"))?"AKTIF YATIRIM BANKASI A.S.":iMap.getString("GONDEREN_BANKA")));
            //searchEftData.setSenderBankCode(iMap.getString("GONDEREN_BANKA","AKTIF YATIRIM BANKASI A.S."));
            searchEftData.setValueDate(getXmlGregorianCalendar(iMap.getDate("EFT_TARIH")));
            searchEftData.setBeneficiaryIdentificationNo(iMap.getString("ALICI_TCKN"));
            searchEftData.setApplicationName(iMap.getString("TRX_NAME","2315"));
            searchEftData.setDetailLevel(DetailLevel.FULL);
            searchEftData.setExternalId(iMap.getString("TRX_NO"));
            searchEftData.setInstanceId(PaygateConstants.LIST_GROUP_AKUSTIK_4);
            searchEftData.setDirection("O");
            
            ArrayOfSearchFilter arrOfSearchFilter = new ArrayOfSearchFilter();
            //MUSTERI_NO paygate search filter
            if (StringUtils.isNotBlank(iMap.getString("MUSTERI_NO"))) {
	            SearchFilter sfMusteriNo = new SearchFilter();
	            sfMusteriNo.setKey(FilterName.CUSTOMER_NUMBER);
	            sfMusteriNo.setValue(iMap.getString("MUSTERI_NO"));
	            sfMusteriNo.setLogicalOperator("AND");
	            sfMusteriNo.setIsFeatureFilter(false);
	            arrOfSearchFilter.getSearchFilter().add(sfMusteriNo);
            }  
            //ALICI_TCKN paygate search filter
            if (StringUtils.isNotBlank(iMap.getString("ALICI_TCKN"))) {
	            SearchFilter sfAliciTckn = new SearchFilter();
	            sfAliciTckn.setKey(FilterName.BENEFICIARY_NATIOANAL_ID);
	            sfAliciTckn.setValue(iMap.getString("ALICI_TCKN"));
	            sfAliciTckn.setLogicalOperator("AND");
	            sfAliciTckn.setIsFeatureFilter(false);
	            arrOfSearchFilter.getSearchFilter().add(sfAliciTckn);
            }
            //ALICI_DTARIH paygate search filter
            if (StringUtils.isNotBlank(iMap.getString("ALICI_DTARIH"))) {
	            SearchFilter sfAliciDtarih = new SearchFilter();
	            sfAliciDtarih.setKey(FilterName.BENEFICIARY_DATE_OF_BIRTH);
	            sfAliciDtarih.setValue(sdf.format(iMap.getDate("ALICI_DTARIH")));
	            sfAliciDtarih.setLogicalOperator("AND");
	            sfAliciDtarih.setIsFeatureFilter(false);
	            arrOfSearchFilter.getSearchFilter().add(sfAliciDtarih);
            }
            //GONDEREN_TCKN paygate search filter
            if (StringUtils.isNotBlank(iMap.getString("GONDEREN_TCKN"))) {
	            SearchFilter sfGonderenTckn = new SearchFilter();
	            sfGonderenTckn.setKey(FilterName.CUSTOMER_NATIONAL_ID);
	            sfGonderenTckn.setValue(iMap.getString("GONDEREN_TCKN"));
	            sfGonderenTckn.setLogicalOperator("AND");
	            sfGonderenTckn.setIsFeatureFilter(false);
	            arrOfSearchFilter.getSearchFilter().add(sfGonderenTckn);
            }
            //GONDEREN_DTARIH paygate search filter
            if (StringUtils.isNotBlank(iMap.getString("GONDEREN_DTARIH"))) {
	            SearchFilter sfGonderenDtarih = new SearchFilter();
	            sfGonderenDtarih.setKey(FilterName.CUSTOMER_DATE_OF_BIRTH);
	            sfGonderenDtarih.setValue(sdf.format(iMap.getDate("GONDEREN_DTARIH")));
	            sfGonderenDtarih.setLogicalOperator("AND");
	            sfGonderenDtarih.setIsFeatureFilter(false);
	            arrOfSearchFilter.getSearchFilter().add(sfGonderenDtarih);
            }
            
            searchEftData.setFilters(arrOfSearchFilter);

            GMMap amlMap = new GMMap(); 
            amlMap.put("SEARCH_EFT_DATA", searchEftData);             
            oMap = GMServiceExecuter.call("BNSPR_EXT_FINEKSUS_SEARCH_EFT_DATA", amlMap);
            return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}	
	
	@GraymoundService("BNSPR_TRN2315_EFT_PAYGATE_CHECK_OLD")
	public static GMMap eft2315PaygateCheckOld(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		List<SearchRequest> searchRequestList = new ArrayList<SearchRequest>();
		try {
            ArrayOfSearchRequest arrayOfSearchRequest = new ArrayOfSearchRequest();

			SearchRequest srGonderen = new SearchRequest();
            srGonderen.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_2, SearchType.GENERIC_NAME));
            srGonderen.setValue(iMap.getString("GONDEREN"));
            if (StringUtils.isNotBlank(iMap.getString("MUSTERI_NO"))) {
                   ArrayOfSearchFilter arrOfSearchFilter = new ArrayOfSearchFilter();
                   SearchFilter sf = new SearchFilter();
                   sf.setKey(FilterName.CUSTOMER_NUMBER);
                   sf.setValue(iMap.getString("MUSTERI_NO"));
                   sf.setLogicalOperator("AND");
                   arrOfSearchFilter.getSearchFilter().add(sf);
                   srGonderen.setFilters(arrOfSearchFilter);
            }
			searchRequestList.add(srGonderen);
			
			SearchRequest srAlici = new SearchRequest();
			srAlici.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_2, SearchType.GENERIC_NAME));
			srAlici.setValue(iMap.getString("ALICI"));
			searchRequestList.add(srAlici);

//			SearchRequest srAlanBanka = new SearchRequest();
//			srAlanBanka.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_2, SearchType.GENERIC_NAME));
//			srAlanBanka.setValue(iMap.getString("ALAN_BANKA"));
//			searchRequestList.add(srAlanBanka);

			if (StringUtils.isNotBlank(iMap.getString("ACIKLAMA"))) {
				SearchRequest srAciklama = new SearchRequest();
				srAciklama.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_2, SearchType.TEXT));
				srAciklama.setValue(iMap.getString("ACIKLAMA"));
				searchRequestList.add(srAciklama);				
			}
			
            arrayOfSearchRequest.getSearchRequest().addAll(searchRequestList);
            
            GMMap amlMap = new GMMap(); 
            amlMap.put("TRX_NAME","2315"); 
            amlMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
            amlMap.put("SEARCH_REQUEST_LIST", arrayOfSearchRequest);
             
            oMap = GMServiceExecuter.call("BNSPR_EXT_FINEKSUS_SEARCH_BULK_DATA", amlMap);
            return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}	

	private static ArrayOfInstanceGroup getArrOfInstanceGroupWithTypeAndName(String instanceName, SearchType searchType) {
		ArrayOfInstanceGroup instanceGroupListArray = new ArrayOfInstanceGroup();
		List<InstanceGroup> instanceGroupList = new ArrayList<InstanceGroup>();
		InstanceGroup ig = new InstanceGroup();
		ig.setDetailLevel(DetailLevel.FULL);
		ig.setInstanceName(instanceName);
		ig.setSearchType(searchType);
		instanceGroupList.add(ig);
		instanceGroupListArray.getInstanceGroup().addAll(instanceGroupList);
		return instanceGroupListArray;
	}
	
	public static XMLGregorianCalendar getXmlGregorianCalendar(java.util.Date date) throws DatatypeConfigurationException {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(date);
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(c);	
	}

	@GraymoundService("BNSPR_TRN2315_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmtSql = null;

		try {
			conn = DALUtil.getGMConnection();
			stmtSql = conn.prepareCall("{? = call pkg_rc_eft.BONO_MASRAFSIZ_EFT_MI(?)}");
			stmtSql.registerOutParameter(1, Types.VARCHAR);
			stmtSql.setBigDecimal(2, iMap.getBigDecimal("ISLEM_NO"));
			stmtSql.execute();
            if ("E".equals(stmtSql.getString(1))) 
            {
				iMap.put("EVENT_TYPE_NO", "88");
				iMap.put("EVENT_REF_NO", iMap.getBigDecimal("ISLEM_NO"));
				GMServiceExecuter.executeAsync("BNSPR_CORE_EVENT_CREATE_EVENT", iMap);
            }
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally{
			GMServerDatasource.close(stmtSql);
			GMServerDatasource.close(conn);
		}
	}	
}