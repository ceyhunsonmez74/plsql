package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.aktifbank.bnspr.dao.EftEuptOdemeTx;
import tr.com.aktifbank.bnspr.dao.EftGuncellemeTx;
import tr.com.aktifbank.bnspr.dao.EftOdemeDetayTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2347Services {
	
	
	
	@GraymoundService("BNSPR_TRN2347_SAVE")
	public static GMMap Save (GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			EftEuptOdemeTx objEftEuptOdemeTx = (EftEuptOdemeTx)session.get(EftEuptOdemeTx.class, iMap.getBigDecimal("TRX_NO"));
			if(objEftEuptOdemeTx == null) {
				objEftEuptOdemeTx = new EftEuptOdemeTx();
			}
			objEftEuptOdemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			objEftEuptOdemeTx.setEftTxno(iMap.getBigDecimal("EFT_TX_NO"));
			objEftEuptOdemeTx.setAdSoyad(iMap.getString("ALICI_ADSOYAD"));
			objEftEuptOdemeTx.setDurum(iMap.getString("DURUM"));
			objEftEuptOdemeTx.setMesajKodu(iMap.getString("MESAJ_KODU"));
			objEftEuptOdemeTx.setEuptHesapNo(iMap.getString("EUPT_HESAPNO"));
			objEftEuptOdemeTx.setPasaportNo(iMap.getString("PASAPORT_NO"));
			objEftEuptOdemeTx.setTcKimlikNo(iMap.getString("TC_KIMLIK_NO"));
			objEftEuptOdemeTx.setYkn(iMap.getString("YKN"));
			objEftEuptOdemeTx.setTutar(iMap.getBigDecimal("TUTAR"));

			session.saveOrUpdate(objEftEuptOdemeTx);
			session.flush();
			iMap.put("TRX_NAME", "2347");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		}
	}
	@GraymoundService("BNSPR_TRN2347_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal" );
			EftEuptOdemeTx objEftEuptOdemeTx = (EftEuptOdemeTx)session.get(EftEuptOdemeTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("EFT_TXNO",objEftEuptOdemeTx.getEftTxno());
			oMap.put("EUPT_HESAPNO",objEftEuptOdemeTx.getEuptHesapNo());
			oMap.put("TC_KIMLIK_NO",objEftEuptOdemeTx.getTcKimlikNo());
			oMap.put("YKN",objEftEuptOdemeTx.getYkn());
			oMap.put("PASAPORT_NO",objEftEuptOdemeTx.getPasaportNo());
			oMap.put("ALICI_ADSOYAD",objEftEuptOdemeTx.getAdSoyad());
		    
		    return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		}
	}


	
	@GraymoundService("BNSPR_TRN2347_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		CallableStatement stmt2 = null;
		CallableStatement stmt3 = null;  
		ResultSet rSet = null;
		String cardDurumu;
		boolean result;
		BigDecimal txNo = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			EftEuptOdemeTx objEftEuptOdemeTx = (EftEuptOdemeTx)session.get(EftEuptOdemeTx.class, iMap.getBigDecimal("ISLEM_NO"));
			if(objEftEuptOdemeTx == null) {
				objEftEuptOdemeTx = new EftEuptOdemeTx();
			}
			

				conn = DALUtil.getGMConnection();
				    txNo = objEftEuptOdemeTx.getEftTxno();  
					if (("EUPT_SORUN").equals(objEftEuptOdemeTx.getDurum())) {
						try {
							GMMap sMap = new GMMap();
							
						    sMap.put("KART_NO", objEftEuptOdemeTx.getEuptHesapNo());	
							sMap.put("TUTAR", objEftEuptOdemeTx.getTutar());
							sMap.put("ALICI_ADI", objEftEuptOdemeTx.getAdSoyad());
							sMap.put("MESAJ_KODU", objEftEuptOdemeTx.getMesajKodu());
							sMap.put("TRX_NO", objEftEuptOdemeTx.getEftTxno());
							sMap = GMServiceExecuter.call(
									"BNSPR_EUPT_LOAD_EFT_MONEY_TO_EUPT", sMap);
							result = sMap.getBoolean("RESULT");
							if (result)
								cardDurumu = "EUPT_OK";
							else
								cardDurumu = "EUPT_SORUN";
						} catch (Exception e) {
							cardDurumu = "EUPT_SORUN";
						}

						stmt2 = conn
								.prepareCall("{call PKG_eupt.EUPT_CARD_EFT_DURUM_UPDATE(?,?)}");
						stmt2.setBigDecimal(1, txNo);
						stmt2.setString(2, cardDurumu);
						stmt2.execute();
						GMServerDatasource.close(stmt2);

						if (cardDurumu == "EUPT_OK") {
							stmt3 = conn
									.prepareCall("{call PKG_eupt.KRED_KART_MUHASEBE(?,?,?)}");
							stmt3.setBigDecimal(1, txNo);
							stmt3.setBigDecimal(2, null);
							stmt3.setBigDecimal(3, objEftEuptOdemeTx.getTxNo());
							
							stmt3.execute();
							GMServerDatasource.close(stmt3);
						}
					}
			
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(stmt2);
			GMServerDatasource.close(stmt3);
			GMServerDatasource.close(conn);
		}

	}
		
	
	@GraymoundService("BNSPR_TRN2347_AFTER_CANCELATION")
	public static GMMap afterCancellation(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt2 = null;
		ResultSet rSet = null;
		BigDecimal txNo = null;
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			EftEuptOdemeTx objEftEuptOdemeTx = (EftEuptOdemeTx)session.get(EftEuptOdemeTx.class, iMap.getBigDecimal("ISLEM_NO"));
			
			
			if(objEftEuptOdemeTx == null) {
				objEftEuptOdemeTx = new EftEuptOdemeTx();
			}
				conn = DALUtil.getGMConnection();
				    txNo = objEftEuptOdemeTx.getEftTxno();  
					
				    GMMap sMap = new GMMap();
							
				    sMap.put("TRX_NO", txNo);
				    sMap.put("TYPE", "C");
					sMap = GMServiceExecuter.call(
							"BNSPR_EUPT_EUPT_ISLEM_IPTAL_CHECK", sMap);
				
					GMMap sMap2 = new GMMap();
					
				    sMap2.put("TRX_NO", txNo);
				    sMap2.put("TYPE", "C");
					sMap2 = GMServiceExecuter.call(
							"BNSPR_EUPT_EUPT_ISLEM_IPTAL", sMap2);
								
				
					/*stmt2 = conn
					.prepareCall("{call PKG_eupt.EUPT_CARD_EFT_DURUM_UPDATE(?,?)}");
					stmt2.setBigDecimal(1, txNo);
					stmt2.setString(2, "EUPT_SORUN");
					stmt2.execute();
					GMServerDatasource.close(stmt2); */
					
					
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt2);
		}

	}	
		
	
	
	
}
