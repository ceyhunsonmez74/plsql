package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class EftTRN2368Services {
	@GraymoundService("BNSPR_TRN2368_GET_EFT_MERKEZ_MI")
	public static GMMap getEftMerkez(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_eft.is_eft_merkezi(?)}");

			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setString(2, iMap.getString("SUBE_KODU"));

			stmt.execute();

			oMap.put("EFT_MERKEZ_MI", stmt.getBigDecimal(1));
			oMap.put("K_ALAN_SUBE", LovHelper.diLov(iMap.getString("SUBE_KODU"), "2362/LOV_BOLUM", "EFT_KODU"));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN2368_GET_EFT_MESAJLARI")
	public static GMMap getEftList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			StringBuilder query = new StringBuilder();

			query.append("select tx_no,sorgu_no,mesaj_kodu,tutar,gonderen_banka,alici_hesap_no,alici_adi,pkg_genel_pr.banka_adi_al_eft_hatasiz(gonderen_banka) as banka_adi,Pkg_Tx.islem_kod(tx_no) ekran_no " );
			query.append("from EFT_EFT_TX e ");
			query.append("where  gelen_giden = 'GELEN' ");
			query.append("and substr('00000'||alan_sube_kodu,-5) = NVL(?,substr('00000'||alan_sube_kodu,-5)) ");
			
			if(iMap.getString("K_MESAJ_KODU")!=null && !iMap.getString("K_MESAJ_KODU").equals(""))query.append("and rtrim(mesaj_kodu) = NVL(?,mesaj_kodu) ");
			else query.append("and rtrim(mesaj_kodu) in (select rtrim(mesaj_kodu) from eft_mesaj_tanim_tx where odeme_yap = ?) ");
			query.append("and sorgu_no >= NVL(?,0) ");
			query.append("and durum not in ('TAMAM','MUHASEBE') ");
			query.append("and NVL(musteri_no,0) = NVL(?,NVL(musteri_no,0)) ");
			query.append("and NVL(musteri_hesap_no,0) = NVL(?,NVL(musteri_hesap_no,0)) ");
			query.append("and gonderen_banka = NVL(?,gonderen_banka) ");
			query.append("and tutar between NVL(?,tutar) and NVL(?,tutar) ");
			query.append("and exists (select durum from muh_islem m where m.numara = e.tx_no and m.durum='E')");
			
			stmt = conn.prepareCall(query.toString());

			stmt.setString(1, iMap.getString("K_ALAN_SUBE"));
			if(iMap.getString("K_MESAJ_KODU")!=null && !iMap.getString("K_MESAJ_KODU").equals("")){
				stmt.setString(2, iMap.getString("K_MESAJ_KODU"));
			}else {
				stmt.setString(2, "H");
			}
			stmt.setString(3, iMap.getString("K_SORGU_NO"));
			stmt.setString(4, iMap.getString("K_MUSTERI_NO"));
			stmt.setString(5, iMap.getString("K_MUSTERI_HESAP_NO"));
			stmt.setString(6, iMap.getString("K_GONDEREN_BANKA"));
			
			if (iMap.getBigDecimal("K_MIN_TUTAR").compareTo(BigDecimal.ZERO)==0) {
				stmt.setBigDecimal(7, null);
			} else {
				stmt.setBigDecimal(7, iMap.getBigDecimal("K_MIN_TUTAR"));
			}

			if (iMap.getBigDecimal("K_MAX_TUTAR").compareTo(BigDecimal.ZERO)==0) {
				stmt.setBigDecimal(8, null);
			} else {
				stmt.setBigDecimal(8, iMap.getBigDecimal("K_MAX_TUTAR"));
			}
			
			rSet = stmt.executeQuery();

			GMMap oMap = new GMMap();
			String tableName = "EFT_MESAJLARI";
			int row = 0;
			BigDecimal toplamTutar = new BigDecimal(0);
			while (rSet.next()) {
				oMap.put(tableName, row, "EKRAN_NO", rSet.getString("ekran_no"));
				oMap.put(tableName, row, "TRX_NO", rSet.getString("tx_no"));
				oMap.put(tableName, row, "SORGU_NO", rSet.getString("sorgu_no"));
				oMap.put(tableName, row, "MESAJ_KODU", rSet.getString("mesaj_kodu").trim());
				oMap.put(tableName, row, "TUTAR", rSet.getString("TUTAR"));			
				oMap.put(tableName, row, "GONDEREN_BANKA_KODU", rSet.getString("gonderen_banka"));
				oMap.put(tableName, row, "BANKA_ADI", rSet.getString("banka_adi"));
				oMap.put(tableName, row, "ALICI_HESAP_NO", rSet.getString("alici_hesap_no"));
				oMap.put(tableName, row, "ALICI_ADI", rSet.getString("alici_adi"));
				
				toplamTutar = toplamTutar.add(rSet.getBigDecimal("tutar"));
				row++;
			}
			oMap.put("TOPLAM_TUTAR", toplamTutar);
			oMap.put("KAYIT_SAYISI", row);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
