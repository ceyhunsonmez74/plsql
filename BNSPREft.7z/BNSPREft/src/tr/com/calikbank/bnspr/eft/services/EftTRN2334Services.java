package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2334Services {
	@GraymoundService("BNSPR_TRN2334_GET_EFT_INFO")
	public static GMMap getEftInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			GMMap oMap = new GMMap();
			oMap.put("ONCELIK", eftEftTx.getOncelik());
			oMap.put("DURUM", eftEftTx.getDurum());
			oMap.put("EFT_TARIH", eftEftTx.getEftTarih());
			oMap.put("SORGU_NO", eftEftTx.getSorguNo());
			oMap.put("GELEN_GIDEN", eftEftTx.getGelenGiden());
			oMap.put("MESAJ_KODU", eftEftTx.getMesajKodu());
			oMap.put("TUTAR", eftEftTx.getTutar());
			oMap.put("ACIKLAMA", eftEftTx.getAciklama());
			oMap.put("REFERANS_NO", eftEftTx.getReferansNo());
			oMap.put("ALAN_SUBE_KODU", eftEftTx.getAlanSubeKodu());
			oMap.put("ALAN_SEHIR_KODU", eftEftTx.getAlanSehirKodu());
			oMap.put("ALAN_BANKA_KODU", eftEftTx.getAlanBankaKodu());
			oMap.put("GONDEREN_SEHIR", eftEftTx.getGonderenSehir());
			oMap.put("GONDEREN_SUBE", eftEftTx.getGonderenSube());
			oMap.put("GONDEREN_BANKA", eftEftTx.getGonderenBanka());
			oMap.put("MUSTERI_NO", eftEftTx.getMusteriNo());
			oMap.put("GONDEREN_HESAP_NO", eftEftTx.getGonderenHesapNumarasi());
			oMap.put("GONDEREN_VERGI_KIMLIK_NUMARASI", eftEftTx.getGonderenVergiKimlikNumarasi());
			oMap.put("BOLUM_KODU", eftEftTx.getBolumKodu());
			oMap.put("GONDEREN", eftEftTx.getGonderen());
			oMap.put("GONDEREN_TELEFON", eftEftTx.getGonderenTelefon());
			oMap.put("GONDEREN_ADRES", eftEftTx.getGonderenAdres());
			oMap.put("ALICI_HESAP_NO", eftEftTx.getAliciHesapNo());
			oMap.put("ALICI_ADI", eftEftTx.getAliciAdi());
			oMap.put("ALICI_HESAP_NO", eftEftTx.getAliciHesapNo());
			oMap.put("ACIKLAMA_2", eftEftTx.getAciklama2());
	        
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN2334_GET_INITIAL_VALUES")
	public static GMMap getInitialValues(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN2334.form_instance(?,?,?,?,?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.DATE);
			stmt.registerOutParameter(5, Types.VARCHAR);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.registerOutParameter(7, Types.VARCHAR);
			stmt.registerOutParameter(8, Types.VARCHAR);
			stmt.registerOutParameter(9, Types.VARCHAR);
			stmt.execute();

			oMap.put("SUBE_KODU", stmt.getString(1));
			oMap.put("BANKA_KODU", stmt.getString(2));
			oMap.put("BANKA_ADI", stmt.getString(3));
			
			oMap.put("ALAN_BANKA_KODU", stmt.getString(6));
			oMap.put("ALAN_BANKA_ADI", stmt.getString(7));
			
			oMap.put("ALICI_ADI", stmt.getString(7));
			oMap.put("DISPLAY_ALAN_BANKA_ADI",LovHelper.diLov(oMap.get("ALAN_BANKA_KODU"), "2334/LOV_ALAN_BANKA", "BANKA_ADI"));
			
		
			ArrayList<Object> input = new ArrayList<Object>();
			input.add(stmt.getString(6));
			oMap.put("ALAN_SEHIR_KODU", stmt.getString(5));
			oMap.put("DISPLAY_ALAN_SEHIR_ADI", LovHelper.diLov((String)oMap.getString("ALAN_SEHIR_KODU") , "2334/LOV_ALAN_SEHIR", "IL_ADI", input));
		
			
			 input.add(stmt.getString(5));
			 oMap.put("ALAN_SUBE_KODU", stmt.getString(1));
			 oMap.put("DISPLAY_ALAN_SUBE_ADI",LovHelper.diLov((String)oMap.getString("SUBE_KODU"), "2334/LOV_ALAN_SUBE", "SUBE_ADI",input));
			
			oMap.put("ALICI_HESAP_NO", stmt.getString(8));
			oMap.put("ACIKLAMA", stmt.getString(9));

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
