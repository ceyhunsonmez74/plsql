package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class EftQRY2365Services {
	@GraymoundService("BNSPR_QRY2365_GET_GELEN_EFT_MESAJLARI")
	public static GMMap getEftList(GMMap iMap) {
	                                                                  
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_eft.RC_QRY2365_GELEN_EFT_MESAJLARI(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("K_BOLUM"));
			stmt.setString(i++, iMap.getString("K_ALAN"));
			stmt.setString(i++, iMap.getString("K_SIRALAMA"));
			stmt.setString(i++, iMap.getString("K_MESAJ_KODU"));
			stmt.setString(i++, iMap.getString("K_SORGU_NO"));
			stmt.setString(i++, iMap.getString("K_DURUM"));
			stmt.setString(i++, iMap.getString("K_GONDEREN_SUBE"));
			
			if(iMap.getString("K_ALAN_SUBE")!=null && !iMap.getString("K_ALAN_SUBE").equals(""))stmt.setString(i++, iMap.getString("K_ALAN_SUBE"));
			else stmt.setDate(i++, null);
			
			if ((iMap.get("K_EFT_TARIH_BAS") != null)) stmt.setDate(i++, new Date(iMap.getDate("K_EFT_TARIH_BAS").getTime()));
			else stmt.setDate(i++, null);

			if ((iMap.get("K_EFT_TARIH_BIT") != null)) stmt.setDate(i++, new Date(iMap.getDate("K_EFT_TARIH_BIT").getTime()));
			else stmt.setDate(i++, null);
			
			stmt.setString(i++, iMap.getString("K_MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("K_MUSTERI_HESAP_NO"));
			stmt.setString(i++, iMap.getString("K_DK_HESAP_NO"));
			stmt.setString(i++, iMap.getString("K_GONDEREN_BANKA"));
			stmt.setString(i++, iMap.getString("K_GONDEREN_SEHIR"));
			
			if (iMap.getBigDecimal("K_MIN_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("K_MIN_TUTAR"));

			if (iMap.getBigDecimal("K_MAX_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("K_MAX_TUTAR"));
			stmt.setString(i++, iMap.getString("KAS_MESAJ_KODU"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			GMMap oMap = new GMMap();
			BigDecimal toplamTutar = new BigDecimal(0);
			String tableName = "EFT_MESAJLARI";
			int row = 0; 
			while (rSet.next()) {

				oMap.put(tableName, row,"EKRAN_NO", rSet.getString("ekran_no"));
				oMap.put(tableName, row,"TRX_NO", rSet.getString("tx_no"));
				oMap.put(tableName, row,"ALICI_ADI", rSet.getString("alici_adi"));
				oMap.put(tableName, row,"ALICI_HESAP_NO", rSet.getString("alici_hesap_no"));
				oMap.put(tableName, row,"BANKA_ADI", rSet.getString("banka_adi"));
				oMap.put(tableName, row,"GONDEREN_SUBE_ADI", rSet.getString("gonderen_sube_adi"));
				oMap.put(tableName, row,"ALAN_SUBE_ADI", rSet.getString("alan_sube_adi"));
				oMap.put(tableName, row,"DURUM", rSet.getString("durum"));
				oMap.put(tableName, row,"EFT_TARIH", rSet.getDate("eft_tarih"));
				oMap.put(tableName, row,"MESAJ_KODU", rSet.getString("mesaj_kodu"));
				oMap.put(tableName, row,"SORGU_NO", rSet.getString("sorgu_no"));
				oMap.put(tableName, row,"TUTAR", rSet.getString("TUTAR"));
				oMap.put(tableName, row,"YARATILDIGI_TARIH", rSet.getString("yaratildigi_tarih"));
				oMap.put(tableName, row,"GONDEREN_SUBE", rSet.getString("GONDEREN_SUBE"));
				oMap.put(tableName, row,"GONDEREN_ADI", rSet.getString("GONDEREN_ADI"));
				oMap.put(tableName, row,"ODEME_ACIK", rSet.getString("ODEME_ACIK"));
				oMap.put(tableName, row,"ACIKLAMA", rSet.getString("ACIKLAMA"));
				oMap.put(tableName, row,"KAS_MESAJ_KODU", rSet.getString("KAS_MESAJ_KODU"));
				oMap.put(tableName, row,"ODEME_TRX_NO", rSet.getString("ODEME_TX_NO"));
				if (  ( "SATS-UYAR".equals(rSet.getString("mesaj_kodu")) ) ||
					  ( "ALIS-TMAM".equals(rSet.getString("mesaj_kodu")) ) ||
					  ( "REPO-UYAR".equals(rSet.getString("mesaj_kodu")) ) ||
					  ( "REDN-UYAR".equals(rSet.getString("mesaj_kodu")) ) ||
					  ( "HABR-ACIK".equals(rSet.getString("mesaj_kodu")) ) 
				   )
					toplamTutar = toplamTutar ; 	
				else
				    toplamTutar = toplamTutar.add(rSet.getBigDecimal("tutar"));
				row++;
			}
			oMap.put("KAYIT_SAYISI", row);
			oMap.put("TOPLAM_TUTAR", toplamTutar);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2365_GET_DURUM_KODLARI")
	public static GMMap getDurumKodlari(GMMap iMap) {
		iMap.put("ADD_EMPTY_KEY", "E");
		iMap.put("LIST_NAME", "RESULTS");
		iMap.put("LIST_QUERY", "select key1 kod, text aciklama from v_ml_gnl_param_text p where p.kod = 'GELEN_EFT_DURUM' and p.key1 not in ('EKLENDI')");
		DALUtil.fillComboBox(iMap);
		return iMap;
	}
}
