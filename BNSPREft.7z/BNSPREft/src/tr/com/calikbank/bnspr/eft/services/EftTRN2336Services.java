package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftDetayTx;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.PaygateConstants;
import tr.com.paygate.ArrayOfInstanceGroup;
import tr.com.paygate.ArrayOfSearchFilter;
import tr.com.paygate.ArrayOfSearchRequest;
import tr.com.paygate.DetailLevel;
import tr.com.paygate.FilterName;
import tr.com.paygate.InstanceGroup;
import tr.com.paygate.SearchFilter;
import tr.com.paygate.SearchRequest;
import tr.com.paygate.SearchType;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2336Services {
	@GraymoundService("BNSPR_TRN2336_GET_EFT_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
			
		    oMap.put("TRX_NO" , eftEftTx.getTxNo());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("DURUM" , eftEftTx.getDurum());
			oMap.put("MUSTERI_NO" , eftEftTx.getMusteriNo());
	        oMap.put("MUSTERI_HESAP_NO" , eftEftTx.getMusteriHesapNo());
	        oMap.put("DISPLAY_MUSTERI_ADI" , LovHelper.diLov(eftEftTx.getMusteriNo(), "2315/LOV_MUSTERI", "UNVAN"));
	        oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("GELEN_GIDEN" , eftEftTx.getGelenGiden());
	        oMap.put("TUTAR" , eftEftTx.getTutar());
	        oMap.put("ALICI_HES_BULUN_KURUM" , eftEftTx.getAliciHesBulunKurum());
	        oMap.put("ALICI_HES_BULUN_KURUM_HESAP_NO" ,eftEftTx.getAliciHesBulunKurumHesapNo());
	        oMap.put("NIHAI_ALICI" , eftEftTx.getNihaiAlici());
	        oMap.put("NIHAI_ALICI_HESAP_NO" , eftEftTx.getNihaiAliciHesapNo());
	        oMap.put("AMIR_KURUM_VKNO" , eftEftTx.getAmirKurumVkno());
	        oMap.put("AMIR_KURUM" , eftEftTx.getAmirKurum());
	        oMap.put("AMIR" , eftEftTx.getAmir());
	        oMap.put("AMIR_KURUM_HESAP_NO" , eftEftTx.getAmirKurumHesapNo());
	        oMap.put("AMIR_HESAP_NO" , eftEftTx.getAmirHesapNo());
	        oMap.put("ARACI_KURUM" , eftEftTx.getAraciKurum());
	        oMap.put("MASRAF_DETAYI" , eftEftTx.getMasrafDetayi());
	        oMap.put("ACIKLAMA_2" , eftEftTx.getAciklama2());
	        oMap.put("GONDERICIDEN_ALICIYA_BILGI" , eftEftTx.getGondericidenAliciyaBilgi());
	        oMap.put("ODEME_TURU" , eftEftTx.getOdemeTuru());
	        oMap.put("ODEME_KAYNAK" , eftEftTx.getOdemeKaynak());
	        oMap.put("MASRAF_DETAYI" , eftEftTx.getMasrafDetayi());	        
	        oMap.put("REFERANS_NO" , eftEftTx.getReferansNo());
	        oMap.put("NIHAI_ALICI_KURUM" , eftEftTx.getNihaiAliciKurum());
	        oMap.put("NIHAI_ALICI_KURUM_HESAP_NO" , eftEftTx.getNihaiAliciKurumHesapNo());
	        oMap.put("ACIKLAMA_2" , eftEftTx.getAciklama2());
	        oMap.put("KAS_MESAJ_KODU" , eftEftTx.getKasMesajKodu());
	        oMap.put("GONDEREN" , eftEftTx.getGonderen());
	        oMap.put("GONDEREN_ADRES" , eftEftTx.getGonderenAdres());
	        oMap.put("GONDEREN_PASAPORT_NO", eftEftTx.getGonderenPasaportNo());
	        oMap.put("GONDEREN_DOGUM_YERI", eftEftTx.getGonderenDogumYeri());
	        oMap.put("GONDEREN_DOGUM_TARIHI", eftEftTx.getGonderenDogumTarihi());
	        oMap.put("GONDEREN_MUSTERI_NUMARASI", eftEftTx.getGonderenMusteriNumarasi());	 
	        oMap.put("GONDEREN_HESAP_NUMARASI", eftEftTx.getGonderenHesapNumarasi());
	       
	        oMap.put("ISLEM_TIPI" , eftEftTx.getIslemTipi());
	        oMap.put("ODEME_SUBE" , eftEftTx.getOdemeSube());
	        oMap.put("ODEME_DK_HESAP" , eftEftTx.getOdemeDkHesap());
	        oMap.put("ODEME_MUSTERI_NO" , eftEftTx.getOdemeMusteriNo());
	        oMap.put("ODEME_MUSTERI_HESAP" , eftEftTx.getOdemeMusteriHesap());
	        oMap.put("ALICI_IBAN" , eftEftTx.getAliciIban());
	        oMap.put("F_SWIFT_GONDERILDIMI" , GuimlUtil.convertToCheckBoxSelected(eftEftTx.getFSwiftGonderildimi()));
            oMap.put("ARACI_KURUM_HESAP_NO" , eftEftTx.getAraciKurumHesapNo());
	        oMap.put("MASRAF_IC_DIS", eftEftTx.getMasrafIcDis());
	        oMap.put("MASRAF_HESAP_NO", eftEftTx.getMasrafHesapNo());
	        oMap.put("MASRAF" , eftEftTx.getMasraf());
	        oMap.put("TUTAR_SCR" , eftEftTx.getTutarScr());

            oMap.put("ILGILI_ISLEM_NUMARA" , eftEftTx.getIlgiliIslemNumara());
            oMap.put("ILGILI_ISLEM_REFERANSI" , eftEftTx.getIlgiliIslemReferansi());
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
            oMap.put("ON_BILDIRIM_REFERANSI", eftEftTx.getOnBildirimReferansi());			
            oMap.put("DBOR_ALACAKLI", eftEftTx.getDborAlacakli());
                       
            oMap.put("AMIR_ULKE_SEHIR", eftEftTx.getAmirUlkeSehir());
            oMap.put("MESAJ_GRUBU", eftEftTx.getMesajGrubu());
            oMap.put("AMIR_KIMLIK_NO", eftEftTx.getAmirKimlikNo());
            oMap.put("NIHAI_ALICI_ADRESI", eftEftTx.getNihaiAliciAdresi());
            oMap.put("NIHAI_ALICI_ULKE_SEHIR", eftEftTx.getNihaiAliciUlkeSehir());
            oMap.put("AMIR_BILGI_SECIM", eftEftTx.getAmirBilgiSecim());
            oMap.put("NIHAI_ALICI_BILGI_SECIM", eftEftTx.getNihaiAliciBilgiSecim());
            
	        List<?> eftDetayList = session.createCriteria(EftEftDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        int i=0;
			for (Object name : eftDetayList) {
				EftEftDetayTx eftEftDetayTx = (EftEftDetayTx) name;
				oMap.put("EFTDETAY", i,"AMIR_EK_BILGI", eftEftDetayTx.getAmirEkBilgi());
				oMap.put("EFTDETAY", i,"NIHAI_ALICI_EK_BILGI", eftEftDetayTx.getNihaiAliciEkBilgi());				
				i++;
			}

            
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN2336_EFT_PAYGATE_CHECK")
	public static GMMap eft2336PaygateCheck(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		List<SearchRequest> searchRequestList = new ArrayList<SearchRequest>();
		try {

            ArrayOfSearchRequest arrayOfSearchRequest = new ArrayOfSearchRequest();

			SearchRequest srGonderen = new SearchRequest();
            srGonderen.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_4, SearchType.GENERIC_NAME));
			srGonderen.setValue(iMap.getString("GONDEREN"));
            if (StringUtils.isNotBlank(iMap.getString("MUSTERI_NO"))) {
                ArrayOfSearchFilter arrOfSearchFilter = new ArrayOfSearchFilter();
                SearchFilter sf = new SearchFilter();
                sf.setKey(FilterName.CUSTOMER_NUMBER);
                sf.setValue(iMap.getString("MUSTERI_NO"));
                arrOfSearchFilter.getSearchFilter().add(sf);
                srGonderen.setFilters(arrOfSearchFilter);
         }
			searchRequestList.add(srGonderen);
			
            if (StringUtils.isNotBlank(iMap.getString("ALAN_BANKA"))) {
				SearchRequest srAlanBanka = new SearchRequest();
				srAlanBanka.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_4, SearchType.GENERIC_NAME));
				srAlanBanka.setValue(iMap.getString("ALAN_BANKA"));
				searchRequestList.add(srAlanBanka);
            }	

            if (StringUtils.isNotBlank(iMap.getString("ACIKLAMA"))) {
				SearchRequest srAciklama = new SearchRequest();
				srAciklama.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_4, SearchType.TEXT));
				srAciklama.setValue(iMap.getString("ACIKLAMA"));
				searchRequestList.add(srAciklama);
            }	

            if (StringUtils.isNotBlank(iMap.getString("AMIR"))) {
				SearchRequest srAmir = new SearchRequest();
				srAmir.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_4, SearchType.GENERIC_NAME));
				srAmir.setValue(iMap.getString("AMIR"));
				searchRequestList.add(srAmir);
            }	

            if (StringUtils.isNotBlank(iMap.getString("NIHAI_ALICI"))) {
				SearchRequest srNihaiAlici = new SearchRequest();
				srNihaiAlici.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_4, SearchType.GENERIC_NAME));
				srNihaiAlici.setValue(iMap.getString("NIHAI_ALICI"));
				searchRequestList.add(srNihaiAlici);
            }

            if (StringUtils.isNotBlank(iMap.getString("ARACI_KURUM"))) {
				SearchRequest srAraci = new SearchRequest();
				srAraci.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_4, SearchType.GENERIC_NAME));
				srAraci.setValue(iMap.getString("ARACI_KURUM"));
				searchRequestList.add(srAraci);
            }

            if (StringUtils.isNotBlank(iMap.getString("AMIR_KURUM"))) {
				SearchRequest srAmirKurum = new SearchRequest();
				srAmirKurum.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_4, SearchType.GENERIC_NAME));
				srAmirKurum.setValue(iMap.getString("AMIR_KURUM"));
				searchRequestList.add(srAmirKurum);
            }	
			
            if (StringUtils.isNotBlank(iMap.getString("NIHAI_ALICI_KURUM"))) {
				SearchRequest srNihaiAliciKurum = new SearchRequest();
				srNihaiAliciKurum.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_4, SearchType.GENERIC_NAME));
				srNihaiAliciKurum.setValue(iMap.getString("NIHAI_ALICI_KURUM"));
				searchRequestList.add(srNihaiAliciKurum);
            }	

            if (StringUtils.isNotBlank(iMap.getString("ALICI_KURUM"))) {
				SearchRequest srAliciKurum = new SearchRequest();
				srAliciKurum.setInstanceList(getArrOfInstanceGroupWithTypeAndName(PaygateConstants.LIST_GROUP_AKUSTIK_4, SearchType.GENERIC_NAME));
				srAliciKurum.setValue(iMap.getString("ALICI_KURUM"));
				searchRequestList.add(srAliciKurum);
            }		
			
            arrayOfSearchRequest.getSearchRequest().addAll(searchRequestList);
            
            GMMap amlMap = new GMMap(); 
            amlMap.put("TRX_NAME","2336"); 
            amlMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
            amlMap.put("SEARCH_REQUEST_LIST", arrayOfSearchRequest);
             
            oMap = GMServiceExecuter.call("BNSPR_EXT_FINEKSUS_SEARCH_BULK_DATA", amlMap);
		   return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}	
	
	private static ArrayOfInstanceGroup getArrOfInstanceGroupWithTypeAndName(String instanceName, SearchType searchType) {
		ArrayOfInstanceGroup instanceGroupListArray = new ArrayOfInstanceGroup();
		List<InstanceGroup> instanceGroupList = new ArrayList<InstanceGroup>();
		InstanceGroup ig = new InstanceGroup();
		ig.setDetailLevel(DetailLevel.FULL);
		ig.setInstanceName(instanceName);
		ig.setSearchType(searchType);
		instanceGroupList.add(ig);
		instanceGroupListArray.getInstanceGroup().addAll(instanceGroupList);
		return instanceGroupListArray;
	}
	
	@GraymoundService("BNSPR_LOAD_COMBO_PARAMETERS")
	public static GMMap loadComboParameter(GMMap iMap) {
	
		try {
			GMMap oMap = new GMMap();


		   iMap.put("KOD" , "ON_BILDIRIM_TUR");
	       iMap.put("ADD_EMPTY_KEY" , "E");
	       oMap.put("ON_BILDIRIM_TUR", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
	            
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
	
}
