package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class EftQRY2379Services {
	@GraymoundService("BNSPR_QRY2379_GET_DUZENLI_ODEME")
	public static GMMap getEftList(GMMap iMap) {
        
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_eft.RC_QRY2379_GET_DUZENLI_ODEME(?,?,?,?,?,?,?)}");
			int j = 1;	
			stmt.registerOutParameter(j++, -10); //ref cursor
			stmt.setBigDecimal(j++, iMap.getBigDecimal("SIRA_NO_BAS"));
			stmt.setBigDecimal(j++, iMap.getBigDecimal("SIRA_NO_BIT"));
			stmt.setBigDecimal(j++, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setBigDecimal(j++, iMap.getBigDecimal("HESAP_NO"));
			
			if ((iMap.get("EFT_TARIH_BAS") != null)) stmt.setDate(j++, new Date( iMap.getDate("EFT_TARIH_BAS").getTime()));
			else stmt.setDate(j++, null);

			if ((iMap.get("EFT_TARIH_BIT") != null)) stmt.setDate(j++, new Date(iMap.getDate("EFT_TARIH_BIT").getTime()));
			else stmt.setDate(j++, null);
			
			stmt.setString(j++, iMap.getString("DURUM"));
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			String tableName = "DUZENLI_ODEME";
			int row = 0;
			while(rSet.next()){
				int i = 1;
				oMap.put(tableName, row,"ODEME_SIRA_NO", rSet.getBigDecimal(i++));
				oMap.put(tableName, row,"MUSTERI_NO", rSet.getBigDecimal(i++));
				oMap.put(tableName, row,"MUSTERI_ADI", rSet.getString(i++));
				oMap.put(tableName, row,"HESAP_NO", rSet.getBigDecimal(i++));
				oMap.put(tableName, row,"ODEME_TIPI", rSet.getString(i++));
				oMap.put(tableName, row,"ODEME_TUTARI", rSet.getBigDecimal(i++));
				oMap.put(tableName, row,"BASLANGIC_TARIHI", rSet.getDate(i++));
				oMap.put(tableName, row,"BITIS_TARIHI", rSet.getDate(i++));
				oMap.put(tableName, row,"DOVIZ_KODU", rSet.getString(i++));
				oMap.put(tableName, row,"ODEME_SEKLI", rSet.getString(i++));
				oMap.put(tableName, row,"KANAL_ADI", rSet.getString(i++));
				oMap.put(tableName, row,"KULLANICI_ADI", rSet.getString(i++));
				oMap.put(tableName, row,"YARATAN_TX_NO", rSet.getString(i++));
				oMap.put(tableName, row,"DURUM", rSet.getString(i++));
				row++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
}
