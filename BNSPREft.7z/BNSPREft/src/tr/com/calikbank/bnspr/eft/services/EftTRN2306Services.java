package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftGelgonBirlestirDetail;
import tr.com.calikbank.bnspr.dao.EftGelgonBirlestirDetailId;
import tr.com.calikbank.bnspr.dao.EftGelgonBirlestirMain;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2306Services {
	@GraymoundService("BNSPR_TRN2306_GET_EFT_BILGI")
	public static GMMap getEftBilgi(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftGelgonBirlestirMain eftGelgonBirlestirMain = (EftGelgonBirlestirMain) session
					.createCriteria(EftGelgonBirlestirMain.class).add(
							Restrictions.eq("txNo", iMap
									.getBigDecimal("TRX_NO"))).uniqueResult();
			
			GMMap oMap = new GMMap();
			
			oMap.put("HESAP_TIPI", eftGelgonBirlestirMain.getHesapTipi());
			oMap.put("HESAP_NO", eftGelgonBirlestirMain.getHesapNo());
			oMap.put("SORGU_NO", eftGelgonBirlestirMain.getSorguNo());
			oMap.put("MESAJ_TIPI", eftGelgonBirlestirMain.getMesajTipi());
			oMap.put("BANKA_KODU", eftGelgonBirlestirMain.getBankaKodu());
			oMap.put("BANKA_SUBE_KODU", eftGelgonBirlestirMain.getBankaSubeKodu());
			oMap.put("TUTAR",eftGelgonBirlestirMain.getTutar());
			oMap.put("MUSTERI_ADI",LovHelper.diLov(eftGelgonBirlestirMain.getMusteriNo(), "2306/LOV_K_MUSTERI_NO", "ISIM_UNVAN"));
			oMap.put("BANKA_ADI",LovHelper.diLov(eftGelgonBirlestirMain.getBankaKodu(), "2306/LOV_BANKA", "BANKA_ADI"));
			oMap.put("BANKA_SUBE_ADI", LovHelper.diLov(eftGelgonBirlestirMain.getBankaSubeKodu(),eftGelgonBirlestirMain.getBankaKodu(),"2306/LOV_SUBE_KODLARI", "SUBE_ADI"));
			
			List<?> list = (List<?>) session
			.createCriteria(EftGelgonBirlestirDetail.class).add(
					Restrictions.eq("id.txNo", iMap
							.getBigDecimal("TRX_NO"))).list();
			
			String tableName = "GELGON_EFT_BIRLESTIR_DTYIS";
			int row = 0;
			BigDecimal toplamTutar = new BigDecimal(0);
			for (Iterator<?> iterator = list.iterator(); iterator.hasNext();) {
				EftGelgonBirlestirDetail eftGelgonBirlestirDetail = (EftGelgonBirlestirDetail)iterator.next();
				
				oMap.put(tableName, row, "ESKI_TRX_NO", eftGelgonBirlestirDetail.getId().getEskiTxNo());
				oMap.put(tableName, row, "BANKA_KODU", eftGelgonBirlestirDetail.getBankaKodu());
				oMap.put(tableName, row, "BANKA_SUBE_KODU",eftGelgonBirlestirDetail.getBankaSubeKodu() );
				oMap.put(tableName, row, "DK_NO", eftGelgonBirlestirDetail.getDkNo());
				oMap.put(tableName, row, "GIREN_KULLANICI", eftGelgonBirlestirDetail.getGirenKullanici());
				oMap.put(tableName, row, "HESAP_NO", eftGelgonBirlestirDetail.getHesapNo());
				oMap.put(tableName, row, "ISLEM_TARIHI", eftGelgonBirlestirDetail.getIslemTarihi());
				oMap.put(tableName, row, "K_BANKA_ADI", LovHelper.diLov(eftGelgonBirlestirDetail.getBankaKodu(), "2306/LOV_BANKA", "BANKA_ADI"));
				oMap.put(tableName, row, "MESAJ_TIPI",eftGelgonBirlestirDetail.getMesajTipi() );
				if(eftGelgonBirlestirDetail.getSecildi().equals("E"))oMap.put(tableName, row, "SECILDI", "1");
				else oMap.put(tableName, row, "SECILDI", "0");
				oMap.put(tableName, row, "SORGU_NO", eftGelgonBirlestirDetail.getSorguNo());
				oMap.put(tableName, row, "TUTAR", eftGelgonBirlestirDetail.getTutar());			
				
				toplamTutar = toplamTutar.add(eftGelgonBirlestirDetail.getTutar());
				row++;		
			}
			
			oMap.put("TOPLAM_TUTAR", toplamTutar);
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2306_GET_TRX_NO")
	public static GMMap getTrxNo(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		try{
			GMMap oMap = new GMMap();
			conn =DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call pkg_trn2306.bilgiaktar(?,?) }");
			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setBigDecimal(2, iMap.getBigDecimal("MUSTERI_NO"));
			stmt.setString(3, iMap.getString("EFT_URUN_TUR"));
			
			stmt.execute();
			
			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN2306_SAVE")
	public static Map<?,?> save(GMMap iMap){
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftGelgonBirlestirMain eftGelgonBirlestirMain = (EftGelgonBirlestirMain)session.get(EftGelgonBirlestirMain.class, iMap.getBigDecimal("TRX_NO"));
			if(eftGelgonBirlestirMain == null)eftGelgonBirlestirMain = new EftGelgonBirlestirMain();
			
	        eftGelgonBirlestirMain.setEftUrunTur(iMap.getString("EFT_URUN_TUR"));
	        eftGelgonBirlestirMain.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
	        eftGelgonBirlestirMain.setHesapTipi(iMap.getString("HESAP_TIPI"));
	        eftGelgonBirlestirMain.setSorguNo(iMap.getBigDecimal("SORGU_NO"));
	        eftGelgonBirlestirMain.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
	        eftGelgonBirlestirMain.setMesajTipi(iMap.getString("MESAJ_TIPI"));
	        eftGelgonBirlestirMain.setBankaKodu(iMap.getString("BANKA_KODU"));
	        eftGelgonBirlestirMain.setBankaSubeKodu(iMap.getString("BANKA_SUBE_KODU"));
	        eftGelgonBirlestirMain.setTutar(iMap.getBigDecimal("TUTAR"));
	        session.update(eftGelgonBirlestirMain);
			session.flush();
			
			String tableName = "GELGON_EFT_BIRLESTIR_DTYIS";
			List<?> list = (List<?>)iMap.get(tableName);
			int row = 0;
			for (int i=0;i<list.size();i++) {
				EftGelgonBirlestirDetailId eftGelgonBirlestirDetailId = new EftGelgonBirlestirDetailId();
				eftGelgonBirlestirDetailId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				eftGelgonBirlestirDetailId.setEskiTxNo(iMap.getBigDecimal(tableName, row, "ESKI_TRX_NO"));
				
				EftGelgonBirlestirDetail eftGelgonBirlestirDetail = (EftGelgonBirlestirDetail)session.get(EftGelgonBirlestirDetail.class, eftGelgonBirlestirDetailId);
				if(eftGelgonBirlestirDetail == null){
					eftGelgonBirlestirDetail = new EftGelgonBirlestirDetail();
				}
				eftGelgonBirlestirDetail.setId(eftGelgonBirlestirDetailId);
				eftGelgonBirlestirDetail.setBankaKodu(iMap.getString(tableName, row,"BANKA_KODU"));
				eftGelgonBirlestirDetail.setBankaSubeKodu(iMap.getString(tableName, row,"BANKA_SUBE_KODU"));
				eftGelgonBirlestirDetail.setDkNo(iMap.getString(tableName, row,"DK_NO"));
				eftGelgonBirlestirDetail.setGirenKullanici(iMap.getString(tableName, row,"GIREN_KULLANICI"));
				eftGelgonBirlestirDetail.setHesapNo(iMap.getBigDecimal(tableName, row,"HESAP_NO"));
				eftGelgonBirlestirDetail.setIslemTarihi(iMap.getDate(tableName, row,"ISLEM_TARIHI"));
				eftGelgonBirlestirDetail.setMesajTipi(iMap.getString(tableName, row,"MESAJ_TIPI"));
				eftGelgonBirlestirDetail.setSorguNo(iMap.getBigDecimal(tableName, row,"SORGU_NO"));
				eftGelgonBirlestirDetail.setTutar(iMap.getBigDecimal(tableName, row,"TUTAR"));
				if((iMap.getString(tableName, row,"SECILDI")).equals("1"))eftGelgonBirlestirDetail.setSecildi("E");
				else eftGelgonBirlestirDetail.setSecildi("H");	
				
				session.saveOrUpdate(eftGelgonBirlestirDetail);
				row++;
			}
			session.flush();
			
			iMap.put("TRX_NAME", "2306");
			
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);			
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
