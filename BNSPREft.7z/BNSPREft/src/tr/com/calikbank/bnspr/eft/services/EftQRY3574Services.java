package tr.com.calikbank.bnspr.eft.services;

import java.awt.Color;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.TuGonderTx;
import tr.com.aktifbank.bnspr.dao.TuTransferTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.connection.GMConnection;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftQRY3574Services {
	
	private static final String DURUM_SORUNLU = "Sorunlu";
	private static final String DURUM_SORUNLU_IPTAL = "Sorunlu Iptal";
	private static Logger logger = Logger.getLogger(EftQRY3574Services.class);
	
	@GraymoundService("BNSPR_QRY3574_INITIALIZE")
	public static GMMap getGidenEftMesajlari(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			
			GMMap xMap = new GMMap();

			DALUtil.fillComboBox(oMap, "KANAL_LIST"			, false, "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr where KOD in ('25') ");
			DALUtil.fillComboBox(oMap, "GIDEN_DURUM_KODU"	, true, "select key1, text from v_ml_gnl_param_text where kod = 'GIDEN_EFT_DURUM' and key1 in ('TAMAM','IPTAL','TCMB','RELEASE','TCMB-HATA')");
			/*xMap.put("KOD"				, "PFT_TOPLU_ONAY_KRITER");
			xMap.put("ADD_EMPTY_KEY"	, "E");
			oMap.put("ISLEM_DURUM_LIST"	, GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", xMap).get("RESULTS"));*/
			
			xMap.put("KOD"				, "EFT_GUNCELLEME_SEBEP");
			xMap.put("ADD_EMPTY_KEY"	, "E");
			oMap.put("ACIKLAMA_LIST"	, GMServiceExecuter.call("BNSPR_COMMON_GET_COMBO_PARAMETERS", xMap).get("RESULTS"));
			
			iMap.put("ADD_EMPTY_KEY"	, "E");
			iMap.put("KOD"				, "TU_ISLEM_TIPI");
			oMap.put("ISLEM_TIPI"		, GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("ADD_EMPTY_KEY"	, "E");
			iMap.put("KOD"				, "TU_ISLEM_TIPI");
			oMap.put("ISLEM_TIPI_TBL"	, GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
			
			iMap.put("ADD_EMPTY_KEY" , "E");
            iMap.put("KOD"              , "TU_SWIFT_DURUM");
            oMap.put("DURUM_KODU"   , GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

            iMap.put("ADD_EMPTY_KEY", "E");
            iMap.put("KOD", "TU_HAVALE_DURUM");
            oMap.put("HAVALE_DURUM_KODU", GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            
            iMap.put("ADD_EMPTY_KEY"	, "E");
			iMap.put("KOD"				, "GIDEN_EFT_ISLEM_TIPI");
			oMap.put("GIDEN_EFT_ISLEM_TIPI"		, GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));
            
            
            
			oMap.putAll(GMServiceExecuter.execute("BNSPR_COMMON_GET_BANKA_TARIH", iMap));
			
		} catch (Exception e) {
			EftServices.throwGMBusssinessException(e.getMessage());
			//throw new GMRuntimeException(0, e);
		}
		return oMap;
	}
	
	
	@GraymoundService("BNSPR_QRY3574_GET_GIDEN_UPT")
	public static GMMap getGelenUpt(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		int i = 1;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_TU.RC_TU_GIDEN_EFT_MESAJLARI(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("KANAL"));
			stmt.setString(i++, iMap.getString("SORGU_NO"));
			stmt.setString(i++, iMap.getString("UPT_TIPI"));
			stmt.setString(i++, iMap.getString("TU_REFERANS"));
			stmt.setBigDecimal(i++, iMap.getBigDecimal("UPT_ISLEM_NO"));
			stmt.setString(i++, iMap.getString("GON_AD_SOYAD"));
			stmt.setString(i++, iMap.getString("GON_TCKN"));
			stmt.setString(i++, iMap.getString("ALICI_BANKA"));
			stmt.setString(i++, iMap.getString("ALICI_AD_SOYAD"));
			stmt.setString(i++, iMap.getString("DURUM_KODU"));
			
			if (iMap.getBigDecimal("MIN_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("MIN_TUTAR"));

			if (iMap.getBigDecimal("MAX_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("MAX_TUTAR"));			
			
			
			if(iMap.getDate("BAS_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("BAS_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			
			if(iMap.getDate("BIT_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("BIT_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			stmt.setString(i++, iMap.getBoolean("IADE_GELEN") ? "E" : "H");
			stmt.setString(i++, iMap.getBoolean("CHK_TAMAMLANANLAR") ? "E" : "H");
			
			stmt.setString(i++, iMap.getString("ISLEM_TIPI"));
			stmt.setString(i++, iMap.getString("PTT_ISLEMIMI"));
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			GMMap oMap = new GMMap();
			oMap.putAll(DALUtil.rSetResults(rSet, "GIDEN_UPT")); 
			if(!oMap.containsKey("GIDEN_UPT"))
			{
				iMap.put("HATA_NO", new BigDecimal(1614));
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
			
			GMMap colorChanged = new GMMap();
			colorChanged.put("setBackground", Color.WHITE);
			colorChanged.put("setForeground", Color.RED);
			
			GMMap colorNotChanged  = new GMMap();
			colorNotChanged.put("setBackground", Color.WHITE);
			colorNotChanged.put("setForeground", Color.BLACK);
			
			GMMap colorCase = new GMMap();

			for (int y = 0; y < oMap.getSize("GIDEN_UPT"); y++) {
				if (StringUtils.isBlank(oMap.getString("GIDEN_UPT", y, "IADE_AKIBET"))) {
					colorCase = colorNotChanged;
				}
				else {
					colorCase = colorChanged;
				}

				for (int x = 0; x < iMap.getSize("columnList"); x++) {
					oMap.put("GIDEN_UPT_COLOR", y, iMap.getString("columnList", x, "NAME"), colorCase);
				}
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	
	@GraymoundService("BNSPR_QRY3574_SORUNLU_ISLEM_IZLEME")
	public static GMMap getSorunluIslemIzleme(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		
	    
		try{      
			
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_TU.RC_TU_SORUNLU(?,?,?,?)}"); 
			
			int i = 1;
			
			stmt.registerOutParameter(i++, -10);
			stmt.setString	(i++, iMap.getString("TUREFERANS"));
			stmt.setString	(i++, iMap.getString("ISLEMTIPI"));
			if(iMap.get("TARIHBAS")!=null)
				stmt.setDate(i++, new Date(iMap.getDate("TARIHBAS").getTime()));
			else 
				stmt.setDate(i++, null);
			if(iMap.get("TARIHSON")!=null)
				stmt.setDate(i++, new Date(iMap.getDate("TARIHSON").getTime()));
			else 
				stmt.setDate(i++, null);
			
			stmt.execute();
			//stmt.getMoreResults();
			rSet = (ResultSet) stmt.getObject(1);
			oMap = DALUtil.rSetResults(rSet, "IZLEMETABLOSU");
			//oMap.put("ISLEMADEDI", oMap.getSize("IZLEMETABLOSU"));


			String tableName2 = "IZLEMETABLOSU";
			int j=0;
			int ISLEM_ADET =0;
			
			
			for  ( j = 0; j < oMap.getSize(tableName2); j++) {  

					ISLEM_ADET = ISLEM_ADET +1;
				}

			oMap.put("ISLEMADEDI", ISLEM_ADET);
			 
			return oMap;  
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY3574_ISLEM_ONAY_BEKLET")
	public static GMMap getIslemOnayIzleme(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap(); 
		try{      
			
			conn = DALUtil.getGMConnection();
			
			Session session = DAOSession.getSession("BNSPRDal");
			Criteria cr = session.createCriteria(TuGonderTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("ISLEM_NO")));
			TuGonderTx tx = (TuGonderTx) cr.uniqueResult();
			
			if ("E".equals(tx.getfOnaylanabilirmi())) {
				tx.setfOnaylanabilirmi("H");
			} else if ("H".equals(tx.getfOnaylanabilirmi())) {
				tx.setfOnaylanabilirmi("E");
			}
			
			session.saveOrUpdate(tx);
			
			return oMap;  
			
		}catch (Exception e){
			throw ExceptionHandler.convertException(e);
		}finally{
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("QRY3574_ISLEM_ONAYLAMA")
	public static GMMap TuBasarisizIslemTamamla(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		GMMap iMap3 = new GMMap();

		try {

			if("CLKS".equals(iMap.getString("REC_OWNER"))) {
				iMap3.putAll(GMServiceExecuter.call("SET_USER_GLOBALS_CLKS", new GMMap().put("USER_TYPE", "CLKS")));
			} else {
				iMap3.putAll(GMServiceExecuter.call("SET_USER_GLOBALS_TU", new GMMap().put("USER_TYPE", "TU")));
			}
			iMap3.put("USER_TYPE", "BNSPR");

			if(DURUM_SORUNLU_IPTAL.equals(iMap.getString("DURUM_KODU"))) {

				DALUtil.callOracleProcedure("{call Pkg_tu.WS_TU_TU_GON_IPTAL(?)}", 
					new Object[]{BnsprType.NUMBER, iMap.getBigDecimal("ISLEM_NO")}, 
					new Object[]{});
				
				oMap.put("ISLEM_TALEP_SAYISI", 1);
				oMap.put("SONUC", "1");
			}
			
			else if("E".equals(iMap.getString("ISLEM_TIPI")) || "H".equals(iMap.getString("ISLEM_TIPI"))) {
				
				String call = "{call Pkg_tu.WS_TU_TU_GON_EFT_ONAY(?,?)}";
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall(call);
				stmt.setBigDecimal(1, iMap.getBigDecimal("ISLEM_NO"));
				stmt.registerOutParameter(2, Types.NUMERIC);
				stmt.execute();
				if(stmt.getBigDecimal(2) == null) {
					oMap.put("BAKIYE", "-1");
				}
				else {
					oMap.put("BAKIYE", stmt.getBigDecimal(2));
				}
				oMap.put("ISLEM_TALEP_SAYISI", 1);
				oMap.put("SONUC", "1");
			}

			else {
				GMServiceExecuter.call("BNSPR_ISLEM_DOGRULA_ONAYLA_IPTAL_DOGRULA", new GMMap()
					.put("ISLEM_NO", iMap.getBigDecimal("ISLEM_NO"))
					.put("ISLEM_TURU", "O")
					.put("ACIKLAMA", "Turkish Union"));
			}

			return oMap;
		}
		catch(Exception e) {
			logger.error("QRY3574_ISLEM_ONAYLAMA err: " + e.getMessage());
			GMServiceExecuter.call("SET_USER_GLOBALS_BNSPR", iMap3);
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServiceExecuter.call("SET_USER_GLOBALS_BNSPR", iMap3);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(stmt);
		}
	}
	
	
	public static GMMap remoteCall(String serviceName,GMMap iMap){
		GMConnection connection = null;
		GMMap oMap = new GMMap();
		
		 String BANKING_SERVICE = "TRUNION"; 
		
		try {
			connection = GMConnection.getConnection(BANKING_SERVICE);
			
			oMap.putAll(connection.serviceCall(serviceName, iMap));
			
			
		
		} catch (IOException e) {
			EftServices.throwGMBusssinessException(e.getMessage());
			//throw new com.graymound.util.GMRuntimeException(101, e.getMessage());		
		} finally {			
			if (connection != null) {	try { connection.close(); } catch (IOException e) { e.printStackTrace(); } }
		}
		return oMap;
	}	
	
	@GraymoundService("SET_USER_GLOBALS_TU")
	public static GMMap SetUserGlobalsTu(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try{
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_RC_TU.Set_User_Globals_TU_User(?,?,?)}");	
			stmt.setString(1, iMap.getString("USER_TYPE"));
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			
			stmt.execute();
			
			oMap.put("KULLANICI_KOD", stmt.getString(2));
			oMap.put("KULLANICI_SUBE_KOD", stmt.getString(3));
			
			return oMap;
		} catch (SQLException e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN3574_TUMUNE_ATA")
	public static GMMap mumkunseTumuneAtaGel(GMMap iMap) {
		String tableName = "TABLE_DATA";
		int rowCount = iMap.getSize(tableName);
		for (int i = 0; i < rowCount; i++) {
			if (StringUtils.isBlank(iMap.getString(tableName,i,iMap.getString("COLUMN_NAME_2"))))
				
			{
				iMap.put(tableName, i, iMap.getString("COLUMN_NAME"), iMap.getString("VALUE"));
			}
			else
			{
				iMap.put(tableName, i, iMap.getString("COLUMN_NAME"), iMap.getString("VALUE2"));
			}
		}
		return iMap;
	}
	@GraymoundService("BNSPR_QRY3574_SWIFT_SORGULA")
    public static GMMap swiftSorgula(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {               
            String func = "{? = call PKG_RC_TU.RC_TU_GIDEN_SWIFT_MESAJLARI(?,?,?,?,?,?,?,?,?,?,?,?)}";
            Object[] inputValues = new Object[]{BnsprType.STRING, iMap.getString("TU_REFERANS"),
                    BnsprType.NUMBER, iMap.getBigDecimal("ISLEM_NO"),
                    BnsprType.STRING, iMap.getString("GON_AD"),
                    BnsprType.STRING, iMap.getString("GON_TCKN"),
                    BnsprType.STRING, iMap.getString("ALICI_BANKA"),
                    BnsprType.STRING, iMap.getString("ALICI_AD"),
                    BnsprType.STRING, iMap.getString("DURUM_KODU"),
                    BnsprType.STRING, iMap.getString("DOVIZ_KODU"),
                    BnsprType.NUMBER, iMap.getBigDecimal("K_MIN_TUTAR"),
                    BnsprType.NUMBER, iMap.getBigDecimal("K_MAX_TUTAR"),
                    BnsprType.DATE, iMap.getDate("K_BAS_TARIH"),
                    BnsprType.DATE, iMap.getDate("K_BIT_TARIH")
                    };
            oMap = DALUtil.callOracleRefCursorFunction(func, "RC_TU", inputValues);
            
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
	@GraymoundService("BNSPR_QRY3574_SWIFT_TOPLAM_KAYIT")
    public static GMMap swiftToplamKayit(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {               
        	BigDecimal tmpToplamMasraf = new BigDecimal(0.00);
            BigDecimal tmpToplamTutar = new BigDecimal(0.00);
            for(int i =0; i< iMap.getSize("TBL_SWIFT");i++){
                if(iMap.getBigDecimal("TBL_SWIFT" , i , "GON_TUTAR") != null)
                    tmpToplamTutar = tmpToplamTutar.add(iMap.getBigDecimal("TBL_SWIFT" , i , "GON_TUTAR"));
                
                if(iMap.getBigDecimal("TBL_SWIFT" , i , "MASRAF_TUTARI") != null)
                    tmpToplamMasraf = tmpToplamMasraf.add(iMap.getBigDecimal("TBL_SWIFT" , i , "MASRAF_TUTARI"));
            }
            oMap.put("TOPLAM_TUTAR" , tmpToplamTutar);
            oMap.put("TOPLAM_MASRAF" , tmpToplamMasraf);
            oMap.put("TOPLAM_KAYIT" , iMap.getSize("TBL_SWIFT"));
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
	
	@GraymoundService("BNSPR_QRY3574_HAVALE_SORGULA")
	public static GMMap bnsprQRY3574HavaleSorgula(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {               
        	String func = "{? = call pkg_rc_tu.rc_tu_giden_havale_islemleri(?,?,?,?,?,?,?,?,?,?,?,?)}";
            Object[] inputValues = new Object[]{
            		BnsprType.STRING, iMap.getString("KANAL_KODU"),
                    BnsprType.NUMBER, iMap.getBigDecimal("TU_REFERANS"),
                    BnsprType.STRING, iMap.getString("ISLEM_NO"),
                    BnsprType.STRING, iMap.getString("DURUM_KODU"),
                    BnsprType.STRING, iMap.getString("DOVIZ_KODU"),
                    BnsprType.STRING, iMap.getString("GONDEREN_AD"),
                    BnsprType.STRING, iMap.getString("GONDEREN_TCKN"),
                    BnsprType.NUMBER, iMap.getBigDecimal("K_MIN_TUTAR"),
                    BnsprType.NUMBER, iMap.getBigDecimal("K_MAX_TUTAR"),
                    BnsprType.DATE, iMap.getDate("K_BAS_TARIH"),
                    BnsprType.DATE, iMap.getDate("K_BIT_TARIH"),
                    BnsprType.STRING, iMap.getString("BAYI_KOD")
                    };
            oMap = DALUtil.callOracleRefCursorFunction(func, "RC_TU", inputValues);

			if(!oMap.containsKey("RC_TU"))
			{
				iMap.put("HATA_NO", new BigDecimal(1614));
				return (GMMap) GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", iMap);
			}
            
            GMMap colorChanged = new GMMap();
			colorChanged.put("setBackground", Color.WHITE);
			colorChanged.put("setForeground", Color.RED);
			
			GMMap colorNotChanged  = new GMMap();
			colorNotChanged.put("setBackground", Color.WHITE);
			colorNotChanged.put("setForeground", Color.BLACK);
			
			GMMap colorCase = new GMMap();

			for (int y = 0; y < oMap.getSize("RC_TU"); y++) {
				if ("H".equals(oMap.getString("RC_TU", y, "F_IADE_EDILDIMI"))) {
					colorCase = colorNotChanged;
				}
				else {
					colorCase = colorChanged;
				}

				for (int x = 0; x < iMap.getSize("columnList"); x++) {
					oMap.put("HAVALE_COLOR", y, iMap.getString("columnList", x, "NAME"), colorCase);
				}
			}

        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
	
	@GraymoundService("BNSPR_QRY3574_HAVALE_TOPLAM_KAYIT")
    public static GMMap havaleToplamKayit(GMMap iMap) {
        GMMap oMap = new GMMap();
        try {               
            BigDecimal tmpToplamTutar = new BigDecimal(0.00);
            BigDecimal tmpToplamMasraf = new BigDecimal(0.00);
            for(int i =0; i< iMap.getSize("TBL_HAVALE");i++){
                if(iMap.getBigDecimal("TBL_HAVALE" , i , "TUTAR") != null)
                    tmpToplamTutar = tmpToplamTutar.add(iMap.getBigDecimal("TBL_HAVALE" , i , "TUTAR"));
                
                if(iMap.getBigDecimal("TBL_HAVALE" , i , "MASRAF_TUTARI") != null)
                    tmpToplamMasraf = tmpToplamMasraf.add(iMap.getBigDecimal("TBL_HAVALE" , i , "MASRAF_TUTARI"));
            }
            oMap.put("TOPLAM_TUTAR" , tmpToplamTutar);
            oMap.put("TOPLAM_MASRAF" , tmpToplamMasraf);
            oMap.put("TOPLAM_KAYIT" , iMap.getSize("TBL_HAVALE"));
            
        }
        catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
	
	@GraymoundService("BNSPR_QRY3574_LOG_FOR_CC")
    public static GMMap qry3574LogCC(GMMap iMap) {
        GMMap oMap = new GMMap();
        try{
        } catch (Exception e){
            throw ExceptionHandler.convertException(e);
        }
        return oMap;
    }
}



