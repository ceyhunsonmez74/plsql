package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftDetayTx;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2348Services {
	@GraymoundService("BNSPR_TRN2348_GET_INITIAL_VALUES")
	public static GMMap getInitialValues(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			
			stmt = conn.prepareCall("{call PKG_TRN2315.form_instance(?,?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			
			
			stmt.registerOutParameter(4, Types.DATE);
			stmt.registerOutParameter(5, Types.DECIMAL);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.execute();

			oMap.put("SUBE_KODU", stmt.getString(1));
			oMap.put("BANKA_KODU", stmt.getString(2));
			oMap.put("BANKA_ADI", stmt.getString(3));
			oMap.put("EFT_TARIH", stmt.getDate(4));
			oMap.put("TRX_NO", stmt.getBigDecimal(5));

		   	    
			  
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2348_GET_EFT_INFO")
	public static GMMap getEftInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
	        
			oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("TUTAR" , eftEftTx.getTutar());
	        oMap.put("KIYMET_KODU" , eftEftTx.getKiymetKodu());
	        oMap.put("MIKTAR" , eftEftTx.getMiktar());
	        oMap.put("KULLANICI_REFERANSI" , eftEftTx.getKullaniciReferansi());
	        oMap.put("PARCA_TESL_IZIN_GOSTERGE" , eftEftTx.getParcaTeslIzinGosterge());
	        oMap.put("CIKIS_DEPO_KODU" , eftEftTx.getCikisDepoKodu());
	        oMap.put("DONUS_TARIHI" , eftEftTx.getDonusTarihi());
	        oMap.put("DONUS_TUTARI" , eftEftTx.getDonusTutari());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("SATIS_TURU", eftEftTx.getSatisTuru());
	        oMap.put("ALIS_TARIHI" , eftEftTx.getAlisTarihi());
	        oMap.put("ALIS_BEDELI" , eftEftTx.getAlisBedeli());
	        oMap.put("ALICININ_ADI_SOYADI" , eftEftTx.getAlicininAdiSoyadi());
	        oMap.put("ALICI_HESAP_NO" , eftEftTx.getAliciHesapNo());
	        	        
	        oMap.put("TRX_NO" , eftEftTx.getTxNo());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("DURUM" , eftEftTx.getDurum());	  	  
	        
	        List<?> eftDetayList = session.createCriteria(EftEftDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        int i=0;
			for (Object name : eftDetayList) {
				EftEftDetayTx eftEftDetayTx = (EftEftDetayTx) name;
				oMap.put("EFTDETAY", i,"GONDEREN", eftEftDetayTx.getGonderen());
				oMap.put("EFTDETAY", i,"GONDEREN_VERGI_KIMLIK_NUMARASI", eftEftDetayTx.getGonderenVergiKimlikNumarasi());
				i++;
			}

	        
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_QRY2387_GET_EFT_MESAJLARI")
		public static GMMap getEftMesajlari(GMMap iMap){
			GMMap oMap = new GMMap();
			try{
				GMMap mMap = new GMMap();
				String func = "{? = call PKG_TRN2348.H04_Mesaj_al}";
				mMap = DALUtil.callOracleRefCursorFunction(func, "MESSAGES");
				int s=0;
				s= mMap.getSize("MESSAGES");
				for (int i = 0; i < s; i++) {
					oMap.put("H04_MESAJLAR",i, "TX_NO", mMap.getBigDecimal("MESSAGES",i,"TX_NO"));
					oMap.put("H04_MESAJLAR",i, "ISLEM_VALOR", mMap.getDate("MESSAGES",i,"ISLEM_VALOR"));
					oMap.put("H04_MESAJLAR",i, "TUTAR", mMap.getBigDecimal("MESSAGES",i,"TUTAR"));
					oMap.put("H04_MESAJLAR",i, "KIYMET_KODU", mMap.getString("MESSAGES",i,"KIYMET_KODU"));
					oMap.put("H04_MESAJLAR",i, "GERI_DONUS_VALORU", mMap.getDate("MESSAGES",i,"GERI_DONUS_VALORU"));
					oMap.put("H04_MESAJLAR",i, "MIKTAR", mMap.getBigDecimal("MESSAGES",i,"MIKTAR"));
					oMap.put("H04_MESAJLAR",i, "FIYAT", mMap.getBigDecimal("MESSAGES",i,"FIYAT"));
					oMap.put("H04_MESAJLAR",i, "ACIKLAMA", mMap.getString("MESSAGES",i,"ACIKLAMA"));
					oMap.put("H04_MESAJLAR",i, "MESAJ_GRUBU", mMap.getString("MESSAGES",i,"MESAJ_GRUBU"));
					oMap.put("H04_MESAJLAR",i, "ISLEM_KOD", mMap.getString("MESSAGES",i,"ISLEM_KOD"));
					oMap.put("H04_MESAJLAR",i, "IHALE_KODU", mMap.getString("MESSAGES",i,"IHALE_KODU"));
					oMap.put("H04_MESAJLAR",i, "IHALE_NO", mMap.getString("MESSAGES",i,"IHALE_NO"));
					
				}

				return oMap;
			}
			catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}
		}
	@GraymoundService("BNSPR_QRY2387_GET_H04_MESAJ")
	public static GMMap getH04Mesaj(GMMap iMap){
		GMMap oMap = new GMMap();
		try{
			GMMap mMap = new GMMap();
			Object[] iValues = new Object[2];
			iValues[0] = BnsprType.NUMBER;
			iValues[1] = iMap.getBigDecimal("ILGILI_ISLEM_NO");
			String func = "{? = call PKG_TRN2348.H04_Mesaj_detay_al(?)}";
			mMap = DALUtil.callOracleRefCursorFunction(func, "MESSAGES",iValues);
			int s=0;
			s= mMap.getSize("MESSAGES");
			for (int i = 0; i < s; i++) {
				oMap.put("TUTAR", mMap.getBigDecimal("MESSAGES",i,"TUTAR"));
				oMap.put("KIYMET_KODU", mMap.getString("MESSAGES",i,"KIYMET_KODU"));
				oMap.put("MIKTAR", mMap.getBigDecimal("MESSAGES",i,"MIKTAR"));
				oMap.put("DONUS_TARIHI", mMap.getDate("MESSAGES",i,"GERI_DONUS_VALORU"));
				oMap.put("DONUS_TUTARI", mMap.getBigDecimal("MESSAGES",i,"GERI_ODENECEK_TUTAR"));
				oMap.put("ALIS_TARIHI", mMap.getDate("MESSAGES",i,"ISLEM_VALOR"));
				
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_QRY2348_GET_H03_MESAJ")
	public static GMMap getH03Mesaj(GMMap iMap){
		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		try{
	
			conn = DALUtil.getGMConnection();

			stmt = conn	.prepareCall("{call PKG_TRN2348.H03_Mesaj_detay_al(?,?,?)}");

			stmt.setString(1, iMap.getString("TRX_NO"));
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.DECIMAL);
			
			stmt.execute();
			
			oMap.put("REFERANS", stmt.getString(2));
			oMap.put("TUTAR" , stmt.getBigDecimal(3));

			return oMap;
			
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	 finally {
		GMServerDatasource.close(stmt);
		GMServerDatasource.close(conn);
	 }
	}
}
