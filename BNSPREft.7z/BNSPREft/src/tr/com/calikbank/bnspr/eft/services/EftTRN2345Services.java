package tr.com.calikbank.bnspr.eft.services;

import org.hibernate.Session;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

import tr.com.aktifbank.bnspr.dao.EftGuncellemeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.LovHelper;

public class EftTRN2345Services {
 
	@GraymoundService("BNSPR_TRN2345_SAVE")
	public static GMMap Save (GMMap iMap){
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			EftGuncellemeTx objEftGuncellemeTx = (EftGuncellemeTx)session.get(EftGuncellemeTx.class, iMap.getBigDecimal("TRX_NO"));
			if(objEftGuncellemeTx == null) {
				objEftGuncellemeTx = new EftGuncellemeTx();
			}
			objEftGuncellemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			objEftGuncellemeTx.setEftTxNo(iMap.getBigDecimal("EFT_TX_NO"));
			objEftGuncellemeTx.setGelenGiden(iMap.getString("GELEN_GIDEN"));
			objEftGuncellemeTx.setMesajKodu(iMap.getString("MESAJ_KODU"));
			objEftGuncellemeTx.setEftTarih(iMap.getDate("EFT_TARIH"));
			objEftGuncellemeTx.setGonderenBanka(iMap.getString("GONDEREN_BANKA"));
			objEftGuncellemeTx.setGonderenSube(iMap.getString("GONDEREN_SUBE"));
			objEftGuncellemeTx.setGonderenSehir(iMap.getString("GONDEREN_SEHIR"));
			objEftGuncellemeTx.setGonderen(iMap.getString("GONDEREN"));
			objEftGuncellemeTx.setGonderenTelefon(iMap.getString("GONDEREN_TELEFON"));
			objEftGuncellemeTx.setGonderenAdres(iMap.getString("GONDEREN_ADRES"));
			objEftGuncellemeTx.setEftDurum(iMap.getString("EFT_DURUM"));
			objEftGuncellemeTx.setTutar(iMap.getBigDecimal("TUTAR"));
			objEftGuncellemeTx.setSorguNo(iMap.getBigDecimal("SORGU_NO"));
			objEftGuncellemeTx.setOrjAciklama(iMap.getString("ORJ_ACIKLAMA"));
			objEftGuncellemeTx.setGuncellemeSebebi(iMap.getString("GUNCELLEME_SEBEBI"));
			objEftGuncellemeTx.setGuncellemeAciklama(iMap.getString("GUNCELLEME_ACIKLAMA"));
			objEftGuncellemeTx.setOrjAlanBankaKodu(iMap.getString("ORJ_ALAN_BANKA_KODU"));
			objEftGuncellemeTx.setOrjAlanSubeKodu(iMap.getString("ORJ_ALAN_SUBE_KODU"));
			objEftGuncellemeTx.setOrjAlanSehirKodu(iMap.getString("ORJ_ALAN_SEHIR_KODU"));
			objEftGuncellemeTx.setOrjAliciAdi(iMap.getString("ORJ_ALICI_ADI"));
			objEftGuncellemeTx.setOrjAliciTelefonNo(iMap.getString("ORJ_ALICI_TELEFON_NO"));
			objEftGuncellemeTx.setOrjAliciAdres1(iMap.getString("ORJ_ALICI_ADRES_1"));
			objEftGuncellemeTx.setOrjAliciAdres2(iMap.getString("ORJ_ALICI_ADRES_2"));
			objEftGuncellemeTx.setOrjAliciBabaAdi(iMap.getString("ORJ_ALICI_BABA_ADI"));
			objEftGuncellemeTx.setOrjAliciHesapNo(iMap.getString("ORJ_ALICI_HESAP_NO"));
	//		objEftGuncellemeTx.setOrjAliciIban(iMap.getString("ORJ_ALICI_IBAN"));
			objEftGuncellemeTx.setOrjKartNo(iMap.getString("ORJ_KART_NO"));
			objEftGuncellemeTx.setNewAlanBankaKodu(iMap.getString("NEW_ALAN_BANKA_KODU"));
			objEftGuncellemeTx.setNewAlanSubeKodu(iMap.getString("NEW_ALAN_SUBE_KODU"));
			objEftGuncellemeTx.setNewAlanSehirKodu(iMap.getString("NEW_ALAN_SEHIR_KODU"));
			objEftGuncellemeTx.setNewAliciAdi(iMap.getString("NEW_ALICI_ADI"));
			objEftGuncellemeTx.setNewAliciTelefonNo(iMap.getString("NEW_ALICI_TELEFON_NO"));
			objEftGuncellemeTx.setNewAliciAdres1(iMap.getString("NEW_ALICI_ADRES_1"));
			objEftGuncellemeTx.setNewAliciAdres2(iMap.getString("NEW_ALICI_ADRES_2"));
			objEftGuncellemeTx.setNewAliciBabaAdi(iMap.getString("NEW_ALICI_BABA_ADI"));
			objEftGuncellemeTx.setNewAliciHesapNo(iMap.getString("NEW_ALICI_HESAP_NO"));
			objEftGuncellemeTx.setNewAciklama(iMap.getString("NEW_ACIKLAMA"));
//			objEftGuncellemeTx.setNewAliciIban(iMap.getString("NEW_ALICI_IBAN"));
			objEftGuncellemeTx.setNewKartNo(iMap.getString("NEW_KART_NO"));
			objEftGuncellemeTx.setEftDurum(iMap.getString("DURUM_KODU"));
			session.saveOrUpdate(objEftGuncellemeTx);
			session.flush();
			iMap.put("TRX_NAME", "2345");
			return GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		}
	}
	@GraymoundService("BNSPR_TRN2345_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try {
			GMMap oMap = new GMMap();
			Session session = DAOSession.getSession("BNSPRDal" );
			EftGuncellemeTx objEftGuncellemeTx = (EftGuncellemeTx)session.get(EftGuncellemeTx.class, iMap.getBigDecimal("TRX_NO"));
			
			oMap.put("TRX_NO",objEftGuncellemeTx.getTxNo());
			oMap.put("EFT_TX_NO",objEftGuncellemeTx.getEftTxNo());
			oMap.put("GELEN_GIDEN",objEftGuncellemeTx.getGelenGiden());
			oMap.put("MESAJ_KODU",objEftGuncellemeTx.getMesajKodu());
			oMap.put("EFT_TARIH",objEftGuncellemeTx.getEftTarih());
			oMap.put("GONDEREN_BANKA",objEftGuncellemeTx.getGonderenBanka());
			oMap.put("GONDEREN_SUBE",objEftGuncellemeTx.getGonderenSube());
			oMap.put("GONDEREN_SEHIR",objEftGuncellemeTx.getGonderenSehir());
			oMap.put("GONDEREN",objEftGuncellemeTx.getGonderen());
			oMap.put("GONDEREN_TELEFON",objEftGuncellemeTx.getGonderenTelefon());
			oMap.put("GONDEREN_ADRES",objEftGuncellemeTx.getGonderenAdres());
			oMap.put("EFT_DURUM",objEftGuncellemeTx.getEftDurum());
			oMap.put("TUTAR",objEftGuncellemeTx.getTutar());
			oMap.put("SORGU_NO",objEftGuncellemeTx.getSorguNo());//
			oMap.put("ORJ_ACIKLAMA",objEftGuncellemeTx.getOrjAciklama());
			oMap.put("NEW_ACIKLAMA",objEftGuncellemeTx.getNewAciklama());
			oMap.put("GUNCELLEME_SEBEBI",objEftGuncellemeTx.getGuncellemeSebebi());
			oMap.put("GUNCELLEME_ACIKLAMA",objEftGuncellemeTx.getGuncellemeAciklama());
			oMap.put("ORJ_ALAN_BANKA_KODU",objEftGuncellemeTx.getOrjAlanBankaKodu());
			oMap.put("ORJ_ALAN_SUBE_KODU",objEftGuncellemeTx.getOrjAlanSubeKodu());
			oMap.put("ORJ_ALAN_SEHIR_KODU",objEftGuncellemeTx.getOrjAlanSehirKodu());
			oMap.put("ORJ_ALICI_ADI",objEftGuncellemeTx.getOrjAliciAdi());
			oMap.put("ORJ_ALICI_TELEFON_NO",objEftGuncellemeTx.getOrjAliciTelefonNo());
			oMap.put("ORJ_ALICI_ADRES_1",objEftGuncellemeTx.getOrjAliciAdres1());
			oMap.put("ORJ_ALICI_ADRES_2",objEftGuncellemeTx.getOrjAliciAdres2());
			oMap.put("ORJ_ALICI_BABA_ADI",objEftGuncellemeTx.getOrjAliciBabaAdi());
			oMap.put("ORJ_ALICI_HESAP_NO",objEftGuncellemeTx.getOrjAliciHesapNo());
//			oMap.put("ORJ_ALICI_IBAN",objEftGuncellemeTx.getOrjAliciIban());
			oMap.put("ORJ_KART_NO",objEftGuncellemeTx.getOrjKartNo());
			oMap.put("NEW_ALAN_BANKA_KODU",objEftGuncellemeTx.getNewAlanBankaKodu());
			oMap.put("NEW_ALAN_SUBE_KODU",objEftGuncellemeTx.getNewAlanSubeKodu());
			oMap.put("NEW_ALAN_SEHIR_KODU",objEftGuncellemeTx.getNewAlanSehirKodu());
			oMap.put("NEW_ALICI_ADI",objEftGuncellemeTx.getNewAliciAdi());
			oMap.put("NEW_ALICI_TELEFON_NO",objEftGuncellemeTx.getNewAliciTelefonNo());
			oMap.put("NEW_ALICI_ADRES_1",objEftGuncellemeTx.getNewAliciAdres1());
			oMap.put("NEW_ALICI_ADRES_2",objEftGuncellemeTx.getNewAliciAdres2());
			oMap.put("NEW_ALICI_BABA_ADI",objEftGuncellemeTx.getNewAliciBabaAdi());
			oMap.put("NEW_ALICI_HESAP_NO",objEftGuncellemeTx.getNewAliciHesapNo());
//			oMap.put("NEW_ALICI_IBAN",objEftGuncellemeTx.getNewAliciIban());
			oMap.put("NEW_KART_NO",objEftGuncellemeTx.getNewKartNo());
			oMap.put("DURUM_KODU",objEftGuncellemeTx.getEftDurum());
			oMap.put("SORGU_NO",objEftGuncellemeTx.getSorguNo());
		    oMap.putAll(EftServices.getEftDiValues(objEftGuncellemeTx.getGonderenBanka(), objEftGuncellemeTx.getGonderenSube(), objEftGuncellemeTx.getGonderenSehir(), objEftGuncellemeTx.getOrjAlanBankaKodu(),objEftGuncellemeTx.getOrjAlanSubeKodu(), objEftGuncellemeTx.getOrjAlanSehirKodu()));
			
		    oMap.put("DISPLAY_NEW_ALAN_BANKA_KODU" , LovHelper.diLov(objEftGuncellemeTx.getNewAlanBankaKodu(), "2345/LOV_ALAN_BANKA", "BANKA_ADI"));
		    oMap.put("DISPLAY_NEW_ALAN_SEHIR_KODU" , LovHelper.diLov(objEftGuncellemeTx.getNewAlanSehirKodu(), objEftGuncellemeTx.getNewAlanBankaKodu(), "2315/LOV_ALAN_SEHIR", "IL_ADI"));
		    oMap.put("DISPLAY_NEW_ALAN_SUBE_KODU" , LovHelper.diLov(objEftGuncellemeTx.getNewAlanSubeKodu(), objEftGuncellemeTx.getNewAlanBankaKodu(),
		    		objEftGuncellemeTx.getNewAlanSehirKodu(), "2315/LOV_ALAN_SUBE", "SUBE_ADI"));
		    
		    return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
		}
	}
	
	@GraymoundService("BNSPR_TRN2345_GET_EFT_ODEME_BILGI")
	public static GMMap getEftBilgi(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
			
			oMap.put("EFT_TRX_NO" , eftEftTx.getTxNo());
			oMap.put("ODEME_MUSTERI_NO" , eftEftTx.getOdemeMusteriNo());
	        oMap.put("ODEME_MUSTERI_HESAP" , eftEftTx.getOdemeMusteriHesap());
	        oMap.put("ODEME_SUBE" , eftEftTx.getOdemeSube());
	        oMap.put("ODEME_DK_HESAP" , eftEftTx.getOdemeDkHesap());
	        oMap.put("DISPLAY_ODEME_SUBE" , LovHelper.diLov(eftEftTx.getOdemeSube(), "2317/LOV_BOLUM", "ADI"));
	        oMap.put("DISPLAY_MUSTERI_ADI" , LovHelper.diLov(eftEftTx.getOdemeMusteriNo(),eftEftTx.getOdemeSube(),eftEftTx.getOdemeSube(), "2317/LOV_MUSTERI", "ADI"));
	        oMap.put("ISLEM_TIPI" , eftEftTx.getIslemTipi());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("GONDEREN" , eftEftTx.getGonderen());
	        oMap.put("GONDEREN_TELEFON" , eftEftTx.getGonderenTelefon());
	        oMap.put("GONDEREN_ADRES" , eftEftTx.getGonderenAdres());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("ALICI_ADI" , eftEftTx.getAliciAdi());
	        oMap.put("ALICI_TELEFON_NO" , eftEftTx.getAliciTelefonNo());
	        oMap.put("ALICI_ADRES_1" , eftEftTx.getAliciAdres1());
	        oMap.put("ALICI_ADRES_2" , eftEftTx.getAliciAdres2());
	        oMap.put("ALICI_BABA_ADI" , eftEftTx.getAliciBabaAdi());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALICI_HESAP_NO" , eftEftTx.getAliciHesapNo());
	        oMap.put("KART_NO" , eftEftTx.getKartNo());
	        oMap.put("TUTAR" , eftEftTx.getTutar());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("DURUM" , eftEftTx.getDurum());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("KART_EK_KOD", eftEftTx.getKartEkKod());
	        oMap.put("ODEME_TX_NO", eftEftTx.getOdemeTxNo());
	        oMap.put("OTOMATIK_BILDIRIM_OLUSTUR" , eftEftTx.getOtomatikBildirimOlustur());
	        oMap.put("BILDIRIM_NO" , eftEftTx.getBildirimNo());
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
	        oMap.put("ISLEM_SAAT" ,eftEftTx.getIslemSaat());
	        oMap.put("GIRIS_SAAT" ,eftEftTx.getGirisSaat());
	        oMap.put("ODEME_TURU" ,eftEftTx.getOdemeTuru());
	        oMap.put("GELEN_GIDEN" ,eftEftTx.getGelenGiden());
	        
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
