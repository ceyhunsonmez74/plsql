package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.GnlDuzenliOdemeTx;
import tr.com.calikbank.bnspr.dao.GnlDuzenliTaksitTx;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2302Services {
	@GraymoundService("BNSPR_TRN2302_GET_DUZENLI_ODEME")
	public static Map<?, ?>  getDuzenliOdeme(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			BigDecimal txNo = iMap.getBigDecimal("TRX_NO");
			GnlDuzenliOdemeTx gnlDuzenliOdemeTx = null;
			if(txNo != null)
				gnlDuzenliOdemeTx = (GnlDuzenliOdemeTx)session.createCriteria(GnlDuzenliOdemeTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			else
				gnlDuzenliOdemeTx = (GnlDuzenliOdemeTx)session.createCriteria(GnlDuzenliOdemeTx.class).add(Restrictions.eq("siraNo", iMap.getBigDecimal("SIRA_NO"))).uniqueResult();
			GMMap oMap = new GMMap();
			oMap.put("TRX_NO", gnlDuzenliOdemeTx.getTxNo());
			oMap.put("TALIMAT_NO", gnlDuzenliOdemeTx.getSiraNo());
			oMap.put("ODEME_TIPI", gnlDuzenliOdemeTx.getOdemeTipi());
			oMap.put("ILK_ODEME_TARIHI", gnlDuzenliOdemeTx.getIlkOdemeTarihi());
			oMap.put("BITIS_DONEMI", gnlDuzenliOdemeTx.getBitisDonemi());
			oMap.put("BITIS_TARIHI", gnlDuzenliOdemeTx.getBitisTarihi());
			oMap.put("DONEM_TIPI", gnlDuzenliOdemeTx.getDonemTipi());
			oMap.put("DONEM_SURESI", gnlDuzenliOdemeTx.getDonemSuresi());
			oMap.put("ONCE_SONRA_FLAG", gnlDuzenliOdemeTx.getOnceSonraFlag());
			oMap.put("TUTAR", gnlDuzenliOdemeTx.getTutar());
			oMap.put("BILGILENDIRME_KODU", gnlDuzenliOdemeTx.getBilgilendirmeKodu());
			oMap.put("DENENECEK_SAYI", gnlDuzenliOdemeTx.getDenenecekSayi());
			oMap.put("ODEME_SEKLI", gnlDuzenliOdemeTx.getOdemeSekli());
			oMap.put("DOVIZ_KODU", gnlDuzenliOdemeTx.getDovizKodu());
			oMap.put("GON_MUSTERI_NO", gnlDuzenliOdemeTx.getGonMusteriNo());
			oMap.put("GON_HESAP_NO", gnlDuzenliOdemeTx.getGonHesapNo());
			oMap.put("GON_EK_HESAP_NO", gnlDuzenliOdemeTx.getGonEkHesapNo());
			oMap.put("SW_MASRAF_SECENEK", gnlDuzenliOdemeTx.getSwMasrafSecenek());
			oMap.put("MUH_MASRAF_HESAP_NO", gnlDuzenliOdemeTx.getMuhMasrafHesapNo());
			oMap.put("HAV_IBAN_NO", gnlDuzenliOdemeTx.getHavAliciIbanNo());
			oMap.put("HAV_SUBE_KODU", gnlDuzenliOdemeTx.getSubeKodu());
			oMap.put("HAV_MUSTERI_NO", gnlDuzenliOdemeTx.getHavMusteriNo());
			oMap.put("HAV_MUSTERI_AD", LovHelper.diLov(gnlDuzenliOdemeTx.getGonMusteriNo(), gnlDuzenliOdemeTx.getHavMusteriNo(), 
									gnlDuzenliOdemeTx.getDovizKodu(), gnlDuzenliOdemeTx.getSubeKodu(), "2301/LOV_HAV_MUSTERI_NO", "ID_DESC"));
			oMap.put("HAV_HESAP_NO", gnlDuzenliOdemeTx.getHavHesapNo());
			oMap.put("HAV_ALICI_ADI", gnlDuzenliOdemeTx.getHavAliciAdi());
			oMap.put("HAV_ACIKLAMA", gnlDuzenliOdemeTx.getHavAciklama());
			oMap.put("HAV_ALICI_TEL_NO", gnlDuzenliOdemeTx.getHavAliciTelNo());
			oMap.put("HVL_ALICI_BABA_ADI", gnlDuzenliOdemeTx.getHavBabaAdi());
			oMap.put("HVL_ALICI_ANNE_ADI", gnlDuzenliOdemeTx.getHavAnaAdi());
			oMap.put("HVL_ALICI_DOGUM_TARIHI", gnlDuzenliOdemeTx.getHavDogumTarihi());
			oMap.put("HVL_ALICI_ADRES", gnlDuzenliOdemeTx.getHavAdres());
			oMap.put("HAV_SEKLI", gnlDuzenliOdemeTx.getHavTipi());
			oMap.put("EFT_MESAJ_TIPI", gnlDuzenliOdemeTx.getEftMesajTipi());
			oMap.put("EFT_ALICI_HESAP_NO", gnlDuzenliOdemeTx.getEftAliciHesapNo());
			oMap.put("EFT_ALICI_TC_KIMLIK_NO", gnlDuzenliOdemeTx.getAliciTcKimlikNo());
			oMap.put("EFT_ALICI_ADI", gnlDuzenliOdemeTx.getEftAliciAdi());
			oMap.put("EFT_ALAN_BANKA_KODU", gnlDuzenliOdemeTx.getEftAlanBankaKodu());
			
			oMap.put("EFT_ALAN_BANKA_ADI", 
					LovHelper.diLov(gnlDuzenliOdemeTx.getEftAlanBankaKodu(), "2301/LOV_ALAN_BANKA", "BANKA_ADI"));
			
			oMap.put("EFT_ALAN_SEHIR_KODU", gnlDuzenliOdemeTx.getEftAlanSehirKodu());
			
			oMap.put("EFT_ALAN_SEHIR_ADI", 
					LovHelper.diLov(gnlDuzenliOdemeTx.getEftAlanSehirKodu(),gnlDuzenliOdemeTx.getEftAlanBankaKodu(), "2301/LOV_ALAN_SEHIR", "IL_ADI"));
			
			oMap.put("EFT_ALAN_SUBE_KODU", gnlDuzenliOdemeTx.getEftAlanSubeKodu());
			
			oMap.put("EFT_ALAN_SUBE_ADI", 
					LovHelper.diLov(gnlDuzenliOdemeTx.getEftAlanSubeKodu(),gnlDuzenliOdemeTx.getEftAlanBankaKodu(),gnlDuzenliOdemeTx.getEftAlanSehirKodu(), "2301/LOV_ALAN_SUBE", "SUBE_ADI"));
			
			oMap.put("EFT_KART_NO", gnlDuzenliOdemeTx.getEftKartNo());
			oMap.put("EFT_ACIKLAMA_1", gnlDuzenliOdemeTx.getEftAciklama1());
			oMap.put("EFT_ACIKLAMA_2", gnlDuzenliOdemeTx.getEftAciklama2());
			oMap.put("SW_ULKE_KODU", gnlDuzenliOdemeTx.getSwUlkeKodu());
			oMap.put("SW_BANKA_KODU", gnlDuzenliOdemeTx.getSwBankaKodu());
			oMap.put("SW_SEHIR_KODU", gnlDuzenliOdemeTx.getSwSehirKodu());
			oMap.put("SW_SUBE_KODU", gnlDuzenliOdemeTx.getSwSubeKodu());
			oMap.put("SW_ALICI_ADI", gnlDuzenliOdemeTx.getSwAliciAdi());
			oMap.put("SW_ALICI_HESAP_NO", gnlDuzenliOdemeTx.getSwAliciHesapNo());
			oMap.put("SW_ALICI_ADRES_1", gnlDuzenliOdemeTx.getSwAliciAdres1());
			oMap.put("SW_ALICI_ADRES_2", gnlDuzenliOdemeTx.getSwAliciAdres2());
			oMap.put("SW_ALICI_ADRES_3", gnlDuzenliOdemeTx.getSwAliciAdres3());
			oMap.put("SW_ALICI_TEL_NO", gnlDuzenliOdemeTx.getSwAliciTelNo());
			oMap.put("SW_GON_TEL_NO", gnlDuzenliOdemeTx.getSwGonTelNo());
			oMap.put("SW_ACIKLAMA_1", gnlDuzenliOdemeTx.getSwAciklama1());
			oMap.put("SW_ACIKLAMA_2", gnlDuzenliOdemeTx.getSwAciklama2());
			oMap.put("SW_ACIKLAMA_3", gnlDuzenliOdemeTx.getSwAciklama3());
			oMap.put("SW_ACIKLAMA_4", gnlDuzenliOdemeTx.getSwAciklama4());
			oMap.put("SW_BIC_KODU", gnlDuzenliOdemeTx.getSwBicKodu());
			oMap.put("KMH_KULLANILSINMI", gnlDuzenliOdemeTx.getKmhKullanilsinmi());
			oMap.put("ILK_SON_ISGUNU", gnlDuzenliOdemeTx.getIlkSonIsgunu());
			oMap.put("EFT_ALICI_IBAN_NO", gnlDuzenliOdemeTx.getEftAliciIbanNo());
			oMap.put("EFT_ALICI_TELEFON_NO", gnlDuzenliOdemeTx.getEftAliciTelNo());
			oMap.put("EFT_ALICI_BABA_ADI", gnlDuzenliOdemeTx.getEftAliciBabaAdi());
			oMap.put("EFT_ALICI_ADRESI", gnlDuzenliOdemeTx.getEftAliciHesapNo());
			oMap.put("HAV_ALICI_TEL_NO", gnlDuzenliOdemeTx.getHavAliciTelNo());
			oMap.put("SIRA_NO", gnlDuzenliOdemeTx.getSiraNo());
			oMap.put("HVL_TIPI", gnlDuzenliOdemeTx.getHavTipi());
			oMap.put("HVL_ALICI_BABA_ADI", gnlDuzenliOdemeTx.getHavBabaAdi());
			oMap.put("HVL_ALICI_ANNE_ADI", gnlDuzenliOdemeTx.getHavAnaAdi());
			oMap.put("HVL_ALICI_DOGUM_TARIHI", gnlDuzenliOdemeTx.getHavDogumTarihi());
			oMap.put("HVL_ALICI_ADRES", gnlDuzenliOdemeTx.getHavAdres());
			oMap.put("EFT_ALICI_ANNE_ADI", gnlDuzenliOdemeTx.getEftAliciAnneAdi());
			oMap.put("EFT_ODEME_TURU", gnlDuzenliOdemeTx.getEftOdemeTuru());
			if("E".equals(gnlDuzenliOdemeTx.getFIbanBilinmiyor()))
				oMap.put("FIBAN_BILINMIYOR", "true");
			else
				oMap.put("FIBAN_BILINMIYOR", "false");
			
			if("E".equals(gnlDuzenliOdemeTx.getEmailEh())){
				oMap.put("BILGILENDIRME_EMAIL", true);
			}
			else{	
				oMap.put("BILGILENDIRME_EMAIL", false);
			}
			
			if("E".equals(gnlDuzenliOdemeTx.getSmsEh())){
				oMap.put("BILGILENDIRME_SMS", true);
			}
			else{	
				oMap.put("BILGILENDIRME_SMS", false);
			}
			oMap.put("SMS_TELEFON_SIRA", gnlDuzenliOdemeTx.getCepTelSirano());
			oMap.put("BILGILENDIRME_EMAIL_TIP", gnlDuzenliOdemeTx.getEmailTip());
			 
			List<?> taksitList = session.createCriteria(GnlDuzenliTaksitTx.class).add(Restrictions.eq("id.txNo", gnlDuzenliOdemeTx.getTxNo())).addOrder(Order.asc("id.siraNo")).list();
			String tableName = "DUZENLI_TAKSIT_ISLEM";
			int row = 0;
			for (Iterator<?> iterator = taksitList.iterator(); iterator.hasNext();) {
				GnlDuzenliTaksitTx gnlDuzenliTaksitTx = (GnlDuzenliTaksitTx) iterator.next();
				oMap.put(tableName, row, "TAKSIT_TARIHI", gnlDuzenliTaksitTx.getTaksitTarihi());
				oMap.put(tableName, row, "TAKSIT_TUTAR", gnlDuzenliTaksitTx.getTaksitTutar());
				oMap.put("DENENECEK_SAYI", gnlDuzenliOdemeTx.getDenenecekSayi());
				row++;
			}
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2302_SAVE_DUZENLI_ODEME_IPTAL")
	public static Map<?, ?>  saveDuzenliOdemeIptal(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlDuzenliOdemeTx gnlDuzenliOdemeTx = new GnlDuzenliOdemeTx();
			gnlDuzenliOdemeTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			gnlDuzenliOdemeTx.setSiraNo(iMap.getBigDecimal("SIRA_NO"));
			gnlDuzenliOdemeTx.setOdemeTipi(iMap.getString("ODEME_TIPI"));
			gnlDuzenliOdemeTx.setYaratanTxno(iMap.getBigDecimal("YARATAN_TXNO"));
			session.save(gnlDuzenliOdemeTx);
			session.flush();
			iMap.put("TRX_NAME", "2302");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN2302_GET_YARATAN_TXNO")
	public static Map<?, ?>  getYaratanTxno(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			GnlDuzenliOdemeTx gnlDuzenliOdemeTx = null;
			gnlDuzenliOdemeTx = (GnlDuzenliOdemeTx)session.createCriteria(GnlDuzenliOdemeTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			GMMap oMap = new GMMap();
			oMap.put("YARATAN_TXNO", gnlDuzenliOdemeTx.getYaratanTxno());
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

		}	
}
