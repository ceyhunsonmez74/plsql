package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.aktifbank.bnspr.dao.EftKanalCutoffSaat;
import tr.com.aktifbank.bnspr.dao.EftSaatTxId;
import tr.com.calikbank.bnspr.dao.EftSaatAraligi;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

//

public class EftPAR2373Services {
	
	@GraymoundService("BNSPR_PAR2373_INITIALIZE")
	public static GMMap getInitialize(GMMap iMap) {
		return DALUtil.fillComboBox(iMap, "KANAL_KODU", false, "select kod,aciklama from v_ml_gnl_kanal_grup_kod_pr");
	}
	
	@GraymoundService("BNSPR_PAR2373_GET_EFT_GIRIS_SAAT_BILGILERI")
	public static GMMap getEftGirisSaatBilgileri(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			List<?> list1 = session.createCriteria(EftSaatAraligi.class).list();
			
			GMMap oMap = new GMMap();
			String tableName = "EFT_SAAT_ARALIGI";
			int row = 0;
			for (Iterator<?> iterator = list1.iterator(); iterator.hasNext();) {

				EftSaatAraligi eftSaatAraligi = (EftSaatAraligi) iterator
						.next();

				oMap.put(tableName, row, "BAS_DAKIKA", eftSaatAraligi.getBasDakika());
				oMap.put(tableName, row, "BAS_SAAT", eftSaatAraligi.getBasSaat());
				oMap.put(tableName, row, "MARJ_ORAN", eftSaatAraligi.getMarjOran());
				oMap.put(tableName, row, "MARJ_TUTAR", eftSaatAraligi.getMarjTutar());
				oMap.put(tableName, row, "MIN_TUTAR", eftSaatAraligi.getMinTutar());
				oMap.put(tableName, row, "SON_DAKIKA", eftSaatAraligi.getSonDakika());
				oMap.put(tableName, row, "SON_SAAT", eftSaatAraligi.getSonSaat());

				row++;
			}

			List<?> list2 = (List<?>) session
					.createCriteria(EftKanalCutoffSaat.class).list();
			
			tableName = "ILERI_EFT_SAAT";
			row = 0;
			for (Iterator<?> iterator = list2.iterator(); iterator.hasNext();) {
				EftKanalCutoffSaat eftKanalCutoffSaat = (EftKanalCutoffSaat) iterator.next();

				oMap.put(tableName, row, "CUTOFFSAAT", eftKanalCutoffSaat.getCutoffSaat());
				oMap.put(tableName, row, "KANAL_KODU", eftKanalCutoffSaat.getKanalKod());
				//rowData.put("NUMARA", eftIleriSaat.getNumara());
				row++;
			}

			Connection conn = null;
			CallableStatement stmt = null;
			try {

				conn = DALUtil.getGMConnection();

				stmt = conn
						.prepareCall("{call PKG_EFT_SAAT.saat_cek(?,?,?,?)}");

				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.registerOutParameter(2, Types.VARCHAR);
				stmt.registerOutParameter(3, Types.VARCHAR);
				stmt.registerOutParameter(4, Types.VARCHAR);

				stmt.execute();

				oMap.put("G_BAS_SAAT", stmt.getString(1));
				oMap.put("G_BAS_DAKIKA", stmt.getString(2));
				oMap.put("G_SON_SAAT", stmt.getString(3));
				oMap.put("G_SON_DAKIKA", stmt.getString(4));

				stmt = null;
				stmt = conn
						.prepareCall("{call PKG_EFT_SAAT.eft_saat_cek(?,?,?,?)}");
				stmt.registerOutParameter(1, Types.VARCHAR);
				stmt.registerOutParameter(2, Types.VARCHAR);
				stmt.registerOutParameter(3, Types.VARCHAR);
				stmt.registerOutParameter(4, Types.VARCHAR);

				stmt.execute();

				oMap.put("EFT_BAS_SAAT", stmt.getString(1));
				oMap.put("EFT_BAS_DAKIKA", stmt.getString(2));
				oMap.put("EFT_SON_SAAT", stmt.getString(3));
				oMap.put("EFT_SON_DAKIKA", stmt.getString(4));

			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_PAR2373_EFT_RELEASE_HABR_KAPA_KONTROL")
	public static GMMap getEftReleaseKapa(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_RC_EFT.EFT_RELEASE_HABR_KAPA_KONTROL}");

			stmt.registerOutParameter(1, Types.VARCHAR);

			stmt.execute();
            
			oMap.put("EFT_KAPA_EH",stmt.getString(1));
			
			
		}catch (Exception e) {
			EftServices.throwGMBusssinessException(e.getMessage());
			//throw new GMRuntimeException(0, e);
		}finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}	
	
	@GraymoundService("BNSPR_PAR2373_EFT_RELEASE_HABR_KAPA_SAVE")
	public static GMMap getFisNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		GMMap oMap = new GMMap();
		try {
			
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_RC_EFT.EFT_RELEASE_HABR_KAPA_SAVE(?)}");

			stmt.setString(1, iMap.getString("EFT_KAPA_EH"));

			stmt.execute();

		}catch (Exception e) {
			EftServices.throwGMBusssinessException(e.getMessage());
			//throw new GMRuntimeException(0, e);
		}finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}		

	@GraymoundService("BNSPR_PAR2373_SAVE")
	public static Map<?, ?> save(GMMap iMap) {
		try {
			Connection conn = null;
			CallableStatement stmt = null;
			try {
				conn = DALUtil.getGMConnection();

				stmt = conn.prepareCall("{call pkg_eft_saat.gelgon_eft_saat_update(?,?,?,?)}");

				stmt.setString(1, iMap.getString("G_BAS_SAAT"));
				stmt.setString(2, iMap.getString("G_BAS_DAKIKA"));
				stmt.setString(3, iMap.getString("G_SON_SAAT"));
				stmt.setString(4, iMap.getString("G_SON_DAKIKA"));

				stmt.execute();

				stmt = null;
				stmt = conn
						.prepareCall("{call pkg_eft_saat.eft_saat_update(?,?,?,?)}");
				stmt.setString(1, iMap.getString("EFT_BAS_SAAT"));
				stmt.setString(2, iMap.getString("EFT_BAS_DAKIKA"));
				stmt.setString(3, iMap.getString("EFT_SON_SAAT"));
				stmt.setString(4, iMap.getString("EFT_SON_DAKIKA"));

				stmt.execute();
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}

			Session session = DAOSession.getSession("BNSPRDal");

			List<?> listEftGirisSaat = (List<?>) session.createCriteria(
					EftSaatAraligi.class).list();

			for (Iterator<?> iterator = listEftGirisSaat.iterator(); iterator
					.hasNext();) {
				EftSaatAraligi eftSaatAraligi = (EftSaatAraligi) iterator
						.next();
				session.delete(eftSaatAraligi);
			}

			List<?> list1 = (List<?>) iMap.get("EFT_SAAT_ARALIGI");
			String tableName = "EFT_SAAT_ARALIGI";
			int numara = 1;
			for (int i=0;i<list1.size();i++) {
				EftSaatAraligi eftSaatAraligi = new EftSaatAraligi();

				eftSaatAraligi.setNumara(new BigDecimal(numara++));

				eftSaatAraligi.setBasDakika(iMap.getString(tableName,i, "BAS_DAKIKA"));
				eftSaatAraligi.setBasSaat(iMap.getString(tableName,i, "BAS_SAAT"));
				eftSaatAraligi.setMarjOran(iMap.getBigDecimal(tableName, i, "MARJ_ORAN"));
				eftSaatAraligi.setMarjTutar(iMap.getBigDecimal(tableName, i, "MARJ_TUTAR"));
				eftSaatAraligi.setMinTutar(iMap.getBigDecimal(tableName, i, "MIN_TUTAR"));
				eftSaatAraligi.setSonDakika(iMap.getString(tableName,i, "SON_DAKIKA"));
				eftSaatAraligi.setSonSaat(iMap.getString(tableName,i, "SON_SAAT"));

				session.save(eftSaatAraligi);
			}
			List<?> listEftGonderimSaat = (List<?>) session.createCriteria(
					EftKanalCutoffSaat.class).list();

			for (Iterator<?> iterator = listEftGonderimSaat.iterator(); iterator
					.hasNext();) {
				EftKanalCutoffSaat eftKanalCutoffSaat = (EftKanalCutoffSaat) iterator.next();
				session.delete(eftKanalCutoffSaat);
			}
			numara = 1;
			tableName = "ILERI_EFT_SAAT";
			List<?> list2 = (List<?>) iMap.get("ILERI_EFT_SAAT");
			for (int i=0;i<list2.size();i++) {
				EftKanalCutoffSaat eftKanalCutoffSaat = new EftKanalCutoffSaat();
				
				eftKanalCutoffSaat.setCutoffSaat(iMap.getString(tableName,i,"CUTOFFSAAT"));
				eftKanalCutoffSaat.setKanalKod(iMap.getString(tableName,i,"KANAL_KODU"));

				session.save(eftKanalCutoffSaat);
			}
			session.flush();

			conn = null;
			stmt = null;
			try {
				conn = DALUtil.getGMConnection();

				stmt = conn.prepareCall("{call pkg_eft_saat.ekran_kontrol}");
				stmt.execute();

			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			}finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
			GMMap messageMap = new GMMap();
			messageMap.put("MESSAGE_NO", new BigDecimal(711));
			messageMap.put("MESSAGE", (String)GMServiceExecuter.execute("BNSPR_COMMON_GET_ERROR_MESSAGE", messageMap).get("ERROR_MESSAGE"));
			return messageMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}