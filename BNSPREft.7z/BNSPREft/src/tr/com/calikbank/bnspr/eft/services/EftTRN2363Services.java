package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EftNysDetayTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftDetayTx;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;
 
public class EftTRN2363Services {
    
    @GraymoundService("BNSPR_TRN2363_GET_MESAJ_TURLERI")
    public static GMMap getAll(GMMap iMap){
        try{
            GMMap oMap = new GMMap();
            DALUtil.fillComboBox(oMap, "RESULTS", false, "select key1 kod,text from v_ml_gnl_param_text where kod = 'EFT_KAS_MESAJ_TIPLERI' and key1 in ('H03','H02') order by 1 desc");
            return oMap;
        }catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        }
    }   
    
	@GraymoundService("BNSPR_TRN2363_GET_INITIAL_VALUES")
	public static GMMap getInitialValues(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN2363.form_instance(?,?,?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.DATE);
			stmt.registerOutParameter(5, Types.DECIMAL);
			stmt.registerOutParameter(6, Types.VARCHAR);
			stmt.registerOutParameter(7, Types.VARCHAR);
			
			stmt.execute();

			oMap.put("SUBE_KODU", stmt.getString(1));
			oMap.put("BANKA_KODU", stmt.getString(2));
			oMap.put("BANKA_ADI", stmt.getString(3));
			oMap.put("EFT_TARIH", stmt.getDate(4));
			oMap.put("TRX_NO", stmt.getBigDecimal(5));
			oMap.put("ALAN_BANKA_KODU", stmt.getString(6));
			oMap.put("ALAN_BANKA_ADI", stmt.getString(7));

			oMap.put("GONDEREN_SUBE_KODU", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2363/LOV_BOLUM", "EFT_KODU"));
			oMap.put("DI_GONDEREN_SUBE_KODU", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2363/LOV_BOLUM", "ADI"));
			oMap.put("GONDEREN_SEHIR", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2363/LOV_BOLUM", "IL_KOD"));
			oMap.put("DI_GONDEREN_SEHIR", LovHelper.diLov((String) oMap.get("SUBE_KODU"), "2363/LOV_BOLUM", "IL_ADI"));

			oMap.put("ALAN_SEHIR_KODU", "006");
			ArrayList<Object> input = new ArrayList<Object>();
			input.add(stmt.getString(6));
			oMap.put("DI_ALAN_SEHIR_KODU", LovHelper.diLov((String) "006", "2363/LOV_ALAN_SEHIR", "IL_ADI", input));

			oMap.put("ALAN_SUBE_KODU", "00001");
			input = new ArrayList<Object>();
			input.add(stmt.getString(6));
			input.add("006");
			oMap.put("DI_ALAN_SUBE_KODU", LovHelper.diLov((String) "00001", "2363/LOV_ALAN_SUBE", "SUBE_ADI", input));

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2363_GET_EFT_INFO")
	public static GMMap getEftInfo(GMMap iMap) {
		String tblName="EFT_DETAY";
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			GMMap oMap = new GMMap();
			oMap.put("ONCELIK", eftEftTx.getOncelik());
			oMap.put("DURUM", eftEftTx.getDurum());
			oMap.put("EFT_TARIH", eftEftTx.getEftTarih());
			oMap.put("SORGU_NO", eftEftTx.getSorguNo());
			oMap.put("GELEN_GIDEN", eftEftTx.getGelenGiden());
			oMap.put("MESAJ_KODU", eftEftTx.getMesajKodu());
			oMap.put("ACIKLAMA", eftEftTx.getAciklama());
			oMap.put("ACIKLAMA_2", eftEftTx.getAciklama2());
			oMap.put("ACIKLAMA_3", eftEftTx.getAciklama3());
			oMap.put("ACIKLAMA_4", eftEftTx.getAciklama4());
			oMap.put("ACIKLAMA_5", eftEftTx.getAciklama5());
			oMap.put("ACIKLAMA_6", eftEftTx.getAciklama6());
			oMap.put("ALAN_SUBE_KODU", eftEftTx.getAlanSubeKodu());
			oMap.put("ALAN_SEHIR_KODU", eftEftTx.getAlanSehirKodu());
			oMap.put("ALAN_BANKA_KODU", eftEftTx.getAlanBankaKodu());
			oMap.put("GONDEREN_SEHIR", eftEftTx.getGonderenSehir());
			oMap.put("GONDEREN_SUBE", eftEftTx.getGonderenSube());
			oMap.put("GONDEREN_BANKA", eftEftTx.getGonderenBanka());
			oMap.put("BOLUM_KODU", eftEftTx.getBolumKodu());
			oMap.put("KAS_MESAJ_KODU", eftEftTx.getKasMesajKodu());
			oMap.put("BILGI", eftEftTx.getBilgi());
			oMap.put("MESAJ_GRUBU", eftEftTx.getMesajGrubu());
			oMap.put("ISLEM_TIPI", eftEftTx.getIslemTipi());
			oMap.put("DUZELTME_TURU", eftEftTx.getDuzeltmeTuru());
			oMap.put("PARCA_TESL_IZIN_GOSTERGE", eftEftTx.getParcaTeslIzinGosterge());
			oMap.put("KIYMET_KODU", eftEftTx.getKiymetKodu());
			oMap.put("ISLEM_VALOR", eftEftTx.getIslemValor());
			oMap.put("ISLEM_TURU", eftEftTx.getIslemTuru());
			oMap.put("TEKLIF_FIYAT", eftEftTx.getTeklifFiyat());
			oMap.put("MIKTAR", eftEftTx.getMiktar());
			oMap.put("ILGILI_ISLEM_REFERANSI", eftEftTx.getIlgiliIslemReferansi());
			oMap.put("KOTASYON_KODU", eftEftTx.getIhaleTur());
			oMap.put("KOTASYON_NO", eftEftTx.getKimKurum());
			oMap.put("KOTASYON_TUTAR", eftEftTx.getTutar());
			oMap.put("PP_ISLEMI", eftEftTx.getTeslimSekli());
			oMap.put("VADE_TURU", eftEftTx.getHesapTuru());
			oMap.put("FAIZ_ORANI", eftEftTx.getFaizOrani());
			oMap.put("FAIZ_TUTARI", eftEftTx.getFaizTutari());
			oMap.put("MAHSUP_TUTARI", eftEftTx.getAnapara());
			oMap.put("KIM_TUR", eftEftTx.getKimTur());
			oMap.put("IHALE_NO", eftEftTx.getIhaleNo());
			oMap.put("TEKLIF_TUR", eftEftTx.getTeklifTur());
			oMap.put("BILDIRIM_TURU", eftEftTx.getBildirimTuru());
			oMap.put("ARACI_KURUM", eftEftTx.getAraciKurum());
			oMap.put("DOVIZ_KODU", eftEftTx.getDovizKodu());
			oMap.put("DOVIZ_TUTARI", eftEftTx.getDovizTutari());
			oMap.put("VALOR", eftEftTx.getValor());			

		 	List<?> eftDetayList = session.createCriteria(EftEftDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			int i=0;
	    	for (Object name : eftDetayList) {
				EftEftDetayTx eftEftDetayTx = (EftEftDetayTx) name;
				 oMap.put(tblName,i,"KIYMET_KODU", eftEftDetayTx.getKiymetKodu());
				 oMap.put(tblName,i,"ALAC_MIKTAR", eftEftDetayTx.getAlacMiktar());
				 i++;
			}			
			
	        
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN2363_GET_PARAMS")
	public static GMMap getParams(GMMap iMap){
		GMMap oMap = new GMMap();
		try {
			oMap.put("ACIKLAMA", "");
			oMap.put("ACIKLAMA_2", "");
			oMap.put("ACIKLAMA_3", "");
			oMap.put("ACIKLAMA_4", "");
			oMap.put("ACIKLAMA_5", "");
			oMap.put("ACIKLAMA_6", "");
			if (iMap.get("REFERANS")!=null){
				oMap.put("ACIKLAMA", "REPO "+iMap.getString("REFERANS"));
			for (int i = 0; i < iMap.getSize("ISIN_LIST"); i++) {
				if (i==0){
					oMap.put("ACIKLAMA_2", "ISIN:"+iMap.getString("ISIN_LIST",i,"ISIN_CODE")+" "+"TUTAR:"+iMap.getString("ISIN_LIST",i,"TUTAR"));
				}
				if (i==1){
					oMap.put("ACIKLAMA_3", "ISIN:"+iMap.getString("ISIN_LIST",i,"ISIN_CODE")+" "+"TUTAR:"+iMap.getString("ISIN_LIST",i,"TUTAR"));
				}
				if (i==2){
					oMap.put("ACIKLAMA_4", "ISIN:"+iMap.getString("ISIN_LIST",i,"ISIN_CODE")+" "+"TUTAR:"+iMap.getString("ISIN_LIST",i,"TUTAR"));
				}
				if (i==3){
					oMap.put("ACIKLAMA_5", "ISIN:"+iMap.getString("ISIN_LIST",i,"ISIN_CODE")+" "+"TUTAR:"+iMap.getString("ISIN_LIST",i,"TUTAR"));
				}
				if (i==4){
					oMap.put("ACIKLAMA_6", "ISIN:"+iMap.getString("ISIN_LIST",i,"ISIN_CODE")+" "+"TUTAR:"+iMap.getString("ISIN_LIST",i,"TUTAR"));
				}
				
			}
			}	
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
