package tr.com.calikbank.bnspr.eft.services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EftNysDetayTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;

import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2392Services {
	@GraymoundService("BNSPR_TRN2392_GET_EFT_INFO")
	public static GMMap getInfo(GMMap iMap) {
		String tblName = "EFT_NYS_DETAY";
		try {
			Session session = DAOSession.getSession("BNSPRDal");

			EftEftTx eftEftTx = (EftEftTx) session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));

			GMMap oMap = new GMMap();

			oMap.put("TRX_NO", eftEftTx.getTxNo());
			oMap.put("MESAJ_KODU", eftEftTx.getMesajKodu());
			oMap.put("SORGU_NO", eftEftTx.getSorguNo());
			oMap.put("EFT_TARIH", eftEftTx.getEftTarih());
			oMap.put("ONCELIK", eftEftTx.getOncelik().toString());
			oMap.put("DURUM", eftEftTx.getDurum());
			oMap.put("BOLUM_KODU", eftEftTx.getBolumKodu());
			oMap.put("GONDEREN_BANKA", eftEftTx.getGonderenBanka());
			oMap.put("GONDEREN_SUBE", eftEftTx.getGonderenSube());
			oMap.put("GONDEREN_SEHIR", eftEftTx.getGonderenSehir());
			oMap.put("ALAN_BANKA_KODU", eftEftTx.getAlanBankaKodu());
			oMap.put("ALAN_SEHIR_KODU", eftEftTx.getAlanSehirKodu());
			oMap.put("ALAN_SUBE_KODU", eftEftTx.getAlanSubeKodu());
			oMap.put("ACIKLAMA", eftEftTx.getAciklama());
			oMap.put("GELEN_GIDEN", eftEftTx.getGelenGiden());
			oMap.put("KIM_TUR", eftEftTx.getKimTur());
			oMap.put("VERGI_NO", eftEftTx.getVergiNo());
			oMap.put("KIM_KURUM", eftEftTx.getKimKurum());

			oMap.put("BANKA", eftEftTx.getBankaKodu());
			oMap.put("ISLEM_TARIHI", eftEftTx.getAlisTarihi());
			oMap.put("YETKILI_KISI_TCKN", eftEftTx.getBildirimNo());
			oMap.put("KEY1", eftEftTx.getSubeKodu());
			oMap.put("TEXT", LovHelper.diLov((String) oMap.get("KEY1"), "2391/LOV_SUBE_DEPO", "TEXT"));

			oMap.put("MESAJ_GRUBU", eftEftTx.getMesajGrubu());

			if ("HAT".equals(eftEftTx.getMesajGrubu())) {
				oMap.put("HATA_KODU", eftEftTx.getHataKodu());
				oMap.put("HATA_ISLEM_REFERANS", eftEftTx.getReferansNo());
				oMap.put("HATA_ACIKLAMA", eftEftTx.getBilgi());
			}
			else {
				oMap.put("BEKLENEN_TUTAR", eftEftTx.getTutar());
				oMap.put("GERCEKLESEN_TUTAR", eftEftTx.getDonusTutari());
				oMap.put("MASRAF", eftEftTx.getMasraf());
				oMap.put("NEW_ISLEM_REFERANS_NO", eftEftTx.getReferansNo());
				oMap.put("TEDIYE_TUTAR", eftEftTx.getGeriOdenecekTutar());

			}

			List<?> eftNysDetayTx = session.createCriteria(EftNysDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			int i = 0;
			for (Object name : eftNysDetayTx) {
				EftNysDetayTx eftEftDetayTx = (EftNysDetayTx) name;
				oMap.put(tblName, i, "BARKOD_NO", eftEftDetayTx.getBarkodNumarasi());
				oMap.put(tblName, i, "EMISYON_GRUP", eftEftDetayTx.getEmisyonGrubu());
				oMap.put(tblName, i, "KAP_TURU", eftEftDetayTx.getKapTuru());
				oMap.put(tblName, i, "KUPUR_BILGISI", eftEftDetayTx.getKupurBilgisi());
				oMap.put(tblName, i, "PAKET_SAYISI", eftEftDetayTx.getPaketSayisi());
				oMap.put(tblName, i, "DURUM", eftEftDetayTx.getDurum());
				oMap.put(tblName, i, "FARK_KUPUR_BILGISI", eftEftDetayTx.getFarkKupuru());
				oMap.put(tblName, i, "FARK_TURU", eftEftDetayTx.getFarkTuru());
				oMap.put(tblName, i, "FARK_SAYISI", eftEftDetayTx.getFarkSayisi());
				i++;
			}

			oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(), eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));

			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
