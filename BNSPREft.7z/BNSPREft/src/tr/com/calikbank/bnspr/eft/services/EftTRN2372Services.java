package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class EftTRN2372Services {
	
	@GraymoundService("BNSPR_TRN2372_GET_DURUM_KODLARI")
	public static GMMap getBasvuruIadeKodAll(GMMap iMap){
		try{
			GMMap oMap = new GMMap();
			DALUtil.fillComboBox(oMap, "DURUM_KODU", true, "select key1 kod,text from v_ml_gnl_param_text t where t.KOD = 'GELEN_EFT_DURUM' and t.KEY1 in ('PTT_ODNCK', 'PTT_SORUN', 'PTT_OK')");
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}	

	@GraymoundService("BNSPR_TRN2372_GET_EFT_MESAJLARI")
	public static GMMap getEftList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{? = call PKG_RC_EFT.RC_TRN2372_GET_EFT_MESAJLARI(?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(1, -10);
			
			if(iMap.getString("K_DURUM_KODU")!=null && !iMap.getString("K_DURUM_KODU").equals("")){
				stmt.setString(2, iMap.getString("K_DURUM_KODU"));
			}else {
				stmt.setString(2, null);
			}
			stmt.setString(3, iMap.getString("K_SORGU_NO"));
			stmt.setString(4, iMap.getString("K_GONDEREN_BANKA"));
			
			if (iMap.getBigDecimal("K_MIN_TUTAR").compareTo(BigDecimal.ZERO)==0) {
				stmt.setBigDecimal(5, null);
			} else {
				stmt.setBigDecimal(5, iMap.getBigDecimal("K_MIN_TUTAR"));
			}

			if (iMap.getBigDecimal("K_MAX_TUTAR").compareTo(BigDecimal.ZERO)==0) {
				stmt.setBigDecimal(6, null);
			} else {
				stmt.setBigDecimal(6, iMap.getBigDecimal("K_MAX_TUTAR"));
			}
			if (!(iMap.getDate("K_EFT_TARIH_BAS") == null)) {
				stmt.setDate(7,  new java.sql.Date(iMap.getDate("K_EFT_TARIH_BAS").getTime()));
			} else {
					stmt.setDate(7, null);
			}
			if (!(iMap.getDate("K_EFT_TARIH_BIT") == null)) {
					stmt.setDate(8,  new java.sql.Date(iMap.getDate("K_EFT_TARIH_BIT").getTime()));
			} else {
					stmt.setDate(8, null);
			}
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);

			GMMap oMap = new GMMap();
			String tableName = "EFT_MESAJLARI";
			int row = 0;
			BigDecimal toplamTutar = new BigDecimal(0);
			while (rSet.next()) {
				oMap.put(tableName, row, "TRX_NO", rSet.getBigDecimal("tx_no"));
				oMap.put(tableName, row, "SORGU_NO", rSet.getBigDecimal("sorgu_no"));
				oMap.put(tableName, row, "MESAJ_KODU", rSet.getString("mesaj_kodu"));
				oMap.put(tableName, row, "TUTAR", rSet.getBigDecimal("TUTAR"));
				oMap.put(tableName, row, "GONDEREN_BANKA_KODU", rSet.getString("gonderen_banka"));
				oMap.put(tableName, row, "BANKA_ADI", rSet.getString("banka_adi"));
				oMap.put(tableName, row, "ALICI_HESAP_NO", rSet.getString("alici_hesap_no"));
				oMap.put(tableName, row, "ALICI_ADI", rSet.getString("alici_adi"));
				oMap.put(tableName, row, "EFT_TARIH", rSet.getDate("eft_tarih"));
				oMap.put(tableName, row, "DURUM_ACIKLAMA", rSet.getString("durum_aciklama"));
				oMap.put(tableName, row, "DURUM", rSet.getString("durum"));
				oMap.put(tableName, row, "ACIKLAMA", rSet.getString("sorunlu_aciklama"));
				
				toplamTutar = toplamTutar.add(rSet.getBigDecimal("tutar"));
				row++; 
			}

			oMap.put("TOPLAM_TUTAR", toplamTutar);
			oMap.put("KAYIT_SAYISI", row);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2372_EFT_STATU_DEGISTIR")
	public static GMMap eftStatuDegistir(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			conn = DALUtil.getGMConnection();
			
			stmt = conn.prepareCall("{call pkg_eft.UPT_EFT_Statu_Degistir(?,?)}");
			stmt.setString(1, iMap.getString("EFT_TX_NO"));
			stmt.setString(2, iMap.getString("ACIKLAMA"));
			stmt.execute();
			
			return new GMMap();
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
}
