package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EftHabrgenlEtiketTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2319Services {
	@GraymoundService("BNSPR_TRN2319_GET_INITIAL_VALUES")
	public static GMMap getInitialValues(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_TRN2319.form_instance(?,?,?,?,?)}");

			stmt.registerOutParameter(1, Types.VARCHAR);
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.DATE);
			stmt.registerOutParameter(5, Types.DECIMAL);
			stmt.execute();

			oMap.put("SUBE_KODU", stmt.getString(1));
			oMap.put("BANKA_KODU", stmt.getString(2));
			oMap.put("BANKA_ADI", stmt.getString(3));
			oMap.put("EFT_TARIH", stmt.getDate(4));
			oMap.put("TRX_NO", stmt.getBigDecimal(5));

			oMap.put("GONDEREN_SUBE_KODU", LovHelper.diLov((String) oMap
					.get("SUBE_KODU"), "2319/LOV_BOLUM", "EFT_KODU"));
			oMap.put("DI_GONDEREN_SUBE_KODU", LovHelper.diLov(
					(String) oMap.get("SUBE_KODU"), "2319/LOV_BOLUM", "ADI"));
			oMap.put("GONDEREN_SEHIR", LovHelper.diLov((String) oMap
					.get("SUBE_KODU"), "2319/LOV_BOLUM", "IL_KODU"));
			oMap.put("DI_GONDEREN_SEHIR", LovHelper.diLov((String) oMap
					.get("SUBE_KODU"), "2319/LOV_BOLUM", "IL_ADI"));

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@SuppressWarnings("unchecked")
	@GraymoundService("BNSPR_TRN2319_GET_EFT_INFO")
	public static GMMap getEftInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
	        
			oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("ACIKLAMA_2" , eftEftTx.getAciklama2());
	        oMap.put("ACIKLAMA_3" , eftEftTx.getAciklama3());
	        oMap.put("ACIKLAMA_4" , eftEftTx.getAciklama4());
	        oMap.put("ACIKLAMA_5" , eftEftTx.getAciklama5());
	        oMap.put("ACIKLAMA_6" , eftEftTx.getAciklama6());
	        oMap.put("TRX_NO" , eftEftTx.getTxNo());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("DURUM" , eftEftTx.getDurum());
	        oMap.put("ILGILI_ISLEM_NUMARA" , eftEftTx.getIlgiliIslemNumara());
	        oMap.put("BILGI" , eftEftTx.getBilgi());
	        oMap.put("IADE_KODU", eftEftTx.getIadeKodu());	        
	        
	        oMap.put("IADE_TALEBI", false);
	        oMap.put("AYRINTI_TALEBI", false);
	        oMap.put("AYRINTI_GONDERIMI", false);

	        if(eftEftTx.getIslemTipi() != null){
	        
		        if(eftEftTx.getIslemTipi().equals("I"))
		        {
		        	oMap.put("IADE_TALEBI", true);
		        }
		        else if(eftEftTx.getIslemTipi().equals("A"))
		        {
		        	oMap.put("AYRINTI_TALEBI", true);
		        }
		        else if(eftEftTx.getIslemTipi().equals("G"))
		        {
		        	oMap.put("AYRINTI_GONDERIMI", true);
		        }
		        
	        }
	       
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
			
	        
	        List<EftHabrgenlEtiketTx> islemTuruTablo = session.createCriteria(EftHabrgenlEtiketTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
	        
	        if(islemTuruTablo != null)
	        {
	        String tableName = "ISLEM_TURU_TABLO";
	        
	        int row = 0;
	        
	        for(EftHabrgenlEtiketTx birEftHabrgenlEtiketTx : islemTuruTablo)
	        {
	        	oMap.put(tableName, row, "SIRA_NO", birEftHabrgenlEtiketTx.getId().getSiraNo());
	        	oMap.put(tableName, row, "ETIKET", birEftHabrgenlEtiketTx.getEtiket());
	        	oMap.put(tableName, row, "DEGER", birEftHabrgenlEtiketTx.getDeger());
	        	row++;
	        }
	        
	        }

			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN2319_OPEN_RELATED_TRANSACTION")
	public static GMMap openRelatedTransaction(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TX.Islem_kod(?)}");
			
			stmt.registerOutParameter(1, Types.BIGINT);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ILGILI_ISLEM_NUMARA"));
			stmt.execute();
			
			oMap.put("GUIML","BNSPR_TRN"+stmt.getBigDecimal(1)+".guiml");
		
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2319_HABR_ALICI_BUL")
	public static GMMap getHabrAliciBul(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{call PKG_TRN2319.HABR_alici_bul(?,?,?,?)}");
			
			stmt.setBigDecimal(1, iMap.getBigDecimal("ILGILI_ISLEM_NUMARA"));
			stmt.registerOutParameter(2, Types.VARCHAR);
			stmt.registerOutParameter(3, Types.VARCHAR);
			stmt.registerOutParameter(4, Types.VARCHAR);
			stmt.execute();
			
			oMap.put("ALAN_BANKA_KODU", stmt.getString(2));
			oMap.put("ALAN_SUBE_KODU", stmt.getString(3));
			oMap.put("ALAN_SEHIR_KODU", stmt.getString(4));
			
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
}
