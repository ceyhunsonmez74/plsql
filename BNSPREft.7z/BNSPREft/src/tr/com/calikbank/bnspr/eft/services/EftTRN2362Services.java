package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.Types;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2362Services {
	@GraymoundService("BNSPR_TRN2362_GET_EFT_MERKEZ_MI")
	public static GMMap getEftMerkez(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_eft.is_eft_merkezi(?)}");

			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setString(2, iMap.getString("SUBE_KODU"));

			stmt.execute();

			oMap.put("EFT_MERKEZ_MI", stmt.getBigDecimal(1));
			oMap.put("K_ALAN_SUBE", LovHelper.diLov(iMap.getString("SUBE_KODU"), "2362/LOV_BOLUM", "EFT_KODU"));
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	@GraymoundService("BNSPR_TRN2362_GET_EFT_MESAJLARI")
	public static GMMap getEftList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_RC_EFT.RC_TRN2362_GET_EFT_MESAJLARI (?,?,?,?,?,?,?,?,?,?,?,?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("K_ALAN_SUBE"));
			stmt.setString(i++, iMap.getString("K_BOLUM"));
			stmt.setString(i++, iMap.getString("K_MESAJ_KODU"));
			stmt.setString(i++, iMap.getString("K_SORGU_NO"));
			stmt.setString(i++, iMap.getString("K_MUSTERI_NO"));
			stmt.setString(i++, iMap.getString("K_MUSTERI_HESAP_NO"));
			stmt.setString(i++, iMap.getString("K_GONDEREN_BANKA"));
			
			if (iMap.getBigDecimal("K_MIN_TUTAR").compareTo(BigDecimal.ZERO)==0) {
				stmt.setBigDecimal(i++, null);
			} else {
				stmt.setBigDecimal(i++, iMap.getBigDecimal("K_MIN_TUTAR"));
			}

			if (iMap.getBigDecimal("K_MAX_TUTAR").compareTo(BigDecimal.ZERO)==0) {
				stmt.setBigDecimal(i++, null);
			} else {
				stmt.setBigDecimal(i++, iMap.getBigDecimal("K_MAX_TUTAR"));
			}
			
			stmt.setString(i++, iMap.getString("K_ALAN_MUSTERI_ADI"));
			
			if(iMap.getDate("K_BAS_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("K_BAS_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			
			if(iMap.getDate("K_BIT_TARIH") != null) {
				stmt.setDate(i++, new Date(iMap.getDate("K_BIT_TARIH").getTime()));
			}
			else {
				stmt.setDate(i++, null);
			}
			
			
			
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			GMMap oMap = new GMMap();
			String tableName = "EFT_MESAJLARI";
			int row = 0;
			BigDecimal toplamTutar = new BigDecimal(0);
			while (rSet.next()) {
				oMap.put(tableName, row, "TRX_NO", rSet.getString("tx_no"));
				oMap.put(tableName, row, "SORGU_NO", rSet.getString("sorgu_no"));
				oMap.put(tableName, row, "MESAJ_KODU", rSet.getString("mesaj_kodu"));
				oMap.put(tableName, row, "TUTAR", rSet.getString("TUTAR"));
				oMap.put(tableName, row, "GONDEREN_BANKA_KODU", rSet.getString("gonderen_banka"));
				oMap.put(tableName, row, "BANKA_ADI", rSet.getString("banka_adi"));
				oMap.put(tableName, row, "ALICI_HESAP_NO", rSet.getString("alici_hesap_no"));
				oMap.put(tableName, row, "ALICI_ADI", rSet.getString("alici_adi"));
				oMap.put(tableName, row, "EFT_TARIH", rSet.getDate("eft_tarih"));
				oMap.put(tableName, row, "ODEME_ACIK", rSet.getString("odeme_acik"));
	            oMap.put(tableName, row, "YETKI_2311", rSet.getString("yetki_2311"));
	            oMap.put(tableName, row, "ILGILI_ISLEM_NO", rSet.getString("ILGILI_ISLEM_NO"));
	            oMap.put(tableName, row, "ILGILI_ISLEM_TXNO", rSet.getString("ILGILI_ISLEM_TXNO"));
				
				toplamTutar = toplamTutar.add(rSet.getBigDecimal("tutar"));
				row++; 
			}

			oMap.put("TOPLAM_TUTAR", toplamTutar);
			oMap.put("KAYIT_SAYISI", row);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}

@GraymoundService("BNSPR_TRN2362_ALICI_SUBE_GUNCELLE")
public static GMMap getAliciSubeGuncelle(GMMap iMap) {
	Connection conn = null;
	CallableStatement stmt = null;
	GMMap myMap = new GMMap();
	try {
		conn = DALUtil.getGMConnection();
		stmt = conn.prepareCall("{ ?=call PKG_EFT.EFT_Alici_Sube_Guncelle (?,?)}");
		int i = 1;
		
		stmt.registerOutParameter(i++, Types.DECIMAL);
		stmt.setString(i++, iMap.getString("K_ISLEM_NO"));
		stmt.setString(i++, iMap.getString("K_SUBE_KOD"));
		stmt.execute();
		
		if(stmt.getBigDecimal(1).compareTo(new BigDecimal(1)) == 0){
			myMap.put("HATA_NO", "1805");
			myMap.put("P1",  iMap.getString("K_SUBE_KOD"));
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", myMap);
		}
		else{
			myMap.put("HATA_NO", "232");
			GMServiceExecuter.execute("BNSPR_COMMON_HATA_YAZ", myMap);
		}
			
		return myMap;
	
	} catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	} finally {
		GMServerDatasource.close(stmt);
		GMServerDatasource.close(conn);
	}
}



}


