package tr.com.calikbank.bnspr.eft.services;

import org.hibernate.Session;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2378Services {
	
	@GraymoundService("BNSPR_TRN2378_GET_EFT_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();

	        oMap.put("TRX_NO" , eftEftTx.getTxNo());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("DURUM" , eftEftTx.getDurum());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("TUTAR" , eftEftTx.getTutar());
	        oMap.put("ALICI_HES_BULUN_KURUM" , eftEftTx.getAliciHesBulunKurum());
	        oMap.put("ALICI_HES_BULUN_KURUM_HESAP_NO" ,eftEftTx.getAliciHesBulunKurumHesapNo());
	        oMap.put("NIHAI_ALICI" , eftEftTx.getNihaiAlici());
	        oMap.put("NIHAI_ALICI_HESAP_NO" , eftEftTx.getNihaiAliciHesapNo());
	        oMap.put("AMIR_KURUM" , eftEftTx.getAmirKurum());
	        oMap.put("AMIR" , eftEftTx.getAmir());
	        oMap.put("ARACI_KURUM" , eftEftTx.getAraciKurum());
	        oMap.put("ODEME_TURU" , eftEftTx.getOdemeTuru());
	        oMap.put("GONDEREN" , eftEftTx.getGonderen());
	        oMap.put("ODEME_KAYNAK" , eftEftTx.getOdemeKaynak());
	        oMap.put("NIHAI_ALICI_KURUM" , eftEftTx.getNihaiAliciKurum());
	        oMap.put("NIHAI_ALICI_KURUM_HESAP_NO" , eftEftTx.getNihaiAliciKurumHesapNo());
	        oMap.put("ARACI_KURUM_HESAP_NO" , eftEftTx.getAraciKurumHesapNo());
            oMap.put("ILGILI_ISLEM_NUMARA" , eftEftTx.getIlgiliIslemNumara());
            oMap.put("ILGILI_ISLEM_REFERANSI" , eftEftTx.getIlgiliIslemReferansi());
            oMap.put("ON_BILDIRIM_REF", eftEftTx.getOnBildirimReferansi());
	        oMap.put("CMB_ONBILDIRIM_TURU", eftEftTx.getOnBildirimTuru());
	        oMap.put("ISLEM_VALOR", eftEftTx.getIslemValor());
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
            oMap.put("MESAJ_GRUBU", eftEftTx.getMesajGrubu());

	     
	      
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
}
