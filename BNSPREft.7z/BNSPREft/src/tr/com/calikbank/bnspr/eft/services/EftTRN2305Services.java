package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Map;

import org.hibernate.Session;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftGelgonGirisTx;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2305Services {
	@GraymoundService("BNSPR_TRN2305_GET_EFT_LIST")
	public static GMMap getEftList(GMMap iMap) {
	                                                                  
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();

			StringBuilder query = new StringBuilder();

			query.append("select g.eft_urun_tur,g.musteri_no,Pkg_musteri.unvan(g.musteri_no) as unvan,g.hesap_no,g.dk_no," );
			query.append("g.tutar,g.banka_kodu,g.sorgu_no,g.giren_kullanici,g.tx_no,pkg_trn2305.Kull_Oran(g.tx_no) as ndb_kull_oran ");
			query.append("from EFT_GELGON_GIRIS g ");
			query.append("where eft_urun_tur = NVL(?,eft_urun_tur) ");
			query.append("and NVL(musteri_no,0) = NVL(?,NVL(musteri_no,0)) ");
			query.append("and nvl(banka_kodu,0) = NVL(?,nvl(banka_kodu,0)) ");
			query.append("and tutar between NVL(?,tutar) and NVL(?,tutar) ");
			query.append("and (mesaj_tipi = NVL(?,mesaj_tipi) or mesaj_tipi is null) ");
			query.append("and NVL(hesap_no,0) = NVL(?,NVL(hesap_no,0)) ");
			query.append("and nvl(dk_no,'0') = NVL(?,nvl(dk_no,'0')) ");
			query.append("and nvl(banka_sube_kodu,0) = NVL(?,nvl(banka_sube_kodu,0)) ");		
			query.append("and DURUM_KODU NOT IN ('I','K') ");
			query.append("AND ISLEM_TARIHI = pkg_global.GET_BANKATARIH ");
			query.append("AND YARATAN_BOLUM_KODU = pkg_global.GET_SUBEKOD ");
			
			if(iMap.getString("SIRALAMA_KRITERI").equals("ASC")){
				query.append("order by tutar ASC");
			}else if(iMap.getString("SIRALAMA_KRITERI").equals("DESC")){
				query.append("order by tutar DESC");
			}		

			stmt = conn.prepareCall(query.toString());

			stmt.setString(1, iMap.getString("EFT_URUN_TUR"));
			stmt.setString(2, iMap.getString("MUSTERI_NO"));
			stmt.setString(3, iMap.getString("BANKA_KODU"));
			
			if (iMap.getBigDecimal("MIN_TUTAR").compareTo(BigDecimal.ZERO)==0) {
				stmt.setBigDecimal(4, null);
			} else {
				stmt.setBigDecimal(4, iMap.getBigDecimal("MIN_TUTAR"));
			}

			if (iMap.getBigDecimal("MAX_TUTAR").compareTo(BigDecimal.ZERO)==0) {
				stmt.setBigDecimal(5, null);
			} else {
				stmt.setBigDecimal(5, iMap.getBigDecimal("MAX_TUTAR"));
			}
			
			stmt.setString(6, iMap.getString("MESAJ_TIPI"));
			stmt.setString(7, iMap.getString("HESAP_NO"));
			stmt.setString(8, iMap.getString("DK_NO"));
			stmt.setString(9, iMap.getString("BANKA_SUBE_KODU"));

			rSet = stmt.executeQuery();

			GMMap oMap = new GMMap();
			String tableName = "GELGON_EFT_GIRIS";
			int row = 0;
			BigDecimal toplamTutar = new BigDecimal(0);
			while (rSet.next()) {
				oMap.put(tableName, row, "EFT_URUN_TUR", rSet.getString("eft_urun_tur"));
				oMap.put(tableName, row, "MUSTERI_NO", rSet.getString("musteri_no"));
				oMap.put(tableName, row, "UNVAN", rSet.getString("unvan"));
				oMap.put(tableName, row, "HESAP_NO", rSet.getString("hesap_no"));
				oMap.put(tableName, row, "DK_NO", rSet.getString("dk_no"));
				oMap.put(tableName, row, "TUTAR", rSet.getString("tutar"));
				oMap.put(tableName, row, "BANKA_KODU", rSet.getString("BANKA_KODU"));
				oMap.put(tableName, row, "SORGU_NO", rSet.getString("sorgu_no"));
				oMap.put(tableName, row, "GIREN_KULLANICI", rSet.getString("giren_kullanici"));
				oMap.put(tableName, row, "TRX_NO", rSet.getString("tx_no"));
				oMap.put(tableName, row, "NDB_KUL_ORAN", rSet.getString("ndb_kull_oran"));
               
				toplamTutar = toplamTutar.add(rSet.getBigDecimal("tutar"));
				row++;
			}

			oMap.put("TOPLAM_TUTAR", toplamTutar);

			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2305_EFT_BILGI_AKTAR")
	public static GMMap eftBilgiAktar(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call pkg_trn2305.bilgiaktar(?)}");

			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ESKI_TRX_NO"));
			stmt.execute();

			oMap.put("TRX_NO", stmt.getBigDecimal(1));
			
			stmt = null;
			stmt = conn.prepareCall("{? = call pkg_trn2305.kullanilan_tutar(?)}");
			stmt.registerOutParameter(1, Types.FLOAT);
			stmt.setBigDecimal(2, iMap.getBigDecimal("ESKI_TRX_NO"));
			
			stmt.execute();
			
			oMap.put("KULLANILAN_TUTAR", stmt.getBigDecimal(1));
				
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_TRN2305_GET_EFT_BILGI")
	public static GMMap getEftBilgi(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftGelgonGirisTx eftGelgonGirisTx = (EftGelgonGirisTx) session
					.load(EftGelgonGirisTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
			
			oMap.put("DURUM_KODU", eftGelgonGirisTx.getDurumKodu());
			oMap.put("EFT_URUN_TUR", eftGelgonGirisTx.getEftUrunTur());
			oMap.put("MESAJ_TIPI", eftGelgonGirisTx.getMesajTipi());
			oMap.put("SORGU_NO", eftGelgonGirisTx.getSorguNo());
			oMap.put("BANKA_KODU", eftGelgonGirisTx.getBankaKodu());
			oMap.put("BANKA_SUBE_ADI", LovHelper.diLov(eftGelgonGirisTx.getBankaSubeKodu(),eftGelgonGirisTx.getBankaKodu(), "2305/LOV_SUBE_KODLARI_ISLEM", "SUBE_ADI"));
			oMap.put("BANKA_ADI", LovHelper.diLov(eftGelgonGirisTx.getBankaKodu(), "2305/LOV_BANKA_ISLEM", "BANKA_ADI"));
			oMap.put("BANKA_SUBE_KODU", eftGelgonGirisTx.getBankaSubeKodu());
			oMap.put("MUSTERI_NO", eftGelgonGirisTx.getMusteriNo());
			oMap.put("HESAP_TIPI", eftGelgonGirisTx.getHesapTipi());
			oMap.put("HESAP_NO", eftGelgonGirisTx.getHesapNo());
			oMap.put("DK_NO", eftGelgonGirisTx.getDkNo());
			oMap.put("NDB_DKADI", LovHelper.diLov(eftGelgonGirisTx.getDkNo(), "2305/LOV_DK", "ACIKLAMA"));
			oMap.put("TUTAR", eftGelgonGirisTx.getTutar());
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	@GraymoundService("BNSPR_TRN2305_SAVE")
	public static Map<?, ?> save(GMMap iMap) {

		try {
			Session session = DAOSession.getSession("BNSPRDal");

			EftGelgonGirisTx eftGelgonGirisTx = (EftGelgonGirisTx) session
					.get(EftGelgonGirisTx.class, iMap.getBigDecimal("TRX_NO"));
			if(eftGelgonGirisTx == null)eftGelgonGirisTx = new EftGelgonGirisTx();

			eftGelgonGirisTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			eftGelgonGirisTx.setDurumKodu(iMap.getString("DURUM_KODU"));
			eftGelgonGirisTx.setEftUrunTur(iMap.getString("EFT_URUN_TUR"));
			eftGelgonGirisTx.setMesajTipi(iMap.getString("MESAJ_TIPI"));
			eftGelgonGirisTx.setHesapTipi(iMap.getString("HESAP_TIPI"));
			eftGelgonGirisTx.setBankaKodu(iMap.getString("BANKA_KODU"));
			eftGelgonGirisTx.setBankaSubeKodu(iMap.getString("BANKA_SUBE_KODU"));
			eftGelgonGirisTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			eftGelgonGirisTx.setHesapNo(iMap.getBigDecimal("HESAP_NO"));
			eftGelgonGirisTx.setDkNo(iMap.getString("DK_NO"));
			eftGelgonGirisTx.setTutar(iMap.getBigDecimal("TUTAR"));
			eftGelgonGirisTx.setSorguNo(iMap.getBigDecimal("SORGU_NO"));

			session.saveOrUpdate(eftGelgonGirisTx);
			session.flush();

			iMap.put("TRX_NAME", "2305");

			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
}
