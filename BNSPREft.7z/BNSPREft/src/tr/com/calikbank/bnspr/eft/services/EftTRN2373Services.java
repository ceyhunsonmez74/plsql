package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EftGelgonSaatTx;
import tr.com.aktifbank.bnspr.dao.EftGelgonSaatTxId;
import tr.com.aktifbank.bnspr.dao.EftKanalCutoffSaatTx;
import tr.com.aktifbank.bnspr.dao.EftKanalCutoffSaatTxId;
import tr.com.aktifbank.bnspr.dao.EftOtoReleaseParametreTx;
import tr.com.aktifbank.bnspr.dao.EftSaatAraligiTx;
import tr.com.aktifbank.bnspr.dao.EftSaatAraligiTxId;
import tr.com.aktifbank.bnspr.dao.EftSaatTx;
import tr.com.aktifbank.bnspr.dao.EftSaatTxId;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2373Services {
	
	@GraymoundService("BNSPR_TRN2373_CREATE_TRX_NO")
	public static GMMap createIadeTRX_NO(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		try {

			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_TRN2373.EftSaatAktar() }");

			stmt.registerOutParameter(1, Types.DECIMAL);
			stmt.execute();

			BigDecimal txNo = stmt.getBigDecimal(1);

			oMap.put("TRX_NO", txNo);

			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}		
	
	
	@GraymoundService("BNSPR_TRN2373_INITIALIZE")
	public static GMMap getInitialize(GMMap iMap) {
		return DALUtil.fillComboBox(iMap, "KANAL_KODU", false, "select kod,aciklama from v_ml_gnl_kanal_grup_kod_pr");
	}
	
	
	@GraymoundService("BNSPR_TRN2373_GET_INFO")
	public static GMMap getInfo(GMMap iMap) {

		GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		

		
		
		try {
			String tableName = "EFT_SAAT_ARALIGI";
			Session session = DAOSession.getSession("BNSPRDal");
			List<?> paremetrePersistentList = session.createCriteria(EftSaatAraligiTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			int row = 0;
			for (Iterator<?> iterator = paremetrePersistentList.iterator(); iterator.hasNext();row++) {
				EftSaatAraligiTx eftSaatAraligiTx = (EftSaatAraligiTx) iterator.next();
				oMap.put("TX_NO", iMap.getBigDecimal("TX_NO"));
				oMap.put(tableName, row, "BAS_DAKIKA", eftSaatAraligiTx.getBasDakika());
				oMap.put(tableName, row, "BAS_SAAT", eftSaatAraligiTx.getBasSaat());
				oMap.put(tableName, row, "MARJ_ORAN", eftSaatAraligiTx.getMarjOran());
				oMap.put(tableName, row, "MARJ_TUTAR", eftSaatAraligiTx.getMarjTutar());
				oMap.put(tableName, row, "MIN_TUTAR", eftSaatAraligiTx.getMinTutar());
				oMap.put(tableName, row, "SON_DAKIKA", eftSaatAraligiTx.getSonDakika());
				oMap.put(tableName, row, "SON_SAAT", eftSaatAraligiTx.getSonSaat());
			}
			
			tableName = "ILERI_EFT_SAAT";
			row = 0;
			List<?> paremetrePersistentList2 = session.createCriteria(EftKanalCutoffSaatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			for (Iterator<?> iterator = paremetrePersistentList2.iterator(); iterator.hasNext();row++) {
				EftKanalCutoffSaatTx eftKanalCutoffSaatTx = (EftKanalCutoffSaatTx) iterator.next();
				oMap.put("TX_NO", iMap.getBigDecimal("TX_NO"));
				oMap.put(tableName, row, "KANAL_KODU", eftKanalCutoffSaatTx.getId().getKanalKod());
				oMap.put(tableName, row, "CUTOFFSAAT", eftKanalCutoffSaatTx.getCutoffSaat());
			}
			
			
			
			List<?> paremetrePersistentList3 = session.createCriteria(EftGelgonSaatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			row = 0;
			for (Iterator<?> iterator = paremetrePersistentList3.iterator(); iterator.hasNext();row++) {
				EftGelgonSaatTx eftGelgonSaatTx = (EftGelgonSaatTx) iterator.next();
                oMap.put("G_BAS_SAAT" , eftGelgonSaatTx.getIlkSaat().substring(0,2));
                oMap.put("G_BAS_DAKIKA" , eftGelgonSaatTx.getIlkSaat().substring(3));
			    oMap.put("G_SON_SAAT" , eftGelgonSaatTx.getSonSaat().substring(0,2));
			    oMap.put("G_SON_DAKIKA" , eftGelgonSaatTx.getSonSaat().substring(3));
			        
			}
	        
			List<?> paremetrePersistentList4 = session.createCriteria(EftSaatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			row = 0;
			for (Iterator<?> iterator = paremetrePersistentList4.iterator(); iterator.hasNext();row++) {
				EftSaatTx eftSaatTx = (EftSaatTx) iterator.next();
		        oMap.put("EFT_BAS_SAAT" , eftSaatTx.getIlkSaat().substring(0,2));
		        oMap.put("EFT_BAS_DAKIKA" , eftSaatTx.getIlkSaat().substring(3));
		        oMap.put("EFT_SON_SAAT" , eftSaatTx.getSonSaat().substring(0,2));
		        oMap.put("EFT_SON_DAKIKA" , eftSaatTx.getSonSaat().substring(3));
			}
			
			 List<?> paremetrePersistentList5 = session.createCriteria(EftOtoReleaseParametreTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).list();
	            row = 0;
	            for (Iterator<?> iterator = paremetrePersistentList5.iterator(); iterator.hasNext();row++) {
	                EftOtoReleaseParametreTx eftOtoRelease = (EftOtoReleaseParametreTx) iterator.next();
	                oMap.put("O_SAAT" , eftOtoRelease.getOtorelSaat().substring(0,2));
	                oMap.put("O_DAKIKA" , eftOtoRelease.getOtorelSaat().substring(3));
	                oMap.put("O_TUTAR" , eftOtoRelease.getOtorelTutar());
	                oMap.put("B_TUTAR", eftOtoRelease.getOtoBildirimTutar());
	    
	            }
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}

	}
	
	@GraymoundService("BNSPR_TRN2373_SAVE")
	public static Map<?, ?> saveParametreTanim(GMMap iMap) {
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			
			
			
			
			List<?> listEftGirisSaatTx = session.createCriteria(EftSaatAraligiTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			for (Iterator<?> iterator = listEftGirisSaatTx.iterator(); iterator.hasNext();) {
				EftSaatAraligiTx eftSaatAraligiTx = (EftSaatAraligiTx) iterator.next();
				session.delete(eftSaatAraligiTx);
			}

			session.flush();
			
			String tableName = "EFT_SAAT_ARALIGI";
			List<?> list1 = (List<?>) iMap.get(tableName);
			int numara = 1;
			for (int i=0;i<list1.size();i++) {
				EftSaatAraligiTx eftSaatAraligiTx = new EftSaatAraligiTx();
				EftSaatAraligiTxId eftSaatAraligiTxId = new EftSaatAraligiTxId();
				eftSaatAraligiTxId.setTxNo(iMap.getBigDecimal("TRX_NO")) ; 
				eftSaatAraligiTxId.setNumara(new BigDecimal(numara++));
				eftSaatAraligiTx.setId(eftSaatAraligiTxId) ; 
				eftSaatAraligiTx.setBasDakika(iMap.getString(tableName,i, "BAS_DAKIKA"));
				eftSaatAraligiTx.setBasSaat(iMap.getString(tableName,i, "BAS_SAAT"));
				eftSaatAraligiTx.setMarjOran(iMap.getBigDecimal(tableName, i, "MARJ_ORAN"));
				eftSaatAraligiTx.setMarjTutar(iMap.getBigDecimal(tableName, i, "MARJ_TUTAR"));
				eftSaatAraligiTx.setMinTutar(iMap.getBigDecimal(tableName, i, "MIN_TUTAR"));
				eftSaatAraligiTx.setSonDakika(iMap.getString(tableName,i, "SON_DAKIKA"));
				eftSaatAraligiTx.setSonSaat(iMap.getString(tableName,i, "SON_SAAT"));

				session.saveOrUpdate(eftSaatAraligiTx);
			}
			
			List<?> listEftGonderimSaat = session.createCriteria(EftKanalCutoffSaatTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();

			for (Iterator<?> iterator = listEftGonderimSaat.iterator(); iterator.hasNext();) {
				EftKanalCutoffSaatTx eftIleriSaat = (EftKanalCutoffSaatTx) iterator.next();
				session.delete(eftIleriSaat);
			}
			session.flush(); 
			numara = 1;
			tableName = "ILERI_EFT_SAAT";
			List<?> list2 = (List<?>) iMap.get(tableName);
			for (int i=0;i<list2.size();i++) {
				EftKanalCutoffSaatTx eftKanalCutoffSaatTx = new EftKanalCutoffSaatTx();
				EftKanalCutoffSaatTxId eftKanalCutoffSaatTxId = new EftKanalCutoffSaatTxId();
				
				eftKanalCutoffSaatTxId.setTxNo(iMap.getBigDecimal("TRX_NO"));
				eftKanalCutoffSaatTxId.setKanalKod(iMap.getString(tableName,i,"KANAL_KODU")) ; 
				eftKanalCutoffSaatTx.setId(eftKanalCutoffSaatTxId) ;
				eftKanalCutoffSaatTx.setCutoffSaat(iMap.getString(tableName,i,"CUTOFFSAAT"));

				session.saveOrUpdate(eftKanalCutoffSaatTx);
			}
			session.flush();

			
			
			EftGelgonSaatTx eftgelgonSaat = new EftGelgonSaatTx();
			EftGelgonSaatTxId eftgelgonSaatId = new EftGelgonSaatTxId();
			
			eftgelgonSaatId.setTxNo(iMap.getBigDecimal("TRX_NO")) ;
			eftgelgonSaatId.setNumara(iMap.getBigDecimal("NUMARA")) ; 
			eftgelgonSaat.setId(eftgelgonSaatId) ; 
			eftgelgonSaat.setIlkSaat(iMap.getString("G_BAS_SAAT")) ;
			eftgelgonSaat.setSonSaat(iMap.getString("G_SON_SAAT")) ; 
			
			session.saveOrUpdate(eftgelgonSaat);
		
		    session.flush();
			
		    
			EftSaatTx eftSaatTx = new EftSaatTx();
			EftSaatTxId eftSaatTxId = new EftSaatTxId();
			
			eftSaatTxId.setTxNo(iMap.getBigDecimal("TRX_NO")) ;
			eftSaatTxId.setNumara(iMap.getBigDecimal("NUMARA")) ; 
			eftSaatTx.setId(eftSaatTxId) ; 
			eftSaatTx.setIlkSaat(iMap.getString("EFT_BAS_SAAT")) ;
			eftSaatTx.setSonSaat(iMap.getString("EFT_SON_SAAT")) ; 
			
			session.saveOrUpdate(eftSaatTx);
		
		    session.flush();		
		    
		    EftOtoReleaseParametreTx eftOtoRelease = new EftOtoReleaseParametreTx();
		    eftOtoRelease.setTxNo(iMap.getBigDecimal("TRX_NO"));
		    eftOtoRelease.setOtorelTutar(iMap.getBigDecimal("O_TUTAR"));
		    eftOtoRelease.setOtorelSaat(iMap.getString("O_SAAT"));
		    eftOtoRelease.setOtoBildirimTutar(iMap.getBigDecimal("B_TUTAR"));
		    session.saveOrUpdate(eftOtoRelease);
		    session.flush();
			
			iMap.put("TRX_NAME", "2373");
			return GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}		
	
	
	@GraymoundService("BNSPR_PAR2373_EFT_RELEASE_HABR_KAPA_KONTROL")
	public static GMMap getEftReleaseKapa(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{? = call PKG_RC_EFT.EFT_RELEASE_HABR_KAPA_KONTROL}");

			stmt.registerOutParameter(1, Types.VARCHAR);

			stmt.execute();
            
			oMap.put("EFT_KAPA_EH",stmt.getString(1));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}	
	
	@GraymoundService("BNSPR_PAR2373_EFT_RELEASE_HABR_KAPA_SAVE")
	public static GMMap getFisNo(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		try {
			GMMap oMap = new GMMap();
			conn = DALUtil.getGMConnection();

			stmt = conn.prepareCall("{call PKG_RC_EFT.EFT_RELEASE_HABR_KAPA_SAVE(?)}");

			stmt.setString(1, iMap.getString("EFT_KAPA_EH"));

			stmt.execute();

			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}		
	
	
	
}