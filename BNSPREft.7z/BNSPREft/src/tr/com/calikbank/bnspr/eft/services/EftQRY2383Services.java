package tr.com.calikbank.bnspr.eft.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class EftQRY2383Services {

    @GraymoundService("BNSPR_QRY2383_POS_BAKIYE")
    public static GMMap getPosBakiye(GMMap iMap) {
        Connection conn = null;
        CallableStatement stmt = null;
        ResultSet rSet = null;
        try {
            GMMap oMap= new GMMap();
            
            
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{ ?=call PKG_RC_EFT.RC_QRY2383_GET_POS_BAKIYE}");

            stmt.registerOutParameter(1, -10);

            stmt.execute();

            rSet = (ResultSet) stmt.getObject(1);

            String tableName = "RESULTS"; 
            int row = 0;
            while(rSet.next()){ 
                oMap.put(tableName, row, "SISTEM", rSet.getObject("SISTEM"));
                oMap.put(tableName, row, "GCRLISG", rSet.getObject("GCRLISG"));
                
                oMap.put(tableName, row, "GUNBZM", rSet.getDate("GUNBZM"));
              //Time i�in yeni bir g�r�nmez kolon a�al�m
                oMap.put(tableName, row, "GUNBZM_TIME", sdf.format(rSet.getTimestamp("GUNBZM")));
                
                oMap.put(tableName, row, "GUNSZM", rSet.getDate("GUNSZM"));
                oMap.put(tableName, row, "GUNSZM_TIME", sdf.format(rSet.getTimestamp("GUNSZM")));
                oMap.put(tableName, row, "SNRISG", rSet.getObject("SNRISG"));
                oMap.put(tableName, row, "SNRGUNBZM", rSet.getDate("SNRGUNBZM"));
                oMap.put(tableName, row, "SNRGUNBZM_TIME", sdf.format(rSet.getTimestamp("SNRGUNBZM")));
                oMap.put(tableName, row, "BKY", rSet.getObject("BKY"));
                oMap.put(tableName, row, "GUNBBKY", rSet.getObject("GUNBBKY"));
                oMap.put(tableName, row, "BORCMES", rSet.getObject("BORCMES"));
                oMap.put(tableName, row, "BORCTTR", rSet.getObject("BORCTTR"));
                oMap.put(tableName, row, "ALACMES", rSet.getObject("ALACMES"));
                oMap.put(tableName, row, "ALACTTR", rSet.getObject("ALACTTR"));
                oMap.put(tableName, row, "KASDURUM", rSet.getObject("KASDURUM"));
                oMap.put(tableName, row, "BEKMES", rSet.getObject("BEKMES"));
                oMap.put(tableName, row, "BEKTTR", rSet.getObject("BEKTTR"));
                oMap.put(tableName, row, "KUYMES", rSet.getObject("KUYMES"));
                oMap.put(tableName, row, "KUYTTR", rSet.getObject("KUYTTR"));                
                row++;
            }
            
            return oMap;

        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
            GMServerDatasource.close(rSet);
            GMServerDatasource.close(stmt);
            GMServerDatasource.close(conn);
        }
    }
    
    @GraymoundService("BNSPR_QRY2383_POS_BAKIYE_SUM")
	public static GMMap toplam(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			String func = "{ ?=call PKG_RC_EFT.RC_QRY2383_GET_POS_BAKIYE_SUM}";
			Object[] inputValues = new Object[0];

			oMap =  DALUtil.callOracleRefCursorFunction(func, "TOPLAM", inputValues);
			oMap.put("TOPLAM", 0, "TOPLAM_ROW", "TOPLAM"); 

		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
}
