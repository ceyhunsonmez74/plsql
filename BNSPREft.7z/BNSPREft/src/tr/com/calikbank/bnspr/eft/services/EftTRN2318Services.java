package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;

import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.util.GMMap;

public class EftTRN2318Services {

	@GraymoundService("BNSPR_TRN2318_GET_EFT_INFO")
	public static GMMap getInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			
			
			EftEftTx eftEftTx = (EftEftTx)session.createCriteria(EftEftTx.class).add(Restrictions.eq("txNo", iMap.getBigDecimal("TRX_NO"))).uniqueResult();
			
			GMMap oMap = new GMMap();
			
			   oMap.put("TRX_NO" , eftEftTx.getTxNo());
		        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
		        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
		        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
		        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
		        oMap.put("DURUM" , eftEftTx.getDurum());
				oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
		        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
		        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
		        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
		        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
		        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
		        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
		        oMap.put("KIYMET_KODU" , eftEftTx.getKiymetKodu());
		        oMap.put("MIKTAR", eftEftTx.getMiktar());
		        oMap.put("KULLANICI_REFERANSI" , eftEftTx.getKullaniciReferansi());
		        oMap.put("SATIS_ISLEM_NO", eftEftTx.getSatisIslemNo());
		        oMap.put("GELEN_GIDEN", eftEftTx.getGelenGiden());
		        oMap.put("TUTAR", eftEftTx.getTutar());
		        oMap.put("KAS_MESAJ_KODU", eftEftTx.getKasMesajKodu());
		        oMap.put("BILDIRIM_TURU", eftEftTx.getBildirimTuru());
		        oMap.put("ACIKLAMA", eftEftTx.getAciklama());
		        
		        
	            oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	
	
}
