package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;

import org.apache.commons.lang.StringUtils;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftQRY2369Services {
	@GraymoundService("BNSPR_TRN2369_GET_IADE_EFT")
	public static GMMap getGidenEftMesajlari(GMMap iMap) {
	                                                                  
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		int i = 1;	
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_eft.RC_QRY2369_GET_IADE_EFT(?,?,?,?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("K_KANAL"));
			
			if(("0".equals(iMap.getString("IADE_NEDENI"))) || (StringUtils.isBlank(iMap.getString("IADE_NEDENI")))){
			      stmt.setString(i++, null);
			}
			else
			{
				iMap.put("KEY", iMap.getString("IADE_NEDENI")) ;
				 stmt.setString(i++, getEFTIadeAkibetAciklama(iMap));
				 
			}
			
			
        	if (!(iMap.getDate("K_EFT_TARIH_BAS") == null)) {
					stmt.setDate(i++,  new java.sql.Date(iMap.getDate("K_EFT_TARIH_BAS").getTime()));
			} else {
					stmt.setDate(i++, null);
			}
			if (!(iMap.getDate("K_EFT_TARIH_BIT") == null)) {
				stmt.setDate(i++, new java.sql.Date(iMap.getDate("K_EFT_TARIH_BIT").getTime()));
			} else {
				stmt.setDate(i++, null);
			}
			
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			BigDecimal toplamTutar = new BigDecimal(0);
			
			String tableName = "EFT_MESAJLARI";
			int row = 0;
			while (rSet.next()) {
				oMap.put(tableName, row,"TRX_NO", rSet.getString("TX_NO"));
				oMap.put(tableName, row,"TUTAR", rSet.getBigDecimal("TUTAR"));
				oMap.put(tableName, row,"MESAJ_KODU", rSet.getString("MESAJ_KODU"));
				oMap.put(tableName, row,"KANAL", rSet.getString("KANAL"));
				oMap.put(tableName, row,"IADE_EFT_TXNO", rSet.getString("IADE_EFT_TXNO"));
				oMap.put(tableName, row,"IADE_EFT_SORGU_NO", rSet.getString("IADE_EFT_SORGU_NO"));
				oMap.put(tableName, row,"IADE_EFT_AKIBET_TXNO", rSet.getString("IADE_EFT_AKIBET_TXNO"));
				oMap.put(tableName, row,"IADE_EFT_AKIBET_ACK", rSet.getString("IADE_EFT_AKIBET_ACK"));
				oMap.put(tableName, row,"GONDEREN", rSet.getString("GONDEREN"));
				oMap.put(tableName, row,"EFT_TARIH", rSet.getDate("EFT_TARIH"));
				oMap.put(tableName, row,"EFT_SORGU_NO", rSet.getString("EFT_SORGU_NO"));
				oMap.put(tableName, row,"ALAN_BANKA_ADI", rSet.getString("ALAN_BANKA_ADI"));
				oMap.put(tableName, row,"AKIBET_EKRAN_KODU", rSet.getString("AKIBET_EKRAN_KODU"));
				
				oMap.put(tableName, row,"GONDEREN_VERGI_KIMLIK_NUMARASI", rSet.getString("GONDEREN_VERGI_KIMLIK_NUMARASI"));
				oMap.put(tableName, row,"GONDEREN_TELEFON", rSet.getString("GONDEREN_TELEFON"));
							oMap.put(tableName, row,"ALICI_ADI", rSet.getString("ALICI_ADI"));
				oMap.put(tableName, row,"ALICI_TELEFON_NO", rSet.getString("ALICI_TELEFON_NO"));
				oMap.put(tableName, row,"ALICI_TC_KIMLIKNO", rSet.getString("ALICI_TC_KIMLIKNO"));
				oMap.put(tableName, row,"EFT_HVL_TAR", rSet.getDate("EFT_HVL_TAR"));
				oMap.put(tableName, row,"AKB_ISLTAR", rSet.getDate("AKB_ISLEM_TAR"));
				oMap.put(tableName, row,"ISLEMIN_YAPILDIGI_YER", rSet.getString("ISLEMIN_YAPILDIGI_YER"));
				oMap.put(tableName, row,"IADE_NEDENI", rSet.getString("IADE_NEDENI"));
				
				
				toplamTutar = toplamTutar.add(rSet.getBigDecimal("tutar"));
				
				
		
				row++;
			}

			oMap.put("KAYIT_SAYISI",row);
			oMap.put("TOPLAM_TUTAR", toplamTutar);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	public static String getEFTIadeAkibetAciklama(GMMap iMap) {
	
	GMMap oMap = new GMMap();
	int i = 0;
	
	try {
		String key = iMap.getString("KEY");
		iMap.put("KOD", iMap.getString("KOD"));
		iMap.put("KEY1", key);
		
		oMap.put(key, GMServiceExecuter.execute("BNSPR_COMMON_GET_COMBO_PARAMETERS", iMap).get("RESULTS"));

		while (i < oMap.getSize(key)) {

			if (oMap.getString(key, i, "VALUE").equals(key)) {
				oMap.put(key, oMap.getString(key, i, "NAME"));
			}
			i++;
		}

		return oMap.getString(key);
	}
	catch (Exception e) {
		throw ExceptionHandler.convertException(e);
	}

}
@GraymoundService("BNSPR_TRN2369_GET_KANAL_KODLARI")
public static GMMap getKanalKodlari(GMMap iMap) {
	iMap.put("ADD_EMPTY_KEY", "E");
	iMap.put("LIST_NAME", "KANAL_KODLARI");
	iMap.put("LIST_QUERY", "select kod, aciklama from v_ml_gnl_kanal_grup_kod_pr order by 1");
	DALUtil.fillComboBox(iMap);
	return iMap;
}


}


