package tr.com.calikbank.bnspr.eft.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import tr.com.aktifbank.bnspr.dao.EftEngellemeTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class EftTRN2399Services {
	@GraymoundService("BNSPR_TRN2399_CONVERT_TIME")
	public static GMMap convertTime(GMMap iMap){
		GMMap oMap =new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		try{
			oMap.put("CONVERTEDDATE", sdf.format(new Date()));}
		catch (Exception e) {
			oMap.put("CONVERTEDDATE", "");
		}
		return oMap;
	}
	@GraymoundService("BNSPR_TRN2399_SAVE")
	public static GMMap save(GMMap iMap){
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		String durum=null;
		int a=0;
		
		try {
			int s=iMap.getSize("RESTRICTION_LIST");
			for (int i = 0; i<s; i++) {
				durum=iMap.get("RESTRICTION_LIST",i,"IGS")==null?"":iMap.getString("RESTRICTION_LIST",i,"IGS");
				if(durum.equals("G")||durum.equals("I")){
					EftEngellemeTx eftEngellemeTx = new EftEngellemeTx();
					eftEngellemeTx.setCustomerNo(iMap.getBigDecimal("RESTRICTION_LIST",i,"MUSTERI_NO"));
					if(durum.equals("I")){
					eftEngellemeTx.setDeletedatetime(new Date());
					eftEngellemeTx.setDeletedescription(iMap.getString("RESTRICTION_LIST",i,"DESCRIPTION"));
					eftEngellemeTx.setStatus("I");
					}
					else{
					eftEngellemeTx.setInsertdatetime(sdf.parse(iMap.getString("RESTRICTION_LIST",i,"INSERTDATETIME")));
					eftEngellemeTx.setInsertdescription(iMap.getString("RESTRICTION_LIST",i,"DESCRIPTION"));
					eftEngellemeTx.setStatus("G");
					}
					eftEngellemeTx.setNameSurname(iMap.getString("RESTRICTION_LIST",i,"ADSOYAD"));
					eftEngellemeTx.setTxNo(iMap.getBigDecimal("TX_NO"));
					session.saveOrUpdate(eftEngellemeTx);
					a=a+1;
				}
			}
			session.flush();
			if (a>0){
				iMap.put("TRX_NO", iMap.getBigDecimal("TX_NO"));
				iMap.put("TRX_NAME", "2399");
				GMServiceExecuter.execute("BNSPR_TRX_SEND_TRANSACTION", iMap);
				oMap.put("MESSAGE",a+" adet m��teri i�in i�lem yap�ld�.");
			}
			else
				oMap.put("MESSAGE","De�i�en ya da eklenen kay�t bulunamad�.");
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
		
	}
	@GraymoundService("BNSPR_TRN2399_GET_RESTRICTON_LIST")
	public static GMMap getRestrictions(GMMap iMap){
		GMMap oMap= new GMMap();
		GMMap oMap2= new GMMap();
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN2399.GETRESTRICTIONLIST()}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.execute();

			rSet = (ResultSet) stmt.getObject(1);
			oMap2.putAll(DALUtil.rSetResultsPutStr(rSet, "TABLO"));
			//String func="{? = call PKG_TRN2399.GETRESTRICTIONLIST() }";
			//oMap2=DALUtil.callOracleRefCursorFunction(func, "TABLO");
			int s = oMap2.getSize("TABLO");
			for (int j = 0; j < s; j++) {
				oMap.put("RESTRICTION_LIST", j,"MUSTERI_NO", oMap2.getBigDecimal("TABLO",j,"CUSTOMER_NO"));
				oMap.put("RESTRICTION_LIST", j,"ADSOYAD", oMap2.getString("TABLO",j,"NAME_SURNAME"));
				oMap.put("RESTRICTION_LIST", j,"INSERTDATETIME", formatDate(oMap2.getString("TABLO",j,"INSERTDATETIME")));
				oMap.put("RESTRICTION_LIST", j,"DESCRIPTION", oMap2.getString("TABLO",j,"INSERTDESCRIPTION"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}
	public static String formatDate(String Date){
		String Tarih = null;
		Tarih=Date.substring(8, 10)+"/"+Date.substring(5,7)+"/"+Date.substring(0, 4)+" "+Date.substring(11,19);
		return Tarih;
	}
	@GraymoundService("BNSPR_QRY2399_GET_RESTRICTON_LIST")
	public static GMMap getRestrictionList(GMMap iMap){
		GMMap oMap= new GMMap();
		GMMap oMap2= new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
		try {
			BigDecimal musteriNo = iMap.get("MUSTERI_NO")==null?BigDecimal.ZERO:iMap.getBigDecimal("MUSTERI_NO");
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_TRN2399.GETRESTRICTIONS(?)}");
			int i = 1;
			stmt.registerOutParameter(i++, -10); // ref cursor
			stmt.setBigDecimal(i++, musteriNo);
			stmt.execute();
			rSet = (ResultSet) stmt.getObject(1);
			oMap2.putAll(DALUtil.rSetResultsPutStr(rSet, "TABLO"));
			
			//Object[] objArray = new Object[2];
			//objArray[0]=BnsprType.NUMBER;
			//objArray[1]=musteriNo==null?BigDecimal.ZERO:musteriNo;
			
			//String func="{? = call PKG_TRN2399.GETRESTRICTIONS(?) }";
			//oMap2=DALUtil.callOracleRefCursorFunction(func, "TABLO",objArray);
			int s = oMap2.getSize("TABLO");
			for (int j = 0; j < s; j++) {
				oMap.put("RESTRICTION_LIST", j,"MUSTERI_NO", oMap2.getBigDecimal("TABLO",j,"CUSTOMER_NO"));
				oMap.put("RESTRICTION_LIST", j,"ADSOYAD", oMap2.getString("TABLO",j,"NAME_SURNAME"));
				oMap.put("RESTRICTION_LIST", j,"INSERTDATETIME", formatDate(oMap2.getString("TABLO",j,"INSERTDATETIME")));
				oMap.put("RESTRICTION_LIST", j,"INSERTDESCRIPTION", oMap2.getString("TABLO",j,"INSERTDESCRIPTION"));
				oMap.put("RESTRICTION_LIST", j,"DELETEDATETIME", StringUtils.isEmpty(oMap2.getString("TABLO",j,"DELETEDATETIME"))?"": formatDate(oMap2.getString("TABLO",j,"DELETEDATETIME")));
				oMap.put("RESTRICTION_LIST", j,"DELETEDESCRIPTION", oMap2.getString("TABLO",j,"DELETEDESCRIPTION"));
			}
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
		return oMap;
	}


}


