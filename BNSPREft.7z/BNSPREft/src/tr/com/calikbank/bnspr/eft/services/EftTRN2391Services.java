package tr.com.calikbank.bnspr.eft.services;


import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.EftNysDetayTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.dao.EftEftTx;
import tr.com.calikbank.bnspr.util.BnsprType;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class EftTRN2391Services {
	@GraymoundService("BNSPR_TRN2391_GET_EFT_INFO")
	public static GMMap getInfo(GMMap iMap) {
		String tblName="EFT_NYS_DETAY";
		String tblNameM="EFT_NYS_DETAY_MONY";
		
		try{
			Session session = DAOSession.getSession("BNSPRDal");
			
			EftEftTx eftEftTx = (EftEftTx)session.load(EftEftTx.class, iMap.getBigDecimal("TRX_NO"));
			
			GMMap oMap = new GMMap();
			
		    oMap.put("TRX_NO" , eftEftTx.getTxNo());
	        oMap.put("MESAJ_KODU" , eftEftTx.getMesajKodu());
	        oMap.put("SORGU_NO" , eftEftTx.getSorguNo());
	        oMap.put("EFT_TARIH" , eftEftTx.getEftTarih());
	        oMap.put("ONCELIK" , eftEftTx.getOncelik().toString());
	        oMap.put("DURUM" , eftEftTx.getDurum());
			oMap.put("BOLUM_KODU" , eftEftTx.getBolumKodu());
	        oMap.put("GONDEREN_BANKA" , eftEftTx.getGonderenBanka());
	        oMap.put("GONDEREN_SUBE" , eftEftTx.getGonderenSube());
	        oMap.put("GONDEREN_SEHIR" , eftEftTx.getGonderenSehir());
	        oMap.put("ALAN_BANKA_KODU" , eftEftTx.getAlanBankaKodu());
	        oMap.put("ALAN_SEHIR_KODU" , eftEftTx.getAlanSehirKodu());
	        oMap.put("ALAN_SUBE_KODU" , eftEftTx.getAlanSubeKodu());
	        oMap.put("ACIKLAMA" , eftEftTx.getAciklama());
	        oMap.put("GELEN_GIDEN" , eftEftTx.getGelenGiden());
	        oMap.put("KIM_TUR" , eftEftTx.getKimTur());
	        oMap.put("VERGI_NO" , eftEftTx.getVergiNo());
	        oMap.put("KIM_KURUM" , eftEftTx.getKimKurum());
	        oMap.put("TUTAR", eftEftTx.getTutar());
	        
	        
	        oMap.put("BANKA", eftEftTx.getBankaKodu());
	        oMap.put("ISLEM_TARIHI", eftEftTx.getAlisTarihi());
	        oMap.put("YETKILI_KISI_TCKN", eftEftTx.getBildirimNo());
	        oMap.put("NEW_ISLEM_REFERANS_NO", eftEftTx.getReferansNo());
	        oMap.put("KEY1", eftEftTx.getSubeKodu());
	        oMap.put("TEXT", LovHelper.diLov((String) oMap.get("KEY1"), "2391/LOV_SUBE_DEPO", "TEXT"));
	        oMap.put("EMISYON_GRUBU", eftEftTx.getIhaleTur());
	        
	        oMap.put("MESAJ_GRUBU", eftEftTx.getMesajGrubu());
	        if("IPT".equals(eftEftTx.getMesajGrubu()))
	          oMap.put("ILGILI_ISLEM_REFERANS_NO", eftEftTx.getReferansNo());
	        
	        
	    	List<?> eftNysDetayTx = session.createCriteria(EftNysDetayTx.class).add(Restrictions.eq("id.txNo", iMap.getBigDecimal("TRX_NO"))).list();
			int i=0;
			if("MNY".equals(eftEftTx.getMesajGrubu()))
			{
		    	for (Object name : eftNysDetayTx) {
					EftNysDetayTx eftEftDetayTx = (EftNysDetayTx) name;
					 oMap.put(tblNameM,i,"KUPUR_BILGISI", eftEftDetayTx.getKupurBilgisi());
					 oMap.put(tblNameM,i,"UYGUN_ADET", eftEftDetayTx.getUygunAdet());
					 oMap.put(tblNameM,i,"FERSUDE_ADET", eftEftDetayTx.getUygunAdet());
					 oMap.put(tblNameM,i,"IADE_ADET", eftEftDetayTx.getIadeAdet());
					 oMap.put(tblNameM,i,"TAHSILAT_ADET", eftEftDetayTx.getTahsilatAdet());
					 oMap.put(tblNameM,i,"TEDIYE_ADET", eftEftDetayTx.getTediyeAdet());
					 oMap.put(tblNameM,i,"TCMB_FERSUDE_ADET", eftEftDetayTx.getTcmbFersudeAdet());
					 oMap.put(tblNameM,i,"VARDIYA_ADET", eftEftDetayTx.getSonrakiVardiyaAdet());
					 i++;
				}
			}
			else	
			    	for (Object name : eftNysDetayTx) {
						EftNysDetayTx eftEftDetayTx = (EftNysDetayTx) name;
						 oMap.put(tblName,i,"BARKOD_NO", eftEftDetayTx.getBarkodNumarasi());
						 oMap.put(tblName,i,"EMISYON_GRUP", eftEftDetayTx.getEmisyonGrubu());
						 oMap.put(tblName,i,"KAP_TURU", eftEftDetayTx.getKapTuru());
						 oMap.put(tblName,i,"KUPUR_BILGISI", eftEftDetayTx.getKupurBilgisi());
						 oMap.put(tblName,i,"PAKET_SAYISI", eftEftDetayTx.getPaketSayisi());
						 i++;
					}
			
	        oMap.putAll(EftServices.getEftDiValues(eftEftTx.getGonderenBanka(), eftEftTx.getGonderenSube(), eftEftTx.getGonderenSehir(), eftEftTx.getAlanBankaKodu(),eftEftTx.getAlanSubeKodu(), eftEftTx.getAlanSehirKodu()));
			
			return oMap;
		}catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	
	@GraymoundService("BNSPR_TRN2391_GET_EFT_INFO_BY_REF")
	public static GMMap getInfoByRef(GMMap iMap) {
		GMMap oMap = new GMMap();
		Session session = DAOSession.getSession("BNSPRDal");
		String tblName="EFT_NYS_DETAY";
		try {
			String func = "{? = call PKG_TRN2391.getDetayByRef(?)}";
			Object[] inputValues = new Object[4];
			int i = 0;
			inputValues[i++] = BnsprType.STRING;
			inputValues[i++] = iMap.getString("REFERANS_NO");
			String tableName = "RESULTS";
			oMap = DALUtil.callOracleRefCursorFunction(func, tableName, inputValues);

			i = 0;
			while (i < oMap.getSize(tableName)) {
				    oMap.put("TRX_NO",oMap.getBigDecimal(tableName,i, "TX_NO"));
				    oMap.put("BANKA", oMap.getString(tableName,i,"BANKA_KODU"));
			        oMap.put("ISLEM_TARIHI", oMap.getString(tableName,i,"ALIS_TARIHI"));
			        oMap.put("YETKILI_KISI_TCKN", oMap.getString(tableName,i,"BILDIRIM_NO"));
			        oMap.put("NEW_ISLEM_REFERANS_NO", oMap.getString(tableName,i,"REFERANS_NO"));
			        oMap.put("KEY1", oMap.getString(tableName,i,"SUBE_KODU"));
			        oMap.put("TUTAR",oMap.getBigDecimal(tableName,i, "TUTAR"));
			        oMap.put("ACIKLAMA" , oMap.getString(tableName,i,"ACIKLAMA"));
			        oMap.put("MESAJ_GRUBU", "IPT");
				    oMap.put("ILGILI_ISLEM_REFERANS_NO", oMap.getString("NEW_ISLEM_REFERANS_NO"));
			        oMap.put("TEXT", LovHelper.diLov((String) oMap.get("KEY1"), "2391/LOV_SUBE_DEPO", "TEXT"));
			        oMap.put("EMISYON_GRUBU", oMap.getString(tableName,i,"IHALE_TUR"));
				i++;
			}

			List<?> eftNysDetayTx = session.createCriteria(EftNysDetayTx.class).add(Restrictions.eq("id.txNo", oMap.getBigDecimal("TRX_NO"))).list();
			  i=0;
	    	for (Object name : eftNysDetayTx) {
				EftNysDetayTx eftEftDetayTx = (EftNysDetayTx) name;
				 oMap.put(tblName,i,"BARKOD_NO", eftEftDetayTx.getBarkodNumarasi());
				 oMap.put(tblName,i,"EMISYON_GRUP", eftEftDetayTx.getEmisyonGrubu());
				 oMap.put(tblName,i,"KAP_TURU", eftEftDetayTx.getKapTuru());
				 oMap.put(tblName,i,"KUPUR_BILGISI", eftEftDetayTx.getKupurBilgisi());
				 oMap.put(tblName,i,"PAKET_SAYISI", eftEftDetayTx.getPaketSayisi());
				 i++;
			}
	    	
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}	
	@GraymoundService("BNSPR_TRN2391_CHECK_TCKN")
	public static GMMap tcknCheckDigit(GMMap iMap) {
		GMMap oMap = new GMMap();

		try {

			if ((iMap.getString("YETKILI_KISI_TCKN") != null) && (!StringUtils.isEmpty(iMap.getString("YETKILI_KISI_TCKN")))) {
				oMap.put("SONUC", DALUtil.callOneParameterFunction("{? = call pkg_musteri.tckn_kontrol(?)}", Types.VARCHAR, iMap.getString("YETKILI_KISI_TCKN")));
				if (oMap.getInt("SONUC") == 0)
					throw new GMRuntimeException(10561, "Ge�erli bir TCKN giriniz");
			}
		}
		catch (Exception e) {
			throw new GMRuntimeException(10561, "Ge�erli bir TCKN  giriniz");
		}

		return oMap;
	}

	

	@GraymoundService("BNSPR_TRN2391_CREATE_EFT_REFERANS_NO")
	public static GMMap txNoVarMi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

			oMap.put("ISLEM_REFERANS_NO", String.valueOf(DALUtil.callOneParameterFunction("{? = call PKG_TRN2391.create_referance_no(?)}", Types.VARCHAR, iMap.getString("EFT_TARIH"))));
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
		return oMap;
	}
	

	@GraymoundService("BNSPR_TRN2391_KAP_TUTAR_HESAPLA")
	public static GMMap calcKapTutar(GMMap iMap) {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		String tblName="EFT_NYS_DETAY";
		 BigDecimal toplamTutar;
		 BigDecimal kupurTutarItem ;
		 int i = 0;
		try {
			conn = DALUtil.getGMConnection();
			toplamTutar = new BigDecimal(0);
			kupurTutarItem = new BigDecimal(0);
			while (i < iMap.getSize(tblName)) {
				int paketSayisi= iMap.getInt(tblName,i,"PAKET_SAYISI");
				stmt = conn.prepareStatement("SELECT KEY2 FROM V_ML_GNL_PARAM_TEXT WHERE KOD = ? AND KEY1 = ? ORDER BY SIRA_NO,TEXT");
				stmt.setString(1, "EFT_NYS_KUPUR_BILGISI");
				stmt.setString(2, iMap.getString(tblName,i,"KUPUR_BILGISI"));
				rSet = stmt.executeQuery();
				       while (rSet.next()) {
					            kupurTutarItem = rSet.getBigDecimal(1);
				              }
				            kupurTutarItem = kupurTutarItem.multiply(new BigDecimal(paketSayisi));
				            kupurTutarItem = kupurTutarItem.multiply(new BigDecimal(1000));
				            toplamTutar = toplamTutar.add(kupurTutarItem);
				         i++;
			}
			if(iMap.getSize(tblName) == 0)
				oMap.put("TUTAR", 0);
			else
				oMap.put("TUTAR", toplamTutar);
			
			return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}

	}	
	
	
}
