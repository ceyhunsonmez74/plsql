package tr.com.calikbank.bnspr.fast.services;

import java.text.ParseException;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;

import org.apache.log4j.Logger;

import tr.com.aktifbank.integration.KasboxClient;
import tr.com.aktifbank.integration.kasbox.fast.EFTMesRefBlg;
import tr.com.aktifbank.integration.kasbox.fast.GidenAnlikOdemeRequest;
import tr.com.aktifbank.integration.kasbox.fast.GidenAnlikOdemeResponse;
import tr.com.aktifbank.integration.kasbox.fast.GidenBakiyeAktarimIstegiRequest;
import tr.com.aktifbank.integration.kasbox.fast.GidenBakiyeAktarimIstegiResponse;
import tr.com.aktifbank.integration.kasbox.fast.GidenGenelAmacliBilgiRequest;
import tr.com.aktifbank.integration.kasbox.fast.GidenGenelAmacliBilgiResponse;
import tr.com.aktifbank.integration.kasbox.fast.GidenIadeIstegiRequest;
import tr.com.aktifbank.integration.kasbox.fast.GidenIadeIstegiResponse;
import tr.com.aktifbank.integration.kasbox.fast.GidenKatilimcidanTCMByeOdemeRequest;
import tr.com.aktifbank.integration.kasbox.fast.GidenKatilimcidanTCMByeOdemeResponse;
import tr.com.aktifbank.integration.kasbox.fast.GidenKatilimcilarArasiOdemeRequest;
import tr.com.aktifbank.integration.kasbox.fast.GidenKatilimcilarArasiOdemeResponse;
import tr.com.aktifbank.integration.kasbox.fast.GidenOdemeIadesiRequest;
import tr.com.aktifbank.integration.kasbox.fast.GidenOdemeIadesiResponse;
import tr.com.aktifbank.integration.kasbox.fast.Krkd;
import tr.com.aktifbank.integration.kasbox.fast.KtmSrvBlg;
import tr.com.aktifbank.integration.kasbox.fast.MesRefBlg;
import tr.com.aktifbank.integration.kasbox.fast.MesRefBlgOptional;
import tr.com.aktifbank.integration.kasbox.fast.OdmAyr;
import tr.com.aktifbank.integration.kasbox.rapor.GidenBakiyeSorguResponse;
import tr.com.aktifbank.integration.kasbox.rapor.GidenKatilimciSorguResponse;
import tr.com.aktifbank.integration.kasbox.rapor.GidenMesajSorguRequest;
import tr.com.aktifbank.integration.kasbox.rapor.GidenMesajSorguResponse;
import tr.com.aktifbank.integration.kasbox.rapor.GidenRaporRequest;
import tr.com.aktifbank.integration.kasbox.rapor.GidenRaporResponse;
import tr.com.aktifbank.integration.kasbox.rapor.Katilimci;
import tr.com.aktifbank.integration.kasbox.rapor.KatilimciRaporCevap;

import com.graymound.annotation.GraymoundService;
import com.graymound.util.GMMap;
import com.graymound.util.GMRuntimeException;

public class FastOutgoingServices extends FastCoreServices {

	private static final Logger logger = Logger.getLogger(FastOutgoingServices.class);
	
	/**
	 * Bu servis, u� kullan�c�lar aras�ndaki anl�k �demeler i�in kullan�lacakt�r.
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_FAST_OUTGOING_INSTANT_PAYMENT")
	public static GMMap anlikOdeme(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GidenAnlikOdemeRequest request=new GidenAnlikOdemeRequest();
			
			request.setSN(iMap.getString(Keys.SN.name()));
			request.setAlKK(iMap.getString(Keys.ALN_KAT_KOD.name()));
			request.setTtr(FastCoreServicesUtility.formatBigDecimal(iMap.getBigDecimal(Keys.TTR.name())));
			request.setOdmAmc(iMap.getString(Keys.ODM_AMC.name()));
			request.setOdmKynk(iMap.getString(Keys.ODM_KYNK.name()));
			request.setGonAd(iMap.getString(Keys.GON_AD.name()));
			request.setGonHesN(iMap.getString(Keys.GON_HES_NO.name()));
			request.setGonKimN(iMap.getString(Keys.GON_KIM_NO.name()));
			request.setAlAd(iMap.getString(Keys.ALC_AD.name()));
			request.setAlHesN(iMap.getString(Keys.ALC_HES_NO.name()));
			request.setAlKimN(iMap.getString(Keys.ALC_KIM_NO.name()));
			request.setRefBlg(iMap.getString(Keys.REF_BLG.name()));
			request.setAcklm(iMap.getString(Keys.ACKLM.name()));
			
			if(iMap.containsKey(Keys.ODM_AYRNT.name())){
				request.setOdmAyr(createOdemeAyr(Keys.ODM_AYRNT.name(),iMap));
			}
			if(iMap.containsKey(Keys.KTM_SRV_BLG.name())){
				request.setKtmSrvBlg(createKtmSrvBlg(Keys.KTM_SRV_BLG.name(),iMap));
			}
			
			GidenAnlikOdemeResponse response=KasboxClient.getFastClient().gidenAnlikOdeme(request);
			
			oMap.put(Keys.BSR_DRM.name(), 	response.isBsrDrm());
			oMap.put(Keys.SRG_NO.name(), 	response.getSN());
			oMap.put(Keys.GON_ZMN.name(), 	FastCoreServicesUtility.toStringFromXMLGreCal(response.getMesGonZmn()));
			
		}
		catch (Exception exp) {
			logger.error("Fast Outgoing AnlikOdeme Exp:",exp);
			throw new GMRuntimeException(0, exp);
		}
		return oMap;
	}
	
	/**
	 * �deme iadesi servisi, gelen �deme mesaj�nda herhangi bir hata oldu�unda 
	 * veya H31 �ade �ste�i ile talep edildi�inde �demeyi iade etmek amac�yla kullan�l�r.
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_FAST_OUTGOING_PAYMENT_REFUND")
	public static GMMap odemeIadesi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GidenOdemeIadesiRequest request=new GidenOdemeIadesiRequest();
			
			request.setSN(iMap.getString(Keys.SN.name()));
			request.setAlKK(iMap.getString(Keys.ALN_KAT_KOD.name()));
			request.setTtr(FastCoreServicesUtility.formatBigDecimal(iMap.getBigDecimal(Keys.TTR.name())));
			request.setGonAd(iMap.getString(Keys.GON_AD.name()));
			request.setGonHesN(iMap.getString(Keys.GON_HES_NO.name()));
			request.setGonKimN(iMap.getString(Keys.GON_KIM_NO.name()));
			request.setAlAd(iMap.getString(Keys.ALC_AD.name()));
			request.setAlHesN(iMap.getString(Keys.ALC_HES_NO.name()));
			request.setIadK(iMap.getString(Keys.IADE_KOD.name()));
			request.setAcklm(iMap.getString(Keys.ACKLM.name()));
			
			if(iMap.containsKey(Keys.ODM_AYRNT.name())){
				request.setOdmAyr(createOdemeAyr(Keys.ODM_AYRNT.name(),iMap));
			}
			request.setIlgMesRefBlg(createMesRefBlg(Keys.ILG_MES_REF_BLG.name(),iMap));
			
			GidenOdemeIadesiResponse response=KasboxClient.getFastClient().gidenOdemeIadesi(request);
			
			oMap.put(Keys.BSR_DRM.name(), 	response.isBsrDrm());
			oMap.put(Keys.SRG_NO.name(), 	response.getSN());
			oMap.put(Keys.GON_ZMN.name(), 	FastCoreServicesUtility.toStringFromXMLGreCal(response.getMesGonZmn()));
		}
		catch (Exception exp) {
			logger.error("Fast Outgoing Odeme Iadesi Exp:",exp);
			throw new GMRuntimeException(0, exp);
		}
		return oMap;
	}
	
	/**
	 * Bu servis, kat�l�mc�lar aras�nda fon aktar�m� i�in kullan�l�r.
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_FAST_OUTGOING_INTER_PARTICIPANT_PAYMENT")
	public static GMMap katilimcilarArasiOdeme(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GidenKatilimcilarArasiOdemeRequest request=new GidenKatilimcilarArasiOdemeRequest();
			
			request.setSN(iMap.getString(Keys.SN.name()));
			request.setAlKK(iMap.getString(Keys.ALN_KAT_KOD.name()));
			request.setOdmAmc(iMap.getString(Keys.ODM_AMC.name()));
			request.setTtr(FastCoreServicesUtility.formatBigDecimal(iMap.getBigDecimal(Keys.TTR.name())));
			request.setAlHesN(iMap.getString(Keys.ALC_HES_NO.name()));
			request.setBlg(iMap.getString(Keys.BLG.name()));
		
			if(iMap.containsKey(Keys.EFT_MES_REF_BLG.name())){
				request.setEFTMesRefBlg(createEFTMesRefBlg(Keys.EFT_MES_REF_BLG.name(),iMap));
			}
			request.setIlgMesRefBlg(createMesRefBlgOptional(Keys.ILG_MES_REF_BLG.name(),iMap));
			
			GidenKatilimcilarArasiOdemeResponse response=KasboxClient.getFastClient().gidenKatilimcilarArasiOdeme(request);
			
			oMap.put(Keys.BSR_DRM.name(), 	response.isBsrDrm());
			oMap.put(Keys.SRG_NO.name(), 	response.getSN());
			oMap.put(Keys.GON_ZMN.name(), 	FastCoreServicesUtility.toStringFromXMLGreCal(response.getMesGonZmn()));
		}
		catch (Exception exp) {
			logger.error("Fast Outgoing Katilimcilar Arasi Odeme Exp:",exp);
			throw new GMRuntimeException(0, exp);
		}
		return oMap;
	}
	
	/**
	 * Kat�l�mc�dan TCMB�ye �deme servisi, kat�l�mc�dan TCMB�ye fon aktar�m� i�in kullan�l�r.
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_FAST_OUTGOING_TCMB_PAYMENT")
	public static GMMap katilimcidanTCMByeOdeme(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GidenKatilimcidanTCMByeOdemeRequest request=new GidenKatilimcidanTCMByeOdemeRequest();
			
			request.setSN(iMap.getString(Keys.SN.name()));
			request.setOdmAmc(iMap.getString(Keys.ODM_AMC.name()));
			request.setTtr(FastCoreServicesUtility.formatBigDecimal(iMap.getBigDecimal(Keys.TTR.name())));
			request.setAlHesN(iMap.getString(Keys.ALC_HES_NO.name()));
			request.setBlg(iMap.getString(Keys.BLG.name()));
			
			GidenKatilimcidanTCMByeOdemeResponse response=KasboxClient.getFastClient().gidenKatilimcidanTCMByeOdeme(request);
			
			oMap.put(Keys.BSR_DRM.name(), 	response.isBsrDrm());
			oMap.put(Keys.SRG_NO.name(), 	response.getSN());
			oMap.put(Keys.GON_ZMN.name(), 	FastCoreServicesUtility.toStringFromXMLGreCal(response.getMesGonZmn()));
		}
		catch (Exception exp) {
			logger.error("Fast Outgoing TCMB Odeme Exp:",exp);
			throw new GMRuntimeException(0, exp);
		}
		return oMap;
	}

	/**
	 * Bu servis, kat�l�mc�lar�n iade isteklerini bildirmesi i�in kullan�l�r.
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_FAST_OUTGOING_REFUND")
	public static GMMap iadeIstegi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GidenIadeIstegiRequest request=new GidenIadeIstegiRequest();
			
			request.setSN(iMap.getString(Keys.SN.name()));
			request.setAlKK(iMap.getString(Keys.ALN_KAT_KOD.name()));
			request.setIadTlbSbp(iMap.getString(Keys.IADE_TLB_SBP.name()));
			request.setAcklm(iMap.getString(Keys.ACKLM.name()));
			
			if(iMap.containsKey(Keys.ILG_MES_REF_BLG.name())){
				request.setIlgMesRefBlg(createMesRefBlgOptional(Keys.ILG_MES_REF_BLG.name(),iMap));
			}
			
			GidenIadeIstegiResponse response=KasboxClient.getFastClient().gidenIadeIstegi(request);
			
			oMap.put(Keys.BSR_DRM.name(), 	response.isBsrDrm());
			oMap.put(Keys.SRG_NO.name(), 	response.getSN());
			oMap.put(Keys.GON_ZMN.name(), 	FastCoreServicesUtility.toStringFromXMLGreCal(response.getMesGonZmn()));
		}
		catch (Exception exp) {
			logger.error("Fast Outgoing Iade Istegi Exp:",exp);
			throw new GMRuntimeException(0, exp);
		}
		return oMap;
	}
	
	/**
	 * Bu servis, kat�l�mc�lar�n kat�l�mc�lar aras�nda genel ama�l� haberle�me ama�l� kullan�l�r.
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_FAST_OUTGOING_GENERAL_INFO")
	public static GMMap genelAmacliBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GidenGenelAmacliBilgiRequest request=new GidenGenelAmacliBilgiRequest();
			
			request.setSN(iMap.getString(Keys.SN.name()));
			request.setAlKK(iMap.getString(Keys.ALN_KAT_KOD.name()));
			request.setBlg(iMap.getString(Keys.BLG.name()));
			
			GidenGenelAmacliBilgiResponse response=KasboxClient.getFastClient().gidenGenelAmacliBilgi(request);
			
			oMap.put(Keys.BSR_DRM.name(), 	response.isBsrDrm());
			oMap.put(Keys.SRG_NO.name(), 	response.getSN());
			oMap.put(Keys.GON_ZMN.name(), 	FastCoreServicesUtility.toStringFromXMLGreCal(response.getMesGonZmn()));
		}
		catch (Exception exp) {
			logger.error("Fast Outgoing Genel Amacli Bilgi Exp:",exp);
			throw new GMRuntimeException(0, exp);
		}
		return oMap;
	}
	
	/**
	 * Bu servis, kat�l�mc�lar�n TCMB hesaplar�ndan FAST�a fon aktar�m talepleri i�in kullan�l�r.
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_FAST_OUTGOING_BALANCE_TRANSFER")
	public static GMMap bakiyeAktarimIstegi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GidenBakiyeAktarimIstegiRequest request=new GidenBakiyeAktarimIstegiRequest();
			
			request.setSN(iMap.getString(Keys.SN.name()));
			request.setAlKK(iMap.getString(Keys.ALN_KAT_KOD.name()));
			request.setTtr(FastCoreServicesUtility.formatBigDecimal(iMap.getBigDecimal(Keys.TTR.name())));
			request.setBorcHesN(iMap.getString(Keys.BRC_HES_NO.name()));
			
			GidenBakiyeAktarimIstegiResponse response=KasboxClient.getFastClient().gidenBakiyeAktarimIstegi(request);
			
			oMap.put(Keys.BSR_DRM.name(), 	response.isBsrDrm());
			oMap.put(Keys.SRG_NO.name(), 	response.getSN());
			oMap.put(Keys.GON_ZMN.name(), 	FastCoreServicesUtility.toStringFromXMLGreCal(response.getMesGonZmn()));
		}
		catch (Exception exp) {
			logger.error("Fast Outgoing Bakiye Aktarim Exp:",exp);
			throw new GMRuntimeException(0, exp);
		}
		return oMap;
	}
	
	/**
	 * Bu servis, kat�l�mc�lar�n al�m ve g�nderim y�n�ndeki mesajlar�n�n iki ayr� dosya olarak i� g�nlerinde EFT g�n 
	 * sonunda, hafta sonlar� ve resm� tatil g�nlerinde ise saat 17.30�da tetiklenmesiyle olu�mas�n�n ard�ndan 
	 * kat�l�mc�lar taraf�ndan bu dosyalar� almak i�in kullan�l�r.
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_FAST_OUTGOING_REPORT")
	public static GMMap rapor(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GidenRaporRequest request=new GidenRaporRequest();
			
			request.setRprTr(iMap.getString(Keys.RPR_TUR.name()));
			request.setTrh(FastCoreServicesUtility.toXMLGreCalFromDate(iMap.getDate(Keys.RPR_TRH.name())));
			
			GidenRaporResponse response=KasboxClient.getRaporClient().gidenRapor(request);
			
			oMap.put(Keys.CVP_ZMN.name(), 	FastCoreServicesUtility.toStringFromXMLGreCal(response.getCevapZamani()));
			oMap.put(Keys.KAT_KOD.name(), 	response.getKatilimciKodu());
			
			KatilimciRaporCevap katilimciRaporCevap=response.getKtlmcRprCvp();
			if(katilimciRaporCevap!=null){
				oMap.put(Keys.RPR.name(), 		katilimciRaporCevap.getRpr());
				oMap.put(Keys.RPR_TUR.name(), 	katilimciRaporCevap.getRprTr());
				oMap.put(Keys.RPR_TRH.name(), 	FastCoreServicesUtility.toStringFromXMLGreCal(katilimciRaporCevap.getTrh()));	
			}
		}
		catch (Exception exp) {
			logger.error("Fast Outgoing Rapor Exp:",exp);
			throw new GMRuntimeException(0, exp);
		}
		return oMap;
	}
	
	/**
	 * Bakiye sorgulama
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_FAST_OUTGOING_QUERY_BALANCE")
	public static GMMap sorguBakiye(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GidenBakiyeSorguResponse response=KasboxClient.getRaporClient().gidenBakiyeSorgu(null);
			
			oMap.put(Keys.CVP_ZMN.name(), 	FastCoreServicesUtility.toStringFromXMLGreCal(response.getCevapZamani()));
			oMap.put(Keys.KAT_KOD.name(), 	response.getKatilimciKodu());
			oMap.put(Keys.BKY.name(), 		FastCoreServicesUtility.toBigDecimal(response.getBky()));
		}
		catch (Exception exp) {
			logger.error("Fast Outgoing Bakiye Sorgulama Exp:",exp);
			throw new GMRuntimeException(0, exp);
		}
		return oMap;
	}
	
	/**
	 * Kat�l�mc� listesi sorgulama
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_FAST_OUTGOING_QUERY_PARTICIPANT_LIST")
	public static GMMap sorguKatilimciListesi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GidenKatilimciSorguResponse response=KasboxClient.getRaporClient().gidenKatilimciSorgu(null);
			
			oMap.put(Keys.CVP_ZMN.name(), 	FastCoreServicesUtility.toStringFromXMLGreCal(response.getCevapZamani()));
			oMap.put(Keys.KAT_KOD.name(), 	response.getKatilimciKodu());
			List<Katilimci> katilimcilar=response.getKatilimci();
			int index = 0;
			for (Katilimci katilimci:katilimcilar) {
				loadKatilimciToGMMap(oMap,Keys.KAT.name(), index++, katilimci);
			}
		}
		catch (Exception exp) {
			logger.error("Fast Outgoing Katilimci Listesi Sorgulama Exp:",exp);
			throw new GMRuntimeException(0, exp);
		}
		return oMap;
	}
	
	/**
	 * Mesaj durum sorgulama
	 * 
	 * @param iMap
	 * @return
	 */
	@GraymoundService("BNSPR_FAST_OUTGOING_QUERY_MESSAGE_STATE")
	public static GMMap sorguMesajDurum(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			GidenMesajSorguRequest request=new GidenMesajSorguRequest();
			
			request.setTrh(FastCoreServicesUtility.toXMLGreCalFromDate(iMap.getDate(Keys.TRH.name())));
			request.setSN(iMap.getLong(Keys.SRG_NO.name()));
			
			GidenMesajSorguResponse response=KasboxClient.getRaporClient().gidenMesajSorgu(request);
			
			oMap.put(Keys.CVP_ZMN.name(), 	FastCoreServicesUtility.toStringFromXMLGreCal(response.getCevapZamani()));
			oMap.put(Keys.KAT_KOD.name(), 	response.getKatilimciKodu());
			
			tr.com.aktifbank.integration.kasbox.rapor.MesRefBlg mesRefBlg=response.getMesRefBlg();
			if(mesRefBlg!=null) {
				oMap.put(Keys.MES_REF_BLG.name(), 0, Keys.TRH.name(), FastCoreServicesUtility.toStringFromXMLGreCal(mesRefBlg.getTrh()));
				oMap.put(Keys.MES_REF_BLG.name(), 0, Keys.GON_KAT_KOD.name(), mesRefBlg.getGonKK());
				oMap.put(Keys.MES_REF_BLG.name(), 0, Keys.SRG_NO.name(), mesRefBlg.getSN());
			}
			oMap.put(Keys.ALN_KAT_KOD.name(), 	response.getAlKK());
			oMap.put(Keys.ISL_TUR.name(),	response.getIslTur());
			oMap.put(Keys.TTR.name(),		FastCoreServicesUtility.toBigDecimal(response.getTtr()));
			oMap.put(Keys.GIR_ZMN.name(),	FastCoreServicesUtility.toStringFromXMLGreCal(response.getGirZmn()));
			oMap.put(Keys.GON_ZMN.name(),	FastCoreServicesUtility.toStringFromXMLGreCal(response.getGonZmn()));
			oMap.put(Keys.TYT_ZMN.name(),	FastCoreServicesUtility.toStringFromXMLGreCal(response.getTytZmn()));
			oMap.put(Keys.ISL_ZMN.name(),	FastCoreServicesUtility.toStringFromXMLGreCal(response.getIslZmn()));
			oMap.put(Keys.SNC_DRM.name(),	response.getSncDrm());
			oMap.put(Keys.SNC_DRM_KOD.name(),	response.getSncDrmK());
		}
		catch (Exception exp) {
			logger.error("Fast Outgoing Mesaj Durum Sorgulama Exp:",exp);
			throw new GMRuntimeException(0, exp);
		}
		return oMap;
	}
	
	private static OdmAyr createOdemeAyr(String key, GMMap iMap) throws ParseException{
		OdmAyr odmAyr=new OdmAyr();
		odmAyr.setAdr(iMap.getString(key, 0, Keys.ADRES.name()));
		odmAyr.setPsp(iMap.getString(key, 0, Keys.PASAPORT.name()));
		odmAyr.setDYe(iMap.getString(key, 0, Keys.DGM_YER.name()));
		odmAyr.setDTrh(FastCoreServicesUtility.formatDate(iMap.getDate(key, 0, Keys.DGM_TRH.name())));
		odmAyr.setMN(iMap.getString(key, 0, Keys.MUS_NO.name()));
		return odmAyr;
	}
	private static KtmSrvBlg createKtmSrvBlg(String key, GMMap iMap){
		KtmSrvBlg ktmSrvBlg=new KtmSrvBlg();
		ktmSrvBlg.setKolasRef(iMap.getString(key, 0, Keys.KOLAS_REF.name()));
		if(iMap.containsKey(Keys.KRKD.name())){
			ktmSrvBlg.setKrkd(createKrkd(Keys.KRKD.name(), iMap));
		}
		return ktmSrvBlg;
	}
	private static Krkd createKrkd(String key, GMMap iMap){
		Krkd krkd=new Krkd();
		krkd.setKrkdAksTur(iMap.getString(key, 0, Keys.KRKD_AKS_TUR.name()));
		krkd.setKrkdRef(iMap.getString(key, 0, Keys.KRKD_REF.name()));
		return krkd;
	}
	private static MesRefBlg createMesRefBlg(String key, GMMap iMap) throws ParseException, DatatypeConfigurationException {
		MesRefBlg mesRefBlg=new MesRefBlg();
		mesRefBlg.setTrh(FastCoreServicesUtility.toXMLGreCalFromDate(iMap.getDate(key, 0, Keys.TRH.name())));
		mesRefBlg.setGonKK(iMap.getString(key, 0, Keys.GON_KAT_KOD.name()));
		mesRefBlg.setSN(iMap.getLong(key, 0, Keys.SRG_NO.name()));
		return mesRefBlg;
	}
	private static MesRefBlgOptional createMesRefBlgOptional(String key, GMMap iMap) throws ParseException{
		MesRefBlgOptional mesRefBlgOptional=new MesRefBlgOptional();
		mesRefBlgOptional.setTrh(FastCoreServicesUtility.formatDate(iMap.getDate(key, 0, Keys.TRH.name())));
		mesRefBlgOptional.setGonKK(iMap.getString(key, 0, Keys.GON_KAT_KOD.name()));
		mesRefBlgOptional.setSN(iMap.getString(key, 0, Keys.SRG_NO.name()));
		return mesRefBlgOptional;
	}
	private static EFTMesRefBlg createEFTMesRefBlg(String key, GMMap iMap) throws ParseException{
		EFTMesRefBlg eftMesRefBlg=new EFTMesRefBlg();
		eftMesRefBlg.setEFTMesTrh(FastCoreServicesUtility.formatDate(iMap.getDate(key, 0, Keys.TRH.name())));
		eftMesRefBlg.setEFTMesGonKK(iMap.getString(key, 0, Keys.GON_KAT_KOD.name()));
		eftMesRefBlg.setEFTMesSN(iMap.getString(key, 0, Keys.SRG_NO.name()));
		return eftMesRefBlg;
	}
	private static void loadKatilimciToGMMap(GMMap oMap, String name, int index, Katilimci katilimci){
		oMap.put(name, index, Keys.KAT_KOD.name(), 	katilimci.getKK());
		oMap.put(name, index, Keys.KAT_AD.name(), 	katilimci.getKAd());
		oMap.put(name, index, Keys.KAT_DRM.name(), 	katilimci.getHzmtDrm());
	}
	
}