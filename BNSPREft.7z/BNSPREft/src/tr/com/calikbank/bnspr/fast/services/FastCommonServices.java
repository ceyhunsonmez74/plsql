package tr.com.calikbank.bnspr.fast.services;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.text.SimpleDateFormat;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.BnsprCommonFunctions;
import tr.com.calikbank.bnspr.util.DALUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class FastCommonServices {

	@GraymoundService("BNSPR_FAST_ISLEM_SONUC")
	public static GMMap fastIslemSonuc(GMMap iMap) {

		Connection conn = null;
		CallableStatement stmt = null;
		int i = 1;	
		try {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call PKG_FAST.FAST_islem_sonuc(?)}");
	  		    stmt.setString(i++, iMap.getString("OID"));
				stmt.execute();

				GMMap oMap = new GMMap();
			
			return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
	
	
	     }
	
	@GraymoundService("BNSPR_EXT_FAST_BANKA_KONTROL")
	public static GMMap extFastBankaKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		
	    try{
 	        oMap = GMServiceExecuter.call("BNSPR_TRN8315_ALAN_BANKA_KONTROL", iMap);
	        return oMap;
			
	    }catch (Exception e) {
	        throw ExceptionHandler.convertException(e);
	    }	
	}

	@GraymoundService("BNSPR_EXT_FAST_LIMIT")
	public static GMMap extFastLimit(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("FAST_LIMIT", DALUtil.callNoParameterFunction("{? = call Pkg_Parametre.Deger_Al_K_N('FAST_TUTAR_LIMIT')}", Types.NUMERIC));
		return oMap;
	}
	
	@GraymoundService("BNSPR_EXT_FAST_ANLIK_ODEME")
	public static GMMap extFastInstantPayment(GMMap iMap) {
		
        Connection conn = null;
        CallableStatement stmt = null;

		
	    try{
	    	GMMap oMap = new GMMap();
	    	SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
            setBranchCode(iMap.getString("MUSTERI_HESAP_NO"));
            conn = DALUtil.getGMConnection();
            stmt = conn.prepareCall("{call Pkg_FAST.FAST_Giris_Initials(?,?,?,?,?,?,?,?,?)}");
            int i = 1;
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("MUSTERI_HESAP_NO"));
            stmt.setBigDecimal(i++, iMap.getBigDecimal("FAST_TUTAR"));
            stmt.setString(i++, iMap.getString("ALICI_IBAN"));
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.registerOutParameter(i++, Types.NUMERIC);
            stmt.registerOutParameter(i++, Types.VARCHAR);
            stmt.execute();
            i = 5;
            iMap.put("TRX_NO", stmt.getBigDecimal(i++));
            iMap.put("MESAJ_KODU", "A01");
            iMap.put("GONDEREN_BANKA", stmt.getString(i++));
            iMap.put("ALAN_BANKA", stmt.getString(i++));
            iMap.put("MASRAF", stmt.getBigDecimal(i++));
            iMap.put("GONDEREN_KIMLIK_NUMARASI", stmt.getString(i++));
            iMap.put("MASRAF_IC_DIS", "D");
            iMap.put("MASRAF_TAHSIL_SEKLI", "H");
            iMap.put("MASRAF_HESAP_NO", iMap.getBigDecimal("MUSTERI_HESAP_NO"));
            iMap.put("KIMLIK_TIPI", "1");
            iMap.put("FAST_TARIH",sdf.format(new java.util.Date())); 
            iMap.put("TUTAR_SCR", iMap.getBigDecimal("FAST_TUTAR"));
            iMap.put("DURUM", "EKLENDI");
            iMap.put("ALICI_HESAP_NO", iMap.getString("ALICI_IBAN"));
            iMap.putAll(GMServiceExecuter.execute("BNSPR_TRN8315_GET_SORGU_NO", iMap));
      
            GMMap amlMap = new GMMap(); 
			amlMap.put("ALAN_BANKA", DALUtil.callOneParameterFunction("{? = call pkg_genel_pr.banka_adi_al_eft_hatasiz(?)}", Types.VARCHAR, 
					iMap.getString("ALAN_BANKA")));
			amlMap.put("GONDEREN", iMap.getString("GONDEREN"));
			amlMap.put("GONDEREN_TCKN", iMap.getString("GONDEREN_KIMLIK_NUMARASI"));
			amlMap.put("MUSTERI_NO", iMap.getString("MUSTERI_NO"));
			GMMap dtMap = new GMMap();
			dtMap.put("CUSTOMER_NO" , iMap.getString("MUSTERI_NO"));
	        iMap.putAll(GMServiceExecuter.execute("BNSPR_CUST_GET_CUSTOMER_BIRTH_DATE" , dtMap));
	        amlMap.put("GONDEREN_DTARIH" , iMap.getString("BIRTH_DATE"));
	        amlMap.put("ACIKLAMA", iMap.getString("ACIKLAMA"));
			amlMap.put("ALICI", iMap.getString("ALICI_ADI"));
			amlMap.put("ALICI_TCKN", iMap.getString("ALICI_KIMLIK_NUMARASI"));
			amlMap.put("TUTAR", iMap.getBigDecimal("FAST_TUTAR"));
			amlMap.put("FAST_TARIH", iMap.getDate("FAST_TARIH"));
			amlMap.put("TRX_NO", iMap.getBigDecimal("TRX_NO"));
			oMap.putAll(GMServiceExecuter.execute("BNSPR_TRN8315_FAST_PAYGATE_CHECK", amlMap));	

	        oMap = GMServiceExecuter.call("BNSPR_TRN8315_SAVE", iMap);

  			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		   } 
	    }

    public static void setBranchCode(String accountNo) throws Exception {
        try {
        	BnsprCommonFunctions.setBranchCode(accountNo);
        } catch (Exception e) {
            throw ExceptionHandler.convertException(e);
        } finally {
        }
    }	

	@GraymoundService("BNSPR_FAST_GELEN_TEYIT")
	public static GMMap fastGelenTeyit(GMMap iMap) {

    	GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		int i = 1;	
		try {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call PKG_FAST.FAST_gelen_kontrol(?,?,?)}");
	  		    stmt.setString(i++, iMap.getString("OID"));
	  		    stmt.registerOutParameter(i++, Types.DECIMAL);
	  		    stmt.registerOutParameter(i++, Types.DECIMAL);
				stmt.execute();
				
				oMap.put("TEYIT_DURUM", stmt.getObject(2));
				oMap.put("TEYIT_DURUM_KODU", stmt.getObject(3));
			
			return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
	
	
	     }
	
	@GraymoundService("BNSPR_FAST_GELEN_TEYITSIZ")
	public static GMMap fastGelenTeyitsiz(GMMap iMap) {

    	GMMap oMap = new GMMap();
		Connection conn = null;
		CallableStatement stmt = null;
		int i = 1;	
		try {
				conn = DALUtil.getGMConnection();
				stmt = conn.prepareCall("{call PKG_FAST.FAST_gelen_teyitsiz(?)}");
	  		    stmt.setString(i++, iMap.getString("OID"));
				stmt.execute();
			
			return oMap;
			} catch (Exception e) {
				throw ExceptionHandler.convertException(e);
			} finally {
				GMServerDatasource.close(stmt);
				GMServerDatasource.close(conn);
			}
	
	
	     }	
}
