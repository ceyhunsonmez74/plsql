package tr.com.calikbank.bnspr.fast.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;

import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.GuimlUtil;
import tr.com.calikbank.bnspr.util.StringUtil;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.util.GMMap;

public class FastQRY8378Services {
	@GraymoundService("BNSPR_QRY8378_GET_FAST_MESAJLARI")
	public static GMMap getFastList(GMMap iMap) {
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		int i = 1;	  
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call pkg_rc_fast.RC_QRY8378_GET_FAST_MESAJLARI(?,?,?,?,?,?,?,?,?,?,?)}");
			stmt.registerOutParameter(i++, -10); //ref cursor
			stmt.setString(i++, iMap.getString("GELEN_GIDEN"));
			stmt.setString(i++, iMap.getString("MESAJ_KODU"));
			if(iMap.getString("K_DURUM")!=null && !iMap.getString("K_DURUM").equals(""))				
				stmt.setString(i++, iMap.getString("K_DURUM"));
			else
				stmt.setString(i++, null);
			stmt.setString(i++, iMap.getString("K_EFT_DURUMU"));
					
			if(iMap.getString("K_BOLUM")!=null && !iMap.getString("K_BOLUM").equals(""))
				{stmt.setString(i++, iMap.getString("K_BOLUM"));} 
			else stmt.setDate(i++, null);
			
			if ((iMap.get("K_EFT_TARIH_BAS") != null)) stmt.setDate(i++, new Date( iMap.getDate("K_EFT_TARIH_BAS").getTime()));
			else stmt.setDate(i++, null);

			if ((iMap.get("K_EFT_TARIH_BIT") != null)) stmt.setDate(i++, new Date(iMap.getDate("K_EFT_TARIH_BIT").getTime()));
			else stmt.setDate(i++, null);
			
			stmt.setString(i++, iMap.getString("K_MUSTERI_NO"));
			
			if (iMap.getBigDecimal("K_MIN_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("K_MIN_TUTAR"));

			if (iMap.getBigDecimal("K_MAX_TUTAR").compareTo(BigDecimal.ZERO)==0) stmt.setBigDecimal(i++, null);
			else stmt.setBigDecimal(i++, iMap.getBigDecimal("K_MAX_TUTAR"));
            
			stmt.setString(i++, iMap.getString("SIRALAMA_KRITERI"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
	
			String tableName = "EFT_MESAJLARI";
			int row = 0;
			BigDecimal gelenTutar = new BigDecimal(0);
			BigDecimal gidenTutar = new BigDecimal(0);
			int gidenSayi = 0;
			int gelenSayi = 0;
			while (rSet.next()) {
				oMap.put(tableName, row,"EKRAN_NO", rSet.getString("ekran_no"));
                if (rSet.getString("gelen_giden").equals("GELEN"))
                	oMap.put(tableName, row,"GELEN_GIDEN",  "Gelen");
                else
                	oMap.put(tableName, row,"GELEN_GIDEN",  "Giden");
                oMap.put(tableName, row,"SORGU_NO", rSet.getString("sorgu_no"));
                oMap.put(tableName, row,"MESAJ_KODU", rSet.getString("mesaj_kodu"));
                oMap.put(tableName, row,"BANKA_ADI", rSet.getString("banka_adi"));
                oMap.put(tableName, row,"MESAJ_TARIH", rSet.getDate("mesaj_tarih"));
                oMap.put(tableName, row,"DURUM", rSet.getString("durum"));
                oMap.put(tableName, row,"TRX_NO", rSet.getString("tx_no"));
                oMap.put(tableName, row,"KANAL_ADI", rSet.getString("kanal_adi"));
                oMap.put(tableName, row,"ISLEM_SAAT", rSet.getString("islem_saati"));
                oMap.put(tableName, row,"TUTAR", rSet.getString("FAST_TUTAR"));	
                oMap.put(tableName, row,"ACIKLAMA", rSet.getString("ACIKLAMA"));	
                oMap.put(tableName, row, "REFERANS_BILGISI", rSet.getString("referans_bilgisi"));
                oMap.put(tableName, row,"YARATILDIGI_TARIH", rSet.getString("yaratildigi_tarih"));
				if (rSet.getString("gelen_giden").equals("GELEN")){
 				try {
					gelenTutar = gelenTutar.add(rSet.getBigDecimal("fast_tutar"));
					gelenSayi++;
				} catch (Exception e) {}				
				} else
				if (rSet.getString("gelen_giden").equals("GIDEN")){
	 				try {
	 					gidenTutar = gidenTutar.add(rSet.getBigDecimal("fast_tutar"));
						gidenSayi++;
					} catch (Exception e) {}				
				}
				row++;  
			}
			oMap.put("GELEN_TOPLAM", gelenTutar);
			oMap.put("GIDEN_TOPLAM", gidenTutar);
			oMap.put("GELEN_KAYIT_SAYISI", gelenSayi);
			oMap.put("GIDEN_KAYIT_SAYISI", gidenSayi);
			
			String listName = "EFT_TIPLERI";
			GuimlUtil.wrapMyCombo(oMap, listName, "GELEN", "Gelen");
			GuimlUtil.wrapMyCombo(oMap, listName, "GIDEN", "Giden");
			
			return oMap;

		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
	
	@GraymoundService("BNSPR_QRY8374_GET_TARIHCE")
	public static GMMap getTarihce(GMMap iMap) {
		Connection 			conn = null;
		CallableStatement 	stmt = null;
		ResultSet 			rSet = null;
		GMMap				oMap = null;
		
		String tableName 	= "TARIHCE_LIST";
		String islemGoster[]= {"8311", "8317", "8312","8315"};
		int i = 1;
		try {
			conn = DALUtil.getGMConnection();
			stmt = conn.prepareCall("{? = call PKG_RC_FAST.GET_FAST_TARIHCE(?)}");
			stmt.registerOutParameter(i++, -10);
			stmt.setString(i++, iMap.getString("ISLEM_NO"));
			stmt.execute();
			rSet = (ResultSet)stmt.getObject(1);
			
			oMap = DALUtil.rSetResultsPutStr(rSet, tableName);
			
            for (int row = 0; row < oMap.getSize(tableName); row++){
                String islemNo = oMap.getString(tableName , row , "ISLEM_KODU");
                for (int n = 0; n < islemGoster.length; n++){
                    if (islemGoster[n].equals(islemNo)){
                        if (!StringUtil.isEmpty(oMap.getString(tableName , row , "ISLEM_NO"))){
                            oMap.put(tableName , row , "ISLEM_GOSTER" , true);
                            break;
                        }
                    }
                }
            }
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(rSet);
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
		}
	}
		
}
 



