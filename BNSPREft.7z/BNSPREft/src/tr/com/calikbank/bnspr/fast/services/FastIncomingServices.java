package tr.com.calikbank.bnspr.fast.services;

import java.math.BigDecimal;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.FastGelenMesajLog;
import tr.com.aktifbank.bnspr.dao.FastislemSonucLog;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.fast.services.FastCoreServices.Keys;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class FastIncomingServices {

	private static final Logger logger = Logger.getLogger(FastIncomingServices.class);
	
	@GraymoundService("BNSPR_FAST_INCOMING_INTER_PARTICIPANT_PAYMENT")
	public static GMMap katilimcilarArasiOdeme(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			FastGelenMesajLog fastGelenMesajLog=new FastGelenMesajLog();
			fastGelenMesajLog.setAlanKatilimciKodu(iMap.getString(Keys.ALN_KAT_KOD.name()));
			fastGelenMesajLog.setGirisZamani(iMap.getString(Keys.GIR_ZMN.name()));
			fastGelenMesajLog.setIslemTuru(iMap.getString(Keys.ISL_TUR.name()));
			fastGelenMesajLog.setIslemZamani(iMap.getString(Keys.ISL_ZMN.name()));
			fastGelenMesajLog.setOdemeAmaci(iMap.getString(Keys.ODM_AMC.name()));
			fastGelenMesajLog.setTutar(iMap.getBigDecimal(Keys.TTR.name()));
			fastGelenMesajLog.setAliciHesapNo(iMap.getString(Keys.ALC_HES_NO.name()));
			fastGelenMesajLog.setBilgi(iMap.getString(Keys.BLG.name()));
			fastGelenMesajLog.setDurum("EKLENDI");

			if(iMap.getSize(Keys.MES_REF_BLG.name())>0){
				fastGelenMesajLog.setMesajTarih(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.TRH.name())));
				fastGelenMesajLog.setGonderenKatilimciKodu(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.GON_KAT_KOD.name()));
				fastGelenMesajLog.setSorguNumarasi(new BigDecimal(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.SRG_NO.name())));
			}	
			if(iMap.getSize(Keys.ILG_MES_REF_BLG.name())>0){
				fastGelenMesajLog.setIlgiliIslemTarih(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.ILG_MES_REF_BLG.name(),0,Keys.TRH.name())));
				fastGelenMesajLog.setIlgiliGonderenKatilimci(iMap.getString(Keys.ILG_MES_REF_BLG.name(),0,Keys.GON_KAT_KOD.name()));
				fastGelenMesajLog.setIlgiliIslemSorguNo(new BigDecimal(iMap.getString(Keys.ILG_MES_REF_BLG.name(),0,Keys.SRG_NO.name())));
			}	
			
			if(iMap.getSize(Keys.EFT_MES_REF_BLG.name())>0){
				fastGelenMesajLog.setEftMesajTarih(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.EFT_MES_REF_BLG.name(),0,Keys.TRH.name())));
				fastGelenMesajLog.setEftGonderenKatilimci(iMap.getString(Keys.EFT_MES_REF_BLG.name(),0,Keys.GON_KAT_KOD.name()));
				fastGelenMesajLog.setEftSorguNumarasi(new BigDecimal(iMap.getString(Keys.EFT_MES_REF_BLG.name(),0,Keys.SRG_NO.name())));
			}	
			session.save(fastGelenMesajLog);
			session.flush();
			
			iMap.put("OID", fastGelenMesajLog.getOid());
			oMap = GMServiceExecuter.call("BNSPR_FAST_GELEN_TEYITSIZ", iMap);
			
		}

		catch (Exception exp) {
			logger.error("Fast Incoming Katilimcilar Arasi Odeme Exp:",exp);
			throw ExceptionHandler.convertException(exp);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_FAST_INCOMING_GENERAL_INFO")
	public static GMMap genelAmacliBilgi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
				Session session = DAOSession.getSession("BNSPRDal");
				FastGelenMesajLog fastGelenMesajLog=new FastGelenMesajLog();
				fastGelenMesajLog.setAlanKatilimciKodu(iMap.getString(Keys.ALN_KAT_KOD.name()));
				fastGelenMesajLog.setGirisZamani(iMap.getString(Keys.GIR_ZMN.name()));
				fastGelenMesajLog.setIslemTuru(iMap.getString(Keys.ISL_TUR.name()));
				fastGelenMesajLog.setBilgi(iMap.getString(Keys.BLG.name()));
				fastGelenMesajLog.setDurum("EKLENDI");

				if(iMap.getSize(Keys.MES_REF_BLG.name())>0){
					fastGelenMesajLog.setMesajTarih(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.TRH.name())));
					fastGelenMesajLog.setGonderenKatilimciKodu(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.GON_KAT_KOD.name()));
					fastGelenMesajLog.setSorguNumarasi(new BigDecimal(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.SRG_NO.name())));
				}	
				
				session.save(fastGelenMesajLog);
				session.flush();
				
				iMap.put("OID", fastGelenMesajLog.getOid());
				oMap = GMServiceExecuter.call("BNSPR_FAST_GELEN_TEYITSIZ", iMap);
				
		}
		catch (Exception exp) {
			logger.error("Fast Incoming Genel Amacli Bilgi Exp:",exp);
			throw ExceptionHandler.convertException(exp);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_FAST_INCOMING_BALANCE_TRANSFER_INFO")
	public static GMMap bakiyeAktarimIstegi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			FastGelenMesajLog fastGelenMesajLog=new FastGelenMesajLog();
			fastGelenMesajLog.setAlanKatilimciKodu(iMap.getString(Keys.ALN_KAT_KOD.name()));
			fastGelenMesajLog.setGirisZamani(iMap.getString(Keys.GIR_ZMN.name()));
			fastGelenMesajLog.setIslemTuru(iMap.getString(Keys.ISL_TUR.name()));
			fastGelenMesajLog.setTutar(iMap.getBigDecimal(Keys.TTR.name()));
			fastGelenMesajLog.setBorcluHesapNo(iMap.getString(Keys.BRC_HES_NO.name()));
			fastGelenMesajLog.setDurum("EKLENDI");

			if(iMap.getSize(Keys.MES_REF_BLG.name())>0){
				fastGelenMesajLog.setMesajTarih(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.TRH.name())));
				fastGelenMesajLog.setGonderenKatilimciKodu(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.GON_KAT_KOD.name()));
				fastGelenMesajLog.setSorguNumarasi(new BigDecimal(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.SRG_NO.name())));
			}	
			
			session.save(fastGelenMesajLog);
			session.flush();
			
			iMap.put("OID", fastGelenMesajLog.getOid());
			oMap = GMServiceExecuter.call("BNSPR_FAST_GELEN_TEYITSIZ", iMap);
		}
		catch (Exception exp) {
			logger.error("Fast Incoming Bakiye Aktarim Istegi Exp:",exp);
			throw ExceptionHandler.convertException(exp);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_FAST_INCOMING_DDB")
	public static GMMap duzelticiDogrudanBorclandirma(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

		}
		catch (Exception exp) {
			logger.error("Fast Incoming Duzeltici Dogrudan Barclandirma(DDB) Exp:",exp);
			throw ExceptionHandler.convertException(exp);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_FAST_INCOMING_DAILY_STATE_REPORT")
	public static GMMap gundonumuDurumRaporu(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

		}
		catch (Exception exp) {
			logger.error("Fast Incoming Gundonumu Durum Raporu Exp:",exp);
			throw ExceptionHandler.convertException(exp);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_FAST_INCOMING_PARTICIPANT_PROCESS_RESULT")
	public static GMMap katilimciyaIslemSonucu(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			FastislemSonucLog fastislemSonucLog=new FastislemSonucLog();
			fastislemSonucLog.setMesajKodu(iMap.getString(Keys.ISL_TUR.name()));
			fastislemSonucLog.setAlanKatilimciKodu(iMap.getString(Keys.ALN_KAT_KOD.name()));
			fastislemSonucLog.setGirisZamani(iMap.getString(Keys.GIR_ZMN.name()));
			fastislemSonucLog.setIslemZamani(iMap.getString(Keys.ISL_ZMN.name()));
			fastislemSonucLog.setSonucDurum(iMap.getInt(Keys.SNC_DRM.name())>0?true:false);
			fastislemSonucLog.setSonucDurumKodu(Byte.decode(iMap.getString(Keys.SNC_DRM_KOD.name())));
			fastislemSonucLog.setSonucDetay(iMap.getString(Keys.SNC_DTY.name()));
			if(iMap.getSize(Keys.MES_REF_BLG.name())>0){
				fastislemSonucLog.setMesajTarih(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.TRH.name())));
				fastislemSonucLog.setGonderenKatilimciKodu(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.GON_KAT_KOD.name()));
				fastislemSonucLog.setSorguNumarasi(new BigDecimal(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.SRG_NO.name())));
			}
			if(iMap.getSize(Keys.ILG_MES_REF_BLG.name())>0){
				fastislemSonucLog.setIlgiliIslemTarih(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.ILG_MES_REF_BLG.name(),0,Keys.TRH.name())));
				fastislemSonucLog.setIlgiliGonderenKatilimci(iMap.getString(Keys.ILG_MES_REF_BLG.name(),0,Keys.GON_KAT_KOD.name()));
				fastislemSonucLog.setIlgiliIslemSorguNo(new BigDecimal(iMap.getString(Keys.ILG_MES_REF_BLG.name(),0,Keys.SRG_NO.name())));
			}
			session.save(fastislemSonucLog);
			session.flush();
			
			iMap.put("OID", fastislemSonucLog.getOid());
	        oMap = GMServiceExecuter.call("BNSPR_FAST_ISLEM_SONUC", iMap);
			oMap.put(Keys.BSR_DRM.name(), 1);
		}
		catch (Exception exp) {
			logger.error("Fast Incoming Katilimciya Islem Sonucu Exp:",exp);
			throw ExceptionHandler.convertException(exp);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_FAST_INCOMING_DAILY_FLOW_NOTIFICATION")
	public static GMMap gunlukAkisBildirimi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {

		}
		catch (Exception exp) {
			logger.error("Fast Incoming Gunluk Akis Bildirimi Exp:",exp);
			throw ExceptionHandler.convertException(exp);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_FAST_INCOMING_REFUND")
	public static GMMap iadeIstegi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			FastGelenMesajLog fastGelenMesajLog=new FastGelenMesajLog();
			fastGelenMesajLog.setAlanKatilimciKodu(iMap.getString(Keys.ALN_KAT_KOD.name()));
			fastGelenMesajLog.setIslemTuru(iMap.getString(Keys.ISL_TUR.name()));
			fastGelenMesajLog.setIadeTalebiSebebi(iMap.getString(Keys.IADE_TLB_SBP.name()));
			fastGelenMesajLog.setAciklama(iMap.getString(Keys.ACKLM.name()));
			fastGelenMesajLog.setDurum("EKLENDI");
			if(iMap.getSize(Keys.MES_REF_BLG.name())>0){
				fastGelenMesajLog.setMesajTarih(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.TRH.name())));
				fastGelenMesajLog.setGonderenKatilimciKodu(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.GON_KAT_KOD.name()));
				fastGelenMesajLog.setSorguNumarasi(new BigDecimal(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.SRG_NO.name())));
			}	
			if(iMap.getSize(Keys.ILG_MES_REF_BLG.name())>0){
				fastGelenMesajLog.setIlgiliIslemTarih(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.ILG_MES_REF_BLG.name(),0,Keys.TRH.name())));
				fastGelenMesajLog.setIlgiliGonderenKatilimci(iMap.getString(Keys.ILG_MES_REF_BLG.name(),0,Keys.GON_KAT_KOD.name()));
				fastGelenMesajLog.setIlgiliIslemSorguNo(new BigDecimal(iMap.getString(Keys.ILG_MES_REF_BLG.name(),0,Keys.SRG_NO.name())));
			}			
			session.save(fastGelenMesajLog);
			session.flush();
			
			iMap.put("OID", fastGelenMesajLog.getOid());
			oMap = GMServiceExecuter.call("BNSPR_FAST_GELEN_TEYITSIZ", iMap);
			
		}
		catch (Exception exp) {
			logger.error("Fast Incoming Iade Istegi Exp:",exp);
			throw ExceptionHandler.convertException(exp);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_FAST_INCOMING_PAYMENT_REFUND")
	public static GMMap odemeIadesi(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			FastGelenMesajLog fastGelenMesajLog=new FastGelenMesajLog();
			fastGelenMesajLog.setAlanKatilimciKodu(iMap.getString(Keys.ALN_KAT_KOD.name()));
			fastGelenMesajLog.setIslemTuru(iMap.getString(Keys.ISL_TUR.name()));
			fastGelenMesajLog.setTutar(FastCoreServicesUtility.toBigDecimal(iMap.getString(Keys.TTR.name())));
			fastGelenMesajLog.setGonderenAdi(iMap.getString(Keys.GON_AD.name()));
			fastGelenMesajLog.setGonderenHesapNo(iMap.getString(Keys.GON_HES_NO.name()));
			fastGelenMesajLog.setGonderenKimlikNumarasi(iMap.getString(Keys.GON_KIM_NO.name()));
			fastGelenMesajLog.setAliciAdi(iMap.getString(Keys.ALC_AD.name()));
			fastGelenMesajLog.setAliciHesapNo(iMap.getString(Keys.ALC_HES_NO.name()));
			fastGelenMesajLog.setAliciKimlikNumarasi(iMap.getString(Keys.ALC_KIM_NO.name()));
			fastGelenMesajLog.setIadeKodu(iMap.getString(Keys.IADE_KOD.name()));
			fastGelenMesajLog.setAciklama(iMap.getString(Keys.ACKLM.name()));
			fastGelenMesajLog.setDurum("EKLENDI");
			if(iMap.getSize(Keys.MES_REF_BLG.name())>0){
				fastGelenMesajLog.setMesajTarih(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.TRH.name())));
				fastGelenMesajLog.setGonderenKatilimciKodu(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.GON_KAT_KOD.name()));
				fastGelenMesajLog.setSorguNumarasi(new BigDecimal(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.SRG_NO.name())));
			}			
			if(iMap.getSize(Keys.ILG_MES_REF_BLG.name())>0){
				fastGelenMesajLog.setIlgiliIslemTarih(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.ILG_MES_REF_BLG.name(),0,Keys.TRH.name())));
				fastGelenMesajLog.setIlgiliGonderenKatilimci(iMap.getString(Keys.ILG_MES_REF_BLG.name(),0,Keys.GON_KAT_KOD.name()));
				fastGelenMesajLog.setIlgiliIslemSorguNo(new BigDecimal(iMap.getString(Keys.ILG_MES_REF_BLG.name(),0,Keys.SRG_NO.name())));
			}
			if(iMap.getSize(Keys.ODM_AYRNT.name())>0){
				fastGelenMesajLog.setGonderenAdres(iMap.getString(Keys.ODM_AYRNT.name(),0,Keys.ADRES.name()));
				fastGelenMesajLog.setGonderenPasaportNo(iMap.getString(Keys.ODM_AYRNT.name(),0,Keys.PASAPORT.name()));
				fastGelenMesajLog.setGonderenDogumYeri(iMap.getString(Keys.ODM_AYRNT.name(),0,Keys.DGM_YER.name()));
				fastGelenMesajLog.setGonderenDogumTarihi(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.ODM_AYRNT.name(),0,Keys.DGM_TRH.name())));
				fastGelenMesajLog.setGonderenMusteriNumarasi(iMap.getString(Keys.ODM_AYRNT.name(),0,Keys.MUS_NO.name()));
			}

			session.save(fastGelenMesajLog);
			session.flush();
			
			iMap.put("OID", fastGelenMesajLog.getOid());

			oMap = GMServiceExecuter.call("BNSPR_FAST_GELEN_TEYIT", iMap);
			oMap.put(Keys.TYT_DRM.name(), oMap.getBigDecimal("TEYIT_DURUM"));
			oMap.put(Keys.TYT_DRM_KOD.name(), oMap.getBigDecimal("TEYIT_DURUM_KODU"));
			
		}
		catch (Exception exp) {
			logger.error("Fast Incoming Odeme Iadesi Exp:",exp);
			throw ExceptionHandler.convertException(exp);
		}
		return oMap;
	}
	
	@GraymoundService("BNSPR_FAST_INCOMING_INSTANT_PAYMENT")
	public static GMMap anlikOdeme(GMMap iMap) {
		GMMap oMap = new GMMap();
		try {
			Session session = DAOSession.getSession("BNSPRDal");
			FastGelenMesajLog fastGelenMesajLog=new FastGelenMesajLog();
			fastGelenMesajLog.setAlanKatilimciKodu(iMap.getString(Keys.ALN_KAT_KOD.name()));
			fastGelenMesajLog.setGirisZamani(iMap.getString(Keys.GIR_ZMN.name()));
			fastGelenMesajLog.setIslemTuru(iMap.getString(Keys.ISL_TUR.name()));
			fastGelenMesajLog.setTutar(FastCoreServicesUtility.toBigDecimal(iMap.getString(Keys.TTR.name())));
			fastGelenMesajLog.setOdemeAmaci(iMap.getString(Keys.ODM_AMC.name()));
			fastGelenMesajLog.setOdemeKaynak(iMap.getString(Keys.ODM_KYNK.name()));
			fastGelenMesajLog.setGonderenAdi(iMap.getString(Keys.GON_AD.name()));
			fastGelenMesajLog.setGonderenHesapNo(iMap.getString(Keys.GON_HES_NO.name()));
			fastGelenMesajLog.setGonderenKimlikNumarasi(iMap.getString(Keys.GON_KIM_NO.name()));
			fastGelenMesajLog.setAliciAdi(iMap.getString(Keys.ALC_AD.name()));
			fastGelenMesajLog.setAliciHesapNo(iMap.getString(Keys.ALC_HES_NO.name()));
			fastGelenMesajLog.setAliciKimlikNumarasi(iMap.getString(Keys.ALC_KIM_NO.name()));
			fastGelenMesajLog.setReferansBilgisi(iMap.getString(Keys.REF_BLG.name()));
			fastGelenMesajLog.setAciklama(iMap.getString(Keys.ACKLM.name()));
			fastGelenMesajLog.setDurum("EKLENDI");
			
			if(iMap.getSize(Keys.ODM_AYRNT.name())>0){
				fastGelenMesajLog.setGonderenAdres(iMap.getString(Keys.ODM_AYRNT.name(),0,Keys.ADRES.name()));
				fastGelenMesajLog.setGonderenPasaportNo(iMap.getString(Keys.ODM_AYRNT.name(),0,Keys.PASAPORT.name()));
				fastGelenMesajLog.setGonderenDogumYeri(iMap.getString(Keys.ODM_AYRNT.name(),0,Keys.DGM_YER.name()));
				fastGelenMesajLog.setGonderenDogumTarihi(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.ODM_AYRNT.name(),0,Keys.DGM_TRH.name())));
				fastGelenMesajLog.setGonderenMusteriNumarasi(iMap.getString(Keys.ODM_AYRNT.name(),0,Keys.MUS_NO.name()));
			}
			if(iMap.getSize(Keys.MES_REF_BLG.name())>0){
				fastGelenMesajLog.setMesajTarih(FastCoreServicesUtility.toDateFromString(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.TRH.name())));
				fastGelenMesajLog.setGonderenKatilimciKodu(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.GON_KAT_KOD.name()));
				fastGelenMesajLog.setSorguNumarasi(new BigDecimal(iMap.getString(Keys.MES_REF_BLG.name(),0,Keys.SRG_NO.name())));
			}
			if(iMap.getSize(Keys.KTM_SRV_BLG.name())>0){
				fastGelenMesajLog.setKolasReferansi(iMap.getString(Keys.KTM_SRV_BLG.name(),0,Keys.KOLAS_REF.name()));
			}
			if(iMap.getSize(Keys.KRKD.name())>0){
				fastGelenMesajLog.setKarekodAkisTuru(iMap.getString(Keys.KRKD.name(),0,Keys.KRKD_AKS_TUR.name()));
				fastGelenMesajLog.setKarekodReferansi(iMap.getString(Keys.KRKD.name(),0,Keys.KRKD_REF.name()));
			}
			
			session.save(fastGelenMesajLog);
			session.flush();
			
			iMap.put("OID", fastGelenMesajLog.getOid());

			oMap = GMServiceExecuter.call("BNSPR_FAST_GELEN_TEYIT", iMap);
			oMap.put(Keys.TYT_DRM.name(), oMap.getBigDecimal("TEYIT_DURUM"));
			oMap.put(Keys.TYT_DRM_KOD.name(), oMap.getBigDecimal("TEYIT_DURUM_KODU"));
			
		}
		catch (Exception exp) {
			logger.error("Fast Incoming Anlik Odeme Exp:",exp);
			throw ExceptionHandler.convertException(exp);
		}
		return oMap;
	}
	
}
