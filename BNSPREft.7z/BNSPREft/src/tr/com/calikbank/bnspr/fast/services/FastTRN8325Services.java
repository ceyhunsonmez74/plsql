package tr.com.calikbank.bnspr.fast.services;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.FastGelenTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class FastTRN8325Services {

	@GraymoundService("BNSPR_TRN8325_GET_INFO")
	public static GMMap getTRN8320GetInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
	                                                                  
			GMMap oMap=new GMMap();
	        
			FastGelenTx fastGelenTx = (FastGelenTx) session.load(FastGelenTx.class, iMap.getBigDecimal("TRX_NO"));	

			oMap.put("MESAJ_KODU", fastGelenTx.getMesajKodu());
			oMap.put("FAST_TARIH", fastGelenTx.getMesajTarih());
			oMap.put("GONDEREN_BANKA", fastGelenTx.getGonderenBankaKodu());
            oMap.put("DISPLAY_GONDEREN_BANKA", LovHelper.diLov(fastGelenTx.getGonderenBankaKodu(), "8317/LOV_BANKA", "BANKA_ADI"));			
			oMap.put("ALAN_BANKA", fastGelenTx.getAlanBankaKodu());
			oMap.put("SORGU_NO", fastGelenTx.getSorguNo());
			oMap.put("BILGI", fastGelenTx.getBilgi());
			oMap.put("ODEME_AMACI", fastGelenTx.getOdemeAmaci());
			oMap.put("DURUM", fastGelenTx.getDurum());
			oMap.put("ILGILI_ISLEM_TARIH", fastGelenTx.getIlgiliIslemTarih());
			oMap.put("ILGILI_GONDEREN_KATILIMCI", fastGelenTx.getIlgiliGonderenKatilimci());
			oMap.put("ILGILI_ISLEM_SORGU_NO", fastGelenTx.getIlgiliIslemSorguNo());
			oMap.put("ILGILI_ISLEM_TXNO", fastGelenTx.getIlgiliIslemTxNo());
			oMap.put("EFT_MESAJ_TARIH", fastGelenTx.getEftMesajTarih());
			oMap.put("EFT_GONDEREN_KATILIMCI", fastGelenTx.getEftGonderenKatilimci());
			oMap.put("EFT_SORGU_NO", fastGelenTx.getEftSorguNumarasi());
			
	        return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
		
}	
