package tr.com.calikbank.bnspr.fast.services;

import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import tr.com.aktifbank.bnspr.dao.FastGidenTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.fast.services.FastCoreServices.Keys;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;
import tr.com.calikbank.bnspr.util.PaygateConstants;
import tr.com.paygate.ArrayOfSearchFilter;
import tr.com.paygate.DetailLevel;
import tr.com.paygate.FilterName;
import tr.com.paygate.SearchEFTData;
import tr.com.paygate.SearchFilter;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.GMServerDatasource;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class FastTRN8315Services {

	@GraymoundService("BNSPR_TRN8315_GET_SORGU_NO")
	public static GMMap getApplicationNo(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("SORGU_NO", new BigDecimal(DALUtil.getResult("select bnspr.SEQ_FAST_SORGU_NO.nextval from dual")));
		return oMap;
	}	

	@GraymoundService("BNSPR_TRN8315_ALAN_BANKA_KONTROL")
	public static GMMap alanBankaKontrol(GMMap iMap) {
		GMMap oMap = new GMMap();
		oMap.put("RESULT", DALUtil.callNoParameterFunction("{? = call pkg_fast.FAST_banka_durum('" + iMap.getString("ALAN_BANKA") + "')}", Types.VARCHAR));
		return oMap;
	}
	
	@GraymoundService("BNSPR_TRN8315_SAVE")
	public static GMMap save(GMMap iMap) {
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			FastGidenTx fastGidenTx = (FastGidenTx) session.get(FastGidenTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if (fastGidenTx == null) {
				fastGidenTx = new FastGidenTx();
				fastGidenTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}
			
			fastGidenTx.setMesajKodu(iMap.getString("MESAJ_KODU"));
			fastGidenTx.setMesajTarih(iMap.getDate("FAST_TARIH"));
			fastGidenTx.setGonderenBankaKodu(iMap.getString("GONDEREN_BANKA"));
			fastGidenTx.setAlanBankaKodu(iMap.getString("ALAN_BANKA"));
			fastGidenTx.setSorguNo(iMap.getBigDecimal("SORGU_NO"));
			fastGidenTx.setFastTutar(iMap.getBigDecimal("FAST_TUTAR"));
			fastGidenTx.setTutarScr(iMap.getBigDecimal("TUTAR_SCR"));
			fastGidenTx.setOdemeTuru(iMap.getString("ODEME_TURU"));
			fastGidenTx.setOdemeKaynak(iMap.getString("ODEME_KAYNAK"));
			fastGidenTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			fastGidenTx.setMusteriHesapNo(iMap.getBigDecimal("MUSTERI_HESAP_NO"));
			fastGidenTx.setGonderen(iMap.getString("GONDEREN"));
			fastGidenTx.setGonderenIban(iMap.getString("GONDEREN_IBAN"));
			fastGidenTx.setGonderenKimlikNumarasi(iMap.getString("GONDEREN_KIMLIK_NUMARASI"));
			fastGidenTx.setAliciAdi(iMap.getString("ALICI_ADI"));
			fastGidenTx.setAliciHesapNo(iMap.getString("ALICI_HESAP_NO"));
			fastGidenTx.setAliciKimlikNumarasi(iMap.getString("ALICI_KIMLIK_NUMARASI"));	
			fastGidenTx.setReferansBilgisi(iMap.getString("REFERANS_BILGISI"));
			fastGidenTx.setAciklama(iMap.getString("ACIKLAMA"));
			fastGidenTx.setGonderenAdres(iMap.getString("GONDEREN_ADRES"));
			fastGidenTx.setGonderenPasaportNo(iMap.getString("GONDEREN_PASAPORT_NO"));
			fastGidenTx.setGonderenDogumTarihi(iMap.getDate("GONDEREN_DOGUM_TARIHI"));
			fastGidenTx.setGonderenDogumYeri(iMap.getString("GONDEREN_DOGUM_YERI"));
			fastGidenTx.setGonderenMusteriNumarasi(iMap.getString("GONDEREN_MUSTERI_NUMARASI"));
			fastGidenTx.setKolasReferansi(iMap.getString("KOLAS_REFERANSI"));
			fastGidenTx.setDurum(iMap.getString("DURUM"));
			fastGidenTx.setMasraf(iMap.getBigDecimal("MASRAF"));
			fastGidenTx.setMasrafIcDis(iMap.getString("MASRAF_IC_DIS"));
			fastGidenTx.setIslemKaynak(iMap.getString("ISLEM_KAYNAK"));
			fastGidenTx.setMasrafHesapNo(iMap.getBigDecimal("MASRAF_HESAP_NO"));
			fastGidenTx.setKimlikTipi(iMap.getBigDecimal("KIMLIK_TIPI"));
			fastGidenTx.setKolayAdresTipi(iMap.getString("KOLAY_ADRES_TIPI"));
			fastGidenTx.setKolayAdresDegeri(iMap.getString("KOLAY_ADRES"));
			
			session.saveOrUpdate(fastGidenTx);
			session.flush();
			
			iMap.put("TRX_NAME", "8315");

			GMMap oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
			
	@GraymoundService("BNSPR_TRN8315_GET_INFO")
	public static GMMap getTRN8315GetInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
	                                                                  
			GMMap oMap=new GMMap();
	        
			FastGidenTx fastGidenTx = (FastGidenTx) session.load(FastGidenTx.class, iMap.getBigDecimal("TRX_NO"));	
			oMap.put("MESAJ_KODU", fastGidenTx.getMesajKodu());
			oMap.put("FAST_TARIH", fastGidenTx.getMesajTarih());
			oMap.put("GONDEREN_BANKA", fastGidenTx.getGonderenBankaKodu());
			oMap.put("ALAN_BANKA", fastGidenTx.getAlanBankaKodu());
            oMap.put("DISPLAY_ALAN_BANKA_KODU", LovHelper.diLov(fastGidenTx.getAlanBankaKodu(), "8315/LOV_ALAN_BANKA", "BANKA_ADI"));
			oMap.put("SORGU_NO", fastGidenTx.getSorguNo());
			oMap.put("FAST_TUTAR", fastGidenTx.getFastTutar());
			oMap.put("TUTAR_SCR", fastGidenTx.getTutarScr());
			oMap.put("ODEME_TURU", fastGidenTx.getOdemeTuru());
			oMap.put("ODEME_KAYNAK", fastGidenTx.getOdemeKaynak());
			oMap.put("MUSTERI_NO", fastGidenTx.getMusteriNo());
	        oMap.put("DISPLAY_MUSTERI_ADI" , LovHelper.diLov(fastGidenTx.getMusteriNo(), "8315/LOV_MUSTERI", "UNVAN"));
			oMap.put("MUSTERI_HESAP_NO", fastGidenTx.getMusteriHesapNo());
			oMap.put("GONDEREN", fastGidenTx.getGonderen());
			oMap.put("GONDEREN_IBAN", fastGidenTx.getGonderenIban());
			oMap.put("GONDEREN_KIMLIK_NUMARASI", fastGidenTx.getGonderenKimlikNumarasi());
			oMap.put("ALICI_ADI", fastGidenTx.getAliciAdi());
			oMap.put("ALICI_HESAP_NO", fastGidenTx.getAliciHesapNo());
			oMap.put("ALICI_KIMLIK_NUMARASI", fastGidenTx.getAliciKimlikNumarasi());
			oMap.put("REFERANS_BILGISI", fastGidenTx.getReferansBilgisi());
			oMap.put("ACIKLAMA", fastGidenTx.getAciklama());
			oMap.put("GONDEREN_ADRES", fastGidenTx.getGonderenAdres());
			oMap.put("GONDEREN_PASAPORT_NO", fastGidenTx.getGonderenPasaportNo());
			oMap.put("GONDEREN_DOGUM_TARIHI", fastGidenTx.getGonderenDogumTarihi());
			oMap.put("GONDEREN_DOGUM_YERI", fastGidenTx.getGonderenDogumYeri());
			oMap.put("GONDEREN_MUSTERI_NUMARASI", fastGidenTx.getGonderenMusteriNumarasi());
			oMap.put("KOLAS_REFERANSI", fastGidenTx.getKolasReferansi());
			oMap.put("DURUM", fastGidenTx.getDurum());
			oMap.put("MASRAF", fastGidenTx.getMasraf());
			oMap.put("MASRAF_IC_DIS", fastGidenTx.getMasrafIcDis());
			oMap.put("MASRAF_HESAP_NO", fastGidenTx.getMasrafHesapNo());
			oMap.put("ISLEM_KAYNAK", fastGidenTx.getIslemKaynak());
			oMap.put("KIMLIK_TIPI", fastGidenTx.getKimlikTipi());	
			oMap.put("KOLAY_ADRES_TIPI", fastGidenTx.getKolayAdresTipi());
			oMap.put("KOLAY_ADRES", fastGidenTx.getKolayAdresDegeri());
			
	        return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN8315_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {

		GMMap oMap = new GMMap();
		GMMap iMap2 = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal"); 
			FastGidenTx fastGidenTx = (FastGidenTx) session.get(FastGidenTx.class, iMap.getBigDecimal("ISLEM_NO")); 
			session.refresh(fastGidenTx);
			iMap2.put("ALN_KAT_KOD", fastGidenTx.getAlanBankaKodu());
			iMap2.put("TTR", fastGidenTx.getFastTutar());
			iMap2.put("ODM_AMC", fastGidenTx.getOdemeTuru());
			iMap2.put("ODM_KYNK", fastGidenTx.getOdemeKaynak());
			iMap2.put("GON_AD", fastGidenTx.getGonderen());
			iMap2.put("GON_HES_NO", fastGidenTx.getGonderenIban());
			iMap2.put("GON_KIM_NO", fastGidenTx.getGonderenKimlikNumarasi());
			iMap2.put("ALC_AD", fastGidenTx.getAliciAdi());
			iMap2.put("ALC_HES_NO", fastGidenTx.getAliciHesapNo());
			iMap2.put("ALC_KIM_NO", fastGidenTx.getAliciKimlikNumarasi());
			iMap2.put("REF_BLG", fastGidenTx.getReferansBilgisi());
			iMap2.put("ACKLM", fastGidenTx.getAciklama());
			iMap2.put("REF_BLG", fastGidenTx.getReferansBilgisi());
			iMap2.put("SN", fastGidenTx.getSorguNo());
			
			iMap2.put("ODM_AYRNT", 0, "ADRES", fastGidenTx.getGonderenAdres());
			iMap2.put("ODM_AYRNT", 0, "PASAPORT", fastGidenTx.getGonderenPasaportNo());
			iMap2.put("ODM_AYRNT", 0, "DGM_YER", fastGidenTx.getGonderenDogumYeri());
			iMap2.put("ODM_AYRNT", 0, "DGM_TRH", fastGidenTx.getGonderenDogumTarihi());
			iMap2.put("ODM_AYRNT", 0, "MUS_NO", fastGidenTx.getGonderenMusteriNumarasi());
			
            if (fastGidenTx.getKolasReferansi()!=null) {
            	iMap2.put("KTM_SRV_BLG", 0, "KOLAS_REF", fastGidenTx.getKolasReferansi());
            }

			oMap = GMServiceExecuter.call("BNSPR_FAST_OUTGOING_INSTANT_PAYMENT", iMap2);
			
			
			return oMap;

	   } catch (Exception e) {
	     	throw ExceptionHandler.convertException(e);
	     } 
		
	}	
	
	@GraymoundService("BNSPR_TRN8315_FAST_PAYGATE_CHECK")
	public static GMMap fast8315PaygateCheck(GMMap iMap){
		Connection conn = null;
		CallableStatement stmt = null;
		ResultSet rSet = null;
		GMMap oMap = new GMMap();
		try {
    		DateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
			SearchEFTData searchEftData = new SearchEFTData();

          	searchEftData.setComment(StringUtils.isBlank(iMap.getString("ACIKLAMA")) ? "":iMap.getString("ACIKLAMA"));
            searchEftData.setBeneficiaryName(iMap.getString("ALICI"));
            searchEftData.setCustomerName(iMap.getString("GONDEREN"));
            searchEftData.setCustomerIdentificationNo(iMap.getString("MUSTERI_NO"));
            searchEftData.setAmount(iMap.getBigDecimal("TUTAR"));
            searchEftData.setReceiverBankCode(iMap.getString("ALAN_BANKA"));
            searchEftData.setSenderBankCode((StringUtils.isBlank(iMap.getString("GONDEREN_BANKA"))?"AKTIF YATIRIM BANKASI A.S.":iMap.getString("GONDEREN_BANKA")));
            //searchEftData.setSenderBankCode(iMap.getString("GONDEREN_BANKA","AKTIF YATIRIM BANKASI A.S."));
            searchEftData.setValueDate(getXmlGregorianCalendar(iMap.getDate("FAST_TARIH")));
            searchEftData.setBeneficiaryIdentificationNo(iMap.getString("ALICI_TCKN"));
            searchEftData.setApplicationName(iMap.getString("TRX_NAME","8315"));
            searchEftData.setDetailLevel(DetailLevel.FULL);
            searchEftData.setExternalId(iMap.getString("TRX_NO"));
            searchEftData.setInstanceId(PaygateConstants.LIST_GROUP_AKUSTIK_4);
            searchEftData.setDirection("O");
            
            ArrayOfSearchFilter arrOfSearchFilter = new ArrayOfSearchFilter();
            //MUSTERI_NO paygate search filter
            if (StringUtils.isNotBlank(iMap.getString("MUSTERI_NO"))) {
	            SearchFilter sfMusteriNo = new SearchFilter();
	            sfMusteriNo.setKey(FilterName.CUSTOMER_NUMBER);
	            sfMusteriNo.setValue(iMap.getString("MUSTERI_NO"));
	            sfMusteriNo.setLogicalOperator("AND");
	            sfMusteriNo.setIsFeatureFilter(false);
	            arrOfSearchFilter.getSearchFilter().add(sfMusteriNo);
            }  
            //ALICI_TCKN paygate search filter
            if (StringUtils.isNotBlank(iMap.getString("ALICI_TCKN"))) {
	            SearchFilter sfAliciTckn = new SearchFilter();
	            sfAliciTckn.setKey(FilterName.BENEFICIARY_NATIOANAL_ID);
	            sfAliciTckn.setValue(iMap.getString("ALICI_TCKN"));
	            sfAliciTckn.setLogicalOperator("AND");
	            sfAliciTckn.setIsFeatureFilter(false);
	            arrOfSearchFilter.getSearchFilter().add(sfAliciTckn);
            }
            //ALICI_DTARIH paygate search filter
            if (StringUtils.isNotBlank(iMap.getString("ALICI_DTARIH"))) {
	            SearchFilter sfAliciDtarih = new SearchFilter();
	            sfAliciDtarih.setKey(FilterName.BENEFICIARY_DATE_OF_BIRTH);
	            sfAliciDtarih.setValue(sdf.format(iMap.getDate("ALICI_DTARIH")));
	            sfAliciDtarih.setLogicalOperator("AND");
	            sfAliciDtarih.setIsFeatureFilter(false);
	            arrOfSearchFilter.getSearchFilter().add(sfAliciDtarih);
            }
            //GONDEREN_TCKN paygate search filter
            if (StringUtils.isNotBlank(iMap.getString("GONDEREN_TCKN"))) {
	            SearchFilter sfGonderenTckn = new SearchFilter();
	            sfGonderenTckn.setKey(FilterName.CUSTOMER_NATIONAL_ID);
	            sfGonderenTckn.setValue(iMap.getString("GONDEREN_TCKN"));
	            sfGonderenTckn.setLogicalOperator("AND");
	            sfGonderenTckn.setIsFeatureFilter(false);
	            arrOfSearchFilter.getSearchFilter().add(sfGonderenTckn);
            }
            //GONDEREN_DTARIH paygate search filter
            if (StringUtils.isNotBlank(iMap.getString("GONDEREN_DTARIH"))) {
	            SearchFilter sfGonderenDtarih = new SearchFilter();
	            sfGonderenDtarih.setKey(FilterName.CUSTOMER_DATE_OF_BIRTH);
	            sfGonderenDtarih.setValue(sdf.format(iMap.getDate("GONDEREN_DTARIH")));
	            sfGonderenDtarih.setLogicalOperator("AND");
	            sfGonderenDtarih.setIsFeatureFilter(false);
	            arrOfSearchFilter.getSearchFilter().add(sfGonderenDtarih);
            }
            
            searchEftData.setFilters(arrOfSearchFilter);

            GMMap amlMap = new GMMap(); 
            amlMap.put("SEARCH_EFT_DATA", searchEftData);             
            oMap = GMServiceExecuter.call("BNSPR_EXT_FINEKSUS_SEARCH_EFT_DATA", amlMap);
            return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} finally {
			GMServerDatasource.close(stmt);
			GMServerDatasource.close(conn);
			GMServerDatasource.close(rSet);
		}
	}

	
	public static XMLGregorianCalendar getXmlGregorianCalendar(java.util.Date date) throws DatatypeConfigurationException {
		GregorianCalendar c = new GregorianCalendar();
		c.setTime(date);
		return DatatypeFactory.newInstance().newXMLGregorianCalendar(c);	
	}
	
}
