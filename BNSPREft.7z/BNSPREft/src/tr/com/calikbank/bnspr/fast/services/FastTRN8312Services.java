package tr.com.calikbank.bnspr.fast.services;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.FastGelenTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class FastTRN8312Services {

	
	@GraymoundService("BNSPR_TRN8312_GET_INFO")
	public static GMMap getTRN8312GetInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
	                                                                  
			GMMap oMap=new GMMap();
	        
			FastGelenTx fastGelenTx = (FastGelenTx) session.load(FastGelenTx.class, iMap.getBigDecimal("TRX_NO"));				
			oMap.put("MESAJ_KODU", fastGelenTx.getMesajKodu());
			oMap.put("FAST_TARIH", fastGelenTx.getMesajTarih());
			oMap.put("GONDEREN_BANKA", fastGelenTx.getGonderenBankaKodu());
			oMap.put("ALAN_BANKA", fastGelenTx.getAlanBankaKodu());
            oMap.put("DISPLAY_GONDEREN_BANKA", LovHelper.diLov(fastGelenTx.getGonderenBankaKodu(), "8317/LOV_BANKA", "BANKA_ADI"));
            oMap.put("DISPLAY_ALAN_BANKA_KODU", LovHelper.diLov(fastGelenTx.getAlanBankaKodu(), "8317/LOV_BANKA", "BANKA_ADI"));
            oMap.put("SORGU_NO", fastGelenTx.getSorguNo());
			oMap.put("FAST_TUTAR", fastGelenTx.getFastTutar());
			oMap.put("ODEME_MUSTERI_NO", fastGelenTx.getOdemeMusteriNo());
	        oMap.put("DISPLAY_MUSTERI_ADI" , LovHelper.diLov(fastGelenTx.getOdemeMusteriNo(), "8317/LOV_MUSTERI", "ADI"));
			oMap.put("ODEME_MUSTERI_HESAP_NO", fastGelenTx.getOdemeMusteriHesap());
			oMap.put("DISPLAY_KISA_ISIM" , LovHelper.diLov(fastGelenTx.getOdemeMusteriHesap(), fastGelenTx.getOdemeMusteriNo(), "8317/LOV_MUSTERI_HESAP_NO", "KISA_ISIM"));
			oMap.put("ODEME_IBAN" , LovHelper.diLov(fastGelenTx.getOdemeMusteriHesap(), fastGelenTx.getOdemeMusteriNo(), "8317/LOV_MUSTERI_HESAP_NO", "IBAN"));
            oMap.put("ODEME_SUBE", fastGelenTx.getOdemeSube());
            oMap.put("DISPLAY_ODEME_SUBE", LovHelper.diLov(fastGelenTx.getOdemeSube(),"8317/LOV_BOLUM", "ADI"));
			oMap.put("GONDEREN", fastGelenTx.getGonderenAdi());
			oMap.put("GONDEREN_HESAP_NUMARASI", fastGelenTx.getGonderenHesapNo());
			oMap.put("GONDEREN_KIMLIK_NUMARASI", fastGelenTx.getGonderenKimlikNumarasi());
			oMap.put("ALICI_ADI", fastGelenTx.getAliciAdi());
			oMap.put("ALICI_HESAP_NO", fastGelenTx.getAliciHesapNo());
			oMap.put("ALICI_KIMLIK_NUMARASI", fastGelenTx.getAliciKimlikNumarasi());
			oMap.put("ACIKLAMA", fastGelenTx.getAciklama());
			oMap.put("GONDEREN_ADRES", fastGelenTx.getGonderenAdres());
			oMap.put("GONDEREN_PASAPORT_NO", fastGelenTx.getGonderenPasaportNo());
			oMap.put("GONDEREN_DOGUM_TARIHI", fastGelenTx.getGonderenDogumTarihi());
			oMap.put("GONDEREN_DOGUM_YERI", fastGelenTx.getGonderenDogumYeri());
			oMap.put("GONDEREN_MUSTERI_NUMARASI", fastGelenTx.getGonderenMusteriNumarasi());
			oMap.put("IADE_KODU", fastGelenTx.getIadeKodu());
			oMap.put("DURUM", fastGelenTx.getDurum());
			oMap.put("ILGILI_ISLEM_TARIH", fastGelenTx.getIlgiliIslemTarih());
			oMap.put("ILGILI_GONDEREN_KATILIMCI", fastGelenTx.getIlgiliGonderenKatilimci());
			oMap.put("ILGILI_ISLEM_SORGU_NO", fastGelenTx.getIlgiliIslemSorguNo());
			oMap.put("ILGILI_ISLEM_TXNO", fastGelenTx.getIlgiliIslemTxNo());
			
	        return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

}
