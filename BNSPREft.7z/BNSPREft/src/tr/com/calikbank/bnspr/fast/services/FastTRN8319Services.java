package tr.com.calikbank.bnspr.fast.services;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.FastGidenTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class FastTRN8319Services {


	@GraymoundService("BNSPR_TRN8319_SAVE")
	public static GMMap save(GMMap iMap) {
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			FastGidenTx fastGidenTx = (FastGidenTx) session.get(FastGidenTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if (fastGidenTx == null) {
				fastGidenTx = new FastGidenTx();
				fastGidenTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}
			
			fastGidenTx.setMesajKodu(iMap.getString("MESAJ_KODU"));
			fastGidenTx.setMesajTarih(iMap.getDate("FAST_TARIH"));
			fastGidenTx.setGonderenBankaKodu(iMap.getString("GONDEREN_BANKA"));
			fastGidenTx.setAlanBankaKodu(iMap.getString("ALAN_BANKA"));
			fastGidenTx.setSorguNo(iMap.getBigDecimal("SORGU_NO"));
			fastGidenTx.setIadeKodu(iMap.getString("IADE_TALEP_KODU"));
			fastGidenTx.setAciklama(iMap.getString("ACIKLAMA"));
			fastGidenTx.setIlgiliIslemTarih(iMap.getDate("ILGILI_ISLEM_TARIH"));
			fastGidenTx.setIlgiliGonderenKatilimci(iMap.getString("ILGILI_GONDEREN_KATILIMCI"));
			fastGidenTx.setIlgiliIslemSorguNo(iMap.getBigDecimal("ILGILI_ISLEM_SORGU_NO"));
			fastGidenTx.setIlgiliIslemTxNo(iMap.getBigDecimal("ILGILI_ISLEM_TXNO"));
			fastGidenTx.setIadeTalebiSebebi(iMap.getString("IADE_TALEP_KODU"));
			fastGidenTx.setDurum(iMap.getString("DURUM"));
			
			session.saveOrUpdate(fastGidenTx);
			session.flush();
			
			iMap.put("TRX_NAME", "8319");

			GMMap oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}

	@GraymoundService("BNSPR_TRN8319_GET_INFO")
	public static GMMap getTRN8319GetInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
	                                                                  
			GMMap oMap=new GMMap();
	        
			FastGidenTx fastGidenTx = (FastGidenTx) session.load(FastGidenTx.class, iMap.getBigDecimal("TRX_NO"));	
			oMap.put("MESAJ_KODU", fastGidenTx.getMesajKodu());
			oMap.put("FAST_TARIH", fastGidenTx.getMesajTarih());
			oMap.put("GONDEREN_BANKA", fastGidenTx.getGonderenBankaKodu());
			oMap.put("ALAN_BANKA", fastGidenTx.getAlanBankaKodu());
			oMap.put("SORGU_NO", fastGidenTx.getSorguNo());
			oMap.put("ACIKLAMA", fastGidenTx.getAciklama());
			oMap.put("IADE_TALEP_KODU", fastGidenTx.getIadeTalebiSebebi());
			oMap.put("DURUM", fastGidenTx.getDurum());
			oMap.put("ILGILI_ISLEM_TARIH", fastGidenTx.getIlgiliIslemTarih());
			oMap.put("ILGILI_GONDEREN_KATILIMCI", fastGidenTx.getIlgiliGonderenKatilimci());
			oMap.put("ILGILI_ISLEM_SORGU_NO", fastGidenTx.getIlgiliIslemSorguNo());
			oMap.put("ILGILI_ISLEM_TXNO", fastGidenTx.getIlgiliIslemTxNo());
			
	        return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
	@GraymoundService("BNSPR_TRN8319_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {

		GMMap oMap = new GMMap();
		GMMap iMap2 = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal"); 
			FastGidenTx fastGidenTx = (FastGidenTx) session.get(FastGidenTx.class, iMap.getBigDecimal("ISLEM_NO")); 
			session.refresh(fastGidenTx);
			iMap2.put("ALN_KAT_KOD", fastGidenTx.getAlanBankaKodu());
			iMap2.put("IADE_TLB_SBP", fastGidenTx.getIadeTalebiSebebi());
			iMap2.put("ACKLM", fastGidenTx.getAciklama());
			iMap2.put("SN", fastGidenTx.getSorguNo());
			
            iMap2.put("ILG_MES_REF_BLG", 0, "TRH", fastGidenTx.getIlgiliIslemTarih());
            iMap2.put("ILG_MES_REF_BLG", 0, "GON_KAT_KOD", fastGidenTx.getIlgiliGonderenKatilimci());
            iMap2.put("ILG_MES_REF_BLG", 0, "SRG_NO", fastGidenTx.getIlgiliIslemSorguNo());

			oMap = GMServiceExecuter.call("BNSPR_FAST_OUTGOING_REFUND", iMap2);
			
			
			return oMap;

	   } catch (Exception e) {
	     	throw ExceptionHandler.convertException(e);
	     } 
		
	}	
		
}	
