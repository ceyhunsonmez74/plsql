package tr.com.calikbank.bnspr.fast.services;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.FastGelenTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class FastTRN8320Services {

	@GraymoundService("BNSPR_TRN8320_GET_INFO")
	public static GMMap getTRN8320GetInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
	                                                                  
			GMMap oMap=new GMMap();
	        
			FastGelenTx fastGelenTx = (FastGelenTx) session.load(FastGelenTx.class, iMap.getBigDecimal("TRX_NO"));	

			oMap.put("MESAJ_KODU", fastGelenTx.getMesajKodu());
			oMap.put("FAST_TARIH", fastGelenTx.getMesajTarih());
			oMap.put("GONDEREN_BANKA", fastGelenTx.getGonderenBankaKodu());
			oMap.put("ALAN_BANKA", fastGelenTx.getAlanBankaKodu());
			oMap.put("SORGU_NO", fastGelenTx.getSorguNo());
			oMap.put("ACIKLAMA", fastGelenTx.getAciklama());
			oMap.put("IADE_TALEP_KODU", fastGelenTx.getIadeTalebiSebebi());
			oMap.put("DURUM", fastGelenTx.getDurum());
			oMap.put("ILGILI_ISLEM_TARIH", fastGelenTx.getIlgiliIslemTarih());
			oMap.put("ILGILI_GONDEREN_KATILIMCI", fastGelenTx.getIlgiliGonderenKatilimci());
            oMap.put("DISPLAY_GONDEREN_BANKA", LovHelper.diLov(fastGelenTx.getIlgiliGonderenKatilimci(), "8317/LOV_BANKA", "BANKA_ADI"));			
			oMap.put("ILGILI_ISLEM_SORGU_NO", fastGelenTx.getIlgiliIslemSorguNo());
			oMap.put("ILGILI_ISLEM_TXNO", fastGelenTx.getIlgiliIslemTxNo());
			
	        return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}
	
		
}	
