package tr.com.calikbank.bnspr.fast.services;

import org.hibernate.Session;

import tr.com.aktifbank.bnspr.dao.FastGidenTx;
import tr.com.calikbank.bnspr.core.exception.ExceptionHandler;
import tr.com.calikbank.bnspr.util.DALUtil;
import tr.com.calikbank.bnspr.util.LovHelper;

import com.graymound.annotation.GraymoundService;
import com.graymound.server.dao.DAOSession;
import com.graymound.service.GMServiceExecuter;
import com.graymound.util.GMMap;

public class FastTRN8311Services {


	@GraymoundService("BNSPR_TRN8311_SAVE")
	public static GMMap save(GMMap iMap) {
		try {

			Session session = DAOSession.getSession("BNSPRDal");
			FastGidenTx fastGidenTx = (FastGidenTx) session.get(FastGidenTx.class, iMap.getBigDecimal("TRX_NO"));
			
			if (fastGidenTx == null) {
				fastGidenTx = new FastGidenTx();
				fastGidenTx.setTxNo(iMap.getBigDecimal("TRX_NO"));
			}
			
			fastGidenTx.setMesajKodu(iMap.getString("MESAJ_KODU"));
			fastGidenTx.setMesajTarih(iMap.getDate("FAST_TARIH"));
			fastGidenTx.setGonderenBankaKodu(iMap.getString("GONDEREN_BANKA"));
			fastGidenTx.setAlanBankaKodu(iMap.getString("ALAN_BANKA"));
			fastGidenTx.setSorguNo(iMap.getBigDecimal("SORGU_NO"));
			fastGidenTx.setFastTutar(iMap.getBigDecimal("FAST_TUTAR"));
			fastGidenTx.setMusteriNo(iMap.getBigDecimal("MUSTERI_NO"));
			fastGidenTx.setMusteriHesapNo(iMap.getBigDecimal("MUSTERI_HESAP_NO"));
			fastGidenTx.setGonderen(iMap.getString("GONDEREN"));
			fastGidenTx.setGonderenIban(iMap.getString("GONDEREN_IBAN"));
			fastGidenTx.setGonderenKimlikNumarasi(iMap.getString("GONDEREN_KIMLIK_NUMARASI"));
			fastGidenTx.setAliciAdi(iMap.getString("ALICI_ADI"));
			fastGidenTx.setAliciHesapNo(iMap.getString("ALICI_HESAP_NO"));
			fastGidenTx.setAliciKimlikNumarasi(iMap.getString("ALICI_KIMLIK_NUMARASI"));
			fastGidenTx.setIadeKodu(iMap.getString("IADE_KODU"));
			fastGidenTx.setAciklama(iMap.getString("ACIKLAMA"));
			fastGidenTx.setGonderenAdres(iMap.getString("GONDEREN_ADRES"));
			fastGidenTx.setGonderenPasaportNo(iMap.getString("GONDEREN_PASAPORT_NO"));
			fastGidenTx.setGonderenDogumTarihi(iMap.getDate("GONDEREN_DOGUM_TARIHI"));
			fastGidenTx.setGonderenDogumYeri(iMap.getString("GONDEREN_DOGUM_YERI"));
			fastGidenTx.setGonderenMusteriNumarasi(iMap.getString("GONDEREN_MUSTERI_NUMARASI"));
			fastGidenTx.setIlgiliIslemTarih(iMap.getDate("ILGILI_ISLEM_TARIH"));
			fastGidenTx.setIlgiliGonderenKatilimci(iMap.getString("ILGILI_GONDEREN_KATILIMCI"));
			fastGidenTx.setIlgiliIslemSorguNo(iMap.getBigDecimal("ILGILI_ISLEM_SORGU_NO"));
			fastGidenTx.setIlgiliIslemTxNo(iMap.getBigDecimal("ILGILI_ISLEM_TXNO"));
			fastGidenTx.setDurum(iMap.getString("DURUM"));
			
			session.saveOrUpdate(fastGidenTx);
			session.flush();
			
			iMap.put("TRX_NAME", "8311");

			GMMap oMap = GMServiceExecuter.call("BNSPR_TRX_SEND_TRANSACTION", iMap);
			return oMap;
		} catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		} 
	}
			
	@GraymoundService("BNSPR_TRN8311_GET_INFO")
	public static GMMap getTRN8311GetInfo(GMMap iMap) {
		try{
			Session session = DAOSession.getSession("BNSPRDal");
	                                                                  
			GMMap oMap=new GMMap();
	        
			FastGidenTx fastGidenTx = (FastGidenTx) session.load(FastGidenTx.class, iMap.getBigDecimal("TRX_NO"));	
			oMap.put("MESAJ_KODU", fastGidenTx.getMesajKodu());
			oMap.put("FAST_TARIH", fastGidenTx.getMesajTarih());
			oMap.put("GONDEREN_BANKA", fastGidenTx.getGonderenBankaKodu());
			oMap.put("ALAN_BANKA", fastGidenTx.getAlanBankaKodu());
            oMap.put("DISPLAY_ALAN_BANKA_KODU", LovHelper.diLov(fastGidenTx.getAlanBankaKodu(), "8315/LOV_ALAN_BANKA", "BANKA_ADI"));
			oMap.put("SORGU_NO", fastGidenTx.getSorguNo());
			oMap.put("FAST_TUTAR", fastGidenTx.getFastTutar());
			oMap.put("MUSTERI_NO", fastGidenTx.getMusteriNo());
	        oMap.put("DISPLAY_MUSTERI_ADI" , LovHelper.diLov(fastGidenTx.getMusteriNo(), "8315/LOV_MUSTERI", "UNVAN"));
			oMap.put("MUSTERI_HESAP_NO", fastGidenTx.getMusteriHesapNo());
			oMap.put("GONDEREN", fastGidenTx.getGonderen());
			oMap.put("GONDEREN_IBAN", fastGidenTx.getGonderenIban());
			oMap.put("GONDEREN_KIMLIK_NUMARASI", fastGidenTx.getGonderenKimlikNumarasi());
			oMap.put("ALICI_ADI", fastGidenTx.getAliciAdi());
			oMap.put("ALICI_HESAP_NO", fastGidenTx.getAliciHesapNo());
			oMap.put("ALICI_KIMLIK_NUMARASI", fastGidenTx.getAliciKimlikNumarasi());
			oMap.put("ACIKLAMA", fastGidenTx.getAciklama());
			oMap.put("GONDEREN_ADRES", fastGidenTx.getGonderenAdres());
			oMap.put("GONDEREN_PASAPORT_NO", fastGidenTx.getGonderenPasaportNo());
			oMap.put("GONDEREN_DOGUM_TARIHI", fastGidenTx.getGonderenDogumTarihi());
			oMap.put("GONDEREN_DOGUM_YERI", fastGidenTx.getGonderenDogumYeri());
			oMap.put("GONDEREN_MUSTERI_NUMARASI", fastGidenTx.getGonderenMusteriNumarasi());
			oMap.put("IADE_KODU", fastGidenTx.getIadeKodu());
			oMap.put("DURUM", fastGidenTx.getDurum());
			oMap.put("ILGILI_ISLEM_TARIH", fastGidenTx.getIlgiliIslemTarih());
			oMap.put("ILGILI_GONDEREN_KATILIMCI", fastGidenTx.getIlgiliGonderenKatilimci());
			oMap.put("ILGILI_ISLEM_SORGU_NO", fastGidenTx.getIlgiliIslemSorguNo());
			oMap.put("ILGILI_ISLEM_TXNO", fastGidenTx.getIlgiliIslemTxNo());
			
	        return oMap;
		}
		catch (Exception e) {
			throw ExceptionHandler.convertException(e);
		}
	}

	@GraymoundService("BNSPR_TRN8311_AFTER_APPROVAL")
	public static GMMap afterApproval(GMMap iMap) {

		GMMap oMap = new GMMap();
		GMMap iMap2 = new GMMap();
		
		try {
			
			Session session = DAOSession.getSession("BNSPRDal"); 
			FastGidenTx fastGidenTx = (FastGidenTx) session.get(FastGidenTx.class, iMap.getBigDecimal("ISLEM_NO")); 
			session.refresh(fastGidenTx);
			iMap2.put("ALN_KAT_KOD", fastGidenTx.getAlanBankaKodu());
			iMap2.put("TTR", fastGidenTx.getFastTutar());
			iMap2.put("GON_AD", fastGidenTx.getGonderen());
			iMap2.put("GON_HES_NO", fastGidenTx.getGonderenIban());
			iMap2.put("GON_KIM_NO", fastGidenTx.getGonderenKimlikNumarasi());
			iMap2.put("ALC_AD", fastGidenTx.getAliciAdi());
			iMap2.put("ALC_HES_NO", fastGidenTx.getAliciHesapNo());
			iMap2.put("ALC_KIM_NO", fastGidenTx.getAliciKimlikNumarasi());
			iMap2.put("IADE_KOD", fastGidenTx.getIadeKodu());
			iMap2.put("ACKLM", fastGidenTx.getAciklama());
			iMap2.put("SN", fastGidenTx.getSorguNo());
			
			iMap2.put("ODM_AYRNT", 0, "ADRES", fastGidenTx.getGonderenAdres());
			iMap2.put("ODM_AYRNT", 0, "PASAPORT", fastGidenTx.getGonderenPasaportNo());
			iMap2.put("ODM_AYRNT", 0, "DGM_YER", fastGidenTx.getGonderenDogumYeri());
			iMap2.put("ODM_AYRNT", 0, "DGM_TRH", fastGidenTx.getGonderenDogumTarihi());
			iMap2.put("ODM_AYRNT", 0, "MUS_NO", fastGidenTx.getGonderenMusteriNumarasi());
			
            
            iMap2.put("ILG_MES_REF_BLG", 0, "TRH", fastGidenTx.getIlgiliIslemTarih());
            iMap2.put("ILG_MES_REF_BLG", 0, "GON_KAT_KOD", fastGidenTx.getIlgiliGonderenKatilimci());
            iMap2.put("ILG_MES_REF_BLG", 0, "SRG_NO", fastGidenTx.getIlgiliIslemSorguNo());

			oMap = GMServiceExecuter.call("BNSPR_FAST_OUTGOING_PAYMENT_REFUND", iMap2);
			
			
			return oMap;

	   } catch (Exception e) {
	     	throw ExceptionHandler.convertException(e);
	     } 
		
	}	
	

}
