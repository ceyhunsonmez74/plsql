package tr.com.calikbank.bnspr.fast.services;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

public class FastCoreServicesUtility {

	private static String DF_YYYY_MM_DD="yyyy-MM-dd";
	
	private static DecimalFormat getDecimatFormat(String pattern){
		DecimalFormat decimalFormat=(pattern!=null)?(new DecimalFormat(pattern)):(new DecimalFormat());
		DecimalFormatSymbols symbols = new DecimalFormatSymbols();
		symbols.setDecimalSeparator(',');
		symbols.setGroupingSeparator('.');
		decimalFormat.setDecimalFormatSymbols(symbols);
		decimalFormat.setParseBigDecimal(true);
		return decimalFormat;
	}
	public static String formatBigDecimal(BigDecimal decimal){
		return decimal!=null?getDecimatFormat("0.00").format(decimal):null;
	}
	public static BigDecimal toBigDecimal(String decimal) throws ParseException{
		return decimal!=null?(BigDecimal)getDecimatFormat(null).parse(decimal):null;
	}
	
	public static String formatDate(Date date){
		return formatDate(date, DF_YYYY_MM_DD);
	}
	public static String formatDate(Date date, String pattern){
		if (date!=null){
			if(pattern!=null){
				SimpleDateFormat sdf=new SimpleDateFormat(pattern);
				return sdf.format(date);
			}
			return date.toString();
		}
		return null;
	}
	public static Date toDateFromString(String date) throws ParseException{
		return toDateFromString(date, DF_YYYY_MM_DD);
	}
	public static Date toDateFromString(String date, String pattern) throws ParseException{
		if (date!=null && pattern!=null){
			SimpleDateFormat sdf=new SimpleDateFormat(pattern);
			return sdf.parse(date);
		}
		return null;
	}
	
	public static String toStringFromXMLGreCal(XMLGregorianCalendar calendar){
		return calendar!=null?calendar.toString():null;
	}
	public static Date toDateFromXMLGreCalString(String calendar) throws DatatypeConfigurationException {
		return calendar!=null?DatatypeFactory.newInstance().newXMLGregorianCalendar(calendar).toGregorianCalendar().getTime():null;
	}
	public static XMLGregorianCalendar toXMLGreCalFromDate(Date date) throws DatatypeConfigurationException{
		return toXMLGreCalFromDate(date, DF_YYYY_MM_DD);
	}
	public static XMLGregorianCalendar toXMLGreCalFromDate(Date date, String pattern) throws DatatypeConfigurationException{
		if(date!=null && pattern!=null){
			SimpleDateFormat sdf=new SimpleDateFormat(pattern);
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(sdf.format(date));
		}
		return null;
	}
	
}
